#!/usr/bin/env python3
"""Retrieve optional photographic candidates from an independently frozen core."""
from __future__ import annotations

import argparse
import json
import os
import secrets
import sys
from pathlib import Path

import prompt_generator as generator
from photo_camera_evidence import CAMERA_AXES, require_camera_evidence, camera_authoring_declaration


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__, allow_abbrev=False)
    for argument in ("request-envelope-json", "authorial-core-json", "creative-controls-json", "embodiment-review-json"):
        parser.add_argument("--" + argument, required=True)
    parser.add_argument("--visual-intent-json")
    parser.add_argument('--slot-expression-json', type=Path,
                        help='Sealed authored goals and exact role queries, required before candidate access.')
    parser.add_argument('--precap-bundle-json',type=Path,
                        help='Opt-in sealed pre-cap shortlist and direct whole-source review.')
    parser.add_argument('--slot-query-context-json',type=Path,
                        help='Exact frozen query execution used to prepare the pre-cap shortlist; never re-embed on finalization.')
    parser.add_argument("--require-camera-evidence", action="append", choices=CAMERA_AXES, default=[],
                        help="New authoring: verify each requester-owned camera axis has explicit frozen evidence.")
    parser.add_argument("--new-author-camera-evidence", action="store_true",
                        help="Require owner and separate direction/height declarations when camera is an open or locked dimension.")
    parser.add_argument('--retrieval-mode',choices=('hybrid_required','keyword_only'),default='hybrid_required',help='keyword_only is explicit diagnostic retrieval.')
    parser.add_argument('--embedding-env-file',type=Path)
    parser.add_argument('--query-cache',type=Path)
    parser.add_argument('--slot',action='append',help='Explicit managed slot; every requested slot searches the entire positive pool.')
    parser.add_argument('--query-language',choices=('en','ko'),default='en')
    parser.add_argument("--seed", type=int)
    parser.add_argument("--output-file")
    parser.add_argument("--runtime-store", help="Runtime-owned generation/cache directory.")
    parser.add_argument("--source-root", help="Photo skill root; default is this installed skill.")
    parser.add_argument("--source-mode", choices=("local_current", "remote_before_retrieval"), default="local_current")
    parser.add_argument("--source-remote", help="Explicit Git remote URL for remote_before_retrieval.")
    parser.add_argument("--source-ref", default="main")
    parser.add_argument("--runtime-receipt", help="Save the private generation/pack binding separately from the public pack.")
    args = parser.parse_args(argv)
    if bool(args.precap_bundle_json)!=bool(args.slot_query_context_json):
        raise ValueError('pre-cap finalization requires its exact frozen query context')
    envelope = generator.load_request_envelope_arg(args.request_envelope_json)
    controls = json.loads(Path(args.creative_controls_json).read_text(encoding="utf-8"))
    core = generator.load_authorial_core_arg(args.authorial_core_json, request_envelope=envelope,
                                            creative_control_snapshot=controls)
    import photo_slot_expression as expression
    from photo_workflow import slot_intent_material
    source_root = Path(args.source_root) if args.source_root else Path(__file__).resolve().parents[1]
    neutral_catalog = expression.specification(json.loads((source_root / 'assets/photo_candidate_slot_catalog.json').read_bytes())['slot_catalog'])
    material = slot_intent_material(core, controls, neutral_catalog, args.slot)
    if args.slot_expression_json is None:
        print(json.dumps({'status': 'needs_slot_intent_authoring', 'required_input': '--slot-expression-json',
                          'material': material}, ensure_ascii=False, indent=2))
        return 0
    expression_plan = json.loads(args.slot_expression_json.read_bytes())
    expression.validate(expression_plan, core, controls, neutral_catalog, material['requested_slot_ids'])
    # Configuration/interpreter selection begins only after authored intentions
    # validate; a missing plan must not initialize models or runtime sources.
    if argv is None and args.source_mode=='local_current':
        from photo_local_embedding import ROOT, runtime_lock
        configuration=source_root/'embedding-default.json'
        if configuration.is_file() and json.loads(configuration.read_bytes()).get('provider')=='embeddinggemma2-local':
            runtime=runtime_lock(verify=False);python=ROOT/runtime['python']
            if Path(sys.prefix).resolve()!=python.parents[1].resolve():
                os.execv(str(python),[str(python),str(Path(__file__).resolve()),*sys.argv[1:]])
    require_camera_evidence(core, args.require_camera_evidence)
    lock = core["intent_lock"]
    camera_declared = "camera" in set(lock["locked_dimensions"]) | set(lock["open_dimensions"])
    # An absent camera domain permits neither an advisory assertion nor a new
    # camera choice. Preserve that valid closed scope; explicit requester-axis
    # checks above and validation of any supplied declaration still apply.
    camera_authoring_declaration(core, required=args.new_author_camera_evidence and camera_declared)
    embodiment = json.loads(Path(args.embodiment_review_json).read_text(encoding="utf-8"))
    # No candidate data is loaded until all authored inputs are validated.
    generator.photo_embodiment.build_policy(core, embodiment)
    preparation=None
    if args.query_cache and not args.query_cache.exists() and args.source_mode=='local_current':
        from photo_local_embedding import ROOT, runtime_lock, preload
        configuration=(Path(args.source_root) if args.source_root else ROOT)/'embedding-default.json'
        if configuration.is_file() and json.loads(configuration.read_bytes()).get('provider')=='embeddinggemma2-local':
            lock=runtime_lock()
            if Path(sys.prefix).resolve()==(ROOT/lock['python']).parents[1].resolve():
                from concurrent.futures import ThreadPoolExecutor
                preparation=ThreadPoolExecutor(max_workers=1);prepared=preparation.submit(preload)
    # Use the skill's pinned numeric dependencies without changing the caller's
    # environment. Revalidate all authored inputs in the managed interpreter.
    if argv is None and args.source_mode=='local_current':
        from photo_local_embedding import ROOT, runtime_lock
        source=Path(args.source_root) if args.source_root else ROOT
        manifest=source/'assets/photo_candidate_search.json'
        if manifest.is_file() and json.loads(manifest.read_bytes()).get('space',{}).get('provider')=='embeddinggemma2-local':
            lock=runtime_lock(verify=False);python=ROOT/lock['python']
            if Path(sys.prefix).resolve()!=python.parents[1].resolve():
                os.execv(str(python),[str(python),str(Path(__file__).resolve()),*sys.argv[1:]])
    from photo_runtime_sources import RuntimeSnapshotProvider, SKILL_ROOT
    provider = RuntimeSnapshotProvider(Path(args.source_root) if args.source_root else SKILL_ROOT,
        Path(args.runtime_store) if args.runtime_store else None,
        mode=args.source_mode, remote=args.source_remote or "", ref=args.source_ref)
    snapshot = provider.acquire()
    data = snapshot.data.for_core(core)
    if preparation:
        try:prepared.result()
        finally:preparation.shutdown(wait=True)
    visual_intent = generator.load_visual_intent_arg(
        args.visual_intent_json, data[generator.VISUAL_OBLIGATIONS_DATA_KEY],
        data[generator.VISUAL_PROFILE_INDEX_DATA_KEY])
    if args.embedding_env_file:
        from photo_embedding_provider import load_env
        load_env(args.embedding_env_file)
    pack = generator.generate_candidate_pack(
        data, core, controls, embodiment,
        seed=args.seed if args.seed is not None else secrets.randbits(63),
        visual_intent=visual_intent,retrieval_mode=args.retrieval_mode,query_cache=args.query_cache or provider.publisher.store/"query-embeddings",requested_slots=material['requested_slot_ids'],query_language=args.query_language,
        expression_plan=expression_plan,
        query_context=json.loads(args.slot_query_context_json.read_bytes()) if args.slot_query_context_json else None,
        precap_bundle=json.loads(args.precap_bundle_json.read_bytes()) if args.precap_bundle_json else None)
    receipt = provider.receipt(snapshot, pack)
    receipt_path = args.runtime_receipt or (str(args.output_file) + ".runtime-receipt.json" if args.output_file else None)
    if receipt_path:
        Path(receipt_path).write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    output = json.dumps([pack], ensure_ascii=False, indent=2) + "\n"
    if args.output_file:
        Path(args.output_file).write_text(output, encoding="utf-8")
    else:
        print(output, end="")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (ValueError, KeyError, FileNotFoundError, json.JSONDecodeError) as exc:
        print(f"Error: {exc}", file=sys.stderr)
        raise SystemExit(1)
