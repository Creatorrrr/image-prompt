"""Bounded pre-presentation search and caller-authored whole-source judgments.

No model, network or implicit semantic classifier. Review seals prove binding,
not natural-language truth, native qualification, permission or adoption.
"""
from __future__ import annotations
import copy
import hashlib
import photo_candidate_corpus as c
import photo_candidate_realizations as realizations
import photo_global_retrieval as guards
import photo_role_proposals as roles
import photo_semantic_evidence as semantic
import photo_slot_expression as expression
import photo_slot_queries as queries
import photo_sharded_search as search
import photo_preview_ranking as ranking
import photo_review_window as review_window
import photo_common_meaning as common_meaning
import photo_common_selection as common_selection
from bm25f_retrieval import reciprocal_rank_fusion

SHORTLIST_SCHEMA = 'photo-precap-shortlist/v1'
REVIEW_SCHEMA = 'photo-precap-whole-source-review/v1'
POLICY = {'recipe': 'photo-balanced-precap/v1', 'lane_limit': 384,
          'shortlist_limit': 8, 'maximum_examined': 256,
          'ordering': 'round_robin_rrf_bm25f_embedding', 'tag_admission_filter': False}
RETRIEVAL_VERSION = 'photo-slot-retrieval/precap-v1'
ALGORITHM = 'independent_global_bm25f_certified_cosine_rrf_precap/v1'
# A known non-contribution is distinct from both contradiction and unknown.
STATES = frozenset({'direct_fit', 'fit_with_permitted_refinement', 'conflict', 'not_role_fit', 'uncertain'})
FIT = frozenset({'direct_fit', 'fit_with_permitted_refinement'})
SHORTLIST_FIELDS = frozenset({'schema','core_sha256','controls_sha256','plan','query_context_sha256',
    'corpus_sha256','index_sha256','catalog_sha256','bindings_sha256','requested_slots',
    'query_language','policy','eligible_candidates','slots','proposals','canonical_sha256'})
REVIEW_FIELDS = frozenset({'schema','author','shortlist_sha256','decisions','native_approval',
    'semantic_approval','canonical_sha256'})
DECISION_FIELDS = frozenset({'slot_id','candidate_id','realization_id','source_record_sha256',
    'goal_sha256','state','rationale','source_quotes','permitted_refinements','whole_source_conflict'})

def seal(value):
    value = copy.deepcopy(value)
    value['canonical_sha256'] = c.digest({k:v for k,v in value.items() if k!='canonical_sha256'})
    return value

def _checksum(value, schema, fields):
    if (not isinstance(value,dict) or set(value)!=fields or value.get('schema')!=schema
            or value.get('canonical_sha256')!=c.digest({k:v for k,v in value.items() if k!='canonical_sha256'})):
        raise ValueError('foreign or modified pre-cap contract')

def balanced_order(rrf, lexical, dense):
    """No CID-specific preference. Preserve each lane and unmodified RRF ranks."""
    seen=set(); result=[]
    for pos in range(max(map(len,(rrf,lexical,dense)),default=0)):
        for lane in (rrf,lexical,dense):
            if pos<len(lane):
                cid=lane[pos]['document_id']
                if cid not in seen: result.append(cid);seen.add(cid)
    return result

def prepare(data, core, controls, context, *, requested_slots=None, language='en', ranking_policy=None):
    import prompt_generator as g
    reader=data['_search_reader'];reader.check_presence()
    policy=ranking.policy(ranking_policy) if ranking_policy else dict(POLICY)
    plan=(context or {}).get('expression_plan')
    slots=sorted(set(requested_slots if requested_slots is not None else (plan or {}).get('slots',{})))
    expression.validate(plan,core,controls,data['slot_catalog'],slots)
    fields=queries.validate_set(context,core,controls,data['slot_catalog'],slots,space=reader.manifest['space'])
    common=ranking.is_common(ranking_policy)
    if common and 'common_intents' not in context:raise ValueError('common-meaning selection requires authored intent graphs')
    allowed,source_roles,contract=guards.eligible(data,core,controls)
    _,picked=g.frozen_core_context(data,core,controls)
    gd=dict(data);gd['candidates']=reader.meta['guards']
    declared={}
    for bid,row in data['slot_bindings'].items(): declared.setdefault(row['candidate_id'],[]).append(bid)
    traces={};proposals={}
    for slot in slots:
        intention=plan['slots'][slot]
        if intention['status']!='search':
            traces[slot]={'state':intention['status'],'candidates':[], 'reason':intention['reason'],
                          'lanes':None,'rrf':[],'stop_reason':'authored_'+intention['status']}
            continue
        row=context['slots'][slot]
        if row['binding']['caller_language']!=language: raise ValueError('pre-cap query language changed')
        if row['binding']['recipe']!=policy.get('query_recipe',queries.RECIPE):raise ValueError('ranking query recipe mismatch')
        lh=search.lexical_rank(reader,fields[slot],allowed,policy['lane_limit'])
        vh,proof=search.cosine_rank(reader,row['vector'],allowed,policy['lane_limit'])
        fused=reciprocal_rank_fusion([[h['document_id'] for h in lh],[h['document_id'] for h in vh]],k=30)
        candidates=[];examined=[];rejected=[];scores={};duplicates={};allocation=[]
        pool_ids,seed_count=ranking.pool(fused,lh,vh) if ranking_policy else (balanced_order(fused,lh,vh),0)
        fused_by_id={h['document_id']:h for h in fused}
        blocked=g.slot_block_reason(data,slot,contract)
        for cid in ([] if blocked else pool_ids):
            if len(examined)>=policy['maximum_examined']:break
            if not ranking.feature(policy,'pool') and len(candidates)>=(seed_count if ranking_policy else policy['shortlist_limit']):break
            examined.append(cid)
            possible=realizations.eligible_ids(gd,cid,core,contract,picked,slot,allow_owner_selection_pending=True)
            if not possible: rejected.append(cid);continue
            proposal=roles.propose(data,slot,cid,source_roles[cid],declared.get(cid,[]),realization_ids=possible)
            if (proposal['applicability_status']=='incompatible' or
                    not g.core_entry_eligible(data,core,contract,picked,slot,roles.entry(gd,proposal),allow_owner_selection_pending=True)):
                rejected.append(cid);continue
            proposals[proposal['proposal_id']]=proposal
            candidates.append({'candidate_id':cid,'realization_id':proposal['realization_id'],
                'proposal_id':proposal['proposal_id'],'source_record_sha256':reader.meta['record_sha256'][cid],
                'goal_sha256':c.digest(intention)})
            if ranking_policy:
                record=data['candidates'][cid]
                scores[cid]=ranking.score(record,proposal['realization_id'],intention,fused_by_id[cid],policy['weights'])
                if common:
                    scores[cid]=common_selection.score(scores[cid],common_meaning.lookup(data,cid,proposal['realization_id']),context['common_intents'][slot])
                import photo_retrieval_relevance as relevance
                duplicates[cid]=relevance.duplicate_key(record,proposal['realization_id'])
        eligible_rows=list(candidates)
        if ranking_policy:
            if ranking.feature(policy,'evidence_order'):scores=ranking.evidence_order(scores,fused)
            order=ranking.ranked(scores,fused)
            selected,allocation=(review_window.window_order(scores,fused,lh,vh,duplicates,balanced=ranking.feature(policy,'window')) if common else ranking.allocate(order,lh,vh,duplicates))
            by_id={r['candidate_id']:r for r in candidates};candidates=[by_id[cid] for cid in selected]
        repair_stop=('slot_blocked' if blocked else 'generated_pool_exhausted' if len(examined)==len(pool_ids)
                     else 'maximum_examined' if len(examined)>=policy['maximum_examined'] else 'seed_target_reached')
        pipeline=({'generated_candidate_ids':pool_ids,'examined':len(examined),'role_rejected':len(rejected),
                   'scored':len(scores),'unique_meaning_groups':len(set(duplicates.values())),
                   'scored_candidate_rows':eligible_rows,'duplicate_groups':duplicates,
                   'window_candidate_ids':[r['candidate_id'] for r in candidates],
                   'maximum_examined_reached':len(examined)>=policy['maximum_examined']} if policy.get('repair_features') else None)
        traces[slot]={'state':'executed','candidates':candidates,'query_sha256':hashlib.sha256(row['text'].encode()).hexdigest(),
            'lanes':{'bm25f':lh,'embedding':vh},'cosine_proof':proof,'rrf':fused,
            'examined_candidate_ids':examined,'role_rejected_candidate_ids':rejected,'role_block_reason':blocked,
            **({'ranking_scores':scores,'pool_candidate_ids':list(scores),'pool_seed_count':seed_count,'allocation_trace':allocation} if ranking_policy else {}),
            **({'pipeline':pipeline} if pipeline is not None else {}),
            'stop_reason':(repair_stop if pipeline is not None else 'slot_blocked' if blocked else 'preview_budget' if len(candidates)==POLICY['shortlist_limit']
                           else 'examined_budget' if len(examined)>=policy['maximum_examined'] else 'lane_union_exhausted')}
    return seal({'schema':SHORTLIST_SCHEMA,'core_sha256':c.digest(core),'controls_sha256':c.digest(controls),
        'plan':plan,'query_context_sha256':context['canonical_sha256'],'corpus_sha256':reader.meta['corpus_sha256'],
        'index_sha256':data['_global_index_sha256'],'catalog_sha256':c.digest(data['slot_catalog']),
        'bindings_sha256':c.digest(data['slot_bindings']),'requested_slots':slots,'query_language':language,
        'policy':policy,'eligible_candidates':len(allowed),'slots':traces,'proposals':proposals})

def validate_shortlist(shortlist, data, core, controls, context, *, replay=True):
    _checksum(shortlist,SHORTLIST_SCHEMA,SHORTLIST_FIELDS)
    if len(c.canonical_bytes(shortlist))>32*1024*1024: raise ValueError('pre-cap shortlist exceeds byte budget')
    policy=shortlist['policy']
    if not isinstance(policy,dict) or (policy!=POLICY and policy!=ranking.policy(policy.get('variant'))): raise ValueError('pre-cap search policy changed')
    slots=shortlist['requested_slots']
    if not isinstance(slots,list) or slots!=sorted(set(slots)) or not 1<=len(slots)<=149:
        raise ValueError('bounded exact pre-cap slot set required')
    expression.validate(shortlist['plan'],core,controls,data['slot_catalog'],slots)
    reader=data['_search_reader']
    checks={'core_sha256':c.digest(core),'controls_sha256':c.digest(controls),
        'query_context_sha256':context['canonical_sha256'],'corpus_sha256':reader.meta['corpus_sha256'],
        'index_sha256':data['_global_index_sha256'],'catalog_sha256':c.digest(data['slot_catalog']),
        'bindings_sha256':c.digest(data['slot_bindings'])}
    if any(shortlist[k]!=v for k,v in checks.items()): raise ValueError('pre-cap source, goal or query changed')
    if set(shortlist['slots'])!=set(slots): raise ValueError('pre-cap slot coverage changed')
    if replay and shortlist!=prepare(data,core,controls,context,requested_slots=slots,language=shortlist['query_language'],ranking_policy=policy.get('variant')):
        raise ValueError('pre-cap shortlist differs from exact search replay')
    return shortlist

def _source(data, short, decision):
    slot=decision['slot_id'];cid=decision['candidate_id'];rid=decision['realization_id']
    matches=[r for r in short['slots'].get(slot,{}).get('candidates',[]) if r['candidate_id']==cid and r['realization_id']==rid]
    if len(matches)!=1: raise ValueError('decision does not name one frozen preview CID/RID')
    row=matches[0];record=data['candidates'][cid]
    if (decision['source_record_sha256']!=row['source_record_sha256'] or c.digest(record)!=row['source_record_sha256']
            or data['_search_reader'].meta['record_sha256'][cid]!=row['source_record_sha256']
            or decision['goal_sha256']!=row['goal_sha256'] or rid not in realizations.ids(record)):
        raise ValueError('pre-cap decision source, realization or goal changed')
    return record

def validate_review(review, shortlist, data):
    _checksum(shortlist,SHORTLIST_SCHEMA,SHORTLIST_FIELDS)
    _checksum(review,REVIEW_SCHEMA,REVIEW_FIELDS)
    if (review['author']!='Codex' or review['shortlist_sha256']!=shortlist['canonical_sha256']
            or review['native_approval'] is not False or review['semantic_approval'] is not False):
        raise ValueError('review is advisory and binds one frozen shortlist')
    rows=review['decisions']
    if (not isinstance(rows,list) or len(rows)>149*shortlist['policy'].get('review_window_limit',8) or len(c.canonical_bytes(review))>4*1024*1024):
        raise ValueError('pre-cap review exceeds bounded decision budget')
    seen=set()
    for d in rows:
        if (not isinstance(d,dict) or set(d)!=DECISION_FIELDS or not isinstance(d['state'],str) or d['state'] not in STATES
                or any(not isinstance(d[k],str) for k in ('slot_id','candidate_id','realization_id','source_record_sha256','goal_sha256'))):
            raise ValueError('explicit whole-source decision required')
        key=(d['slot_id'],d['candidate_id'],d['realization_id'])
        if key in seen: raise ValueError('duplicate pre-cap goal judgment')
        seen.add(key);record=_source(data,shortlist,d)
        if not isinstance(d['rationale'],str) or not d['rationale'].strip() or len(d['rationale'])>6000:
            raise ValueError('explicit bounded semantic rationale required')
        conflict=d['whole_source_conflict']
        if conflict is not None and type(conflict) is not bool: raise ValueError('explicit conflict status required')
        if ((d['state'] in FIT and conflict is not False) or (d['state']=='conflict' and conflict is not True)):
            raise ValueError('fit cannot conceal a whole-source conflict or unknown')
        changes=d['permitted_refinements']
        if (not isinstance(changes,list) or len(changes)>16 or any(not isinstance(v,str) or not v.strip() or len(v)>2000 for v in changes)
                or (d['state']=='fit_with_permitted_refinement' and (not changes or not shortlist['plan']['slots'][d['slot_id']]['open_scope']))
                or (d['state']!='fit_with_permitted_refinement' and changes)):
            raise ValueError('refinement requires explicit changes and authored open scope')
        quotes=d['source_quotes'];rid=d['realization_id']
        if not isinstance(quotes,list) or len(quotes)>12 or (d['state'] in FIT and not quotes):
            raise ValueError('fit needs bounded positive original source quotation')
        paths=semantic.primary_paths(record,rid)
        for q in quotes:
            if (not isinstance(q,dict) or set(q)!={'pointer','quote'} or q['pointer'] not in paths
                    or not isinstance(q['quote'],str) or not q['quote'].strip() or len(q['quote'])>12000
                    or q['quote'] not in semantic.positive_string(record,q['pointer'],realization_id=rid)):
                raise ValueError('pre-cap source quotation changed or is not positive')
    return review

def create_review(shortlist, decisions, data):
    return validate_review(seal({'schema':REVIEW_SCHEMA,'author':'Codex',
        'shortlist_sha256':shortlist['canonical_sha256'],'decisions':copy.deepcopy(decisions),
        'native_approval':False,'semantic_approval':False}),shortlist,data)

def source_view(shortlist, data, candidate_ids=None):
    """Read full payloads only for frozen preview members, once per CID."""
    _checksum(shortlist,SHORTLIST_SCHEMA,SHORTLIST_FIELDS)
    available={row['candidate_id'] for slot in shortlist['slots'].values() for row in slot['candidates']}
    if candidate_ids is not None and not set(candidate_ids)<=available:raise ValueError('source view is limited to frozen review window')
    result={}
    for slot in shortlist['slots'].values():
        for row in (slot['candidates'][:8] if candidate_ids is None else slot['candidates']):
            cid=row['candidate_id']
            if candidate_ids is not None and cid not in candidate_ids:continue
            if cid in result: continue
            record=data['candidates'][cid]
            if c.digest(record)!=row['source_record_sha256']: raise ValueError('pre-cap view source changed')
            result[cid]=record
    return {'schema':'photo-precap-source-view/v1','shortlist_sha256':shortlist['canonical_sha256'],
            'goals':shortlist['plan'],'slots':{s:t['candidates'] for s,t in shortlist['slots'].items()},
            'source_records':result,
            'common_meanings':{row['candidate_id']+'|'+row['realization_id']:common_meaning.lookup(data,row['candidate_id'],row['realization_id'])
                for slot in shortlist['slots'].values() for row in slot['candidates'] if row['candidate_id'] in result},
            'native_approval':False}

def finalize(data, core, controls, context, bundle, *, replay=True, unique_limit=64):
    """Consume every supplied judgment, then apply final 4/2/64 limits.

    Missing judgments abstain. Similarity and the legacy `supported` advisory
    never grant whole-source fit. Native source/role guards remain cumulative.
    """
    import prompt_generator as g
    import photo_retrieval_relevance as relevance
    if not isinstance(bundle,dict) or set(bundle)!={'shortlist','review'} or not 1<=unique_limit<=64:
        raise ValueError('exact pre-cap bundle and bounded final budget required')
    short=bundle['shortlist'];review=bundle['review']
    validate_shortlist(short,data,core,controls,context,replay=replay)
    validate_review(review,short,data)
    decisions={(d['slot_id'],d['candidate_id'],d['realization_id']):d for d in review['decisions']}
    slots=short['requested_slots'];plan=short['plan'];limits={s:4 if data['slot_catalog'][s]['priority']=='core' else 2 for s in slots}
    common_window=ranking.is_common(short['policy'].get('variant'))
    desired={};traces={};proposal_map=short['proposals']
    for slot in slots:
        preview=short['slots'][slot];wanted=[];seen={};assessments={};duplicates={};review_states={}
        fused_by_id={r['document_id']:r for r in preview['rrf']}
        states={(cid,rid):d['state'] for (s,cid,rid),d in decisions.items() if s==slot}
        groups=preview.get('pipeline',{}).get('duplicate_groups') if ranking.feature(short['policy'],'final') else None
        active,rounds=(review_window.active_rows(preview['candidates'],states,limits[slot],FIT,duplicate_groups=groups) if common_window else (preview['candidates'],[len(preview['candidates'])]))
        display=review_window.display_rows(active,states,FIT) if common_window else active
        for row in active:
            cid=row['candidate_id'];d=decisions.get((slot,cid,row['realization_id']))
            review_states[cid]=d['state'] if d else 'unreviewed'
            # Inspect all frozen members before slicing, not only until 4/2 fit.
            if d is None or d['state'] not in FIT: continue
            group=relevance.duplicate_key(data['candidates'][cid],row['realization_id'])
            if group in seen: duplicates[cid]=seen[group];continue
            seen[group]=cid
            wanted.append((cid,row['proposal_id'],fused_by_id[cid]))
        final_trace=[]
        if short['policy']!=POLICY and wanted:
            order,final_trace=ranking.final_order([cid for cid,_,_ in wanted],preview['ranking_scores'],separate_novelty=ranking.feature(short['policy'],'final'))
            by_id={row[0]:row for row in wanted};wanted=[by_id[cid] for cid in order]
        desired[slot]=wanted[:limits[slot]]
        if common_window:
            active_by_id={r['candidate_id']:r for r in active};fit_ids=[cid for cid,_,_ in wanted]
            display=review_window.display_rows([active_by_id[cid] for cid in fit_ids]+[r for r in active if r['candidate_id'] not in fit_ids],states,FIT)
        if preview['state']!='executed':
            from audit_global_retrieval import nonsearch_trace
            traces[slot]=nonsearch_trace(slot,plan['slots'][slot],data['slot_catalog'],short['eligible_candidates'])
            continue
        q=context['slots'][slot];lh=preview['lanes']['bm25f'];vh=preview['lanes']['embedding']
        lh_by_id={r['document_id']:r for r in lh};vh_by_id={r['document_id']:r for r in vh}
        for row in active:
            cid=row['candidate_id']
            assessments[cid]=relevance.assess(data,slot,proposal_map[row['proposal_id']],q['binding'],lh_by_id.get(cid),vh_by_id.get(cid))
        traces[slot]={'state':'executed','search_scope':'whole_shared_positive_corpus','tag_admission_filter':False,
            'query_sha256':preview['query_sha256'],'slot_spec_sha256':q['binding']['slot_spec_sha256'],
            'expression_row_sha256':c.digest(plan['slots'][slot]),'lane_limit':POLICY['lane_limit'],'iterations':1,
            'eligible_candidates':short['eligible_candidates'],'role_block_reason':preview['role_block_reason'],
            'role_rejected_candidate_ids':preview['role_rejected_candidate_ids'],
            'relevance_assessments':assessments,'duplicate_candidate_ids':duplicates,
            'stop_reason':'reviewed_preview_then_final_cap','preview_stop_reason':preview['stop_reason'],
            'presentation_exhaustive':False,'examined_budget_reached':preview['stop_reason']=='examined_budget',
            'prefix_history':[],'lanes':{name:{'state':'executed','positive_hits':len(rows),'ranks':rows}
                for name,rows in preview['lanes'].items()},'cosine_proof':preview['cosine_proof'],'rrf':preview['rrf'],
            'preview_candidate_ids':[r['candidate_id'] for r in display],
            **({'review_window_candidate_ids':[r['candidate_id'] for r in active],'standby_candidate_ids':[r['candidate_id'] for r in preview['candidates'][len(active):]],'review_round_sizes':rounds,'display_limit':8} if common_window else {}),
            'whole_source_review_states':review_states,'unreviewed_count':sum(v=='unreviewed' for v in review_states.values()),
            **({'final_ranking_trace':final_trace,'allocation_trace':preview['allocation_trace'],'ranking_scores':preview['ranking_scores']} if short['policy']!=POLICY else {}),
            'desired_proposal_ids':[pid for _,pid,_ in desired[slot]]}
        if preview.get('pipeline') is not None:
            traces[slot]['pipeline']={**copy.deepcopy(preview['pipeline']),
                'active_candidate_ids':[r['candidate_id'] for r in active],
                'display_candidate_ids':[r['candidate_id'] for r in display],
                'known_fit_unique_groups':len({preview['pipeline']['duplicate_groups'][cid] for cid in fit_ids})}
    admitted={s:[] for s in slots};selected=[]
    priority=sorted(slots,key=lambda s:(data['slot_catalog'][s]['priority']!='core',s))
    for pos in range(max(limits.values(),default=0)):
        for slot in priority:
            if pos>=len(desired[slot]): continue
            cid,pid,hit=desired[slot][pos]
            if cid not in selected:
                if len(selected)>=unique_limit: continue
                selected.append(cid)
            admitted[slot].append((cid,pid,hit))
    presented=dict(data)
    presented['_request_role_proposals']={s:{cid:proposal_map[pid] for cid,pid,_ in admitted[s]} for s in slots}
    cards={}
    for slot in slots:
        rows=[]
        for cid,pid,hit in admitted[slot]:
            proposal=proposal_map[pid]
            row,_=g.candidate_pack_summarize_slot_candidate(presented,slot,{'id':cid,
                'applicability_status':proposal['applicability_status'],'applicability_source':'whole_source_precap_review'})
            row.update(proposal_id=pid,binding_id=proposal['source_binding_id'],realization_id=proposal['realization_id'],
                retrieval_evidence={'rrf_score':hit['score'],'lane_count':hit['lane_count']},
                retrieval_relevance=traces[slot]['relevance_assessments'][cid])
            if common_window:row['discovery_meaning_view']=common_meaning.lookup(data,cid,proposal['realization_id'])
            source=relevance.summary(data['candidates'][cid],proposal['realization_id'])
            if source['concept_units']:
                source.update(affected_dimensions=proposal['effects']['dimensions'],affected_properties=proposal['effects']['properties'],adoption='optional')
                row['_native_semantic_source']=source;row['concept_terms']=source['concept_units']
            else: row['_native_semantic_source']=g.photo_candidate_semantics.semantic_source(roles.entry(data,proposal))
            rows.append(row)
        state=plan['slots'][slot]['status'] if plan['slots'][slot]['status']!='search' else (
            'blocked' if traces[slot]['role_block_reason'] else 'no_hits' if not desired[slot] else
            'budget_excluded' if not rows else 'budget_partial' if len(rows)<len(desired[slot]) else 'available')
        cards[slot]={'slot':slot,'role':data['slot_catalog'][slot]['priority'],'selected':None,'candidates':rows,
            'candidate_count':short['eligible_candidates'],'retrieved_candidate_count':len(traces[slot]['rrf']),
            'candidate_limit':limits[slot],'status':state,'presentation_exhaustive':False,
            'presentation_stop_reason':traces[slot]['stop_reason']}
        if traces[slot].get('pipeline') is not None:traces[slot]['pipeline']['final_candidate_ids']=[r['id'] for r in rows]
    retained={pid:proposal_map[pid] for rows in admitted.values() for _,pid,_ in rows}
    record={'contract_version':RETRIEVAL_VERSION,'algorithm':ALGORITHM,
        'source_authorial_core_sha256':core['canonical_sha256'],'creative_controls_sha256':controls['canonical_sha256'],
        'corpus_sha256':short['corpus_sha256'],'binding_sha256':short['bindings_sha256'],
        'catalog_sha256':short['catalog_sha256'],'index_sha256':short['index_sha256'],
        'query_context_sha256':short['query_context_sha256'],'expression_plan':plan,
        'expression_plan_sha256':plan['canonical_sha256'],'mode':'hybrid_required','query_language':short['query_language'],
        'requested_slot_ids':slots,'active_slot_ids':slots,'inactive_slot_ids':sorted(set(data['slot_catalog'])-set(slots)),
        'presentation_policy':copy.deepcopy(short['policy']),'relevance_policy_sha256':c.digest(relevance.POLICY),
        'rrf_k':30,'minimum_similarity':.30,'slot_searches':traces,'role_proposals':retained,
        'lanes':{name:{'state':'executed' if context['slots'] else 'not_requested','slot_count':len(context['slots'])} for name in ('bm25f','embedding')},
        'eligible_candidates':short['eligible_candidates'],'selected_candidate_ids':selected,'unique_candidate_limit':unique_limit,
        'role_limits':{'core':4,'support':2},'tag_admission_filter':False,'candidate_adoption':'optional','precap_bundle':copy.deepcopy(bundle)}
    _,_,contract=guards.eligible(data,core,controls)
    return cards,seal(record),contract

def audit(pack, data, context):
    """Independent lane/certificate checks, then exact frozen review allocation."""
    from audit_global_retrieval import lexical_replay, fusion
    import photo_native_pack as packs
    failures=[]
    try:
        packs.validate(pack)
        if hasattr(data,'for_core'): data=data.for_core(pack['authorial_core'])
        record=pack['global_retrieval'];short=record['precap_bundle']['shortlist']
        validate_shortlist(short,data,pack['authorial_core'],pack['creative_controls'],context,replay=True)
        allowed,_,_=guards.eligible(data,pack['authorial_core'],pack['creative_controls'])
        for slot,trace in short['slots'].items():
            if trace['state']!='executed': continue
            query=context['slots'][slot]
            lexical=lexical_replay(data['_search_reader'],query['binding']['query_fields'],allowed,POLICY['lane_limit'])
            if lexical!=trace['lanes']['bm25f'] or fusion([lexical,trace['lanes']['embedding']])!=trace['rrf']:
                raise ValueError('independent pre-cap lane/fusion audit failed')
            search.audit_cosine(data['_search_reader'],query['vector'],allowed,trace['lanes']['embedding'],trace['cosine_proof'])
        cards,expected,_=finalize(data,pack['authorial_core'],pack['creative_controls'],context,record['precap_bundle'],replay=False)
        if record!=expected or pack['role_proposals']!=expected['role_proposals']:
            raise ValueError('pre-cap final selection or role authority changed')
        if set(pack['candidate_pool'])!=set(expected['selected_candidate_ids']): raise ValueError('pre-cap unique allocation changed')
        for slot,card in cards.items():
            view=pack['role_views'][slot]
            if any(view.get(k)!=v for k,v in card.items() if k!='candidates'):
                raise ValueError('pre-cap role presentation changed')
            refs=[{'candidate_id':r['id'],'proposal_id':r['proposal_id']} for r in card['candidates']]
            # Public projection canonicalizes unordered presentation references;
            # actual private search order remains bound in the retrieval record.
            canonical_refs=lambda rows:sorted((r['candidate_id'],r['proposal_id']) for r in rows)
            if canonical_refs(view['candidate_refs'])!=canonical_refs(refs): raise ValueError('pre-cap candidate references changed')
            evidence={r['id']:{key:r[key] for key in ('retrieval_relevance','retrieval_evidence')} for r in card['candidates']}
            if view.get('candidate_evidence')!=evidence: raise ValueError('pre-cap per-role evidence changed')
        bids={p['source_binding_id'] for p in expected['role_proposals'].values() if p['source_binding_id'] is not None}
        if pack['candidate_bindings']!={bid:data['slot_bindings'][bid] for bid in bids}: raise ValueError('pre-cap source binding changed')
        for cid,row in pack['candidate_pool'].items():
            if row['authored_record']!=data['candidates'][cid]: raise ValueError('pre-cap full source changed')
            if ranking.is_common(short['policy'].get('variant')):
                for proposal in expected['role_proposals'].values():
                    if proposal['candidate_id']!=cid:continue
                    rid=proposal['realization_id'];surface=row.get('realization_views',{}).get(rid,row)
                    if surface.get('discovery_meaning_view')!=common_meaning.lookup(data,cid,rid):raise ValueError('composer meaning view differs from bound source projection')
    except (KeyError,TypeError,ValueError,AttributeError) as exc:
        failures.append({'check':'precap_global_retrieval_contract','reason':str(exc)})
    return failures
