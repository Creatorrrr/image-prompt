"""Reuse only an installed local inference worker; no legacy candidate/search imports."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import subprocess

from photo_candidate_corpus import digest
from photo_recall_generation import read
from photo_recall_first import require
def vector(value,dimensions):
    import math
    require(isinstance(value,list) and len(value)==dimensions and all(math.isfinite(x) for x in value),'invalid local vector')


class LocalEncoder:
    def __init__(self, skill_root):
        self.root = Path(skill_root).resolve()
        self.lock = read(self.root / "embedding-runtime.lock.json")
        space = self.lock.get("space", {})
        require(space.get("provider") == "embeddinggemma2-local", "only the installed local embedding backend is supported")
        require(self.lock.get("schema") == "photo-local-embedding-installation/v1", "unknown local installation")
        self.worker = self.root / "scripts/photo_local_embedding.py"
        self.python = self.root / self.lock["python"]
        require(self.worker.is_file() and self.python.is_file(), "local inference runtime is missing")
        self.binding = {"space": space, "installation_hash": digest(self.lock),
                        "worker_sha256": hashlib.sha256(self.worker.read_bytes()).hexdigest(),
                        "adapter": "visual-idea-local/v1"}
        self.process = None

    def encode(self, texts, kind):
        require(kind in ("document", "query"), "invalid embedding kind")
        if not texts:
            return []
        require(all(isinstance(x, str) and x.strip() for x in texts), "empty embedding text")
        require(read(self.root / "embedding-runtime.lock.json") == self.lock, "local runtime changed")
        require(hashlib.sha256(self.worker.read_bytes()).hexdigest() == self.binding["worker_sha256"], "inference worker changed")
        if self.process is None:
            env = dict(os.environ, HF_HUB_OFFLINE="1", TRANSFORMERS_OFFLINE="1",
                       HF_HUB_DISABLE_TELEMETRY="1", TOKENIZERS_PARALLELISM="false")
            for key in ("GEMINI_API_KEY", "GOOGLE_API_KEY", "OPENAI_API_KEY", "ANTHROPIC_API_KEY"):
                env.pop(key, None)
            self.process = subprocess.Popen([str(self.python), str(self.worker), "--worker"],
                                            stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                            text=True, env=env)
        request = {"texts": texts, "kind": kind, "space": self.lock["space"]}
        self.process.stdin.write(json.dumps(request, ensure_ascii=False, allow_nan=False)+"\n")
        self.process.stdin.flush()
        line = self.process.stdout.readline()
        require(bool(line), "local worker exited without a response")
        response = json.loads(line)
        require(response.get("request_sha256") == digest(request), "inference response identity mismatch")
        require("error" not in response, f"local inference failed: {response.get('error')}")
        rows = response.get("rows", [])
        require(len(rows) == len(texts), "inference response count mismatch")
        prefix = {"query": "task: search result | query: ", "document": "title: none | text: "}[kind]
        for source, row in zip(texts, rows):
            vector(row["vector"], self.lock["space"]["dimensions"])
            proof = row["execution"]
            require(proof.get("provider_executed") is True and proof.get("kind") == kind, "missing execution proof")
            require(proof.get("space") == self.lock["space"], "inference space mismatch")
            require(proof.get("installation_sha256") == digest(self.lock), "inference installation mismatch")
            require(proof.get("input_sha256") == hashlib.sha256((prefix+source).encode()).hexdigest(), "inference input mismatch")
            require(proof.get("vector_sha256") == digest(row["vector"]), "inference vector mismatch")
        return rows

    def close(self):
        if self.process is not None:
            self.process.stdin.close()
            try:
                self.process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                self.process.terminate()
                self.process.wait(timeout=10)
            self.process.stdout.close()
            self.process = None

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()
