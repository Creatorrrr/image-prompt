"""Candidate-free, source-bound advisory role projections after core freeze.

Lexical cues select evidence; they do not certify its meaning. Exact source
spans preserve ownership, conditions and negation for review and replay.
"""
from __future__ import annotations

import hashlib
import re
import copy
import photo_candidate_corpus as corpus

RECIPE = 'photo-positive-slot-projection/v1'
SCHEMA = 'photo-positive-slot-projection/v1'
MAX_FACT_CHARS = 640
MAX_CONTEXT_CHARS = 180
MAX_FACTS = 4
_HASH = re.compile(r'[0-9a-f]{64}\Z')
_META = re.compile(r'(?:/(?:Users|home|tmp|private|Volumes)/|[A-Za-z]:\\|\b[0-9a-f]{64}\b|\b[^\s/]+\.(?:png|jpe?g|webp|heic|json)\b)', re.I)
_NEGATIVE_START = re.compile(r'^\s*(?:no\b|not\b|without\b|avoid\b|exclude\b|do not\b|never\b|금지|제외)', re.I)
_RELATION = re.compile(r'\b(?:not|no|without|unless|if|until|before|after|while|when|only|instead|but|except)\b|않|없|아닌|전에는|후에는|경우', re.I)
_INSTRUCTION_START = re.compile(r'^\s*(?:use|refer to|match|copy|follow)\s+(?:the\s+)?(?:supplied|attached|reference|provided)\b', re.I)
# General observable activity verbs, never candidate names or scene templates.
# Carrier nouns (e.g. "hand") alone are insufficient activity evidence.
_ACTIVITY_TERMS = ('hold', 'play', 'walk', 'work', 'perform', 'carry', 'lift', 'raise',
    'push', 'pull', 'place', 'put', 'offer', 'present', 'pass', 'receive', 'take',
    'grasp', 'touch', 'press', 'turn', 'open', 'close', 'cut', 'write', 'read',
    'pour', 'drink', 'eat', 'drive', 'ride', 'run', 'swim', 'fly', 'climb',
    'operate', 'repair', 'assemble', 'inspect', 'measure', 'draw', 'paint',
    'fold', 'unfold', 'serve', 'feed', 'throw', 'catch', 'point', 'reach',
    '들고', '잡고', '건네', '걷', '달리', '운전', '먹', '마시', '연주', '수리',
    '조립', '작동', '올리', '내리', '밀', '당기', '열', '닫', '읽', '붓')
_CAPTURE_TERMS = re.compile(r'\b(?:camera|viewpoint|frontal view|portrait|framing|silhouette|eye level|depth of field|perspective|lens)\b', re.I)
_POSE_PREDICATE = re.compile(r'\b(?:she|he|they|it)\s+(?:(?:is|are)\s+)?(?:kneel|sit|stand|lie|crouch|squat|recline)(?:s|ing|ed)?\b', re.I)


def _sha(text):
    return hashlib.sha256(text.encode()).hexdigest()


def _escape(value):
    return str(value).replace('~', '~0').replace('/', '~1')


def _strings(value, pointer):
    if isinstance(value, str):
        yield pointer, value
    elif isinstance(value, list):
        for i, row in enumerate(value):
            yield from _strings(row, pointer + '/' + str(i))
    elif isinstance(value, dict):
        for key in sorted(value):
            yield from _strings(value[key], pointer + '/' + _escape(key))


def _sources(core):
    """Only visual facts, never request/provenance/reasons/reference metadata."""
    result = {}
    for field in ('subject', 'setting', 'event', 'visual_priorities', 'baseline_prompt_en'):
        for pointer, text in _strings(core.get(field), '/' + field):
            result[pointer] = {'text': text, 'field': field, 'kind': 'core_field'}
    for pointer, text in _strings((core.get('style') or {}).get('evidence'), '/style/evidence'):
        result[pointer] = {'text': text, 'field': 'style', 'kind': 'core_field'}
    for i, assertion in enumerate(core.get('semantic_assertions') or []):
        if not isinstance(assertion, dict) or assertion.get('polarity') not in {'required', 'advisory'}:
            continue
        for pointer, text in _strings(assertion.get('evidence') or {}, f'/semantic_assertions/{i}/evidence'):
            axes = assertion.get('axes') or {}
            result[pointer] = {'text': text, 'field': 'semantic_assertions', 'kind': 'typed_witness',
                'dimension': assertion.get('dimension'), 'axes': axes,
                'assertion_id': assertion.get('assertion_id'), 'relations': assertion.get('relations') or []}
            for key, axis in (('owner', 'target'), ('property', 'property')):
                if isinstance(axes.get(axis), str) and axes[axis]:
                    result[pointer][key] = axes[axis]
    for i, anchor in enumerate((core.get('intent_lock') or {}).get('semantic_anchors') or []):
        if not isinstance(anchor, dict) or anchor.get('polarity') == 'excluded':
            continue
        pointer = f'/intent_lock/semantic_anchors/{i}/prompt_evidence'
        if isinstance(anchor.get('prompt_evidence'), str):
            result[pointer] = {'text': anchor['prompt_evidence'], 'field': 'intent_lock', 'kind': 'typed_anchor',
                'dimension': anchor.get('dimension'), 'property': anchor.get('property'),
                'owner': anchor.get('target'), 'anchor_id': anchor.get('anchor_id')}
    return result


def _clauses(text):
    # Sentence punctuation is a boundary; decimal points and ordinary
    # abbreviations are retained. A conditional/negated sentence stays whole.
    for match in re.finditer(r'[^\n]+(?:\n|$)', text):
        line, offset = match.group().rstrip('\n'), match.start()
        start = 0
        boundaries = [m.end() for m in re.finditer(r'[.!?](?=\s+[A-Z가-힣]|$)', line)] + [len(line)]
        for end in dict.fromkeys(boundaries):
            sentence = line[start:end]
            parts = [(start, end)]
            if not _RELATION.search(sentence):
                parts = [(start + m.start(), start + m.end()) for m in re.finditer(r'[^;]+', sentence)]
            for left, right in parts:
                while left < right and line[left].isspace(): left += 1
                while right > left and line[right - 1].isspace(): right -= 1
                if right > left:
                    yield offset + left, offset + right, line[left:right]
            start = end


def _has(text, term):
    term = str(term).strip()
    if not term:
        return False
    if term.isascii():
        # Small inflection tolerance; no candidate vocabulary is consulted.
        pattern = re.escape(term)
        if term.endswith('ing') and len(term) > 5:
            pattern = re.escape(term[:-3]) + r'(?:e|s|es|ed|ing)?'
        elif term.endswith('ed') and len(term) > 4:
            pattern = re.escape(term[:-2]) + r'(?:e|s|es|ed|ing)?'
        elif term.endswith('e') and len(term) > 3:
            pattern = re.escape(term[:-1]) + r'(?:e|es|ed|ing)'
        else:
            pattern += r'(?:s|ed|ing)?'
        return bool(re.search(r'(?<![A-Za-z0-9])' + pattern + r'(?![A-Za-z0-9])', text, re.I))
    return term.casefold() in text.casefold()


def _positive(text, core):
    if not text.strip() or _META.search(text) or _NEGATIVE_START.search(text) or _INSTRUCTION_START.search(text):
        return False
    # Do not promote an excluded term from a contradictory positive clause.
    return not any(_has(text, excluded) and not _RELATION.search(text)
                   for excluded in core.get('user_exclusions') or [])


def _span(pointer, source, start, end):
    result = {'source_pointer': pointer, 'start': start, 'end': end,
              'quote': source['text'][start:end], 'source_sha256': _sha(source['text'])}
    # These are frozen-source annotations, never newly inferred owners.
    for key in ('kind', 'dimension', 'property', 'owner', 'axes', 'relations', 'assertion_id', 'anchor_id'):
        if key in source:
            result[key] = copy.deepcopy(source[key])
    return result


def role_head(spec, language):
    text = spec['description_ko' if language == 'ko' else 'description']
    # Catalog boundaries/includes are audit material, not positive search words.
    text = re.split(r'[:;]|\b(?:distinct from|separate from|without inferring|Preserve|Do not)\b', text, maxsplit=1)[0]
    text = re.split(r'(?<=[.!?])\s+', text, maxsplit=1)[0].strip(' ,;:.')
    return text if text else spec['id'].replace('_', ' ')


def _property_match(prop, prefixes):
    return isinstance(prop, str) and any(prop.startswith(prefix) for prefix in prefixes)


def _score(slot, spec, source, text):
    cues = sum(_has(text, term) for term in spec.get('evidence_terms') or [])
    prop = source.get('property')
    if prop and _property_match(prop, spec['property_prefixes']):
        return 20 + cues
    # A typed property belonging elsewhere is not promoted by a broad dimension.
    if prop:
        return 0
    dim = source.get('dimension')
    if source['kind'] == 'typed_witness' and dim in spec['dimensions'] and cues:
        return 12 + cues
    if slot == 'subject' and (source['field'] == 'subject' or dim == 'subject'):
        return 10 + cues
    if slot == 'location' and (source['field'] == 'setting' or dim == 'setting'):
        return 10 + cues
    # Dedicated frozen owner/place fields are safer than matching e.g. a
    # person depicted on a sleeve, or the window serving as a light source.
    if slot in {'subject', 'location'}:
        return 0
    if source['field'] not in set(spec['core_fields']) | {'baseline_prompt_en', 'semantic_assertions', 'intent_lock'}:
        return 0
    if slot == 'action':
        # Abstract holding (a pose, gaze or opinion) cannot establish an
        # object-directed activity, even when a hand is mentioned elsewhere.
        activity_text = re.sub(r'\b(?:the|a|an|my|your|his|her|its|their|our)\s+(?:\w+ly\s+)?\w+(?:ed|en)\b', ' ', text, flags=re.I)
        activities = [term for term in _ACTIVITY_TERMS if _has(activity_text, term)]
        if activities == ['hold'] and re.search(r'\b(?:posture|pose|stance|gaze|attention|expression|opinion)\b', text, re.I):
            return 0
        if not activities:
            return 0
        return max(cues, len(activities))
    if slot == 'body_pose' and _CAPTURE_TERMS.search(text) and not _POSE_PREDICATE.search(text):
        return 0
    return cues


def _binding(core, slot, facts, contexts, mode):
    value = {'schema': SCHEMA, 'recipe': RECIPE, 'slot_id': slot,
             'core_sha256': core['canonical_sha256'], 'mode': mode,
             'status': 'partial' if facts else 'role_only_unknown',
             'role_facts': facts, 'scene_context': contexts,
             'semantic_approval': False}
    value['canonical_sha256'] = corpus.digest(value)
    return value


def validate(value, core, slot):
    """Validate authored or generated spans without accepting foreign metadata."""
    fields = {'schema', 'recipe', 'slot_id', 'core_sha256', 'mode', 'status',
              'role_facts', 'scene_context', 'semantic_approval', 'canonical_sha256'}
    if (not isinstance(value, dict) or set(value) != fields or value['schema'] != SCHEMA
            or value['recipe'] != RECIPE or value['slot_id'] != slot
            or value['core_sha256'] != core.get('canonical_sha256')
            or value['mode'] not in {'deterministic', 'authored_post_freeze'}
            or value['semantic_approval'] is not False
            or value['canonical_sha256'] != corpus.digest({k: v for k, v in value.items() if k != 'canonical_sha256'})):
        raise ValueError('foreign or modified slot projection')
    sources = _sources(core)
    for field, max_rows, max_chars in (('role_facts', MAX_FACTS, MAX_FACT_CHARS), ('scene_context', 1, MAX_CONTEXT_CHARS)):
        spans = value[field]
        if not isinstance(spans, list) or len(spans) > max_rows:
            raise ValueError('invalid projection span collection')
        size = 0
        for span in spans:
            if not isinstance(span, dict):
                raise ValueError('invalid projection span')
            pointer, start, end = span.get('source_pointer'), span.get('start'), span.get('end')
            source = sources.get(pointer)
            if (source is None or type(start) is not int or type(end) is not int
                    or not 0 <= start < end <= len(source['text'])
                    or span != _span(pointer, source, start, end)
                    or not _positive(span.get('quote', ''), core)):
                raise ValueError('unbound or nonpositive projection span')
            # Quoting only a positive word from a negated/conditional clause
            # would lose its scope. Require complete safe clauses or an entire
            # authored typed witness; exact offsets alone are insufficient.
            safe = {(left, right) for left, right, _ in _clauses(source['text'])}
            safe.add((0, len(source['text'])))
            if (start, end) not in safe:
                raise ValueError('projection must preserve a complete source clause')
            size += len(span['quote'])
        if size > max_chars:
            raise ValueError('projection exceeds role/context budget')
    expected_status = 'partial' if value['role_facts'] else 'role_only_unknown'
    if value['status'] != expected_status:
        raise ValueError('projection cannot claim semantic approval')
    return value


def authored(core, slot, role_facts, scene_context=()):
    """Build an optional reviewed projection from exact source spans.

Callers can construct each span with ``source_span``. Review is advisory and
does not alter frozen core or create native candidate authority.
"""
    value = _binding(core, slot, list(role_facts), list(scene_context), 'authored_post_freeze')
    return validate(value, core, slot)


def source_span(core, pointer, start=0, end=None):
    source = _sources(core).get(pointer)
    if source is None:
        raise ValueError('projection source is not a visual core field')
    end = len(source['text']) if end is None else end
    if type(start) is not int or type(end) is not int or not 0 <= start < end <= len(source['text']):
        raise ValueError('invalid source span offsets')
    return _span(pointer, source, start, end)


def project(core, catalog, slot, *, override=None):
    if slot not in catalog:
        raise ValueError('unknown managed slot: ' + slot)
    if not _HASH.fullmatch(str(core.get('canonical_sha256') or '')):
        raise ValueError('slot projection requires frozen core')
    if override is not None:
        return validate(override, core, slot)
    spec, sources = catalog[slot], _sources(core)
    ranked = []
    for pointer, source in sources.items():
        for start, end, text in _clauses(source['text']):
            if len(text) > MAX_FACT_CHARS or not _positive(text, core):
                continue
            score = _score(slot, spec, source, text)
            if score:
                ranked.append((-score, pointer, start, end, text))
    facts, seen, size = [], set(), 0
    for _, pointer, start, end, text in sorted(ranked):
        normalized = re.sub(r'\s+', ' ', text).casefold().rstrip('.;')
        if normalized in seen or size + len(text) > MAX_FACT_CHARS:
            continue
        facts.append(_span(pointer, sources[pointer], start, end)); seen.add(normalized); size += len(text)
        if len(facts) == MAX_FACTS:
            break
    contexts = []
    # An exact typed primary owner is preferable to a broad subject description.
    owners = sorted((pointer, source) for pointer, source in sources.items()
                    if (pointer.endswith('/subject_phrase') and source.get('dimension') == 'subject'))
    owners += [(pointer, source) for pointer, source in sources.items() if pointer == '/subject']
    fact_owners = {span.get('owner') for span in facts if span.get('owner')}
    if fact_owners - {'main_subject'}:
        owners = []
    for pointer, source in owners:
        text = source['text']
        if 0 < len(text) <= MAX_CONTEXT_CHARS and _positive(text, core):
            if text.casefold().rstrip('.') not in seen:
                contexts = [_span(pointer, source, 0, len(text))]
            break
    return validate(_binding(core, slot, facts, contexts, 'deterministic'), core, slot)


def texts(projection, spec, language='en'):
    if language not in {'en', 'ko'}:
        raise ValueError('unsupported slot query language')
    facts = '; '.join(span['quote'] for span in projection['role_facts'])
    focus = role_head(spec, language) + (': ' + facts if facts else '')
    context = '; '.join(span['quote'] for span in projection['scene_context'])
    return focus, context
