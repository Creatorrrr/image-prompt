import copy
import unittest
import photo_recall_first as rf


class RecallContracts(unittest.TestCase):
    def test_zero_lexical_has_no_rrf_credit(self):
        rows=rf.fuse([{'id':'a','cid':'a','rid':'base'}],[0.],[.5])
        self.assertEqual(rows[0]['rrf'],1/11)

    def test_rid_lanes_never_mix_and_return_unique_cids(self):
        docs=[{'id':cid+'|'+rid,'cid':cid,'rid':rid} for cid,rid in [('a','x'),('a','y'),('b','base')]]
        rows=rf.fuse(docs,[10.,0.,5.],[0.,1.,.5])
        self.assertEqual([r['cid'] for r in rows],['a','b'])
        self.assertTrue(all(r['rrf']<2/11 for r in rows))

    def test_ties_and_duplicate_identity(self):
        docs=[{'id':v,'cid':v,'rid':'base'} for v in ['b','a']]
        self.assertEqual(rf.fuse(docs,[1.,1.],[1.,1.])[0]['cid'],'a')
        with self.assertRaises(ValueError):rf.fuse(docs*2,[0.]*4,[1.]*4)

    def test_nonfinite_scores_and_empty_query(self):
        with self.assertRaises(ValueError):rf.fuse([{'id':'a'}],[float('nan')],[0.])
        with self.assertRaises(ValueError):rf.lexical_scores(rf.lexical_index(['abc']),' ')
        with self.assertRaises(ValueError):rf.cosine([0.],[1.])

    def test_query_words_not_reweighted(self):
        index=rf.lexical_index(['tea tea cup','cup','blue'])
        self.assertEqual(rf.lexical_scores(index,'tea'),rf.lexical_scores(index,'tea tea tea'))
        self.assertEqual(rf.tokens('A_B 한글; TEA'),['a','b','한글','tea'])

    def test_stale_kind_prefix_model_and_vector(self):
        binding={'space':{'provider':'embeddinggemma2-local','dimensions':1},'installation_hash':'i'}
        row={'vector':[1.],'execution':{'provider_executed':True,'kind':'query','space':binding['space'],
             'installation_sha256':'i','input_sha256':rf.sha('task: search result | query: S'),
             'vector_sha256':rf.corpus.digest([1.])}}
        rf.check_embedding(row,binding,'S','query')
        for text,kind in [('changed','query'),('S','document')]:
            with self.assertRaises(ValueError):rf.check_embedding(row,binding,text,kind)
        for patch in [{'installation_hash':'j'},{'space':{'provider':'remote','dimensions':1}}]:
            with self.assertRaises(ValueError):rf.check_embedding(row,{**binding,**patch},'S','query')
        bad=copy.deepcopy(row);bad['vector'][0]=.5
        with self.assertRaises(ValueError):rf.check_embedding(bad,binding,'S','query')


if __name__=='__main__':unittest.main()
