"""Bounded advisory source relevance, independent of native adoption authority.

This deterministic policy observes positive language, explicit carriers and
actual lane evidence. It neither certifies source meaning nor edits records.
"""
from __future__ import annotations
import photo_canonical_source as canonical

import copy
import hashlib
import math
import re
import photo_candidate_corpus as c
import photo_candidate_realizations as realizations
import photo_semantic_evidence as semantic
import photo_slot_projection as projection

RECIPE = 'photo-source-retrieval-relevance/v2'
SCHEMA = 'photo-retrieval-relevance/v1'
POLICY = {'recipe': RECIPE, 'maximum_source_units': 256, 'maximum_source_characters': 131072,
          'maximum_quote_count': 3, 'maximum_quote_characters': 6000,
          'minimum_cosine_corrobation': .30, 'minimum_fact_overlap': 1,
          'minimum_keyword_fact_overlap': 2, 'semantic_approval': False,
          'role_rules': 'observable-role-predicates/v1', 'owner_rules': 'explicit-carrier-conflicts/v1',
          'native_role_bridge': 'independent-qualified-source-facts/v1',
          'dedupe_recipe': 'complete-meaning-conditions-owner-contract/v1',
          'authored_goal_evidence': 'exact-authored-focus-and-explicit-source-effect/v1',
          'whole_source_approval': 'separate-direct-Codex-review'}
POLICY_SHA256 = c.digest(POLICY)
_CID = re.compile(r'\bcand_[0-9a-f]{8,}\b', re.I)
_WORDS = re.compile(r'[a-z0-9]+(?:[-\'][a-z0-9]+)*|[가-힣]{2,}|[一-龥ぁ-ゖァ-ヺ]{2,}', re.I)
_GRAMMAR = frozenset('a an the and or but of to in on at for with from by as is are was were be been being has have had its it her his their our your my she he they them this that those these same one two three will can remains remain photographic photograph photo image visible selected declared actual subject source role surface'.split())
_NEGATION = re.compile(r'\b(?:not|without|unless|except|neither|nor)\b|않|없|아닌|제외', re.I)
_CONDITIONAL = re.compile(r'\b(?:if|unless|until|before|after|when)\b|경우|전에는|후에는', re.I)
_PLACE = re.compile(r'\b(?:room|interior|exterior|street|chapel|church|cathedral|temple|hall|corridor|kitchen|workshop|studio|courtyard|courtyard|landscape|forest|beach|riverbank|mountain|valley|building|architecture|vault|apse|archway|doorway|alcove|aisle|ceiling|wall|floor|staircase|garden|balcony|rooftop)\b|장소|공간|실내|실외|거리|골목|예배당|성당|교회|복도|부엌|작업실|숲|해변|산맥|천장|벽면|바닥|教会|礼拝堂|室内|建築', re.I)
_STRUCTURE = re.compile(r'\b(?:interior|exterior|architecture|vault|apse|archway|doorway|alcove|aisle|ceiling|wall|floor|staircase|ribbed|rib|arched|spatial|structure|space|room|corridor|hall)\b|공간|구조|실내|천장|벽면|바닥|아치|볼트|건축|建築|構造', re.I)
_ILLUMINATION = re.compile(r'\b(?:light|lighting|illumination|illuminated|lit|sunlight|daylight|windowlight|backlight|headlight|flash|lamplight)\b|조명|빛|광원|광질|ライティング|照明|光源', re.I)
_LIGHT_RELATION = re.compile(r'\b(?:from|onto|across|falls on|falling on|on a|on an|on the|left|right|overhead|side|front|behind|backlit|raking|direction|receiv|window|lamp|flash|sun|sunlight|daylight)\b|왼쪽|오른쪽|위에서|옆에서|비추|가로질러|창빛|광원|방향|窓|照ら', re.I)
_POSE = re.compile(r'\b(?:kneel(?:s|ing|ed)?|seated|sitting|sits|standing|stands|lying|lies|crouch(?:ed|ing|es)?|squat(?:ting|s)?|reclin(?:e|ed|ing)|perch(?:ed|ing)|bent elbow|elbow flexion|bent knee|joint flexion)\b|무릎을 꿇|꿇은|앉아|앉은|서 있는|누워|누운|팔꿈치.*굽|膝立ち|座る|座った|跪', re.I)
_LAYOUT = re.compile(r'\b(?:composition|negative space|rule of thirds|off-center|centred|centered|triangular|diagonal arrangement|leading lines|foreground|midground|background layer|frame left|frame right|left of|right of|between|overlap|placement|spatial arrangement|visual hierarchy)\b|구도|여백|삼분할|전경|중경|배치|시각적 위계|構図|余白', re.I)
_TEXTURE = re.compile(r'\b(?:texture|weave|woven|stitch(?:es|ing)?|rough|roughness|smooth|brushed|groove|grooves|pores|fibers|fibres|fabric grain|wood grain|surface grain|tactile|creases|cracked|pitted)\b|질감|직조|짜임|바느질|거칠|매끈|피부결|나뭇결|表面質感|織り|木目', re.I)
_GRAIN = re.compile(r'\b(?:film grain|digital noise|image grain|grain profile|chroma noise|luminance noise)\b|필름 입자|입자감|디지털 노이즈|フィルム粒子', re.I)
_PARTS = {
    'eyes': r'\b(?:eyes?|iris|irises|pupils?|eyelids?)\b|눈동자|안구|홍채',
    'face': r'\b(?:face|facial|cheeks?|forehead|jaw|nose)\b|얼굴|볼의|이마|턱',
    'hair': r'\b(?:hair|braid|fringe|bangs|bob)\b|머리카락|머리색',
    'lips': r'\b(?:lips?|vermilion)\b|입술',
    'garment': r'\b(?:sleeves?|cuffs?|garment|clothing|dress|shirt|skirt|coat|wardrobe|cloth|linen)\b|소매|의복|옷|천|리넨',
    'hands': r'\b(?:hands?|fingers?|palms?|thumbs?)\b|손가락|손바닥|양손',
    'skin': r'\b(?:skin|complexion)\b|피부',
}
_REPRESENTED = re.compile(r'\b(?:printed|depicted|embroidered|poster|painting|painted (?:face|person|figure)|photograph of a photograph)\b|인쇄된|묘사된|자수|포스터|그려진', re.I)
_BACKGROUND_OWNER = re.compile(r'\b(?:background person|background figure|secondary person|bystander)\b|배경 인물|주변 인물', re.I)


def _sha(text):
    return hashlib.sha256(text.encode()).hexdigest()


def _normalize(text):
    return ' '.join(text.split()).casefold()


def _tokens(text):
    values = set()
    for word in _WORDS.findall(text):
        word = word.casefold()
        if word in _GRAMMAR or len(word) < 2:
            continue
        if word in {'seated', 'sitting', 'sits'}: word = 'sit'
        elif word in {'lying', 'lies'}: word = 'lie'
        elif len(word) > 5 and word.endswith('ing'): word = word[:-3]
        elif len(word) > 5 and word.endswith('ed'): word = word[:-2]
        elif len(word) > 4 and word.endswith('s'): word = word[:-1]
        values.add(word)
    return values


def _units(record, rid, *, bounded=True):
    # Complete primary strings retain their original field ownership. Aliases,
    # tags, conditions and review/routing text are excluded by this contract.
    paths = sorted(semantic.primary_paths(record, rid))
    result, size, omitted = [], 0, 0
    for pointer in paths:
        text = semantic.positive_string(record, pointer, realization_id=rid)
        if not text.strip() or _CID.search(text) or projection._META.search(text):
            continue
        if bounded and (len(result) >= POLICY['maximum_source_units'] or size + len(text) > POLICY['maximum_source_characters']):
            omitted += 1
            continue
        result.append({'pointer': pointer, 'quote': text, 'source_sha256': _sha(text)})
        size += len(text)
    return result, omitted


def _actual_effects(record, rid):
    return realizations.effects(record, rid)


def _relations(record, rid):
    selected = (canonical.native(record).get('realization_content') or {}).get(rid) or canonical.native(record)
    return copy.deepcopy(selected.get('relations') or [])


def duplicate_key(record, rid='base'):
    """Exact source-meaning grouping only; identities are never merged.

    Referenced dependency identities remain significant semantic referents;
    the declaring record ID and provenance are not part of this key.
    """
    # Unlike display/relevance evidence, an exact equivalence key must retain
    # every whole positive string, even a poor CID-containing source label.
    # Omitting that string could collapse distinct unreviewed meanings.
    meanings = [semantic.positive_string(record, path, realization_id=rid)
                for path in sorted(semantic.primary_paths(record, rid))]
    branch = realizations.branch(record, rid)
    branch_material = {k: v for k, v in (branch or {}).items() if k != 'id'}
    proof = semantic.proof_of(record)
    dependencies = (proof.get('dependencies') or {}).get(rid) if isinstance(proof, dict) else None
    material = {'positive_meaning': sorted(set(meanings)),
                'relations': _relations(record, rid), 'conditions': record['conditions'],
                'effects': _actual_effects(record, rid), 'branch': branch_material,
                'member_candidates': canonical.native(record).get('member_candidates') or [],
                'dependencies': dependencies,
                # Native owner/guard/permission requirements can differ even
                # when a display phrase and scalar effects are identical.
                'native_owner_contract': {key: copy.deepcopy(proof.get(key)) for key in
                    ('owner_maps','guard_sets','guard_supports','permission_envelopes','manual_role_views')} if isinstance(proof,dict) else None,
                'owner_requirements': record.get('owner_selection_requirements') or canonical.native(record).get('owner_selection_requirements')}
    return c.digest(material)


def summary(record, rid='base'):
    """Small complete-source summary, never CID fragments or cropped facts."""
    units, omitted = _units(record, rid)
    def priority(unit):
        pointer = unit['pointer']
        return (0 if pointer.endswith('/definition') else 1 if pointer.endswith(('/en', '/phrase_en', '/ko', '/phrase_ko')) else 2, pointer)
    result, seen, size = [], set(), 0
    for unit in sorted(units, key=priority):
        text = unit['quote']; normalized = _normalize(text)
        if normalized in seen:
            continue
        if len(result) == 3 or size + len(text) > 1800:
            omitted += 1
            continue
        result.append(text); seen.add(normalized); size += len(text)
    return {'concept_units': result, 'relations': _relations(record, rid), 'omitted_unit_count': omitted}


def _activities(text):
    text = re.sub(r'\b(?:the|a|an|my|your|his|her|its|their|our)\s+(?:\w+ly\s+)?\w+(?:ed|en)\b', ' ', text, flags=re.I)
    terms = [term for term in projection._ACTIVITY_TERMS if projection._has(text, term)]
    if terms == ['hold'] and re.search(r'\b(?:posture|pose|stance|gaze|attention|expression|opinion)\b', text, re.I):
        return []
    return terms


def _role_cues(slot, spec, text):
    cues = sorted({term for term in spec.get('evidence_terms') or [] if projection._has(text, term)})
    if projection._NEGATIVE_START.search(text):
        return [], False
    if slot == 'location':
        supported = bool(_PLACE.search(text)) and (not _POSE.search(text) or bool(_STRUCTURE.search(text)))
    elif slot == 'lighting':
        supported = bool(_ILLUMINATION.search(text) and _LIGHT_RELATION.search(text))
    elif slot == 'action':
        activities = _activities(text)
        return sorted(set(cues) | set(activities)), bool(activities)
    elif slot == 'body_pose':
        supported = bool(_POSE.search(text)) and (not projection._CAPTURE_TERMS.search(text) or bool(projection._POSE_PREDICATE.search(text)))
    elif slot == 'composition':
        supported = bool(_LAYOUT.search(text))
    elif slot == 'texture':
        supported = bool(_TEXTURE.search(text)) and not (bool(_GRAIN.search(text)) and not re.search(r'\b(?:skin|fabric|wood|material|surface|weave|pores)\b|피부|직물|표면|나무', text, re.I))
    elif slot == 'grain_profile':
        supported = bool(_GRAIN.search(text))
    else:
        # Other roles remain conservative: one generic noun alone is not a
        # declaration, but multiple independent catalog observations can help.
        supported = len(cues) >= 2
    if supported and not cues:
        cues = ['observable_' + slot]
    return cues, supported


def _other_roles(text, requested):
    checks = {'body_pose': bool(_POSE.search(text)), 'location': bool(_PLACE.search(text) and _STRUCTURE.search(text)),
              'lighting': bool(_ILLUMINATION.search(text) and _LIGHT_RELATION.search(text)),
              'grain_profile': bool(_GRAIN.search(text)), 'texture': bool(_TEXTURE.search(text))}
    return sorted(role for role, yes in checks.items() if yes and role != requested)


def _owner_class(value):
    if not isinstance(value, str) or not value:
        return None
    lowered = value.casefold()
    if any(term in lowered for term in ('printed', 'depicted', 'represented', 'poster')):
        return 'represented'
    if any(term in lowered for term in ('background', 'secondary', 'bystander')):
        return 'background'
    if lowered in {'main_subject', 'primary_subject', 'principal_subject'}:
        return 'main_subject'
    if lowered in {'scene', 'environment', 'entity', 'light', 'camera', 'image', 'surface', 'body'}:
        return None
    return lowered


def _owner_evidence(slot, spec, facts, texts, properties):
    expected = sorted({_owner_class(fact.get('owner')) for fact in facts} - {None})
    actual = sorted({_owner_class(prop.get('target')) for prop in properties} - {None})
    query_text = ' '.join(fact['quote'] for fact in facts)
    source_text = ' '.join(texts)
    if _REPRESENTED.search(query_text): expected = sorted(set(expected) | {'represented'})
    if _BACKGROUND_OWNER.search(query_text): expected = sorted(set(expected) | {'background'})
    source_special = []
    if _REPRESENTED.search(source_text): source_special.append('represented')
    if _BACKGROUND_OWNER.search(source_text): source_special.append('background')
    actual = sorted(set(actual) | set(source_special))
    conflict = bool(expected and actual and set(expected).isdisjoint(actual))
    query_parts = sorted(part for part, pattern in _PARTS.items() if re.search(pattern, query_text, re.I))
    source_parts = sorted(part for part, pattern in _PARTS.items() if re.search(pattern, source_text, re.I))
    # Part disjointness is meaningful for local appearance/material properties,
    # not for place, framing or a light's relation to several receiving planes.
    local = slot in {'color', 'texture', 'eye_detail', 'hair_color', 'hair_style', 'skin_tone',
                     'skin_finish', 'facial_geometry', 'garment_detail', 'lip_finish', 'lip_color_placement'}
    compatible = bool(set(query_parts) & set(source_parts)) or (bool(set(query_parts) & {'face', 'eyes', 'lips'}) and bool(set(source_parts) & {'face', 'eyes', 'lips'}))
    part_conflict = bool(local and query_parts and source_parts and not compatible)
    return {'query_owners': expected, 'source_owners': actual, 'query_parts': query_parts,
            'source_parts': source_parts, 'explicit_conflict': conflict or part_conflict,
            'unresolved_special_owner': bool(source_special and not expected)}


def _numeric(cid, lexical_hit, cosine_hit, query_binding, facts, source_text):
    def score(hit, lane):
        if hit is None:
            return None
        if not isinstance(hit, dict) or hit.get('document_id') != cid or type(hit.get('score')) not in {int, float} or not math.isfinite(hit['score']):
            raise ValueError('finite same-candidate ' + lane + ' evidence required')
        if lane == 'cosine' and not -1.000000001 <= hit['score'] <= 1.000000001:
            raise ValueError('invalid cosine evidence')
        if lane == 'lexical' and hit['score'] < 0:
            raise ValueError('invalid lexical evidence')
        return float(hit['score'])
    lexical_score, cosine_score = score(lexical_hit, 'lexical'), score(cosine_hit, 'cosine')
    matched = (lexical_hit or {}).get('matched_terms') or []
    if not isinstance(matched, list) or any(not isinstance(term, str) for term in matched):
        raise ValueError('invalid lexical term evidence')
    query_text = ' '.join(fact['quote'] for fact in facts)
    overlap = sorted(_tokens(query_text) & _tokens(source_text))
    return {'bm25f_score': lexical_score, 'cosine': cosine_score,
            'cosine_state': 'observed' if cosine_score is not None else 'not_observed',
            'matched_terms': sorted(set(matched)), 'fact_source_overlap': overlap,
            'query_fields_sha256': c.digest(query_binding.get('query_fields') or {})}


def _native_role_bridge(data, spec, record, rid):
    """Reuse independently verified role facts without minting adoption rights.

    A proposal's own qualification flag is never authority. The source reader
    and semantic qualification contract independently verify complete source,
    current role specification, selected realization and optional manual view.
    """
    qualified_source = record
    reader = data.get('_search_reader')
    if reader is not None:
        # Generation transport authority belongs to its verified compact guard.
        # Bind the complete positive payload to that same immutable source hash;
        # public pack text and proposal flags cannot stand in for this reader.
        if c.digest(record) != reader.meta['record_sha256'].get(record['id']):
            raise ValueError('native relevance payload differs from pinned generation')
        qualified_source = reader.meta['guards'][record['id']]
    qualification = semantic.qualification(spec, qualified_source, rid, source_data=data)
    result = {'recipe': POLICY['native_role_bridge'], 'verified': False,
              'qualification': qualification, 'fact_refs': [], 'source_quotes': []}
    refs = qualification.get('fact_refs') or []
    if (qualification.get('status') != 'eligible' or qualification.get('native_qualification') != 'qualified'
            or not refs or len(refs) > POLICY['maximum_source_units']):
        return result
    proof = semantic.proof_of(record)
    if not isinstance(proof, dict):
        return result
    selected = [fact for fact in proof.get('facts') or []
                if fact.get('id') in refs and fact.get('realization_id') == rid]
    if len(selected) != len(refs) or {fact['id'] for fact in selected} != set(refs):
        return result
    quotes, seen = [], set()
    for fact in selected:
        try:
            text = semantic.positive_string(record, fact['pointer'], realization_id=rid)
        except (KeyError, ValueError, TypeError):
            return result
        if not isinstance(fact.get('quote'), str) or fact['quote'] not in text:
            return result
        if fact['pointer'] not in seen:
            quotes.append({'pointer': fact['pointer'], 'quote': text, 'source_sha256': _sha(text)})
            seen.add(fact['pointer'])
    result.update(verified=True, fact_refs=list(refs), source_quotes=quotes)
    return result


def assess(data, slot, proposal, query_binding, lexical_hit=None, cosine_hit=None):
    """Assess one already intrinsically eligible proposal, without adopting it."""
    if slot not in data['slot_catalog'] or proposal.get('target_slot_id') != slot or query_binding.get('slot_id') != slot:
        raise ValueError('same-slot proposal and query binding required')
    cid, rid = proposal['candidate_id'], proposal['realization_id']
    record = data['candidates'][cid]
    if record.get('id') != cid:
        raise ValueError('candidate source identity changed')
    record_hash = c.digest(record)
    if proposal.get('source_record_sha256') not in (None, record_hash):
        raise ValueError('candidate source differs from proposal')
    spec = data['slot_catalog'][slot]
    native_bridge = _native_role_bridge(data, spec, record, rid)
    units, omitted = _units(record, rid)
    effects = _actual_effects(record, rid)
    properties = effects.get('properties') or []
    relevant_properties = [prop for prop in properties if projection._property_match(prop.get('property'), spec['property_prefixes'])]
    other_properties = [prop for prop in properties if prop not in relevant_properties]
    frozen_projection = query_binding.get('projection') or {}
    facts = frozen_projection.get('role_facts') or []
    authored = query_binding.get('slot_expression')
    if authored is not None:
        # Authored query semantics are the retrieval input, not a failed lexical
        # extraction of baseline prose. This remains advisory lane evidence.
        facts = [{'quote': authored['role_focus']}] if authored.get('status') == 'search' else []
    if not isinstance(facts, list) or any(not isinstance(row, dict) or not isinstance(row.get('quote'), str) for row in facts):
        raise ValueError('source-bound role facts required')
    annotated, supported_units, other_roles = [], [], set()
    for unit in units:
        cues, supported = _role_cues(slot, spec, unit['quote'])
        other_roles.update(_other_roles(unit['quote'], slot))
        if supported:
            supported_units.append(unit)
            annotated.append({'pointer': unit['pointer'], 'cues': cues})
    effect_advisory = False
    if authored is not None and not supported_units:
        # An authored expression need not contain a catalog cue. A source's
        # own declared role effect plus actual positive correspondence can
        # support discovery, never native qualification or whole-source fit.
        explicit_effect = bool(relevant_properties) or bool(set(effects.get('dimensions') or []) & set(spec['dimensions']))
        focus_tokens = _tokens(authored['role_focus'])
        if explicit_effect:
            for unit in units:
                if len(focus_tokens & _tokens(unit['quote'])) >= POLICY['minimum_keyword_fact_overlap']:
                    supported_units.append(unit)
                    annotated.append({'pointer': unit['pointer'], 'cues': ['explicit_source_effect_advisory']})
                    effect_advisory = True
    if native_bridge['verified']:
        present = {unit['pointer'] for unit in supported_units}
        for unit in native_bridge['source_quotes']:
            if unit['pointer'] not in present:
                supported_units.append(unit); present.add(unit['pointer'])
                annotated.append({'pointer': unit['pointer'], 'cues': ['independently_qualified_role_fact']})
    source_text = ' '.join(unit['quote'] for unit in supported_units)
    numeric = _numeric(cid, lexical_hit, cosine_hit, query_binding, facts, source_text)
    owners = _owner_evidence(slot, spec, facts, [unit['quote'] for unit in supported_units or units], relevant_properties)
    reasons, status = [], 'uncertain'
    if owners['explicit_conflict']:
        status, reasons = 'unsupported', ['explicit_owner_or_carrier_conflict']
    elif native_bridge['qualification'].get('status') == 'incompatible':
        status, reasons = 'unsupported', ['independent_qualified_source_does_not_support_role']
    elif owners['unresolved_special_owner']:
        reasons = ['represented_or_background_owner_correspondence_unknown']
    elif not supported_units:
        if other_roles:
            status, reasons = 'unsupported', ['positive_source_supports_other_role', 'requested_role_not_observed']
        else:
            reasons = ['requested_role_not_observed']
    elif not facts and not native_bridge['verified']:
        reasons = ['frozen_role_facts_unknown']
    elif _NEGATION.search(source_text) or (_CONDITIONAL.search(source_text) and not native_bridge['verified']):
        reasons = ['negation_or_exception_scope_requires_review']
    elif native_bridge['verified'] and ((numeric['bm25f_score'] is not None and numeric['bm25f_score'] > 0)
            or numeric['cosine'] is not None):
        status, reasons = 'supported', ['independently_qualified_positive_role_facts', 'observed_search_lane']
    elif not facts:
        reasons = ['frozen_role_facts_unknown']
    elif not numeric['fact_source_overlap'] or (slot == 'lighting' and not (set(numeric['fact_source_overlap']) - {'light', 'lit', 'illumination', 'illuminat', 'glow'})):
        reasons = ['source_role_present_but_frozen_fact_correspondence_unknown']
    elif numeric['cosine'] is not None and numeric['cosine'] >= POLICY['minimum_cosine_corrobation']:
        status, reasons = 'supported', ['positive_role_source_and_frozen_fact_overlap', 'local_cosine_corroborates']
    elif numeric['bm25f_score'] is not None and numeric['bm25f_score'] > 0 and len(numeric['fact_source_overlap']) >= POLICY['minimum_keyword_fact_overlap']:
        status, reasons = 'supported', ['positive_role_source_and_frozen_fact_overlap', 'lexical_source_corroborates']
    else:
        reasons = ['insufficient_lane_corroboration']
    if omitted:
        status = 'uncertain'; reasons.append('positive_source_scan_budget_exhausted')
    quotes, quote_chars = [], 0
    for unit in supported_units or units:
        if len(quotes) >= POLICY['maximum_quote_count']:
            break
        if quote_chars + len(unit['quote']) <= POLICY['maximum_quote_characters']:
            quotes.append(unit); quote_chars += len(unit['quote'])
    if supported_units and not quotes:
        status = 'uncertain'; reasons.append('complete_positive_quote_exceeds_evidence_budget')
    result = {'schema': SCHEMA, 'recipe': RECIPE, 'policy_sha256': POLICY_SHA256,
              'slot_id': slot, 'candidate_id': cid, 'realization_id': rid,
              'source_record_sha256': record_hash, 'query_binding_sha256': c.digest(query_binding),
              'status': status, 'reasons': reasons, 'source_quotes': quotes,
              'role_cues': annotated[:POLICY['maximum_quote_count']], 'other_observed_roles': sorted(other_roles),
              'property_evidence': {'matching': copy.deepcopy(relevant_properties), 'other': copy.deepcopy(other_properties),
                                    'missing_effects_are_unknown': not bool(properties)},
              'owner_evidence': owners, 'numeric_evidence': numeric,
              'native_role_bridge': native_bridge,
              'omitted_source_unit_count': omitted, 'semantic_approval': False,
              'native_qualification': native_bridge['qualification'].get('native_qualification'),
              'applicability_status': proposal.get('applicability_status')}
    if authored is not None:
        result['expression_goal'] = {'goal_sha256': query_binding.get('slot_expression_sha256'),
            'expressive_goal': authored['expressive_goal'], 'goal_fit': 'not_reviewed',
            'whole_source_review_required': True, 'retrieval_support_only': True,
            'effect_correspondence_is_advisory': effect_advisory}
    result['canonical_sha256'] = c.digest(result)
    return result


def validate(value, data, slot, proposal, query_binding, lexical_hit=None, cosine_hit=None):
    expected = assess(data, slot, proposal, query_binding, lexical_hit, cosine_hit)
    if value != expected:
        raise ValueError('retrieval relevance differs from canonical source replay')
    return value
