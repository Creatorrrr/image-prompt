"""Isolated recall-first D1/S recipe. A search proposal never authorizes use.

This module deliberately does not import runtime publishers or role admission.
Canonical records remain the authority; documents are immutable derived views.
"""
from collections import Counter
import hashlib
import math
import re
import photo_canonical_source as canonical
import photo_candidate_corpus as corpus
import photo_candidate_realizations as realizations

RECIPE = 'photo-recall-first-typed-D1/v1'
QUERY_RECIPE = 'photo-recall-first-raw-S/v1'
POLICY = {'k1': 1.2, 'b': .75, 'rrf_k': 10, 'default_k': 8}
# All existing cue roles are retained without field-name boilerplate. The role
# is metadata, never an assertion that lookup or render instructions are facts.
TYPE_ORDER = {
    'option': ('labels', 'definition', 'core_meaning', 'concept_units', 'semantic_relations'),
    'profile': ('definition', 'core_meaning', 'concept_units', 'semantic_relations', 'labels'),
    'bundle': ('concept_units', 'semantic_relations', 'definition', 'core_meaning', 'labels'),
    'relationship_concept': ('definition', 'semantic_relations', 'concept_units', 'core_meaning', 'labels'),
    'relationship_mechanism': ('definition', 'semantic_relations', 'concept_units', 'core_meaning', 'labels'),
    'diagnostic': ('definition', 'labels', 'concept_units', 'semantic_relations', 'core_meaning'),
}
TAIL = ('source_requirements', 'applicability', 'manifestations', 'aliases',
        'paraphrases', 'keywords', 'discovery_hints')


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(text):
    return hashlib.sha256(text.encode()).hexdigest()


def tokens(text):
    return re.findall(r'[^\W_]+', text.casefold(), re.UNICODE)


def documents(record):
    canonical.validate(record)
    kind = canonical.contract(record)
    require(kind in TYPE_ORDER, 'unknown canonical type')
    m = record['meaning']; pool = m['literals']; fields = m['search']['fields']
    require(set(TYPE_ORDER[kind] + TAIL) == set(fields), 'unmapped canonical cue role')
    branches = record['effects'].get('realizations', {}).get('branches', [])
    branch_units = {v for b in branches for vs in b.get('component_units', {}).values() for v in vs}
    output = []
    for rid in realizations.ids(record):
        selected = realizations.branch(record, rid)
        selected_units = {v for vs in (selected or {}).get('component_units', {}).values() for v in vs}
        rejected = branch_units - selected_units
        parts = []; seen = {}; covered = []

        def add(text, role, ref):
            require(isinstance(text, str) and text.strip(), 'empty D1 part')
            item = {'role': role, 'ref': ref, 'sha256': sha(text)}
            if text in seen:
                parts[seen[text]]['sources'].append(item)
            else:
                seen[text] = len(parts)
                parts.append({'text': text, 'sources': [item]})

        for field in TYPE_ORDER[kind] + TAIL:
            role = ('lookup' if field in canonical.LOOKUP or field == 'paraphrases'
                    else 'execution_requirement' if field == 'source_requirements'
                    else 'source_' + field)
            for uid in fields[field]:
                text = pool[uid]
                if text in rejected:
                    covered.append({'field': field, 'literal': uid, 'status': 'other_RID_only'})
                else:
                    add(text, role, {'literal': uid, 'field': field})
                    covered.append({'field': field, 'literal': uid, 'status': 'included'})
        if selected:
            for i, text in enumerate(selected.get('concept_units', [])):
                add(text, 'selected_branch_unit', {'effects_branch': rid, 'concept_unit': i})
            for name, values in selected.get('component_units', {}).items():
                for i, text in enumerate(values):
                    add(text, 'selected_branch_component', {'effects_branch': rid, 'component': name, 'unit': i})
            if selected.get('context_terms'):
                add(corpus.canonical_bytes({'requires_declared_context_any': selected['context_terms']}).decode(),
                    'context_requirement', {'effects_branch': rid, 'field': 'context_terms'})
        if record['conditions']:
            add(corpus.canonical_bytes(record['conditions']).decode(), 'source_conditions', {'pointer': '/conditions'})
        if selected and selected.get('conditions'):
            add(corpus.canonical_bytes(selected['conditions']).decode(), 'branch_conditions', {'effects_branch': rid, 'field': 'conditions'})
        text = '\n'.join(p['text'] for p in parts)
        require(text.strip(), 'empty D1 document')
        body = {'recipe': RECIPE, 'id': record['id'] + '|' + rid, 'cid': record['id'],
                'rid': rid, 'record_kind': record['record_kind'], 'class': m['retrieval_class'],
                'source_sha256': corpus.digest(record), 'native_sha256': m['origin']['source_record_sha256'],
                'conditions_sha256': corpus.digest(record['conditions']), 'effects_sha256': corpus.digest(record['effects']),
                'text': text, 'text_sha256': sha(text), 'parts': parts, 'cue_coverage': covered,
                'native_evidence_preserved_in_body': True,
                'member_ids': sorted(realizations.member_ids(record, rid)),
                'authority': 'proposal_only; source conditions and final application review still required'}
        output.append({**body, 'document_sha256': corpus.digest(body)})
    return output


def validate_document(doc, record=None):
    require(doc['recipe'] == RECIPE, 'wrong D1 recipe')
    require(doc['text'] == '\n'.join(p['text'] for p in doc['parts']), 'D1 parts changed')
    require(doc['text_sha256'] == sha(doc['text']), 'stale D1 text')
    require(doc['document_sha256'] == corpus.digest({k:v for k,v in doc.items() if k != 'document_sha256'}), 'stale document checksum')
    if record is not None:
        require(doc in documents(record), 'stale or forged canonical source')
    return doc


def lexical_index(texts):
    require(bool(texts), 'empty lexical corpus')
    bags = [Counter(tokens(t)) for t in texts]
    lengths = [sum(b.values()) for b in bags]
    postings = {}
    for i, bag in enumerate(bags):
        for term, tf in bag.items():
            postings.setdefault(term, []).append([i, tf])
    return {'n': len(texts), 'lengths': lengths, 'avg_length': math.fsum(lengths)/len(bags),
            'postings': postings, 'text_hashes': [sha(t) for t in texts]}


def lexical_scores(index, query):
    require(bool(query.strip()), 'empty S')
    scores = [0.] * index['n']
    for term in sorted(set(tokens(query))):
        rows = index['postings'].get(term, [])
        idf = math.log1p((index['n'] - len(rows) + .5)/(len(rows) + .5))
        for i, tf in rows:
            norm = 1.2 * (.25 + .75 * index['lengths'][i]/index['avg_length'])
            scores[i] += idf * tf * 2.2/(tf + norm)
    return scores


def cosine(a, b):
    require(len(a) == len(b) and len(a) > 0, 'vector dimensions mismatch')
    require(all(math.isfinite(v) for v in (*a, *b)), 'nonfinite vector')
    na = math.sqrt(math.fsum(x*x for x in a)); nb = math.sqrt(math.fsum(x*x for x in b))
    require(na > 0 and nb > 0, 'zero vector')
    return math.fsum(x*y for x,y in zip(a,b))/(na*nb)


def fuse(documents_meta, sparse, dense, k=10):
    require(k == 10, 'recall-first RRF must use k10')
    ids = [d['id'] for d in documents_meta]
    require(len(set(ids)) == len(ids) == len(sparse) == len(dense), 'lane identity mismatch')
    require(all(math.isfinite(v) for v in sparse+dense), 'nonfinite lane score')
    lr = {i:r for r,i in enumerate(sorted((i for i,s in enumerate(sparse) if s > 0), key=lambda i:(-sparse[i],ids[i])),1)}
    dr = {i:r for r,i in enumerate(sorted(range(len(ids)),key=lambda i:(-dense[i],ids[i])),1)}
    ranked = []
    for i, d in enumerate(documents_meta):
        ranked.append({'id':d['id'], 'cid':d['cid'], 'rid':d['rid'], 'bm25':sparse[i], 'cosine':dense[i],
                       'bm25_rank':lr.get(i), 'dense_rank':dr[i],
                       'rrf':(1/(10+lr[i]) if i in lr else 0.)+1/(10+dr[i])})
    ranked.sort(key=lambda d:(-d['rrf'],d['id']))
    seen = set(); unique = []
    for row in ranked:
        if row['cid'] not in seen:
            seen.add(row['cid']); unique.append(row)
    return unique


def check_embedding(row, binding, text, kind):
    require(binding['space']['provider'] == 'embeddinggemma2-local', 'local backend required')
    prefix = {'document':'title: none | text: ', 'query':'task: search result | query: '}[kind]
    proof = row['execution']; v = row['vector']
    require(len(v) == binding['space']['dimensions'] and all(math.isfinite(x) for x in v), 'invalid vector')
    require(proof['provider_executed'] is True and proof['kind'] == kind, 'missing local execution')
    require(proof['space'] == binding['space'] and proof['installation_sha256'] == binding['installation_hash'], 'stale local model')
    require(proof['input_sha256'] == sha(prefix+text) and proof['vector_sha256'] == corpus.digest(v), 'stale input or vector')
    return row
