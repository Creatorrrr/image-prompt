#!/usr/bin/env python3
"""Deterministic, field-aware lexical retrieval for photo prompt indexes.

The module deliberately owns no prompt-domain meanings.  Callers provide
authored fields and a versioned policy; this file only normalizes text,
materializes a derived BM25F index, ranks documents, and fuses private ranks.
"""

from __future__ import annotations

import math
import re
import unicodedata
from collections import Counter
from functools import lru_cache
from typing import Any, Iterable, Mapping, Optional, Sequence


BM25F_TOKENIZER_RECIPE_VERSION = "photo-bm25f-tokenizer/v4"
BM25F_INDEX_RECIPE_VERSION = "photo-bm25f-index/v1"
BM25F_NONEMPTY_RECIPE_VERSION = "photo-bm25f-index/v2"
BM25F_QUERY_TERMS_RECIPE_VERSION = "photo-bm25f-query-terms/v1"
# Deliberately excludes prepositions, negation, directions, quantities and time.
# Damping retains ownership tokens; the structured query retains owner relations.
_ENGLISH_GRAMMAR_TERMS = frozenset({
    "a", "an", "the", "and", "or", "he", "she", "it", "they", "him", "her",
    "them", "his", "its", "their", "hers", "theirs",
})

_HANGUL_RE = re.compile(r"^[\uac00-\ud7a3]+$")
_JAPANESE_OR_HAN_RE = re.compile(
    r"^[\u3040-\u30ff\u3400-\u4dbf\u4e00-\u9fff]+$"
)

# Longest-first removal keeps a full eojeol and emits a conservative stem.
# It handles common particles and request-form endings without treating an
# arbitrary substring inside another Korean noun as an independent term.
_KOREAN_SUFFIXES = tuple(
    sorted(
        {
            "으로부터",
            "에게서",
            "에서부터",
            "으로써",
            "으로서",
            "이라고",
            "해져가는",
            "되어가는",
            "해가는",
            "해지는",
            "해진",
            "하는",
            "하다",
            "되는",
            "되다",
            "된",
            "라는",
            "처럼",
            "보다",
            "까지",
            "부터",
            "에게",
            "한테",
            "에서",
            "으로",
            "하고",
            "이며",
            "이고",
            "하게",
            "스러운",
            "스럽게",
            "함을",
            "라고",
            "이라",
            "와",
            "과",
            "을",
            "를",
            "은",
            "는",
            "이",
            "가",
            "의",
            "에",
            "도",
            "만",
            "로",
            "한",
            "함",
            "감",
        },
        key=lambda value: (-len(value), value),
    )
)


def normalize_bm25f_text(value: Any) -> str:
    """Return the canonical lexical representation used by every lane."""

    return " ".join(
        unicodedata.normalize("NFKC", str(value or "")).casefold().split()
    )


@lru_cache(maxsize=4096)
def _character_group(character: str) -> tuple[Optional[str], bool]:
    """Keep legacy word groups and recognize other Unicode letters/marks.

    Unicode names provide conservative alphabet boundaries without adding a
    runtime dependency or prompt-domain vocabulary. Combining accents inherit
    the preceding alphabet; alphabet-specific vowel marks stay with it.
    """
    point = ord(character)
    if character.isascii():
        return ("latin", False) if character.isalnum() else (None, False)
    if 0xAC00 <= point <= 0xD7A3:
        return "hangul_syllables", False
    if (0x3040 <= point <= 0x30FF or 0x3400 <= point <= 0x4DBF
            or 0x4E00 <= point <= 0x9FFF):
        return "japanese_han", False
    category = unicodedata.category(character)
    mark = category.startswith("M")
    if not (category.startswith("L") or category == "Nd" or mark):
        return None, False
    name = unicodedata.name(character, "")
    group = name.split(" ", 1)[0]
    # Some alphabets have two-word names; do not fuse unrelated OLD scripts
    # or TAI scripts merely because their names share the first word.
    if group in {"OLD", "NEW", "TAI", "IMPERIAL", "PAHAWH", "MEETEI"}:
        group = " ".join(name.split()[:2])
    if group == "LATIN":
        group = "latin"
    return group or None, mark


def _text_segments(text: str) -> Iterable[str]:
    """Yield words without dropping Indic/Thai marks or joining alphabets."""
    word: list[str] = []
    group = None
    for position, character in enumerate(text):
        if (character in "_+.-" and group == "latin" and word
                and word[-1].isascii() and word[-1].isalnum()
                and position + 1 < len(text)
                and text[position + 1].isascii() and text[position + 1].isalnum()):
            word.append(character)
            continue
        next_group, mark = _character_group(character)
        if mark:
            if (word and group not in {"hangul_syllables", "japanese_han"}
                    and next_group in {group, "COMBINING"}):
                word.append(character)
                continue
            # An unattached or unrelated mark is a boundary, never a word.
            next_group = None
        if word and (next_group is None or next_group != group):
            yield "".join(word)
            word = []
        group = next_group
        if group is not None:
            word.append(character)
    if word:
        yield "".join(word)


@lru_cache(maxsize=16)
def _normalized_lexicon_cached(terms: tuple[str, ...]) -> tuple[str, ...]:
    normalized = {
        normalize_bm25f_text(term)
        for term in terms
        if normalize_bm25f_text(term)
    }
    # Mixed-script authored aliases such as Han+ASCII+Kana are split by the
    # tokenizer before matching. Retain the full alias and also expose only
    # its Japanese/Han components to the longest-first segmenter. These are
    # derived from caller-owned text; this module still owns no domain terms.
    expanded = set(normalized)
    for term in normalized:
        expanded.update(
            token for token in _text_segments(term)
            if _JAPANESE_OR_HAN_RE.fullmatch(token)
        )
    return tuple(sorted(expanded, key=lambda value: (-len(value), value)))


def _normalized_lexicon(terms: Iterable[Any]) -> tuple[str, ...]:
    return _normalized_lexicon_cached(tuple(str(term) for term in terms))


class _PreparedLexicon:
    def __init__(self, terms: tuple[str, ...]) -> None:
        self.terms = terms
        self.trie: dict[str, Any] = {}
        for term in terms:
            # Only these terms can match the Japanese/Han tokens segmented below.
            if not _JAPANESE_OR_HAN_RE.fullmatch(term):
                continue
            node = self.trie
            for character in term:
                node = node.setdefault(character, {})
            node[""] = term


@lru_cache(maxsize=16)
def _prepared_lexicon_cached(terms: tuple[str, ...]) -> _PreparedLexicon:
    return _PreparedLexicon(_normalized_lexicon_cached(terms))


def _prepare_lexicon(terms: Iterable[Any] | _PreparedLexicon) -> _PreparedLexicon:
    if isinstance(terms, _PreparedLexicon):
        return terms
    return _prepared_lexicon_cached(tuple(str(term) for term in terms))


def _korean_stem(token: str) -> Optional[str]:
    for suffix in _KOREAN_SUFFIXES:
        if not token.endswith(suffix):
            continue
        stem = token[: -len(suffix)]
        if len(stem) >= 2:
            return stem
    return None


def _lexicon_segments(token: str, lexicon: _PreparedLexicon) -> list[str]:
    """Greedily segment Japanese/Han compounds with a caller-owned lexicon."""

    if not token or not lexicon.trie:
        return []
    results: list[str] = []
    cursor = 0
    while cursor < len(token):
        node = lexicon.trie
        match = None
        for position in range(cursor, len(token)):
            node = node.get(token[position])
            if node is None:
                break
            if "" in node:
                match = node[""]
        if match is None:
            cursor += 1
            continue
        results.append(match)
        cursor += len(match)
    return results


def tokenize_bm25f_text(
    value: Any,
    *,
    lexicon: Sequence[str] = (),
) -> list[str]:
    """Tokenize without raw CJK substring activation.

    Korean eojeols remain whole and may emit one conservative suffix-stripped
    stem.  Japanese/Han compounds may additionally be segmented only by the
    supplied authored lexicon. Other Unicode letters retain their combining
    marks and alphabet boundaries. The behavior is deterministic and versioned.
    """

    return _tokenize_bm25f_text(value, lexicon=lexicon)


def _tokenize_bm25f_text(
    value: Any,
    *,
    lexicon: Sequence[str] | _PreparedLexicon,
) -> list[str]:
    normalized = normalize_bm25f_text(value)
    tokens: list[str] = []
    prepared_lexicon = None
    for token in _text_segments(normalized):
        tokens.append(token)
        if _HANGUL_RE.fullmatch(token):
            stem = _korean_stem(token)
            if stem and stem != token:
                tokens.append(stem)
                plural_stem = stem[:-1] if stem.endswith("들") else ""
                if len(plural_stem) >= 2:
                    tokens.append(plural_stem)
            elif token.endswith("들") and len(token[:-1]) >= 2:
                tokens.append(token[:-1])
        elif _JAPANESE_OR_HAN_RE.fullmatch(token):
            if prepared_lexicon is None:
                prepared_lexicon = _prepare_lexicon(lexicon)
            tokens.extend(_lexicon_segments(token, prepared_lexicon))
    return tokens


def _as_values(value: Any) -> list[str]:
    if value is None:
        return []
    if isinstance(value, (list, tuple, set)):
        return [str(item) for item in value if str(item).strip()]
    return [str(value)] if str(value).strip() else []


def _policy_fields(policy: Mapping[str, Any]) -> dict[str, dict[str, float]]:
    raw_fields = policy.get("fields")
    if not isinstance(raw_fields, Mapping) or not raw_fields:
        raise ValueError("BM25F policy requires a non-empty fields mapping")
    fields: dict[str, dict[str, float]] = {}
    for name, raw_config in raw_fields.items():
        config = raw_config if isinstance(raw_config, Mapping) else {}
        weight = float(config.get("weight", 1.0))
        b_value = float(config.get("b", 0.75))
        if not math.isfinite(weight) or weight < 0:
            raise ValueError(f"BM25F field {name!r} weight must be non-negative")
        if not 0 <= b_value <= 1:
            raise ValueError(f"BM25F field {name!r} b must be between 0 and 1")
        fields[str(name)] = {"weight": weight, "b": b_value}
        if "normalization_population" in config:
            population=config["normalization_population"]
            if population not in {"all_documents","nonempty_documents"}:
                raise ValueError("unsupported field normalization population")
            fields[str(name)]["normalization_population"]=population
    return fields


def canonical_bm25f_policy(policy: Mapping[str, Any]) -> dict[str, Any]:
    """Validate and return a JSON-serializable canonical policy."""

    k1 = float(policy.get("k1", 1.2))
    if not math.isfinite(k1) or k1 <= 0:
        raise ValueError("BM25F k1 must be greater than zero")
    query_fields = policy.get("query_fields")
    canonical_query_fields = {
        str(name): float(weight)
        for name, weight in (
            query_fields.items() if isinstance(query_fields, Mapping) else []
        )
    }
    if any(not math.isfinite(weight) or weight < 0 for weight in canonical_query_fields.values()):
        raise ValueError("BM25F query field weights must be finite and non-negative")
    query_terms = policy.get("query_terms")
    canonical_query_terms = None
    if query_terms is not None:
        if not isinstance(query_terms, Mapping) or query_terms.get("recipe") != BM25F_QUERY_TERMS_RECIPE_VERSION:
            raise ValueError("unsupported BM25F query terms recipe")
        cap = float(query_terms.get("tf_cap", 1.0))
        damping = float(query_terms.get("english_grammar_weight", 0.1))
        if not math.isfinite(cap) or cap <= 0:
            raise ValueError("BM25F query TF cap must be finite and positive")
        if not math.isfinite(damping) or not 0 <= damping <= 1:
            raise ValueError("BM25F English grammar weight must be between zero and one")
        canonical_query_terms = {"recipe": BM25F_QUERY_TERMS_RECIPE_VERSION,
                                 "tf_cap": cap, "english_grammar_weight": damping}
    result = {
        "k1": k1,
        "fields": _policy_fields(policy),
        "query_fields": canonical_query_fields,
        "rrf_k": max(1, int(policy.get("rrf_k", 60))),
        "candidate_limit": max(1, int(policy.get("candidate_limit", 8))),
    }
    if canonical_query_terms is not None:
        result["query_terms"] = canonical_query_terms
    return result


def build_bm25f_index(
    documents: Mapping[str, Mapping[str, Any]],
    *,
    policy: Mapping[str, Any],
    lexicon: Sequence[str] = (),
) -> dict[str, Any]:
    """Materialize a deterministic BM25F corpus from fielded documents."""

    canonical_policy = canonical_bm25f_policy(policy)
    field_configs = canonical_policy["fields"]
    prepared_lexicon = _prepare_lexicon(lexicon)
    normalized_lexicon = list(prepared_lexicon.terms)
    indexed_documents: dict[str, Any] = {}
    field_length_totals = {field: 0 for field in field_configs}
    field_document_counts = {field: 0 for field in field_configs}
    document_frequencies: Counter[str] = Counter()

    for document_id in sorted(str(key) for key in documents):
        source = documents[document_id]
        indexed_fields: dict[str, Any] = {}
        document_terms: set[str] = set()
        for field in field_configs:
            values = _as_values(source.get(field))
            tokens: list[str] = []
            for value in values:
                tokens.extend(_tokenize_bm25f_text(value, lexicon=prepared_lexicon))
            frequencies = Counter(tokens)
            length = len(tokens)
            field_length_totals[field] += length
            field_document_counts[field] += int(length > 0)
            document_terms.update(frequencies)
            indexed_fields[field] = {
                "length": length,
                "term_frequencies": dict(sorted(frequencies.items())),
            }
        document_frequencies.update(document_terms)
        indexed_documents[document_id] = {"fields": indexed_fields}

    document_count = len(indexed_documents)
    versioned=any("normalization_population" in v for v in field_configs.values())
    populations={field:config.get("normalization_population","all_documents") for field,config in field_configs.items()}
    average_field_lengths={}
    for field in field_configs:
        denominator=field_document_counts[field] if populations[field]=="nonempty_documents" else document_count
        average_field_lengths[field]=field_length_totals[field]/denominator if denominator else 0.0
    result={
        "recipe_version": BM25F_NONEMPTY_RECIPE_VERSION if versioned else BM25F_INDEX_RECIPE_VERSION,
        "tokenizer_recipe": BM25F_TOKENIZER_RECIPE_VERSION,
        "policy": canonical_policy,
        "lexicon": normalized_lexicon,
        "document_count": document_count,
        "average_field_lengths": average_field_lengths,
        "document_frequencies": dict(sorted(document_frequencies.items())),
        "documents": indexed_documents,
    }
    if versioned:result.update(field_document_counts=field_document_counts,field_length_totals=field_length_totals,
        field_normalization_populations=populations)
    return result

def validate_statistics(payload):
    """Reject missing/inconsistent v2 statistics before reading TF postings."""
    policy=canonical_bm25f_policy(payload.get("policy") or {})
    versioned=any("normalization_population" in v for v in policy["fields"].values())
    expected=BM25F_NONEMPTY_RECIPE_VERSION if versioned else BM25F_INDEX_RECIPE_VERSION
    if payload.get("tokenizer_recipe")!=BM25F_TOKENIZER_RECIPE_VERSION:
        raise ValueError("unsupported BM25F tokenizer recipe")
    if payload.get("recipe_version")!=expected:
        raise ValueError("unsupported or mixed BM25F normalization recipe")
    if not versioned:return
    n=payload.get("document_count");fields=policy["fields"]
    if type(n) is not int or n<0:raise ValueError("invalid BM25F population")
    for key in ("field_document_counts","field_length_totals","field_normalization_populations","average_field_lengths"):
        if not isinstance(payload.get(key),Mapping) or set(payload[key])!=set(fields):raise ValueError("missing complete field normalization statistics")
    for field,config in fields.items():
        count=payload["field_document_counts"][field];total=payload["field_length_totals"][field]
        population=config.get("normalization_population","all_documents")
        if (type(count) is not int or not 0<=count<=n or type(total) is not int or total<count
            or (count==0)!=(total==0) or payload["field_normalization_populations"][field]!=population):
            raise ValueError("inconsistent field normalization population")
        denominator=count if population=="nonempty_documents" else n
        average=total/denominator if denominator else 0.0
        if payload["average_field_lengths"][field]!=average:raise ValueError("inconsistent field average")



def validate_bm25f_index(
    payload: Mapping[str, Any],
    documents: Mapping[str, Mapping[str, Any]],
    *,
    policy: Mapping[str, Any],
    lexicon: Sequence[str] = (),
) -> None:
    """Reject any stale or independently edited derived BM25F payload."""

    expected = build_bm25f_index(documents, policy=policy, lexicon=lexicon)
    if payload != expected:
        raise ValueError("BM25F index is stale; regenerate it from the authored source")


def _query_term_weights(
    query_fields: Mapping[str, Any],
    *,
    policy: Mapping[str, Any],
    lexicon: Sequence[str],
) -> Counter[str]:
    weights: Counter[str] = Counter()
    configured = policy.get("query_fields")
    query_weights = configured if isinstance(configured, Mapping) else {}
    for field, raw_value in sorted(query_fields.items()):
        field_weight = float(query_weights.get(field, 1.0))
        if field_weight <= 0:
            continue
        frequencies: Counter[str] = Counter()
        for value in _as_values(raw_value):
            frequencies.update(tokenize_bm25f_text(value, lexicon=lexicon))
        terms_policy = policy.get("query_terms")
        for token, count in sorted(frequencies.items()):
            if terms_policy is None:
                weights[token] += field_weight * count
            else:
                if terms_policy.get("recipe") != BM25F_QUERY_TERMS_RECIPE_VERSION:
                    raise ValueError("unsupported BM25F query terms recipe")
                grammar_weight = terms_policy["english_grammar_weight"] if token in _ENGLISH_GRAMMAR_TERMS else 1.0
                weights[token] += field_weight * min(count, terms_policy["tf_cap"]) * grammar_weight
    return weights


def rank_bm25f(
    payload: Mapping[str, Any],
    query_fields: Mapping[str, Any],
    *,
    limit: Optional[int] = None,
    allowed_ids: Optional[Iterable[str]] = None,
    blocked_ids: Iterable[str] = (),
) -> list[dict[str, Any]]:
    """Return private BM25F ranks with deterministic document-ID tie breaks."""

    validate_statistics(payload)
    policy = canonical_bm25f_policy(payload.get("policy") or {})
    field_configs = policy["fields"]
    lexicon = [str(value) for value in payload.get("lexicon") or []]
    query_terms = _query_term_weights(
        query_fields,
        policy=policy,
        lexicon=lexicon,
    )
    if not query_terms:
        return []
    # Persisted JSON may reorder mappings. Fix accumulation order so exact
    # receipt replay cannot differ by a floating-point rounding unit.
    ordered_terms = sorted(query_terms.items())
    ordered_fields = sorted(field_configs.items())

    allowed = {str(value) for value in allowed_ids} if allowed_ids is not None else None
    blocked = {str(value) for value in blocked_ids}
    document_count = int(payload.get("document_count", 0) or 0)
    average_lengths = payload.get("average_field_lengths") or {}
    document_frequencies = payload.get("document_frequencies") or {}
    documents = payload.get("documents") or {}
    rows: list[dict[str, Any]] = []

    document_ids = (
        sorted(str(key) for key in documents)
        if allowed is None
        else sorted(document_id for document_id in allowed if document_id in documents)
    )
    for document_id in document_ids:
        if document_id in blocked:
            continue
        document = documents.get(document_id) or {}
        indexed_fields = document.get("fields") or {}
        score = 0.0
        matched_terms: list[str] = []
        for term, query_weight in ordered_terms:
            weighted_tf = 0.0
            for field, config in ordered_fields:
                field_data = indexed_fields.get(field) or {}
                term_frequency = float(
                    (field_data.get("term_frequencies") or {}).get(term, 0)
                )
                if term_frequency <= 0:
                    continue
                field_length = float(field_data.get("length", 0) or 0)
                average_length = float(average_lengths.get(field, 0) or 0)
                length_ratio = field_length / average_length if average_length > 0 else 1.0
                normalization = 1.0 - config["b"] + config["b"] * length_ratio
                weighted_tf += config["weight"] * term_frequency / max(
                    normalization,
                    1e-12,
                )
            if weighted_tf <= 0:
                continue
            frequency = int(document_frequencies.get(term, 0) or 0)
            idf = math.log(
                1.0
                + (document_count - frequency + 0.5) / max(frequency + 0.5, 1e-12)
            )
            score += (
                float(query_weight)
                * idf
                * ((weighted_tf * (policy["k1"] + 1.0)) / (policy["k1"] + weighted_tf))
            )
            matched_terms.append(term)
        if score > 0:
            rows.append(
                {
                    "document_id": document_id,
                    "score": round(score, 12),
                    "matched_terms": sorted(set(matched_terms)),
                }
            )

    rows.sort(key=lambda row: (-float(row["score"]), str(row["document_id"])))
    effective_limit = (
        max(1, int(limit)) if limit is not None else int(policy["candidate_limit"])
    )
    return rows[:effective_limit]


def reciprocal_rank_fusion(
    rankings: Sequence[Sequence[str]],
    *,
    k: int = 60,
    limit: Optional[int] = None,
) -> list[dict[str, Any]]:
    """Fuse incomparable private ranks without treating raw scores as calibrated."""

    denominator_offset = max(1, int(k))
    scores: Counter[str] = Counter()
    lanes: dict[str, set[int]] = {}
    for lane_index, ranking in enumerate(rankings):
        seen: set[str] = set()
        for rank, raw_id in enumerate(ranking, start=1):
            document_id = str(raw_id)
            if not document_id or document_id in seen:
                continue
            seen.add(document_id)
            scores[document_id] += 1.0 / (denominator_offset + rank)
            lanes.setdefault(document_id, set()).add(lane_index)
    rows = [
        {
            "document_id": document_id,
            "score": round(float(score), 12),
            "lane_count": len(lanes.get(document_id, set())),
        }
        for document_id, score in scores.items()
    ]
    rows.sort(
        key=lambda row: (
            -float(row["score"]),
            -int(row["lane_count"]),
            str(row["document_id"]),
        )
    )
    return rows[: max(1, int(limit))] if limit is not None else rows
