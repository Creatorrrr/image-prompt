"""Offline exact index and resumable, proof-bound local vector batches."""
from array import array
import argparse
import errno
import json
import math
import os
from pathlib import Path
import socket
import sys
import time
import photo_candidate_corpus as c
import photo_recall_first as rf
from photo_recall_generation import read, write, file_sha


def positive_documents(generation):
    generation=Path(generation);manifest=read(generation/'source-manifest.json')
    documents=[]
    for path,expected in manifest['files'].items():
        if path.startswith('documents/'):
            rf.require(file_sha(generation/path)==expected,'stale D1 document shard')
            documents.extend(d for d in read(generation/path) if d['class']=='positive')
    documents.sort(key=lambda d:d['id'])
    for d in documents:rf.validate_document(d)
    rf.require(len(documents)==manifest['positive_documents'],'positive document coverage mismatch')
    return documents


def network_denied():
    try:
        with socket.socket() as sock:sock.connect(('127.0.0.1',9))
    except OSError as error:
        rf.require(error.errno in (errno.EPERM,errno.EACCES),'OS network denial is required')
        return {'probe':'127.0.0.1:9','errno':error.errno,'network_denied':True}
    raise ValueError('OS network denial is required')


def build(generation, skill, queries_path, stop_after=None):
    probe=network_denied();start=time.monotonic();generation=Path(generation);skill=Path(skill)
    # The installed worker is the only inference dependency of this isolated path.
    sys.path.insert(0,str(Path(__file__).resolve().parents[3]))
    from prototypes.visual_ideas.embedding import LocalEncoder
    documents=positive_documents(generation);texts=[d['text'] for d in documents]
    lexical=rf.lexical_index(texts);write(generation/'lexical.json.gz',lexical)
    unique={rf.sha(t):t for t in texts};ordered=sorted(unique,key=lambda h:(len(unique[h]),h))
    query_values=read(queries_path);query_keys=sorted(query_values)
    done={};new=0;reused=0
    with LocalEncoder(skill) as encoder:
        binding=encoder.binding
        for offset in range(0,len(ordered),32):
            hashes=ordered[offset:offset+32];batchtexts=[unique[h] for h in hashes]
            request=c.digest({'texts':batchtexts,'kind':'document','binding':binding})
            path=generation/'embedding-batches'/(request+'.json.gz')
            if path.exists():
                batch=read(path);rf.require(batch['binding']==binding and batch['hashes']==hashes,'stale batch identity')
                rows=batch['rows'];reused+=len(rows)
            else:
                rows=encoder.encode(batchtexts,'document');new+=len(rows)
                write(path,{'binding':binding,'hashes':hashes,'rows':rows,'OS_network_denial':probe})
            for h,text,row in zip(hashes,batchtexts,rows,strict=True):
                rf.check_embedding(row,binding,text,'document');done[h]=row
            progress={'unique_documents':len(ordered),'completed':len(done),'new':new,'reused':reused,
                      'elapsed_seconds':time.monotonic()-start,'binding':binding,'network':probe}
            write(generation/'embedding-progress.json',progress)
            print('local document vectors',len(done),'/',len(ordered),'new',new,'reused',reused,
                  'seconds',round(progress['elapsed_seconds'],1),flush=True)
            if stop_after is not None and offset//32+1>=stop_after:return progress
        querytexts=[query_values[k]['S'] for k in query_keys]
        qrequest=c.digest({'kind':'query','texts':querytexts,'binding':binding})
        qpath=generation/'embedding-batches'/(qrequest+'.json.gz')
        query_reused=qpath.exists()
        if query_reused:qrows=read(qpath)['rows']
        else:
            qrows=[]
            for i in range(0,len(querytexts),32):qrows.extend(encoder.encode(querytexts[i:i+32],'query'))
            write(qpath,{'binding':binding,'rows':qrows,'OS_network_denial':probe})
        for text,row in zip(querytexts,qrows,strict=True):rf.check_embedding(row,binding,text,'query')
        write(generation/'query-vectors.json.gz',{'binding':binding,'queries':query_values,
              'rows':{k:r for k,r in zip(query_keys,qrows,strict=True)}})
    matrix=array('d')
    for d in documents:matrix.extend(done[d['text_sha256']]['vector'])
    rf.require(sys.byteorder=='little','little endian vector writer required')
    path=generation/'vectors.f64';temporary=path.with_suffix('.partial')
    with temporary.open('wb') as stream:matrix.tofile(stream);stream.flush();os.fsync(stream.fileno())
    os.replace(temporary,path)
    metadata=[{k:d[k] for k in ('id','cid','rid','source_sha256','text_sha256','document_sha256')} for d in documents]
    write(generation/'indexed-documents.json.gz',metadata)
    files={str(p.relative_to(generation)):file_sha(p) for p in sorted(generation.rglob('*'))
           if p.is_file() and p.name not in {'index-manifest.json'} and not p.name.endswith('.partial')}
    result={'schema':'photo-recall-first-index/v1','recipe':rf.RECIPE,'policy':rf.POLICY,'binding':binding,
            'source_manifest_sha256':file_sha(generation/'source-manifest.json'),'documents':len(documents),
            'CIDs':len({d['cid'] for d in documents}),'unique_inputs':len(ordered),'new_document_inference':new,
            'resumed_document_inference':reused,'query_vector_rows':len(qrows),
            'new_query_inference_rows':0 if query_reused else len(qrows),
            'reused_query_vector_rows':len(qrows) if query_reused else 0,
            'lexical_tokenizer':'unicode-casefold-no-stopwords/v1',
            'exact_cosine':'entire float64 matrix; every document, no ANN/routing/admission',
            'vector_dtype':'little-endian-float64','network':probe,'Gemini_calls':0,'files':files,
            'elapsed_seconds':time.monotonic()-start,'publication':'isolated only; not CURRENT'}
    write(generation/'index-manifest.json',result)
    print('complete isolated full-pool index',len(documents),'documents',flush=True)
    return result


class Index:
    def __init__(self,generation,numpy):
        self.root=Path(generation);self.manifest=read(self.root/'index-manifest.json');self.np=numpy
        rf.require(self.manifest['schema']=='photo-recall-first-index/v1' and self.manifest['recipe']==rf.RECIPE
                   and self.manifest['policy']==rf.POLICY,'wrong index recipe')
        for name in ('vectors.f64','lexical.json.gz','indexed-documents.json.gz','query-vectors.json.gz','source-manifest.json'):
            rf.require(file_sha(self.root/name)==self.manifest['files'][name],'stale indexed file: '+name)
        self.documents=read(self.root/'indexed-documents.json.gz');self.lexical=read(self.root/'lexical.json.gz')
        self.matrix=numpy.memmap(self.root/'vectors.f64',dtype='<f8',mode='r',shape=(len(self.documents),768))
        self.norms=numpy.linalg.norm(self.matrix,axis=1)
        rf.require(bool(numpy.isfinite(self.matrix).all()) and bool((self.norms>0).all()),'invalid full vector matrix')
        rf.require(self.lexical['text_hashes']==[d['text_sha256'] for d in self.documents],'stale lexical/document correspondence')

    def search(self, text, query_row, *, binding=None, chunk_size=1024):
        binding=self.manifest['binding'] if binding is None else binding
        rf.require(binding==self.manifest['binding'],'query/index binding mismatch')
        rf.check_embedding(query_row,binding,text,'query')
        sparse=rf.lexical_scores(self.lexical,text);query=self.np.asarray(query_row['vector'],dtype=self.np.float64)
        norm=float(self.np.linalg.norm(query));dense=[]
        rf.require(type(chunk_size) is int and chunk_size>0,'positive chunk size required')
        for offset in range(0,len(self.documents),chunk_size):
            # BLAS GEMV changes reduction order with block dimensions. That can
            # split equal scores for duplicate document vectors by one ULP and
            # change rank-based fusion. Fix the per-row reduction independently
            # of chunk shape; do not round distinct scores or add a rank prior.
            products=self.np.einsum('ij,j->i',self.matrix[offset:offset+chunk_size],query,optimize=False)
            scores=products/(self.norms[offset:offset+chunk_size]*norm)
            dense.extend(float(x) for x in scores)
        return rf.fuse(self.documents,sparse,dense)


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--generation',required=True)
    parser.add_argument('--skill',required=True);parser.add_argument('--queries',required=True)
    parser.add_argument('--stop-after-batches',type=int)
    args=parser.parse_args();build(args.generation,args.skill,args.queries,args.stop_after_batches)
