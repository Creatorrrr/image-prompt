"""Bounded, deterministic advisory ordering; no cached judgments or authority.

Source coverage is a lexical observation, never a whole-source fit decision.
The original full-pool lanes and RRF are retained without modification.
"""
import copy
import photo_candidate_corpus as c
import photo_retrieval_relevance as relevance

GOAL_RECIPE='photo-goal-first-slot-query/v1'
POLICIES={
    'evidence-v1':{'query_recipe':'photo-independent-slot-query/v4','weights':[.30,.50,.20]},
    'goal-v1':{'query_recipe':GOAL_RECIPE,'weights':[.30,.50,.20]},
    'goal-strong-v1':{'query_recipe':GOAL_RECIPE,'weights':[.15,.70,.15]}}
POLICIES['common-meaning-v1']={'query_recipe':'photo-independent-slot-query/v4','weights':[.30,.50,.20]}
REPAIR_FEATURES={'common-repair-pool-v1':('pool',),'common-repair-rank-v1':('evidence_order',),
                 'common-repair-window-v1':('window',),'common-repair-final-v1':('final',),
                 'common-repair-v1':('pool','evidence_order','window','final')}
for _name in REPAIR_FEATURES:
    POLICIES[_name]={'query_recipe':'photo-independent-slot-query/v4','weights':[.30,.50,.20]}

def is_common(name):return name=='common-meaning-v1' or name in REPAIR_FEATURES
def feature(policy,name):return name in policy.get('repair_features',())

def policy(name):
    if name not in POLICIES:raise ValueError('unknown frozen preview policy')
    value={'recipe':'photo-goal-preview/v1','variant':name,**copy.deepcopy(POLICIES[name]),
            'lane_limit':384,'shortlist_limit':8,'maximum_examined':128,
            'pool_seeds':{'rrf':64,'bm25f':16,'embedding':16},
            'quota':{'reranked':4,'bm25f':2,'embedding':2},'tag_admission_filter':False}
    if is_common(name):
        value.update(recipe='photo-relational-review-window/v1',review_window_limit=16,
            quota={'initial_meaning':6,'initial_unstructured':2,'standby':8})
    if name in REPAIR_FEATURES:
        value.update(recipe='photo-common-search-repair/v1',repair_features=list(REPAIR_FEATURES[name]))
        if 'evidence_order' in REPAIR_FEATURES[name]:value['ordering']='intent_evidence_then_lane_prior/v1'
        if 'window' in REPAIR_FEATURES[name]:value['quota'].update(standby_intent=4,standby_lane_rescue=4,standby_order='alternating')
        if 'final' in REPAIR_FEATURES[name]:value.update(novelty_contract='separate_intent_claim_and_lexical_term/v1',active_fit_count='unique_complete_meaning_groups')
    return value

def pool(rrf,lexical,dense):
    """Up to 96 seeds; deterministic refill up to 128, independent of labels."""
    seeds=list(dict.fromkeys([r['document_id'] for lane,n in ((rrf,64),(lexical,16),(dense,16)) for r in lane[:n]]))
    refill=list(dict.fromkeys([r['document_id'] for pos in range(max(map(len,(rrf,lexical,dense)),default=0))
        for lane in (rrf,lexical,dense) for r in lane[pos:pos+1]]))
    return seeds+[cid for cid in refill if cid not in set(seeds)][:128-len(seeds)],len(seeds)

def score(record,rid,goal,hit,weights):
    focus=relevance._tokens(goal['role_focus'])
    targets=relevance._tokens(' '.join(goal['observable_targets']+goal['owner_relations']))
    units,omitted=relevance._units(record,rid)
    evidence=[];union=set();supported=0
    for unit in units:
        words=relevance._tokens(unit['quote']);union.update(words)
        overlap=words&(focus|targets)
        supported+=bool(overlap)
        if overlap:evidence.append({'pointer':unit['pointer'],'source_sha256':unit['source_sha256'],
                                    'matched_terms':sorted(overlap)})
    coverage=.8*len(union&focus)/max(1,len(focus))+.2*len(union&targets)/max(1,len(targets))
    # Long compound records with many unmatched units retain uncertainty.
    precision=len(union&(focus|targets))/max(1,len(union))
    prior=min(1.0,31*hit['score']/2)
    value=sum(w*x for w,x in zip(weights,(prior,coverage,precision),strict=True))
    return {'score':round(value,12),'lane_prior':prior,'goal_coverage':coverage,'primary_specificity':precision,
            'unmatched_unit_fraction':1-supported/max(1,len(units)), 'omitted_source_units':omitted,
            'source_record_sha256':c.digest(record),'positive_evidence':evidence,
            'matched_terms':sorted(union&(focus|targets)), 'semantic_approval':False,'native_approval':False}

def evidence_order(scores,rrf):
    """Keep raw evidence intact; a prior can only break evidence-score ties."""
    positions={h['document_id']:n for n,h in enumerate(rrf,1)};result={}
    for cid,row in scores.items():
        out=dict(row);value=round(.50*row['goal_coverage']+.20*row['primary_specificity']+row.get('common_meaning_adjustment',0),12)
        out.update(legacy_combined_score=row['score'],intent_evidence=value,score=value,
            ordering_recipe='intent_evidence_then_lane_prior/v1',raw_rrf_position=positions.get(cid,10**9))
        result[cid]=out
    return result

def ranked(scores,rrf):
    positions={h['document_id']:n for n,h in enumerate(rrf)}
    modes={row.get('ordering_recipe') for row in scores.values()}
    if len(modes)>1:raise ValueError('mixed preview ordering contracts')
    if modes=={'intent_evidence_then_lane_prior/v1'}:
        return sorted(scores,key=lambda cid:(-scores[cid]['intent_evidence'],-scores[cid]['lane_prior'],positions.get(cid,10**9),cid))
    return sorted(scores,key=lambda cid:(-scores[cid]['score'],positions.get(cid,10**9),cid))

def allocate(order,lexical,dense,duplicate_keys,limit=8):
    """Four goal-ranked, two lexical, two dense; borrow in stable round robin."""
    selected=[];groups=set();trace=[]
    def take(lane,name,count):
        added=0
        for cid in lane:
            if cid in selected or cid not in duplicate_keys or duplicate_keys[cid] in groups:continue
            selected.append(cid);groups.add(duplicate_keys[cid]);trace.append({'candidate_id':cid,'quota':name})
            added+=1
            if added==count or len(selected)==limit:break
        return added
    lanes=[order,[r['document_id'] for r in lexical],[r['document_id'] for r in dense]]
    for lane,name,count in zip(lanes,('reranked','bm25f','embedding'),(4,2,2),strict=True):
        if len(selected)<limit:take(lane,name,min(count,limit-len(selected)))
    while len(selected)<limit:
        before=len(selected)
        for lane,name in zip(lanes,('borrow_reranked','borrow_bm25f','borrow_embedding'),strict=True):
            if len(selected)<limit:take(lane,name,1)
        if len(selected)==before:break
    return selected,trace

def final_order(cids,scores,*,separate_novelty=False):
    """Soft novelty after direct fit review; no state-specific fit preference."""
    if len({scores[cid].get('ordering_recipe') for cid in cids})>1:raise ValueError('mixed final ordering contracts')
    remaining=list(cids);selected=[];covered=set();trace=[]
    coverage={'intent_claim':set(),'lexical_term':set()}
    def novelty(cid):
        comparison=scores[cid].get('meaning_comparison',{})
        claims=set(comparison.get('matched_intent_claims') or []) if comparison.get('complete_search') is True and not comparison.get('explicit_conflicts') else set()
        namespace='intent_claim' if claims else 'lexical_term'
        terms=claims or set(scores[cid]['matched_terms'])
        return namespace,terms,terms-coverage[namespace]
    while remaining:
        def value(cid):
            if separate_novelty:
                _,terms,new=novelty(cid)
                return scores[cid]['score']+.10*len(new)/max(1,len(terms))
            terms=set(scores[cid].get('meaning_comparison',{}).get('matched_intent_claims') or scores[cid]['matched_terms']);novel=len(terms-covered)/max(1,len(terms))
            return scores[cid]['score']+.10*novel
        if all(scores[cid].get('ordering_recipe')=='intent_evidence_then_lane_prior/v1' for cid in remaining):
            cid=min(remaining,key=lambda x:(-value(x),-scores[x]['lane_prior'],scores[x]['raw_rrf_position'],x))
        else:cid=max(remaining,key=lambda x:(value(x),-cids.index(x)))
        if separate_novelty:
            namespace,terms,new=novelty(cid)
            trace.append({'candidate_id':cid,'score_with_novelty':value(cid),'novelty_namespace':namespace,
                'new_intent_claims':sorted(new) if namespace=='intent_claim' else [],
                'new_lexical_terms':sorted(new) if namespace=='lexical_term' else [],'semantic_approval':False})
            coverage[namespace].update(terms)
        else:trace.append({'candidate_id':cid,'score_with_novelty':value(cid),
                          'new_goal_terms':sorted(set(scores[cid]['matched_terms'])-covered)})
        remaining.remove(cid);selected.append(cid);covered.update(scores[cid].get('meaning_comparison',{}).get('matched_intent_claims') or scores[cid]['matched_terms'])
    return selected,trace
