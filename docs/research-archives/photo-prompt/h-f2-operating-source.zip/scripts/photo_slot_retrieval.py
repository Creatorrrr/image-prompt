"""Independent, full-positive-pool hybrid retrieval before presentation budgets."""
import hashlib
import photo_candidate_corpus as c
import photo_global_retrieval as guards
import photo_slot_queries as queries
import photo_role_proposals as roles
import photo_sharded_search as search
import photo_candidate_realizations as realizations
import photo_retrieval_relevance as relevance
import photo_slot_expression as expression
from bm25f_retrieval import reciprocal_rank_fusion

VERSION='photo-slot-retrieval/v6'
ALGORITHM='independent_global_bm25f_certified_cosine_rrf_authored/v5'
PRESENTATION_POLICY={'recipe':'photo-relevance-presentation/v1','initial_lane_limit':384,
                     'maximum_lane_limit':768,'examined_per_prefix':256}
MODES={'hybrid_required','keyword_only'}


def active_slots(data,core,controls,requested=None):
    import prompt_generator as g
    if requested is not None:
        slots=sorted(set(requested))
        for slot in slots:queries.specification(data['slot_catalog'],slot)
        return slots
    contract,_=g.frozen_core_context(data,core,controls)
    opened=set(core['intent_lock']['open_dimensions'])
    return [slot for slot,spec in sorted(data['slot_catalog'].items())
            if not g.slot_block_reason(data,slot,contract)
            and (not spec['dimensions'] or bool(opened & set(spec['dimensions'])))]


def retrieve(data,core,controls,context=None,mode='hybrid_required',*,requested_slots=None,language='en',unique_limit=64):
    import prompt_generator as g
    if mode not in MODES or not 1<=unique_limit<=64:raise ValueError('invalid slot retrieval mode/budget')
    reader=data.get('_search_reader')
    if reader is None:raise ValueError('lazy shared search generation required')
    reader.check_presence()
    plan=(context or {}).get('expression_plan') or getattr(data,'expression_plan',None)
    slots=active_slots(data,core,controls,requested_slots if requested_slots is not None else sorted((plan or {}).get('slots',{})))
    expression.validate(plan,core,controls,data['slot_catalog'],slots)
    fields=queries.validate_set(context,core,controls,data['slot_catalog'],slots,space=reader.manifest['space']) if mode=='hybrid_required' else {}
    if mode=='keyword_only' and context is not None:raise ValueError('keyword diagnostic cannot claim query embeddings')
    allowed,source_roles,contract=guards.eligible(data,core,controls)
    _,picked=g.frozen_core_context(data,core,controls)
    guard_data=dict(data);guard_data['candidates']=reader.meta['guards']
    bindings_by_candidate={}
    for bid,source_binding in data['slot_bindings'].items():
        bindings_by_candidate.setdefault(source_binding['candidate_id'],[]).append(bid)
    traces={};desired={};proposals={};counts={};limits={slot:4 if data['slot_catalog'][slot]['priority']=='core' else 2 for slot in slots}
    for slot in slots:
        intention=plan['slots'][slot]
        if intention['status']!='search':
            desired[slot]=[];counts[slot]=0
            traces[slot]={'state':intention['status'],'search_scope':'whole_shared_positive_corpus','tag_admission_filter':False,
                'query_sha256':None,'slot_spec_sha256':c.digest(queries.specification(data['slot_catalog'],slot)),
                'expression_row_sha256':c.digest(intention),'lane_limit':0,'iterations':0,'eligible_candidates':len(allowed),
                'role_block_reason':None,'reason':intention['reason'],'role_rejected_candidate_ids':[],
                'prefix_history':[],'relevance_assessments':{},'duplicate_candidate_ids':{},
                'stop_reason':'authored_'+intention['status'],'presentation_exhaustive':False,'examined_budget_reached':False,
                'lanes':{lane:{'state':'not_executed','positive_hits':0,'ranks':[]} for lane in ('bm25f','embedding')},
                'cosine_proof':None,'rrf':[],'desired_proposal_ids':[]}
            continue
        text,lexical,binding=queries.inputs(core,controls,data['slot_catalog'],slot,language,expression_plan=plan)
        if mode=='hybrid_required':
            lexical=fields[slot];row=context['slots'][slot];text=row['text'];binding=row['binding'];vector=row['vector']
        limit=PRESENTATION_POLICY['initial_lane_limit'];chosen=[];iterations=0
        history=[];assessments={}
        while True:
            lh=search.lexical_rank(reader,lexical,allowed,limit)
            vh,proof=search.cosine_rank(reader,vector,allowed,limit) if mode=='hybrid_required' else ([],None)
            rankings=[[r['document_id'] for r in lh]]+([[r['document_id'] for r in vh]] if mode=='hybrid_required' else [])
            fused=reciprocal_rank_fusion(rankings,k=30)
            chosen=[];iterations+=1;rejected=set();duplicates={};groups={};examined=[]
            lexical_hits={r['document_id']:r for r in lh};cosine_hits={r['document_id']:r for r in vh}
            blocked=g.slot_block_reason(data,slot,contract)
            if blocked:
                rejected.update(hit['document_id'] for hit in fused)
            for hit in ([] if blocked else fused):
                if len(examined)>=PRESENTATION_POLICY['examined_per_prefix']:break
                cid=hit['document_id'];examined.append(cid)
                possible=realizations.eligible_ids(guard_data,cid,core,contract,picked,slot,allow_owner_selection_pending=True)
                if not possible:
                    rejected.add(cid);continue
                proposal=roles.propose(data,slot,cid,source_roles[cid],bindings_by_candidate.get(cid,[]),realization_ids=possible)
                if proposal['applicability_status']=='incompatible':
                    rejected.add(cid);continue
                entry=roles.entry(guard_data,proposal)
                if not g.core_entry_eligible(data,core,contract,picked,slot,entry,allow_owner_selection_pending=True):
                    rejected.add(cid);continue
                advisory=relevance.assess(data,slot,proposal,binding,lexical_hits.get(cid),cosine_hits.get(cid))
                assessments[cid]=advisory
                if advisory['status']!='supported':continue
                group=relevance.duplicate_key(data['candidates'][cid],proposal['realization_id'])
                if group in groups:
                    duplicates[cid]=groups[group];continue
                groups[group]=cid
                proposals[proposal['proposal_id']]=proposal
                chosen.append((cid,proposal['proposal_id'],hit))
                if len(chosen)>=limits[slot]:break
            if blocked:stop='slot_blocked'
            elif len(chosen)>=limits[slot]:stop='cap_filled'
            elif len(lh)<limit and len(vh)<limit:stop='lanes_exhausted'
            elif limit>=len(allowed):stop='pool_exhausted'
            elif limit>=PRESENTATION_POLICY['maximum_lane_limit']:stop='prefix_budget_exhausted'
            else:stop='extend'
            history.append({'lane_limit':limit,'examined_candidate_ids':examined,
                            'chosen_proposal_ids':[p for _,p,_ in chosen],'stop_reason':stop})
            if stop!='extend':break
            # Recompute both prefixes and fusion; no stale RRF page appends.
            limit=min(len(allowed),PRESENTATION_POLICY['maximum_lane_limit'],limit*2)
        desired[slot]=chosen;counts[slot]=len(fused)
        traces[slot]={'state':'executed','search_scope':'whole_shared_positive_corpus','tag_admission_filter':False,
                      'query_sha256':hashlib.sha256(text.encode()).hexdigest(),'slot_spec_sha256':binding['slot_spec_sha256'],
                      'expression_row_sha256':c.digest(intention),
                      'lane_limit':limit,'iterations':iterations,'eligible_candidates':len(allowed),
                      'role_block_reason':blocked,'role_rejected_candidate_ids':sorted(rejected),
                      'prefix_history':history,'relevance_assessments':assessments,
                      'duplicate_candidate_ids':duplicates,'stop_reason':stop,
                      'presentation_exhaustive':bool(blocked) or (stop in {'lanes_exhausted','pool_exhausted'} and len(examined)==len(fused)),
                      'examined_budget_reached':len(examined)<len(fused) and len(examined)>=PRESENTATION_POLICY['examined_per_prefix'],
                      'lanes':{'bm25f':{'state':'executed','positive_hits':len(lh),'ranks':lh},
                               'embedding':{'state':'executed' if mode=='hybrid_required' else 'not_requested','positive_hits':len(vh),'ranks':vh}},
                      'cosine_proof':proof,'rrf':fused,'desired_proposal_ids':[p for _,p,_ in chosen]}
    selected=[];cards={};admitted={slot:[] for slot in slots};priority=sorted(slots,key=lambda s:(data['slot_catalog'][s]['priority']!='core',s))
    for position in range(max(limits.values(),default=0)):
        for slot in priority:
            if position>=len(desired[slot]):continue
            cid,pid,hit=desired[slot][position]
            if cid not in selected:
                if len(selected)>=unique_limit:continue
                selected.append(cid)
            admitted[slot].append((cid,pid,hit))
    presented=dict(data);presented['_request_role_proposals']={slot:{cid:proposals[pid] for cid,pid,_ in admitted[slot]} for slot in slots}
    for slot in slots:
        rows=[]
        for cid,pid,hit in admitted[slot]:
            proposal=proposals[pid]
            candidate,_=g.candidate_pack_summarize_slot_candidate(presented,slot,{'id':cid,'applicability_status':proposal['applicability_status'],'applicability_source':'independent_full_pool_hybrid'})
            candidate.update(proposal_id=pid,binding_id=proposal['source_binding_id'],
                             realization_id=proposal['realization_id'],
                             retrieval_evidence={'rrf_score':hit['score'],'lane_count':hit['lane_count']},
                             retrieval_relevance=traces[slot]['relevance_assessments'][cid])
            source=relevance.summary(data['candidates'][cid],proposal['realization_id'])
            if source['concept_units']:
                source.update(affected_dimensions=proposal['effects']['dimensions'],
                              affected_properties=proposal['effects']['properties'],adoption='optional')
                candidate['_native_semantic_source']=source
                candidate['concept_terms']=source['concept_units']
            else:candidate['_native_semantic_source']=g.photo_candidate_semantics.semantic_source(roles.entry(data,proposal))
            rows.append(candidate)
        state=plan['slots'][slot]['status'] if plan['slots'][slot]['status']!='search' else ('blocked' if traces[slot]['role_block_reason'] else ('no_hits' if not desired[slot] else ('budget_excluded' if not rows else ('budget_partial' if len(rows)<len(desired[slot]) else 'available'))))
        cards[slot]={'slot':slot,'role':data['slot_catalog'][slot]['priority'],'selected':None,'candidates':rows,
                     'candidate_count':len(allowed),'retrieved_candidate_count':counts[slot],'candidate_limit':limits[slot],'status':state,
                     'presentation_exhaustive':traces[slot]['presentation_exhaustive'],
                     'presentation_stop_reason':traces[slot]['stop_reason']}
    retained={pid:proposals[pid] for rows in admitted.values() for _,pid,_ in rows}
    record={'contract_version':VERSION,'source_authorial_core_sha256':core['canonical_sha256'],'creative_controls_sha256':controls['canonical_sha256'],
            'corpus_sha256':reader.meta['corpus_sha256'],'binding_sha256':c.digest(data['slot_bindings']),'catalog_sha256':c.digest(data['slot_catalog']),
            'index_sha256':data['_global_index_sha256'],'query_context_sha256':context['canonical_sha256'] if context else None,
            'expression_plan':plan,'expression_plan_sha256':plan['canonical_sha256'],
            'mode':mode,'query_language':language,'requested_slot_ids':sorted(set(requested_slots)) if requested_slots is not None else None,
            'active_slot_ids':slots,'inactive_slot_ids':sorted(set(data['slot_catalog'])-set(slots)),
            'algorithm':ALGORITHM,'presentation_policy':dict(PRESENTATION_POLICY),
            'relevance_policy_sha256':c.digest(relevance.POLICY),'rrf_k':30,'minimum_similarity':.30,
            'lanes':{'bm25f':{'state':'executed' if any(r['status']=='search' for r in plan['slots'].values()) else 'not_requested','slot_count':sum(r['status']=='search' for r in plan['slots'].values())},
                     'embedding':{'state':'executed' if mode=='hybrid_required' and any(r['status']=='search' for r in plan['slots'].values()) else 'not_requested','slot_count':sum(r['status']=='search' for r in plan['slots'].values()) if mode=='hybrid_required' else 0}},
            'slot_searches':traces,'role_proposals':retained,'eligible_candidates':len(allowed),'selected_candidate_ids':selected,
            'unique_candidate_limit':unique_limit,'role_limits':{'core':4,'support':2},'tag_admission_filter':False,'candidate_adoption':'optional'}
    record['canonical_sha256']=c.digest(record)
    return cards,record,contract
