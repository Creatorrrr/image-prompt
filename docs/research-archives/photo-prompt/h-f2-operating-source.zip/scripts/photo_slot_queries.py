"""Post-freeze, candidate-free role queries and immutable provider contexts."""
import hashlib
import copy
import photo_candidate_corpus as c
import photo_slot_expression as expression
from photo_embedding_provider import embed, embed_many, SPACE, default_space, validate_vector, validate_execution
import re
HASH=re.compile(r'[0-9a-f]{64}\Z')

RECIPE = 'photo-independent-slot-query/v4'
SCHEMA = 'photo-slot-query-set/v4'
CONTEXT_SCHEMA = 'photo-slot-query-vector/v4'
GOAL_RECIPE = 'photo-goal-first-slot-query/v1'
H_F2_RECIPE = 'photo-h-f2/v1'


def specification(catalog, slot):
    if slot not in catalog:
        raise ValueError('unknown managed slot: ' + slot)
    row = catalog[slot]
    return {'recipe': RECIPE, 'slot_id': slot, 'focus_en': row['description'],
            'focus_ko': row['description_ko'], 'dimensions': row['dimensions'],
            'semantic_role': row['semantic_role'], 'owners': row['owners'],
            'property_prefixes': row['property_prefixes'], 'includes': row['includes'],
            'evidence_terms': row['evidence_terms'],
            'excludes': row['excludes'], 'neighbors': row['neighbors'],
            'core_fields': row['core_fields'], 'applicability': row['applicability'],
            'search_scope': 'whole_shared_positive_corpus'}


def inputs(core, controls, catalog, slot, language='en', *, expression_plan=None, recipe=RECIPE):
    if recipe not in {RECIPE, GOAL_RECIPE, H_F2_RECIPE}: raise ValueError('unknown slot query recipe')
    if language not in {'en', 'ko'}:
        raise ValueError('unsupported slot query language')
    spec = specification(catalog, slot)
    expression.validate(expression_plan, core, controls, catalog)
    authored = expression_plan['slots'].get(slot)
    if not isinstance(authored, dict) or authored.get('status') != 'search':
        raise ValueError('authored search expression required for this slot')
    focus, scene = authored['role_focus'], authored['scene_context']
    lexical = {'role_focus': focus, 'scene_context': scene}
    text = 'Photographic role: ' + focus + ('\nScene context: ' + scene if scene else '')
    if recipe == GOAL_RECIPE:
        focused = focus + '\nObservable targets: ' + '; '.join(authored['observable_targets']) + '\nOwner relations: ' + '; '.join(authored['owner_relations'])
        lexical = {'role_focus': focused, 'scene_context': ''}
        text = 'Photographic expression goal: ' + focused
    binding = {'recipe': recipe, 'slot_id': slot, 'slot_spec_sha256': c.digest(spec),
               'core_sha256': core['canonical_sha256'], 'controls_sha256': controls['canonical_sha256'],
               'language': authored['language'], 'caller_language': language, 'query_fields': lexical,
               'slot_expression': copy.deepcopy(authored), 'slot_expression_sha256': c.digest(authored),
               'expression_plan_sha256': expression_plan['canonical_sha256']}
    if any(not HASH.fullmatch(v) for v in (core['canonical_sha256'], controls['canonical_sha256'])):
        raise ValueError('slot queries require frozen core and controls')
    return text, lexical, binding


def context(core, controls, catalog, slot, cache, language='en', *, space=None, result=None, expression_plan=None, recipe=RECIPE):
    space=space or default_space()
    text, fields, binding = inputs(core, controls, catalog, slot, language, expression_plan=expression_plan, recipe=recipe)
    row = result or embed(text, binding, cache,space=space)
    value = {'schema': CONTEXT_SCHEMA, 'text': text, 'text_sha256': hashlib.sha256(text.encode()).hexdigest(),
             'binding': binding, 'space': space, 'vector': row['vector'], 'vector_sha256': row['vector_sha256'],
             'execution': row['execution'], 'cache_hit': row['cache_hit']}
    value['canonical_sha256'] = c.digest(value)
    return value


def validate(row, core, controls, catalog, slot, *, space=SPACE, expression_plan=None):
    language = (row.get('binding') or {}).get('caller_language') if isinstance(row, dict) else None
    text, fields, binding = inputs(core, controls, catalog, slot, language, expression_plan=expression_plan, recipe=(row.get('binding') or {}).get('recipe'))
    if (set(row) != {'schema','text','text_sha256','binding','space','vector','vector_sha256','execution','cache_hit','canonical_sha256'}
            or row.get('schema') != CONTEXT_SCHEMA or row.get('binding') != binding
            or row.get('space') != space or row.get('text') != text
            or row.get('text_sha256') != hashlib.sha256(text.encode()).hexdigest()
            or row.get('vector_sha256') != c.digest(row.get('vector'))
            or row.get('canonical_sha256') != c.digest({k:v for k,v in row.items() if k != 'canonical_sha256'})):
        raise ValueError('foreign or modified independent slot query')
    validate_vector(row.get('vector'))
    trace = row.get('execution') or {}
    validate_execution(trace,space,text,row['vector'])
    return fields


def prepare(core, controls, catalog, slots, cache, *, workers=4, language='en',space=None, expression_plan=None, recipe=RECIPE, common_intents=None):
    if language not in {'en', 'ko'}:
        raise ValueError('unsupported caller query language')
    slots = sorted(set(slots))
    space=space or default_space()
    expression.validate(expression_plan, core, controls, catalog, slots)
    if common_intents is not None:
        import photo_common_meaning as common
        common.validate_intent_set(common_intents,core,controls,expression_plan,slots)
    # Native v4 queries never fall back to a remote provider. Historical
    # receipts keep their original generation and are not re-embedded here.
    if space.get('provider') != 'embeddinggemma2-local':
        raise ValueError('native slot queries require the local embedding provider')
    searched = [slot for slot in slots if expression_plan['slots'][slot]['status'] == 'search']
    items=[inputs(core,controls,catalog,slot,language,expression_plan=expression_plan,recipe=recipe) for slot in searched]
    results=embed_many([x[0] for x in items],[x[2] for x in items],cache,space=space) if items else []
    rows=[context(core,controls,catalog,slot,cache,language,space=space,result=row,expression_plan=expression_plan,recipe=recipe) for slot,row in zip(searched,results,strict=True)]
    value = {'schema': SCHEMA, 'slots': dict(zip(searched, rows)), 'expression_plan': copy.deepcopy(expression_plan)}
    if common_intents is not None:value['common_intents']=copy.deepcopy(common_intents)
    value['canonical_sha256'] = c.digest(value)
    return value


def validate_set(value, core, controls, catalog, slots, *, space=SPACE, expression_plan=None):
    required={'schema','slots','expression_plan','canonical_sha256'}
    if not isinstance(value, dict) or set(value) not in (required, required|{'common_intents'}) or value.get('schema') != SCHEMA:
        raise ValueError('exact independent slot query set required')
    plan = value['expression_plan']
    if expression_plan is not None and expression_plan != plan:
        raise ValueError('foreign authored expression plan in query set')
    expression.validate(plan, core, controls, catalog, slots)
    if 'common_intents' in value:
        import photo_common_meaning as common
        common.validate_intent_set(value['common_intents'],core,controls,plan,slots)
    searched = {slot for slot in slots if plan['slots'][slot]['status'] == 'search'}
    if not isinstance(value['slots'], dict) or set(value['slots']) != searched:
        raise ValueError('exact authored search query set required')
    if value.get('canonical_sha256') != c.digest({k:v for k,v in value.items() if k != 'canonical_sha256'}):
        raise ValueError('slot query set checksum mismatch')
    return {slot: validate(value['slots'][slot], core, controls, catalog, slot,space=space,
                           expression_plan=plan) for slot in sorted(searched)}
