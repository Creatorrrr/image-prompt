"""Canonical literal ownership, source meaning and native execution contracts.

Only this source schema is accepted. Native execution trees use generic literal
references; they are not an old source input or a discovery/meaning parser.
Historical evidence locators are opaque keys, never JSON paths walked at run
time. Native qualification keeps its established hash codec and proof bytes.
"""
import copy
import photo_candidate_corpus as c

SCHEMA='photo-canonical-meaning/v1'
NATIVE='photo-native-literal-tree/v1'
GUARD='photo-canonical-native-guard/v1'
RECIPE='photo-common-grounded-document/v2'
ORDER=('labels','definition','aliases','paraphrases','concept_units','semantic_relations',
       'manifestations','keywords','core_meaning','source_requirements','applicability','discovery_hints')
LOOKUP=frozenset({'aliases','keywords','discovery_hints'})
MEANING_FIELDS=frozenset({'schema','literals','primary','evidence','search','graphs','graph_provenance',
    'retrieval_class','native_contract','origin','coverage'})
CONTRACTS=frozenset({'option','profile','relationship_concept','relationship_mechanism','bundle','diagnostic'})

def decode_tree(tree,literals):
    if isinstance(tree,dict):
        if set(tree)=={'$literal'} and isinstance(tree['$literal'],str):
            try:return literals[tree['$literal']]
            except KeyError as exc:raise ValueError('dangling canonical literal reference') from exc
        return {k:decode_tree(v,literals) for k,v in tree.items()}
    if isinstance(tree,list):return [decode_tree(v,literals) for v in tree]
    return tree

def native(record):
    if 'content' in record:raise ValueError('retired content source is not accepted')
    value=record.get('native')
    if not isinstance(value,dict) or set(value)!={'schema','tree'}:raise ValueError('canonical native execution contract required')
    if value['schema']==GUARD:return value['tree']
    if value['schema']!=NATIVE or record.get('meaning',{}).get('schema')!=SCHEMA:raise ValueError('canonical literal source required')
    return decode_tree(value['tree'],record['meaning']['literals'])

def payload(value):
    """Native presentation entries are derived views, never authored sources."""
    if 'content' in value:raise ValueError('retired content source is not accepted')
    return native(value) if 'native' in value else value

def contract(record):
    return record.get('meaning',{}).get('native_contract') or record.get('native_contract')

def positive(record):
    return record.get('meaning',{}).get('retrieval_class',record.get('retrieval_class'))=='positive'

def units(record,rid):
    try:
        meaning=record['meaning'];locators=meaning['primary'][rid]
        return {key:meaning['literals'][uid] for key,uid in locators.items()}
    except KeyError as exc:raise ValueError('missing exact canonical RID/source units') from exc

def evidence(record,rid):
    try:
        m=record['meaning'];return {key:m['literals'][uid] for key,uid in m['evidence'][rid].items()}
    except KeyError as exc:raise ValueError('missing exact canonical RID/evidence units') from exc

def quote(record,rid,locator):
    try:return evidence(record,rid)[locator]
    except KeyError as exc:raise ValueError('missing positive canonical source locator') from exc

def document(record):
    meaning=record.get('meaning',{})
    if meaning.get('schema')!=SCHEMA:raise ValueError('canonical meaning document required')
    pool=meaning['literals'];fields={name:[pool[uid] for uid in meaning['search']['fields'][name]] for name in ORDER}
    text='\n'.join(('lookup ' if name in LOOKUP else '')+name.replace('_',' ')+': '+'; '.join(fields[name]) for name in ORDER if fields[name])
    return {'recipe':RECIPE,'fields':fields,'text':text}

def graph(record,rid):
    if rid not in record['meaning']['primary']:raise ValueError('foreign canonical realization')
    value=record['meaning']['graphs'].get(rid)
    return decode_tree(value,record['meaning']['literals']) if value is not None else None

def native_snapshot(record):
    """Exact native authority snapshot codec, independent of storage layout.

    `content` is the existing native-proof hash domain, not an input schema.
    Keeping this codec is necessary to preserve, rather than re-sign, evidence.
    """
    return {'id':record['id'],'record_kind':record['record_kind'],'content':native(record),
        'conditions':record['conditions'],'effects':record['effects'],'provenance':record['provenance']}

def semantic_fingerprint(record):
    return c.digest({'native_evidence':{rid:evidence(record,rid) for rid in record['meaning']['evidence']},'primary':{rid:units(record,rid) for rid in record['meaning']['primary']},
        'conditions':record['conditions'],'effects':record['effects'],'native':native_snapshot(record)})

def validate(record):
    meaning=record.get('meaning')
    if (not isinstance(meaning,dict) or set(meaning)!=MEANING_FIELDS or meaning['schema']!=SCHEMA
        or meaning['retrieval_class'] not in {'positive','diagnostic'} or meaning['native_contract'] not in CONTRACTS
        or not isinstance(meaning['literals'],dict) or len(meaning['literals'])>65536
        or any(not isinstance(k,str) or not isinstance(v,str) for k,v in meaning['literals'].items())
        or len(set(meaning['literals'].values()))!=len(meaning['literals'])):
        raise ValueError('canonical single-owner literal meaning required')
    if record.get('native',{}).get('schema')!=NATIVE:raise ValueError('full canonical source requires a literal reference tree')
    def encoded(value):
        if isinstance(value,str):raise ValueError('unowned string in canonical reference tree')
        if isinstance(value,dict):
            if set(value)=={'$literal'} and isinstance(value['$literal'],str):
                if value['$literal'] not in meaning['literals']:raise ValueError('dangling canonical literal reference')
            else:
                for child in value.values():encoded(child)
        elif isinstance(value,list):
            for child in value:encoded(child)
    encoded(record['native']['tree']);encoded(meaning['graphs'])
    import photo_candidate_realizations as r
    if set(meaning['evidence'])!=set(meaning['primary']) or set(meaning['primary'])!=set(r.ids(record)) or not set(meaning['graphs'])<=set(meaning['primary']):
        raise ValueError('canonical RID/source/graph inventory mismatch')
    if (set(meaning['search'])!={'fields'} or set(meaning['search']['fields'])!=set(ORDER)
        or any(not isinstance(v,list) or len(v)!=len(set(v)) or not set(v)<=set(meaning['literals']) for v in meaning['search']['fields'].values())):
        raise ValueError('canonical field/literal coverage required')
    for rid,paths in list(meaning['primary'].items())+list(meaning['evidence'].items()):
        if not isinstance(paths,dict) or any(not isinstance(p,str) or uid not in meaning['literals'] for p,uid in paths.items()):
            raise ValueError('canonical opaque source locator changed')
    if any(any(meaning['evidence'][rid].get(p)!=uid for p,uid in paths.items()) for rid,paths in meaning['primary'].items()):
        raise ValueError('primary source must remain exact native evidence')
    if c.digest(native_snapshot(record))!=meaning['origin']['source_record_sha256']:
        raise ValueError('native semantic snapshot changed during canonical migration')
    if semantic_fingerprint(record)!=meaning['origin']['semantic_fingerprint']:
        raise ValueError('canonical full source meaning/conditions/effects changed')
    if set(meaning['graphs'])!=set(meaning['graph_provenance']):raise ValueError('graph provenance coverage required')
    if meaning['graphs']:
        from photo_common_meaning import graph as validate_graph
        for rid in meaning['graphs']:
            value=graph(record,rid);provenance=meaning['graph_provenance'][rid]
            if c.digest(value)!=provenance['graph_sha256'] or provenance['review']['native_approval'] is not False:
                raise ValueError('preserved graph provenance/authority changed')
            validate_graph(value,units(record,rid),source=True)
    # Origins can point to duplicated source literals; the canonical pool owns
    # each exact string once. Search strings may retain normalized join units.
    for name,ids in meaning['search']['fields'].items():
        if any(not meaning['literals'][uid].strip() for uid in ids):raise ValueError('empty canonical search unit')
    document(record)
    return record
