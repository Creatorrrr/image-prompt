"""One directly authored, post-freeze H query; no candidates or provider IO."""
import hashlib
import photo_slot_expression as expression
import photo_slot_queries as queries
RECIPE='photo-h-f2/v1'

def text(role_focus,scene_context):
    if not isinstance(role_focus,str) or not role_focus.strip() or not isinstance(scene_context,str):
        raise ValueError('nonempty authored role focus and scene context required')
    return 'Photographic role: '+role_focus+('\nScene context: '+scene_context if scene_context else '')

def prepare(core,controls,catalog,plan):
    expression.validate(plan,core,controls,catalog)
    rows={}
    for slot,goal in sorted(plan['slots'].items()):
        if goal['status']!='search':continue
        value,fields,binding=queries.inputs(core,controls,catalog,slot,goal['language'],expression_plan=plan,recipe=RECIPE)
        if value!=text(goal['role_focus'],goal['scene_context']):raise ValueError('H query text mismatch')
        rows[slot]={'text':value,'binding':binding,'text_sha256':hashlib.sha256(value.encode()).hexdigest()}
    return {'recipe':RECIPE,'slots':rows,'plan_sha256':plan['canonical_sha256'],
            'core_sha256':expression.digest(core),'controls_sha256':expression.digest(controls)}
