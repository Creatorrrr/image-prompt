"""Bounded independent proof/rank/allocation audit for native slot queries."""
import hashlib
import math
import photo_candidate_corpus as c
import photo_native_pack as packs
import photo_global_retrieval as guards
import photo_role_proposals as roles
import photo_slot_queries as queries
import photo_slot_expression as expressions
import photo_slot_retrieval as rules
import photo_candidate_realizations as realizations
import photo_retrieval_relevance as relevance
import photo_sharded_search as search
from bm25f_retrieval import _query_term_weights, validate_statistics


def lexical_replay(reader,fields,allowed,limit):
    stats=reader.meta['statistics'];policy=stats['policy'];values={};matched={}
    validate_statistics(stats)
    for term,weight in sorted(_query_term_weights(fields,policy=policy,lexicon=stats['lexicon']).items()):
        block=reader.meta['posting_locator'].get(term)
        if block is None:continue
        df=stats['document_frequencies'][term]
        idf=math.log(1+(stats['document_count']-df+.5)/max(df+.5,1e-12))
        for cid,tf in reader.block('posting',block)[term]:
            if cid in allowed:
                values[cid]=values.get(cid,0.)+float(weight)*idf*((tf*(policy['k1']+1))/(policy['k1']+tf))
                matched.setdefault(cid,[]).append(term)
    rows=[{'document_id':cid,'score':round(score,12),'matched_terms':matched[cid]} for cid,score in values.items() if score>0]
    return sorted(rows,key=lambda r:(-r['score'],r['document_id']))[:limit]


def fusion(lanes):
    sums={};counts={}
    for hits in lanes:
        for position,row in enumerate(hits,1):
            cid=row['document_id'];sums[cid]=sums.get(cid,0.)+1/(30+position);counts[cid]=counts.get(cid,0)+1
    rows=[{'document_id':cid,'score':round(v,12),'lane_count':counts[cid]} for cid,v in sums.items()]
    return sorted(rows,key=lambda r:(-r['score'],-r['lane_count'],r['document_id']))


def nonsearch_trace(slot,expression,catalog,eligible_count):
    """Derive an authored abstention without querying either retrieval lane."""
    return {'state':expression['status'],'search_scope':'whole_shared_positive_corpus','tag_admission_filter':False,
        'query_sha256':None,'slot_spec_sha256':c.digest(queries.specification(catalog,slot)),
        'expression_row_sha256':expressions.digest(expression),'lane_limit':0,'iterations':0,'eligible_candidates':eligible_count,
        'role_block_reason':None,'reason':expression['reason'],'role_rejected_candidate_ids':[],
        'prefix_history':[],'relevance_assessments':{},'duplicate_candidate_ids':{},
        'stop_reason':'authored_'+expression['status'],'presentation_exhaustive':False,'examined_budget_reached':False,
        'lanes':{lane:{'state':'not_executed','positive_hits':0,'ranks':[]} for lane in ('bm25f','embedding')},
        'cosine_proof':None,'rrf':[],'desired_proposal_ids':[]}


def audit(pack,data,context):
    import prompt_generator as g
    import photo_precap_review as precap
    if pack.get('global_retrieval',{}).get('contract_version')==precap.RETRIEVAL_VERSION:
        return precap.audit(pack,data,context)
    failures=[]
    try:
        packs.validate(pack);record=pack['global_retrieval'];core=pack['authorial_core'];controls=pack['creative_controls']
        if hasattr(data,'for_core'):data=data.for_core(core)
        reader=data['_search_reader'];reader.check_presence();mode=record['mode']
        plan=record['expression_plan']
        requested=record['requested_slot_ids']
        slots=sorted(set(requested)) if requested is not None else sorted(plan['slots'])
        expressions.validate(plan,core,controls,data['slot_catalog'],slots=slots)
        if record['expression_plan_sha256']!=plan['canonical_sha256']:raise ValueError('foreign authored expression plan')
        search_slots=[slot for slot in slots if plan['slots'][slot]['status']=='search']
        if record['contract_version']!=rules.VERSION or mode not in rules.MODES or record['canonical_sha256']!=c.digest({k:v for k,v in record.items() if k!='canonical_sha256'}):raise ValueError('slot retrieval schema/checksum mismatch')
        expected={'corpus_sha256':reader.meta['corpus_sha256'],'binding_sha256':c.digest(data['slot_bindings']),'catalog_sha256':c.digest(data['slot_catalog']),'index_sha256':data['_global_index_sha256'],
                  'source_authorial_core_sha256':core['canonical_sha256'],'creative_controls_sha256':controls['canonical_sha256'],'active_slot_ids':slots,'inactive_slot_ids':sorted(set(data['slot_catalog'])-set(slots)),
                  'unique_candidate_limit':64,'role_limits':{'core':4,'support':2},'minimum_similarity':.30,'rrf_k':30,'tag_admission_filter':False,'candidate_adoption':'optional','algorithm':'independent_global_bm25f_certified_cosine_rrf_authored/v5',
                  'presentation_policy':{'recipe':'photo-relevance-presentation/v1','initial_lane_limit':384,'maximum_lane_limit':768,'examined_per_prefix':256},
                  'relevance_policy_sha256':c.digest(relevance.POLICY),
                  'lanes':{'bm25f':{'state':'executed' if search_slots else 'not_requested','slot_count':len(search_slots)},'embedding':{'state':'executed' if mode=='hybrid_required' and search_slots else 'not_requested','slot_count':len(search_slots) if mode=='hybrid_required' else 0}}}
        if any(record.get(k)!=v for k,v in expected.items()):raise ValueError('slot source/query/policy binding mismatch')
        if mode=='hybrid_required':
            fields=queries.validate_set(context,core,controls,data['slot_catalog'],slots,space=reader.manifest['space'])
            if context['expression_plan']!=plan:raise ValueError('query set authored expression plan differs')
        elif context is not None:raise ValueError('keyword diagnostic claims query vectors')
        if record['query_context_sha256']!=(context['canonical_sha256'] if context else None):raise ValueError('foreign slot query set')
        allowed,source_roles,contract=guards.eligible(data,core,controls);_,picked=g.frozen_core_context(data,core,controls)
        gd=dict(data);gd['candidates']=reader.meta['guards'];wanted={};expected_proposals={};expected_evidence={}
        limits={s:4 if data['slot_catalog'][s]['priority']=='core' else 2 for s in slots}
        declared={}
        for bid,b in data['slot_bindings'].items():declared.setdefault(b['candidate_id'],[]).append(bid)
        if set(record['slot_searches'])!=set(slots) or record['eligible_candidates']!=len(allowed):raise ValueError('missing independent slot search')
        for slot in slots:
            trace=record['slot_searches'][slot];limit=trace['lane_limit']
            expression=plan['slots'][slot]
            if expression['status']!='search':
                expected_trace=nonsearch_trace(slot,expression,data['slot_catalog'],len(allowed))
                if trace!=expected_trace:raise ValueError('non-search authored slot claims execution or changed reason')
                wanted[slot]=[];expected_evidence[slot]={}
                continue
            text,lexical,binding=queries.inputs(core,controls,data['slot_catalog'],slot,record['query_language'],expression_plan=plan)
            if mode=='hybrid_required':
                row=context['slots'][slot]
                if row['binding']['language']!=expression['language'] or row['binding']['caller_language']!=record['query_language']:raise ValueError('authored slot language or caller metadata changed')
                text=row['text'];lexical=fields[slot];binding=row['binding']
            if trace['expression_row_sha256']!=expressions.digest(expression):raise ValueError('authored slot row changed')
            if limit<384 or trace['state']!='executed' or trace['search_scope']!='whole_shared_positive_corpus' or trace['tag_admission_filter'] is not False or trace['query_sha256']!=hashlib.sha256(text.encode()).hexdigest() or trace['slot_spec_sha256']!=binding['slot_spec_sha256'] or trace['eligible_candidates']!=len(allowed):raise ValueError('slot execution binding mismatch')
            lh=lexical_replay(reader,lexical,allowed,limit);vh=trace['lanes']['embedding']['ranks']
            if trace['lanes']['bm25f']!={'state':'executed','positive_hits':len(lh),'ranks':lh}:raise ValueError('global posting BM25F ranks differ')
            if mode=='hybrid_required':
                proof=trace['cosine_proof']
                if proof['limit']!=limit or proof['minimum']!=.30:raise ValueError('cosine search scope/cutoff changed')
                search.audit_cosine(reader,row['vector'],allowed,vh,proof)
            elif vh or trace['cosine_proof'] is not None:raise ValueError('keyword search claims cosine ranks')
            if trace['lanes']['embedding']!={'state':'executed' if mode=='hybrid_required' else 'not_requested','positive_hits':len(vh),'ranks':vh}:raise ValueError('embedding lane execution mismatch')
            combined=fusion([lh,vh] if mode=='hybrid_required' else [lh])
            if trace['rrf']!=combined:raise ValueError('slot RRF changed')
            blocked=g.slot_block_reason(data,slot,contract)
            history=[];assessments={};prefix=384
            while True:
                partial_lh=lh[:prefix];partial_vh=vh[:prefix]
                combined_prefix=fusion([partial_lh,partial_vh] if mode=='hybrid_required' else [partial_lh])
                lexical_by_id={r['document_id']:r for r in partial_lh}
                cosine_by_id={r['document_id']:r for r in partial_vh}
                chosen=[];rejected=set();duplicates={};seen={};examined=[];prefix_proposals={}
                if blocked:
                    rejected.update(r['document_id'] for r in combined_prefix)
                else:
                    for hit in combined_prefix[:256]:
                        cid=hit['document_id'];examined.append(cid)
                        possible=realizations.eligible_ids(gd,cid,core,contract,picked,slot,allow_owner_selection_pending=True)
                        if not possible:
                            rejected.add(cid);continue
                        p=roles.propose(data,slot,cid,source_roles[cid],declared.get(cid,[]),realization_ids=possible)
                        if p['applicability_status']=='incompatible':rejected.add(cid);continue
                        entry=roles.entry(gd,p)
                        if not g.core_entry_eligible(data,core,contract,picked,slot,entry,allow_owner_selection_pending=True):rejected.add(cid);continue
                        advisory=relevance.assess(data,slot,p,binding,lexical_hit=lexical_by_id.get(cid),cosine_hit=cosine_by_id.get(cid))
                        assessments[cid]=advisory
                        if advisory['status']!='supported':continue
                        group=relevance.duplicate_key(data['candidates'][cid],p['realization_id'])
                        if group in seen:
                            duplicates[cid]=seen[group];continue
                        seen[group]=cid;prefix_proposals[p['proposal_id']]=p;chosen.append((cid,p['proposal_id']))
                        if len(chosen)>=limits[slot]:break
                if blocked:stop='slot_blocked'
                elif len(chosen)>=limits[slot]:stop='cap_filled'
                elif len(partial_lh)<prefix and len(partial_vh)<prefix:stop='lanes_exhausted'
                elif prefix>=len(allowed):stop='pool_exhausted'
                elif prefix>=768:stop='prefix_budget_exhausted'
                else:stop='extend'
                history.append({'lane_limit':prefix,'examined_candidate_ids':examined,
                                'chosen_proposal_ids':[pid for _,pid in chosen],'stop_reason':stop})
                if stop!='extend':break
                prefix=min(len(allowed),prefix*2,768)
            exhaustive=bool(blocked) or (stop in {'lanes_exhausted','pool_exhausted'} and len(examined)==len(combined))
            examined_budget=len(examined)<len(combined) and len(examined)>=256
            if trace['stop_reason']!=stop or trace['presentation_exhaustive']!=exhaustive or trace['examined_budget_reached']!=examined_budget:
                raise ValueError('relevance completeness claim changed')
            if prefix!=limit or trace['iterations']!=len(history) or trace['prefix_history']!=history:
                raise ValueError('relevance prefix search/stopping changed')
            if trace['relevance_assessments']!=assessments or trace['duplicate_candidate_ids']!=duplicates:
                raise ValueError('relevance source evidence or semantic deduplication changed')
            if trace['desired_proposal_ids']!=[p for _,p in chosen] or trace['role_rejected_candidate_ids']!=sorted(rejected) or trace['role_block_reason']!=blocked:
                raise ValueError('role guard/adoption projection changed')
            expected_proposals.update(prefix_proposals)
            final_by_id={r['document_id']:r for r in combined}
            expected_evidence[slot]={cid:{'retrieval_relevance':assessments[cid],
                'retrieval_evidence':{'rrf_score':final_by_id[cid]['score'],'lane_count':final_by_id[cid]['lane_count']}}
                for cid,_ in chosen}
            wanted[slot]=chosen
        selected=[];refs={s:[] for s in slots}
        for position in range(max(limits.values(),default=0)):
            for slot in sorted(slots,key=lambda s:(data['slot_catalog'][s]['priority']!='core',s)):
                if position>=len(wanted[slot]):continue
                cid,pid=wanted[slot][position]
                if cid not in selected:
                    if len(selected)>=64:continue
                    selected.append(cid)
                refs[slot].append({'candidate_id':cid,'proposal_id':pid})
        retained={r['proposal_id']:expected_proposals[r['proposal_id']] for rows in refs.values() for r in rows}
        if selected!=record['selected_candidate_ids'] or set(pack['candidate_pool'])!=set(selected):raise ValueError('global unique allocation changed')
        if pack['role_proposals']!=retained or record['role_proposals']!=retained:raise ValueError('role source effect/condition altered')
        canonical_refs=lambda values:{slot:sorted((r['candidate_id'],r['proposal_id']) for r in rows) for slot,rows in values.items()}
        if canonical_refs({s:v['candidate_refs'] for s,v in pack['role_views'].items()})!=canonical_refs(refs):raise ValueError('role reference allocation changed')
        for slot,rows in refs.items():
            trace=record['slot_searches'][slot]
            state=plan['slots'][slot]['status'] if slot not in search_slots else ('blocked' if trace['role_block_reason'] else ('no_hits' if not wanted[slot] else ('budget_excluded' if not rows else ('budget_partial' if len(rows)<len(wanted[slot]) else 'available'))))
            expected_view={'slot':slot,'role':data['slot_catalog'][slot]['priority'],'selected':None,
                'candidate_count':len(allowed),'retrieved_candidate_count':len(trace['rrf']),
                'candidate_limit':limits[slot],'status':state,'presentation_exhaustive':trace['presentation_exhaustive'],
                'presentation_stop_reason':trace['stop_reason']}
            if any(pack['role_views'][slot].get(key)!=value for key,value in expected_view.items()):
                raise ValueError('role presentation availability/completeness changed')
            evidence={ref['candidate_id']:expected_evidence[slot][ref['candidate_id']] for ref in rows}
            if pack['role_views'][slot].get('candidate_evidence')!=evidence:
                raise ValueError('per-role relevance presentation changed')
        for slot,card in packs.role_cards(pack).items():
            for row in card['candidates']:
                proposal=retained[row['proposal_id']]
                summary=relevance.summary(data['candidates'][row['id']],proposal['realization_id'])
                if summary['concept_units']:
                    summary.update(affected_dimensions=proposal['effects']['dimensions'],
                                   affected_properties=proposal['effects']['properties'],adoption='optional')
                    if row.get('concept_terms')!=summary['concept_units']:
                        raise ValueError('candidate positive summary terms changed')
                else:summary=g.photo_candidate_semantics.semantic_source(roles.entry(data,proposal))
                if '_native_semantic_source' in row:
                    if row['_native_semantic_source']!=summary:
                        raise ValueError('candidate positive source summary changed')
                elif summary.get('concept_units') and row.get('content_form')=='unordered_inspiration_terms':
                    if any(row.get(key)!=summary[key] for key in ('concept_units','relations')):
                        raise ValueError('public candidate positive source summary changed')
        for row in pack['candidate_pool'].values():
            if 'retrieval_relevance' in row or 'retrieval_evidence' in row:
                raise ValueError('role-specific relevance leaked into shared candidate pool')
        bids={p['source_binding_id'] for p in retained.values() if p['source_binding_id'] is not None}
        if pack['candidate_bindings']!={bid:data['slot_bindings'][bid] for bid in bids}:raise ValueError('persistent source binding altered')
        for cid,row in pack['candidate_pool'].items():
            if row['authored_record']!=data['candidates'][cid]:raise ValueError('candidate authored meaning altered')
    except (KeyError,TypeError,ValueError,AttributeError) as error:failures.append({'check':'global_retrieval_contract','reason':str(error)})
    return failures
