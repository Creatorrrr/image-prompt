"""Request-local creative proposals over a complete common candidate pool.

No active skill entrypoint is changed by this adapter. Stage 9 may bind it to
the managed authoring workflow after an explicit operating transition.
"""
import time
import photo_candidate_corpus as c
import photo_canonical_source as canonical
import photo_candidate_realizations as realizations
import photo_recall_first as rf
from photo_recall_generation import BodyReader,file_sha

SCHEMA='photo-recall-first-proposals/v1'


def pack(index, request, goals, query_rows, *, limit=8, display_budget=None):
    rf.require(limit in (8,16),'supported proposal budgets are 8 and 16')
    rf.require(display_budget is None or type(display_budget) is int and display_budget>=0,'invalid display budget')
    rf.require(goals and set(goals)==set(query_rows),'goal/query scope mismatch')
    request_hash=c.digest(request)
    for goal in goals.values():
        rf.require(goal.get('core_sha256')==request_hash,'S core or lock changed; author a newly bound goal')
        rf.require(goal['request_sha256']==rf.sha(request['source_request']),'S request changed')
    reader=BodyReader(index.root);sources={};results={};truncated=[];remaining=display_budget
    binding=index.manifest['binding']
    for key in sorted(goals):
        goal=goals[key];text=goal['S']
        rf.require(goal['request_sha256']==rf.sha(request['source_request']),'S request changed')
        started=time.monotonic();order=index.search(text,query_rows[key],binding=binding)
        proposals=[]
        for rank,row in enumerate(order[:limit],1):
            record=reader.record(row['cid'])
            rf.require(c.digest(record)==next(d['source_sha256'] for d in index.documents if d['id']==row['id']),'proposal source changed')
            rf.require(row['rid'] in realizations.ids(record),'proposal RID changed')
            sources[row['cid']]=record
            proposals.append({**row,'rank':rank,'source_sha256':c.digest(record),
                              'native_sha256':record['meaning']['origin']['source_record_sha256'],
                              'conditions':record['conditions'],'selected_branch':realizations.branch(record,row['rid']),
                              'effects':realizations.effects(record,row['rid']),
                              'meaning_units':canonical.units(record,row['rid']),
                              'judgment':'unreviewed creative proposal','application':'requires source and owner/locked-fact review'})
        shown=proposals if remaining is None else proposals[:remaining]
        if remaining is not None:remaining=max(0,remaining-len(shown))
        dropped=[r['cid'] for r in proposals[len(shown):]]
        if dropped:truncated.append({'goal':key,'candidate_ids':dropped,'reason':'presentation_budget_only'})
        results[key]={'S':text,'S_sha256':rf.sha(text),'goal_sha256':goal['goal_sha256'],
                      'query_execution':query_rows[key]['execution'],'query_recipe':rf.QUERY_RECIPE,
                      'considered_CIDs':index.manifest['CIDs'],'considered_documents':index.manifest['documents'],
                      'retrieved':proposals,'displayed':shown,'search_seconds':time.monotonic()-started,
                      'full_order_sha256':c.digest(order),'full_unique_order_count':len(order)}
    value={'schema':SCHEMA,'request_sha256':request_hash,'request':request,
           'index_manifest_sha256':file_sha(index.root/'index-manifest.json'),
           'source_manifest_sha256':index.manifest['source_manifest_sha256'],'recipe':rf.RECIPE,
           'limit':limit,'goals':results,'sources':sources,'body_shards_read':reader.reads,
           'body_records_loaded':sum(map(len,reader.cache.values())),
           'body_compressed_bytes_read':sum((reader.root/path).stat().st_size for path in reader.reads),
           'presentation_losses':truncated,'authority':'retrieval only; no whole-source approval or automatic prompt modification'}
    return {**value,'pack_sha256':c.digest(value)}


def application_context(packet, goal_key, cid, *, request):
    """Restore the source and original lock for an author's final decision.

    This is a review input, not a replacement for the managed compose audit.
    An author's fragment reference must not assert whole-contract adoption.
    """
    rf.require(packet['schema']==SCHEMA,'wrong proposal packet')
    rf.require(packet['pack_sha256']==c.digest({k:v for k,v in packet.items() if k!='pack_sha256'}),'stale proposal packet')
    rf.require(c.digest(request)==packet['request_sha256'],'request or lock changed')
    row=next((r for r in packet['goals'][goal_key]['retrieved'] if r['cid']==cid),None)
    rf.require(row is not None,'candidate does not belong to this goal proposal')
    source=packet['sources'][cid];rf.require(c.digest(source)==row['source_sha256'],'application source changed')
    return {'goal':goal_key,'S':packet['goals'][goal_key]['S'],'candidate_id':cid,'realization_id':row['rid'],
            'native':canonical.native(source),'primary_units':canonical.units(source,row['rid']),
            'conditions':source['conditions'],'effects':row['effects'],'selected_branch':row['selected_branch'],
            'intent_lock':request.get('intent_lock'),'semantic_assertions':request.get('semantic_assertions',[]),
            'allowed_decisions':['skip','creative_fragment_reference','propose_whole_source_for_managed_compose_audit'],
            'whole_source_adopted':False,'approval':'pending authored final application review and existing compose audit'}
