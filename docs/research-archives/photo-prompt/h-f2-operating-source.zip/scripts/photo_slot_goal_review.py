"""Separate human-authored goal-fit judgements bound to an unchanged pack.

Labels and rationales are supplied by Codex, never inferred here. Hash and quote
checks establish binding/integrity, not semantic truth, authorship authenticity,
candidate adoption, native qualification, permission or pre-retrieval timing.
``goal_sha256`` binds the complete authored slot row, including its open scope.
Without source_data this checks public-pack consistency only. Supplying pinned
source_data also compares the full canonical record and authoritative catalog.
No search, corpus traversal, model, network or filesystem operation is used.
"""
from __future__ import annotations

import copy
import re
import photo_slot_expression as expression
import photo_semantic_evidence as semantic
import photo_candidate_realizations as realizations

SCHEMA = 'photo-slot-goal-review/v1'
LABELS = frozenset({'relevant', 'uncertain', 'irrelevant'})
DECISION_INPUT_FIELDS = frozenset({'slot_id', 'candidate_id', 'realization_id', 'label',
    'rationale', 'source_record_sha256', 'goal_sha256', 'source_quotes'})
DECISION_FIELDS = DECISION_INPUT_FIELDS | {'semantic_approval', 'native_approval'}
REVIEW_FIELDS = frozenset({'schema', 'author', 'pack_sha256', 'expression_plan_sha256',
    'decisions', 'semantic_approval', 'native_approval', 'canonical_sha256'})
MAX_DECISIONS = 149 * 4
MAX_QUOTES = 12
MAX_REVIEW_BYTES = 2 * 1024 * 1024
_CID = re.compile(r'cand_[0-9a-f]{32}\Z')


def _plan(pack, source_data):
    if not isinstance(pack, dict):
        raise ValueError('candidate pack mapping required')
    retrieval = pack.get('global_retrieval')
    if not isinstance(retrieval, dict):
        raise ValueError('pack authored retrieval binding required')
    if retrieval.get('canonical_sha256') != expression.digest({k:v for k,v in retrieval.items() if k != 'canonical_sha256'}):
        raise ValueError('pack retrieval checksum changed')
    plan = retrieval.get('expression_plan')
    if (not isinstance(plan, dict) or set(plan) != expression.PLAN_FIELDS
            or plan.get('schema') != expression.SCHEMA or plan.get('semantic_approval') is not False
            or plan.get('canonical_sha256') != expression.digest({k:v for k,v in plan.items() if k != 'canonical_sha256'})
            or retrieval.get('expression_plan_sha256') != plan['canonical_sha256']):
        raise ValueError('pack authored expression plan changed')
    core, controls = pack.get('authorial_core'), pack.get('creative_controls')
    if (not isinstance(core, dict) or not isinstance(controls, dict)
            or plan['core_sha256'] != expression.digest(core)
            or plan['controls_sha256'] != expression.digest(controls)):
        raise ValueError('goal review plan belongs to another core or controls')
    slots = retrieval.get('active_slot_ids')
    if not isinstance(plan['slots'], dict) or not isinstance(slots, list) or len(slots) != len(set(slots)) or set(plan['slots']) != set(slots):
        raise ValueError('goal review requires exact authored slot coverage')
    expression._text(plan['overall_intent'], 'overall_intent', 8000, required=True)
    for slot, row in plan['slots'].items():
        expression._row(row, core, slot)
    if source_data is not None:
        catalog = source_data['slot_catalog']
        expression.validate(plan, core, controls, catalog, slots)
        if retrieval.get('catalog_sha256') != expression.digest(catalog):
            raise ValueError('pack catalog differs from authoritative source')
    return plan


def _record(pack, plan, decision, source_data):
    slot, cid, rid = (decision[key] for key in ('slot_id', 'candidate_id', 'realization_id'))
    if (not isinstance(slot, str) or slot not in plan['slots'] or plan['slots'][slot]['status'] != 'search'
            or not isinstance(cid, str) or not _CID.fullmatch(cid)
            or not isinstance(rid, str) or not rid or len(rid) > 200):
        raise ValueError('review requires a presented search role and exact CID/RID')
    try:
        view = pack['role_views'][slot]
        refs = view['candidate_refs']
        if not isinstance(refs, list): raise ValueError('invalid role references')
        matches = []
        for ref in refs:
            if ref.get('candidate_id') != cid:
                continue
            pid = ref['proposal_id']; proposal = pack['role_proposals'][pid]
            if (proposal.get('proposal_id') != pid or proposal.get('candidate_id') != cid
                    or proposal.get('target_slot_id') != slot):
                raise ValueError('foreign presented role proposal')
            if proposal.get('realization_id') == rid:
                matches.append(proposal)
        if len(matches) != 1: raise ValueError('decision does not name one presented CID/RID')
        record = pack['candidate_pool'][cid]['authored_record']
    except (KeyError, TypeError, AttributeError) as exc:
        raise ValueError('decision refers to a missing presented source') from exc
    actual_hash = expression.digest(record)
    if (record.get('id') != cid or rid not in realizations.ids(record)
            or decision['source_record_sha256'] != actual_hash
            or matches[0].get('source_record_sha256') != actual_hash):
        raise ValueError('goal review source identity, realization or full record changed')
    if source_data is not None:
        try:
            actual = source_data['candidates'][cid]
        except (KeyError, TypeError) as exc:
            raise ValueError('review source is absent from authoritative data') from exc
        if expression.digest(actual) != actual_hash:
            raise ValueError('public pack differs from authoritative full source')
        reader = source_data.get('_search_reader')
        if reader is not None and reader.meta['record_sha256'].get(cid) != actual_hash:
            raise ValueError('review source differs from pinned record hash')
    if decision['goal_sha256'] != expression.digest(plan['slots'][slot]):
        raise ValueError('goal review belongs to another authored slot row')
    return record, rid


def _decision(pack, plan, decision, source_data):
    if (not isinstance(decision, dict) or set(decision) != DECISION_FIELDS
            or decision.get('semantic_approval') is not False or decision.get('native_approval') is not False
            or not isinstance(decision.get('label'), str) or decision['label'] not in LABELS
            or not isinstance(decision.get('rationale'), str) or not decision['rationale'].strip()
            or len(decision['rationale']) > 6000):
        raise ValueError('explicit advisory goal-fit judgement required without native authority')
    record, rid = _record(pack, plan, decision, source_data)
    quotes = decision['source_quotes']
    if not isinstance(quotes, list) or len(quotes) > MAX_QUOTES:
        raise ValueError('bounded goal-review source quotes required')
    if decision['label'] == 'relevant' and not quotes:
        raise ValueError('a relevant goal decision requires positive source quotation')
    paths = semantic.primary_paths(record, rid)
    for quote in quotes:
        if (not isinstance(quote, dict) or set(quote) != {'pointer', 'quote'}
                or not isinstance(quote['pointer'], str) or quote['pointer'] not in paths
                or not isinstance(quote['quote'], str) or not quote['quote'].strip()
                or len(quote['quote']) > 12000):
            raise ValueError('goal review requires canonical positive source quotation')
        if quote['quote'] not in semantic.positive_string(record, quote['pointer'], realization_id=rid):
            raise ValueError('goal-review quote differs from the selected source realization')


def create(pack, decisions, source_data=None):
    """Seal caller-authored judgements separately; leave the original pack intact."""
    if not isinstance(decisions, list):
        raise ValueError('explicit goal-review decision list required')
    plan = _plan(pack, source_data)
    rows = copy.deepcopy(decisions)
    for row in rows:
        if not isinstance(row, dict) or set(row) not in (DECISION_INPUT_FIELDS, DECISION_FIELDS):
            raise ValueError('explicit goal-review decision fields required')
        row.setdefault('semantic_approval', False); row.setdefault('native_approval', False)
    review = {'schema': SCHEMA, 'author': 'Codex', 'pack_sha256': expression.digest(pack),
              'expression_plan_sha256': plan['canonical_sha256'], 'decisions': rows,
              'semantic_approval': False, 'native_approval': False}
    review['canonical_sha256'] = expression.digest(review)
    return validate(review, pack, source_data)


def validate(review, pack, source_data=None):
    plan = _plan(pack, source_data)
    if (not isinstance(review, dict) or set(review) != REVIEW_FIELDS or review.get('schema') != SCHEMA
            or review.get('author') != 'Codex' or review.get('semantic_approval') is not False
            or review.get('native_approval') is not False
            or review.get('pack_sha256') != expression.digest(pack)
            or review.get('expression_plan_sha256') != plan['canonical_sha256']
            or review.get('canonical_sha256') != expression.digest({k:v for k,v in review.items() if k != 'canonical_sha256'})):
        raise ValueError('foreign or modified advisory slot-goal review')
    if len(expression.canonical_bytes(review)) > MAX_REVIEW_BYTES:
        raise ValueError('goal review exceeds bounded record size')
    rows = review['decisions']
    if not isinstance(rows, list) or len(rows) > MAX_DECISIONS:
        raise ValueError('bounded explicit goal-review decisions required')
    seen = set()
    for row in rows:
        _decision(pack, plan, row, source_data)
        key = (row['slot_id'], row['candidate_id'], row['realization_id'])
        if key in seen: raise ValueError('duplicate slot/CID/RID goal judgement')
        seen.add(key)
    return review
