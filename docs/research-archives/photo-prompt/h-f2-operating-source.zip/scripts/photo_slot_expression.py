"""Neutral, candidate-free contract for authored post-freeze slot intentions.

``create(core, controls, catalog, rows, overall_intent)`` seals a v1 plan;
``validate(..., slots=...)`` additionally requires exact caller-selected slot
coverage. Hashes bind the *entire supplied snapshots*, including any existing
self-reported hashes. ``specification(catalog, slot=None)`` exposes only neutral
role specifications. ``source_span`` binds an exact quote to a permitted core
string with Python Unicode character offsets and a hash of the whole string.

Every row has the same explicit fields: status, reason, expressive_goal,
observable_targets, owner_relations, required_constraints, preserved_choices,
open_scope, unknowns, role_focus, scene_context, language, grounds, and review.
Search requires a goal, observable target, ground and authored role_focus.
Non-search rows have empty role_focus/scene_context and a reason. Unresolved
rows also name their unknowns. Review is ``author='Codex'`` plus a rationale.

Paraphrased goals and queries are intentional: no cue matching, automatic goal
generation, translation, or source-text equality is required. Structural and
hash validation certify neither semantic truth nor pre-retrieval timing. A
plan grants no native qualification, permission, hard obligation or adoption.
This module imports only the Python standard library and performs no IO.
"""
from __future__ import annotations

import copy
import hashlib
import json
import re

SCHEMA = 'photo-slot-expression-plan/v1'
STATUSES = frozenset({'search', 'not_applicable', 'unresolved'})
MAX_SLOTS = 149
MAX_PLAN_BYTES = 2 * 1024 * 1024
MAX_ROW_BYTES = 32768
MAX_GROUNDS = 12
MAX_LIST_ITEMS = 16
MAX_GROUND_CHARS = 12000
SPEC_FIELDS = frozenset({'id', 'description', 'description_ko', 'dimensions', 'applicability',
    'semantic_role', 'owners', 'property_prefixes', 'evidence_terms', 'includes', 'excludes',
    'neighbors', 'core_fields', 'priority'})
ROW_FIELDS = frozenset({'status', 'reason', 'expressive_goal', 'observable_targets',
    'owner_relations', 'required_constraints', 'preserved_choices', 'open_scope',
    'unknowns', 'role_focus', 'scene_context', 'language', 'grounds', 'review'})
PLAN_FIELDS = frozenset({'schema', 'core_sha256', 'controls_sha256', 'catalog_spec_sha256',
    'overall_intent', 'slots', 'semantic_approval', 'canonical_sha256'})
SPAN_FIELDS = frozenset({'source_pointer', 'start', 'end', 'quote', 'source_sha256'})
_HASH = re.compile(r'[0-9a-f]{64}\Z')
_CANDIDATE = re.compile(r'\b(?:cand|bind)_[A-Za-z0-9_]+\b|\brole_[0-9a-f]{16,}\b', re.I)
_METADATA_TEXT = re.compile(r'\b[0-9a-f]{32,64}\b|(?:https?|file|s3)://|(?:^|\s)(?:~?/|[A-Za-z]:\\)|\b[^\s/]+\.(?:png|jpe?g|webp|heic|json|pdf|yaml|yml)\b', re.I)
_CONTROL = re.compile(r'[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]')
_META_KEYS = frozenset({'id', 'ids', 'assertion_id', 'anchor_id', 'span_id', 'source_span_id',
    'source_span_ids', 'affected_dimensions', 'dimension', 'polarity', 'schema',
    'contract_version', 'canonical_sha256', 'source_sha256', 'hash', 'sha256',
    'provenance', 'sources', 'urls', 'url', 'path', 'file', 'filename', 'artifact',
    'source', 'kind', 'type', 'value_type', 'basis', 'resolution_reason'})
_TEXT_ROOTS = frozenset({'source_request', 'interpreted_intent', 'baseline_prompt_en',
    'subject', 'setting', 'event'})


def canonical_bytes(value):
    try:
        return json.dumps(value, ensure_ascii=False, sort_keys=True,
                          separators=(',', ':'), allow_nan=False).encode('utf-8')
    except (ValueError, TypeError, UnicodeError) as exc:
        raise ValueError('slot expression material must be finite JSON') from exc


def digest(value):
    return hashlib.sha256(canonical_bytes(value)).hexdigest()


def _text(value, name, maximum, *, required=False):
    if not isinstance(value, str) or len(value) > maximum or (required and not value.strip()):
        raise ValueError('invalid slot expression text: ' + name)
    if _CONTROL.search(value) or _CANDIDATE.search(value) or _METADATA_TEXT.search(value):
        raise ValueError('candidate, path, hash or metadata text is not an expression: ' + name)
    return value


def _json_pointer(pointer):
    if not isinstance(pointer, str) or not pointer.startswith('/') or re.search(r'~(?![01])', pointer):
        raise ValueError('canonical core JSON pointer required')
    keys = [key.replace('~1', '/').replace('~0', '~') for key in pointer[1:].split('/')]
    if any(not key or key in {'.', '..'} for key in keys):
        raise ValueError('invalid core JSON pointer')
    return keys


def _ground_path(keys):
    root = keys[0]
    if any(key in _META_KEYS or key.endswith(('_id', '_ids', '_sha256', '_path', '_url')) for key in keys):
        return False
    if root in _TEXT_ROOTS:
        return len(keys) == 1
    if root in {'visual_priorities', 'user_exclusions'}:
        return len(keys) == 2
    if root == 'style':
        return len(keys) >= 3 and keys[1] == 'evidence'
    if root == 'semantic_assertions':
        return len(keys) >= 4 and keys[2] in {'evidence', 'axes', 'relations'}
    if root == 'intent_lock':
        return len(keys) == 4 and keys[1] == 'semantic_anchors' and keys[3] in {'source_text', 'prompt_evidence'}
    if root == 'request_binding':
        return len(keys) == 4 and keys[1] == 'active_spans' and keys[3] == 'text'
    if root == 'user_definitions':
        return len(keys) == 3 and keys[2] in {'term', 'source_text', 'interpreted_meaning', 'prompt_evidence'}
    return False


def _source(core, pointer):
    keys = _json_pointer(pointer)
    if not _ground_path(keys):
        raise ValueError('ground pointer does not name semantic core source material')
    value = core
    try:
        for key in keys:
            if isinstance(value, list):
                if not key.isdigit() or str(int(key)) != key:
                    raise ValueError('canonical source array index required')
                value = value[int(key)]
            elif isinstance(value, dict):
                value = value[key]
            else:
                raise ValueError('ground pointer traverses a noncontainer')
    except (KeyError, IndexError, TypeError) as exc:
        raise ValueError('missing core source ground') from exc
    if not isinstance(value, str):
        raise ValueError('ground pointer must address a source string')
    return value


def source_span(core, pointer, start=0, end=None):
    """Bind a selected quote; this proves its origin, never its interpretation."""
    if not isinstance(core, dict):
        raise ValueError('frozen core mapping required')
    text = _source(core, pointer)
    end = len(text) if end is None else end
    if type(start) is not int or type(end) is not int or not 0 <= start < end <= len(text):
        raise ValueError('invalid core source span offsets')
    quote = _text(text[start:end], 'ground quote', MAX_GROUND_CHARS, required=True)
    return {'source_pointer': pointer, 'start': start, 'end': end, 'quote': quote,
            'source_sha256': hashlib.sha256(text.encode('utf-8')).hexdigest()}


def specification(catalog, slot=None):
    """Project neutral role definitions, omitting corpus/count/result metadata."""
    if not isinstance(catalog, dict) or not catalog or len(catalog) > MAX_SLOTS or any(not isinstance(name, str) for name in catalog):
        raise ValueError('bounded neutral slot catalog required')
    names = [slot] if slot is not None else sorted(catalog)
    result = {}
    for name in names:
        if not isinstance(name, str) or name not in catalog or not isinstance(catalog[name], dict):
            raise ValueError('unknown neutral slot specification')
        row = catalog[name]
        if row.get('id') != name or not SPEC_FIELDS <= set(row):
            raise ValueError('incomplete neutral slot specification: ' + name)
        neutral = {key: copy.deepcopy(row[key]) for key in sorted(SPEC_FIELDS)}
        # A spec must not smuggle candidate identities through an allowed field.
        if _CANDIDATE.search(canonical_bytes(neutral).decode('utf-8')):
            raise ValueError('candidate identity in neutral slot specification')
        result[name] = neutral
    return result[slot] if slot is not None else result


def _snapshots(core, controls, catalog):
    if not isinstance(core, dict) or not isinstance(controls, dict):
        raise ValueError('frozen core and controls mappings required')
    if any(not isinstance(value.get('canonical_sha256'), str) or not _HASH.fullmatch(value['canonical_sha256'])
           for value in (core, controls)):
        raise ValueError('slot expression authoring requires frozen core and controls')
    return {'core_sha256': digest(core), 'controls_sha256': digest(controls),
            'catalog_spec_sha256': digest(specification(catalog))}


def _row(row, core, slot):
    if not isinstance(row, dict) or set(row) != ROW_FIELDS or not isinstance(row.get('status'), str) or row['status'] not in STATUSES:
        raise ValueError('complete authored slot expression row required: ' + slot)
    if len(canonical_bytes(row)) > MAX_ROW_BYTES:
        raise ValueError('slot expression row exceeds its bounded budget')
    if not isinstance(row['language'], str) or row['language'] not in {'en', 'ko'}:
        raise ValueError('slot expression language must be en or ko')
    _text(row['reason'], 'reason', 2400, required=True)
    _text(row['expressive_goal'], 'expressive_goal', 2400)
    _text(row['role_focus'], 'role_focus', 3000)
    _text(row['scene_context'], 'scene_context', 800)
    for name in ('observable_targets', 'owner_relations', 'required_constraints',
                 'preserved_choices', 'open_scope', 'unknowns'):
        values = row[name]
        if not isinstance(values, list) or len(values) > MAX_LIST_ITEMS:
            raise ValueError('bounded authored expression list required: ' + name)
        for value in values:
            _text(value, name, 1600, required=True)
    grounds = row['grounds']
    if not isinstance(grounds, list) or len(grounds) > MAX_GROUNDS:
        raise ValueError('bounded source grounds required')
    for span in grounds:
        if not isinstance(span, dict) or set(span) != SPAN_FIELDS:
            raise ValueError('exact source span contract required')
        expected = source_span(core, span['source_pointer'], span['start'], span['end'])
        if span != expected:
            raise ValueError('authored expression ground differs from frozen source')
    review = row['review']
    if not isinstance(review, dict) or set(review) != {'author', 'rationale'} or review['author'] != 'Codex':
        raise ValueError('explicit Codex expression review required')
    _text(review['rationale'], 'review rationale', 3000, required=True)
    if row['status'] == 'search':
        if not row['expressive_goal'].strip() or not row['observable_targets'] or not grounds or not row['role_focus'].strip():
            raise ValueError('search requires an authored goal, observable target, ground and role_focus')
    elif row['role_focus'] != '' or row['scene_context'] != '':
        raise ValueError('non-search expression rows must have empty search text')
    if row['status'] == 'unresolved' and not row['unknowns']:
        raise ValueError('unresolved expression must name its unknowns')


def create(core, controls, catalog, rows, overall_intent):
    """Seal the author's exact text without interpreting or extending it."""
    value = {'schema': SCHEMA, **_snapshots(core, controls, catalog),
             'overall_intent': copy.deepcopy(overall_intent), 'slots': copy.deepcopy(rows),
             'semantic_approval': False}
    value['canonical_sha256'] = digest(value)
    return validate(value, core, controls, catalog)


def validate(plan, core, controls, catalog, slots=None):
    if (not isinstance(plan, dict) or set(plan) != PLAN_FIELDS or plan.get('schema') != SCHEMA
            or plan.get('semantic_approval') is not False):
        raise ValueError('authored slot expression plan v1 required without semantic approval')
    snapshots = _snapshots(core, controls, catalog)
    if any(plan[key] != value for key, value in snapshots.items()):
        raise ValueError('slot expression plan belongs to another core, controls or catalog')
    if plan['canonical_sha256'] != digest({key: value for key, value in plan.items() if key != 'canonical_sha256'}):
        raise ValueError('slot expression plan checksum mismatch')
    if len(canonical_bytes(plan)) > MAX_PLAN_BYTES:
        raise ValueError('slot expression plan exceeds its bounded budget')
    _text(plan['overall_intent'], 'overall_intent', 8000, required=True)
    rows = plan['slots']
    if not isinstance(rows, dict) or len(rows) > MAX_SLOTS or not set(rows) <= set(catalog):
        raise ValueError('slot expression rows must name declared neutral roles')
    if slots is not None:
        if not isinstance(slots, (list, tuple, set, frozenset)) or any(not isinstance(slot, str) for slot in slots):
            raise ValueError('explicit requested slot coverage required')
        if len(set(slots)) != len(slots) or set(rows) != set(slots):
            raise ValueError('slot expression plan does not exactly cover requested slots')
    for slot, row in rows.items():
        _row(row, core, slot)
    return plan
