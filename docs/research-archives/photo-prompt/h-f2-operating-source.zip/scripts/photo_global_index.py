"""Pure positive-document projection and offline full-scan vector qualification.

No filesystem index loader, writer, runtime cache, or query execution path.
"""
from __future__ import annotations
import hashlib, math
from pathlib import Path
import photo_candidate_corpus as corpus
import photo_canonical_source as canonical
from photo_embedding_provider import SPACE, validate_vector, validate_space, validate_execution, atomic
from bm25f_retrieval import build_bm25f_index

SCHEMA='photo-offline-vector-map/v1'
QUERY_RECIPE='photo-independent-slot-query/v4'
POLICY={'k1':1.2,'rrf_k':30,'candidate_limit':64,
 'query_fields':{'role_focus':3.0,'scene_context':0.5},
 'query_terms':{'recipe':'photo-bm25f-query-terms/v1','tf_cap':1.0,'english_grammar_weight':0.1},
 'fields':{k:{'weight':w,'b':0.75} for k,w in {'aliases':4,'labels':3,'definition':2,'paraphrases':2,
 'semantic_relations':2,'concept_units':2,'manifestations':1,'keywords':1,'semantic_caption':1}.items()}}

def strings(v):
    if isinstance(v,str):return [v] if v.strip() else []
    if isinstance(v,list):return [x for x in v if isinstance(x,str) and x.strip()]
    return []

def fields(record):
    return canonical.document(record)['fields']

def text(record):
    result=canonical.document(record)
    return result['recipe'],result['text']

def fields_for(data,record):return fields(record)
def text_for(data,record):return text(record)

def documents(data):return {cid:fields(r) for cid,r in data['candidates'].items() if canonical.positive(r)}

def policy_for(data):
    import copy
    policy=copy.deepcopy(POLICY)
    policy['fields'].update({name:{'weight':weight,'b':.75,'normalization_population':'nonempty_documents'}
        for name,weight in {'core_meaning':2,'source_requirements':2,'applicability':1,'discovery_hints':1}.items()})
    return policy

def lexical(data):
    docs=documents(data)
    lexicon=sorted({v for f in docs.values() for name in ('aliases','labels','paraphrases','keywords','discovery_hints') for v in f.get(name) or []})
    return build_bm25f_index(docs,policy=policy_for(data),lexicon=lexicon)

def validate(index,c):
    expected={cid:r for cid,r in c['candidates'].items() if canonical.positive(r)}
    validate_space(index.get('space'))
    if index.get('schema')!=SCHEMA or index.get('corpus_sha256')!=corpus.digest(c):
        raise ValueError('native shared index schema/space/source mismatch')
    if set(index.get('entries',{}))!=set(expected):raise ValueError('native shared index coverage mismatch')
    for cid,record in expected.items():
        row=index['entries'][cid];recipe,body=text_for(c,record)
        if row.get('id')!=cid or row.get('text')!=body or row.get('recipe')!=recipe or row.get('text_sha256')!=hashlib.sha256(body.encode()).hexdigest():
            raise ValueError('native shared index identity/text/recipe mismatch: '+cid)
        validate_vector(row.get('vector'),SPACE['dimensions'])
        if index['space']['provider']=='embeddinggemma2-local':
            validate_execution(row.get('embedding_execution') or {},index['space'],body,row['vector'],'document')
    return index

def cosine_rank(index, vector, allowed_ids=None, limit=384, minimum_similarity=0.30):
    """Exact cosine over the entire allowed shared corpus, no role selection."""
    validate_vector(vector,index['space']['dimensions'])
    ids=sorted(index['entries']) if allowed_ids is None else sorted(set(allowed_ids))
    if not set(ids)<=set(index['entries']):raise ValueError('cosine search has unknown candidate identity')
    if not ids:return []
    query_norm=math.sqrt(math.sumprod(vector,vector))
    scores=[]
    for cid in ids:
        values=index['entries'][cid]['vector']
        scores.append(math.sumprod(values,vector)/(math.sqrt(math.sumprod(values,values))*query_norm))
    ranked=sorted(((cid,float(score)) for cid,score in zip(ids,scores) if score>=minimum_similarity),key=lambda row:(-row[1],row[0]))
    return [{'document_id':cid,'score':round(score,9)} for cid,score in ranked[:limit]]
