"""Conservative shared unary/directed-fact support; never a fit/authority label."""
POLICY='common-meaning-v1'
GENERIC={'person':'person','place':'place','object':'object','task':'action','surface_texture':'feature'}
INVERSE={'above':'below','below':'above'}
OPPOSITES={frozenset(p) for p in [('left','right'),('above','below'),('glossy','matte'),('open','closed'),('front','behind')]}

def correspondence(source,target):
    if source['type']!=target['type']:return False
    if source['concept']!=target['concept'] and GENERIC.get(source['concept'])!=source['type']:return False
    return source['count'] is None or target['count'] is None or source['count']==target['count']
def predicates(source,target):
    return source==target or (source=='grips' and target=='contacts')
def qualifiers(source,target):
    # Missing target detail remains unknown, not an invented entailment.
    if any(k in target and target[k]!=v for k,v in source.items()):return False
    return all(k in target for k in source)
def compare(view,intent,maximum_mappings=4096):
    empty={'state':'unstructured','matched_source_claims':[],'matched_intent_claims':[],
        'unmatched_source_claims':[],'mapping':{},'complete_search':True,'source_coverage':None,
        'focus_coverage':0,'explicit_conflicts':[],'whole_source_fit':'requires_direct_review',
        'native_approval':False,'semantic_approval':False}
    if view is None:return empty
    source=view['meaning'];target=intent['meaning'];se={r['id']:r for r in source['entities']};te={r['id']:r for r in target['entities']}
    choices={sid:[tid for tid,t in te.items() if correspondence(s,t)] for sid,s in se.items()}
    # More discriminating entities first; no CID, cache, gold, or tag input.
    order=sorted(se,key=lambda sid:(len(choices[sid]),se[sid]['concept'],sid));focus=set(intent['focus_fact_ids'])
    visited=0;exhausted=False;best=None
    def evaluate(mapping):
        matches=[];targets=[];conflicts=[]
        for fact in source['facts']:
            subject=mapping.get(fact['subject']);obj=mapping.get(fact['object']) if fact['object'] else None
            if subject is None or (fact['object'] and obj is None):continue
            for goal in target['facts']:
                forward=subject==goal['subject'] and obj==goal['object']
                reverse=fact['object'] and subject==goal['object'] and obj==goal['subject'] and INVERSE.get(fact['predicate'])==goal['predicate']
                if subject==goal['subject'] and fact['predicate'] in {'part_of','owned_by'} and fact['predicate']==goal['predicate'] and obj!=goal['object']:
                    conflicts.append({'source':fact['id'],'intent':goal['id'],'axis':'owner'})
                if not forward and not reverse:continue
                same=(reverse or predicates(fact['predicate'],goal['predicate']))
                if same and fact['value']==goal['value'] and qualifiers(fact['qualifiers'],goal['qualifiers']):
                    matches.append(fact['id']);targets.append(goal['id']);break
                if forward and fact['predicate']==goal['predicate']:
                    if frozenset((fact['value'],goal['value'])) in OPPOSITES:conflicts.append({'source':fact['id'],'intent':goal['id'],'axis':'state'})
                    for k in set(fact['qualifiers'])&set(goal['qualifiers']):
                        if frozenset((fact['qualifiers'][k],goal['qualifiers'][k])) in OPPOSITES:conflicts.append({'source':fact['id'],'intent':goal['id'],'axis':k})
                if forward and INVERSE.get(fact['predicate'])==goal['predicate']:
                    conflicts.append({'source':fact['id'],'intent':goal['id'],'axis':'direction'})
        return list(dict.fromkeys(matches)),sorted(set(targets)),conflicts
    def walk(pos,mapping,used):
        nonlocal visited,exhausted,best
        if visited>=maximum_mappings:exhausted=True;return
        if pos==len(order):
            visited+=1;matches,targets,conflicts=evaluate(mapping)
            value=(len(set(targets)&focus),len(matches),len(mapping),-len(conflicts))
            if best is None or value>best[0]:best=(value,dict(mapping),matches,targets,conflicts)
            return
        sid=order[pos]
        for tid in choices[sid]:
            if tid not in used:
                mapping[sid]=tid;walk(pos+1,mapping,used|{tid});mapping.pop(sid)
        walk(pos+1,mapping,used)
    walk(0,{},set())
    _,mapping,matches,targets,conflicts=best;matched=set(matches)
    required=[g for g in source['requirements'] if g['mode']!='optional']
    groups=[{'mode':g['mode'],'fact_ids':g['fact_ids'],'supported':(set(g['fact_ids'])<=matched if g['mode']=='all' else bool(set(g['fact_ids'])&matched))} for g in required]
    return {**empty,'state':'explicit_conflict' if conflicts else 'grounded_support' if matches else 'unknown_correspondence',
        'matched_source_claims':matches,'matched_intent_claims':targets,
        'unmatched_source_claims':[f['id'] for f in source['facts'] if f['id'] not in matched],
        'mapping':mapping,'complete_search':not exhausted,'source_coverage':len(matches)/max(1,len(source['facts'])),
        'focus_coverage':len(set(targets)&focus)/max(1,len(focus)),'explicit_conflicts':conflicts,
        'required_groups':groups,'all_structured_requirements_supported':all(g['supported'] for g in groups),
        'unresolved_units':len(view['review']['unresolved_units'])}
def score(base,view,intent):
    result=compare(view,intent);out=dict(base)
    delta=.35*result['focus_coverage'] if result['complete_search'] and not result['explicit_conflicts'] else 0
    out.update(score=round(base['score']+delta,12),meaning_comparison=result,
        meaning_view_sha256=view['canonical_sha256'] if view else None,
        common_meaning_adjustment=delta,discovery_score=base['score'])
    return out
