#!/usr/bin/env python3
"""Audit an agent-composed photo prompt against a candidate pack."""

from __future__ import annotations
import photo_canonical_source as canonical
import photo_native_pack
import photo_shared_views
import audit_global_retrieval as global_audit

import argparse
import contextlib
import contextvars
import copy
import hashlib
import json
import re
import sys
from pathlib import Path
from typing import Any, Sequence


_SCRIPTS_IMPORT_DIR = str(Path(__file__).resolve().parent)
_SCRIPTS_IMPORT_DIR_ADDED = _SCRIPTS_IMPORT_DIR not in sys.path
if _SCRIPTS_IMPORT_DIR_ADDED:
    sys.path.insert(0, _SCRIPTS_IMPORT_DIR)
try:
    import photo_candidate_context
    import photo_candidate_semantics
    import photo_contextual_appeal
    import photo_embodiment
    import photo_creative_controls as creative_controls
    import prompt_generator as candidate_semantics_generator
    from photo_contracts import (
        ADULT_APPEAL_AXIS_DIMENSIONS,
        ADULT_APPEAL_DIMENSION_SCOPE_CONTRACT_VERSION,
        AUTHORIAL_AUTHORSHIP_POLICY_CONTRACT_VERSION,
        AUTHORIAL_CORE_BINDING_CONTRACT_VERSION,
        AUTHORIAL_CORE_CONTRACT_VERSION,
        AUTHORIAL_CORE_MODERN_CONTRACT_VERSIONS,
        AUTHORIAL_CORE_V3_CONTRACT_VERSION,
        AUTHORIAL_CORE_V3_INTENT_LOCK_DIMENSIONS,
        AUTHORIAL_IDENTITY_PRESERVATION_NEGATIVE_TERMS,
        AUTHORIAL_INTENT_NEUTRAL_NEGATIVE_TERMS,
        AUTHORIAL_PROMPT_ABSOLUTE_MAX_WORDS,
        AUTHORIAL_PROMPT_BUDGET_CONTRACT_VERSION,
        AUTHORIAL_PROMPT_MIN_WORDS,
        AUTHORIAL_PROMPT_RECOMMENDED_MAX_WORDS,
        AUTHORIAL_PROMPT_REQUIRED_EVIDENCE_HEADROOM_WORDS,
        CHARACTER_RESPONSE_CONTRACT_VERSION,
        CHARACTER_RESPONSE_RELATION_MEMBERS,
        CHARACTER_RESPONSE_REQUIRED_AXES,
        CHARACTER_RESPONSE_REQUIRED_EVIDENCE,
        DOWNSTREAM_INTENT_PRECEDENCE_CONTRACT_VERSION,
        INTENT_LOCK_CONTRACT_VERSION,
        INTENT_LOCK_PROPERTY_CONTRACT_VERSION,
        intent_property_locks,
        authored_subject_category,
        property_effects_allowed,
        INTENT_LOCK_DIMENSIONS,
        INTENT_PRESERVATION_CONTRACT_VERSION,
        NEGATIVE_INTENT_GUARD_CONTRACT_VERSION,
        RENDER_REPAIR_ALLOWED_AXES,
        RENDER_REPAIR_CONTACT_EXPECTATIONS,
        RENDER_REPAIR_CONTRACT_VERSION,
        RENDER_REPAIR_DIMENSION_AXES,
        RENDER_REPAIR_IMPORTANCE_VALUES,
        RENDER_REPAIR_INTERACTION_STATES,
        RENDER_REPAIR_RELATION_ORIGINS,
        REQUEST_BINDING_CONTRACT_VERSION,
        REQUEST_ENVELOPE_CONTRACT_VERSION,
        REQUEST_LINEAGE_V2_CONTRACT_VERSION,
        REQUIRED_INTENT_LOCK_DIMENSIONS,
        SEMANTIC_ASSERTION_OBLIGATIONS_CONTRACT_VERSION,
        canonical_json_sha256,
    )
finally:
    if _SCRIPTS_IMPORT_DIR_ADDED:
        sys.path.remove(_SCRIPTS_IMPORT_DIR)


SUPPORTED_CANDIDATE_PACK_VERSIONS = {"photo-candidate-pack/v10"}
MOE_PROMPT_DEFAULT_RECOMMENDED_MIN_WORDS = 100
MOE_PROMPT_DEFAULT_RECOMMENDED_MAX_WORDS = 240
VISUAL_OBLIGATIONS_CONTRACT_VERSION = "photo-visual-obligations/v1"
VISUAL_INTENT_CONTRACT_VERSION = "photo-visual-intent/v1"
VISUAL_CONCEPTS_CONTRACT_VERSION = "photo-visual-concepts/v1"
MOE_RESPONSE_EVIDENCE_DIMENSIONS = {
    "actor_phrase": "subject",
    "aesthetic_baseline_phrase": "style",
    "affective_leak_phrase": "expression",
    "active_denial_phrase": "expression",
    "care_action_anchor_phrase": "relationship",
    "relationship_gaze_anchor_phrase": "relationship",
    "concealed_affection_phrase": "expression",
    "benevolent_affect_phrase": "expression",
    "baseline_phrase": "role",
    "event_phase_phrase": "event",
    "trigger_phrase": "event",
    "target_phrase": "event",
    "visible_response_phrase": "expression",
    "immediate_consequence_phrase": "event",
    "continuity_phrase": "event",
    "background_control_phrase": "setting",
    "focal_plane_phrase": "composition",
    "reference_identity_phrase": "identity",
}
MOE_RESPONSE_DEFAULT_RULE_DIMENSIONS = {
    "aesthetic_style_default": ("style",),
    "aesthetic_expression_default": ("expression",),
    "affective_balance_default": ("expression",),
    "generic_character_response_mechanism": (
        "event",
        "expression",
        "pose",
        "relationship",
    ),
    "generic_relationship_register": ("relationship", "expression"),
    "default_sensual_support": ("sexual_tone", "style", "composition"),
    "generic_expression_negative_suppression": ("expression",),
    "generic_style_negative_suppression": ("style",),
    "generic_appearance_negative_suppression": ("appearance",),
    "generic_text_negative_suppression": ("text",),
}
ADULT_APPEAL_DEFAULT_AFFECTED_DIMENSIONS = {
    "sexual_tone",
    "style",
    "composition",
    "expression",
    "pose",
    "body_geometry",
    "framing",
    "lighting",
}
MOE_WARM_AFFECT_GROUPS = (
    ("softened eye", "soft eyes", "eyes soften", "gentle eye", "warm eye"),
    (
        "lower lids soften",
        "softened lower lids",
        "lower eyelids soften",
        "softened lower eyelids",
    ),
    (
        "almost-smile",
        "almost smile",
        "near-smile",
        "near smile",
        "smile threatens",
        "smile starts",
    ),
    (
        "mouth corner lifts",
        "lifted mouth corner",
        "pleased mouth corner",
        "relieved mouth corner",
    ),
    ("mouth corner starts to lift", "mouth corner begins to lift"),
    ("fond", "fondness", "pleased", "relieved", "tender", "warmth"),
    (
        "playful embarrassment",
        "playfully embarrassed",
        "bashful delight",
        "private delight",
    ),
)
MOE_NEGATIVE_AFFECT_CUES = (
    "annoyed",
    "angry",
    "averted gaze",
    "bored",
    "cold stare",
    "frown",
    "irritated",
    "listless",
    "pout",
    "pursed",
    "sad",
    "scowl",
    "skeptical",
    "sullen",
)
MOE_WARM_EXPRESSION_DEFAULT_MARKERS = (
    "softened eye",
    "soft eyes",
    "eyes soften",
    "gentle eye",
    "warm eye",
    "lower lids soften",
    "softened lower lids",
    "lower eyelids soften",
    "softened lower eyelids",
    "almost-smile",
    "almost smile",
    "near-smile",
    "near smile",
    "smile threatens",
    "smile starts",
    "mouth corner lifts",
    "lifted mouth corner",
    "pleased mouth corner",
    "relieved mouth corner",
    "mouth corner starts to lift",
    "mouth corner begins to lift",
    "fondness",
    "playful embarrassment",
    "playfully embarrassed",
    "bashful delight",
    "private delight",
)
MOE_NEGATIVE_DEFAULT_TERMS_BY_RULE = {
    "generic_expression_negative_suppression": (
        "blank bored expression",
        "listless expression",
        "pure scowl without a warm micro-expression",
    ),
    "generic_style_negative_suppression": (
        "generic sparkle overlays",
        "decorative blush circles",
        "unrequested heart symbols",
        "heart-shaped pupils",
        "heart-shaped latte art",
        "cartoon motion lines",
        "manga reaction marks",
        "comic emphasis marks",
    ),
    "generic_appearance_negative_suppression": ("oversized anime eyes",),
    "generic_text_negative_suppression": (
        "readable background text",
        "pseudo-writing",
        "menu board lettering",
        "chalkboard writing",
        "signage behind the subject",
    ),
}
SEMANTIC_CLARIFICATION_CONTRACT_VERSION = "photo-semantic-clarification/v2"
CREATIVE_AUGMENTATION_CONTRACT_VERSION = "photo-creative-augmentation/v1"


def load_json_arg(raw: str) -> Any:
    raw = raw.strip()
    if raw.startswith("{") or raw.startswith("["):
        return json.loads(raw)
    return json.loads(Path(raw).read_text(encoding="utf-8"))


def first_pack(payload: Any) -> dict[str, Any]:
    if isinstance(payload, list):
        if len(payload) != 1:
            raise ValueError("candidate pack list must contain exactly one pack")
        payload = payload[0]
    if not isinstance(payload, dict):
        raise ValueError("candidate pack must be a JSON object or a non-empty list")
    return payload


def composed_object(payload: Any) -> dict[str, Any]:
    if not isinstance(payload, dict):
        raise ValueError("composed prompt must be a JSON object")
    return payload


def clean_prompt_spaces(text: str) -> str:
    value = re.sub(r"\s+", " ", str(text or "")).strip()
    return re.sub(r"\s+([,.!?;:])", r"\1", value)


def normalize_negative_intent_term(text: str) -> str:
    return clean_prompt_spaces(text).strip(" .;:!?\"'").casefold()


def strip_negative_directive_prefix(text: str) -> str:
    normalized = normalize_negative_intent_term(text)
    return re.sub(
        r"^(?:no|without|avoid|exclude|excluding|do\s+not|don't|never)\s+",
        "",
        normalized,
        count=1,
    ).strip()


def negative_term_matches_requester_exclusion(
    term: str,
    exclusions: Sequence[str],
) -> bool:
    term_key = strip_negative_directive_prefix(term)
    if not term_key:
        return False
    for exclusion in exclusions:
        exclusion_key = strip_negative_directive_prefix(str(exclusion))
        if exclusion_key and term_key == exclusion_key:
            return True
    return False


def authorial_negative_term_allowed(
    term: str,
    core: dict[str, Any],
    *,
    identity_preservation_enabled: bool,
) -> bool:
    key = normalize_negative_intent_term(term)
    if key in AUTHORIAL_INTENT_NEUTRAL_NEGATIVE_TERMS:
        return True
    if (
        identity_preservation_enabled
        and key in AUTHORIAL_IDENTITY_PRESERVATION_NEGATIVE_TERMS
    ):
        return True
    return negative_term_matches_requester_exclusion(
        key,
        [str(item) for item in core.get("user_exclusions") or []],
    )


def split_negative_prompt_terms(value: Any) -> list[str]:
    if value is None:
        return []
    return [
        clean_prompt_spaces(part)
        for part in str(value).split(",")
        if clean_prompt_spaces(part)
    ]


def find_blanket_negative_directives(text: str) -> list[str]:
    value = str(text or "")
    patterns = (
        re.compile(
            r"(?:^|[.;!?:—]\s+|,\s+)((?:no\b|do\s+not\b|don't\b|avoid\b|exclude\b)[^.;!?]*)",
            flags=re.IGNORECASE,
        ),
        re.compile(
            r"(?:^|[.;!?:—]\s+|,\s+)(never\s+(?:touch(?:es|ed|ing)?|inject(?:s|ed|ing)?|contact(?:s|ed|ing)?|show(?:s|ed|ing)?|depict(?:s|ed|ing)?|include(?:s|d|ing)?|use(?:s|d|ing)?|reveal(?:s|ed|ing)?|sexualiz(?:e|es|ed|ing)|crop(?:s|ped|ping)?|add(?:s|ed|ing)?)\b[^.;!?]*)",
            flags=re.IGNORECASE,
        ),
    )
    directives: list[str] = []
    seen: set[str] = set()
    for pattern in patterns:
        for match in pattern.finditer(value):
            directive = clean_prompt_spaces(match.group(1))
            key = directive.casefold()
            if directive and key not in seen:
                directives.append(directive)
                seen.add(key)
    return directives


def expected_negative_intent_guard(pack: dict[str, Any]) -> dict[str, Any] | None:
    pack = photo_native_pack.read_view(pack)
    core = pack.get("authorial_core") if isinstance(pack.get("authorial_core"), dict) else {}
    if core.get("contract_version") not in AUTHORIAL_CORE_MODERN_CONTRACT_VERSIONS:
        return None
    provenance = (
        pack.get("provenance")
        if isinstance(pack.get("provenance"), dict)
        else {}
    )
    identity_preservation_enabled = (
        str(provenance.get("reference_edit_mode") or "off") == "identity"
    )
    guard: dict[str, Any] = {
        "contract_version": NEGATIVE_INTENT_GUARD_CONTRACT_VERSION,
        "source_authorial_core_sha256": str(core.get("canonical_sha256") or ""),
        "source_intent_lock_sha256": str(
            ((core.get("intent_lock") or {}).get("canonical_sha256") or "")
        ),
        "positive_prompt_policy": "positive_description_only_no_blanket_negative_directives",
        "automatic_negative_policy": "intent_neutral_photographic_defects_only",
        "requester_exclusion_policy": "exact_active_request_scope_only",
        "platform_safety_policy": "enforce_outside_prompt_unless_requester_explicit",
        "local_boundary_policy": "positive_geometry_or_visible_state",
        "identity_preservation_enabled": identity_preservation_enabled,
        "explicit_user_exclusions": [
            str(item) for item in core.get("user_exclusions") or []
        ],
        "emitted_terms": split_negative_prompt_terms(pack.get("negative_en")),
    }
    guard["canonical_sha256"] = canonical_json_sha256(guard)
    guard["guard_id"] = str(guard["canonical_sha256"])[:16]
    return guard


def audit_negative_intent_guard(
    pack: dict[str, Any],
    prompt_en: str,
) -> list[dict[str, Any]]:
    pack = photo_native_pack.read_view(pack)
    expected = expected_negative_intent_guard(pack)
    if expected is None:
        return []
    failures: list[dict[str, Any]] = []
    actual = (
        pack.get("negative_intent_guard")
        if isinstance(pack.get("negative_intent_guard"), dict)
        else None
    )
    if actual != expected:
        failures.append(
            {
                "check": "negative_intent_guard_contract",
                "reason": (
                    "v9 pack must expose the exact recomputable requester-first negative-intent boundary"
                ),
                "expected": expected,
                "actual": actual,
            }
        )

    core = pack.get("authorial_core") if isinstance(pack.get("authorial_core"), dict) else {}
    identity_enabled = bool(expected["identity_preservation_enabled"])
    terms = split_negative_prompt_terms(pack.get("negative_en"))
    disallowed_terms = [
        term
        for term in terms
        if not authorial_negative_term_allowed(
            term,
            core,
            identity_preservation_enabled=identity_enabled,
        )
    ]
    if disallowed_terms:
        failures.append(
            {
                "check": "negative_intent_guard_terms",
                "reason": (
                    "automatic negative_en contains semantic suppression that is neither a requester exclusion, an intent-neutral photographic defect, nor an enabled identity-preservation control"
                ),
                "terms": disallowed_terms,
            }
        )
    normalized_terms = [normalize_negative_intent_term(term) for term in terms]
    if len(normalized_terms) != len(set(normalized_terms)):
        failures.append(
            {
                "check": "negative_intent_guard_terms",
                "reason": "negative_en contains duplicate normalized terms",
            }
        )

    baseline_directives = find_blanket_negative_directives(
        str(core.get("baseline_prompt_en") or "")
    )
    if baseline_directives:
        failures.append(
            {
                "check": "negative_intent_guard_baseline",
                "reason": (
                    "baseline_prompt_en embeds blanket negative directives instead of positive visual realization"
                ),
                "directives": baseline_directives,
            }
        )
    prompt_directives = find_blanket_negative_directives(prompt_en)
    if prompt_directives:
        failures.append(
            {
                "check": "negative_intent_guard_prompt",
                "reason": (
                    "prompt_en embeds blanket negative directives; use positive local geometry or visible state and keep platform enforcement outside prompt prose"
                ),
                "directives": prompt_directives,
            }
        )
    return failures


def text_contains_term(text: str, term: str) -> bool:
    term = str(term or "").strip()
    if not term:
        return False
    lowered = text.lower()
    term_lower = term.lower()
    if term_lower.isascii() and re.search(r"[A-Za-z0-9]", term_lower):
        pattern = r"(?<![A-Za-z0-9])" + re.escape(term_lower) + r"(?![A-Za-z0-9])"
        return re.search(pattern, lowered) is not None
    return term_lower in lowered


def expected_authorial_prompt_budget_contract() -> dict[str, Any]:
    return {
        "contract_version": AUTHORIAL_PROMPT_BUDGET_CONTRACT_VERSION,
        "language": "en",
        "minimum_words": AUTHORIAL_PROMPT_MIN_WORDS,
        "recommended_maximum_words": AUTHORIAL_PROMPT_RECOMMENDED_MAX_WORDS,
        "absolute_maximum_words": AUTHORIAL_PROMPT_ABSOLUTE_MAX_WORDS,
        "required_evidence_headroom_words": AUTHORIAL_PROMPT_REQUIRED_EVIDENCE_HEADROOM_WORDS,
        "counting_rule": "ascii_words_with_internal_hyphens_or_apostrophes",
        "policy": {
            "recommended_maximum_is_warning": True,
            "absolute_bounds_are_blocking": True,
            "required_evidence_expands_advisory_ceiling": True,
            "requester_meaning_outranks_concision": True,
            "scene_coherence_outranks_concision": True,
        },
    }


def nested_prompt_evidence_strings(value: Any) -> list[str]:
    if isinstance(value, str):
        text = value.strip()
        return [text] if text else []
    if isinstance(value, dict):
        return [
            phrase
            for nested in value.values()
            for phrase in nested_prompt_evidence_strings(nested)
        ]
    if isinstance(value, list):
        return [
            phrase
            for nested in value
            for phrase in nested_prompt_evidence_strings(nested)
        ]
    return []


def authorial_required_prompt_evidence(
    pack: dict[str, Any],
    composed: dict[str, Any],
    *,
    baseline_only: bool = False,
) -> list[str]:
    """Collect literal hard-evidence phrases without treating optional ideas as duties."""
    pack = photo_native_pack.read_view(pack)

    phrases: list[str] = []
    core = pack.get("authorial_core") if isinstance(pack.get("authorial_core"), dict) else {}
    intent_lock = (
        core.get("intent_lock") if isinstance(core.get("intent_lock"), dict) else {}
    )
    phrases.extend(
        str(anchor.get("prompt_evidence") or "").strip()
        for anchor in intent_lock.get("semantic_anchors") or []
        if isinstance(anchor, dict) and str(anchor.get("prompt_evidence") or "").strip()
    )
    phrases.extend(
        str(definition.get("prompt_evidence") or "").strip()
        for definition in core.get("user_definitions") or []
        if isinstance(definition, dict)
        and str(definition.get("prompt_evidence") or "").strip()
    )
    for assertion in core.get("semantic_assertions") or []:
        if not isinstance(assertion, dict) or assertion.get("polarity") != "required":
            continue
        phrases.extend(nested_prompt_evidence_strings(assertion.get("evidence")))

    if not baseline_only:
        binding = (
            composed.get("authorial_core_binding")
            if isinstance(composed.get("authorial_core_binding"), dict)
            else {}
        )
        phrases.extend(nested_prompt_evidence_strings(binding.get("preserved_evidence")))
        for field, evidence_field in (
            ("character_response", "evidence"),
            ("semantic_assertion_evidence", "evidence"),
            ("viewer_experience", "prompt_evidence"),
        ):
            payload = composed.get(field) if isinstance(composed.get(field), dict) else {}
            phrases.extend(nested_prompt_evidence_strings(payload.get(evidence_field)))
        phrases.extend(
            nested_prompt_evidence_strings(composed.get("visual_obligation_evidence"))
        )
        phrases.extend(nested_prompt_evidence_strings(composed.get("coverage_assertions")))
        manual_gate_evidence = (
            composed.get("manual_gate_evidence")
            if isinstance(composed.get("manual_gate_evidence"), dict)
            else {}
        )
        for evidence in manual_gate_evidence.values():
            if isinstance(evidence, dict):
                phrases.extend(
                    nested_prompt_evidence_strings(evidence.get("evidence_phrases"))
                )

    deduped: list[str] = []
    seen: set[str] = set()
    for phrase in phrases:
        key = phrase.casefold()
        if not phrase or key in seen:
            continue
        seen.add(key)
        deduped.append(phrase)
    return deduped


def authorial_prompt_budget_metrics(
    pack: dict[str, Any],
    composed: dict[str, Any],
    prompt_en: str,
    *,
    baseline_only: bool = False,
    budget_contract: dict[str, Any] | None = None,
) -> dict[str, int]:
    pack = photo_native_pack.read_view(pack)
    active_budget = budget_contract or expected_authorial_prompt_budget_contract()
    recommended_maximum_words = int(active_budget["recommended_maximum_words"])
    absolute_maximum_words = int(active_budget["absolute_maximum_words"])
    required_evidence_headroom_words = int(
        active_budget["required_evidence_headroom_words"]
    )
    word_matches = list(
        re.finditer(r"[A-Za-z0-9]+(?:['’\-][A-Za-z0-9]+)*", str(prompt_en or ""))
    )
    covered_word_indexes: set[int] = set()
    phrases = authorial_required_prompt_evidence(
        pack,
        composed,
        baseline_only=baseline_only,
    )
    for phrase in phrases:
        match = re.search(re.escape(phrase), prompt_en, flags=re.IGNORECASE)
        if match is None:
            continue
        covered_word_indexes.update(
            index
            for index, word in enumerate(word_matches)
            if word.start() >= match.start() and word.end() <= match.end()
        )
    actual_words = len(word_matches)
    required_evidence_words = len(covered_word_indexes)
    effective_recommended_maximum_words = min(
        absolute_maximum_words,
        max(
            recommended_maximum_words,
            required_evidence_words + required_evidence_headroom_words,
        ),
    )
    return {
        "actual_words": actual_words,
        "required_evidence_words": required_evidence_words,
        "optional_prose_words": actual_words - required_evidence_words,
        "effective_recommended_maximum_words": effective_recommended_maximum_words,
    }


AUTHORIAL_EVIDENCE_STOPWORDS = {
    "a",
    "an",
    "and",
    "as",
    "at",
    "by",
    "for",
    "from",
    "in",
    "into",
    "is",
    "of",
    "on",
    "or",
    "the",
    "to",
    "with",
    "without",
}


def authorial_evidence_tokens(text: str) -> set[str]:
    return {
        token.lower()
        for token in re.findall(r"[A-Za-z0-9]+(?:[./'’\-][A-Za-z0-9]+)*", str(text or ""))
        if token.lower() not in AUTHORIAL_EVIDENCE_STOPWORDS
    }


def authorial_general_content_words(text: str) -> list[str]:
    return re.findall(
        r"[A-Za-z0-9][A-Za-z0-9_-]*|[가-힣]{2,}|[ぁ-んァ-ン一-龯]{2,}",
        str(text or ""),
    )


def normalize_chosen_candidate_ids(raw: Any) -> set[str]:
    chosen: set[str] = set()
    if raw is None:
        return chosen
    if isinstance(raw, str):
        return {raw}
    if isinstance(raw, list):
        for item in raw:
            if isinstance(item, str):
                chosen.add(item)
            elif isinstance(item, dict) and item.get("id"):
                chosen.add(str(item["id"]))
        return chosen
    if isinstance(raw, dict):
        for value in raw.values():
            chosen.update(normalize_chosen_candidate_ids(value))
    return chosen


def composed_search_text(composed: dict[str, Any]) -> str:
    return str(composed.get("prompt_en") or "")


def computed_pack_id(pack: dict[str, Any]) -> str:
    pack = photo_native_pack.read_view(pack)
    hashable = dict(pack)
    hashable["pack_id"] = None
    payload = json.dumps(hashable, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()[:16]


def assertion_values(raw: Any) -> list[str]:
    if isinstance(raw, str):
        return [raw] if raw.strip() else []
    if isinstance(raw, list):
        return [str(item) for item in raw if str(item).strip()]
    if isinstance(raw, dict):
        return [str(item) for item in raw.values() if str(item).strip()]
    return []


def candidate_ids_from_pack(pack: dict[str, Any]) -> set[str]:
    pack = photo_native_pack.read_view(pack)
    ids: set[str] = set(pack["candidate_pool"])
    slots = photo_native_pack.role_cards(pack) or {}
    if isinstance(slots, dict):
        slot_values = slots.values()
    else:
        slot_values = slots
    for slot_payload in slot_values:
        if not isinstance(slot_payload, dict):
            continue
        for candidate in slot_payload.get("candidates") or []:
            if isinstance(candidate, dict) and candidate.get("id"):
                ids.add(str(candidate["id"]))
    proposition = pack.get("visual_proposition")
    if isinstance(proposition, dict):
        for key in ("core_candidates", "tension_candidates"):
            for candidate in proposition.get(key) or []:
                if isinstance(candidate, dict) and candidate.get("id"):
                    ids.add(str(candidate["id"]))
    integration = pack.get("photographic_integration")
    if isinstance(integration, dict):
        for candidate in integration.get("category_candidates") or []:
            if isinstance(candidate, dict) and candidate.get("id"):
                ids.add(str(candidate["id"]))
    craft = pack.get("photographic_craft")
    if isinstance(craft, dict):
        for candidate in craft.get("dimension_candidates") or []:
            if isinstance(candidate, dict) and candidate.get("id"):
                ids.add(str(candidate["id"]))
    for candidate in adult_appeal_candidates_from_pack(pack):
        if candidate.get("id"):
            ids.add(str(candidate["id"]))
    for candidate in creative_augmentation_candidates_from_pack(pack):
        if candidate.get("id"):
            ids.add(str(candidate["id"]))
    for candidate in (pack.get("candidate_bundles") or {}).get("candidates") or []:
        if isinstance(candidate, dict) and candidate.get("id"):
            ids.add(str(candidate["id"]))
    return ids


def adult_appeal_candidates_from_pack(pack: dict[str, Any]) -> list[dict[str, Any]]:
    pack = photo_native_pack.read_view(pack)
    adult = pack.get("adult_appeal") or {}
    return [row for axis in (adult.get("axes") or {}).values() if isinstance(axis, dict)
            for row in axis.get("candidate_inventory") or [] if isinstance(row, dict)]


def creative_augmentation_candidates_from_pack(
    pack: dict[str, Any],
) -> list[dict[str, Any]]:
    pack = photo_native_pack.read_view(pack)
    contract = (
        pack.get("creative_augmentation")
        if isinstance(pack.get("creative_augmentation"), dict)
        else {}
    )
    return [
        candidate
        for candidate in contract.get("candidates") or []
        if isinstance(candidate, dict)
    ]


def candidate_objects_from_pack(pack: dict[str, Any]) -> dict[str, dict[str, Any]]:
    pack = photo_native_pack.read_view(pack)
    candidates: dict[str, dict[str, Any]] = {cid:dict(row) for cid,row in pack["candidate_pool"].items()}
    slots = photo_native_pack.role_cards(pack) or {}
    slot_values = slots.values() if isinstance(slots, dict) else slots
    for slot_payload in slot_values:
        if not isinstance(slot_payload, dict):
            continue
        for candidate in slot_payload.get("candidates") or []:
            if isinstance(candidate, dict) and candidate.get("id"):
                candidates[str(candidate["id"])] = candidate
    proposition = pack.get("visual_proposition")
    if isinstance(proposition, dict):
        for key in ("core_candidates", "tension_candidates"):
            for candidate in proposition.get(key) or []:
                if isinstance(candidate, dict) and candidate.get("id"):
                    candidates[str(candidate["id"])] = candidate
    integration = pack.get("photographic_integration")
    if isinstance(integration, dict):
        for candidate in integration.get("category_candidates") or []:
            if isinstance(candidate, dict) and candidate.get("id"):
                candidates[str(candidate["id"])] = candidate
    craft = pack.get("photographic_craft")
    if isinstance(craft, dict):
        for candidate in craft.get("dimension_candidates") or []:
            if isinstance(candidate, dict) and candidate.get("id"):
                candidates[str(candidate["id"])] = candidate
    for candidate in adult_appeal_candidates_from_pack(pack):
        if candidate.get("id"):
            candidates[str(candidate["id"])] = candidate
    for candidate in creative_augmentation_candidates_from_pack(pack):
        if candidate.get("id"):
            candidate_id = str(candidate["id"])
            original = candidates.get(candidate_id)
            candidates[candidate_id] = (
                {**candidate, **original} if original and (
                    "context_prerequisites" in original or "context_requirements" in original
                )
                else candidate
            )
    for candidate in (pack.get("candidate_bundles") or {}).get("candidates") or []:
        if isinstance(candidate, dict) and candidate.get("id"):
            candidates[str(candidate["id"])] = candidate
    candidates=copy.deepcopy(candidates)
    # Advisory presentations may omit native source fields. Restore only the
    # pinned identity/choice carrier so an explicit actual RID is still required.
    for cid,row in candidates.items():
        owned=(pack.get('candidate_pool') or {}).get(cid,{})
        if ((owned.get('authored_record') or {}).get('effects') or {}).get('realizations'):
            row['authored_record']=copy.deepcopy(owned['authored_record'])
            row['realization_views']=copy.deepcopy(owned.get('realization_views') or {})
    return candidates


def audit_authorial_pack(pack: dict[str, Any]) -> list[dict[str, Any]]:
    pack = photo_native_pack.read_view(pack)
    if str(pack.get("contract_version") or "") not in {"photo-candidate-pack/v10"}:
        return []
    failures: list[dict[str, Any]] = []
    contract = (
        pack.get("authorial_composition")
        if isinstance(pack.get("authorial_composition"), dict)
        else {}
    )
    policy = contract.get("policy") if isinstance(contract.get("policy"), dict) else {}
    if (
        not contract.get("enabled")
        or contract.get("candidate_content_form") != "unordered_inspiration_terms"
        or contract.get("candidate_order") != "seed_shuffled_non_preferential"
        or (policy.get("agent_is_final_author") is not True)
        or (policy.get("candidate_sentence_copying_forbidden") is not True)
        or (policy.get("all_advisory_candidates_may_be_rejected") is not True)
        or (policy.get("hard_identity_and_safety_constraints_remain_required") is not True)
        or (policy.get("chosen_candidate_interpretations_required") is not True)
    ):
        failures.append(
            {
                "check": "authorial_pack_contract",
                "reason": "current pack is missing its fail-closed authorial composition policy",
            }
        )

    def contains_key(value: Any, key: str) -> bool:
        if isinstance(value, dict):
            return key in value or any((contains_key(item, key) for item in value.values()))
        if isinstance(value, list):
            return any((contains_key(item, key) for item in value))
        return False

    if contains_key(pack, "covered_by"):
        failures.append(
            {
                "check": "authorial_coverage_answer_key",
                "reason": "current pack must not expose candidate IDs as precomputed intent-coverage answers",
            }
        )
    provenance = pack.get("provenance") if isinstance(pack.get("provenance"), dict) else {}
    private_provenance_keys = sorted(
        {
            "argv",
            "preset_id",
            "sample_prompt_id",
            "concept_gate_results",
            "concept_scene_variants",
            "character_response",
            "adult_appeal",
        }
        & set(provenance)
    )
    quality_profile = (
        pack.get("quality_profile") if isinstance(pack.get("quality_profile"), dict) else {}
    )
    integration = (
        pack.get("photographic_integration")
        if isinstance(pack.get("photographic_integration"), dict)
        else {}
    )
    craft = (
        pack.get("photographic_craft") if isinstance(pack.get("photographic_craft"), dict) else {}
    )
    proposition = (
        pack.get("visual_proposition") if isinstance(pack.get("visual_proposition"), dict) else {}
    )
    leaked_quality_keys = {
        "quality_profile": sorted(
            set(quality_profile) & {"source", "matched_facets", "matched_terms"}
        ),
        "photographic_integration": sorted(
            set(integration)
            & {
                "active_axes",
                "quality_profile",
                "matched_facets",
                "matched_terms",
                "principles",
                "required_categories",
                "suggested_concepts",
            }
        ),
        "photographic_craft": sorted(
            set(craft)
            & {
                "active_dimensions",
                "quality_profile",
                "matched_facets",
                "top_strategy",
                "strategy_variants",
                "prompt_dimension_ids",
            }
        ),
        "visual_proposition": sorted(
            set(proposition)
            & {"quality_profile", "subject_class", "subject_classes", "register", "principles"}
        ),
    }
    if quality_profile.get("profile_id") != "authorial" or any(leaked_quality_keys.values()):
        failures.append(
            {
                "check": "authorial_quality_routing",
                "reason": "current pack exposes a sampler-selected quality profile, axis, strategy, or proposition",
                "leaked_keys": leaked_quality_keys,
            }
        )
    scene_contract = (
        pack.get("scene_contract") if isinstance(pack.get("scene_contract"), dict) else {}
    )
    leaked_scene_groups = [
        str(group.get("group") or "unknown")
        for group in scene_contract.get("groups") or []
        if isinstance(group, dict)
        and (
            group.get("strategy") == "atomic_scene"
            or contains_key(group, "selected_entry_id")
            or contains_key(group, "candidate_entry_ids")
            or contains_key(group, "allowed_entry_ids")
            or (
                group.get("strategy") == "optional_inspiration_group"
                and group.get("sampler_selection_exposed") is not False
            )
        )
    ]
    if leaked_scene_groups:
        failures.append(
            {
                "check": "authorial_scene_selection",
                "reason": "current scene groups expose an internal selected entry or semantic answer key",
                "groups": leaked_scene_groups,
            }
        )
    candidate_surfaces = list(candidate_objects_from_pack(pack).values())
    proposition = (
        pack.get("visual_proposition") if isinstance(pack.get("visual_proposition"), dict) else {}
    )
    for key in ("core_candidates", "tension_candidates"):
        candidate_surfaces.extend(
            (candidate for candidate in proposition.get(key) or [] if isinstance(candidate, dict))
        )
    visual_concepts = (
        pack.get("visual_concept_candidates")
        if isinstance(pack.get("visual_concept_candidates"), dict)
        else {}
    )
    visual_candidates = [
        candidate
        for candidate in visual_concepts.get("candidates") or []
        if isinstance(candidate, dict)
    ]
    candidate_surfaces.extend(visual_candidates)
    if visual_concepts:
        candidate_ids = [str(candidate.get("id") or "") for candidate in visual_candidates]
        selection_policy = (
            visual_concepts.get("selection_policy")
            if isinstance(visual_concepts.get("selection_policy"), dict)
            else {}
        )
        concept_contract_invalid = (
            visual_concepts.get("enabled") is not True
            or visual_concepts.get("contract_version") != VISUAL_CONCEPTS_CONTRACT_VERSION
            or visual_concepts.get("candidate_order") != "seed_shuffled_non_preferential"
            or (visual_concepts.get("selection_field") != "chosen_visual_concept_ids")
            or (not candidate_ids)
            or any(
                (not candidate_semantics_generator.photo_candidate_corpus.ID.fullmatch(candidate_id) for candidate_id in candidate_ids)
            )
            or (len(candidate_ids) != len(set(candidate_ids)))
            or any(
                (
                    selection_policy.get(key) is not True
                    for key in (
                        "all_candidates_optional",
                        "selection_list_required_even_when_empty",
                        "unselected_candidates_add_no_prompt_or_review_duty",
                        "selected_candidates_promote_opt_in_contract_to_hard_obligation",
                        "matched_terms_scores_and_routing_reasons_not_exposed",
                    )
                )
            )
        )
        for candidate in visual_candidates:
            applicability = (
                candidate.get("applicability")
                if isinstance(candidate.get("applicability"), dict)
                else {}
            )
            opt_in = (
                candidate.get("opt_in_contract")
                if isinstance(candidate.get("opt_in_contract"), dict)
                else {}
            )
            obligation = (
                opt_in.get("obligation") if isinstance(opt_in.get("obligation"), dict) else {}
            )
            if (
                applicability.get("status") != "eligible"
                or opt_in.get("effect") != "promote_to_hard_visual_obligation"
                or opt_in.get("visual_obligations_contract_version")
                != VISUAL_OBLIGATIONS_CONTRACT_VERSION
                or (not str(obligation.get("id") or ""))
                or (not obligation.get("render_gates"))
            ):
                concept_contract_invalid = True
        if concept_contract_invalid:
            failures.append(
                {
                    "check": "visual_concept_candidate_contract",
                    "reason": "current visual concepts must be optional non-ranked candidates with a complete pre-baked opt-in obligation",
                }
            )
    copyable = [
        str(candidate.get("id") or candidate.get("candidate_id") or "unknown")
        for candidate in candidate_surfaces
        if any((key in candidate for key in ("label_en", "label_ko", "terms")))
        or candidate.get("content_form") != "unordered_inspiration_terms"
        or (not isinstance(candidate.get("concept_terms"), list))
        or (not candidate.get("concept_terms"))
    ]
    if copyable:
        failures.append(
            {
                "check": "authorial_candidate_surface",
                "reason": "current candidate surfaces must expose only non-empty unordered concept terms",
                "candidate_ids": sorted(set(copyable)),
            }
        )
    slots = photo_native_pack.role_cards(pack) if isinstance(photo_native_pack.role_cards(pack), dict) else {}
    ranked_slots = [
        str(slot)
        for slot, payload in slots.items()
        if isinstance(payload, dict)
        and (
            any(
                (
                    key in payload
                    for key in ("selected", "weight_floor", "score_window", "selected_filter")
                )
            )
            or payload.get("candidate_order") != "seed_shuffled_non_preferential"
        )
    ]
    if ranked_slots or any(
        (
            any(
                (
                    key in candidate
                    for key in ("selected_by_sampler", "probability", "weight", "score", "scores")
                )
            )
            for candidate in candidate_surfaces
        )
    ):
        failures.append(
            {
                "check": "authorial_candidate_ranking",
                "reason": "current pack must not expose sampler defaults, probabilities, weights, or ranking handles",
                "slots": sorted(ranked_slots),
            }
        )
    exploration = (
        pack.get("creative_exploration")
        if isinstance(pack.get("creative_exploration"), dict)
        else {}
    )
    leaked_replacements = [
        str(row.get("candidate_id") or "unknown")
        for row in exploration.get("contrast_candidates") or []
        if isinstance(row, dict) and ("replaces_candidate_id" in row or "relevance_rank" in row)
    ]
    if leaked_replacements:
        failures.append(
            {
                "check": "authorial_exploration_ranking",
                "reason": "current creative exploration must not expose a sampler replacement answer key",
                "candidate_ids": leaked_replacements,
            }
        )
    render_contract = (
        pack.get("render_contract") if isinstance(pack.get("render_contract"), dict) else {}
    )
    selected_scene = (
        render_contract.get("selected_scene")
        if isinstance(render_contract.get("selected_scene"), dict)
        else {}
    )
    scene_contract = (
        pack.get("scene_contract") if isinstance(pack.get("scene_contract"), dict) else {}
    )
    authorial_groups = [
        group
        for group in scene_contract.get("groups") or []
        if isinstance(group, dict) and group.get("strategy") == "authorial_scene"
    ]
    if authorial_groups and any(
        (key in selected_scene for key in ("blueprint_id", "source_blueprint_hash", "atomic_scene"))
    ):
        failures.append(
            {
                "check": "authorial_scene_privacy",
                "reason": "current authorial scene leaks a source handle or reusable atomic prose",
            }
        )
    return failures


def assertion_terms_for_intent(intent: dict[str, Any], composed: dict[str, Any]) -> list[str]:
    text = str(intent.get("text") or "")
    terms = [str(item) for item in intent.get("audit_terms") or [] if str(item).strip()]
    if not terms:
        terms = [text]
    assertions = composed.get("coverage_assertions") or {}
    if isinstance(assertions, dict):
        terms.extend(assertion_values(assertions.get(text)))
    return list(dict.fromkeys(term for term in terms if str(term).strip()))


def photographic_integration_category_terms(integration: dict[str, Any], category: str) -> list[str]:
    terms: list[str] = []
    category_terms = integration.get("category_terms") if isinstance(integration.get("category_terms"), dict) else {}
    for term in category_terms.get(category) or []:
        if isinstance(term, str) and term.strip():
            terms.append(term)
    suggested = integration.get("suggested_phrases") if isinstance(integration.get("suggested_phrases"), dict) else {}
    for phrase in suggested.get(category) or []:
        if isinstance(phrase, str) and phrase.strip():
            terms.append(phrase)
    for candidate in integration.get("category_candidates") or []:
        if not isinstance(candidate, dict) or str(candidate.get("category") or "") != category:
            continue
        terms.extend(
            str(term)
            for term in candidate.get("concept_terms") or []
            if str(term).strip()
        )
    return list(dict.fromkeys(terms))


def audit_photographic_integration(pack: dict[str, Any], search_text: str) -> dict[str, Any] | None:
    pack = photo_native_pack.read_view(pack)
    integration = pack.get("photographic_integration")
    if not isinstance(integration, dict) or not integration.get("enabled", True):
        return None

    authorial_candidates = [
        row
        for row in integration.get("category_candidates") or []
        if isinstance(row, dict) and str(row.get("category") or "").strip()
    ]
    required_categories = (
        [str(row.get("category")) for row in authorial_candidates]
        if authorial_candidates
        else [
            str(category)
            for category in integration.get("required_categories") or []
            if str(category).strip()
        ]
    )
    if not required_categories:
        required_categories = ["environment_binding", "optical_depth"]
    try:
        minimum_hits = int(
            integration.get(
                "minimum_selected_categories"
                if authorial_candidates
                else "minimum_category_hits",
                2,
            )
            or 2
        )
    except (TypeError, ValueError):
        minimum_hits = 2
    minimum_hits = max(1, min(minimum_hits, len(required_categories)))

    hits: dict[str, list[str]] = {}
    missing: list[str] = []
    for category in required_categories:
        terms = photographic_integration_category_terms(integration, category)
        matched = [term for term in terms if text_contains_term(search_text, term)]
        if matched:
            hits[category] = matched[:5]
        else:
            missing.append(category)

    if len(hits) >= minimum_hits:
        return None
    return {
        "check": "photographic_integration",
        "reason": "composed prompt underuses the candidate pack's photographic integration layer",
        "profile_id": integration.get("profile_id"),
        "minimum_category_hits": minimum_hits,
        "hit_categories": sorted(hits),
        "missing_categories": missing,
        "principles": integration.get("principles", [])[:3] if isinstance(integration.get("principles"), list) else [],
    }


def visual_proposition_category_terms(proposition: dict[str, Any], category: str) -> list[str]:
    terms: list[str] = []
    category_terms = proposition.get("category_terms") if isinstance(proposition.get("category_terms"), dict) else {}
    for term in category_terms.get(category) or []:
        if isinstance(term, str) and term.strip():
            terms.append(term)
    candidate_keys = {
        "narrative_core": "core_candidates",
        "concept_tension": "tension_candidates",
    }
    for candidate in proposition.get(candidate_keys.get(category, ""), []) or []:
        if not isinstance(candidate, dict):
            continue
        for term in (candidate.get("concept_terms") or candidate.get("terms") or []):
            if isinstance(term, str) and term.strip():
                terms.append(term)
    return list(dict.fromkeys(terms))


def photographic_craft_dimension_terms(craft: dict[str, Any], dimension_id: str) -> list[str]:
    terms: list[str] = []
    for dimension in craft.get("active_dimensions") or []:
        if not isinstance(dimension, dict) or str(dimension.get("id") or "") != dimension_id:
            continue
        for key in ("selected_guidance_en", "selected_guidance_ko", "guidance_en", "guidance_ko", "selected_principle"):
            value = str(dimension.get(key) or "").strip()
            if value:
                terms.append(value)
        for term in dimension.get("audit_terms") or []:
            if isinstance(term, str) and term.strip():
                terms.append(term)
        for refinement in dimension.get("active_refinements") or []:
            if not isinstance(refinement, dict):
                continue
            for key in ("guidance_en", "guidance_ko", "principle"):
                value = str(refinement.get(key) or "").strip()
                if value:
                    terms.append(value)
            for term in refinement.get("audit_terms") or []:
                if isinstance(term, str) and term.strip():
                    terms.append(term)
    for candidate in craft.get("dimension_candidates") or []:
        if not isinstance(candidate, dict) or str(candidate.get("dimension") or "") != dimension_id:
            continue
        terms.extend(
            str(term)
            for term in candidate.get("concept_terms") or []
            if str(term).strip()
        )
    return list(dict.fromkeys(terms))


def audit_photographic_craft(pack: dict[str, Any], search_text: str) -> dict[str, Any] | None:
    pack = photo_native_pack.read_view(pack)
    craft = pack.get("photographic_craft")
    if not isinstance(craft, dict) or not craft.get("enabled", True):
        return None
    strategy = craft.get("top_strategy") if isinstance(craft.get("top_strategy"), dict) else {}
    dimensions = [
        str(dimension_id)
        for dimension_id in strategy.get("emphasize") or craft.get("prompt_dimension_ids") or []
        if str(dimension_id).strip()
    ]
    if not dimensions:
        dimensions = [
            str(dimension.get("id"))
            for dimension in craft.get("active_dimensions") or []
            if isinstance(dimension, dict) and str(dimension.get("id") or "").strip()
        ][:2]
    if not dimensions:
        dimensions = [
            str(candidate.get("dimension"))
            for candidate in craft.get("dimension_candidates") or []
            if isinstance(candidate, dict) and str(candidate.get("dimension") or "").strip()
        ]
    if not dimensions:
        return None

    hits: dict[str, list[str]] = {}
    missing: list[str] = []
    for dimension_id in dimensions:
        terms = photographic_craft_dimension_terms(craft, dimension_id)
        matched = [term for term in terms if text_contains_term(search_text, term)]
        if matched:
            hits[dimension_id] = matched[:5]
        else:
            missing.append(dimension_id)

    if hits:
        return None
    return {
        "check": "photographic_craft",
        "reason": "composed prompt does not visibly use the candidate pack's photographer craft decision layer",
        "top_strategy": strategy.get("id"),
        "expected_dimensions": dimensions,
        "missing_dimensions": missing,
        "principles": [
            str(dimension.get("selected_principle") or dimension.get("baseline_principle") or "")
            for dimension in craft.get("active_dimensions") or []
            if isinstance(dimension, dict) and str(dimension.get("id") or "") in set(dimensions)
        ][:3],
    }


def audit_visual_proposition(pack: dict[str, Any], search_text: str) -> dict[str, Any] | None:
    pack = photo_native_pack.read_view(pack)
    proposition = pack.get("visual_proposition")
    if not isinstance(proposition, dict) or not proposition.get("enabled", True):
        return None
    try:
        minimum_hits = int(proposition.get("minimum_hits", 1) or 0)
    except (TypeError, ValueError):
        minimum_hits = 1
    if minimum_hits <= 0:
        return None

    categories = [
        str(category)
        for category in proposition.get("audit_categories") or ["narrative_core", "concept_tension", "evidence"]
        if str(category).strip()
    ]
    if not categories:
        categories = ["narrative_core", "concept_tension", "evidence"]
    hits: dict[str, list[str]] = {}
    missing: list[str] = []
    for category in categories:
        terms = visual_proposition_category_terms(proposition, category)
        matched = [term for term in terms if text_contains_term(search_text, term)]
        if matched:
            hits[category] = matched[:5]
        else:
            missing.append(category)

    if len(hits) >= min(minimum_hits, len(categories)):
        return None
    return {
        "check": "visual_proposition",
        "reason": "composed prompt does not visibly use the candidate pack's emotional proposition or visual tension layer",
        "register": proposition.get("register"),
        "subject_class": proposition.get("subject_class"),
        "subject_classes": proposition.get("subject_classes", []),
        "minimum_hits": minimum_hits,
        "hit_categories": sorted(hits),
        "missing_categories": missing,
        "principles": proposition.get("principles", [])[:3] if isinstance(proposition.get("principles"), list) else [],
    }


def audit_artistic_final_touch(pack: dict[str, Any], prompt_en: str) -> dict[str, Any] | None:
    pack = photo_native_pack.read_view(pack)
    touch = pack.get("artistic_final_touch")
    if not isinstance(touch, dict) or not touch.get("enabled", True):
        return None
    final_sentence = str(touch.get("final_sentence_en") or "").strip()
    if final_sentence and final_sentence.lower() in prompt_en.lower():
        return None
    audit_terms = [str(term) for term in touch.get("audit_terms") or [] if str(term).strip()]
    matched_terms = [term for term in audit_terms if text_contains_term(prompt_en, term)]
    if len(matched_terms) >= min(2, len(audit_terms)):
        return None
    return {
        "check": "artistic_final_touch",
        "reason": "composed prompt does not represent the profile-specific photographic touch",
        "expected_final_sentence": final_sentence or None,
        "matched_terms": matched_terms[:5],
    }


def nonempty_string_list(raw: Any) -> list[str]:
    if not isinstance(raw, list):
        return []
    return [str(item).strip() for item in raw if isinstance(item, str) and str(item).strip()]


def normalized_unique_count(values: Sequence[str]) -> int:
    return len({str(value).strip().lower() for value in values if str(value).strip()})


def native_profile_choice_rows(pack):
    value=pack.get('native_profile_choices')
    if value is None:return []
    if (not isinstance(value,dict) or set(value)!={'schema','profiles'}
            or value['schema']!='photo-native-profile-choices/v1' or not isinstance(value['profiles'],list)
            or len(value['profiles'])>64):
        raise ValueError('bounded native profile choices required')
    seen=set()
    for profile in value['profiles']:
        if (not isinstance(profile,dict) or set(profile)!={'candidate_id','required','source_record_sha256','choices'}
                or not isinstance(profile['candidate_id'],str) or profile['candidate_id'] in seen
                or type(profile['required']) is not bool or not isinstance(profile['choices'],list) or len(profile['choices'])>32):
            raise ValueError('exact unique profile choice source required')
        seen.add(profile['candidate_id']);rids=set()
        for choice in profile['choices']:
            if (not isinstance(choice,dict) or set(choice)-{'owner_selection_requirements'}!={'realization_id','qualification','selected_profile_contract',
                    'obligation','en','ko','concept_units','relations','affected_dimensions','affected_properties'}
                    or not isinstance(choice['realization_id'],str) or choice['realization_id'] in rids
                    or not isinstance(choice['qualification'],str) or choice['qualification'] not in {'qualified','unqualified','invalid'}
                    or choice['qualification']=='qualified' and not isinstance(choice['obligation'],dict)
                    or choice['qualification']!='qualified' and choice['obligation'] is not None):
                raise ValueError('exact unique actual profile choice required')
            rids.add(choice['realization_id'])
    return value['profiles']


def derive_effective_visual_obligation_contract(
    pack: dict[str, Any],
    composed: dict[str, Any] | None,
) -> tuple[dict[str, Any] | None, list[dict[str, Any]]]:
    """Derive the only authoritative visual gate set from pack plus selection.

    Hard obligations are unconditional.  Optional visual concepts contribute
    nothing until their IDs occur in the composed selection list; a selected
    concept promotes its immutable opt-in obligation to the same hard contract.
    """
    pack = photo_native_pack.read_view(pack)

    failures: list[dict[str, Any]] = []
    hard_contract = (
        pack.get("visual_obligations")
        if isinstance(pack.get("visual_obligations"), dict)
        and pack.get("visual_obligations", {}).get("enabled") is True
        else None
    )
    candidate_contract = (
        pack.get("visual_concept_candidates")
        if isinstance(pack.get("visual_concept_candidates"), dict)
        and pack.get("visual_concept_candidates", {}).get("enabled") is True
        else None
    )
    composed_object = composed if isinstance(composed, dict) else {}
    raw_chosen = composed_object.get("chosen_visual_concept_ids")
    if candidate_contract is not None and "chosen_visual_concept_ids" not in composed_object:
        failures.append(
            {
                "check": "chosen_visual_concept_ids",
                "reason": (
                    "a pack with optional visual concepts requires an explicit selection list, "
                    "which may be empty"
                ),
            }
        )
    if raw_chosen is None:
        chosen_ids: list[str] = []
    elif not isinstance(raw_chosen, list) or any(
        not isinstance(value, str) or not value.strip() for value in raw_chosen
    ):
        failures.append(
            {
                "check": "chosen_visual_concept_ids",
                "reason": "chosen visual concept ids must be a list of non-empty strings",
            }
        )
        chosen_ids = []
    else:
        chosen_ids = [str(value).strip() for value in raw_chosen]
        if len(chosen_ids) != len(set(chosen_ids)):
            failures.append(
                {
                    "check": "chosen_visual_concept_ids",
                    "reason": "chosen visual concept ids must be distinct",
                }
            )
    if candidate_contract is None and chosen_ids:
        failures.append(
            {
                "check": "chosen_visual_concept_ids",
                "reason": "composed output selected visual concepts that the pack did not expose",
                "ids": chosen_ids,
            }
        )
    candidate_map = {
        str(candidate.get("id") or ""): candidate
        for candidate in (candidate_contract or {}).get("candidates") or []
        if isinstance(candidate, dict) and str(candidate.get("id") or "")
    }
    unknown_ids = sorted(set(chosen_ids) - set(candidate_map))
    if unknown_ids:
        failures.append(
            {
                "check": "chosen_visual_concept_ids",
                "reason": "unknown visual concept candidate id",
                "ids": unknown_ids,
            }
        )

    obligations = [
        copy.deepcopy(item)
        for item in (hard_contract or {}).get("obligations") or []
        if isinstance(item, dict) and str(item.get("id") or "")
    ]
    seen_profile_ids = {str(item.get("id") or "") for item in obligations}
    selected_candidate_ids: list[str] = []
    for candidate_id in chosen_ids:
        candidate = candidate_map.get(candidate_id)
        if not isinstance(candidate, dict):
            continue
        opt_in = (
            candidate.get("opt_in_contract")
            if isinstance(candidate.get("opt_in_contract"), dict)
            else {}
        )
        obligation = (
            opt_in.get("obligation")
            if isinstance(opt_in.get("obligation"), dict)
            else None
        )
        profile_id = str((obligation or {}).get("id") or "")
        if (
            opt_in.get("effect") != "promote_to_hard_visual_obligation"
            or opt_in.get("visual_obligations_contract_version")
            != VISUAL_OBLIGATIONS_CONTRACT_VERSION
            or not profile_id
        ):
            failures.append(
                {
                    "check": "visual_concept_opt_in_contract",
                    "reason": "selected visual concept has an invalid opt-in obligation",
                    "candidate_id": candidate_id,
                }
            )
            continue
        if profile_id in seen_profile_ids:
            failures.append(
                {
                    "check": "visual_concept_opt_in_contract",
                    "reason": "selected visual concept duplicates an already-effective profile",
                    "candidate_id": candidate_id,
                    "profile_id": profile_id,
                }
            )
            continue
        obligations.append(copy.deepcopy(obligation))
        seen_profile_ids.add(profile_id)
        selected_candidate_ids.append(candidate_id)
    transformed=[row for row in (composed_object.get('creative_augmentation_brief') or {}).get('decisions',[])
                 if isinstance(row,dict) and row.get('decision')=='transformed']
    native_chosen=normalize_chosen_candidate_ids(composed_object.get('chosen_candidate_ids'))
    native_chosen.update(chosen_ids)
    native_chosen.update(row.get('candidate_id') for row in transformed if row.get('candidate_id'))
    interpretations={row.get('candidate_id'):row for row in [*(composed_object.get('candidate_interpretations') or []),*transformed] if isinstance(row,dict)}
    try: native_profiles=native_profile_choice_rows(pack)
    except ValueError as exc:
        failures.append({'check':'native_profile_selection','reason':str(exc)});native_profiles=[]
    for profile in native_profiles:
        cid=profile['candidate_id']
        if cid not in native_chosen:
            if profile['required']:failures.append({'check':'native_profile_selection','reason':'required actual profile choice missing','candidate_id':cid})
            continue
        actual=(interpretations.get(cid) or {}).get('realization_id')
        choice=next((row for row in profile['choices'] if row['realization_id']==actual),None)
        if (choice is None or choice.get('qualification')!='qualified' or not isinstance(choice.get('obligation'),dict)
                or cid in seen_profile_ids):
            failures.append({'check':'native_profile_selection','reason':'one unique qualified actual profile obligation required','candidate_id':cid})
            continue
        obligations.append(copy.deepcopy(choice['obligation']));seen_profile_ids.add(cid)
    if not obligations:
        return None, failures
    required_hard_gates = list(
        dict.fromkeys(
            str(gate.get("id") or "")
            for obligation in obligations
            for gate in obligation.get("render_gates") or []
            if isinstance(gate, dict) and str(gate.get("id") or "")
        )
    )
    effective: dict[str, Any] = {
        "enabled": True,
        "contract_version": VISUAL_OBLIGATIONS_CONTRACT_VERSION,
        "scope": "request_only",
        "strict_gate_set": True,
        "obligations": obligations,
        "required_hard_gates": required_hard_gates,
        "selected_visual_concept_ids": selected_candidate_ids,
    }
    if isinstance(hard_contract, dict):
        for key in ("precedence", "retry_policy", "source_visual_intent_sha256"):
            if key in hard_contract:
                effective[key] = copy.deepcopy(hard_contract[key])
    return effective, failures


def effective_visual_obligation_sha256(contract: dict[str, Any] | None) -> str | None:
    if not isinstance(contract, dict):
        return None
    canonical = json.dumps(
        contract,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    )
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def audit_visual_obligations(
    pack: dict[str, Any],
    composed: dict[str, Any],
    prompt_en: str,
) -> list[dict[str, Any]]:
    """Bind active request-scoped visual obligations to literal prompt evidence."""
    pack = photo_native_pack.read_view(pack)

    contract, selection_failures = derive_effective_visual_obligation_contract(
        pack,
        composed,
    )
    supplied_evidence = composed.get("visual_obligation_evidence")
    native_ids={item['id'] for item in (contract or {}).get('obligations',[]) if item.get('native_profile_contract')}
    if native_ids:
        supplied_evidence=copy.deepcopy(supplied_evidence) if isinstance(supplied_evidence,dict) else {}
        transformed=[row for row in (composed.get('creative_augmentation_brief') or {}).get('decisions',[])
                     if isinstance(row,dict) and row.get('decision')=='transformed']
        for item in [*(composed.get('candidate_interpretations') or []),*transformed]:
            if not isinstance(item,dict) or item.get('candidate_id') not in native_ids:continue
            cid=item['candidate_id'];local=item.get('selected_profile_evidence')
            if cid in supplied_evidence and supplied_evidence[cid]!=local:
                selection_failures.append({'check':'native_profile_evidence','reason':'conflicting local and visual obligation evidence','candidate_id':cid})
            elif isinstance(local,dict):supplied_evidence[cid]=copy.deepcopy(local)
    if not isinstance(contract, dict) or contract.get("enabled") is not True:
        if supplied_evidence not in (None, {}):
            selection_failures.append(
                {
                    "check": "visual_obligation_evidence",
                    "reason": "composed output supplies visual-obligation evidence but the pack activates no visual obligations",
                }
            )
        return selection_failures

    failures: list[dict[str, Any]] = list(selection_failures)
    if contract.get("contract_version") != VISUAL_OBLIGATIONS_CONTRACT_VERSION:
        failures.append(
            {
                "check": "visual_obligations_contract",
                "reason": "unsupported visual-obligations contract_version",
                "expected": VISUAL_OBLIGATIONS_CONTRACT_VERSION,
                "actual": contract.get("contract_version"),
            }
        )
    visual_intent = pack.get("visual_intent")
    source_visual_intent_sha256 = str(
        contract.get("source_visual_intent_sha256") or ""
    )
    if visual_intent is not None or source_visual_intent_sha256:
        if not isinstance(visual_intent, dict):
            failures.append(
                {
                    "check": "visual_intent_integrity",
                    "reason": "hash-bound visual obligations require the canonical visual_intent object",
                }
            )
        else:
            allowed_visual_intent_fields = {
                "contract_version",
                "provenance",
                "obligations",
                "canonical_sha256",
                "request_id",
            }
            unknown_visual_intent_fields = sorted(
                set(visual_intent) - allowed_visual_intent_fields
            )
            canonical_visual_intent = {
                "contract_version": visual_intent.get("contract_version"),
                "provenance": visual_intent.get("provenance"),
                "obligations": visual_intent.get("obligations"),
            }
            actual_visual_intent_sha256 = hashlib.sha256(
                json.dumps(
                    canonical_visual_intent,
                    ensure_ascii=False,
                    sort_keys=True,
                    separators=(",", ":"),
                ).encode("utf-8")
            ).hexdigest()
            if (
                unknown_visual_intent_fields
                or visual_intent.get("contract_version")
                != VISUAL_INTENT_CONTRACT_VERSION
                or visual_intent.get("provenance") != "agent_prepack"
                or str(visual_intent.get("canonical_sha256") or "")
                != actual_visual_intent_sha256
                or str(visual_intent.get("request_id") or "")
                != actual_visual_intent_sha256[:16]
                or source_visual_intent_sha256 != actual_visual_intent_sha256
            ):
                failures.append(
                    {
                        "check": "visual_intent_integrity",
                        "reason": "visual_intent canonical bytes or source hash changed after pre-pack freezing",
                        "unknown_fields": unknown_visual_intent_fields,
                        "expected_sha256": actual_visual_intent_sha256,
                        "actual_sha256": visual_intent.get("canonical_sha256"),
                        "contract_sha256": source_visual_intent_sha256 or None,
                    }
                )
    obligations = [
        item
        for item in contract.get("obligations") or []
        if isinstance(item, dict) and str(item.get("id") or "").strip()
    ]
    expected_ids = {str(item["id"]) for item in obligations}
    if isinstance(visual_intent, dict):
        explicit_ids = {
            str(item.get("profile_id") or "")
            for item in visual_intent.get("obligations") or []
            if isinstance(item, dict) and str(item.get("profile_id") or "")
        }
        missing_explicit_profiles = sorted(explicit_ids - expected_ids)
        if missing_explicit_profiles:
            failures.append(
                {
                    "check": "visual_intent_binding",
                    "reason": "a pre-pack visual-intent profile is missing from active visual obligations",
                    "missing": missing_explicit_profiles,
                }
            )
    if not obligations:
        failures.append(
            {
                "check": "visual_obligations_contract",
                "reason": "enabled visual-obligations contract contains no obligations",
            }
        )
    if not isinstance(supplied_evidence, dict):
        failures.append(
            {
                "check": "visual_obligation_evidence",
                "reason": "active visual obligations require a visual_obligation_evidence object",
            }
        )
        supplied_evidence = {}
    actual_ids = {str(key) for key in supplied_evidence}
    missing_ids = sorted(expected_ids - actual_ids)
    extra_ids = sorted(actual_ids - expected_ids)
    if missing_ids or extra_ids:
        failures.append(
            {
                "check": "visual_obligation_evidence",
                "reason": "visual obligation evidence profile ids must exactly match the active pack profiles",
                "missing": missing_ids,
                "extra": extra_ids,
            }
        )

    declared_gate_ids: list[str] = []
    for obligation in obligations:
        profile_id = str(obligation["id"])
        binding = (
            obligation.get("prompt_binding")
            if isinstance(obligation.get("prompt_binding"), dict)
            else {}
        )
        required_fields = [
            str(field)
            for field in binding.get("required_evidence_fields") or []
            if str(field).strip()
        ]
        evidence_requirements = (
            obligation.get("evidence_requirements")
            if isinstance(obligation.get("evidence_requirements"), dict)
            else {}
        )
        runtime_expression = (
            obligation.get("runtime_expression")
            if isinstance(obligation.get("runtime_expression"), dict)
            else {}
        )
        expression_mode = str(runtime_expression.get("default_mode") or "")
        label_terms = nonempty_string_list(runtime_expression.get("prompt_label_terms"))
        forbidden_prompt_terms = nonempty_string_list(
            runtime_expression.get("forbidden_prompt_terms")
        )
        if expression_mode == "label_plus_definition" and not any(
            text_contains_term(prompt_en, term) for term in label_terms
        ):
            failures.append(
                {
                    "check": "visual_obligation_runtime_expression",
                    "reason": "runtime expression policy requires a safe label plus component definition",
                    "profile_id": profile_id,
                    "accepted_labels": label_terms,
                }
            )
        forbidden_runtime_hits = [
            term for term in forbidden_prompt_terms if text_contains_term(prompt_en, term)
        ]
        if forbidden_runtime_hits:
            failures.append(
                {
                    "check": "visual_obligation_runtime_expression",
                    "reason": "runtime prompt contains a label forbidden by the profile expression policy",
                    "profile_id": profile_id,
                    "terms": forbidden_runtime_hits,
                }
            )
        profile_evidence = supplied_evidence.get(profile_id)
        if not isinstance(profile_evidence, dict):
            continue
        actual_fields = {str(key) for key in profile_evidence}
        expected_fields = set(required_fields)
        missing_fields = sorted(expected_fields - actual_fields)
        extra_fields = sorted(actual_fields - expected_fields)
        if missing_fields or extra_fields:
            failures.append(
                {
                    "check": "visual_obligation_evidence",
                    "reason": "profile evidence fields must exactly match its prompt-binding contract",
                    "profile_id": profile_id,
                    "missing": missing_fields,
                    "extra": extra_fields,
                }
            )
        literal_phrases: list[str] = []
        for field in required_fields:
            phrase = profile_evidence.get(field)
            if not isinstance(phrase, str) or not phrase.strip():
                failures.append(
                    {
                        "check": "visual_obligation_evidence",
                        "reason": "required visual evidence must be a non-empty string",
                        "profile_id": profile_id,
                        "field": field,
                    }
                )
                continue
            phrase = phrase.strip()
            literal_phrases.append(phrase)
            if not text_contains_term(prompt_en, phrase):
                failures.append(
                    {
                        "check": "visual_obligation_prompt_binding",
                        "reason": "visual evidence phrase is not literal in prompt_en",
                        "profile_id": profile_id,
                        "field": field,
                        "phrase": phrase,
                    }
                )
            requirement = (
                evidence_requirements.get(field)
                if isinstance(evidence_requirements.get(field), dict)
                else {}
            )
            try:
                minimum_content_words = int(requirement.get("min_content_words", 3))
            except (TypeError, ValueError):
                minimum_content_words = 3
            content_words = authorial_evidence_tokens(phrase)
            if len(content_words) < minimum_content_words:
                failures.append(
                    {
                        "check": "visual_obligation_semantic_evidence",
                        "reason": "visual evidence phrase is too generic to prove its field",
                        "profile_id": profile_id,
                        "field": field,
                        "minimum_content_words": minimum_content_words,
                        "actual_content_words": len(content_words),
                    }
                )
            required_anchors = nonempty_string_list(requirement.get("must_mention_any"))
            if required_anchors and not any(
                text_contains_term(phrase, anchor) for anchor in required_anchors
            ):
                failures.append(
                    {
                        "check": "visual_obligation_semantic_evidence",
                        "reason": "visual evidence phrase lacks a profile-declared component anchor",
                        "profile_id": profile_id,
                        "field": field,
                        "accepted_anchors": required_anchors,
                    }
                )
            forbidden_field_hits = [
                term
                for term in nonempty_string_list(requirement.get("must_not_contain"))
                if text_contains_term(phrase, term)
            ]
            if forbidden_field_hits:
                failures.append(
                    {
                        "check": "visual_obligation_semantic_evidence",
                        "reason": "visual evidence phrase contains a profile-declared contradiction",
                        "profile_id": profile_id,
                        "field": field,
                        "terms": forbidden_field_hits,
                    }
                )
            filler_hits = [
                term
                for term in nonempty_string_list(binding.get("forbidden_filler_phrases"))
                if text_contains_term(phrase, term)
            ]
            if filler_hits:
                failures.append(
                    {
                        "check": "visual_obligation_semantic_evidence",
                        "reason": "field-name or checklist filler is not visual proof",
                        "profile_id": profile_id,
                        "field": field,
                        "terms": filler_hits,
                    }
                )
        try:
            minimum_distinct = int(
                binding.get("minimum_distinct_evidence_phrases", len(required_fields))
            )
        except (TypeError, ValueError):
            minimum_distinct = len(required_fields)
        if normalized_unique_count(literal_phrases) < minimum_distinct:
            failures.append(
                {
                    "check": "visual_obligation_distinct_evidence",
                    "reason": "different visual duties require distinct literal prompt phrases",
                    "profile_id": profile_id,
                    "minimum": minimum_distinct,
                    "actual": normalized_unique_count(literal_phrases),
                }
            )
        try:
            overlap_limit = float(
                binding.get("maximum_pairwise_content_token_overlap_ratio", 0.82)
            )
        except (TypeError, ValueError):
            overlap_limit = 0.82
        phrase_token_sets = [authorial_evidence_tokens(phrase) for phrase in literal_phrases]
        excessive_overlap_pairs: list[list[int]] = []
        for left_index, left_tokens in enumerate(phrase_token_sets):
            for right_index in range(left_index + 1, len(phrase_token_sets)):
                right_tokens = phrase_token_sets[right_index]
                union = left_tokens | right_tokens
                overlap = len(left_tokens & right_tokens) / len(union) if union else 1.0
                if overlap > overlap_limit:
                    excessive_overlap_pairs.append([left_index, right_index])
        if excessive_overlap_pairs:
            failures.append(
                {
                    "check": "visual_obligation_distinct_evidence",
                    "reason": "visual duties reuse too much of the same content-token evidence",
                    "profile_id": profile_id,
                    "maximum_overlap_ratio": overlap_limit,
                    "pairs": excessive_overlap_pairs,
                }
            )
        hard_bindings = (
            obligation.get("bindings")
            if isinstance(obligation.get("bindings"), dict)
            else {}
        )
        for field, expected_phrase in hard_bindings.items():
            actual_phrase = str(profile_evidence.get(str(field)) or "").strip()
            expected_phrase = str(expected_phrase or "").strip()
            if actual_phrase != expected_phrase:
                failures.append(
                    {
                        "check": "visual_obligation_hard_binding",
                        "reason": "request-scoped pre-pack binding changed during composition",
                        "profile_id": profile_id,
                        "field": field,
                        "expected": expected_phrase,
                        "actual": actual_phrase or None,
                    }
                )
            elif not text_contains_term(prompt_en, expected_phrase):
                failures.append(
                    {
                        "check": "visual_obligation_hard_binding",
                        "reason": "request-scoped pre-pack binding is not literal in prompt_en",
                        "profile_id": profile_id,
                        "field": field,
                        "phrase": expected_phrase,
                    }
                )
        declared_gate_ids.extend(
            str(gate.get("id") or "")
            for gate in obligation.get("render_gates") or []
            if isinstance(gate, dict) and str(gate.get("id") or "").strip()
        )

    required_gate_ids = [
        str(gate)
        for gate in contract.get("required_hard_gates") or []
        if str(gate).strip()
    ]
    if list(dict.fromkeys(declared_gate_ids)) != required_gate_ids:
        failures.append(
            {
                "check": "visual_obligations_contract",
                "reason": "required_hard_gates must exactly equal the ordered union of obligation render gates",
            }
        )
    return failures


def audit_viewer_experience(
    pack: dict[str, Any],
    composed: dict[str, Any],
    prompt_en: str,
) -> list[dict[str, Any]]:
    pack = photo_native_pack.read_view(pack)
    contract = pack.get("viewer_experience")
    if not isinstance(contract, dict) or not contract.get("enabled"):
        return []

    failures: list[dict[str, Any]] = []
    experience = composed.get("viewer_experience")
    if not isinstance(experience, dict):
        return [
            {
                "check": "viewer_experience",
                "reason": "enabled viewer-experience pack requires a viewer_experience object",
            }
        ]

    required_fields = [str(item) for item in contract.get("required_fields") or [] if str(item)]
    missing_fields = [field for field in required_fields if field not in experience]
    if missing_fields:
        failures.append(
            {
                "check": "viewer_experience",
                "reason": "viewer experience is missing required fields",
                "fields": missing_fields,
            }
        )

    scalar_fields = (
        "viewing_context",
        "primary_viewer_need",
        "intended_experience",
        "viewer_promise",
        "first_glance_hook",
        "interpretive_question",
        "attachment_channel",
        "commercial_objective",
    )
    invalid_scalars = [
        field
        for field in scalar_fields
        if not isinstance(experience.get(field), str) or not str(experience.get(field)).strip()
    ]
    if invalid_scalars:
        failures.append(
            {
                "check": "viewer_experience_primary",
                "reason": "viewer experience must select one scalar value for each primary field",
                "fields": invalid_scalars,
            }
        )
    if "primary_viewer_needs" in experience or "intended_experiences" in experience:
        failures.append(
            {
                "check": "viewer_experience_affect_stacking",
                "reason": "use one primary_viewer_need and one scalar intended_experience, not stacked plural fields",
            }
        )

    allowed = contract.get("allowed_values") if isinstance(contract.get("allowed_values"), dict) else {}
    for field, enum_key in (
        ("viewing_context", "viewing_context"),
        ("primary_viewer_need", "primary_viewer_need"),
        ("attachment_channel", "attachment_channel"),
        ("commercial_objective", "commercial_objective"),
    ):
        value = str(experience.get(field) or "")
        values = {str(item) for item in allowed.get(enum_key) or []}
        if value and values and value not in values:
            failures.append(
                {
                    "check": "viewer_experience_enum",
                    "reason": "viewer experience uses a value outside the candidate-pack contract",
                    "field": field,
                    "value": value,
                }
            )

    audience = experience.get("target_audience")
    if not isinstance(audience, dict):
        audience = {}
    audience_fields = [str(item) for item in contract.get("target_audience_fields") or [] if str(item)]
    missing_audience = [
        field
        for field in audience_fields
        if not isinstance(audience.get(field), str) or not str(audience.get(field)).strip()
    ]
    if missing_audience:
        failures.append(
            {
                "check": "viewer_experience_audience",
                "reason": "target audience must declare literacy and prior-knowledge scope",
                "fields": missing_audience,
            }
        )
    literacy = str(audience.get("literacy") or "")
    allowed_literacy = {str(item) for item in allowed.get("audience_literacy") or []}
    if literacy and allowed_literacy and literacy not in allowed_literacy:
        failures.append(
            {
                "check": "viewer_experience_audience",
                "reason": "audience literacy is outside the candidate-pack contract",
                "value": literacy,
            }
        )

    affect = experience.get("affect_evidence")
    if not isinstance(affect, dict):
        affect = {}
    affect_fields = [str(item) for item in contract.get("affect_evidence_fields") or [] if str(item)]
    missing_affect = [
        field
        for field in affect_fields
        if not isinstance(affect.get(field), str) or not str(affect.get(field)).strip()
    ]
    if missing_affect:
        failures.append(
            {
                "check": "viewer_experience_affect_cause",
                "reason": "affect requires a visible actor, action, target, and consequence",
                "fields": missing_affect,
            }
        )

    reinspection = experience.get("reinspection_reward")
    if not isinstance(reinspection, dict):
        reinspection = {}
    reinspection_mode = str(reinspection.get("mode") or "")
    reinspection_description = str(reinspection.get("description") or "").strip()
    allowed_reinspection = {str(item) for item in allowed.get("reinspection_mode") or []}
    if reinspection_mode not in allowed_reinspection:
        failures.append(
            {
                "check": "viewer_experience_reinspection",
                "reason": "reinspection reward requires one allowed mode",
                "value": reinspection_mode or None,
            }
        )
    elif reinspection_mode == "causal_second_reading" and not reinspection_description:
        failures.append(
            {
                "check": "viewer_experience_reinspection",
                "reason": "causal second reading requires a concrete description",
            }
        )

    conditional = contract.get("conditional_rules") if isinstance(contract.get("conditional_rules"), dict) else {}
    primary_need = str(experience.get("primary_viewer_need") or "")
    attachment_channel = str(experience.get("attachment_channel") or "")
    attachment_needs = {str(item) for item in conditional.get("attachment_required_for_needs") or []}
    if primary_need in attachment_needs and attachment_channel == "none":
        failures.append(
            {
                "check": "viewer_experience_attachment",
                "reason": "the selected viewer need requires a visible attachment channel",
                "primary_viewer_need": primary_need,
            }
        )

    commercial_objective = str(experience.get("commercial_objective") or "")
    creative_direction = pack.get("creative_direction")
    creative_enabled = isinstance(creative_direction, dict) and creative_direction.get("enabled") is True
    if (
        creative_enabled
        and commercial_objective == "none"
        and conditional.get("creative_noncommercial_reinspection_required") is True
        and reinspection_mode != "causal_second_reading"
    ):
        failures.append(
            {
                "check": "viewer_experience_reinspection",
                "reason": "a noncommercial creative-direction run requires one causal second-reading reward",
            }
        )
    if creative_enabled and commercial_objective == "none" and str(experience.get("interpretive_question") or "").strip().lower() == "none":
        failures.append(
            {
                "check": "viewer_experience_question",
                "reason": "a noncommercial creative-direction run requires a resolvable interpretive question",
            }
        )

    evidence = experience.get("prompt_evidence")
    if not isinstance(evidence, dict):
        evidence = {}
    binding = contract.get("prompt_binding") if isinstance(contract.get("prompt_binding"), dict) else {}
    required_evidence_fields = [str(item) for item in binding.get("required_evidence_fields") or [] if str(item)]
    evidence_phrases: list[str] = []
    missing_evidence = []
    for field in required_evidence_fields:
        phrase = str(evidence.get(field) or "").strip()
        if phrase:
            evidence_phrases.append(phrase)
        else:
            missing_evidence.append(field)
    if missing_evidence:
        failures.append(
            {
                "check": "viewer_experience_binding",
                "reason": "viewer experience is missing required visible prompt evidence",
                "fields": missing_evidence,
            }
        )

    conditional_evidence = binding.get("conditional_evidence_fields") if isinstance(binding.get("conditional_evidence_fields"), dict) else {}
    conditional_required: list[str] = []
    if attachment_channel and attachment_channel != "none":
        conditional_required.append(str(conditional_evidence.get("attachment_channel_not_none") or "attachment_phrase"))
    if reinspection_mode == "causal_second_reading":
        conditional_required.append(
            str(conditional_evidence.get("reinspection_mode_causal_second_reading") or "reinspection_reward_phrase")
        )
    commercial_legibility_objectives = {
        str(item) for item in conditional.get("commercial_legibility_required_for_objectives") or []
    }
    if commercial_objective in commercial_legibility_objectives:
        conditional_required.append(
            str(conditional_evidence.get("commercial_objective_comprehend_remember_act") or "commercial_legibility_phrase")
        )
    missing_conditional = []
    for field in conditional_required:
        phrase = str(evidence.get(field) or "").strip()
        if phrase:
            evidence_phrases.append(phrase)
        else:
            missing_conditional.append(field)
    if missing_conditional:
        failures.append(
            {
                "check": "viewer_experience_binding",
                "reason": "viewer experience is missing conditional visible evidence",
                "fields": missing_conditional,
            }
        )

    missing_literal = [phrase for phrase in evidence_phrases if not text_contains_term(prompt_en, phrase)]
    if missing_literal:
        failures.append(
            {
                "check": "viewer_experience_binding",
                "reason": "declared viewer-experience evidence is not literal in prompt_en",
                "phrases": list(dict.fromkeys(missing_literal)),
            }
        )

    outcome_claim_fragments = (
        "viewer feels",
        "audience feels",
        "makes the viewer feel",
        "evokes empathy",
        "creates attachment",
        "emotionally moving",
        "immersive experience",
        "memorable image",
        "trustworthy product",
    )
    weak_evidence_tokens = {
        "anime",
        "beautiful",
        "cinematic",
        "cute",
        "dramatic",
        "emotional",
        "kawaii",
        "moe",
        "photorealistic",
        "subculture",
    }
    invalid_claims = []
    weak_only = []
    youth_morphology = []
    for phrase in evidence_phrases:
        lower = phrase.lower()
        if any(fragment in lower for fragment in outcome_claim_fragments):
            invalid_claims.append(phrase)
        tokens = {token for token in re.findall(r"[a-z]+", lower) if token}
        if tokens and tokens <= weak_evidence_tokens:
            weak_only.append(phrase)
        if attachment_channel != "none" and any(
            fragment in lower
            for fragment in ("baby face", "childlike", "child-like", "youthful proportions", "oversized eyes")
        ):
            youth_morphology.append(phrase)
    if invalid_claims:
        failures.append(
            {
                "check": "viewer_experience_outcome_claim",
                "reason": "prompt evidence must show a visible cause rather than assert a viewer outcome",
                "phrases": invalid_claims,
            }
        )
    if weak_only:
        failures.append(
            {
                "check": "viewer_experience_weak_evidence",
                "reason": "genre labels and style or affect adjectives alone are not viewer-experience evidence",
                "phrases": weak_only,
            }
        )
    if youth_morphology:
        failures.append(
            {
                "check": "viewer_experience_attachment",
                "reason": "face or youth morphology cannot serve as attachment evidence",
                "phrases": youth_morphology,
            }
        )
    return failures


def audit_creative_direction(
    pack: dict[str, Any],
    composed: dict[str, Any],
    prompt_en: str,
) -> list[dict[str, Any]]:
    pack = photo_native_pack.read_view(pack)
    contract = pack.get("creative_direction")
    if not isinstance(contract, dict) or not contract.get("enabled"):
        return []

    failures: list[dict[str, Any]] = []
    brief = composed.get("creative_brief")
    if not isinstance(brief, dict):
        return [
            {
                "check": "creative_direction",
                "reason": "enabled creative-direction pack requires a creative_brief object",
            }
        ]

    baseline_contract = contract.get("ordinary_baseline") if isinstance(contract.get("ordinary_baseline"), dict) else {}
    minimum_cliches = int(baseline_contract.get("minimum_cliches", 3) or 3)
    ordinary_baseline = nonempty_string_list(brief.get("ordinary_baseline"))
    rejected_cliches = nonempty_string_list(brief.get("rejected_cliches"))
    if len(ordinary_baseline) < minimum_cliches or normalized_unique_count(ordinary_baseline) < minimum_cliches:
        failures.append(
            {
                "check": "creative_direction_baseline",
                "reason": "creative brief must name distinct ordinary first-answer cliches before ideation",
                "minimum": minimum_cliches,
                "actual": len(ordinary_baseline),
            }
        )
    if len(rejected_cliches) < minimum_cliches or normalized_unique_count(rejected_cliches) < minimum_cliches:
        failures.append(
            {
                "check": "creative_direction_cliche_rejection",
                "reason": "creative brief must explicitly reject distinct cliches",
                "minimum": minimum_cliches,
                "actual": len(rejected_cliches),
            }
        )

    proposal_contract = contract.get("proposal_contract") if isinstance(contract.get("proposal_contract"), dict) else {}
    minimum_proposals = int(proposal_contract.get("minimum_proposals", 4) or 4)
    required_proposal_fields = [str(item) for item in proposal_contract.get("required_fields") or [] if str(item)]
    allowed_operator_ids = {
        str(item.get("id"))
        for item in proposal_contract.get("operators") or []
        if isinstance(item, dict) and str(item.get("id") or "")
    }
    proposals = brief.get("proposals")
    if not isinstance(proposals, list):
        proposals = []
    if len(proposals) < minimum_proposals:
        failures.append(
            {
                "check": "creative_direction_proposals",
                "reason": "creative brief has too few concept proposals",
                "minimum": minimum_proposals,
                "actual": len(proposals),
            }
        )

    proposal_by_id: dict[str, dict[str, Any]] = {}
    operator_ids: list[str] = []
    signature_phrases: dict[str, str] = {}
    for index, proposal in enumerate(proposals):
        if not isinstance(proposal, dict):
            failures.append(
                {
                    "check": "creative_direction_proposals",
                    "reason": "every concept proposal must be an object",
                    "index": index,
                }
            )
            continue
        missing = []
        for field in required_proposal_fields:
            value = proposal.get(field)
            if field == "visible_consequences":
                if len(nonempty_string_list(value)) < 2:
                    missing.append(field)
            elif not isinstance(value, str) or not value.strip():
                missing.append(field)
        if missing:
            failures.append(
                {
                    "check": "creative_direction_proposals",
                    "reason": "concept proposal is missing required developed fields",
                    "index": index,
                    "fields": missing,
                }
            )
        proposal_id = str(proposal.get("id") or "").strip()
        operator_id = str(proposal.get("operator_id") or "").strip()
        if proposal_id:
            if proposal_id in proposal_by_id:
                failures.append(
                    {
                        "check": "creative_direction_proposals",
                        "reason": "concept proposal ids must be unique",
                        "id": proposal_id,
                    }
                )
            proposal_by_id[proposal_id] = proposal
            signature_phrases[proposal_id] = str(proposal.get("signature_phrase") or "").strip()
        if operator_id:
            operator_ids.append(operator_id)
            if allowed_operator_ids and operator_id not in allowed_operator_ids:
                failures.append(
                    {
                        "check": "creative_direction_proposals",
                        "reason": "concept proposal uses an operator outside the pack contract",
                        "id": proposal_id or None,
                        "operator_id": operator_id,
                    }
                )
        if "rule_breaks" in proposal or isinstance(proposal.get("rule_break"), (list, dict)):
            failures.append(
                {
                    "check": "creative_direction_rule_break",
                    "reason": "each concept proposal must contain one scalar rule_break, not a stack",
                    "id": proposal_id or None,
                }
            )

    if proposal_contract.get("distinct_operator_ids") and normalized_unique_count(operator_ids) < min(
        minimum_proposals, len(proposals)
    ):
        failures.append(
            {
                "check": "creative_direction_operators",
                "reason": "concept proposals must use distinct concept-move operators",
                "minimum_unique": min(minimum_proposals, len(proposals)),
                "actual_unique": normalized_unique_count(operator_ids),
            }
        )
    nonempty_signatures = [phrase for phrase in signature_phrases.values() if phrase]
    if normalized_unique_count(nonempty_signatures) != len(nonempty_signatures):
        failures.append(
            {
                "check": "creative_direction_proposals",
                "reason": "concept proposal signature phrases must be unique",
            }
        )

    selected_proposal_id = str(brief.get("selected_proposal_id") or "").strip()
    selected_proposal = proposal_by_id.get(selected_proposal_id)
    if not selected_proposal:
        failures.append(
            {
                "check": "creative_direction_selection",
                "reason": "selected_proposal_id must identify exactly one developed proposal",
                "selected_proposal_id": selected_proposal_id or None,
            }
        )
    selected_flags = [
        str(proposal.get("id") or "")
        for proposal in proposals
        if isinstance(proposal, dict) and proposal.get("selected") is True
    ]
    if selected_flags and selected_flags != [selected_proposal_id]:
        failures.append(
            {
                "check": "creative_direction_selection",
                "reason": "proposal selected flags conflict with selected_proposal_id",
                "selected_flags": selected_flags,
                "selected_proposal_id": selected_proposal_id or None,
            }
        )

    selected_signature = signature_phrases.get(selected_proposal_id, "")
    if selected_signature and not text_contains_term(prompt_en, selected_signature):
        failures.append(
            {
                "check": "creative_direction_binding",
                "reason": "selected proposal signature phrase is not literal in prompt_en",
                "phrase": selected_signature,
            }
        )
    mixed_signatures = [
        phrase
        for proposal_id, phrase in signature_phrases.items()
        if proposal_id != selected_proposal_id and phrase and text_contains_term(prompt_en, phrase)
    ]
    if mixed_signatures:
        failures.append(
            {
                "check": "creative_direction_selection",
                "reason": "prompt_en mixes signature phrases from unselected proposals",
                "phrases": mixed_signatures,
            }
        )

    selected_contract = (
        contract.get("selected_concept_contract")
        if isinstance(contract.get("selected_concept_contract"), dict)
        else {}
    )
    selected_concept = brief.get("selected_concept")
    if not isinstance(selected_concept, dict):
        failures.append(
            {
                "check": "creative_direction_selection",
                "reason": "creative brief requires a selected_concept object",
            }
        )
        return failures
    required_selected_fields = [str(item) for item in selected_contract.get("required_fields") or [] if str(item)]
    missing_selected_fields = [field for field in required_selected_fields if field not in selected_concept]
    if missing_selected_fields:
        failures.append(
            {
                "check": "creative_direction_selection",
                "reason": "selected concept is missing required fields",
                "fields": missing_selected_fields,
            }
        )
    if str(selected_concept.get("proposal_id") or "") != selected_proposal_id:
        failures.append(
            {
                "check": "creative_direction_selection",
                "reason": "selected concept proposal_id does not match selected_proposal_id",
            }
        )
    if "rule_breaks" in selected_concept or not isinstance(selected_concept.get("rule_break"), str):
        failures.append(
            {
                "check": "creative_direction_rule_break",
                "reason": "selected concept must contain exactly one scalar rule_break",
            }
        )
    if selected_proposal:
        for field in ("familiar_anchor", "rule_break", "aboutness"):
            if str(selected_concept.get(field) or "").strip() != str(selected_proposal.get(field) or "").strip():
                failures.append(
                    {
                        "check": "creative_direction_selection",
                        "reason": "selected concept diverges from the chosen proposal",
                        "field": field,
                    }
                )
        if nonempty_string_list(selected_concept.get("visible_consequences")) != nonempty_string_list(
            selected_proposal.get("visible_consequences")
        ):
            failures.append(
                {
                    "check": "creative_direction_selection",
                    "reason": "selected concept consequence chain diverges from the chosen proposal",
                    "field": "visible_consequences",
                }
            )

    minimum_consequences = int(selected_contract.get("minimum_visible_consequences", 2) or 2)
    consequences = nonempty_string_list(selected_concept.get("visible_consequences"))
    if len(consequences) < minimum_consequences or normalized_unique_count(consequences) < minimum_consequences:
        failures.append(
            {
                "check": "creative_direction_consequences",
                "reason": "selected rule break needs distinct visible consequences",
                "minimum": minimum_consequences,
                "actual": len(consequences),
            }
        )
    minimum_reveal_steps = int(selected_contract.get("minimum_reveal_steps", 3) or 3)
    reveal_path = nonempty_string_list(selected_concept.get("reveal_path"))
    if len(reveal_path) < minimum_reveal_steps or normalized_unique_count(reveal_path) < minimum_reveal_steps:
        failures.append(
            {
                "check": "creative_direction_reveal",
                "reason": "selected concept needs a staged viewer discovery path",
                "minimum": minimum_reveal_steps,
                "actual": len(reveal_path),
            }
        )

    grammar_fields = [str(item) for item in selected_contract.get("authorial_grammar_fields") or [] if str(item)]
    authorial_grammar = selected_concept.get("authorial_grammar")
    if not isinstance(authorial_grammar, dict):
        authorial_grammar = {}
    missing_grammar = [
        field
        for field in grammar_fields
        if not isinstance(authorial_grammar.get(field), str) or not str(authorial_grammar.get(field)).strip()
    ]
    if missing_grammar:
        failures.append(
            {
                "check": "creative_direction_authorial_grammar",
                "reason": "authorial voice must be expressed as concrete frame, time, omission, and material decisions",
                "fields": missing_grammar,
            }
        )

    evidence = selected_concept.get("prompt_evidence")
    if not isinstance(evidence, dict):
        failures.append(
            {
                "check": "creative_direction_binding",
                "reason": "selected concept requires literal prompt_evidence",
            }
        )
        return failures

    scalar_evidence_fields = ("familiar_anchor_phrase", "rule_break_phrase")
    evidence_phrases: list[str] = []
    for field in scalar_evidence_fields:
        phrase = str(evidence.get(field) or "").strip()
        if not phrase:
            failures.append(
                {
                    "check": "creative_direction_binding",
                    "reason": "prompt evidence field is missing",
                    "field": field,
                }
            )
        else:
            evidence_phrases.append(phrase)
    for field, minimum in (("visible_consequence_phrases", minimum_consequences), ("reveal_path_phrases", minimum_reveal_steps)):
        phrases = nonempty_string_list(evidence.get(field))
        if len(phrases) < minimum:
            failures.append(
                {
                    "check": "creative_direction_binding",
                    "reason": "prompt evidence list is too short",
                    "field": field,
                    "minimum": minimum,
                    "actual": len(phrases),
                }
            )
        evidence_phrases.extend(phrases)

    grammar_evidence = evidence.get("authorial_grammar_phrases")
    if not isinstance(grammar_evidence, dict):
        grammar_evidence = {}
    missing_grammar_evidence = [
        field
        for field in grammar_fields
        if not isinstance(grammar_evidence.get(field), str) or not str(grammar_evidence.get(field)).strip()
    ]
    if missing_grammar_evidence:
        failures.append(
            {
                "check": "creative_direction_binding",
                "reason": "each authorial grammar decision requires literal prompt evidence",
                "fields": missing_grammar_evidence,
            }
        )
    evidence_phrases.extend(
        str(grammar_evidence.get(field) or "").strip()
        for field in grammar_fields
        if str(grammar_evidence.get(field) or "").strip()
    )

    missing_literal_phrases = [phrase for phrase in evidence_phrases if not text_contains_term(prompt_en, phrase)]
    if missing_literal_phrases:
        failures.append(
            {
                "check": "creative_direction_binding",
                "reason": "declared creative evidence is not literal in prompt_en",
                "phrases": list(dict.fromkeys(missing_literal_phrases)),
            }
        )
    if normalized_unique_count(evidence_phrases) != len(evidence_phrases):
        failures.append(
            {
                "check": "creative_direction_binding",
                "reason": "creative evidence fields must point to distinct visible decisions",
            }
        )

    touch = pack.get("artistic_final_touch") if isinstance(pack.get("artistic_final_touch"), dict) else {}
    final_touch = str(touch.get("final_sentence_en") or "").strip().lower()
    borrowed_touch_phrases = [
        phrase
        for phrase in grammar_evidence.values()
        if isinstance(phrase, str)
        and phrase.strip()
        and final_touch
        and (phrase.strip().lower() in final_touch or final_touch in phrase.strip().lower())
    ]
    if borrowed_touch_phrases:
        failures.append(
            {
                "check": "creative_direction_authorial_grammar",
                "reason": "fixed artistic_final_touch wording is surface craft, not evidence of authorial voice",
                "phrases": borrowed_touch_phrases,
            }
        )
    return failures


def audit_global_retrieval(pack,source_data,query_context=None):
    return global_audit.audit(pack,source_data,query_context if query_context is not None else _BOUND_QUERY_CONTEXT.get())



_BOUND_AUDIT_SOURCE = contextvars.ContextVar("photo_audit_source", default=None)
_BOUND_OWNER_SELECTIONS = contextvars.ContextVar("photo_owner_selections",default=None)
_BOUND_NATIVE_INTERPRETATIONS = contextvars.ContextVar("photo_native_interpretations",default={})
_BOUND_QUERY_CONTEXT = contextvars.ContextVar("photo_audit_query", default=None)


def _audit_source_data():
    bound=_BOUND_AUDIT_SOURCE.get()
    if bound is None:raise ValueError('native bound generation/source required')
    return bound



def audit_candidate_semantic_contracts(
    pack: dict[str, Any],
    prompt_en: str,
    chosen: set[str],
    candidates: dict[str, dict[str, Any]],
    interpretations: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """Bind optional semantic units to full adopted component/relationship evidence."""
    pack = photo_native_pack.read_view(pack)
    version = pack.get("candidate_semantic_surface_version")
    bundles = pack.get("candidate_bundles")
    failures: list[dict[str, Any]] = []

    def fail(candidate_id: str, reason: str) -> None:
        failures.append(
            {"check": "candidate_semantic_contract", "candidate_id": candidate_id, "reason": reason}
        )

    if (
        pack.get("contract_version") != "photo-candidate-pack/v10"
        or version != photo_candidate_semantics.SURFACE_VERSION
    ):
        fail("", "semantic-unit candidates require the declared modern v10 surface version")
        return failures
    if (
        not isinstance(bundles, dict)
        or bundles.get("contract_version") != photo_candidate_semantics.BUNDLE_VERSION
        or bundles.get("adoption") != "optional"
        or bundles.get("candidate_order") != "seed_shuffled_non_preferential"
    ):
        fail("", "candidate bundles require their versioned optional non-ranked contract")
        return failures
    # Load from this auditor's skill snapshot, never a path asserted by a pack.
    # Recompute admission instead of trusting its published hash or booleans.
    source_data = {}
    try:
        source_data = _audit_source_data()
        expected_bundles = candidate_semantics_generator.candidate_pack_candidate_bundles(
            source_data, pack
        )
        comparable=lambda contract: {**contract,'candidates':[photo_candidate_semantics.bundle_audit_material(row)
            for row in contract.get('candidates',[])]}
        if comparable(bundles) != comparable(expected_bundles):
            fail(
                "",
                "candidate bundle contents or joint admission differ from the same source snapshot and frozen core",
            )
    except (OSError, TypeError, ValueError, KeyError) as exc:
        fail("", f"candidate bundle source recomputation failed: {exc}")
    open_dimensions = set(
        ((pack.get("authorial_core") or {}).get("intent_lock") or {}).get("open_dimensions") or []
    )
    ordinary = {
        str(row.get("id") or ""): row
        for payload in (photo_native_pack.role_cards(pack) or {}).values()
        for row in payload.get("candidates") or []
        if isinstance(row, dict)
    }
    bundle_rows = bundles.get("candidates") or []
    bundle_ids = [str(row.get("id") or "") for row in bundle_rows if isinstance(row, dict)]
    if len(bundle_ids) != len(bundle_rows) or len(bundle_ids) != len(set(bundle_ids)):
        fail("", "candidate bundles require unique object IDs")
    for bundle in bundle_rows:
        if not isinstance(bundle, dict):
            continue
        candidate_id = str(bundle.get("id") or "")
        if bundle.get('native_bundle_contract') == photo_candidate_semantics.NATIVE_BUNDLE_CONTRACT:
            if bundle.get('source_contract_sha256') != photo_candidate_semantics.digest(
                    photo_candidate_semantics.bundle_source_material(bundle)):
                fail(candidate_id,'native selected-member presentation differs from its bound source')
            # Exact source recomputation above and whole adoption below bind
            # every local/joint effect and actual selected dependency. The
            # historical all-member union is not a native identity contract.
            continue
        if (
            bundle.get("source_contract_sha256")
            != photo_candidate_semantics.digest(
                photo_candidate_semantics.bundle_source_material(bundle)
            )
            or bundle.get("adoption") != "optional"
            or bundle.get("profile_activation") != "independent_request_evidence_only"
            or (bundle.get("selection_contract") or {}).get("associated_profiles_are_not_promoted")
            is not True
        ):
            fail(
                candidate_id,
                "bundle source contract changed or associated profiles acquired automatic authority",
            )
        members = bundle.get("member_candidates") or []
        if bundle.get('realization_choices'):
            # Each full alternative is source-recomputed above. Never union
            # member effects or conflicts across mutually exclusive choices.
            choices=bundle['realization_choices']
            realization_ids=[row.get('realization_id') for row in choices]
            if len(realization_ids)!=len(set(realization_ids)) or not all(realization_ids):
                fail(candidate_id,'conditional bundle requires unique complete realizations')
            for choice in choices:
                selected_members=choice.get('member_candidates') or []
                dims={d for member in selected_members for d in member.get('affected_dimensions') or []}
                if (not selected_members or dims!=set(choice.get('affected_dimensions') or [])
                        or not dims<=open_dimensions
                        or any(not native_property_effects_allowed(pack.get('authorial_core') or {},
                                    member.get('affected_dimensions') or [],member.get('affected_properties',[]),
                                    candidate_id=member.get('id'),realization_id=member.get('realization_id'))
                               for member in selected_members)
                        or choice.get('source_contract_sha256')!=photo_candidate_semantics.digest(photo_candidate_semantics.bundle_source_material(choice))):
                    fail(candidate_id,'conditional bundle choice has altered or closed member effects')
            continue
        member_ids = {str(member.get("id") or "") for member in members if isinstance(member, dict)}
        dimensions = {
            dimension
            for member in members
            if isinstance(member, dict)
            for dimension in member.get("affected_dimensions") or []
        }
        joint_admission = bundle.get("joint_admission")
        if (
            len(member_ids) != len(members)
            or not member_ids
            or any(not member.get("affected_dimensions") for member in members)
            or dimensions != set(bundle.get("affected_dimensions") or [])
            or not dimensions.issubset(open_dimensions)
            or (
                not joint_admission
                and (
                    not member_ids.issubset(ordinary)
                    or any(
                        (ordinary.get(member_id, {}).get("applicability") or {}).get("status")
                        != "eligible"
                        for member_id in member_ids
                    )
                )
            )
            or any(
                member_ids.intersection(ordinary.get(member_id, {}).get("conflicts_with") or [])
                for member_id in member_ids
            )
        ):
            fail(
                candidate_id,
                "all bundle members must remain individually eligible, conflict-free and scoped to open dimensions",
            )
        components = bundle.get("components") or []
        component_ids = [
            str(component.get("id") or "")
            for component in components
            if isinstance(component, dict)
        ]
        if (
            not components
            or len(component_ids) != len(components)
            or len(component_ids) != len(set(component_ids))
            or any(
                not component.get("concept_units") or component.get("minimum_realizations") != 1
                for component in components
            )
        ):
            fail(
                candidate_id, "bundle component groups must retain every authored alternative group"
            )
        inherited_conflicts = {
            conflict
            for member_id in member_ids
            for conflict in ordinary.get(member_id, {}).get("conflicts_with") or []
        }
        if inherited_conflicts != set(bundle.get("conflicts_with") or []):
            fail(candidate_id, "bundle must preserve every member conflict")
        if candidate_id in chosen:
            expanded_chosen = set(chosen)
            for other in bundle_rows:
                if isinstance(other, dict) and other.get("id") in chosen:
                    expanded_chosen.update(
                        member["id"] for member in other.get("member_candidates") or []
                    )
            if inherited_conflicts.intersection(expanded_chosen):
                fail(
                    candidate_id,
                    "selected bundle conflicts with another selected candidate or bundle member",
                )

    by_id = {str(row.get("candidate_id") or ""): row for row in interpretations}
    for candidate_id, candidate in candidates.items():
        if candidate.get("semantic_surface_version") != photo_candidate_semantics.SURFACE_VERSION:
            continue
        if (
            not candidate.get("concept_units")
            or candidate.get("concept_terms") != candidate.get("concept_units")
            or candidate.get("adoption") != "optional"
        ):
            fail(
                candidate_id,
                "semantic-unit candidates must preserve their unordered authored units and optional adoption",
            )
        relations = candidate.get("relations") or []
        relation_ids = [
            str(relation.get("id") or "") for relation in relations if isinstance(relation, dict)
        ]
        if (
            len(relation_ids) != len(relations)
            or len(relation_ids) != len(set(relation_ids))
            or any(
                not all(
                    str(relation.get(key) or "").strip()
                    for key in ("id", "type", "subject", "object")
                )
                for relation in relations
            )
        ):
            fail(
                candidate_id,
                "candidate relations require unique IDs and explicit direction, subject and object",
            )
        if candidate_id not in chosen:
            continue
        if candidate_id in source_data["candidates"] and source_data:
            source_entry = candidate_semantics_generator.candidate_pack_slot_entry_by_id(
                source_data, str(candidate.get("slot") or ""), str(candidate.get("entry_id") or "")
            )
            if (source_data['candidates'][candidate_id]['effects'].get('realizations')):
                import photo_candidate_corpus as corpus
                source_entry=corpus.entry(source_data,candidate_id,realization_id=candidate.get('realization_id'),owner_selections=_BOUND_OWNER_SELECTIONS.get())
            if source_entry:
                trusted = photo_candidate_semantics.semantic_source(
                    source_entry, str(candidate.get("slot") or ""), source_data.get("candidate_semantic_policy")
                )
                resolved_owner_effects=False
                if (candidate.get('native_bundle_contract') == photo_candidate_semantics.NATIVE_BUNDLE_CONTRACT
                        or candidate.get('selected_profile_contract') or source_entry.get('owner_selection_requirements')):
                    import photo_semantic_evidence as native
                    import photo_candidate_corpus as corpus
                    interpretation=by_id.get(candidate_id,{})
                    selected_entry=corpus.entry(source_data,candidate_id,
                        realization_id=interpretation.get('realization_id','base'),
                        dependency_selections=interpretation.get('dependency_selections'),owner_selections=_BOUND_OWNER_SELECTIONS.get())
                    try:
                        dims,props,_=native.permission_scope(selected_entry,pack['authorial_core'])
                    except (ValueError,KeyError,TypeError) as error:
                        fail(candidate_id, 'selected owner/effect resolution failed: '+str(error))
                        continue
                    trusted.update(affected_dimensions=dims,affected_properties=props);resolved_owner_effects=True
                if (candidate.get("affected_properties", []) != trusted.get("affected_properties", [])
                        or candidate.get("affected_dimensions") != trusted["affected_dimensions"]
                        or not native_property_effects_allowed(
                            pack.get("authorial_core") or {}, trusted["affected_dimensions"],
                            trusted.get("affected_properties", []), candidate_id=None if resolved_owner_effects else candidate_id,
                            realization_id=candidate.get("realization_id"))):
                    fail(candidate_id, "selected property effects must match the source and preserve requester property locks")
        interpretation = by_id.get(candidate_id, {})
        for field, expected_ids in (
            (
                "component_evidence",
                {str(component["id"]) for component in candidate.get("components") or []},
            ),
            ("relation_evidence", set(relation_ids)),
        ):
            evidence = interpretation.get(field)
            if not expected_ids and evidence is None:
                continue
            if (
                not isinstance(evidence, dict)
                or set(evidence) != expected_ids
                or any(
                    not isinstance(value, str)
                    or not value.strip()
                    or not text_contains_term(prompt_en, value)
                    for value in evidence.values()
                )
            ):
                fail(
                    candidate_id,
                    f"{field} must cover the entire selected contract with literal final-prompt phrases",
                )
    failures.extend(audit_declared_candidate_contexts(
        pack, prompt_en, chosen, candidates, interpretations
    ))
    return failures


def audit_declared_candidate_contexts(
    pack: dict, prompt_en: str, chosen: set[str], candidates: dict, interpretations: list[dict]
) -> list[dict]:
    """Keep source-authored context alternatives conditional on actual adoption."""
    pack = photo_native_pack.read_view(pack)
    core = pack.get("authorial_core") or {}
    controls = pack.get("creative_controls") or {}
    subject_category = authored_subject_category(
        core.get("semantic_assertions") or [], controls.get("context") or {}
    ) or "unknown"
    allowed = set((core.get("intent_lock") or {}).get("open_dimensions") or [])
    by_id = {row.get("candidate_id"): row for row in interpretations}
    failures = []
    for candidate_id in sorted(chosen):
        candidate = candidates.get(candidate_id, {})
        contract = candidate.get("context_prerequisites")
        if not isinstance(contract, dict) or contract.get("contract_version") != photo_candidate_context.ALTERNATIVE_VERSION:
            continue
        review = by_id.get(candidate_id, {}).get("context_review")
        failures.extend(photo_candidate_context.audit_context(
            candidate, review if isinstance(review, dict) else {},
            prompt_en=prompt_en, core=core, brief={}, subject_category=subject_category,
            allowed=allowed, scope_dimensions=allowed, check="candidate_context_prerequisites",
        ))
    return failures


def audit_candidate_interpretations(
    pack: dict[str, Any],
    composed: dict[str, Any],
    prompt_en: str,
    chosen: set[str],
    candidate_objects: dict[str, dict[str, Any]],
) -> list[dict[str, Any]]:
    """Require authorship evidence for every ordinary current candidate choice."""
    pack = photo_native_pack.read_view(pack)

    contract_version = str(pack.get("contract_version") or "")
    if contract_version not in {
        "photo-candidate-pack/v10",
    }:
        return []
    brief_field = (
        "creative_augmentation_brief"
        if contract_version in {"photo-candidate-pack/v10"}
        else "augmentation_brief"
    )
    augmentation_brief = (
        composed.get(brief_field)
        if isinstance(composed.get(brief_field), dict)
        else {}
    )
    transformed_augmentation_ids = {
        str(row.get("candidate_id") or "")
        for row in augmentation_brief.get("decisions") or []
        if isinstance(row, dict)
        and str(row.get("decision") or "") == "transformed"
        and str(row.get("candidate_id") or "")
    }
    required_ids = chosen - transformed_augmentation_ids
    rows = [
        row
        for row in composed.get("candidate_interpretations") or []
        if isinstance(row, dict)
    ]
    row_ids = [str(row.get("candidate_id") or "") for row in rows]
    failures: list[dict[str, Any]] = []
    semantic_evidence_rows = rows + [row for row in augmentation_brief.get("decisions") or []
                                     if isinstance(row, dict) and row.get("decision") == "transformed"]
    import photo_candidate_realizations as realizations
    by_id={row.get('candidate_id'):row for row in semantic_evidence_rows}
    candidate_objects=copy.deepcopy(candidate_objects)
    for cid in chosen:
        try:
            candidate_objects[cid]=realizations.selected_view(candidate_objects.get(cid,{}),by_id.get(cid,{}))
            import photo_semantic_evidence as native
            import photo_candidate_corpus as corpus
            interpretation=by_id.get(cid,{})
            source=_audit_source_data()
            if cid in source['candidates']:
                selected=corpus.entry(source,cid,realization_id=interpretation.get('realization_id'),
                    dependency_selections=interpretation.get('dependency_selections'),owner_selections=_BOUND_OWNER_SELECTIONS.get())
                if selected.get('owner_selection_requirements'):
                    dims,props,_=native.permission_scope(selected,pack['authorial_core'])
                    candidate_objects[cid].update(affected_dimensions=dims,affected_properties=props,
                        applicability={'status':'eligible','source':'postcore_explicit_owner_binding'})
            if candidate_objects[cid].get('native_bundle_contract') == photo_candidate_semantics.NATIVE_BUNDLE_CONTRACT:
                interpretation=by_id.get(cid,{})
                candidate_objects[cid]=photo_candidate_semantics.native_bundle_view(_audit_source_data(),
                    candidate_objects[cid],pack,interpretation.get('realization_id','base'),
                    interpretation.get('dependency_selections'),owner_selections=_BOUND_OWNER_SELECTIONS.get())
        except ValueError as error:
            failures.append({'check':'candidate_realization','candidate_id':cid,'reason':str(error)})
    failures.extend(audit_candidate_semantic_contracts(pack, prompt_en, chosen, candidate_objects, semantic_evidence_rows))
    if len(row_ids) != len(set(row_ids)):
        failures.append(
            {
                "check": "candidate_interpretations",
                "reason": "each chosen candidate may have only one authorial interpretation",
            }
        )
    missing = sorted(required_ids - set(row_ids))
    unexpected = sorted(set(row_ids) - required_ids)
    if missing or unexpected:
        failures.append(
            {
                "check": "candidate_interpretations",
                "reason": (
                    "candidate_interpretations must cover every non-augmentation chosen candidate "
                    "exactly once and no others"
                ),
                "missing": missing,
                "unexpected": unexpected,
            }
        )

    for row in rows:
        candidate_id = str(row.get("candidate_id") or "")
        if candidate_id not in required_ids:
            continue
        interpretation = str(row.get("artistic_interpretation") or "").strip()
        transformation = str(row.get("transformation") or "").strip()
        evidence = str(row.get("prompt_evidence") or "").strip()
        if (
            len(authorial_evidence_tokens(interpretation)) < 3
            or len(authorial_evidence_tokens(transformation)) < 3
            or not evidence
            or not text_contains_term(prompt_en, evidence)
        ):
            failures.append(
                {
                    "check": "candidate_interpretation_authorship",
                    "reason": (
                        "each chosen candidate needs substantive artistic interpretation, transformation, "
                        "and literal prompt evidence"
                    ),
                    "candidate_id": candidate_id,
                }
            )
            continue
        candidate = candidate_objects.get(candidate_id, {})
        core = pack.get("authorial_core") or {}
        lock = core.get("intent_lock") or {}
        if intent_property_locks(lock):
            effects = candidate.get("affected_dimensions") or []
            baseline_retained = row.get("realization") == "baseline" and text_contains_term(str(core.get("baseline_prompt_en") or ""), evidence)
            if not baseline_retained and (
                not effects
                or not native_property_effects_allowed(core, effects, candidate.get("affected_properties", []), candidate_id=candidate_id, realization_id=row.get("realization_id"))
                or not native_property_effects_allowed(core, effects, row.get("affected_properties", []), candidate_id=candidate_id, realization_id=row.get("realization_id"))
            ):
                failures.append({"check": "candidate_interpretation_properties", "candidate_id": candidate_id,
                                 "reason": "candidate and authored effects must preserve protected properties; broad unknown garment effects are not compatible"})
        source_terms = {
            token
            for item in candidate.get("concept_terms") or []
            for token in authorial_evidence_tokens(str(item))
        }
        evidence_terms = authorial_evidence_tokens(evidence)
        new_terms = evidence_terms - source_terms
        if len(evidence_terms) < 4 or len(new_terms) < 2:
            failures.append(
                {
                    "check": "candidate_interpretation_authorship",
                    "reason": (
                        "prompt evidence must add at least two authored content words beyond the "
                        "candidate's unordered source terms"
                    ),
                    "candidate_id": candidate_id,
                    "source_terms": sorted(source_terms),
                }
            )
    return failures


def authorial_core_active_span_texts(core: dict[str, Any]) -> list[str]:
    binding = (
        core.get("request_binding")
        if isinstance(core.get("request_binding"), dict)
        else {}
    )
    return [
        str(item.get("text") or "")
        for item in binding.get("active_spans") or []
        if isinstance(item, dict) and str(item.get("text") or "")
    ]


def authorial_core_active_scope_contains(core: dict[str, Any], text: str) -> bool:
    needle = str(text or "").strip().casefold()
    return bool(needle) and any(
        needle in source.casefold() for source in authorial_core_active_span_texts(core)
    )


def authorial_core_visual_spans(core: dict[str, Any], snapshot=None) -> list[dict]:
    """Recompute configuration coverage from bound inputs, never an agent label."""
    if snapshot is not None:
        creative_controls.validate(snapshot, core.get("source_request"))
        if core.get("creative_controls_sha256") != snapshot["canonical_sha256"]:
            raise ValueError("creative controls do not match the core binding")
    visual, _ = creative_controls.split_request_spans(
        {"request_text": core.get("source_request"),
         "active_spans": (core.get("request_binding") or {}).get("active_spans", [])}, snapshot)
    return visual


def authorial_core_visual_span_texts(core: dict[str, Any], snapshot=None) -> list[str]:
    return [row["text"] for row in authorial_core_visual_spans(core, snapshot)]


def authorial_core_intent_contract_valid(
    core: dict[str, Any],
    *,
    minimum_open_dimensions: int = 2,
    creative_control_snapshot=None,
) -> bool:
    if core.get("contract_version") not in AUTHORIAL_CORE_MODERN_CONTRACT_VERSIONS:
        return True
    try:
        visual_spans = authorial_core_visual_span_texts(core, creative_control_snapshot)
    except (ValueError, TypeError, KeyError, AttributeError):
        return False
    source_request = core.get("source_request")
    binding = core.get("request_binding")
    if not isinstance(source_request, str) or not source_request or not isinstance(binding, dict):
        return False
    if (
        set(binding) - {"input_inventory"}
        != {
            "contract_version",
            "request_id",
            "request_sha256",
            "request_envelope_sha256",
            "active_spans",
        }
        or binding.get("contract_version") != REQUEST_BINDING_CONTRACT_VERSION
    ):
        return False
    if (
        re.fullmatch(
            r"[A-Za-z0-9][A-Za-z0-9._:-]{0,127}",
            str(binding.get("request_id") or ""),
        )
        is None
    ):
        return False
    if binding.get("request_sha256") != hashlib.sha256(source_request.encode("utf-8")).hexdigest():
        return False
    if re.fullmatch(r"[0-9a-f]{64}", str(binding.get("request_envelope_sha256") or "")) is None:
        return False
    spans = binding.get("active_spans")
    if not isinstance(spans, list) or not 1 <= len(spans) <= 16:
        return False
    previous_end = -1
    seen_ids: set[str] = set()
    seen_texts: set[str] = set()
    for item in spans:
        if not isinstance(item, dict) or set(item) != {"span_id", "start", "end", "text"}:
            return False
        span_id = str(item.get("span_id") or "")
        start = item.get("start")
        end = item.get("end")
        text = item.get("text")
        if (
            re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_-]{0,63}", span_id) is None
            or span_id in seen_ids
            or isinstance(start, bool)
            or isinstance(end, bool)
            or not isinstance(start, int)
            or not isinstance(end, int)
            or start < 0
            or end <= start
            or start < previous_end
            or end > len(source_request)
            or not isinstance(text, str)
            or source_request[start:end] != text
            or text.casefold() in seen_texts
        ):
            return False
        seen_ids.add(span_id)
        seen_texts.add(text.casefold())
        previous_end = end
    reconstructed_envelope = {
        "contract_version": REQUEST_ENVELOPE_CONTRACT_VERSION,
        "provenance": "requesting_user",
        "request_id": str(binding.get("request_id") or ""),
        "request_text": source_request,
        "request_sha256": str(binding.get("request_sha256") or ""),
        "active_spans": spans,
    }
    if "input_inventory" in binding:
        try:
            from photo_precore_bridge import load as _neutral_inventory_load
            reconstructed_envelope["input_inventory"] = _neutral_inventory_load("photo_semantic_witnesses").validate_input_inventory(
                binding["input_inventory"],binding["request_sha256"])
        except (ValueError,KeyError,TypeError):
            return False
    if binding.get("request_envelope_sha256") != canonical_json_sha256(reconstructed_envelope):
        return False

    intent_lock = core.get("intent_lock")
    if not isinstance(intent_lock, dict):
        return False
    if set(intent_lock) != {
        "contract_version",
        "priority",
        "semantic_anchors",
        "locked_dimensions",
        "open_dimensions",
        "augmentation_policy",
        "material_change_policy",
        "candidate_revision_policy",
        "canonical_sha256",
        "lock_id",
    }:
        return False
    lock_material = copy.deepcopy(intent_lock)
    lock_sha = str(lock_material.pop("canonical_sha256", "") or "")
    lock_id = str(lock_material.pop("lock_id", "") or "")
    allowed_dimensions = (
        AUTHORIAL_CORE_V3_INTENT_LOCK_DIMENSIONS
        if core.get("contract_version") == AUTHORIAL_CORE_V3_CONTRACT_VERSION
        else INTENT_LOCK_DIMENSIONS
    )
    if (
        intent_lock.get("contract_version")
        not in {INTENT_LOCK_CONTRACT_VERSION, INTENT_LOCK_PROPERTY_CONTRACT_VERSION}
        or intent_lock.get("priority") != "requesting_user"
        or intent_lock.get("augmentation_policy") != "open_dimensions_only_and_subordinate"
        or intent_lock.get("material_change_policy") != "rebuild_core_after_requester_input"
        or intent_lock.get("candidate_revision_policy") != "forbidden"
        or lock_sha != canonical_json_sha256(lock_material)
        or lock_id != lock_sha[:16]
    ):
        return False
    locked = intent_lock.get("locked_dimensions")
    opened = intent_lock.get("open_dimensions")
    if (
        not isinstance(locked, list)
        or not locked
        or len(locked) != len(set(str(item) for item in locked))
        or not isinstance(opened, list)
        or len(opened) < minimum_open_dimensions
        or len(opened) != len(set(str(item) for item in opened))
        or set(str(item) for item in locked) & set(str(item) for item in opened)
        or not REQUIRED_INTENT_LOCK_DIMENSIONS <= {str(item) for item in locked}
        or (set(str(item) for item in locked) | set(str(item) for item in opened))
        - allowed_dimensions
    ):
        return False
    anchors = intent_lock.get("semantic_anchors")
    if not isinstance(anchors, list) or not 1 <= len(anchors) <= 16:
        return False
    baseline = str(core.get("baseline_prompt_en") or "")
    property_lock = intent_lock.get("contract_version") == INTENT_LOCK_PROPERTY_CONTRACT_VERSION
    if property_lock and core.get("contract_version") != AUTHORIAL_CORE_V3_CONTRACT_VERSION:
        return False
    seen_anchor_ids: set[str] = set()
    seen_anchor_evidence: set[str] = set()
    seen_properties = set()
    for item in anchors:
        fields = {
            "anchor_id",
            "source_text",
            "dimension",
            "prompt_evidence",
        }
        is_property = property_lock and isinstance(item, dict) and "property" in item
        if is_property:
            fields.update({"target", "property"})
        if not isinstance(item, dict) or set(item) != fields:
            return False
        anchor_id = str(item.get("anchor_id") or "")
        source_text = str(item.get("source_text") or "")
        dimension = str(item.get("dimension") or "")
        evidence = str(item.get("prompt_evidence") or "")
        if (
            re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_-]{0,63}", anchor_id) is None
            or anchor_id in seen_anchor_ids
            or dimension not in (opened if is_property else locked)
            or len(authorial_general_content_words(source_text)) < 1
            or not any(source_text.casefold() in span.casefold() for span in visual_spans)
            or len(authorial_evidence_tokens(evidence)) < 2
            or not text_contains_term(baseline, evidence)
            or (evidence.casefold() in seen_anchor_evidence and not is_property)
        ):
            return False
        if is_property:
            key = (dimension, item["target"], item["property"])
            if (
                any(
                    not isinstance(item[k], str)
                    or re.fullmatch(r"[a-z][a-z0-9_]*(?:\.[a-z][a-z0-9_]*)*", item[k]) is None
                    for k in ("target", "property")
                )
                or key in seen_properties
            ):
                return False
            seen_properties.add(key)
        seen_anchor_ids.add(anchor_id)
        seen_anchor_evidence.add(evidence.casefold())
    if {str(item.get("dimension") or "") for item in anchors if "property" not in item} != {
        str(item) for item in locked
    }:
        return False
    if any(
        not any(
            str(anchor.get("source_text") or "").casefold() in str(span_text).casefold()
            for anchor in anchors
        )
        for span_text in visual_spans
    ):
        return False
    definitions = core.get("user_definitions")
    if not isinstance(definitions, list) or len(definitions) > 8:
        return False
    seen_definition_terms: set[str] = set()
    for item in definitions:
        if not isinstance(item, dict) or set(item) != {
            "term",
            "source_text",
            "interpreted_meaning",
            "prompt_evidence",
        }:
            return False
        term = str(item.get("term") or "").strip()
        source_text = str(item.get("source_text") or "").strip()
        evidence = str(item.get("prompt_evidence") or "").strip()
        if (
            not term
            or term.casefold() in seen_definition_terms
            or source_text.casefold() not in {span.casefold() for span in visual_spans}
            or source_text.casefold() == term.casefold()
            or len(authorial_general_content_words(str(item.get("interpreted_meaning") or ""))) < 4
            or len(authorial_evidence_tokens(evidence)) < 4
            or not text_contains_term(baseline, evidence)
        ):
            return False
        seen_definition_terms.add(term.casefold())
    runtime_labels = nonempty_string_list(core.get("runtime_forbidden_labels"))
    if len(runtime_labels) > 12 or len(runtime_labels) != len(
        {item.casefold() for item in runtime_labels}
    ):
        return False
    if any(
        not authorial_core_active_scope_contains(core, label) or text_contains_term(baseline, label)
        for label in runtime_labels
    ):
        return False
    exclusions = nonempty_string_list(core.get("user_exclusions"))
    if any(not authorial_core_active_scope_contains(core, exclusion) for exclusion in exclusions):
        return False
    if {item.casefold() for item in runtime_labels} & {item.casefold() for item in exclusions}:
        return False
    return True


def authorial_core_v3_semantic_contract_valid(core: dict[str, Any], *, creative_control_snapshot=None) -> bool:
    if core.get("contract_version") != AUTHORIAL_CORE_V3_CONTRACT_VERSION:
        return True
    assertions = core.get("semantic_assertions")
    intent_lock = (
        core.get("intent_lock")
        if isinstance(core.get("intent_lock"), dict)
        else {}
    )
    binding = (
        core.get("request_binding")
        if isinstance(core.get("request_binding"), dict)
        else {}
    )
    if not isinstance(assertions, list) or len(assertions) > 64:
        return False
    try:
        authored_subject_category(assertions, (creative_control_snapshot or {}).get("context"))
        visual_spans = authorial_core_visual_spans(core, creative_control_snapshot)
        from photo_precore_bridge import load as _neutral_load
        _native_witnesses=_neutral_load('photo_semantic_witnesses')
        _native_witnesses.read(assertions, visual_spans, core.get('baseline_prompt_en', ''),intent_lock=intent_lock,request_binding=binding)
    except (ValueError, TypeError, KeyError, AttributeError):
        return False
    span_ids = {
        str(item.get("source_span_id", item.get("span_id")) or "")
        for item in visual_spans
        if isinstance(item, dict)
    }
    locked = {str(value) for value in intent_lock.get("locked_dimensions") or []}
    opened = {str(value) for value in intent_lock.get("open_dimensions") or []}
    baseline = str(core.get("baseline_prompt_en") or "")
    seen_ids: set[str] = set()
    required_character_count = 0

    def valid_character_relation(relation: Any) -> bool:
        if not isinstance(relation, dict):
            return False
        operator = str(relation.get("operator") or "")
        identifier = r"[a-z][a-z0-9_]{0,63}"
        if operator == "same_target" and set(relation) == {
            "operator",
            "members",
        }:
            members = nonempty_string_list(relation.get("members"))
            return bool(
                2 <= len(members) <= 8
                and len(members) == len(set(members))
                and "relationship_target" in members
                and set(members) <= CHARACTER_RESPONSE_RELATION_MEMBERS
                and all(re.fullmatch(identifier, value) for value in members)
            )
        if operator == "contrasts" and set(relation) == {
            "operator",
            "left",
            "right",
        }:
            left = str(relation.get("left") or "")
            right = str(relation.get("right") or "")
            return bool(
                left != right
                and {left, right} <= CHARACTER_RESPONSE_RELATION_MEMBERS
                and re.fullmatch(identifier, left)
                and re.fullmatch(identifier, right)
            )
        if operator == "temporal_order" and set(relation) == {
            "operator",
            "first",
            "then",
        }:
            first = str(relation.get("first") or "")
            then = str(relation.get("then") or "")
            return bool(
                first != then
                and {first, then} <= CHARACTER_RESPONSE_RELATION_MEMBERS
                and re.fullmatch(identifier, first)
                and re.fullmatch(identifier, then)
            )
        return False

    def character_relation_signature(relation: dict[str, Any]) -> tuple[Any, ...]:
        operator = str(relation.get("operator") or "")
        if operator == "same_target":
            return operator, tuple(sorted(nonempty_string_list(relation.get("members"))))
        if operator == "contrasts":
            return operator, str(relation.get("left") or ""), str(
                relation.get("right") or ""
            )
        return operator, str(relation.get("first") or ""), str(
            relation.get("then") or ""
        )

    def valid_character_relations(relations: Any) -> bool:
        if not isinstance(relations, list) or not 1 <= len(relations) <= 8:
            return False
        signatures: set[tuple[Any, ...]] = set()
        for relation in relations:
            if not valid_character_relation(relation):
                return False
            signature = character_relation_signature(relation)
            if signature in signatures:
                return False
            signatures.add(signature)
        return True

    for item in assertions:
        required_fields = {
            "assertion_id",
            "dimension",
            "polarity",
            "source_span_ids",
            "axes",
            "evidence",
            "affected_dimensions",
        }
        if not isinstance(item, dict) or frozenset(item) not in {
            frozenset(required_fields),
            frozenset(required_fields | {"relations"}),
        }:
            return False
        assertion_id = str(item.get("assertion_id") or "")
        dimension = str(item.get("dimension") or "")
        polarity = str(item.get("polarity") or "")
        source_span_ids = nonempty_string_list(item.get("source_span_ids"))
        affected = nonempty_string_list(item.get("affected_dimensions"))
        axes = item.get("axes") if isinstance(item.get("axes"), dict) else {}
        evidence = (
            item.get("evidence") if isinstance(item.get("evidence"), dict) else {}
        )
        relations = item.get("relations") if "relations" in item else None
        if (
            re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_-]{0,63}", assertion_id)
            is None
            or assertion_id in seen_ids
            or dimension not in AUTHORIAL_CORE_V3_INTENT_LOCK_DIMENSIONS
            or polarity not in {"required", "advisory", "excluded"}
            or not source_span_ids
            or len(source_span_ids) != len(set(source_span_ids))
            or not set(source_span_ids) <= span_ids
            or not affected
            or len(affected) != len(set(affected))
            or not set(affected) <= AUTHORIAL_CORE_V3_INTENT_LOCK_DIMENSIONS
            or (polarity == "required" and not set(affected) <= locked and not _native_witnesses.is_native_fact(item))
            or (polarity == "advisory" and not set(affected) <= opened)
            or not 1 <= len(axes) <= 16
            or len(evidence) > 16
            or (
                relations is not None
                and (
                    dimension != "character_response"
                    or not valid_character_relations(relations)
                )
            )
        ):
            return False
        seen_ids.add(assertion_id)
        if any(
            re.fullmatch(r"[a-z][a-z0-9_]{0,63}", str(key)) is None
            or not (
                isinstance(value, str)
                and bool(value.strip())
                or isinstance(value, list)
                and 1 <= len(value) <= 8
                and all(isinstance(part, str) and part.strip() for part in value)
                and len(value) == len(set(value))
            )
            for key, value in axes.items()
        ):
            return False
        if any(
            re.fullmatch(r"[a-z][a-z0-9_]{0,63}", str(key)) is None
            or not isinstance(value, str)
            or len(authorial_evidence_tokens(value)) < 2
            or not text_contains_term(baseline, value)
            for key, value in evidence.items()
        ):
            return False
        if polarity == "required" and not evidence:
            return False
        if dimension == "character_response" and polarity == "required":
            required_character_count += 1
            channels = axes.get("affect_leak_channels")
            if (
                not CHARACTER_RESPONSE_REQUIRED_AXES <= set(axes)
                or not CHARACTER_RESPONSE_REQUIRED_EVIDENCE <= set(evidence)
                or not isinstance(channels, list)
                or len(channels) != 1
            ):
                return False
    if required_character_count > 1:
        return False

    lineage = core.get("request_lineage")
    if lineage is None:
        return True
    if not isinstance(lineage, dict):
        return False
    preserved = nonempty_string_list(lineage.get("preserved_dimensions"))
    allowed = nonempty_string_list(lineage.get("allowed_changes"))
    base_valid = bool(
        re.fullmatch(
            r"[A-Za-z0-9][A-Za-z0-9._:-]{0,127}",
            str(lineage.get("parent_request_id") or ""),
        )
        and str(lineage.get("parent_request_id") or "")
        != str(binding.get("request_id") or "")
        and re.fullmatch(
            r"[0-9a-f]{64}", str(lineage.get("parent_core_sha256") or "")
        )
        and preserved
        and allowed
        and len(preserved) == len(set(preserved))
        and len(allowed) == len(set(allowed))
        and set(preserved) <= AUTHORIAL_CORE_V3_INTENT_LOCK_DIMENSIONS
        and set(allowed) <= AUTHORIAL_CORE_V3_INTENT_LOCK_DIMENSIONS
        and not set(preserved) & set(allowed)
    )
    if not base_valid:
        return False
    retry_fields = {
        "parent_request_id",
        "parent_core_sha256",
        "preserved_dimensions",
        "allowed_changes",
    }
    contract_version = str(lineage.get("contract_version") or "")
    if not contract_version:
        return set(lineage) == retry_fields
    if contract_version != REQUEST_LINEAGE_V2_CONTRACT_VERSION or set(
        lineage
    ) != retry_fields | {
        "contract_version",
        "repair_targets",
        "canonical_sha256",
    }:
        return False
    canonical_sha = str(lineage.get("canonical_sha256") or "")
    canonical_payload = {
        key: copy.deepcopy(value)
        for key, value in lineage.items()
        if key != "canonical_sha256"
    }
    if (
        re.fullmatch(r"[0-9a-f]{64}", canonical_sha) is None
        or canonical_json_sha256(canonical_payload) != canonical_sha
    ):
        return False
    targets = lineage.get("repair_targets")
    if not isinstance(targets, list) or not 1 <= len(targets) <= 8:
        return False
    seen_repair_ids: set[str] = set()
    expected_target_fields = {
        "repair_id",
        "source_span_ids",
        "importance",
        "relation_origin",
        "actor_phrase",
        "object_phrase",
        "interaction_state",
        "actor_object_contact",
        "protected_dimensions",
        "allowed_repair_axes",
        "interaction_phrase",
        "recognition_phrase",
    }
    required_action_assertions = [
        item
        for item in assertions
        if isinstance(item, dict)
        and item.get("polarity") == "required"
        and "action" in set(item.get("affected_dimensions") or [])
    ]
    for target in targets:
        if not isinstance(target, dict) or set(target) != expected_target_fields:
            return False
        repair_id = str(target.get("repair_id") or "")
        source_span_ids = nonempty_string_list(target.get("source_span_ids"))
        importance = str(target.get("importance") or "")
        relation_origin = str(target.get("relation_origin") or "")
        interaction_state = str(target.get("interaction_state") or "")
        actor_object_contact = str(target.get("actor_object_contact") or "")
        protected = nonempty_string_list(target.get("protected_dimensions"))
        repair_axes = nonempty_string_list(target.get("allowed_repair_axes"))
        actor_phrase = re.sub(r"\s+", " ", str(target.get("actor_phrase") or "")).strip()
        object_phrase = re.sub(r"\s+", " ", str(target.get("object_phrase") or "")).strip()
        interaction_phrase = re.sub(
            r"\s+", " ", str(target.get("interaction_phrase") or "")
        ).strip()
        recognition_phrase = re.sub(
            r"\s+", " ", str(target.get("recognition_phrase") or "")
        ).strip()
        origin_dimensions = preserved if relation_origin == "parent_preserved" else allowed
        if (
            re.fullmatch(r"[a-z][a-z0-9_]{0,63}", repair_id) is None
            or repair_id in seen_repair_ids
            or not source_span_ids
            or len(source_span_ids) != len(set(source_span_ids))
            or not set(source_span_ids) <= span_ids
            or importance not in RENDER_REPAIR_IMPORTANCE_VALUES
            or relation_origin not in RENDER_REPAIR_RELATION_ORIGINS
            or interaction_state not in RENDER_REPAIR_INTERACTION_STATES
            or actor_object_contact not in RENDER_REPAIR_CONTACT_EXPECTATIONS
            or (
                interaction_state
                in {"held", "wielded", "used", "handed_off", "carried", "worn"}
                and actor_object_contact == "absent"
            )
            or not protected
            or len(protected) != len(set(protected))
            or "action" not in protected
            or not set(protected) <= locked
            or not set(protected) <= set(origin_dimensions)
            or not repair_axes
            or len(repair_axes) != len(set(repair_axes))
            or not set(repair_axes) <= RENDER_REPAIR_ALLOWED_AXES
            or any(
                axis in repair_axes and dimension not in allowed
                for axis, dimension in RENDER_REPAIR_DIMENSION_AXES.items()
            )
            or len(authorial_evidence_tokens(actor_phrase)) < 1
            or len(authorial_evidence_tokens(object_phrase)) < 1
            or len(authorial_evidence_tokens(interaction_phrase)) < 4
            or len(authorial_evidence_tokens(recognition_phrase)) < 4
            or not text_contains_term(baseline, actor_phrase)
            or not text_contains_term(baseline, object_phrase)
            or not text_contains_term(baseline, interaction_phrase)
            or not text_contains_term(baseline, recognition_phrase)
            or interaction_phrase.casefold() == recognition_phrase.casefold()
            or not text_contains_term(interaction_phrase, actor_phrase)
            or not text_contains_term(interaction_phrase, object_phrase)
            or not text_contains_term(recognition_phrase, object_phrase)
        ):
            return False
        evidence_pair = {
            interaction_phrase.casefold(),
            recognition_phrase.casefold(),
        }
        if not any(
            evidence_pair
            <= {
                str(value).casefold()
                for value in (assertion.get("evidence") or {}).values()
                if str(value).strip()
            }
            for assertion in required_action_assertions
        ):
            return False
        seen_repair_ids.add(repair_id)
    return True


def expected_authorial_core_retrieval_provenance(
    core: dict[str, Any],
) -> dict[str, Any]:
    exclusions = [
        re.sub(r"\s+", " ", str(item)).strip()
        for item in core.get("user_exclusions") or []
        if re.sub(r"\s+", " ", str(item)).strip()
    ]
    fields: list[tuple[str, str]] = []
    redacted_fields: set[str] = set()

    def clean(value: Any) -> str:
        text = re.sub(r"\s+", " ", str(value or "")).strip()
        text = re.sub(r"\s+([,.!?;:])", r"\1", text)
        return re.sub(r"([.!?]){2,}", r"\1", text)

    def add(field: str, value: Any) -> None:
        text = clean(value)
        for exclusion in exclusions:
            if exclusion.isascii() and re.search(r"[A-Za-z0-9]", exclusion):
                pattern = (
                    r"(?<![A-Za-z0-9])"
                    + re.escape(exclusion)
                    + r"(?![A-Za-z0-9])"
                )
                updated = re.sub(pattern, " ", text, flags=re.IGNORECASE)
            else:
                updated = re.sub(
                    re.escape(exclusion),
                    " ",
                    text,
                    flags=re.IGNORECASE,
                )
            if updated != text:
                redacted_fields.add(field)
            text = updated
        text = clean(re.sub(r"(?:\s*[,;:/|]\s*){2,}", " ", text).strip(" ,;:/|"))
        if text:
            fields.append((field, text))

    if core.get("contract_version") in AUTHORIAL_CORE_MODERN_CONTRACT_VERSIONS:
        for value in authorial_core_active_span_texts(core):
            add("source_request_scope", creative_controls.strip_assignments(value))
    else:
        add("source_request", core.get("source_request"))
    add("interpreted_intent", core.get("interpreted_intent"))
    add("subject", core.get("subject"))
    add("setting", core.get("setting"))
    add("event", core.get("event"))
    for value in core.get("visual_priorities") or []:
        add("visual_priority", value)
    add("baseline_prompt_en", core.get("baseline_prompt_en"))
    for definition in core.get("user_definitions") or []:
        if isinstance(definition, dict):
            add("user_definition_meaning", definition.get("interpreted_meaning"))
            add("user_definition_prompt_evidence", definition.get("prompt_evidence"))
    for interpretation in core.get("interpretation_provenance") or []:
        if isinstance(interpretation, dict):
            add("interpretation_resolution", interpretation.get("resolution"))
    style = core.get("style") if isinstance(core.get("style"), dict) else {}
    add("style_domain", style.get("domain"))
    add("style_family", style.get("family"))
    for value in style.get("evidence") or []:
        add("style_evidence", value)

    deduped: list[tuple[str, str]] = []
    seen: set[str] = set()
    for field, value in fields:
        key = value.lower()
        if key in seen:
            continue
        seen.add(key)
        deduped.append((field, value))
    query = " | ".join(value for _, value in deduped)
    provenance: dict[str, Any] = {
        "contract_version": (
            "photo-retrieval-query-provenance/v2"
            if core.get("contract_version") in AUTHORIAL_CORE_MODERN_CONTRACT_VERSIONS
            else "photo-retrieval-query-provenance/v1"
        ),
        "source_authorial_core_sha256": str(core.get("canonical_sha256") or ""),
        "source_request_sha256": hashlib.sha256(
            str(core.get("source_request") or "").encode("utf-8")
        ).hexdigest(),
        "source_fields": [field for field, _ in deduped],
        "query_sha256": hashlib.sha256(query.encode("utf-8")).hexdigest(),
        "redacted_source_fields": sorted(redacted_fields),
        "excluded_term_count": len(exclusions),
        "exclusions_used_as_positive_query": False,
    }
    if core.get("contract_version") in AUTHORIAL_CORE_MODERN_CONTRACT_VERSIONS:
        binding = (
            core.get("request_binding")
            if isinstance(core.get("request_binding"), dict)
            else {}
        )
        intent_lock = (
            core.get("intent_lock")
            if isinstance(core.get("intent_lock"), dict)
            else {}
        )
        active_spans = [
            item
            for item in binding.get("active_spans") or []
            if isinstance(item, dict) and str(item.get("text") or "")
        ]
        provenance.update(
            {
                "request_envelope_sha256": str(
                    binding.get("request_envelope_sha256") or ""
                ),
                "active_scope_sha256": canonical_json_sha256(active_spans),
                "source_intent_lock_sha256": str(
                    intent_lock.get("canonical_sha256") or ""
                ),
                "runtime_forbidden_label_count": len(
                    core.get("runtime_forbidden_labels") or []
                ),
            }
        )
    return provenance


def authorial_core_interpretation_contract_valid(core: dict[str, Any], *, creative_control_snapshot=None) -> bool:
    try:
        visual_spans = authorial_core_visual_span_texts(core, creative_control_snapshot)
    except (ValueError, TypeError, KeyError, AttributeError):
        return False
    if core.get("contract_version") not in {AUTHORIAL_CORE_V3_CONTRACT_VERSION}:
        return False
    if "interpretation_provenance" not in core or "unresolved_ambiguities" not in core:
        return False
    if core.get("unresolved_ambiguities") != []:
        return False
    interpretations = core.get("interpretation_provenance")
    if not isinstance(interpretations, list) or len(interpretations) > 8:
        return False
    user_terms = {
        str(item.get("term") or "").strip().casefold()
        for item in core.get("user_definitions") or []
        if isinstance(item, dict) and str(item.get("term") or "").strip()
    }
    source_request = str(core.get("source_request") or "").casefold()
    seen_terms: set[str] = set()
    allowed_bases = {
        "agent_general_knowledge",
        "request_context",
        "public_web_research",
    }
    for item in interpretations:
        if not isinstance(item, dict) or set(item) != {
            "term",
            "source_text",
            "basis",
            "resolution",
            "sources",
        }:
            return False
        term = str(item.get("term") or "").strip()
        source_text = str(item.get("source_text") or "").strip()
        basis = str(item.get("basis") or "").strip()
        resolution = str(item.get("resolution") or "").strip()
        sources = item.get("sources")
        key = term.casefold()
        if (
            not term
            or not source_text
            or key in seen_terms
            or key in user_terms
            or source_text.casefold() not in source_request
            or (
                core.get("contract_version") in AUTHORIAL_CORE_MODERN_CONTRACT_VERSIONS
                and not any(source_text.casefold() in span.casefold() for span in visual_spans)
            )
            or basis not in allowed_bases
            or len(authorial_general_content_words(resolution)) < 4
            or not isinstance(sources, list)
            or len(sources) > 4
            or len(sources) != len(set(str(value) for value in sources))
        ):
            return False
        seen_terms.add(key)
        if basis == "public_web_research":
            if not sources or any(
                re.fullmatch(r"https?://[^\s]+", str(value), flags=re.IGNORECASE)
                is None
                for value in sources
            ):
                return False
        elif sources:
            return False
    if core.get("contract_version") in AUTHORIAL_CORE_MODERN_CONTRACT_VERSIONS:
        semantic_source_texts = [
            str(item.get("source_text") or "")
            for item in [
                *(core.get("user_definitions") or []),
                *interpretations,
            ]
            if isinstance(item, dict) and str(item.get("source_text") or "")
        ]
        if any(
            not any(
                source.casefold() in span.casefold()
                for source in semantic_source_texts
            )
            for span in visual_spans
        ):
            return False
    return True


def audit_authorial_authorship_policy(
    pack: dict[str, Any],
) -> tuple[list[dict[str, Any]], int, int, int]:
    """Recompute current authored-refinement policy; optional work has no quota."""
    pack = photo_native_pack.read_view(pack)

    authorial = pack.get("authorial_composition")
    authorial = authorial if isinstance(authorial, dict) else {}
    binding = authorial.get("core_binding_contract")
    binding = binding if isinstance(binding, dict) else {}
    core = pack.get("authorial_core")
    core = core if isinstance(core, dict) else {}
    intent_lock = core.get("intent_lock")
    intent_lock = intent_lock if isinstance(intent_lock, dict) else {}
    opened = intent_lock.get("open_dimensions")
    opened = opened if isinstance(opened, list) else []
    policy = authorial.get("authorship_policy")
    policy = policy if isinstance(policy, dict) else {}
    minimum_decisions = 0
    minimum_evidence = 0
    policy_version = AUTHORIAL_AUTHORSHIP_POLICY_CONTRACT_VERSION
    binding_version = AUTHORIAL_CORE_BINDING_CONTRACT_VERSION
    expected_policy = {
        "contract_version": policy_version,
        "source_authorial_core_sha256": str(core.get("canonical_sha256") or ""),
        "source_intent_lock_sha256": str(intent_lock.get("canonical_sha256") or ""),
        "allowed_dimensions": copy.deepcopy(opened),
        "minimum_authorial_decisions": minimum_decisions,
        "minimum_preserved_evidence_phrases": minimum_evidence,
        "dimension_policy": "distinct_open_dimensions_only",
        "insufficient_freedom_policy": "do_not_invent_open_dimensions",
    }
    expected_policy["canonical_sha256"] = canonical_json_sha256(expected_policy)
    expected_binding = {
        "composed_field": "authorial_core_binding",
        "minimum_preserved_evidence_phrases": minimum_evidence,
        "minimum_authorial_decisions": minimum_decisions,
        "evidence_must_be_literal_in_baseline_and_final_prompt": True,
        "source_intent_lock_sha256_required": True,
        "all_semantic_anchor_ids_required": True,
        "authorial_decisions_limited_to_open_dimensions": True,
        "contract_version": binding_version,
        "source_authorship_policy_sha256": expected_policy["canonical_sha256"],
    }
    if (
        pack.get("contract_version") != "photo-candidate-pack/v10"
        or core.get("contract_version") != AUTHORIAL_CORE_V3_CONTRACT_VERSION
        or authorial.get("authorship_policy") != expected_policy
        or binding != expected_binding
    ):
        return [
            {
                "check": "authorial_authorship_policy_contract",
                "reason": "the v9 authorship policy and core binding must match the frozen open dimensions and hashes",
            }
        ], 0, 0, 0
    return [], minimum_decisions, 0, minimum_evidence


def audit_authorial_core(
    pack: dict[str, Any],
    composed: dict[str, Any],
    prompt_en: str,
    warnings: list[dict[str, Any]] | None = None,
) -> list[dict[str, Any]]:
    pack = photo_native_pack.read_view(pack)
    pack_version = str(pack.get('contract_version') or '')
    failures, minimum_decisions, minimum_open_dimensions, minimum_evidence = (
        audit_authorial_authorship_policy(pack)
    )
    core = pack.get("authorial_core") if isinstance(pack.get("authorial_core"), dict) else {}
    authorial_composition = (
        pack.get("authorial_composition")
        if isinstance(pack.get("authorial_composition"), dict)
        else {}
    )
    recorded_budget = (
        authorial_composition.get("prompt_budget")
        if isinstance(authorial_composition.get("prompt_budget"), dict)
        else None
    )
    expected_budget = expected_authorial_prompt_budget_contract()
    uses_current_advisory_budget = recorded_budget == expected_budget
    uses_advisory_budget = True
    if recorded_budget != expected_budget:
        failures.append(
            {
                "check": "authorial_prompt_budget_contract",
                "reason": "the versioned authorial prompt-budget policy was changed after pack generation",
                "expected": expected_budget,
                "actual": recorded_budget,
            }
        )
    active_budget = expected_budget
    minimum_words = int(active_budget["minimum_words"])
    recommended_maximum_words = int(active_budget["recommended_maximum_words"])
    absolute_maximum_words = int(active_budget["absolute_maximum_words"])
    required_evidence_headroom_words = int(active_budget["required_evidence_headroom_words"])
    prompt_metrics = authorial_prompt_budget_metrics(
        pack, composed, prompt_en, budget_contract=active_budget
    )
    prompt_word_count = prompt_metrics["actual_words"]
    if not minimum_words <= prompt_word_count <= absolute_maximum_words:
        failures.append(
            {
                "check": "authorial_core_prompt_budget",
                "reason": "v9 prompt_en exceeds the absolute photographic prompt bounds",
                "minimum_words": minimum_words,
                "recommended_maximum_words": recommended_maximum_words,
                "absolute_maximum_words": absolute_maximum_words,
                "actual_words": prompt_word_count,
            }
        )
    elif warnings is not None and prompt_word_count > recommended_maximum_words:
        warnings.append(
            {
                "check": "authorial_prompt_recommended_budget",
                "reason": "prompt_en exceeds the recommended length; this is advisory because requester meaning, coherent scene context, and literal hard evidence take priority",
                "recommended_maximum_words": recommended_maximum_words,
                "absolute_maximum_words": absolute_maximum_words,
                **prompt_metrics,
            }
        )
        if prompt_word_count > prompt_metrics["effective_recommended_maximum_words"]:
            warnings.append(
                {
                    "check": "authorial_prompt_optional_prose_budget",
                    "reason": "prompt_en exceeds the evidence-adjusted advisory ceiling; review redundant technique, candidate detail, and repeated explanation while preserving requester evidence and context needed to read the scene",
                    "required_evidence_headroom_words": required_evidence_headroom_words,
                    "absolute_maximum_words": absolute_maximum_words,
                    **prompt_metrics,
                }
            )
    baseline_prompt = str(core.get('baseline_prompt_en') or '')
    baseline_metrics = authorial_prompt_budget_metrics(
        pack, composed, baseline_prompt, baseline_only=True, budget_contract=active_budget
    )
    baseline_word_count = baseline_metrics["actual_words"]
    if not minimum_words <= baseline_word_count <= absolute_maximum_words:
        failures.append(
            {
                "check": "authorial_core_baseline_prompt_budget",
                "reason": "baseline_prompt_en exceeds the absolute photographic prompt bounds",
                "minimum_words": minimum_words,
                "recommended_maximum_words": recommended_maximum_words,
                "absolute_maximum_words": absolute_maximum_words,
                "actual_words": baseline_word_count,
            }
        )
    elif warnings is not None and baseline_word_count > recommended_maximum_words:
        warnings.append(
            {
                "check": "authorial_core_baseline_recommended_budget",
                "reason": "baseline_prompt_en exceeds the recommended length but remains within the absolute bound; preserve coherent scene context while reviewing redundancy",
                "recommended_maximum_words": recommended_maximum_words,
                "absolute_maximum_words": absolute_maximum_words,
                **baseline_metrics,
            }
        )
    canonical_sha = str(core.get('canonical_sha256') or '')
    canonical_material = copy.deepcopy(core)
    canonical_material.pop("canonical_sha256", None)
    canonical_material.pop("core_id", None)
    expected_sha = hashlib.sha256(
        json.dumps(
            canonical_material, ensure_ascii=False, sort_keys=True, separators=(",", ":")
        ).encode("utf-8")
    ).hexdigest()
    retrieval = (
        (pack.get("provenance") or {}).get("retrieval_query")
        if isinstance(pack.get("provenance"), dict)
        else {}
    )
    expected_retrieval = expected_authorial_core_retrieval_provenance(core)
    modern_core_fields_valid = True
    if core.get("contract_version") in AUTHORIAL_CORE_MODERN_CONTRACT_VERSIONS:
        expected_core_fields = {
            "contract_version",
            "provenance",
            "source_request",
            "interpreted_intent",
            "subject",
            "setting",
            "event",
            "visual_priorities",
            "baseline_prompt_en",
            "user_definitions",
            "interpretation_provenance",
            "unresolved_ambiguities",
            "user_exclusions",
            "runtime_forbidden_labels",
            "intent_lock",
            "request_binding",
            "style",
            "variation_key",
            "canonical_sha256",
            "core_id",
        }
        if core.get("contract_version") == AUTHORIAL_CORE_V3_CONTRACT_VERSION:
            expected_core_fields.update({"semantic_assertions", "request_lineage"})
            if "creative_controls_sha256" in core:
                expected_core_fields.add("creative_controls_sha256")
        modern_core_fields_valid = set(core) == expected_core_fields
    allowed_core_versions = {AUTHORIAL_CORE_V3_CONTRACT_VERSION}
    if (
        core.get("contract_version") not in allowed_core_versions
        or core.get("provenance") != "agent_prepack"
        or (
            not authorial_core_interpretation_contract_valid(
                core, creative_control_snapshot=pack.get("creative_controls")
            )
        )
        or (
            not authorial_core_intent_contract_valid(
                core,
                minimum_open_dimensions=minimum_open_dimensions,
                creative_control_snapshot=pack.get("creative_controls"),
            )
        )
        or (
            not authorial_core_v3_semantic_contract_valid(
                core, creative_control_snapshot=pack.get("creative_controls")
            )
        )
        or (not modern_core_fields_valid)
        or (not canonical_sha)
        or (canonical_sha != expected_sha)
        or (str(core.get('core_id') or '') != canonical_sha[:16])
        or (not isinstance(retrieval, dict))
        or (retrieval != expected_retrieval)
    ):
        failures.append(
            {
                "check": "authorial_core_integrity",
                "reason": "v9 pack is not bound to one valid versioned pre-pack authorial core and retrieval query",
            }
        )
    binding = (
        composed.get("authorial_core_binding")
        if isinstance(composed.get("authorial_core_binding"), dict)
        else {}
    )
    if str(binding.get('source_authorial_core_sha256') or '') != canonical_sha:
        failures.append(
            {
                "check": "authorial_core_binding",
                "reason": "composed prompt is not bound to the governing authorial core hash",
            }
        )
    failures.extend(audit_creative_controls(pack))
    intent_lock = core.get("intent_lock") if isinstance(core.get("intent_lock"), dict) else {}
    intent_locked = core.get("contract_version") in AUTHORIAL_CORE_MODERN_CONTRACT_VERSIONS
    if intent_locked and str(binding.get('source_intent_lock_sha256') or '') != str(intent_lock.get('canonical_sha256') or ''):
        failures.append(
            {
                "check": "intent_lock_binding",
                "reason": "composed prompt is not bound to the requesting-user-priority intent lock",
            }
        )
    if intent_locked:
        required_anchor_ids = {
            str(item.get('anchor_id') or '')
            for item in intent_lock.get("semantic_anchors") or []
            if isinstance(item, dict) and str(item.get('anchor_id') or '')
        }
        preserved_anchor_id_list = nonempty_string_list(binding.get("preserved_anchor_ids"))
        preserved_anchor_ids = set(preserved_anchor_id_list)
        if preserved_anchor_ids != required_anchor_ids or len(preserved_anchor_id_list) != len(
            preserved_anchor_ids
        ):
            failures.append(
                {
                    "check": "intent_lock_anchor_binding",
                    "reason": "authorial_core_binding must preserve every semantic anchor id exactly once",
                    "expected": sorted(required_anchor_ids),
                    "actual": sorted(preserved_anchor_ids),
                }
            )
        for anchor in intent_lock.get("semantic_anchors") or []:
            if not isinstance(anchor, dict):
                continue
            phrase = str(anchor.get('prompt_evidence') or '')
            if not phrase or not text_contains_term(prompt_en, phrase):
                failures.append(
                    {
                        "check": "intent_lock_prompt_evidence",
                        "reason": "every requesting-user semantic anchor must remain literal in prompt_en",
                        "anchor_id": anchor.get("anchor_id"),
                        "phrase": phrase,
                    }
                )
        preservation = (
            pack.get("intent_preservation")
            if isinstance(pack.get("intent_preservation"), dict)
            else {}
        )
        if (
            set(preservation)
            != {
                "contract_version",
                "source_authorial_core_sha256",
                "source_intent_lock_sha256",
                "priority_order",
                "required_anchor_ids",
                "locked_dimensions",
                "open_dimensions",
                "material_change_action",
                "creative_change_boundary",
            }
            or preservation.get("contract_version") != INTENT_PRESERVATION_CONTRACT_VERSION
            or preservation.get("source_authorial_core_sha256") != canonical_sha
            or (
                preservation.get("source_intent_lock_sha256") != intent_lock.get("canonical_sha256")
            )
            or (
                preservation.get("priority_order")
                != [
                    "requesting_user_definition",
                    "requesting_user_semantic_anchor",
                    "requesting_user_modifier_or_exclusion",
                    "agent_prepack_interpretation",
                    "creative_augmentation",
                ]
            )
            or (
                set(nonempty_string_list(preservation.get("required_anchor_ids")))
                != required_anchor_ids
            )
            or (preservation.get("locked_dimensions") != intent_lock.get("locked_dimensions"))
            or (preservation.get("open_dimensions") != intent_lock.get("open_dimensions"))
            or (
                preservation.get("material_change_action")
                != "stop_and_rebuild_core_after_requester_input"
            )
            or (
                preservation.get("creative_change_boundary")
                != "open_dimensions_only_and_subordinate"
            )
        ):
            failures.append(
                {
                    "check": "intent_preservation_contract",
                    "reason": "v9 pack does not preserve the canonical requester-priority intent boundary",
                }
            )
    raw_evidence = binding.get("preserved_evidence")
    evidence = nonempty_string_list(raw_evidence)
    if (
        len(evidence) < minimum_evidence
        or len({item.casefold() for item in evidence}) != len(evidence)
        or (
            minimum_evidence == 0
            and (
                not isinstance(raw_evidence, list)
                or any((not isinstance(item, str) or not item.strip() for item in raw_evidence))
            )
        )
    ):
        failures.append(
            {
                "check": "authorial_core_evidence",
                "reason": "preserved_evidence must be an explicit list of distinct phrases meeting the recorded policy minimum",
                "minimum_preserved_evidence_phrases": minimum_evidence,
            }
        )
    baseline = str(core.get('baseline_prompt_en') or '')
    for phrase in evidence:
        if (
            len(authorial_evidence_tokens(phrase)) < 2
            or not text_contains_term(baseline, phrase)
            or (not text_contains_term(prompt_en, phrase))
        ):
            failures.append(
                {
                    "check": "authorial_core_evidence",
                    "reason": "preserved evidence must be substantive and occur literally in both baseline_prompt_en and prompt_en",
                    "phrase": phrase,
                }
            )
    raw_decisions = binding.get("authorial_decisions")
    decisions = (
        [row for row in raw_decisions if isinstance(row, dict)]
        if isinstance(raw_decisions, list)
        else []
    )
    dimensions = [str(row.get('dimension') or '') for row in decisions]
    if (
        len(decisions) < minimum_decisions
        or (
            minimum_open_dimensions == 0
            and (not isinstance(raw_decisions, list) or len(decisions) != len(raw_decisions))
        )
        or len(dimensions) != len(set(dimensions))
        or any(
            (
                len(authorial_evidence_tokens(str(row.get('decision') or ''))) < 2
                or len(authorial_evidence_tokens(str(row.get('rationale') or ''))) < 3
                for row in decisions
            )
        )
    ):
        failures.append(
            {
                "check": "authorial_core_decisions",
                "reason": "composition requires the policy minimum of distinct substantive authorial decisions",
                "minimum_authorial_decisions": minimum_decisions,
            }
        )
    if intent_locked:
        open_dimensions = {str(item) for item in intent_lock.get("open_dimensions") or []}
        adult_appeal = (
            pack.get("adult_appeal") if isinstance(pack.get("adult_appeal"), dict) else {}
        )
        if adult_appeal.get("dimension_scope") is not None:
            failures.extend(audit_adult_appeal_dimension_scope(pack, adult_appeal))
        if (
            adult_appeal.get("enabled") is True
            and adult_appeal.get("activation_source") == "skill_default"
            and (not isinstance(adult_appeal.get("dimension_scope"), dict))
            and (not ADULT_APPEAL_DEFAULT_AFFECTED_DIMENSIONS.issubset(open_dimensions))
        ):
            failures.append(
                {
                    "check": "intent_lock_adult_appeal_default",
                    "reason": "the skill-default adult-appeal axis may be active only when every semantic dimension it can affect is explicitly open",
                    "required_open_dimensions": sorted(ADULT_APPEAL_DEFAULT_AFFECTED_DIMENSIONS),
                    "open_dimensions": sorted(open_dimensions),
                }
            )
        invalid_dimensions = sorted(
            {
                str(row.get('dimension') or '')
                for row in decisions
                if str(row.get('dimension') or '') not in open_dimensions
            }
        )
        if invalid_dimensions:
            failures.append(
                {
                    "check": "intent_lock_authorial_dimensions",
                    "reason": "authorial decisions may change only dimensions left open by the intent lock",
                    "invalid_dimensions": invalid_dimensions,
                    "open_dimensions": sorted(open_dimensions),
                }
            )
        for row in decisions:
            if not native_property_effects_allowed(
                core, [row.get("dimension")], row.get("affected_properties", [])
            ):
                failures.append(
                    {
                        "check": "intent_lock_authorial_properties",
                        "reason": "declare effects on open properties and preserve every requester-owned property",
                        "dimension": row.get("dimension"),
                    }
                )
    for exclusion in nonempty_string_list(core.get("user_exclusions")):
        if text_contains_term(prompt_en, exclusion):
            failures.append(
                {
                    "check": "authorial_core_exclusion",
                    "reason": "final prompt reintroduced an explicit authorial-core exclusion",
                    "exclusion": exclusion,
                }
            )
    for label in nonempty_string_list(core.get("runtime_forbidden_labels")):
        if text_contains_term(prompt_en, label):
            failures.append(
                {
                    "check": "intent_lock_runtime_label",
                    "reason": "a runtime-only label leaked into prompt_en without being removed from meaning resolution",
                    "label": label,
                }
            )
    return failures


def audit_semantic_clarification(
    pack: dict[str, Any],
    composed: dict[str, Any],
    prompt_en: str,
) -> list[dict[str, Any]]:
    pack = photo_native_pack.read_view(pack)
    contract = (
        pack.get("semantic_clarification")
        if isinstance(pack.get("semantic_clarification"), dict)
        else {}
    )
    if not contract:
        return []
    failures: list[dict[str, Any]] = []
    if (
        contract.get("contract_version") != SEMANTIC_CLARIFICATION_CONTRACT_VERSION
        or contract.get("affected_by_creativity") is not False
        or contract.get("affected_by_seed") is not False
    ):
        failures.append(
            {
                "check": "semantic_clarification_contract",
                "reason": "semantic clarification must be deterministic and separate from creative sampling",
            }
        )
    candidates = [
        row for row in contract.get("candidates") or [] if isinstance(row, dict)
    ]
    candidate_map = {
        str(row.get("id") or ""): row
        for row in candidates
        if str(row.get("id") or "")
    }
    core = pack.get("authorial_core") if isinstance(pack.get("authorial_core"), dict) else {}
    if core.get("contract_version") == AUTHORIAL_CORE_V3_CONTRACT_VERSION:
        expected = candidate_semantics_generator.authorial_meaning_clarification(core)
        if (
            candidate_map.get(expected["id"]) != expected
            or contract.get("authorial_direction")
            != candidate_semantics_generator.authorial_direction_context(core)
        ):
            failures.append({
                "check": "semantic_clarification_authority",
                "reason": "required clarification must project frozen requester evidence; the authored direction is separate context",
            })
    if core.get("contract_version") == AUTHORIAL_CORE_V3_CONTRACT_VERSION:
        try:
            data = _audit_source_data()
            source = {"provenance": {**(pack.get("provenance") or {}), "authorial_core": core, "creative_controls": pack.get("creative_controls")}}
            rows = candidate_semantics_generator.candidate_pack_visual_obligation_request_sources(source, {})
            context = " ".join(str(row.get("text") or "") for row in rows)
            registry = data.get(candidate_semantics_generator.VISUAL_OBLIGATIONS_DATA_KEY) or {}
            profiles = {row["id"]: row for row in registry.get("profiles") or []}
            for candidate in candidates:
                if candidate.get("source") != "visual_meaning_registry":
                    continue
                profile = profiles.get(candidate.get("profile_id"))
                applicability = candidate.get("applicability") or {}
                if profile is None:
                    raise ValueError("clarification references an unknown profile")
                diagnostic = candidate_semantics_generator.visual_profile_context_diagnostics(profile, context,
                    has_authorial_core_context=True, require_positive_context_terms=applicability.get("status") != "eligible")
                if applicability.get("diagnostics") != diagnostic:
                    failures.append({"check": "semantic_clarification_diagnostics", "reason": "context diagnostic differs from frozen source and authored rules", "clarification_id": candidate["id"]})
                if applicability.get("status") == "context_mismatch" and applicability.get("reason") != diagnostic["checks"][0]["code"]:
                    failures.append({"check": "semantic_clarification_diagnostics", "reason": "context mismatch reason has no matching diagnostic evidence"})
            profiles = {"character_response_concept:" + row["id"]: row for row in candidate_semantics_generator.character_response_concept_profiles(data)}
            for candidate in ((pack.get("character_response") or {}).get("advisory_retrieval") or {}).get("candidates") or []:
                if candidate.get("candidate_type") != "concept_profile":
                    continue
                profile = profiles.get(candidate.get("candidate_id"))
                expected_consistency = candidate_semantics_generator.evaluate_character_response_profile(core, data, profile) if profile else None
                if candidate.get("semantic_consistency") != expected_consistency:
                    failures.append({"check": "character_response_diagnostics", "reason": "profile diagnostic differs from frozen assertion and authored rules"})
        except (OSError, ValueError, KeyError, TypeError) as error:
            failures.append({"check": "meaning_diagnostics_source", "reason": str(error)})
    pack_candidate_ids = candidate_ids_from_pack(pack) | set(candidate_map)
    decisions = [
        row
        for row in composed.get("semantic_clarification_decisions") or []
        if isinstance(row, dict)
    ]
    decision_ids = [str(row.get("clarification_id") or "") for row in decisions]
    if (
        set(decision_ids) != set(candidate_map)
        or len(decision_ids) != len(set(decision_ids))
    ):
        failures.append(
            {
                "check": "semantic_clarification_decisions",
                "reason": "every clarification candidate requires exactly one typed decision",
                "expected": sorted(candidate_map),
                "actual": decision_ids,
            }
        )
    for decision in decisions:
        clarification_id = str(decision.get("clarification_id") or "")
        candidate = candidate_map.get(clarification_id)
        if candidate is None:
            continue
        state = str(decision.get("decision") or "")
        rationale = str(decision.get("rationale") or "")
        if state not in {"applied", "rejected"} or len(
            authorial_evidence_tokens(rationale)
        ) < 2:
            failures.append(
                {
                    "check": "semantic_clarification_decisions",
                    "reason": "each clarification needs a typed decision plus a substantive rationale",
                    "clarification_id": clarification_id,
                }
            )
            continue
        status = str((candidate.get("applicability") or {}).get("status") or "")
        if candidate.get("required_in_final_prompt") is True and state != "applied":
            failures.append(
                {
                    "check": "semantic_clarification_required",
                    "reason": "a required meaning clarification cannot be rejected",
                    "clarification_id": clarification_id,
                }
            )
        if status in {"context_mismatch", "requires_existing_adult_context", "requires_explicit_mechanism"} and state != "rejected":
            failures.append(
                {
                    "check": "semantic_clarification_applicability",
                    "reason": "a context-mismatched or adult-context-gated meaning cannot be applied",
                    "clarification_id": clarification_id,
                }
            )
        if state == "applied":
            evidence = str(decision.get("prompt_evidence") or "").strip()
            if not evidence or not text_contains_term(prompt_en, evidence):
                failures.append(
                    {
                        "check": "semantic_clarification_binding",
                        "reason": "applied clarification needs literal prompt evidence",
                        "clarification_id": clarification_id,
                    }
                )
            required_evidence = str(candidate.get("required_prompt_evidence") or "")
            if required_evidence and not text_contains_term(prompt_en, required_evidence):
                failures.append(
                    {
                        "check": "semantic_clarification_user_definition",
                        "reason": "requesting-user definition evidence was not preserved literally",
                        "clarification_id": clarification_id,
                    }
                )
        for label in candidate.get("forbidden_runtime_labels") or []:
            if text_contains_term(prompt_en, str(label)):
                failures.append(
                    {
                        "check": "semantic_clarification_sensitive_label",
                        "reason": "a definition-only sensitive label leaked into prompt_en",
                        "clarification_id": clarification_id,
                        "label": label,
                    }
                )
    return failures


def audit_creative_augmentation(
    pack: dict[str, Any],
    composed: dict[str, Any],
    prompt_en: str,
    chosen: set[str],
) -> list[dict[str, Any]]:
    pack = photo_native_pack.read_view(pack)
    contract = (
        pack.get("creative_augmentation")
        if isinstance(pack.get("creative_augmentation"), dict)
        else {}
    )
    if not contract or not contract.get("enabled"):
        return []
    failures: list[dict[str, Any]] = []
    core = pack.get("authorial_core") if isinstance(pack.get("authorial_core"), dict) else {}
    intent_lock = (
        core.get("intent_lock")
        if core.get("contract_version") in AUTHORIAL_CORE_MODERN_CONTRACT_VERSIONS
        and isinstance(core.get("intent_lock"), dict)
        else {}
    )
    candidates = creative_augmentation_candidates_from_pack(pack)
    candidate_map = {
        str(row.get("id") or ""): row for row in candidates if str(row.get("id") or "")
    }
    allowed_bands = {
        str(item) for item in ((contract.get("distance_policy") or {}).get("allowed_bands") or [])
    }
    if (
        contract.get("contract_version") != CREATIVE_AUGMENTATION_CONTRACT_VERSION
        or not re.fullmatch(r"[0-9a-f]{64}", str(contract.get("hard_eligible_pool_sha256") or ""))
        or not re.fullmatch(r"[0-9a-f]{64}", str(contract.get("guard_invariant_sha256") or ""))
        or any(str(row.get("semantic_band") or "") not in allowed_bands for row in candidates)
    ):
        failures.append(
            {
                "check": "creative_augmentation_contract",
                "reason": "current creative augmentation has an invalid pool, guard, or distance-band contract",
            }
        )
    brief = (
        composed.get("creative_augmentation_brief")
        if isinstance(composed.get("creative_augmentation_brief"), dict)
        else {}
    )
    decisions = [row for row in brief.get("decisions") or [] if isinstance(row, dict)]
    decision_ids = [str(row.get("candidate_id") or "") for row in decisions]
    if set(decision_ids) != set(candidate_map) or len(decision_ids) != len(set(decision_ids)):
        failures.append(
            {
                "check": "creative_augmentation_decisions",
                "reason": "every sampled creative candidate requires exactly one transformed or rejected decision",
                "expected": sorted(candidate_map),
                "actual": decision_ids,
            }
        )
    transformed: set[str] = set()
    for decision in decisions:
        candidate_id = str(decision.get("candidate_id") or "")
        candidate = candidate_map.get(candidate_id)
        if candidate is None:
            continue
        state = str(decision.get("decision") or "")
        rationale = str(decision.get("rationale") or "")
        if (
            state not in {"transformed", "rejected"}
            or len(authorial_evidence_tokens(rationale)) < 2
        ):
            failures.append(
                {
                    "check": "creative_augmentation_decisions",
                    "reason": "every sampled candidate needs transformed/rejected plus rationale",
                    "candidate_id": candidate_id,
                }
            )
            continue
        if state == "rejected":
            if candidate_id in chosen:
                failures.append(
                    {
                        "check": "creative_augmentation_provenance",
                        "reason": "a rejected creative candidate must not be chosen",
                        "candidate_id": candidate_id,
                    }
                )
            continue
        transformed.add(candidate_id)
        evidence = str(decision.get("prompt_evidence") or "").strip()
        interpretation = str(decision.get("artistic_interpretation") or "")
        transformation = str(decision.get("transformation") or "")
        affected_dimensions = nonempty_string_list(decision.get("affected_dimensions"))
        if intent_lock:
            open_dimensions = {str(item) for item in intent_lock.get("open_dimensions") or []}
            adult = pack.get("adult_appeal") or {}
            scope = adult.get("dimension_scope") or {}
            adult_candidates = {row["id"]: row for row in adult_appeal_candidates_from_pack(pack)}
            adult_candidate = adult_candidates.get(candidate_id)
            if isinstance(adult_candidate, dict) and scope.get("contract_version") in {
                photo_contextual_appeal.SCOPE_VERSION
            }:
                open_dimensions = set(
                    (scope.get("axis_allowed_dimensions") or {}).get(
                        adult_candidate.get("axis"), []
                    )
                )
            invalid_dimensions = sorted(set(affected_dimensions) - open_dimensions)
            if (
                not affected_dimensions
                or len(affected_dimensions) != len(set(affected_dimensions))
                or invalid_dimensions
            ):
                failures.append(
                    {
                        "check": "intent_lock_creative_dimensions",
                        "reason": "a transformed candidate must name distinct affected dimensions within its applicable intent-lock or scoped adult-axis boundary",
                        "candidate_id": candidate_id,
                        "invalid_dimensions": invalid_dimensions,
                        "open_dimensions": sorted(open_dimensions),
                    }
                )
            if not native_property_effects_allowed(
                core, affected_dimensions, decision.get("affected_properties", []),
                candidate_id=candidate_id, realization_id=decision.get("realization_id")
            ):
                failures.append(
                    {
                        "check": "intent_lock_creative_properties",
                        "candidate_id": candidate_id,
                        "reason": "a transformed candidate must preserve protected properties and declare its narrower effects",
                    }
                )
        if (
            candidate_id not in chosen
            or not evidence
            or not text_contains_term(prompt_en, evidence)
            or len(authorial_evidence_tokens(interpretation)) < 3
            or len(authorial_evidence_tokens(transformation)) < 3
        ):
            failures.append(
                {
                    "check": "creative_augmentation_transform",
                    "reason": "transformed material needs chosen provenance, interpretation, transformation, and literal evidence",
                    "candidate_id": candidate_id,
                }
            )
            continue
        source_terms = {
            token
            for item in candidate.get("concept_terms") or []
            for token in authorial_evidence_tokens(str(item))
        }
        evidence_terms = authorial_evidence_tokens(evidence)
        if len(evidence_terms) < 4 or len(evidence_terms - source_terms) < 2:
            failures.append(
                {
                    "check": "creative_augmentation_transform",
                    "reason": "creative evidence must add at least two authored content words beyond source terms",
                    "candidate_id": candidate_id,
                }
            )
    if len(transformed) > int(
        ((contract.get("selection_contract") or {}).get("maximum_transformed") or 3)
    ):
        failures.append(
            {
                "check": "creative_augmentation_budget",
                "reason": "too many creative candidates were transformed",
                "actual": len(transformed),
            }
        )
    return failures


def audit_creative_controls(pack: dict[str, Any]) -> list[dict[str, Any]]:
    pack = photo_native_pack.read_view(pack)
    core = pack.get("authorial_core") or {}
    snapshot = pack.get("creative_controls")
    bound_sha = core.get("creative_controls_sha256")
    try:
        creative_controls.validate(snapshot, core.get("source_request"))
        if pack.get("contract_version") != "photo-candidate-pack/v10" or bound_sha != snapshot["canonical_sha256"]:
            raise ValueError("creative controls must be bound into the governing v3 core")
        runtime = creative_controls.runtime_values(snapshot)
        provenance = pack.get("provenance") or {}
        if provenance.get("creative_control_runtime") != runtime or provenance.get("creativity") != runtime["creativity"]:
            raise ValueError("post-core controls differ from the frozen pre-core settings")
        adult = pack.get("adult_appeal") or {}
        if not adult and all(
            runtime[axis + "_intensity"] == 0 for axis in creative_controls.AXES
        ):
            return []
        for axis in creative_controls.AXES:
            row = (adult.get("axes") or {}).get(axis) or {}
            if row.get("requested_intensity") != runtime[axis + "_intensity"]:
                raise ValueError(f"{axis} differs from the frozen effective intensity")
            definition = snapshot["definitions"]["controls"][axis]
            if row.get("definition") != definition["definition"] or row.get("intensity_meaning") != definition["levels"].get(str(row.get("intensity"))):
                raise ValueError(f"{axis} meaning differs from the frozen definition")
        if (adult.get("blend") or {}).get("requested_emphasis") != runtime["adult_appeal_emphasis"]:
            raise ValueError("adult-appeal emphasis differs from the frozen controls")
    except (ValueError, TypeError, KeyError, AttributeError) as exc:
        return [{"check": "creative_controls_binding", "reason": str(exc)}]
    return []


def audit_adult_appeal_dimension_scope(
    pack: dict[str, Any],
    contract: dict[str, Any],
) -> list[dict[str, Any]]:
    """Recompute the current contextual scope from the frozen intent lock."""
    pack = photo_native_pack.read_view(pack)
    scope = contract.get("dimension_scope")
    core = pack.get("authorial_core") or {}
    intent_lock = core.get("intent_lock") or {}
    locked = set(intent_lock.get("locked_dimensions") or [])
    version = scope.get("contract_version") if isinstance(scope, dict) else None
    if version != photo_contextual_appeal.SCOPE_VERSION:
        return [
            {
                "check": "adult_appeal_dimension_scope",
                "reason": "unsupported adult-axis scope version",
            }
        ]
    dimensions_by_axis = {
        axis: photo_contextual_appeal.allowed_dimensions(intent_lock)
        for axis in photo_contextual_appeal.AXES
    }
    expected = {
        "contract_version": version,
        "policy": "preserve_locked_dimensions",
        "source_intent_lock_sha256": str(intent_lock.get("canonical_sha256") or ""),
        "locked_dimensions": sorted(locked),
        "axis_allowed_dimensions": {
            axis: sorted(dimensions - locked) for axis, dimensions in dimensions_by_axis.items()
        },
    }
    expected["protected_properties"] = intent_property_locks(intent_lock)
    if (
        pack.get("contract_version") != "photo-candidate-pack/v10"
        or core.get("contract_version") != AUTHORIAL_CORE_V3_CONTRACT_VERSION
        or scope != expected
    ):
        return [
            {
                "check": "adult_appeal_dimension_scope",
                "reason": "adult-axis scope must match the frozen v3 intent lock and versioned axis dimensions",
            }
        ]
    failures = []
    axes = contract.get("axes") or {}
    if set(axes) != set(ADULT_APPEAL_AXIS_DIMENSIONS):
        failures.append(
            {
                "check": "adult_appeal_dimension_scope",
                "reason": "both independent axis states must be recorded",
            }
        )
    # Key access resolves native inventory references; items() preserves wire refs.
    for axis_id in axes:
        axis = axes[axis_id]
        allowed = set(expected["axis_allowed_dimensions"].get(axis_id, []))
        requested = axis.get("requested_intensity")
        if (
            type(requested) is not int
            or not 0 <= requested <= 3
            or axis.get("intensity") != (requested if allowed else 0)
            or axis.get("active")
            != (
                bool(allowed)
                and bool(requested)
                and (contract.get("eligibility") or {}).get("status") == "eligible"
            )
        ):
            failures.append(
                {
                    "check": "adult_appeal_dimension_scope",
                    "axis": axis_id,
                    "reason": "scope may disable only an axis with no permitted dimensions; requested intensity must be preserved otherwise",
                }
            )
        for candidate in axis.get("candidate_inventory") or []:
            affected = candidate.get("affected_dimensions") or []
            if (
                not affected
                or len(affected) != len(set(affected))
                or not set(affected).issubset(allowed)
            ):
                failures.append(
                    {
                        "check": "adult_appeal_candidate_dimensions",
                        "candidate_id": candidate.get("id"),
                        "reason": "an adult candidate must declare its complete effect within this axis's unlocked dimensions",
                    }
                )
            if not native_property_effects_allowed(
                pack.get("authorial_core") or {}, affected, candidate.get("affected_properties", []),
                candidate_id=candidate.get("id"), realization_id=candidate.get("realization_id")
            ):
                failures.append(
                    {
                        "check": "adult_appeal_candidate_properties",
                        "candidate_id": candidate.get("id"),
                        "reason": "candidate effects conflict with a protected property or omit their property scope",
                    }
                )
    return failures


def audit_adult_appeal(
    pack: dict[str, Any],
    composed: dict[str, Any],
    prompt_en: str,
    chosen: set[str],
    candidate_objects: dict[str, dict[str, Any]],
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    pack = photo_native_pack.read_view(pack)
    contract = pack.get("adult_appeal") if isinstance(pack.get("adult_appeal"), dict) else {}
    if not contract.get("enabled"):
        return [], []
    failures = audit_adult_appeal_dimension_scope(pack, contract)
    warnings: list[dict[str, Any]] = []
    brief = (
        composed.get("adult_appeal_brief")
        if isinstance(composed.get("adult_appeal_brief"), dict)
        else {}
    )
    failures.extend(photo_contextual_appeal.audit_context_copies(
        contract, creative_augmentation_candidates_from_pack(pack)))
    failures.extend(photo_contextual_appeal.audit_review(
        contract, brief, chosen, prompt_en=prompt_en, core=pack.get("authorial_core") or {},
        subject_category=((pack.get("creative_controls") or {}).get("context") or {}).get("subject_category", ""),
    ))
    adult_phrase = str(brief.get("adult_subject_phrase") or "")
    agency_phrase = str(brief.get("agency_phrase") or "")
    expected_axes = contract.get("axes") if isinstance(contract.get("axes"), dict) else {}
    sensual_intensity = int((expected_axes.get("sensual") or {}).get("intensity", 0) or 0)
    if sensual_intensity >= 2 and (
        not re.search(r"\badult\b", adult_phrase, flags=re.IGNORECASE)
        or not text_contains_term(prompt_en, adult_phrase)
    ):
        failures.append(
            {
                "check": "adult_appeal_adult_subject",
                "reason": "sensual intensity 2 or 3 requires a literal adult_subject_phrase containing adult",
            }
        )
    elif adult_phrase and not text_contains_term(prompt_en, adult_phrase):
        failures.append(
            {
                "check": "adult_appeal_adult_subject",
                "reason": "adult_subject_phrase must be literal when supplied",
            }
        )
    if not agency_phrase or not text_contains_term(prompt_en, agency_phrase):
        failures.append(
            {
                "check": "adult_appeal_agency",
                "reason": "agency_phrase must be literal in prompt_en",
            }
        )
    actual_axes = brief.get("axes") if isinstance(brief.get("axes"), dict) else {}
    for axis_id, axis in expected_axes.items():
        if not isinstance(axis, dict):
            continue
        expected_intensity = int(axis.get("intensity", 0) or 0)
        actual = actual_axes.get(axis_id) if isinstance(actual_axes.get(axis_id), dict) else {}
        try:
            actual_intensity = int(actual.get("intensity", -1))
        except (TypeError, ValueError):
            actual_intensity = -1
        evidence = str(actual.get("prompt_evidence") or "")
        scope = contract.get("dimension_scope")
        if isinstance(scope, dict) and expected_intensity > 0:
            affected = nonempty_string_list(actual.get("affected_dimensions"))
            allowed = set((scope.get("axis_allowed_dimensions") or {}).get(axis_id, []))
            selected_dimensions = {
                dimension
                for candidate_id in chosen
                for candidate in [candidate_objects.get(candidate_id, {})]
                if candidate.get("axis") == axis_id
                for dimension in candidate.get("affected_dimensions") or []
            }
            realization = actual.get("realization", "refined")
            retained = realization == "baseline" and scope.get("contract_version") in {
                ADULT_APPEAL_DIMENSION_SCOPE_CONTRACT_VERSION,
                photo_contextual_appeal.SCOPE_VERSION,
            }
            if retained:
                if (
                    affected
                    or selected_dimensions
                    or not text_contains_term(
                        str((pack.get("authorial_core") or {}).get("baseline_prompt_en") or ""),
                        evidence,
                    )
                ):
                    failures.append(
                        {
                            "check": "adult_appeal_baseline_realization",
                            "axis": axis_id,
                            "reason": "baseline realization must retain literal baseline evidence and introduce no axis candidate or changed dimension",
                        }
                    )
            elif (
                not affected
                or len(affected) != len(set(affected))
                or not set(affected).issubset(allowed)
                or not selected_dimensions.issubset(set(affected))
            ):
                failures.append(
                    {
                        "check": "adult_appeal_authored_dimensions",
                        "axis": axis_id,
                        "reason": "each active adult-axis interpretation must declare only unlocked dimensions and cover every adopted candidate's effect",
                    }
                )
            if realization not in {"baseline", "refined"}:
                failures.append(
                    {
                        "check": "adult_appeal_realization",
                        "axis": axis_id,
                        "reason": "realization must be baseline or refined",
                    }
                )
            if not native_property_effects_allowed(
                pack.get("authorial_core") or {}, affected, actual.get("affected_properties", []),
            ):
                failures.append(
                    {
                        "check": "adult_appeal_authored_properties",
                        "axis": axis_id,
                        "reason": "authored styling must declare open property effects and preserve protected properties",
                    }
                )
        if actual_intensity != expected_intensity or (
            expected_intensity > 0
            and (
                len(authorial_evidence_tokens(str(actual.get("artistic_interpretation") or ""))) < 3
                or not evidence
                or not text_contains_term(prompt_en, evidence)
            )
        ):
            failures.append(
                {
                    "check": "adult_appeal_axes",
                    "reason": "active current adult-appeal axes must preserve intensity and authored literal evidence",
                    "axis": axis_id,
                }
            )
    expected_emphasis = str((contract.get("blend") or {}).get("emphasis") or "")
    actual_emphasis = str((brief.get("blend") or {}).get("emphasis") or "")
    if expected_emphasis != actual_emphasis:
        failures.append(
            {
                "check": "adult_appeal_blend",
                "reason": "current adult-appeal blend differs from the preserved contract",
            }
        )

    # Check the combined effects of adopted styling, pose and camera choices.
    combination = (
        contract.get("combination_policy")
        if isinstance(contract.get("combination_policy"), dict)
        else {}
    )
    risk_hits: set[str] = set()
    risk_groups = (
        combination.get("risk_groups") if isinstance(combination.get("risk_groups"), dict) else {}
    )
    chosen_entry_ids = {
        str(candidate_objects.get(candidate_id, {}).get("entry_id") or "")
        for candidate_id in chosen
    }
    for group_id, group in risk_groups.items():
        if not isinstance(group, dict):
            continue
        entry_ids = {str(item) for item in group.get("entry_ids") or []}
        prompt_terms = [str(item) for item in group.get("prompt_terms") or []]
        if chosen_entry_ids & entry_ids or any(
            text_contains_term(prompt_en, term) for term in prompt_terms
        ):
            risk_hits.add(str(group_id))
    for rule in combination.get("hard_combinations") or []:
        if not isinstance(rule, dict):
            continue
        required = {str(item) for item in rule.get("all_of") or []}
        if required and required <= risk_hits:
            failures.append(
                {
                    "check": "adult_appeal_combination_risk",
                    "reason": str(rule.get("reason") or "high-risk styling and camera combination"),
                    "rule_id": rule.get("id"),
                    "risk_groups": sorted(required),
                }
            )
    for rule in combination.get("warning_combinations") or []:
        if not isinstance(rule, dict):
            continue
        required = {str(item) for item in rule.get("all_of") or []}
        if required and required <= risk_hits:
            warnings.append(
                {
                    "check": "adult_appeal_combination_risk",
                    "reason": str(rule.get("reason") or "stacked adult-fashion emphasis"),
                    "rule_id": rule.get("id"),
                    "risk_groups": sorted(required),
                }
            )
    return failures, warnings


def audit_character_response_v8(
    pack: dict[str, Any],
    composed: dict[str, Any],
    prompt_en: str,
) -> list[dict[str, Any]]:
    pack = photo_native_pack.read_view(pack)
    core = (
        pack.get("authorial_core")
        if isinstance(pack.get("authorial_core"), dict)
        else {}
    )
    required_assertions = [
        item
        for item in core.get("semantic_assertions") or []
        if isinstance(item, dict)
        and item.get("dimension") == "character_response"
        and item.get("polarity") == "required"
    ]
    contract = (
        pack.get("character_response")
        if isinstance(pack.get("character_response"), dict)
        else {}
    )
    if not contract:
        return (
            [
                {
                    "check": "character_response_contract",
                    "reason": "a required typed character-response assertion is missing its downstream contract",
                }
            ]
            if required_assertions
            else []
        )
    failures: list[dict[str, Any]] = []
    if len(required_assertions) != 1:
        return [
            {
                "check": "character_response_contract",
                "reason": "a character-response contract requires exactly one governing typed assertion",
            }
        ]
    governing_assertion = required_assertions[0]
    frozen = (
        contract.get("frozen_evidence")
        if isinstance(contract.get("frozen_evidence"), dict)
        else {}
    )
    binding = (
        contract.get("prompt_binding")
        if isinstance(contract.get("prompt_binding"), dict)
        else {}
    )
    required_fields = nonempty_string_list(binding.get("required_evidence_fields"))
    if (
        contract.get("contract_version") != CHARACTER_RESPONSE_CONTRACT_VERSION
        or contract.get("enabled") is not True
        or contract.get("source") != "authorial_core_semantic_assertion"
        or contract.get("source_authorial_core_sha256")
        != core.get("canonical_sha256")
        or contract.get("source_intent_lock_sha256")
        != (core.get("intent_lock") or {}).get("canonical_sha256")
        or contract.get("source_assertion_id")
        != governing_assertion.get("assertion_id")
        or contract.get("source_span_ids")
        != governing_assertion.get("source_span_ids")
        or contract.get("semantic_axes") != governing_assertion.get("axes")
        or frozen != governing_assertion.get("evidence")
        or set(required_fields) != CHARACTER_RESPONSE_REQUIRED_EVIDENCE
        or set(frozen) < CHARACTER_RESPONSE_REQUIRED_EVIDENCE
        or binding.get("new_hard_evidence_from_retrieval_forbidden") is not True
        or not re.fullmatch(
            r"[0-9a-f]{64}", str(contract.get("canonical_sha256") or "")
        )
    ):
        failures.append(
            {
                "check": "character_response_contract",
                "reason": "v9 character response is not bound to one typed assertion and its frozen generic evidence",
            }
        )
    contract_material = copy.deepcopy(contract)
    contract_sha = str(contract_material.pop("canonical_sha256", "") or "")
    if contract_sha != canonical_json_sha256(contract_material):
        failures.append(
            {
                "check": "character_response_integrity",
                "reason": "character-response content does not match its canonical hash",
            }
        )

    response = (
        composed.get("character_response")
        if isinstance(composed.get("character_response"), dict)
        else {}
    )
    evidence = (
        response.get("evidence")
        if isinstance(response.get("evidence"), dict)
        else {}
    )
    if str(response.get("source_contract_sha256") or "") != contract_sha:
        failures.append(
            {
                "check": "character_response_binding",
                "reason": "composed character response is not bound to the pack contract hash",
            }
        )
    if set(evidence) != set(required_fields):
        failures.append(
            {
                "check": "character_response_evidence",
                "reason": "composed evidence must cover every required generic causal field exactly once",
                "expected": required_fields,
                "actual": sorted(evidence),
            }
        )
    for field in required_fields:
        expected_phrase = str(frozen.get(field) or "")
        actual_phrase = str(evidence.get(field) or "")
        if actual_phrase != expected_phrase or not text_contains_term(
            prompt_en, actual_phrase
        ):
            failures.append(
                {
                    "check": "character_response_evidence",
                    "reason": "typed evidence must remain byte-identical to the frozen phrase and literal in prompt_en",
                    "field": field,
                }
            )

    advisory = (
        contract.get("advisory_retrieval")
        if isinstance(contract.get("advisory_retrieval"), dict)
        else {}
    )
    available_ids = {
        str(item.get("candidate_id") or "")
        for item in advisory.get("candidates") or []
        if isinstance(item, dict) and str(item.get("candidate_id") or "")
    }
    selected = nonempty_string_list(response.get("selected_advisory_candidate_ids"))
    if len(selected) != len(set(selected)) or not set(selected) <= available_ids:
        failures.append(
            {
                "check": "character_response_advisory_selection",
                "reason": "selected advisory behavior nodes must be distinct members of the retrieved optional set",
                "unexpected": sorted(set(selected) - available_ids),
            }
        )
    return failures


def expected_semantic_assertion_obligations(
    core: dict[str, Any],
) -> dict[str, Any] | None:
    if core.get("contract_version") != AUTHORIAL_CORE_V3_CONTRACT_VERSION:
        return None
    assertions = [
        item
        for item in core.get("semantic_assertions") or []
        if isinstance(item, dict)
        and item.get("polarity") == "required"
        and item.get("dimension") != "character_response"
    ]
    if not assertions:
        return None
    obligations: list[dict[str, Any]] = []
    for assertion in assertions:
        frozen = copy.deepcopy(assertion.get("evidence") or {})
        obligations.append(
            {
                "assertion_id": str(assertion.get("assertion_id") or ""),
                "dimension": str(assertion.get("dimension") or ""),
                "affected_dimensions": copy.deepcopy(
                    assertion.get("affected_dimensions") or []
                ),
                "source_span_ids": copy.deepcopy(
                    assertion.get("source_span_ids") or []
                ),
                "semantic_axes": copy.deepcopy(assertion.get("axes") or {}),
                "frozen_evidence": frozen,
                "prompt_binding": {
                    "required_evidence_fields": list(frozen),
                    "all_required_phrases_must_be_literal_in_final_prompt": True,
                    "evidence_must_remain_byte_identical": True,
                    "new_hard_evidence_from_retrieval_forbidden": True,
                },
            }
        )
    expected: dict[str, Any] = {
        "contract_version": SEMANTIC_ASSERTION_OBLIGATIONS_CONTRACT_VERSION,
        "enabled": True,
        "source": "authorial_core_semantic_assertions",
        "source_authorial_core_sha256": str(core.get("canonical_sha256") or ""),
        "source_intent_lock_sha256": str(
            ((core.get("intent_lock") or {}).get("canonical_sha256") or "")
        ),
        "composed_field": "semantic_assertion_evidence",
        "obligations": obligations,
    }
    expected["canonical_sha256"] = canonical_json_sha256(expected)
    return expected


def audit_semantic_assertion_obligations_v8(
    pack: dict[str, Any],
    composed: dict[str, Any],
    prompt_en: str,
) -> list[dict[str, Any]]:
    pack = photo_native_pack.read_view(pack)
    core = (
        pack.get("authorial_core")
        if isinstance(pack.get("authorial_core"), dict)
        else {}
    )
    expected = expected_semantic_assertion_obligations(core)
    supplied = (
        pack.get("semantic_assertion_obligations")
        if isinstance(pack.get("semantic_assertion_obligations"), dict)
        else None
    )
    composed_binding = composed.get("semantic_assertion_evidence")
    if expected is None:
        if supplied is None and composed_binding in (None, {}):
            return []
        return [
            {
                "check": "semantic_assertion_obligations_contract",
                "reason": "semantic-assertion evidence was supplied without a required non-character typed assertion",
            }
        ]
    failures: list[dict[str, Any]] = []
    if supplied != expected:
        failures.append(
            {
                "check": "semantic_assertion_obligations_contract",
                "reason": "required typed semantic assertions were changed or dropped after the authorial core was frozen",
            }
        )
    if not isinstance(composed_binding, dict) or set(composed_binding) != {
        "source_contract_sha256",
        "evidence",
    }:
        return failures + [
            {
                "check": "semantic_assertion_evidence",
                "reason": "composed output must bind the exact semantic-assertion contract and evidence map",
            }
        ]
    if composed_binding.get("source_contract_sha256") != expected.get(
        "canonical_sha256"
    ):
        failures.append(
            {
                "check": "semantic_assertion_evidence",
                "reason": "composed semantic evidence is not bound to the governing contract hash",
            }
        )
    actual_by_id = (
        composed_binding.get("evidence")
        if isinstance(composed_binding.get("evidence"), dict)
        else {}
    )
    expected_by_id = {
        str(obligation.get("assertion_id") or ""): obligation.get(
            "frozen_evidence"
        )
        for obligation in expected.get("obligations") or []
        if isinstance(obligation, dict)
    }
    if set(actual_by_id) != set(expected_by_id):
        failures.append(
            {
                "check": "semantic_assertion_evidence",
                "reason": "composed evidence must cover every required assertion exactly once",
                "expected": sorted(expected_by_id),
                "actual": sorted(actual_by_id),
            }
        )
    for assertion_id, expected_evidence in expected_by_id.items():
        actual_evidence = actual_by_id.get(assertion_id)
        if not isinstance(actual_evidence, dict) or actual_evidence != expected_evidence:
            failures.append(
                {
                    "check": "semantic_assertion_evidence",
                    "reason": "typed semantic evidence must remain byte-identical to the frozen assertion",
                    "assertion_id": assertion_id,
                }
            )
            continue
        for field, phrase in expected_evidence.items():
            if not text_contains_term(prompt_en, str(phrase or "")):
                failures.append(
                    {
                        "check": "semantic_assertion_evidence",
                        "reason": "every frozen semantic-evidence phrase must remain literal in prompt_en",
                        "assertion_id": assertion_id,
                        "field": field,
                    }
                )
    return failures


def expected_render_repair_contract(
    core: dict[str, Any],
) -> dict[str, Any] | None:
    lineage = (
        core.get("request_lineage")
        if isinstance(core.get("request_lineage"), dict)
        else {}
    )
    if lineage.get("contract_version") != REQUEST_LINEAGE_V2_CONTRACT_VERSION:
        return None
    targets: list[dict[str, Any]] = []
    required_hard_gates: list[str] = []
    for target in lineage.get("repair_targets") or []:
        if not isinstance(target, dict):
            continue
        repair_id = str(target.get("repair_id") or "")
        gates: list[dict[str, Any]] = [
            {
                "id": f"rr_{repair_id}_object_class_legible",
                "review_scale": "both",
                "criterion": (
                    "The target object is recognizable as the intended object class at thumbnail "
                    "and native scale."
                ),
            },
            {
                "id": f"rr_{repair_id}_gross_structure_coherent",
                "review_scale": "native",
                "criterion": (
                    "The target object's major parts form one coherent, non-grotesque structure; "
                    "minor ornament differences are non-blocking."
                ),
            },
            {
                "id": f"rr_{repair_id}_intended_interaction_matches",
                "review_scale": "both",
                "criterion": (
                    "The actor, object, and intended interaction state match the frozen relation; "
                    "removal, relocation, concealment, or transfer is not a repair."
                ),
            },
        ]
        if str(target.get("actor_object_contact") or "") in {
            "required",
            "transitional",
        }:
            gates.append(
                {
                    "id": f"rr_{repair_id}_contact_anatomy_coherent",
                    "review_scale": "native",
                    "criterion": (
                        "The event-critical actor-object contact and principal anatomy are coherent "
                        "without severe fusion or impossible articulation."
                    ),
                }
            )
        gate_ids = [str(gate["id"]) for gate in gates]
        required_hard_gates.extend(gate_ids)
        targets.append(
            {
                "repair_id": repair_id,
                "source_span_ids": copy.deepcopy(target.get("source_span_ids") or []),
                "importance": str(target.get("importance") or ""),
                "relation_origin": str(target.get("relation_origin") or ""),
                "actor_phrase": str(target.get("actor_phrase") or ""),
                "object_phrase": str(target.get("object_phrase") or ""),
                "interaction_state": str(target.get("interaction_state") or ""),
                "actor_object_contact": str(
                    target.get("actor_object_contact") or ""
                ),
                "protected_dimensions": copy.deepcopy(
                    target.get("protected_dimensions") or []
                ),
                "allowed_repair_axes": copy.deepcopy(
                    target.get("allowed_repair_axes") or []
                ),
                "frozen_evidence": {
                    "interaction_phrase": str(
                        target.get("interaction_phrase") or ""
                    ),
                    "recognition_phrase": str(
                        target.get("recognition_phrase") or ""
                    ),
                },
                "prompt_binding": {
                    "required_evidence_fields": [
                        "interaction_phrase",
                        "recognition_phrase",
                    ],
                    "all_required_phrases_must_be_literal_in_final_prompt": True,
                    "evidence_must_remain_byte_identical": True,
                    "semantic_substitution_forbidden": True,
                },
                "render_gates": gates,
                "required_hard_gates": gate_ids,
            }
        )
    expected: dict[str, Any] = {
        "contract_version": RENDER_REPAIR_CONTRACT_VERSION,
        "enabled": True,
        "source": "authorial_core_request_lineage",
        "source_authorial_core_sha256": str(core.get("canonical_sha256") or ""),
        "source_intent_lock_sha256": str(
            ((core.get("intent_lock") or {}).get("canonical_sha256") or "")
        ),
        "source_request_lineage_sha256": str(
            lineage.get("canonical_sha256") or ""
        ),
        "composed_field": "render_repair_evidence",
        "strict_gate_set": True,
        "major_only": True,
        "targets": targets,
        "required_hard_gates": required_hard_gates,
        "retry_policy": {
            "preserve_interaction_relation": True,
            "repair_smallest_failed_gate_set": True,
            "removal_relocation_concealment_or_transfer_is_not_repair": True,
            "minor_decorative_variation_is_non_blocking": True,
            "maximum_additional_attempts": 1,
        },
    }
    expected["canonical_sha256"] = canonical_json_sha256(expected)
    return expected


def audit_render_repair_v8(
    pack: dict[str, Any],
    composed: dict[str, Any],
    prompt_en: str,
) -> list[dict[str, Any]]:
    pack = photo_native_pack.read_view(pack)
    core = (
        pack.get("authorial_core")
        if isinstance(pack.get("authorial_core"), dict)
        else {}
    )
    expected = expected_render_repair_contract(core)
    supplied = (
        pack.get("render_repair")
        if isinstance(pack.get("render_repair"), dict)
        else None
    )
    composed_binding = composed.get("render_repair_evidence")
    if expected is None:
        if supplied is None and composed_binding in (None, {}):
            return []
        return [
            {
                "check": "render_repair_contract",
                "reason": "render-repair evidence was supplied without a v2 request-lineage repair target",
            }
        ]
    failures: list[dict[str, Any]] = []
    if supplied != expected:
        failures.append(
            {
                "check": "render_repair_contract",
                "reason": "the lineage-bound render-repair contract was changed or dropped after the core was frozen",
            }
        )
    if not isinstance(composed_binding, dict) or set(composed_binding) != {
        "source_contract_sha256",
        "evidence",
    }:
        return failures + [
            {
                "check": "render_repair_evidence",
                "reason": "composed output must bind the exact render-repair contract and evidence map",
            }
        ]
    if composed_binding.get("source_contract_sha256") != expected.get(
        "canonical_sha256"
    ):
        failures.append(
            {
                "check": "render_repair_evidence",
                "reason": "composed render-repair evidence is not bound to the governing contract hash",
            }
        )
    actual_by_id = (
        composed_binding.get("evidence")
        if isinstance(composed_binding.get("evidence"), dict)
        else {}
    )
    expected_by_id = {
        str(target.get("repair_id") or ""): target.get("frozen_evidence")
        for target in expected.get("targets") or []
        if isinstance(target, dict)
    }
    if set(actual_by_id) != set(expected_by_id):
        failures.append(
            {
                "check": "render_repair_evidence",
                "reason": "composed evidence must cover every repair target exactly once",
                "expected": sorted(expected_by_id),
                "actual": sorted(actual_by_id),
            }
        )
    for repair_id, expected_evidence in expected_by_id.items():
        actual_evidence = actual_by_id.get(repair_id)
        if not isinstance(actual_evidence, dict) or actual_evidence != expected_evidence:
            failures.append(
                {
                    "check": "render_repair_evidence",
                    "reason": "repair evidence must remain byte-identical to the frozen target",
                    "repair_id": repair_id,
                }
            )
            continue
        for field, phrase in expected_evidence.items():
            if not text_contains_term(prompt_en, str(phrase or "")):
                failures.append(
                    {
                        "check": "render_repair_evidence",
                        "reason": "every frozen repair-evidence phrase must remain literal in prompt_en",
                        "repair_id": repair_id,
                        "field": field,
                    }
                )
    return failures


@contextlib.contextmanager
def bound_native_source(source_data, query_context=None):
    """Delegate exactly the already validated native request source to sub-audits."""
    if source_data is None:raise ValueError('native pinned generation source is required')
    token=_BOUND_AUDIT_SOURCE.set(source_data);query_token=_BOUND_QUERY_CONTEXT.set(query_context)
    try:yield
    finally:_BOUND_AUDIT_SOURCE.reset(token);_BOUND_QUERY_CONTEXT.reset(query_token)


def native_property_effects_allowed(core, dimensions, effects, *, candidate_id=None, realization_id=None):
    import photo_semantic_evidence as native
    record = None
    if candidate_id:
        try:
            source = _audit_source_data()
            if candidate_id in source['candidates']:
                record = source['candidates'][candidate_id]
                if native.native_status(record)=='qualified':
                    import photo_candidate_corpus as corpus
                    choice=_BOUND_NATIVE_INTERPRETATIONS.get().get(candidate_id,{})
                    selected_rid=realization_id or choice.get('realization_id')
                    maps=native.proof_of(record)['owner_maps']
                    if selected_rid is None and len(maps)==1:selected_rid=next(iter(maps))
                    record=corpus.entry(source,candidate_id,realization_id=selected_rid,
                        dependency_selections=choice.get('dependency_selections'),owner_selections=_BOUND_OWNER_SELECTIONS.get())
        except (KeyError, TypeError, ValueError):
            return False
    return native.property_scope_allowed(core, dimensions, effects, record=record, realization_id=realization_id,owner_selections=_BOUND_OWNER_SELECTIONS.get())


def audit_native_member_requirement_evidence(source_data, closure, selections, interpretation, prompt):
    """Preserve selected semantic/render obligations without treating them as guards."""
    import photo_semantic_evidence as native
    expected={}
    for selected in closure:
        parent_id=selected['candidate_id'];rid=selected['realization_id']
        record=source_data['candidates'][parent_id];guard=native.compact(record,source_data)
        adopted={row['candidate_id'] for row,_ in native.selected_dependencies(guard,rid,selections)}
        for pointer in canonical.native(record).get('member_candidates',[]):
            child_id=pointer['candidate_id'];requirements=pointer.get('requirements') or {}
            if child_id not in adopted:continue
            units=requirements.get('concept_units') or [];relations=requirements.get('relations') or []
            if not units and not relations:continue
            expected.setdefault(parent_id,{})[child_id]={
                'concept_units':{str(index) for index in range(len(units))},
                'relations':{row['id'] for row in relations}}
    evidence=interpretation.get('member_requirement_evidence') or {}
    if not isinstance(evidence,dict) or set(evidence)!=set(expected):
        raise ValueError('selected member semantic/render requirements need explicit literal evidence')
    for parent_id,children in expected.items():
        if not isinstance(evidence[parent_id],dict) or set(evidence[parent_id])!=set(children):
            raise ValueError('member requirement evidence must cover exactly selected parent/child CID edges')
        for child_id,fields in children.items():
            item=evidence[parent_id][child_id]
            if not isinstance(item,dict) or set(item)!=set(fields):
                raise ValueError('member requirement evidence must separate positive units and relations')
            for field,ids in fields.items():
                rows=item[field]
                if (not isinstance(rows,dict) or set(rows)!=ids
                        or any(not isinstance(value,str) or not value.strip() or not text_contains_term(prompt,value)
                               for value in rows.values())):
                    raise ValueError('selected member unit/relation evidence is missing or not literal in the final prompt')


def audit_selected_native_profile(entry, interpretation, prompt):
    contract=entry.get('_selected_profile_contract')
    if contract is None:return
    obligation=candidate_semantics_generator.candidate_pack_visual_profile_obligation(
        entry,{},activation_source='native_actual_realization',source_intent_ids=[])
    if interpretation.get('selected_profile_contract')!=contract:
        raise ValueError('final selected profile contract must match exact CID/RID/meaning/obligation')
    evidence=interpretation.get('selected_profile_evidence')
    required=obligation['prompt_binding']['required_evidence_fields']
    if not isinstance(evidence,dict) or set(evidence)!=set(required):
        raise ValueError('final profile evidence must cover exactly the selected obligations')
    for field in required:
        phrase=evidence[field];rule=obligation['evidence_requirements'][field]
        if (not isinstance(phrase,str) or not phrase.strip() or phrase not in prompt
                or len(phrase.split())<rule['min_content_words']
                or not any(text_contains_term(phrase,term) for term in rule['must_mention_any'])
                or any(text_contains_term(phrase,term) for term in rule.get('must_not_contain',[]))):
            raise ValueError('selected profile duty has missing/invalid literal final evidence')


def audit_native_profile_choices(pack,composed,source_data,chosen,interpretations):
    """The presented choice never substitutes for current canonical source proof."""
    import photo_candidate_corpus as corpus
    import photo_candidate_realizations as realizations
    import photo_semantic_evidence as native
    value=pack.get('native_profile_choices')
    native_profile_choice_rows(pack)
    refs=set((source_data.get('policies') or {}).get('visual_profile_refs') or [])
    refs.update(cid for cid in chosen if cid in source_data['candidates'] and canonical.contract(source_data['candidates'][cid])=='profile')
    reader=source_data.get('_search_reader')
    guards=reader.meta['guards'] if reader is not None else source_data['candidates']
    projected=[corpus.entry(source_data,cid) for cid in sorted(refs)
               if canonical.native(guards[cid]).get('realization_content')]
    core=pack.get('authorial_core') or {};controls=pack.get('creative_controls')
    required=candidate_semantics_generator.native_required_profile_ids(projected,core,
        controls if isinstance(controls,dict) and 'canonical_sha256' in controls else None,pack.get('visual_intent'))
    projected_ids={row['id'] for row in projected}
    if value is None:
        if required or chosen & projected_ids:
            raise ValueError('selected/request-required conditional profile has no source-bound actual choice inventory')
        return
    if (not isinstance(value,dict) or set(value)!={'schema','profiles'}
            or value['schema']!='photo-native-profile-choices/v1' or not isinstance(value['profiles'],list)
            or len(value['profiles'])>64):
        raise ValueError('bounded native profile choices required')
    seen=set()
    for profile in value['profiles']:
        if (not isinstance(profile,dict) or set(profile)!={'candidate_id','required','source_record_sha256','choices'}
                or type(profile['required']) is not bool or profile['candidate_id'] in seen):
            raise ValueError('exact unique profile choice source required')
        cid=profile['candidate_id'];seen.add(cid);record=source_data['candidates'][cid]
        if cid in required and profile['required'] is not True:
            raise ValueError('request-required native profile cannot downgrade activation')
        if (canonical.contract(record)!='profile' or not canonical.native(record).get('realization_content')
                or profile['source_record_sha256']!=corpus.digest(record)
                or not isinstance(profile['choices'],list) or len(profile['choices'])>32):
            raise ValueError('profile choices no longer match the pinned source')
        available={}
        for choice in profile['choices']:
            if (not isinstance(choice,dict) or set(choice)-{'owner_selection_requirements'}!={'realization_id','qualification','selected_profile_contract',
                    'obligation','en','ko','concept_units','relations','affected_dimensions','affected_properties'}
                    or choice['realization_id'] in available):
                raise ValueError('exact unique actual profile choice required')
            rid=choice['realization_id'];entry=corpus.entry(source_data,cid,realization_id=rid)
            dimensions,properties=(native.permission_scope(entry,pack.get('authorial_core') or {})[:2] if native.native_status(record)=='qualified' and not native.pending_owner_selection(entry) else
                (entry['affected_dimensions'],entry['affected_properties']))
            expected={'realization_id':rid,'qualification':native.native_status(record),
                'selected_profile_contract':entry.get('_selected_profile_contract'),
                'obligation':candidate_semantics_generator.candidate_pack_visual_profile_obligation(entry,{},
                    activation_source='native_actual_realization',source_intent_ids=[]) if native.native_status(record)=='qualified' else None,
                'en':entry.get('en'),'ko':entry.get('ko'),'concept_units':entry.get('concept_units') or [],
                'relations':entry.get('relations') or [],'affected_dimensions':dimensions,
                'affected_properties':properties}
            if entry.get('owner_selection_requirements'):expected['owner_selection_requirements']=entry['owner_selection_requirements']
            # Policies may add generic evidence checks, but native source duties
            # and exact obligation/source bindings cannot be weakened.
            provided=copy.deepcopy(choice);expected_obligation=expected.pop('obligation');provided_obligation=provided.pop('obligation')
            if provided!=expected or (provided_obligation is None)!=(expected_obligation is None):
                raise ValueError('profile selected projection/qualification changed')
            if expected_obligation is not None:
                for key in ('id','composition_instruction','component_semantics','evidence_requirements','render_gates','native_profile_contract'):
                    if provided_obligation.get(key)!=expected_obligation[key]:
                        raise ValueError('profile selected compiled obligations changed')
                if provided_obligation.get('prompt_binding',{}).get('required_evidence_fields')!=expected_obligation['prompt_binding']['required_evidence_fields']:
                    raise ValueError('profile selected evidence fields changed')
            available[rid]=choice
        if profile['required'] and cid not in chosen:
            raise ValueError('request-activated profile requires an explicit actual realization selection')
        if cid in chosen:
            selected=(interpretations.get(cid) or {}).get('realization_id')
            if selected not in available or available[selected]['qualification']!='qualified':
                raise ValueError('chosen profile requires one presented qualified actual realization')

    if not required<=seen:raise ValueError('request-required native profile choice inventory is missing')


def _native_adoption_entries(pack,composed,source_data):
    """One source-qualified resolved view for all actual chosen native roots."""
    import photo_semantic_evidence as native
    import photo_candidate_corpus as corpus
    chosen=normalize_chosen_candidate_ids(composed.get('chosen_candidate_ids'))
    chosen.update(normalize_chosen_candidate_ids(composed.get('chosen_visual_concept_ids')))
    transformed=[row for row in (composed.get('creative_augmentation_brief') or {}).get('decisions',[])
        if isinstance(row,dict) and row.get('decision')=='transformed']
    chosen.update(row['candidate_id'] for row in transformed if row.get('candidate_id'))
    interpretations={row.get('candidate_id'):row for row in [*(composed.get('candidate_interpretations') or []),*transformed] if isinstance(row,dict)}
    entries=[];core=pack.get('authorial_core') or {}
    for cid in sorted(chosen):
        try:
            presented=(pack.get('candidate_pool') or {}).get(cid,{})
            source_id=cid if cid in source_data['candidates'] else presented.get('source_candidate_id',cid)
            if source_id not in source_data['candidates']:
                if not corpus.ID.fullmatch(source_id):continue
                raise ValueError('chosen cue has no pinned canonical native source')
            native.validate(source_data['candidates'][source_id],source_data['slot_catalog'],corpus=source_data)
            if native.native_status(source_data['candidates'][source_id])!='qualified':raise ValueError('chosen native source is unqualified')
            interpretation=interpretations.get(cid,{})
            entries.append(corpus.entry(source_data,source_id,interpretation.get('binding_id',presented.get('binding_id')),
                realization_id=interpretation.get('realization_id'),dependency_selections=interpretation.get('dependency_selections'),
                owner_selections=composed.get('owner_selections')))
        except (ValueError,KeyError,TypeError) as exc:
            error=ValueError(str(exc));error.candidate_id=cid;raise error from exc
    return entries


def audit_native_adoptions(pack,composed,source_data,*,resolution_out=None):
    import photo_semantic_evidence as native
    import photo_candidate_corpus as corpus
    core=pack.get('authorial_core') or {}
    try:entries=_native_adoption_entries(pack,composed,source_data)
    except (ValueError,KeyError,TypeError) as exc:
        return [{'check':'native_candidate_adoption','candidate_id':getattr(exc,'candidate_id',None),'reason':str(exc)}]
    if not entries:return _audit_native_adoptions(pack,composed,source_data,resolution_out=resolution_out)
    try:
        with native.bound_selected_resolution(entries,core) as context:
            output={};failures=_audit_native_adoptions(pack,composed,source_data,resolution_out=output)
            if 'native_permission_receipt' in composed or 'native_preservation_receipt' in composed:
                raise ValueError('native permission/preservation receipts are auditor output, never composed input')
            final_preservation=native.audit_final_scalar_preservation(entries,core)
            if final_preservation is not None:
                output['native_preservation_receipt']=final_preservation
            if not failures and resolution_out is not None and output:
                if context['scoped']:
                    output.update(schema='photo-native-owner-resolution/v2',
                        member_scopes_sha256=context['view']['context']['member_scopes_sha256'],
                        input_binding=copy.deepcopy(context['view']['context']['input_binding']),
                        resolved_view=copy.deepcopy(context['view']))
                    output.pop('canonical_sha256',None);output['canonical_sha256']=corpus.digest(output)
                resolution_out.update(output)
            return failures
    except (ValueError,KeyError,TypeError) as exc:
        joint='conflicting joint effect assignment' in str(exc)
        return [{'check':'native_joint_effect_assignments' if joint else 'native_candidate_adoption',
            **({'candidate_id':native._proof_cid(native.proof_of(entries[0]))} if len(entries)==1 else {}),'reason':str(exc)}]



def _audit_native_adoptions(pack, composed, source_data,*,resolution_out=None):
    """Search recall never certifies a chosen cue's whole actual native effects."""
    import photo_candidate_corpus as corpus
    import photo_semantic_evidence as native
    core = pack.get('authorial_core') or {}
    chosen = normalize_chosen_candidate_ids(composed.get('chosen_candidate_ids'))
    chosen.update(normalize_chosen_candidate_ids(composed.get('chosen_visual_concept_ids')))
    transformed = [row for row in (composed.get('creative_augmentation_brief') or {}).get('decisions', [])
                   if isinstance(row, dict) and row.get('decision') == 'transformed']
    chosen.update(row.get('candidate_id') for row in transformed if row.get('candidate_id'))
    interpretations = {row.get('candidate_id'): row for row in
        [*(composed.get('candidate_interpretations') or []), *transformed] if isinstance(row, dict)}
    failures = [];nodes=[];closures=[];joint_entries=[];admissions=[];owner_selections=composed.get('owner_selections')
    try:
        graph=native.frozen_witnesses(core)['graph']
        selected_entries=native.validate_owner_selections(owner_selections,core,graph)
        if 'native_owner_resolution' in composed or 'native_owner_resolution_sha256' in composed:
            raise ValueError('native owner resolution is auditor output, not composed input')
    except (ValueError,KeyError,TypeError) as exc:
        failures.append({'check':'native_owner_selections','reason':str(exc)});selected_entries={}
    try: audit_native_profile_choices(pack,composed,source_data,chosen,interpretations)
    except (ValueError,KeyError,TypeError) as exc:
        failures.append({'check':'native_profile_choices','reason':str(exc)})
    for cid in sorted(chosen):
        try:
            # Noncanonical authorial decisions retain their separate audit. A
            # source candidate can never escape through a pack projection ID.
            source_id = cid
            if cid not in source_data['candidates']:
                projected = (pack.get('candidate_pool') or {}).get(cid, {})
                source_id = projected.get('source_candidate_id', cid)
            if source_id not in source_data['candidates'] and not corpus.ID.fullmatch(source_id):
                continue  # Policy-authored directions have their own bounded audit.
            if source_id not in source_data['candidates']:
                raise ValueError('chosen cue has no pinned canonical native source')
            native.validate(source_data['candidates'][source_id], source_data['slot_catalog'], corpus=source_data)
            interpretation = interpretations.get(cid, {})
            presented=(pack.get('candidate_pool') or {}).get(cid,{})
            binding_id=interpretation.get('binding_id',presented.get('binding_id'))
            if presented.get('binding_id') and binding_id!=presented['binding_id']:
                raise ValueError('chosen presentation binding differs from the source-bound pack')
            entry = corpus.entry(source_data, source_id, binding_id,
                realization_id=interpretation.get('realization_id'),
                dependency_selections=interpretation.get('dependency_selections'),owner_selections=owner_selections)
            receipt = native.admission(entry, core)
            if receipt['status'] != 'qualified' or not receipt['allowed']:
                raise ValueError(receipt.get('reason', 'native whole-cue admission failed'))
            def collect_owner_rows(value):
                if value.get('owner_resolution'):
                    row=copy.deepcopy(value['owner_resolution']);row['resolved_frozen_facts']=copy.deepcopy(value.get('resolved_frozen_facts',[]));nodes.append(row)
                for child in value.get('dependencies',[]):
                    if child.get('admission'):collect_owner_rows(child['admission'])
            collect_owner_rows(receipt)
            if native._ACTIVE_RESOLUTION.get()['scoped']:admissions.append({'candidate_id':source_id,'realization_id':entry.get('_realization_id','base'),'admission':copy.deepcopy(receipt)})
            native.audit_scope_preservation(receipt,interpretation,str(composed.get('prompt_en') or ''))
            audit_selected_native_profile(entry,interpretation,str(composed.get('prompt_en') or ''))
            constraints, picked = candidate_semantics_generator.frozen_core_context(
                source_data, core, pack.get('creative_controls') or {})
            import photo_candidate_realizations as realizations
            proof = native.proof_of(entry); selected_rid = entry.get('_realization_id', 'base')
            selections = entry.get('_native_dependency_selections', {})
            closure = native.effect_closure(source_id, proof, selected_rid, selections)
            closures.append({'candidate_id':source_id,'realization_id':selected_rid,
                'dependency_selections':copy.deepcopy(selections),'effect_closure':closure})
            audit_native_member_requirement_evidence(source_data,closure,selections,interpretation,
                str(composed.get('prompt_en') or ''))
            for selected_source in closure:
                selected_id = selected_source['candidate_id']; rid = selected_source['realization_id']
                child_record = source_data['candidates'][selected_id]
                child_guard = native.compact(child_record, source_data)
                relevant = native.dependency_choices(child_guard, rid)
                child_selections = {key:value for key,value in selections.items() if key in relevant}
                child_entry = corpus.entry(source_data, selected_id, realization_id=rid,
                    dependency_selections=child_selections,owner_selections=owner_selections,guard_root=entry)
                audit_selected_native_profile(child_entry, interpretation if selected_id==source_id else interpretations.get(selected_id,{}),
                    str(composed.get('prompt_en') or ''))
                if not candidate_semantics_generator.core_entry_eligible(source_data, core, constraints, picked, '', child_entry):
                    raise ValueError('selected source intrinsic conditions or native effect scope are incompatible')
                branch = realizations.branch(child_record, rid)
                if not realizations.context_satisfied(branch, core):
                    raise ValueError('selected actual branch has no existing required context')
                if branch and branch.get('conditions') and not candidate_semantics_generator.core_entry_eligible(
                        source_data, core, constraints, picked, '', {**child_entry, **branch['conditions']}, check_effect_scope=False):
                    raise ValueError('selected actual branch conditions are incompatible')
                for member in canonical.native(child_record).get('member_candidates', []):
                    if (member['candidate_id'] not in realizations.member_ids(child_record, rid)
                            or member['candidate_id'] not in {row['candidate_id'] for row in closure}
                            or not member.get('binding_id')):
                        continue
                    member_record = source_data['slot_bindings'][member['binding_id']]
                    member_choice = next(row['realization_id'] for row in closure if row['candidate_id']==member['candidate_id'])
                    member_entry = corpus.entry(source_data, member['candidate_id'], member['binding_id'],
                        realization_id=member_choice, dependency_selections={key:value for key,value in selections.items()
                            if key in native.dependency_choices(native.compact(source_data['candidates'][member['candidate_id']], source_data),member_choice)},owner_selections=owner_selections,guard_root=entry)
                    if not candidate_semantics_generator.core_entry_eligible(source_data, core, constraints, picked,
                            member_record['slot_id'], member_entry):
                        raise ValueError('selected member presentation conditions are incompatible')
            dimensions, properties, _ = native.permission_scope(entry, core)
            if (not set(dimensions) <= set((core.get('intent_lock') or {}).get('open_dimensions') or [])
                    or not native.property_scope_allowed(core, dimensions, properties)):
                raise ValueError('selected whole native effects conflict with frozen dimension/property scope')
            joint_entries.append(entry)
        except (KeyError, ValueError, TypeError) as error:
            failures.append({'check':'native_candidate_adoption','candidate_id':cid,'reason':str(error)})
    try:
        native.validate_joint_effect_assignments(joint_entries, core)
    except (KeyError, ValueError, TypeError) as error:
        failures.append({'check':'native_joint_effect_assignments','reason':str(error)})
    if owner_selections is not None:
        unique_nodes={}
        for row in nodes:
            key=(row['candidate_id'],row['realization_id'])
            if key in unique_nodes and unique_nodes[key]!=row:
                failures.append({'check':'native_owner_selections','reason':'conflicting selected-closure owner resolutions'})
            unique_nodes[key]=row
        nodes=list(unique_nodes.values())
        used=set(unique_nodes)
        if used!=set(selected_entries):failures.append({'check':'native_owner_selections','reason':'missing/unused/foreign selected-closure owner bindings'})
        if not failures and resolution_out is not None:
            value={'schema':'photo-native-owner-resolution/v1','pack_sha256':corpus.digest(pack),
                'composed_sha256':corpus.digest(composed),'core_sha256':core['canonical_sha256'],
                'owner_graph_sha256':corpus.digest(graph),'owner_selections_sha256':corpus.digest(owner_selections),
                'nodes':sorted(nodes,key=lambda row:(row['candidate_id'],row['realization_id'])),
                'selected_closures':sorted(closures,key=lambda row:(row['candidate_id'],row['realization_id']))}
            if admissions:value['native_admissions']=admissions
            value['canonical_sha256']=corpus.digest(value);resolution_out.update(value)
    return failures


def audit_composed_prompt(pack,composed,*,source_data=None,runtime_receipt=None,runtime_store=None,query_context=None):
    if runtime_receipt is not None:
        from photo_runtime_sources import RuntimeSnapshotProvider
        snapshot=RuntimeSnapshotProvider(store=runtime_store).from_receipt(pack,runtime_receipt)
        source_data=snapshot.data;query_context=snapshot.query_context
    if source_data is None:
        source_data=_BOUND_AUDIT_SOURCE.get();query_context=_BOUND_QUERY_CONTEXT.get()
    if source_data is None:raise ValueError('native pinned generation source is required')
    try:photo_native_pack.validate(pack)
    except (KeyError,TypeError,ValueError) as error:
        return {'status':'fail','quality_status':'not_run','pack_id':pack.get('pack_id'),
                'failures':[{'check':'native_candidate_pack','reason':str(error)}],'warnings':[]}
    if hasattr(source_data,'for_core'):
        source_data=photo_shared_views.RequestCandidates(source_data.for_core(pack['authorial_core']),pack['candidate_pool'],pack['role_proposals'])
    token=_BOUND_AUDIT_SOURCE.set(source_data);query_token=_BOUND_QUERY_CONTEXT.set(query_context)
    owner_token=_BOUND_OWNER_SELECTIONS.set(composed.get('owner_selections'))
    choice_token=_BOUND_NATIVE_INTERPRETATIONS.set({row['candidate_id']:row for row in
        [*(composed.get('candidate_interpretations') or []), *[row for row in
            ((composed.get('creative_augmentation_brief') or {}).get('decisions') or []) if isinstance(row,dict) and row.get('decision')=='transformed']]
        if isinstance(row,dict) and row.get('candidate_id')})
    try:
        import photo_semantic_evidence as native
        with contextlib.ExitStack() as stack:
            try:
                entries=_native_adoption_entries(pack,composed,source_data)
                if entries:stack.enter_context(native.bound_selected_resolution(entries,pack['authorial_core']))
            except (ValueError,KeyError,TypeError):pass  # strict native audit below records the failure
            report = _audit_composed_prompt(photo_native_pack.read_view(pack),composed)
            resolution={}
            report['failures'].extend(audit_native_adoptions(pack,composed,source_data,resolution_out=resolution))
            if report['failures']: report['status'] = 'fail'
            elif resolution:report['native_owner_resolution']=resolution
            return report
    finally:_BOUND_AUDIT_SOURCE.reset(token);_BOUND_QUERY_CONTEXT.reset(query_token);_BOUND_OWNER_SELECTIONS.reset(owner_token);_BOUND_NATIVE_INTERPRETATIONS.reset(choice_token)



def _audit_composed_prompt(pack: dict[str, Any], composed: dict[str, Any]) -> dict[str, Any]:
    pack = photo_native_pack.read_view(pack)
    failures: list[dict[str, Any]] = []
    retired_fields = {"authorial_request", "hybrid_augmentation", "moe_response"} & set(pack)
    if retired_fields:
        failures.append({"check": "retired_contract_fields", "reason": "unsupported historical contract fields", "fields": sorted(retired_fields)})
    warnings: list[dict[str, Any]] = []
    prompt_en = str(composed.get("prompt_en") or "")
    search_text = composed_search_text(composed)
    negative_en = composed.get("negative_en")

    contract_version = str(pack.get("contract_version") or "")
    if contract_version not in SUPPORTED_CANDIDATE_PACK_VERSIONS:
        failures.append(
            {
                "check": "contract_version",
                "reason": "unsupported candidate-pack contract",
                "expected": sorted(SUPPORTED_CANDIDATE_PACK_VERSIONS),
                "actual": contract_version or None,
            }
        )
    failures.extend(audit_authorial_pack(pack))
    try:
        source_data = _audit_source_data()
        failures.extend(audit_global_retrieval(pack, source_data))
    except (OSError, KeyError, TypeError, ValueError) as exc:
        failures.append({"check": "global_retrieval_contract", "reason": f"source recomputation failed: {exc}"})
    expected_retrieval_sha = (pack.get("global_retrieval") or {}).get("canonical_sha256")
    if not expected_retrieval_sha or composed.get("global_retrieval_sha256") != expected_retrieval_sha:
        failures.append({"check": "global_retrieval_binding", "reason": "composed prompt must bind the exact core retrieval contract"})

    required_fields = ("pack_id", "prompt_en", "negative_en", "chosen_candidate_ids", "composer")
    missing_fields = [field for field in required_fields if field not in composed]
    if missing_fields:
        failures.append({"check": "output_contract", "reason": "missing required fields", "fields": missing_fields})
    if not prompt_en.strip():
        failures.append({"check": "output_contract", "reason": "missing prompt_en"})
    if composed.get("composer") != "agent":
        failures.append({"check": "output_contract", "reason": "composer must equal agent"})

    pack_id = str(pack.get("pack_id") or "")
    composed_pack_id = str(composed.get("pack_id") or "")
    expected_pack_id = computed_pack_id(pack)
    if not pack_id or pack_id != expected_pack_id:
        failures.append(
            {
                "check": "pack_integrity",
                "reason": "candidate pack content does not match pack_id",
                "expected": expected_pack_id,
                "actual": pack_id or None,
            }
        )
    if composed_pack_id != pack_id:
        failures.append({"check": "pack_id", "reason": "pack_id mismatch", "expected": pack_id, "actual": composed_pack_id})

    pack_negative = pack.get("negative_en")
    if negative_en != pack_negative:
        failures.append({"check": "negative_en", "reason": "negative_en differs from candidate pack"})
    failures.extend(audit_negative_intent_guard(pack, prompt_en))

    failures.extend(audit_creative_direction(pack, composed, prompt_en))
    failures.extend(audit_character_response_v8(pack, composed, prompt_en))
    failures.extend(
        audit_semantic_assertion_obligations_v8(pack, composed, prompt_en)
    )
    failures.extend(audit_render_repair_v8(pack, composed, prompt_en))
    failures.extend(photo_embodiment.audit_composed(pack, composed))
    failures.extend(audit_visual_obligations(pack, composed, prompt_en))
    failures.extend(audit_viewer_experience(pack, composed, prompt_en))
    failures.extend(audit_authorial_core(pack, composed, prompt_en, warnings))
    failures.extend(audit_semantic_clarification(pack, composed, prompt_en))

    safety = pack.get("safety") if isinstance(pack.get("safety"), dict) else {}
    if safety.get("status") != "pass" or safety.get("requires_user_approval") is True:
        failures.append({"check": "safety", "reason": "candidate pack safety contract is not pass", "safety": safety})
    mandatory_texts = {
        str(intent.get("text") or "")
        for intent in pack.get("mandatory_intents") or []
        if isinstance(intent, dict) and str(intent.get("text") or "")
    }
    assertions = composed.get("coverage_assertions")
    if assertions is not None and not isinstance(assertions, dict):
        failures.append({"check": "coverage_assertions", "reason": "coverage_assertions must be an object"})
    elif isinstance(assertions, dict):
        for key, raw in assertions.items():
            if str(key) not in mandatory_texts:
                failures.append({"check": "coverage_assertions", "reason": "assertion key is not a mandatory intent", "intent": key})
            for phrase in assertion_values(raw):
                if not text_contains_term(prompt_en, phrase):
                    failures.append(
                        {
                            "check": "coverage_assertions",
                            "reason": "asserted phrase is not literal in prompt_en",
                            "intent": key,
                            "phrase": phrase,
                        }
                    )

    for intent in pack.get("mandatory_intents") or []:
        if not isinstance(intent, dict):
            continue
        terms = assertion_terms_for_intent(intent, composed)
        if not any(text_contains_term(prompt_en, term) for term in terms):
            failures.append(
                {
                    "check": "mandatory_intent",
                    "reason": "intent not represented in prompt_en",
                    "intent": intent.get("text"),
                    "accepted_terms": terms,
                }
            )
        elif intent.get("status") == "uncovered":
            warnings.append(
                {
                    "check": "uncovered_intent",
                    "reason": "uncovered candidate-pack intent was preserved by free description/assertion",
                    "intent": intent.get("text"),
                }
            )

    chosen = normalize_chosen_candidate_ids(composed.get("chosen_candidate_ids"))
    valid_ids = candidate_ids_from_pack(pack)
    if not chosen and contract_version not in {
        "photo-candidate-pack/v10",
    }:
        failures.append({"check": "chosen_candidate_ids", "reason": "no chosen_candidate_ids supplied"})
    invalid = sorted(candidate_id for candidate_id in chosen if candidate_id not in valid_ids)
    if invalid:
        failures.append({"check": "chosen_candidate_ids", "reason": "unknown candidate id", "ids": invalid})

    candidate_objects = candidate_objects_from_pack(pack)
    ineligible = []
    for candidate_id in sorted(chosen):
        candidate = candidate_objects.get(candidate_id)
        if not isinstance(candidate, dict):
            continue
        applicability = candidate.get("applicability") if isinstance(candidate.get("applicability"), dict) else {}
        if (applicability and applicability.get("status") != "eligible"
                and not (candidate.get('owner_selection_requirements')
                         and applicability.get('status')=='review_required')):
            ineligible.append(
                {
                    "id": candidate_id,
                    "status": applicability.get("status"),
                    "reason": applicability.get("reason"),
                }
            )
    if ineligible:
        failures.append(
            {
                "check": "candidate_applicability",
                "reason": "chosen candidate is not eligible for this request",
                "candidates": ineligible,
            }
        )

    adult_failures, adult_warnings = audit_adult_appeal(
        pack,
        composed,
        prompt_en,
        chosen,
        candidate_objects,
    )
    failures.extend(adult_failures)
    warnings.extend(adult_warnings)


    failures.extend(
        audit_creative_augmentation(
            pack,
            composed,
            prompt_en,
            chosen,
        )
    )
    failures.extend(
        audit_candidate_interpretations(
            pack,
            composed,
            prompt_en,
            chosen,
            candidate_objects,
        )
    )

    coverage = pack.get("coverage") if isinstance(pack.get("coverage"), dict) else {}
    intent_constraints = coverage.get("intent_constraints") if isinstance(coverage.get("intent_constraints"), dict) else {}
    no_people = bool(intent_constraints.get("no_people")) or any(
        isinstance(intent, dict) and "no_people" in (intent.get("constraints") or [])
        for intent in pack.get("intent_contract") or []
    )
    if no_people:
        violations: list[dict[str, Any]] = []
        for candidate_id in sorted(chosen):
            candidate = candidate_objects.get(candidate_id)
            if not isinstance(candidate, dict) or not str(candidate.get("slot") or ""):
                continue
            slot = str(candidate.get("slot") or "")
            tokens = {
                str(item).lower()
                for item in [*(candidate.get("kind") or []), *(candidate.get("tags") or [])]
            }
            conditions = candidate.get("source_conditions") or (candidate.get("authored_record") or {}).get("conditions") or {}
            categories = set(conditions.get("for_any") or [])
            if "human" in tokens or categories == {"human"}:
                violations.append({"id": candidate_id, "slot": slot, "tokens": sorted(tokens)[:12]})
        if violations:
            failures.append(
                {
                    "check": "negative_presence_constraint",
                    "reason": "no-people request contains person-only chosen candidates",
                    "candidates": violations,
                }
            )

    for conflict in pack.get("conflicts") or []:
        if not isinstance(conflict, dict) or str(conflict.get("severity") or "hard") != "hard":
            continue
        conflict_ids = {str(candidate_id) for candidate_id in conflict.get("candidates", [])}
        if conflict_ids and conflict_ids <= chosen:
            failures.append(
                {
                    "check": "hard_conflict",
                    "reason": "conflicting candidates selected together",
                    "conflict_id": conflict.get("id"),
                    "candidate_ids": sorted(conflict_ids),
                }
            )

    photographic_warning = audit_photographic_integration(pack, search_text)
    if photographic_warning:
        warnings.append(photographic_warning)
    proposition_warning = audit_visual_proposition(pack, search_text)
    if proposition_warning:
        warnings.append(proposition_warning)
    craft_warning = audit_photographic_craft(pack, search_text)
    if craft_warning:
        warnings.append(craft_warning)
    final_touch_warning = audit_artistic_final_touch(pack, prompt_en)
    if final_touch_warning:
        warnings.append(final_touch_warning)

    status = "fail" if failures else "pass"
    quality_status = "warn" if warnings else "pass"
    effective_visual_contract, _ = derive_effective_visual_obligation_contract(
        pack,
        composed,
    )
    return {
        "status": status,
        "quality_status": quality_status,
        "pack_id": pack_id or None,
        "chosen_candidate_count": len(chosen),
        "chosen_visual_concept_ids": [
            str(value)
            for value in (effective_visual_contract or {}).get(
                "selected_visual_concept_ids"
            )
            or []
            if str(value).strip()
        ],
        "effective_visual_contract_sha256": effective_visual_obligation_sha256(
            effective_visual_contract
        ),
        "render_repair_contract_sha256": (
            str((pack.get("render_repair") or {}).get("canonical_sha256") or "")
            if isinstance(pack.get("render_repair"), dict)
            else None
        ),
        "failures": failures,
        "warnings": warnings,
    }


def parse_args(argv: Sequence[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Audit an agent-composed prompt against a candidate pack.")
    parser.add_argument("--pack", required=True, help="Candidate pack JSON path or inline JSON.")
    parser.add_argument("--composed", required=True, help="Composed prompt JSON path or inline JSON.")
    parser.add_argument("--plain", action="store_true", help="Print only pass/fail summary.")
    parser.add_argument("--runtime-store")
    parser.add_argument("--runtime-receipt", help="Private receipt saved with this pack; otherwise resolve its exact hash from runtime storage.")
    return parser.parse_args(argv)


def main(argv: Sequence[str] | None = None) -> int:
    try:
        args = parse_args(argv)
        pack = first_pack(load_json_arg(args.pack))
        composed = composed_object(load_json_arg(args.composed))
        from photo_runtime_sources import RuntimeSnapshotProvider
        receipt_path = args.runtime_receipt
        if receipt_path is None and Path(str(args.pack) + ".runtime-receipt.json").is_file():
            receipt_path = str(args.pack) + ".runtime-receipt.json"
        receipt = load_json_arg(receipt_path) if receipt_path else None
        snapshot = RuntimeSnapshotProvider(store=Path(args.runtime_store) if args.runtime_store else None).from_receipt(pack, receipt)
        result = audit_composed_prompt(pack, composed, source_data=snapshot.data,query_context=snapshot.query_context)
    except Exception as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 2

    if args.plain:
        print(result["status"])
    else:
        print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))
    return 0 if result["status"] == "pass" else 1


def english_prompt_word_count(text: str) -> int:
    """Count image-prompt words consistently across the contract and audit."""
    return len(re.findall(r"[A-Za-z0-9]+(?:['’\-][A-Za-z0-9]+)*", str(text or "")))


if __name__ == "__main__":
    raise SystemExit(main())
