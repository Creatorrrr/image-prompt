"""Production H/F2 kernel: full positive RID pool; one invocation per lane."""
import math
import numpy as np
import photo_recall_first as rf
from photo_recall_first import require

def fuse(metadata,sparse,dense,k):
    require(type(k) is int and k in (10,30),'only frozen RRF10/30 admitted')
    ids=[d['id'] for d in metadata]
    require(len(ids)==len(set(ids))==len(sparse)==len(dense),'lane identity mismatch')
    require(all(math.isfinite(float(v)) for v in [*sparse,*dense]),'nonfinite score')
    require(all(v>=0 for v in sparse),'negative sparse score')
    lr={i:r for r,i in enumerate(sorted((i for i,s in enumerate(sparse) if s>0),key=lambda i:(-sparse[i],ids[i])),1)}
    dr={i:r for r,i in enumerate(sorted(range(len(ids)),key=lambda i:(-dense[i],ids[i])),1)}
    rows=[{'id':d['id'],'cid':d['cid'],'rid':d['rid'],'bm25':float(sparse[i]),'cosine':float(dense[i]),
           'bm25_rank':lr.get(i),'dense_rank':dr[i],
           'rrf':(1/(k+lr[i]) if i in lr else 0.)+1/(k+dr[i])} for i,d in enumerate(metadata)]
    rows.sort(key=lambda d:(-d['rrf'],d['id']))
    seen=set();out=[]
    for row in rows:
        if row['cid'] not in seen:seen.add(row['cid']);out.append(row)
    return out


def field_scores(index,query,tokenize,weighted):
    scores=[0.]*index['n']
    for term in sorted(set(tokenize(query))):
        postings=index['postings'].get(term,[])
        idf=math.log1p((index['n']-len(postings)+.5)/(len(postings)+.5))
        for i,fields in postings:
            terms=[]
            for field,tf in sorted(fields.items()):
                config=index['fields'][field];avg=index['average_lengths'][field]
                ratio=index['lengths'][field][i]/avg if avg>0 else 1.
                norm=1-config['b']+config['b']*ratio
                terms.append((config['weight'] if weighted else 1.)*tf/max(norm,1e-12))
            tf=math.fsum(terms)
            if tf>0:scores[i]+=idf*tf*2.2/(1.2+tf)
    return scores

class Index:
    def __init__(self,metadata,fields,matrix):
        self.metadata=metadata;self.fields=fields;self.matrix=matrix;self.calls=[]
        require(len(metadata)==fields['n']>0,'empty or mismatched RID pool')
        require(matrix.shape==(len(metadata),768),'vector dimensions or coverage changed')
        require(len({d['id'] for d in metadata})==len(metadata),'duplicate RID identity')
        require(all(d['id']==d['cid']+'|'+d['rid'] for d in metadata),'crossed CID/RID identity')
        self.norms=np.linalg.norm(matrix,axis=1)
        require(np.isfinite(matrix).all() and (self.norms>0).all(),'invalid document vectors')
    def search(self,text,row,binding,*,chunk_size=1024):
        require(isinstance(text,str) and bool(text.strip()),'empty H query')
        require(type(chunk_size) is int and chunk_size>0,'positive chunk size required')
        rf.check_embedding(row,binding,text,'query')
        v=np.asarray(row['vector'],dtype=np.float64);norm=np.linalg.norm(v)
        require(norm>0,'zero query vector')
        self.calls.append('BM25F')
        sparse=field_scores(self.fields,text,rf.tokens,True)
        self.calls.append('local_cosine')
        dense=np.empty(len(self.metadata),dtype=np.float64)
        for offset in range(0,len(self.metadata),chunk_size):
            dense[offset:offset+chunk_size]=np.einsum('ij,j->i',self.matrix[offset:offset+chunk_size],v,optimize=False)/(self.norms[offset:offset+chunk_size]*norm)
        order=fuse(self.metadata,sparse,dense,10)
        return {'bm25':sparse,'cosine':dense,'order':order,'lane_calls':{'BM25F':1,'local_cosine':1},
                'considered_RIDs':len(self.metadata),'considered_CIDs':len({d['cid'] for d in self.metadata})}
