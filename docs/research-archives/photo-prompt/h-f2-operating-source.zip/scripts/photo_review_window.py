"""Bounded review-window helpers for common-meaning review."""
import photo_preview_ranking as ranking

def window_order(scores,rrf,lexical,dense,duplicate_keys,*,balanced=False):
    ranked=ranking.ranked(scores,rrf);selected=[];seen=set();trace=[]
    def take(order,n,why):
        if n<=0:return 0
        count=0
        for cid in order:
            if cid in selected or cid not in duplicate_keys or duplicate_keys[cid] in seen:continue
            selected.append(cid);seen.add(duplicate_keys[cid]);trace.append({'candidate_id':cid,'quota':why});count+=1
            if count==n:return count
        return count
    take(ranked,6,'meaning_order')
    take([cid for cid in ranked if not scores[cid].get('meaning_view_sha256')],min(2,8-len(selected)),'unstructured_opportunity')
    if len(selected)<8:take(ranked,8-len(selected),'initial_borrow')
    rescue=[]
    for pos in range(max(map(len,(rrf,lexical,dense)),default=0)):
        for lane in (rrf,lexical,dense):
            for row in lane[pos:pos+1]:rescue.append(row['document_id'])
    if balanced:
        for _ in range(4):
            if len(selected)<16:take(ranked,1,'standby_intent')
            if len(selected)<16:take(rescue,1,'standby_lane_rescue')
        while len(selected)<16:
            before=len(selected)
            take(ranked,1,'standby_borrow_intent')
            if len(selected)<16:take(rescue,1,'standby_borrow_lane')
            if len(selected)==before:break
    elif len(selected)<16:take(rescue,16-len(selected),'standby_lane_rescue')
    return selected,trace
def active_rows(rows,states,cap,fit_states,*,duplicate_groups=None):
    size=min(8,len(rows));rounds=[size] if size else []
    while size<len(rows) and size<16:
        fits=[r for r in rows[:size] if states.get((r['candidate_id'],r['realization_id'])) in fit_states]
        count=(len({duplicate_groups[r['candidate_id']] for r in fits}) if duplicate_groups is not None else len(fits))
        if count>=cap:break
        size=min(size+4,len(rows),16);rounds.append(size)
    return rows[:size],rounds
def display_rows(rows,states,fit_states):
    fits=[r for r in rows if states.get((r['candidate_id'],r['realization_id'])) in fit_states]
    pending=[r for r in rows if states.get((r['candidate_id'],r['realization_id'])) in {None,'uncertain'}]
    return (fits+pending)[:8]
