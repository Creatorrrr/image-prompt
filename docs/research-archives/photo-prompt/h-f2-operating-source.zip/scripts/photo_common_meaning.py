"""Source-grounded shared meaning grammar; discovery evidence, never authority.

Unary facts and directed relations share explicit entities. All original
positive units remain binding, even when only part has been structured.
"""
from __future__ import annotations
import copy,re
import photo_candidate_corpus as c
import photo_canonical_source as canonical
import photo_candidate_realizations as realizations

SOURCE_SCHEMA='photo-common-source-meaning/v2'
INTENT_SCHEMA='photo-common-intent-meaning/v1'
TYPES=frozenset({'person','body_part','object','material','place','light','image','property','action','scene','feature'})
UNARY=frozenset({'is_a','has_property'})
BINARY=frozenset({'part_of','owned_by','contacts','grips','below','above','spans','located_in','supports',
    'frame_contains','connects_to','relative_to','acts_on','coats','ends_above','beside','descends_toward','illuminates','looks_at','has_material'})
PREDICATES=UNARY|BINARY
SCOPES=frozenset({'source_assertion','scene_fact','authorial_open','requester_constraint','unknown'})
QUALIFIERS=frozenset({'direction','manner','state','position','view','visibility','co_visibility','extent'})
ENTITY_FIELDS=frozenset({'id','type','concept','label','count','evidence'})
FACT_FIELDS=frozenset({'id','subject','predicate','object','value','qualifiers','scope','evidence'})
KEY=re.compile(r'[a-z][a-z0-9_]{0,95}\Z')

def seal(value):
    out=copy.deepcopy(value);out['canonical_sha256']=c.digest({k:v for k,v in out.items() if k!='canonical_sha256'});return out
def check(value,schema,fields):
    if (not isinstance(value,dict) or set(value)!=set(fields)|{'canonical_sha256'} or value.get('schema')!=schema
        or value.get('canonical_sha256')!=c.digest({k:v for k,v in value.items() if k!='canonical_sha256'})
        or len(c.canonical_bytes(value))>196608):raise ValueError('invalid bounded common meaning contract')
def _name(text):
    if not isinstance(text,str) or not KEY.fullmatch(text):raise ValueError('canonical meaning identifier required')
def _refs(refs,units):
    if not isinstance(refs,list) or not 1<=len(refs)<=12:raise ValueError('explicit meaning evidence required')
    for ref in refs:
        if (not isinstance(ref,dict) or set(ref)!={'pointer','quote'} or ref['pointer'] not in units
            or not isinstance(ref['quote'],str) or not ref['quote'].strip() or ref['quote'] not in units[ref['pointer']]):
            raise ValueError('common meaning quote differs from its actual source')
def graph(value,units,*,source):
    if not isinstance(value,dict) or set(value)!={'entities','facts','requirements'}:raise ValueError('explicit shared meaning graph required')
    if not isinstance(value['entities'],list) or not 1<=len(value['entities'])<=48 or len(value['facts'])>96:raise ValueError('bounded common graph required')
    entities=set();facts=set()
    for row in value['entities']:
        if (set(row)!=ENTITY_FIELDS or row['type'] not in TYPES or row['id'] in entities
            or not isinstance(row['label'],str) or not row['label'].strip()
            or (row['count'] is not None and (type(row['count']) is not int or not 1<=row['count']<=32))):raise ValueError('invalid shared meaning entity')
        _name(row['id']);_name(row['concept']);entities.add(row['id']);_refs(row['evidence'],units)
    for row in value['facts']:
        if (set(row)!=FACT_FIELDS or row['id'] in facts or row['subject'] not in entities
            or row['predicate'] not in PREDICATES or row['scope'] not in SCOPES
            or not isinstance(row['qualifiers'],dict) or not set(row['qualifiers'])<=QUALIFIERS
            or any(not isinstance(v,str) or not v.strip() for v in row['qualifiers'].values())):raise ValueError('invalid common meaning fact')
        _name(row['id']);facts.add(row['id'])
        if row['predicate'] in UNARY:
            if row['object'] is not None:raise ValueError('unary fact cannot invent an object')
            _name(row['value'])
        elif row['object'] not in entities or row['value'] is not None:raise ValueError('binary fact requires an actual directed endpoint')
        if source and row['scope']!='source_assertion':raise ValueError('source fact cannot acquire requester scope')
        if row['scope']=='requester_constraint' and any(not ref['pointer'].startswith(('/core/source_request','/core/request_binding/','/core/intent_lock/','/core/user_definitions/')) for ref in row['evidence']):raise ValueError('baseline grants no requester authority')
        _refs(row['evidence'],units)
    grouped=[]
    for group in value['requirements']:
        if (set(group)!={'mode','fact_ids'} or group['mode'] not in {'all','one_of','optional'} or not group['fact_ids']
            or not set(group['fact_ids'])<=facts or len(group['fact_ids'])!=len(set(group['fact_ids']))):raise ValueError('invalid actual meaning requirements')
        grouped+=group['fact_ids']
    if source and (set(grouped)!=facts or len(grouped)!=len(facts)):raise ValueError('all source facts require explicit grouping')
    return value
def source_units(record,rid):
    return canonical.units(record,rid)
def dependency_binding(data,record):
    reader=data.get('_search_reader');hashes=reader.meta['record_sha256'] if reader else None
    records=data['candidates'];found={};seen={record['id']}
    def visit(value):
        if isinstance(value,dict):
            for item in value.values():visit(item)
        elif isinstance(value,list):
            for item in value:visit(item)
        elif isinstance(value,str):
            for cid in re.findall(r'cand_[0-9a-f]{32}',value):
                if cid in records and cid not in seen:
                    seen.add(cid);dependency=records[cid];found[cid]=hashes[cid] if hashes is not None else c.digest(dependency);visit(dependency)
    visit(record);return found
def build_source(record,rid,meaning,hints,dependencies,reason):
    if hints != []:raise ValueError('canonical search owns discovery cues')
    units=source_units(record,rid)
    return validate_source(seal({'schema':SOURCE_SCHEMA,'binding':{'candidate_id':record['id'],'realization_id':rid,
        'source_record_sha256':c.digest(record),'conditions_sha256':c.digest(record['conditions']),
        'effects_sha256':c.digest(realizations.effects(record,rid)),'dependencies':dependencies},
        'meaning':meaning,'source_units':units,'discovery_hints':[],
        'review':{'author':'Codex','rationale':reason,'source_meaning_changed':False,'native_approval':False,
            'unresolved_units':sorted(units)}}),record,dependencies)
def validate_source(value,record,dependencies):
    check(value,SOURCE_SCHEMA,{'schema','binding','meaning','source_units','discovery_hints','review'})
    binding=value['binding'];rid=binding['realization_id']
    if (rid not in realizations.ids(record) or binding!={'candidate_id':record['id'],'realization_id':rid,
        'source_record_sha256':c.digest(record),'conditions_sha256':c.digest(record['conditions']),
        'effects_sha256':c.digest(realizations.effects(record,rid)),'dependencies':dependencies}):raise ValueError('common source/RID/condition/effect/dependency epoch changed')
    units=source_units(record,rid)
    if value['source_units']!=units:raise ValueError('original positive meaning unit removed or edited')
    graph(value['meaning'],units,source=True)
    if value['discovery_hints'] != []:raise ValueError('canonical search owns discovery cues')
    review=value['review']
    if (set(review)!={'author','rationale','source_meaning_changed','native_approval','unresolved_units'}
        or review['author']!='Codex' or review['source_meaning_changed'] is not False or review['native_approval'] is not False
        or not isinstance(review['rationale'],str) or not review['rationale'].strip() or review['unresolved_units']!=sorted(units)):
        raise ValueError('common graph cannot erase unresolved source meaning or grant authority')
    return value
def lookup(data,cid,rid='base'):
    record=data['candidates'][cid];meaning=canonical.graph(record,rid)
    if meaning is None:return None
    origin=record['meaning']['graph_provenance'][rid]
    value=build_source(record,rid,meaning,[],dependency_binding(data,record),origin['review']['rationale'])
    return value

def intent_units(core,goal):
    result={}
    def walk(value,path):
        if isinstance(value,str) and value.strip():result[path]=value
        elif isinstance(value,dict):
            for key,item in value.items():walk(item,path+'/'+key.replace('~','~0').replace('/','~1'))
        elif isinstance(value,list):
            for n,item in enumerate(value):walk(item,path+'/'+str(n))
    walk(core,'/core');walk(goal,'/goal');return result
def build_intent(core,controls,plan,slot,meaning,focus,reason):
    return validate_intent(seal({'schema':INTENT_SCHEMA,'slot_id':slot,'binding':{
        'core_sha256':c.digest(core),'controls_sha256':c.digest(controls),'goal_sha256':c.digest(plan['slots'][slot])},
        'meaning':meaning,'focus_fact_ids':focus,'review':{'author':'Codex','rationale':reason,'new_requirement':False}}),core,controls,plan,slot)
def validate_intent(value,core,controls,plan,slot):
    check(value,INTENT_SCHEMA,{'schema','slot_id','binding','meaning','focus_fact_ids','review'})
    if (value['slot_id']!=slot or plan['slots'][slot]['status']!='search' or value['binding']!={
        'core_sha256':c.digest(core),'controls_sha256':c.digest(controls),'goal_sha256':c.digest(plan['slots'][slot])}):raise ValueError('common intent epoch changed')
    graph(value['meaning'],intent_units(core,plan['slots'][slot]),source=False)
    facts={r['id']:r for r in value['meaning']['facts']};focus=value['focus_fact_ids']
    if not isinstance(focus,list) or not focus or len(focus)!=len(set(focus)) or not set(focus)<=set(facts):raise ValueError('explicit intent contribution focus required')
    review=value['review']
    if (set(review)!={'author','rationale','new_requirement'} or review['author']!='Codex'
        or review['new_requirement'] is not False or not isinstance(review['rationale'],str) or not review['rationale'].strip()):raise ValueError('intent projection cannot introduce requirements')
    return value
def validate_intent_set(values,core,controls,plan,slots):
    expected={s for s in slots if plan['slots'][s]['status']=='search'}
    if not isinstance(values,dict) or set(values)!=expected:raise ValueError('exact common intent set required')
    for slot,value in values.items():validate_intent(value,core,controls,plan,slot)
    return values
