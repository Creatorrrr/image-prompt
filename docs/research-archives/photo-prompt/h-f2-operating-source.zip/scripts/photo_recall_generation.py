"""Build a closed, isolated D1 generation; no operating pointer writes."""
import gzip
import hashlib
import json
import os
from pathlib import Path
import photo_candidate_corpus as c
import photo_recall_first as rf

SCHEMA = 'photo-recall-first-generation/v1'


def read(path):
    path=Path(path);raw=path.read_bytes()
    return json.loads(gzip.decompress(raw) if path.suffix=='.gz' else raw)


def file_sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()


def write(path, value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    raw=c.canonical_bytes(value)+b'\n'
    if path.suffix=='.gz':raw=gzip.compress(raw,mtime=0)
    temporary=path.with_name(path.name+'.partial')
    with temporary.open('wb') as f:
        f.write(raw);f.flush();os.fsync(f.fileno())
    os.replace(temporary,path)


def build_documents(assets, output, *, body_prefix_length=3):
    output=Path(output).resolve();assets=Path(assets).resolve()
    rf.require(output!=assets and assets not in output.parents, 'isolated output directory required')
    rf.require(not (output/'index-manifest.json').exists(),'indexed generation is immutable; use a fresh output directory')
    rf.require(body_prefix_length in (1,2,3),'unsupported body prefix length')
    source=c.load(assets)
    frozen={cid:c.digest(row) for cid,row in source['candidates'].items()}
    header={k:v for k,v in source.items() if k!='candidates'}
    write(output/'source-header.json.gz',header)
    meta=[];body_locator={};types={};coverage={};all_docs=0
    for shard in '0123456789abcdef':
        body={cid:r for cid,r in source['candidates'].items() if cid[5]==shard}
        groups={}
        for cid,r in body.items():groups.setdefault(cid[5:5+body_prefix_length],{})[cid]=r
        for prefix,group in sorted(groups.items()):write(output/'body'/(prefix+'.json.gz'),group)
        shard_docs=[]
        for cid,r in sorted(body.items()):
            docs=rf.documents(r);all_docs+=len(docs)
            path='body/'+cid[5:5+body_prefix_length]+'.json.gz'
            body_locator[cid]={'path':path,'sha256':frozen[cid]}
            counts=types.setdefault(r['record_kind'],{'CIDs':0,'documents':0,'characters':0,'parts':0})
            counts['CIDs']+=1;counts['documents']+=len(docs)
            for d in docs:
                rf.validate_document(d)
                counts['characters']+=len(d['text']);counts['parts']+=len(d['parts'])
                coverage[d['id']]={'source_sha256':frozen[cid],'text_sha256':d['text_sha256'],
                                   'included_cues':sum(x['status']=='included' for x in d['cue_coverage']),
                                   'other_RID_cues':sum(x['status']=='other_RID_only' for x in d['cue_coverage'])}
                shard_docs.append(d)
        docpath='documents/'+shard+'.json.gz';write(output/docpath,shard_docs)
        meta.extend({k:d[k] for k in ('id','cid','rid','class','source_sha256','text_sha256','document_sha256')}|{'document_path':docpath} for d in shard_docs)
        write(output/'document-checkpoint.json',{'completed_shards':shard,'CIDs':len(body_locator),'documents':len(meta),'source_hashes':frozen})
        print('D1 body/document shard complete',shard,len(body),len(shard_docs),flush=True)
    meta.sort(key=lambda d:d['id'])
    rf.require(len(body_locator)==len(source['candidates']), 'missing body CID')
    rf.require(len({d['id'] for d in meta})==len(meta),'duplicate document RID')
    positive=[d for d in meta if d['class']=='positive']
    rf.require({d['cid'] for d in positive}=={cid for cid,r in source['candidates'].items() if r['meaning']['retrieval_class']=='positive'},'missing positive D1')
    write(output/'document-metadata.json.gz',meta);write(output/'body-locator.json.gz',body_locator)
    write(output/'cue-coverage.json.gz',coverage)
    files={str(p.relative_to(output)):file_sha(p) for p in sorted(output.rglob('*')) if p.is_file() and p.name!='source-manifest.json'}
    result={'schema':SCHEMA,'recipe':rf.RECIPE,'source_sha256':c.digest(source),'candidate_count':len(body_locator),
            'document_count':all_docs,'positive_CIDs':len({d['cid'] for d in positive}),'positive_documents':len(positive),
            'diagnostic_CIDs':len(body_locator)-len({d['cid'] for d in positive}),'types':types,'files':files,
            'bindings':len(source['slot_bindings']),'slots':len(source['slot_catalog']),
            'body_prefix_length':body_prefix_length,'body_shards':len({v['path'] for v in body_locator.values()}),
            'new_semantic_approvals':0,'publication':'isolated shadow; CURRENT untouched'}
    write(output/'source-manifest.json',result)
    # Read every persisted body, document and edge. Memory-only success is insufficient.
    reconstructed={}
    for shard in '0123456789abcdef':
        body={}
        for path in sorted((output/'body').glob(shard+'*.json.gz')):body.update(read(path))
        reconstructed.update(body)
        for d in read(output/'documents'/(shard+'.json.gz')):
            rf.validate_document(d,body[d['cid']])
            rf.require(set(d['member_ids'])<=set(body_locator),'dangling bundle member')
        rf.require(all(c.digest(r)==frozen[cid] for cid,r in body.items()),'body/source mismatch')
    rf.require(c.digest({**read(output/'source-header.json.gz'),'candidates':reconstructed})==result['source_sha256'],'full source closure mismatch')
    return result


class BodyReader:
    """Read only body shards containing the requested top IDs."""
    def __init__(self, generation):
        self.root=Path(generation);self.manifest=read(self.root/'source-manifest.json')
        self.locator=read(self.root/'body-locator.json.gz');self.cache={};self.reads=[]

    def record(self, cid):
        info=self.locator[cid];path=info['path']
        if path not in self.cache:
            rf.require(file_sha(self.root/path)==self.manifest['files'][path],'body shard changed')
            self.cache[path]=read(self.root/path);self.reads.append(path)
        record=self.cache[path][cid]
        rf.require(c.digest(record)==info['sha256'],'body CID/source changed')
        return record


if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--assets',required=True);p.add_argument('--output',required=True)
    args=p.parse_args();result=build_documents(args.assets,args.output)
    print(json.dumps({k:v for k,v in result.items() if k!='files'}),flush=True)
