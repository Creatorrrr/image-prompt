# Eligibility ceiling: DEFER without embeddings

Pinned runtime: `9641e981b7bf7a57ba108a655546098b0b0006cd`. Unchanged approved V2 row SHA-256: `8cce52650b055bbc213c9934292a07a2395901b17e349375abbd7b1f00280231`.

**No fresh compatible case can expose this unchanged proposal as eligible under the current runtime.** Fresh scenes 01 and 02 pass the exact ordinary prerequisite function, but both fail the separate property predicate used later by `build_candidate_pack`. All six tested cores fail that later predicate. An index or embedding cannot change these deterministic scope results. Stop this prototype at **DEFER** with zero paid calls; do not tweak guards, effects, labels, requests or locks.

This is a ceiling for the six frozen cores and this source-reviewed proposal, not a claim that the source meaning is wrong or that no future request could use pottery data.

## Distinct actual runtime stages

1. Loaded the complete unmodified installed runtime and validated its genuine existing indexes. The proposal was passed only as a separate argument to `core_slot_entry_eligible`; it was never inserted into the corpus, index or a pack. No retrieval or index-building function was called.
2. Reconstructed each exact `frozen_core_context` from its normalized genuine before pack and bound control snapshot. For the proposed ordinary **action** row, the real eligibility function removes the current action/event carrier before evaluating `compatible_with_slot_context`. Saved full projections and the remaining token sets show exactly which fields can satisfy prerequisites.
3. Projected the unchanged row with the real `photo_candidate_semantics.semantic_source`, then called the identical `property_effects_allowed` predicate used by the later `build_candidate_pack` property/applicability block. This is a counterfactual applicability ceiling, **not an after-pack or actual proposed-row exposure**. For early-rejected rows the later predicate is evaluated separately, not claimed to have run during their real pack generation.
4. As a check on that correspondence, recomputed the same predicate for seven genuine existing action members across the six packs. All seven match their already-emitted public applicability status. Their outputs remain untouched.

## Six frozen cases

| Case | Ordinary prerequisites | Later property scope | Specific consequence |
|---|---|---|---|
| Fresh 01: open compatible wet forming | Pass | Reject | Human/primary-pottery and wet/clay/wheel prerequisites are present. Its protected `vessel / clay.state` already conflicts with the proposal’s honest wildcard effects, despite an open precise action |
| Fresh 02: required upward wall pull | Pass | Reject | Protected material state and `main_subject / operation.phase` conflict with wildcard effects. Preserving this required stage is legitimate, not a defective test to open up |
| Fresh 03: completed glazed still life | Reject | Reject independently | `explicit_no_people`, no human `for_any` match, and missing clay/wet/wheel. It must not gain a making operation |
| Fresh 04: leather hand-stitching | Reject | Reject independently | No established primary pottery context; clay/wet/wheel are missing. The required leather operation remains protected |
| Earlier wet-wall diagnostic | Reject | Reject independently | The action/event carrier contains the operation, but the remaining ordinary context lacks clay/wet. This is the existing carrier guard limitation, not proof the described scene lacks wet clay |
| Earlier leather-hard trimming diagnostic | Reject | Reject independently | Remaining context lacks clay/wet/wheel; its leather-hard stage and tool/orientation properties also remain protected. It is semantically outside wet-wall pulling |

`eligibility-results.json` records every input hash, core field, context projection, prerequisite result, lock and overlapping effect. Nothing was rewritten to increase token coverage.

## Why the property ceiling is honest

The independently reviewed V2 row retains `action`, `pose`, and `material` effects; only an unnecessary setting effect was removed before this test. Raising a wall deforms the clay, so dropping material effects would misstate the candidate. Its source review found no already-supported narrow non-actor material path that faithfully covers that consequence. The unchanged action and material effects are `target="*", property="*"`; the pose effect is `main_subject / body.support_and_configuration`.

The current property predicate intentionally compares target/property overlaps across carrier dimensions. Either wildcard overlaps every partial property anchor, including the directly relevant wet-clay state, and also more conservative unrelated anchors. The exact overlapping pairs are saved. The conclusion does not depend only on incidental authorial details: both fresh compatible pottery scenes protect requester-specified wet material, and the required-pull case additionally protects its phase.

This does **not** show that the proposed physical refinement would necessarily violate the request. It shows that the honest available declaration cannot be eligible under these frozen scope contracts. Passing prerequisites is not sufficient; source accuracy and usable eligibility are distinct.

## Ordinary selection contract: not covered

The proposal has no genuine public pack membership and cannot be eligible in this cohort. No selected ID, candidate list or pack membership was fabricated to exercise selection. Accordingly there is **no full proposed ordinary-selection/composition audit**, no adoption and no artistic gain result.

The existing auditor source rejects unknown chosen IDs and separately rejects selected candidates whose applicability is not `eligible` (`audit_composed_prompt.py`, the ordinary membership/applicability block). That is supporting code evidence only, not a replacement for a real selection audit. The already-completed four baseline audits belong to the frozen before phase and are not recounted as proposal success.

## Frozen evidence and reproduction

Run `python check_eligibility_ceiling.py` against the pinned source and the supplied immutable artifacts. It performs only the exact runtime predicates and writes this separate eligibility directory. `runtime-functions.snapshot.py.txt` and `actual-build-property-block.snapshot.py.txt` preserve the relevant installed implementations. `summary.json` and `final-integrity.json` separate this helper-level ceiling from public retrieval/adoption claims.

The prior qualification’s 119-file manifest, its V2 freeze, all six input sources and the proposed row remain byte-identical. No corpus/source/request change, index build, embedding query, synthetic vector, provider call or image generation occurred. No real-index after trial is justified for this cohort. Stop rather than modifying its constraints to obtain a positive result.
