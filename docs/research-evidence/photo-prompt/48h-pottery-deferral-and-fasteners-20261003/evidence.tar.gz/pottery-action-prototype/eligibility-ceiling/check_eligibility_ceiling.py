"""Real runtime prerequisite/property predicates, with no proposed pack membership.
No retrieval, index construction, provider/embedding call or input/source mutation.
"""
from pathlib import Path
import copy,hashlib,inspect,json,subprocess,sys
R=Path('/workspace/scratch/ce8f20680f5a/image-prompt');O=Path(__file__).resolve().parent;P=O.parent;Q=P/'qualification';S=R/'skills/photo-prompt-image-generator/scripts'
sys.dont_write_bytecode=True;sys.path.insert(0,str(S));import prompt_generator as g;import photo_candidate_semantics as semantics;import photo_contracts
H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def W(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
row_path=P/'source-draft-v2/proposed_action_row.json';assert H(row_path)=='8cce52650b055bbc213c9934292a07a2395901b17e349375abbd7b1f00280231';row=json.loads(row_path.read_text());original_row=copy.deepcopy(row)
assert H(Q/'frozen-v2-manifest.json')=='22cc750cf97210459f91181b1c63f64ff485fac196e6eaf955846837a6bf6821'
assert H(Q/'before-phase-final-manifest.json')=='b0dfaedbdfa0b931d3c3f5aa380ff47e402f324fb3bd3b8377abd7babceaf204'
frozen_before=json.loads((Q/'before-phase-final-manifest.json').read_text())
for f,v in frozen_before.items():assert H(Q/f)==v['sha256'],f
D=g.load_runtime_data() # reads/validates genuine checked-in indexes; never builds an index
assert g.candidate_pack_slot_entry_by_id(D,'action',row['id']) is None
source=semantics.semantic_source(row,'action',D.get('candidate_semantic_policy'));cases=[]
for c in json.loads((Q/'frozen-v2-manifest.json').read_text())['cases']:
 d=Path(c['input_directory']);cases.append(dict(id=c['id'],cohort='fresh_baseline_repaired_v2',input_directory=d,pack_path=Q/'before'/c['id']/'candidate-pack.json',controls_path=d/'creative-controls.json',core_path=d/'authorial-core.json'))
old=P.parent/'next-scene-target-audit/fresh-inputs'
for rid in ['potter_pulling_wall','potter_trimming_foot']:
 d=old/rid;fm=json.loads((d/'freeze_manifest.json').read_text())
 for f,h in fm['file_sha256'].items():assert H(d/f)==h,(rid,f)
 cases.append(dict(id=rid,cohort='earlier_unchanged_stage_diagnostic',input_directory=d,pack_path=d/'candidate-pack.json',controls_path=d/'creative_controls.json',core_path=d/'authorial_core.json'))
results=[]
def overlap(a,b):return a=='*'or b=='*'or a==b or a.startswith(b+'.')or b.startswith(a+'.')
for case in cases:
 pack=json.loads(case['pack_path'].read_text())[0];core=pack['authorial_core'];controls=json.loads(case['controls_path'].read_text());assert core['creative_controls_sha256']==controls['canonical_sha256'];assert row['id']not in json.dumps(pack)
 contract,picked=g.frozen_core_context(D,core,controls);others={k:copy.deepcopy(v)for k,v in picked.items()if k!='action'}
 primary=g.picked_core_context_tokens(others)
 if others.get('action'):primary|=g.entry_context_tokens(others['action'])
 context=g.picked_context_tokens(others);subject_tokens=g.entry_tags(picked['subject'])|g.entry_kinds(picked['subject'])
 slot_reason=g.slot_block_reason(D,'action',contract);entry_reason=g.entry_block_reason(row,'action',contract)
 domain_tags={domain for tag,domain in g.INTENT_SCOPED_ENTRY_DOMAIN_TAGS.items()if tag in(g.entry_tags(row)|g.entry_kinds(row))}
 eligibility=g.core_slot_entry_eligible(D,core,contract,picked,'action',row)
 slot_context=g.compatible_with_slot_context('action',row,others,D);facet=g.compatible_with_facet_guards(row,others)
 blob=g.candidate_pack_entry_blob(row,extra=[str(row.get('embedding_text')or'')]);exclusions=[e for e in core.get('user_exclusions',[])if g.intent_alias_matches(blob,e)]
 guard=dict(slot_block_reason=slot_reason,entry_block_reason=entry_reason,for_any_matches=sorted(set(row.get('for_any',[]))&subject_tokens),for_any_required=row.get('for_any',[]),exclude_for_any_matches=sorted(set(row.get('exclude_for_any',[]))&subject_tokens),scoped_entry_domains=sorted(domain_tags),frozen_domains=contract['intent_constraints'].get('domains',[]),facet_guards_pass=facet,requires_primary_matches=sorted(g.values_as_set(row,'requires_primary_any_tags')&primary),requires_primary_required=sorted(g.values_as_set(row,'requires_primary_any_tags')),requires_all_missing=sorted(g.values_as_set(row,'requires_all_tags','requires_all')-context),requires_all_present=sorted(g.values_as_set(row,'requires_all_tags','requires_all')&context),quality_primary_requirements=sorted(g.quality_layer_primary_context_requirements(D,'action',row)),declared_slot_context_violation=g.violates_declared_slot_context_rules('action',row,others,D),hard_slot_conflicts=g.slot_conflict_violations('action',row,others,D,'hard'),requester_exclusion_matches=exclusions,compatible_with_slot_context=slot_context)
 property_ok=g.property_effects_allowed(core['intent_lock'],source['affected_dimensions'],source.get('affected_properties',[]));locks=photo_contracts.intent_property_locks(core['intent_lock']);overlaps=[dict(effect=effect,locked_property=lock,cross_carrier=effect['dimension']!=lock['dimension'])for effect in source['affected_properties']for lock in locks if overlap(effect['target'],lock['target'])and overlap(effect['property'],lock['property'])]
 assert property_ok==(not overlaps),case['id']
 # Verify the identical predicate against real existing members without altering their pack.
 existing_property_checks=[]
 for current in pack['slots'].get('action',{}).get('candidates',[]):
  entry=g.candidate_pack_slot_entry_by_id(D,'action',current['entry_id']);sem=semantics.semantic_source(entry,'action',D.get('candidate_semantic_policy'));ok=g.property_effects_allowed(core['intent_lock'],sem.get('affected_dimensions',[]),sem.get('affected_properties',[]));observed=current['applicability'];expected='eligible'if ok else'ineligible';assert observed['status']==expected,(case['id'],current['id'],observed,ok);existing_property_checks.append(dict(id=current['id'],predicate_allows=ok,observed_public_applicability=observed,predicate_matches_public_status=True))
 reasons=[]
 if slot_reason:reasons.append('slot:'+slot_reason)
 if entry_reason:reasons.append('entry:'+entry_reason)
 if row.get('for_any')and not guard['for_any_matches']:reasons.append('for_any requires an established human subject')
 if not guard['requires_primary_matches']:reasons.append('no established primary pottery context token')
 if guard['requires_all_missing']:reasons.append('ordinary action context excludes the action/event carrier and lacks required tokens: '+', '.join(guard['requires_all_missing']))
 if not property_ok:reasons.append('later public applicability rejects the unchanged action/material wildcard effects against existing protected properties')
 item=dict(id=case['id'],cohort=case['cohort'],source_core_sha256=core['canonical_sha256'],pack_sha256=H(case['pack_path']),controls_sha256=H(case['controls_path']),raw_core_file_sha256=H(case['core_path']),frozen_fields={k:core[k]for k in ['subject','setting','event','source_request']},frozen_context=copy.deepcopy(contract),frozen_picked_projections=picked,ordinary_context_after_action_carrier_removal=others,ordinary_context_tokens=sorted(context),ordinary_primary_context_tokens=sorted(primary),subject_compatibility_tokens=sorted(subject_tokens),exact_ordinary_function='prompt_generator.core_slot_entry_eligible(data, core, contract, picked, "action", row)',ordinary_prerequisite_eligible=eligibility,ordinary_guard_detail=guard,exact_later_predicate='photo_candidate_semantics.semantic_source then prompt_generator.property_effects_allowed, exactly as build_candidate_pack uses',later_property_eligible=property_ok,locked_properties=locks,source_effect_overlaps=overlaps,later_applicability_if_exposed=dict(status='eligible'if property_ok else'ineligible',source='frozen_core_slot_contract'if property_ok else'authored_property_scope',reason=None if property_ok else'effect overlaps a protected requester property'),could_be_eligible_if_ranked=eligibility and property_ok,reasons=reasons,existing_genuine_action_member_predicate_checks=existing_property_checks,proposed_pack_membership=False,retrieval_or_ranking_evaluated=False,ordinary_selection_audit='not covered: proposal is absent from every genuine pack; no membership or selected ID was fabricated')
 item['frozen_context'].pop('_authorial_core',None);results.append(item);print(case['id'],'ordinary',eligibility,'later_property',property_ok,'ceiling',eligibility and property_ok,'missing',guard['requires_all_missing'],'entry',entry_reason,flush=True)
assert row==original_row and H(row_path)=='8cce52650b055bbc213c9934292a07a2395901b17e349375abbd7b1f00280231'
for f,v in frozen_before.items():assert H(Q/f)==v['sha256'],f
W(O/'eligibility-results.json',results)
functions=[g.frozen_core_context,g.core_slot_entry_eligible,g.compatible_with_slot_context,g.entry_context_tokens,g.picked_context_tokens,g.picked_core_context_tokens,semantics.semantic_source,g.property_effects_allowed]
(O/'runtime-functions.snapshot.py.txt').write_text('\n\n'.join(inspect.getsource(f)for f in functions))
build=inspect.getsource(g.build_candidate_pack);a=build.index('    for slot, payload in (pack.get("slots") or {}).items():');z=build.index('    pack["candidate_bundles"]',a);(O/'actual-build-property-block.snapshot.py.txt').write_text(build[a:z])
W(O/'summary.json',dict(decision='DEFER',source_row_sha256=H(row_path),case_count=len(results),fresh_case_count=4,ordinary_prerequisite_pass=sum(x['ordinary_prerequisite_eligible']for x in results),later_property_pass=sum(x['later_property_eligible']for x in results),eligible_ceiling_pass=sum(x['could_be_eligible_if_ranked']for x in results),fresh_compatible_eligible_cases=[],after_index_trial_justified=False,ordinary_selection_contract_checked=False,provider_calls=0,index_builds=0,query_embeddings=0,synthetic_vectors=0,source_or_request_changes=0,claim='The unchanged proposal cannot be eligible in any of these six frozen cores under the current actual runtime predicates. No retrieval, adoption, or image-quality claim.'))
print('DEFER: zero eligible ceilings; no after-index/provider work justified.')
