"""Compose identical V2 baselines and audit them, with zero optional adoption."""
from pathlib import Path
import copy,hashlib,json,os,subprocess,sys,time
R=Path('/workspace/scratch/ce8f20680f5a/image-prompt');Q=Path(__file__).resolve().parent;S=R/'skills/photo-prompt-image-generator';H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
E={k:v for k,v in os.environ.items()if not any(t in k.upper()for t in ['TOKEN','API_KEY','CREDENTIAL'])};E['PYTHONDONTWRITEBYTECODE']='1'
def W(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
reasons={
'sca_x03':('irrelevant','Covering the eyes would introduce an unrelated eye-covering treatment rather than improve the requested direct clay-forming contact; keep the current watching maker.'),
'pv_w_sit':('irrelevant','A floor-supported W-sit would replace the current wheel-working seating arrangement without a scene-grounded reason. Preserve the baseline posture.'),
'clt_ct139_v1':('uncertain','A kimono and obi could be an independent wardrobe choice, but this work request supplies no reason to adopt that distinctive garment construction. Keep the existing restrained portrayal.'),
'shirt_cuff_adjustment_mid_action':('conflicting','Both hands are required in direct contact with the clay. Fastening a cuff with both hands would replace that requested operation.'),
'pv_wall_arch':('irrelevant','A wall-supported backward extension introduces a different support relation and distracts from the explicitly required upward vessel-wall pull.'),
'ae_smolder_attraction':('uncertain','The adult already attends to a delicate craft action. Preserve the existing absorbed presence instead of inventing a stronger interpersonal expression.'),
'clt_ct111_v1':('irrelevant','A raised-head finger ring would add a separate jewelry focus without improving the visible wall-raising work. Do not add it merely because the hand is visible.'),
'selective_open_back_stable_front_coverage':('irrelevant','Open-back garment construction adds an unrelated clothing decision to a close hand-stitching scene and is not needed for the saved subtle adult appeal.'),
'perched_edge_sit_grounded_support':('uncertain','A perched seated position could be physically compatible with a suitable bench, but the baseline does not establish that seat arrangement. Preserve the current work-focused presentation.'),
'goth_postpunk_self_styling':('irrelevant','The post-punk music context and compound outfit would introduce a separate scene identity not grounded in the leatherworking request.')}
axis_evidence={
'fresh_scene_01':'She leans forward comfortably, watching the contact between both hands and the potter’s own vessel',
'fresh_scene_02':'His forearms remain close to his body as he concentrates',
'fresh_scene_04':'her fingers keep a clear grip on the needles'}
results=[];m=json.loads((Q/'frozen-v2-manifest.json').read_text())
for case in m['cases']:
 rid=case['id'];d=Q/'before'/rid;source=Path(case['input_directory']);p=json.loads((d/'candidate-pack.json').read_text())[0];core=p['authorial_core'];lock=core['intent_lock'];b=core['baseline_prompt_en'];assert b==(source/'baseline-prompt-en.txt').read_text();assert not p.get('visual_obligations',{}).get('obligations',[])
 for f,h in case['files'].items():assert H(source/f)==h
 review=copy.deepcopy(p['embodiment_preflight']['baseline_review']);review['provenance']='agent_postcomposition'
 c=dict(pack_id=p['pack_id'],core_retrieval_sha256=p['core_retrieval']['canonical_sha256'],prompt_en=b,negative_en=p['negative_en'],chosen_candidate_ids=[],chosen_visual_concept_ids=[],composer='agent',candidate_interpretations=[],embodiment_review=dict(source_contract_sha256=p['embodiment_preflight']['canonical_sha256'],review=review),authorial_core_binding=dict(source_authorial_core_sha256=core['canonical_sha256'],source_intent_lock_sha256=lock['canonical_sha256'],preserved_anchor_ids=[x['anchor_id']for x in lock['semantic_anchors']],preserved_evidence=[],authorial_decisions=[]),semantic_clarification_decisions=[dict(clarification_id=x['id'],decision='applied'if x.get('required_in_final_prompt')else'rejected',rationale='Preserve the frozen requester-owned meaning and decline optional reinterpretations of this independently authored scene.',prompt_evidence=lock['semantic_anchors'][0]['prompt_evidence'])for x in p['semantic_clarification']['candidates']],creative_augmentation_brief=dict(decisions=[dict(candidate_id=x['id'],decision='rejected',rationale='Retain the complete frozen baseline and do not add optional scene changes for this before-arm integrity check.')for x in p['creative_augmentation']['candidates']]))
 contract=p.get('semantic_assertion_obligations')
 if contract:c['semantic_assertion_evidence']=dict(source_contract_sha256=contract['canonical_sha256'],evidence={x['assertion_id']:x['frozen_evidence']for x in contract['obligations']})
 adult=p.get('adult_appeal',{})
 if adult.get('enabled'):
  records=[]
  for cid in adult['contextual_retrieval']['review_candidate_ids']:
   reading,reason=reasons[cid.rsplit(':',1)[-1]];records.append(dict(candidate_id=cid,reading=reading,reason=reason))
  evidence=axis_evidence[rid];assert evidence in b
  c['adult_appeal_brief']=dict(adult_subject_phrase='an adult person'if rid=='fresh_scene_01'else'An adult person'if rid=='fresh_scene_02'else'an adult leatherworker',agency_phrase=next(x['prompt_evidence']for x in lock['semantic_anchors']if x['anchor_id']=='required_event'),contextual_review=records,contextual_comparison='At the same saved subtle sensual level, retain the adult maker’s absorbed presence and controlled working gesture. The offered wardrobe, expression and pose alternatives provide no necessary improvement to this craft moment; no new treatment is adopted. This is a textual preservation judgment, not measured perceptual intensity.',axes={axis:dict(intensity=a['intensity'],realization='baseline',affected_dimensions=[],affected_properties=[],artistic_interpretation='Retain the adult maker’s controlled gesture and absorbed presence around the specified craft work at the frozen setting.',prompt_evidence=evidence if a['intensity']>0 else '')for axis,a in adult['axes'].items()},blend=dict(emphasis=adult['blend']['emphasis']))
 W(d/'composed-baseline.json',c);cmd=[sys.executable,str(S/'scripts/audit_composed_prompt.py'),'--pack',str(d/'candidate-pack.json'),'--composed',str(d/'composed-baseline.json')];t=time.time();r=subprocess.run(cmd,cwd=R,env=E,text=True,capture_output=True,timeout=300);(d/'audit.stdout.json').write_text(r.stdout);(d/'audit.stderr.txt').write_text(r.stderr)
 results.append(dict(id=rid,returncode=r.returncode,command=cmd,seconds=round(time.time()-t,2),result=json.loads(r.stdout)if r.stdout.startswith('{')else r.stdout,error=r.stderr,baseline_identical=True,chosen_candidate_ids=[],chosen_visual_concept_ids=[],claim='Before-arm V2 scaffold validation only; no DATA gain or candidate adoption'));W(Q/'before-audit-results.json',results);print(rid,r.returncode,r.stderr[:600],flush=True)
