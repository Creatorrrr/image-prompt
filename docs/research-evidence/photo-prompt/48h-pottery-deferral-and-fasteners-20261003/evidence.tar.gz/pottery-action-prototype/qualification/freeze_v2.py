"""Freeze all admitted schema-adapted V2 inputs before any proposed-DATA comparison."""
from pathlib import Path
import hashlib,json,subprocess
Q=Path(__file__).resolve().parent;R=Path('/workspace/scratch/ce8f20680f5a/image-prompt');S=R/'skills/photo-prompt-image-generator'
H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert not(Q/'frozen-v2-manifest.json').exists(),'V2 can be frozen only once; any new input requires a new explicitly reviewed version.'
res=json.loads((Q/'adaptation-v2-results.json').read_text());assert len(res)==4 and all(x['result']['status']=='pass'for x in res)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();status=subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True).strip();assert head=='9641e981b7bf7a57ba108a655546098b0b0006cd'and not status
cases=[]
for d in sorted((Q/'inputs-v2').iterdir()):
 files={p.name:H(p)for p in sorted(d.iterdir())if p.is_file()};prov=json.loads((d/'adaptation-provenance.json').read_text());assert prov['baseline_kind']=='baseline_repaired'
 cases.append(dict(id=d.name,input_directory=str(d),files=files,baseline_sha256=prov['adapted_baseline_sha256'],raw_baseline_sha256=prov['original_baseline_sha256'],source_request_sha256=H(d/'source-request.txt'),normalization=next(x['result']for x in res if x['id']==d.name)))
old=Q.parent.parent/'next-scene-target-audit/fresh-inputs';old_checks={}
for d in sorted(old.iterdir()):
 if not d.is_dir():continue
 manifest=json.loads((d/'freeze_manifest.json').read_text());mismatches=[f for f,h in manifest['file_sha256'].items()if H(d/f)!=h];assert not mismatches;old_checks[d.name]=dict(freeze_manifest_sha256=H(d/'freeze_manifest.json'),all_original_input_hashes_match=True)
m=dict(source_head=head,source_worktree_status=status,seed=1003,cohort='Four baseline-repaired schema-adapted V2 controls; not unchanged first-pass admission',raw_author='Source-unexposed author',adapter='Previously source-exposed audit worker; proposed DATA source-draft not inspected',original_requests_sha256=H(Q.parent/'fresh-controls/requests.json'),cases=cases,earlier_two_cores=old_checks,source_hashes={str(p.relative_to(R)):H(p)for p in [S/'assets/photo_prompt_tags.json',S/'assets/photo_prompt_semantic_index.json',S/'assets/photo_prompt_visual_obligations.json',S/'assets/photo_prompt_visual_profile_index.json',S/'scripts/prompt_generator.py',S/'scripts/audit_composed_prompt.py']},claim='Freeze only; no optional-adoption or improvement result')
(Q/'frozen-v2-manifest.json').write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n');print('Frozen',len(cases),'V2 controls',H(Q/'frozen-v2-manifest.json'))
