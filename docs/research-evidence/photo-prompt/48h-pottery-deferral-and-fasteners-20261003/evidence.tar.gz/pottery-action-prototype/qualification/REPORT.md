# Frozen before-arm controls

Source pin: `9641e981b7bf7a57ba108a655546098b0b0006cd`. This phase adapts and validates source-unexposed raw controls against the unchanged installed runtime. The adapter previously saw the bounded ceramic-source audit, but **did not inspect `source-draft`, proposed candidate wording, or proposed DATA**. No corpus/index edits, provider calls, query embeddings, images, forced candidate IDs or visual opt-ins were used.

## Cohort and ownership

The original four requests and baselines have SHA-256 `349444903f86c28b0a871733fe098dfffd79c119ce26c551826ff38103351774` as one source file. Every raw request remains byte-identical. Every default-control snapshot remains byte-identical between V1 and V2. All four V2 controls are **baseline-repaired**, with source-exposed schema adaptation; none is called unchanged first-pass admission.

- Scene 01 retains the requested unfinished wet-clay family, own workpiece and direct contact by both bare hands. The particular compatible forming operation remains open. It is not permission to switch to later dry finishing or an unrelated task
- Scene 02 retains the required upward wall pull and cylindrical wet vessel. Its `action / main_subject / operation.phase` property remains locked; only compatible technique details stay open
- Scene 03 retains all three completed glazed objects and the exact no-people/no-hands/no-making-tool/no-making-process exclusions. `no_people=true`, requester exclusions and explicit excluded assertions remain. The positive sentence grants no new permission
- Scene 04 retains active hand-stitching, own bench, unfinished wallet and the visibility of hands/needle/thread. Brown color, two-needle method, wax, clamp and gender are not made requester-owned

Original human count/adulthood and object counts are declared in the generic required subject assertions. Existing narrowly selectable literal evidence avoids binding incidental tall-vase shape or wallet color. The original declared hard constraints and open dimensions are copied alongside each adaptation. Earlier two stage-specific pottery input manifests still match exactly and remain separate diagnostics.

## Preserved failures and exact approved repairs

V1 scenes 01/02 rejected an `adult` evidence anchor because it contains fewer than two content words; substituting gender-specific evidence would have narrowed an explicitly open choice. Scene 03 rejected its instruction-shaped negative sentence. Scene 04 initially hit an adapter style-shape error: two literal style evidence phrases are required, but the first attempt supplied one. All failed core files and errors remain in `inputs/` and `adaptation-results.json`.

Parent-approved V2 prose changes, with all other baseline bytes retained:

1. Scene 01: `an adult woman` → `an adult person`; `the contact between her hands and her own vessel` → `the contact between both hands and the potter’s own vessel`
2. Scene 02: `An adult man` → `An adult person`
3. Scene 03: replace only the final `No people, hands, tools, raw clay, or signs of an ongoing making process appear.` sentence with `All visible elements belong to the finished-object display and its supporting furnishings.`
4. Scene 04: append `Both hands, a needle, the thread and the unfinished leather wallet are visible together at the adult leatherworker’s own workbench.`

Necessary bookkeeping also adds a second existing literal style evidence phrase, updates review hashes/evidence to the approved prose and uses narrower source-supported anchors. Per-case `adaptation-provenance.json` and `baseline-byte-diff.txt` show exact deltas. An initial adapter syntax error occurred before materialization and is preserved separately; it is not a source or product failure.

## Frozen normal-path evidence

`frozen-v2-manifest.json` was written once before public generation; SHA-256 `22cc750cf97210459f91181b1c63f64ff485fac196e6eaf955846837a6bf6821`. All four cores normalized before the freeze. The normal installed public generation CLI uses seed **1003** and unchanged cached indexes. Exact invocations and all ordinary/optional offers are preserved in `before-results.json` and `before/<id>/candidate-pack.json`. All four public CLI generations exit 0. No hard visual obligations were introduced.

The composed audit keeps each final prompt exactly equal to its V2 baseline, preserves every required anchor/assertion, includes the default-control contextual review and rejects all optional choices. This is **scaffold integrity only**: zero candidate adoption and zero measured DATA gain. All four complete composed audits pass. See `before-audit-results.json` for the actual complete audit outcomes and `final-integrity.json` for the terminal summary.

Existing optional offers remain unfiltered evidence: scene 01 exposes cuff adjustment as eligible despite its incompatibility with the requested two-hand clay contact; scene 03 exposes leather-stitching and a fantastical threshold action as eligible under their existing generic metadata. They are unselected, and eligibility is not scene compatibility or permission. Scene 02’s unrelated bus-stop action and scene 04’s leather-stitching action are marked property-ineligible. These baseline observations are preserved, not repaired or counted as proposed DATA findings.

## Reproduction and phase boundary

`adapt_frozen_controls.py` reproduces preserved V1 materialization failures; `prepare_v2.py` applies only the recorded approvals. `freeze_v2.py` refuses to overwrite the existing freeze. `run_before.py` runs public generation and refuses to overwrite completed packs. `audit_before.py` performs unchanged-baseline composition/audit. Reproduce in a new output directory when retaining these frozen artifacts.

This phase ends here. No proposed-row eligibility, ranking or before/after DATA comparison has been attempted. A separately authorized actual-runtime eligibility check can now use the immutable V2 controls and the earlier two unchanged diagnostics.
