"""Apply only parent-approved scope-preserving fixture repairs, never proposed DATA."""
import copy,difflib,hashlib,json,os,subprocess,sys
from pathlib import Path
R=Path('/workspace/scratch/ce8f20680f5a/image-prompt');Q=Path(__file__).resolve().parent;S=R/'skills/photo-prompt-image-generator'
sys.dont_write_bytecode=True;sys.path.insert(0,str(S/'scripts'));import prompt_generator as g
H=lambda b:hashlib.sha256(b).hexdigest()
def W(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
raw=json.loads((Q.parent/'fresh-controls/requests.json').read_text());assert H((Q.parent/'fresh-controls/requests.json').read_bytes())=='349444903f86c28b0a871733fe098dfffd79c119ce26c551826ff38103351774'
# Initial three substitutions approved by parent message received 2026-10-03 22:40 UTC.
repairs={
 'fresh_scene_01':[('an adult woman','an adult person')],
 'fresh_scene_02':[('An adult man','An adult person')],
 'fresh_scene_03':[('No people, hands, tools, raw clay, or signs of an ongoing making process appear.','All visible elements belong to the finished-object display and its supporting furnishings.')],
 'fresh_scene_04':[]}
# Additional contact/visibility repairs remain gated until a recorded parent approval.
assert (Q/'approved-additional-repairs.json').exists(),'Awaiting exact additional-repair approval; do not create or freeze partial V2.'
extra=json.loads((Q/'approved-additional-repairs.json').read_text())
for rid,pairs in extra['replacements'].items():repairs[rid].extend(map(tuple,pairs))
rows=[]
for row in raw:
 rid=row['id'];a=Q/'inputs'/rid;d=Q/'inputs-v2'/rid;d.mkdir(parents=True,exist_ok=True);req=row['user_request'];old=row['baseline_prompt_en'];b=old
 for before,after in repairs[rid]:
  assert b.count(before)==1,(rid,before,b.count(before));b=b.replace(before,after,1)
 core=json.loads((a/'authorial-core.attempt-1.json').read_text());core['baseline_prompt_en']=b;core['variation_key']=rid+'-schema-adapted-v2';lock=core['intent_lock'];anchors={x['anchor_id']:x for x in lock['semantic_anchors']}
 if rid in ['fresh_scene_01','fresh_scene_02']:
  subject='an adult person'if rid=='fresh_scene_01'else'An adult person';anchors['primary_subject']['prompt_evidence']=subject;anchors['adult_age']['prompt_evidence']='adult person';core['semantic_assertions'][0]['evidence']['subject_phrase']=subject
 if rid=='fresh_scene_01':anchors['required_event']['prompt_evidence']='the contact between both hands and the potter’s own vessel'
 if rid=='fresh_scene_02':anchors['property_4']['prompt_evidence']='own wet cylindrical vessel'
 if rid=='fresh_scene_03':
  anchors['primary_subject']['prompt_evidence']='vase and two small teacups'
  anchors['property_1']['prompt_evidence']='three finished glazed ceramic pieces'
  core['semantic_assertions'][0]['evidence']['subject_phrase']='vase and two small teacups'
  core['semantic_assertions'][0]['axes'].update(vase_count='1',teacup_count='2',completion_state='finished')
  # Exact requester exclusions remain unchanged. The positive baseline replacement never opens a making event.
  assert core['user_exclusions']==['사람','손','제작 도구','제작 과정']
  core['semantic_assertions'].extend([dict(assertion_id='excluded_makers_hands_tools',dimension='subject',polarity='excluded',source_span_ids=['topic'],affected_dimensions=['subject'],axes=dict(excluded_scene_elements=['people','hands','making tools']),evidence={}),dict(assertion_id='excluded_making_process',dimension='event',polarity='excluded',source_span_ids=['topic'],affected_dimensions=['event'],axes=dict(excluded_activity='making or manufacturing the displayed ceramic objects'),evidence={})])
  lock['semantic_anchors'].append(dict(anchor_id='display_only_boundary',source_text='사람이나 손, 제작 도구, 제작 과정은 보이지 않았으면',dimension='event',prompt_evidence='finished-object display and its supporting furnishings'))
 if rid=='fresh_scene_04':
  anchors['required_event']['prompt_evidence']='hand-stitching the edge of an unfinished';anchors['property_2']['prompt_evidence']='own workbench';anchors['property_4']['prompt_evidence']='Both hands, a needle, the thread and the unfinished leather wallet are visible together'
 if rid!='fresh_scene_03':
  core['semantic_assertions'][0]['axes'].update(subject_count='1',age_category='adult')
 core['style']['evidence']=[anchors['scene_concept']['prompt_evidence'],anchors['required_event']['prompt_evidence']]
 review=json.loads((a/'embodiment-review.json').read_text());review['prompt_sha256']=H(b.encode())
 # Review evidence must follow the approved literal contact substitution without changing physical assertions.
 for check in review.get('checks',{}).values():
  for before,after in repairs[rid]:check['prompt_evidence']=[x.replace(before,after)for x in check['prompt_evidence']]
 for f in ['request-envelope.json','creative-context.json','creative-controls.json']:(d/f).write_bytes((a/f).read_bytes())
 assert json.loads((d/'request-envelope.json').read_text())['request_text']==req
 (d/'source-request.txt').write_text(req);(d/'baseline-prompt-en.txt').write_text(b);W(d/'authorial-core.attempt-2.json',core);W(d/'embodiment-review.json',review)
 assert set(lock['open_dimensions'])==set(json.loads((a/'authorial-core.attempt-1.json').read_text())['intent_lock']['open_dimensions'])
 provenance=dict(synthetic_maintenance=True,raw_author='Source-unexposed source of frozen requests.json',schema_adapter='Source-exposed through earlier pottery audit; proposed DATA source-draft and candidate wording not accessed',request_bytes_unchanged=True,default_control_bytes_unchanged=True,original_baseline_sha256=H(old.encode()),adapted_baseline_sha256=H(b.encode()),baseline_replacements=[dict(before=x,after=y)for x,y in repairs[rid]],baseline_kind='baseline_repaired'if repairs[rid]else'bookkeeping_repaired',bookkeeping_changes=['Add the second existing literal style evidence phrase without adding requested meaning','Preserve original requester constraints and original open dimensions','Use narrow non-gender evidence for adulthood and remove incidental color/technique bindings where applicable'],hard_requester_constraints=row['hard_requester_constraints'],open_creative_dimensions=row['open_creative_dimensions'],prior_failure=json.loads((Q/'adaptation-results.json').read_text())[int(rid[-2:])-1]['result'],stage_scope='The broad family remains fixed; only explicitly open details are writable. The specified wall-pull control keeps its action operation.phase property. No new candidate ID or opt-in occurs in these inputs.')
 W(d/'adaptation-provenance.json',provenance);(d/'baseline-byte-diff.txt').write_text(''.join(difflib.unified_diff(old.splitlines(keepends=True),b.splitlines(keepends=True),fromfile='raw-frozen-baseline',tofile='schema-adapted-v2'))+'\n')
 ctl=json.loads((d/'creative-controls.json').read_text())
 try:
  e=g.load_request_envelope_arg(str(d/'request-envelope.json'));n=g.load_authorial_core_arg(str(d/'authorial-core.attempt-2.json'),request_envelope=e,creative_control_snapshot=ctl);g.photo_embodiment.build_policy(n,review);res=dict(status='pass',canonical_core_sha256=n['canonical_sha256']);W(d/'authorial-core.json',core)
 except Exception as exc:res=dict(status='fail',exception=type(exc).__name__,error=str(exc))
 rows.append(dict(id=rid,attempt=2,request_sha256=H(req.encode()),baseline_sha256=H(b.encode()),result=res));W(Q/'adaptation-v2-results.json',rows);print(rid,json.dumps(res),flush=True)
