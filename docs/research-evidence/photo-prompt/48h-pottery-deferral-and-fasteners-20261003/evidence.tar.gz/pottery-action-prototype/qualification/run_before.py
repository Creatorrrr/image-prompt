"""Normal installed before-arm public CLI, no provider calls or synthetic index."""
from pathlib import Path
import hashlib,json,os,subprocess,sys,time
R=Path('/workspace/scratch/ce8f20680f5a/image-prompt');Q=Path(__file__).resolve().parent;S=R/'skills/photo-prompt-image-generator';H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
E={k:v for k,v in os.environ.items()if not any(t in k.upper()for t in ['TOKEN','API_KEY','CREDENTIAL'])};E['PYTHONDONTWRITEBYTECODE']='1'
m=json.loads((Q/'frozen-v2-manifest.json').read_text());results=[]
for path,h in m['source_hashes'].items():assert H(R/path)==h,path
for case in m['cases']:
 d=Path(case['input_directory']);out=Q/'before'/case['id'];out.mkdir(parents=True,exist_ok=True)
 for name,h in case['files'].items():assert H(d/name)==h,(case['id'],name)
 cmd=[sys.executable,str(S/'scripts/generate_photo_prompt.py'),'--request-envelope-json',str(d/'request-envelope.json'),'--authorial-core-json',str(d/'authorial-core.json'),'--creative-controls-json',str(d/'creative-controls.json'),'--embodiment-review-json',str(d/'embodiment-review.json'),'--seed',str(m['seed']),'--output-file',str(out/'candidate-pack.json')]
 assert not(out/'candidate-pack.json').exists(),'Preserve completed before output; do not silently rerun.'
 t=time.time();r=subprocess.run(cmd,cwd=R,env=E,text=True,capture_output=True,timeout=300);(out/'generation.stdout.txt').write_text(r.stdout);(out/'generation.stderr.txt').write_text(r.stderr)
 result=dict(id=case['id'],command=cmd,returncode=r.returncode,seconds=round(time.time()-t,2),frozen_manifest_sha256=H(Q/'frozen-v2-manifest.json'),error=r.stderr)
 if r.returncode==0:
  pack=json.loads((out/'candidate-pack.json').read_text())[0];result.update(pack_id=pack['pack_id'],pack_sha256=H(out/'candidate-pack.json'),ordinary_slots={s:[dict(id=c['id'],applicability=c['applicability'])for c in v['candidates']]for s,v in pack['slots'].items()},hard_obligation_ids=[x['id']for x in pack.get('visual_obligations',{}).get('obligations',[])],optional_visual_ids=[x['id']for x in pack.get('visual_concept_candidates',{}).get('candidates',[])],core_retrieval=pack['core_retrieval'])
 results.append(result);(Q/'before-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n');print(case['id'],r.returncode,r.stderr[:1000],flush=True)
