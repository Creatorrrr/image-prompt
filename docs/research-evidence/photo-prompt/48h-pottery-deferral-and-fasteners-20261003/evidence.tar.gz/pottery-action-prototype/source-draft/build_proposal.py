import hashlib, json, sys, subprocess
from pathlib import Path
ROOT=Path('/workspace/scratch/ce8f20680f5a')
REPO=ROOT/'image-prompt'
OUT=ROOT/'data-progress-48h-20261003/pottery-action-prototype/source-draft'
sys.path.insert(0,str(REPO/'skills/photo-prompt-image-generator/scripts'))
import prompt_generator as pg
import photo_candidate_semantics as pcs
import photo_candidate_context as pcc
from photo_contracts import AUTHORIAL_CORE_V3_INTENT_LOCK_DIMENSIONS, property_effects_allowed
from validate_photo_prompt_dictionary import validate_selection_contracts

def write_json(name,data):
 (OUT/name).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()

row={
 'id':'pulling_wet_clay_wall_on_pottery_wheel',
 'ko':'회전하는 도예 물레 위의 젖은 점토 기물에서 한 손으로 기벽 안쪽을 받치고 다른 손으로 바깥쪽을 눌러 기벽을 끌어올리는',
 'en':'pulling a wet clay vessel wall upward on a rotating pottery wheel, with one hand supporting the inside and the other applying pressure outside',
 'weight':0.5,
 'tags':['human','action','craft','ceramic'],
 'for_any':['human'],
 'requires_primary_any_tags':['potter','pottery','ceramic','ceramics','도예가','도예','물레'],
 'requires_all_tags':['wheel','clay','wet'],
 'aliases':['pottery wall pulling','물레 기벽 올리기'],
 'keywords':['clay wall pull','inner hand support','outer hand pressure','기벽 끌어올리기'],
 'embedding_text':'A wet clay wall rises between supporting inner-hand contact and outer-hand pressure while its vessel stays supported on a rotating pottery wheel.',
 'concept_units':[
  'wet clay vessel supported on a rotating pottery wheel',
  'one hand inside and the other outside the same vessel wall',
  'inside support and outside pressure raise the wall'
 ],
 'relations':[
  {'id':'wheel_support','type':'supported_by','subject':'wet clay vessel','object':'rotating pottery wheel'},
  {'id':'paired_contact','type':'same_target','subject':'inside supporting hand and outside pressing hand','object':'the same wet clay vessel wall'},
  {'id':'forming_effect','type':'shapes','subject':'paired hand contact','object':'the rising vessel wall'}
 ],
 'affected_dimensions':['action','pose','material','setting'],
 'affected_properties':[
  {'dimension':'action','target':'*','property':'*'},
  {'dimension':'pose','target':'main_subject','property':'body.support_and_configuration'},
  {'dimension':'material','target':'*','property':'*'},
  {'dimension':'setting','target':'*','property':'*'}
 ],
 'core_assertion_discovery':False
}
write_json('proposed_action_row.json',row)
(OUT/'embedding_text.txt').write_text(row['embedding_text'],encoding='utf-8')
embedding_input=pg.semantic_text_for_entry(row,'action',kind='slot')
(OUT/'embedding_input.txt').write_text(embedding_input,encoding='utf-8')

sources={
 'status':'public_source_grounded_data_proposal_only',
 'accessed_date_utc':'2026-10-03',
 'private_data_transmitted':False,
 'verbatim_quotations':[],
 'sources':[
  {'id':'crucible_wheel_throwing','url':'https://www.thecrucible.org/guides/ceramics/wheel-throwing/','title':'Guide to Ceramic Wheel Throwing','author':'Kristin Arzt','publisher':'The Crucible','directly_read':True,'locator':'What is wheel throwing?; Step 4: Shape your pottery; Step 5: Final touches','supports':'Wet-wall forming, opposed inner support and outer pressure, increasing height; subsequent trimming is a different material stage.','limits':'One described wall-pulling technique, not an exhaustive definition of all throwing. No prescribed side, spin direction, camera, clothing or brand.'},
  {'id':'plant_pot_chuck','url':'https://ceramicartsnetwork.org/ceramics-monthly/ceramics-monthly-article/quick-tip-plant-pot-chuck','title':'Quick Tip: Plant Pot Chuck','author':'Lea Durie','publisher':'Ceramics Monthly / Ceramic Arts Network','publication':'October 2024 issue','directly_read':True,'locator':'Opening paragraphs and process/captions','supports':'Trimming may use an inverted leather-hard vessel with a supporting chuck.','limits':'Contrast evidence only. No chuck, inversion or trimming step enters the positive row.'},
  {'id':'studio_talk_2022','url':'https://ceramicartsnetwork.org/docs/default-source/magazine-archives/studiotalk_2022_online.pdf?sfvrsn=5d624b08_5','title':'studio talk 2022','publisher':'Ceramic Arts Network','locator':'Printed page 30, Lansing Wagner process, caption 3','directly_read':False,'access_note':'Direct PDF open failed, including content-length rejection for the query-free URL. Public search returned the original publisher PDF page-30 text and caption. No full-PDF or pixel inspection claimed.','supports':'Caption describes loop-tool removal around the foot and outer wall.','limits':'Corroborates the trimming contrast only; not needed to authorize the wall-pull wording.'}
 ],
 'translation_note':'Korean wording is an authored faithful translation of the English process meaning; it is not a quotation from a Korean source. 기벽 identifies the vessel wall. Synonyms are limited to this wall-pulling sub-action.',
 'separation':'Source URLs, author names, page locators, negative examples and this provenance remain outside candidate search text.'
}
write_json('source_provenance.json',sources)

base=json.loads((REPO/'skills/photo-prompt-image-generator/assets/photo_prompt_tags.json').read_text())
pose=json.loads((REPO/'skills/photo-prompt-image-generator/assets/photo_prompt_pose_vocabulary_extension.json').read_text())
selected=[]
for source,ids in [(base,{'kneading_dough','prepping_workshop_materials','milling_metal_part','weaving_leather_strips_by_hand','hand_cutting_individual_paper_pattern'}),(pose,{'pv_book_read','pv_throw_release','pv_catch_receive'})]:
 for r in source['slots']['action']:
  if r['id'] in ids: selected.append({'id':r['id'],'fields':sorted(r),'affected_dimensions':r.get('affected_dimensions'), 'affected_properties':r.get('affected_properties'),'prerequisites':{k:r[k] for k in pcc.RAW_FIELDS if k in r}})
review={
 'status':'REVIEW_REQUIRED_UNINSTALLED',
 'named_ordinary_action_schema_sample':selected,
 'additional_scope_reference':'photo_prompt_editing_effects_extension.json / quality:pe_gradient_banding confirms existing wildcard target/property syntax; property_effects_allowed implements it. No new path is invented.',
 'existing_companion_ids':['subject:ceramic_potter','subject:ceramic_artist','location:ceramics_studio','action:prepping_workshop_materials'],
 'why_one_new_row':'Preparing materials is a different action, so attaching wall-pulling synonyms to it would change meaning. The existing action slot suffices; no new slot or domain bundle is proposed.',
 'field_choices':{
  'for_any':'Existing human subject category constraint. It does not create an actor or establish usable hands.',
  'requires_primary_any_tags':'Coarse primary pottery context only. A role or studio is not sufficient action evidence.',
  'requires_all_tags':'Honest minimal English tool/material token conjunction retained as a provisional guard, not claimed to bind those tokens to one object or support multilingual paraphrases.',
  'concept_units_and_relations':'Carries the complete source-supported relation for optional interpretation; not a physical prerequisite solver.',
  'core_assertion_discovery':'False. No assertion-driven priority is added for this untested prototype.'
 },
 'genuine_prerequisites':[
  {'kind':'actor','required':'An already established human maker with both hands available for this particular paired-contact action.','schema_coverage':'for_any handles human category only; hand availability and ownership require semantic review.'},
  {'kind':'tool_support','required':'An existing pottery wheel and a supported clay workpiece; the wheel may rotate for the proposed action without contradicting the frozen scene. A bat is permitted but not required.','schema_coverage':'wheel token plus the support relation are coarse declarations; neither proves tool identity, rotation, or support.'},
  {'kind':'material','required':'An existing opened wet, workable clay vessel wall accessible from inside and outside.','schema_coverage':'wet and clay tokens do not bind state to the same vessel; openness and workability lack typed ordinary-action prerequisites.'},
  {'kind':'contact_feasibility','required':'The established maker can reach both wall faces with available hands; no retained action, pose, vessel geometry or support constraint prevents the refinement. The exact inside/outside contact need not already exist.','schema_coverage':'Tag guards cannot establish hand availability, access or same-owner physical compatibility; these need ordinary semantic/embodiment review.'}
 ],
 'candidate_added_duties':['The same maker establishes inside support and outside pressure on the same vessel wall.','The supported wheel operates in rotation and the wet wall rises under the paired contact.','These final visible relations are the candidate refinement, not preconditions that must already appear in the frozen event.'],
 'effect_rationale':[
  {'dimension':'action','scope':'* / *','reason':'Covers the maker operation, wall movement and rotating tool state together. Actor-only body.action_configuration would underdeclare non-actor action effects.'},
  {'dimension':'pose','scope':'main_subject / body.support_and_configuration','reason':'Existing ordinary pose-vocabulary path covers the selected hand/support configuration; it does not alter anatomy or identity.'},
  {'dimension':'material','scope':'* / *','reason':'Conservatively accounts for specified wet workable clay and deformation of its wall. No invented vessel-specific material path is used.'},
  {'dimension':'setting','scope':'* / *','reason':'Conservatively reserves apparatus/support arrangement embodied by the complete proposition. This is not permission to fabricate a wheel when the prerequisites are absent.'}
 ],
 'effect_limits':'No camera, lighting, clothing, handedness, spin direction, brand, identity, age, expression, new person, social relationship, narrative timing or multi-step procedure is added. The row remains inapplicable if obtaining its prerequisites would require changing a requester lock.',
 'schema_gaps':[
  {'id':'event_carrier_removed','evidence':'prompt_generator.py: frozen_core_context places core.event in picked.action; core_slot_entry_eligible removes the current slot before compatible_with_slot_context. For an action row, action-only context is therefore absent from its prerequisite check.','consequence':'Source-truthful event-only wheel/clay/wet evidence may be rejected. Do not delete prerequisites, rewrite frozen cores, or inflate subject/location text to rescue retrieval.'},
  {'id':'unbound_token_conjunction','evidence':'compatible_with_slot_context checks sets of tokens, with no entity binding or per-role relation requirement.','consequence':'Separate objects can supply wet, clay and wheel tokens while failing the actual physical premise. Do not claim the token gate solves contact plausibility.'},
  {'id':'multilingual_conjunction','evidence':'requires_all_tags is one flat conjunction, requires_any_tags is one flat disjunction, and no per-prerequisite multilingual alternatives are authored here.','consequence':'The honest Korean label is not a guarantee that Korean-only prerequisite prose is eligible. Requiring all translations or replacing AND with broad OR would be incorrect.'},
  {'id':'conservative_property_scope','evidence':'property_effects_allowed compares target/property overlaps across dimensions to stop carrier evasion. A wildcard target and property overlap every partial property lock.','consequence':'The prototype rejects all partially property-locked scenes, including unrelated partial locks. This is deliberately conservative, not a claim of precise compatibility. Do not invent narrow paths to gain passage.'}
 ],
 'decision':'Freeze one viable optional language proposal for independent review, with conservative scope. A compatible existing maker, wheel and opened workable clay can receive the contact/wall-pull refinement when all declared effects are open and no incompatible retained state exists. Deterministic tags alone are insufficient evidence of that compatibility. Defer installation and promotion pending the separate reviewer; no runtime/schema change is proposed or presumed necessary. Event-carrier and multilingual false negatives may limit usefulness. A failure cannot be fixed by removing truthful premises or effects.'
}
write_json('schema_review.json',review)

bounds={
 'status':'source_proposal_frozen_before_any_candidate_retrieval_or_test_query_access',
 'decision':'REVIEW_REQUIRED_UNINSTALLED',
 'immutable_proposal':{'slot':'action','id':row['id'],'row_file':'proposed_action_row.json','row_sha256':sha(OUT/'proposed_action_row.json'),'embedding_text_file':'embedding_text.txt','embedding_text_sha256':sha(OUT/'embedding_text.txt'),'provider_input_file':'embedding_input.txt','provider_input_sha256':sha(OUT/'embedding_input.txt'),'recipe':pg.SEMANTIC_TEXT_RECIPE_VERSION},
 'positive_meaning':'A single source-described wet-wall pulling action with one supported vessel, the paired contact relation, and rising wall effect.',
 'required_acceptance':[
  'Exactly one ordinary optional action row; no profile, bundled scenes, procedure slot or runtime change.',
  'Actor, wheel, opened workable clay and contact feasibility are genuinely established; candidate tags cannot establish their own prerequisites. The exact paired same-wall contact is an added visible duty, not an initial-event prerequisite.',
  'Every actual semantic effect fits declared open dimensions and property locks, including apparatus/material consequences.',
  'Honest English and Korean equivalents retain the same narrow sub-action without treating all wheel throwing as wall pulling.',
  'The frozen independent evaluation distinguishes visibility, eligibility, optional adoption and image quality; a lexical or schema pass alone proves none of the others.',
  'No holdout edits, leaked query aliases, missing-effects fix, invented property path, relaxed negative, or added hard gate after observing a failure.'
 ],
 'negative_boundaries':[
  'Leather-hard trimming or foot cutting, whether supported directly or by a chuck',
  'Centering, wedging, opening, rib finishing, glazing or clay preparation without this wall-pull relation',
  'A potter or ceramics studio mentioned without the actual making action',
  'A finished fired vessel, a dry clay object, an unrelated wheel, or disconnected wet/clay/wheel tokens',
  'At adoption: final contact remains outside-only, floating or split across different vessels; or a retained action occupies a required hand. An initially outside-only hand is not automatically excluded if pose/contact is open to the proposed refinement.',
  'A scene or property lock incompatible with the full action or its material and support prerequisites'
 ],
 'not_universal_requirements':['particular body posture','left/right hand assignment','wheel rotation direction','wheel brand','apron or clothing','camera distance or angle','lighting','bat','sponge','rib','trimming tool','finished vessel shape or exact wall height'],
 'stopping_condition':'Complete the immutable source draft and schema limitation evidence, then stop. No installation, index build, provider embedding request, image generation, Git publication or external-agent call is authorized by this deliverable.'
}
write_json('acceptance_boundaries.json',bounds)

pcs.validate_candidate_entries({'slots':{'action':[row]}},AUTHORIAL_CORE_V3_INTENT_LOCK_DIMENSIONS)
errors=[]; validate_selection_contracts({'slots':{'action':[row]}},errors)
assert not errors,errors
context=pcc.compile_context(row,'slot:action:'+row['id'])
write_json('compiled_prerequisites.json',context)
# Micro-probes use hand-authored tag carriers only, never evaluation prompts/cores.
subject={'en':'synthetic human category carrier','tags':['human','potter'],'kind':['human']}
location={'en':'synthetic neutral carrier','tags':['interior']}
event={'en':'synthetic prerequisite carrier','tags':['wheel','clay','wet']}
with_event={'subject':subject,'location':location,'action':event}
without_event={k:v for k,v in with_event.items() if k!='action'}
with_other_carrier={'subject':subject,'location':{'en':'tokens only, relations unspecified','tags':['wheel','clay','wet']}}
lock={'contract_version':'photo-intent-lock/v2','semantic_anchors':[{'dimension':'camera','target':'image_plane','property':'viewpoint.direction'}]}
probes={
 'scope':'Local structural/helper micro-probes only; not retrieval evaluation and not an image-quality test.',
 'candidate_entries_schema':'pass','selection_contract_shape':'pass',
 'prerequisites_in_action_carrier':pg.compatible_with_slot_context('action',row,with_event),
 'same_prerequisites_after_action_carrier_removed':pg.compatible_with_slot_context('action',row,without_event),
 'disconnected_token_carrier_without_semantic_relation_check':pg.compatible_with_slot_context('action',row,with_other_carrier),
 'wildcard_effects_allowed_under_unrelated_partial_camera_lock':property_effects_allowed(lock,row['affected_dimensions'],row['affected_properties']),
 'expected':{'prerequisites_in_action_carrier':True,'same_prerequisites_after_action_carrier_removed':False,'disconnected_token_carrier_without_semantic_relation_check':True,'wildcard_effects_allowed_under_unrelated_partial_camera_lock':False},
 'not_run':['frozen holdouts','full dictionary validation with row installed','BM25F retrieval experiment','embedding retrieval','provider calls','index builds','images','Git publication']
}
for k,v in probes['expected'].items(): assert probes[k]==v,(k,probes[k],v)
write_json('schema_probe.json',probes)

inputs=[
 'skills/photo-prompt-image-generator/SKILL.md',
 'skills/photo-prompt-image-generator/references/maintenance.md',
 'skills/photo-prompt-image-generator/assets/photo_prompt_tags.json',
 'skills/photo-prompt-image-generator/assets/photo_prompt_pose_vocabulary_extension.json',
 'skills/photo-prompt-image-generator/scripts/photo_candidate_semantics.py',
 'skills/photo-prompt-image-generator/scripts/photo_candidate_context.py',
 'skills/photo-prompt-image-generator/scripts/photo_contracts.py',
 'skills/photo-prompt-image-generator/scripts/prompt_generator.py',
 'skills/photo-prompt-image-generator/scripts/validate_photo_prompt_dictionary.py'
]
write_json('source_binding.json',{'repository_head':subprocess.check_output(['git','-C',str(REPO),'rev-parse','HEAD'],text=True).strip(),'repo_sources_sha256':{p:sha(REPO/p) for p in inputs},'audit_read_whitelist':['next-scene-target-audit/primary-source-evidence.json','next-scene-target-audit/bounded-source-sample.json'],'forbidden_material_read':False,'proposal_inputs':'Only public process sources, repository skill/maintenance rules, ordinary schema examples and generic schema implementation. No frozen requests, cores, outputs, lane traces or report from the restricted audit were inspected.'})
print(json.dumps({'status':'REVIEW_REQUIRED_UNINSTALLED','candidate':row['id'],'row_sha256':sha(OUT/'proposed_action_row.json'),'embedding_input_sha256':sha(OUT/'embedding_input.txt'),'schema_probe':probes},indent=2))
