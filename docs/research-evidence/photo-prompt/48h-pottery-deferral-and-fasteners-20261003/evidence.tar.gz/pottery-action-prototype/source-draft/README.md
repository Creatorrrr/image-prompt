# One source-grounded pottery action, uninstalled

Status: REVIEW_REQUIRED_UNINSTALLED

Exactly one DATA row is proposed: `action:pulling_wet_clay_wall_on_pottery_wheel`. The repository remains unchanged at `9641e981b7bf7a57ba108a655546098b0b0006cd`.

The row describes one ordinary wall-pulling technique. Its primary source is [The Crucible's wheel-throwing guide](https://www.thecrucible.org/guides/ceramics/wheel-throwing/). [Lea Durie's chuck article](https://ceramicartsnetwork.org/ceramics-monthly/ceramics-monthly-article/quick-tip-plant-pot-chuck) and the [studio talk 2022 process caption, printed page 30](https://ceramicartsnetwork.org/docs/default-source/magazine-archives/studiotalk_2022_online.pdf?sfvrsn=5d624b08_5) support the distinction from trimming. The PDF was verified through a publisher-indexed search extract after direct opening failed, not by inspecting PDF pixels.

## Files

- `proposed_action_row.json`: the single proposed row, with English and Korean wording, narrow synonyms, source-complete relations and effects
- `embedding_text.txt`: exact authored `embedding_text` bytes, without a trailing newline
- `embedding_input.txt`: exact current `semantic-text-v5` provider-input bytes generated locally, without a provider call or trailing newline
- `source_provenance.json`: source support, limits and translation provenance, kept outside retrieval text
- `schema_review.json`: eight named ordinary-action schema examples, prerequisite/refinement split, scope rationale and limitations
- `compiled_prerequisites.json`: existing compiler's deterministic projection of the row's provisional guards
- `schema_probe.json`: limited local helper/shape checks, not a retrieval experiment
- `acceptance_boundaries.json`: frozen source-derived acceptance and contrast boundaries
- `source_binding.json`: repository/input hashes and audit-read isolation
- `manifest.json`: final artifact hashes

## Prerequisites versus added meaning

The maker, wheel and opened workable clay must be compatible with the scene. Available hands and access to the wall must permit the proposed operation. The exact paired contact does **not** need to pre-exist: it is the candidate refinement, together with wall raising. A locked conflicting hand action or tool state defeats applicability; open hand placement may be refined.

This distinction was clarified with the coordinator before the final source-draft freeze. No evaluation request, core, output, trace or control was read before or after that clarification. The candidate row bytes did not change during this clarification.

## Conservative compatibility limits

1. Ordinary action eligibility removes the current action carrier before evaluating tag prerequisites. If wheel/clay/wet evidence exists only in the event, it can therefore be missed. A helper probe confirms this, without using an evaluation core.
2. Flat token conjunctions cannot bind the state, support and hands to the same workpiece. Their presence is only coarse eligibility. Ordinary semantic and embodiment review must establish actual compatibility and the completed final relation.
3. The provisional English token conjunction cannot express per-role English-or-Korean alternatives. Honest Korean labels do not establish Korean-only eligibility.
4. Broad action/material/setting wildcard effects avoid inventing precise property paths or hiding apparatus/material implications. Current cross-carrier property protection consequently rejects the row under **any** partial property anchor, even unrelated ones. This is conservative over-rejection. The existing pose path is `main_subject / body.support_and_configuration`.

The proposal may be semantically viable with compatible established entities and wholly open effect dimensions. It is not proved useful or ready to install. Let the independent reviewer adjudicate the existing contract and scope. Do not weaken guards, omit effects, alter frozen requests or fabricate new fine-grained paths to rescue a failed case.

## Verification limits

Candidate semantic shape and selection-contract shape pass. Four synthetic helper probes confirmed their recorded outcomes. These are schema diagnostics only. No frozen holdout, retrieval run, full installed-dictionary check, index build, embedding API request, image generation, Git change/publication or external-agent call was performed. No runtime schema, hard profile, procedure or broad craft bundle is proposed.
