"""Produce the exact independently reviewed two-field DATA revision, offline."""
import copy, hashlib, json, sys, subprocess
from pathlib import Path
ROOT=Path('/workspace/scratch/ce8f20680f5a')
REPO=ROOT/'image-prompt'
BASE=ROOT/'data-progress-48h-20261003/pottery-action-prototype'
V1=BASE/'source-draft'; OUT=BASE/'source-draft-v2'; REVIEW=BASE/'review/REVIEW.md'
sys.path.insert(0,str(REPO/'skills/photo-prompt-image-generator/scripts'))
import prompt_generator as pg
import photo_candidate_semantics as pcs
import photo_candidate_context as pcc
from photo_contracts import AUTHORIAL_CORE_V3_INTENT_LOCK_DIMENSIONS, property_effects_allowed
from validate_photo_prompt_dictionary import validate_selection_contracts

def digest(data): return hashlib.sha256(data).hexdigest()
def sha(path): return digest(path.read_bytes())
def read(name): return json.loads((V1/name).read_text())
def write(name,value): (OUT/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
def repo_status(): return subprocess.check_output(['git','-C',str(REPO),'status','--porcelain=v1'],text=True)

v1_manifest=read('manifest.json')
v1_before={p.name:sha(p) for p in V1.iterdir() if p.is_file()}
assert all(v1_before[name]==value for name,value in v1_manifest['files'].items())
head=subprocess.check_output(['git','-C',str(REPO),'rev-parse','HEAD'],text=True).strip()
assert head=='9641e981b7bf7a57ba108a655546098b0b0006cd'
assert repo_status()==''
old=read('proposed_action_row.json'); row=copy.deepcopy(old)
assert row['affected_dimensions'].count('setting')==1
row['affected_dimensions'].remove('setting')
removed=[e for e in row['affected_properties'] if e['dimension']=='setting']
assert removed==[{'dimension':'setting','target':'*','property':'*'}]
row['affected_properties']=[e for e in row['affected_properties'] if e['dimension']!='setting']
assert set(row)==set(old)
changed=[k for k in row if row[k]!=old[k]]
assert changed==['affected_dimensions','affected_properties']
assert row['affected_dimensions']==['action','pose','material']
write('proposed_action_row.json',row)
(OUT/'embedding_text.txt').write_bytes(row['embedding_text'].encode('utf-8'))
actual=pg.semantic_text_for_entry(row,'action',kind='slot').encode('utf-8')
(OUT/'embedding_input.txt').write_bytes(actual)
assert pg.SEMANTIC_TEXT_RECIPE_VERSION=='semantic-text-v5'
assert actual==(V1/'embedding_input.txt').read_bytes()
assert (OUT/'embedding_text.txt').read_bytes()==(V1/'embedding_text.txt').read_bytes()
(OUT/'source_provenance.json').write_bytes((V1/'source_provenance.json').read_bytes())

review=read('schema_review.json')
review['status']='REVIEW_REQUIRED_UNINSTALLED_V2'
review['effect_rationale']=[r for r in review['effect_rationale'] if r['dimension']!='setting']
review['revision_v2']={
 'review':'../review/REVIEW.md',
 'review_sha256':sha(REVIEW),
 'change':'Remove only the setting dimension and its setting/*/* effect from the candidate.',
 'reason':'The wheel and supported workpiece are existing prerequisites. The row does not introduce, relocate or install them. Rotation belongs to the action; deformation remains a material effect.',
 'retained':'All source wording, synonyms, relations, guards, action/material wildcards, pose path and remaining compatibility limitations are unchanged.',
 'effect_inventory':['action','pose','material'],
 'no_new_authority':'No installation, runtime/schema change, index build or provider call is implied.'
}
review['ordinary_runtime_clarifications']=[
 'The compiled_prerequisites sidecar demonstrates a generic compiler projection only; it is not evidence that ordinary slot retrieval emits or audits the adult-context prerequisite contract.',
 'Partial-property rejection occurs in later pack applicability, not initial ordinary eligibility. Either remaining action/material wildcard still overlaps every partial property anchor across carriers.',
 'property_effects_allowed alone does not check whole-dimension locks. The ordinary composition, requester-meaning and embodiment contracts remain necessary.',
 'The exact paired contact is an added visible duty, not a pre-existing action requirement. Existing apparatus/workpiece support and feasible access remain prerequisites.'
]
review['decision']='Freeze V2 for independent confirmation of the exact two-field correction. The bounded refinement may fit an established compatible maker, supported wheel/workpiece and open action/pose/material scope. No setting change is proposed or needed. All V1 remaining limitations persist; normal-path usefulness is not established. Do not weaken guards or fabricate narrower paths if a later isolated trial fails.'
write('schema_review.json',review)

context=pcc.compile_context(row,'slot:action:'+row['id'])
write('compiled_prerequisites.json',context)
assert (OUT/'compiled_prerequisites.json').read_bytes()==(V1/'compiled_prerequisites.json').read_bytes()
pcs.validate_candidate_entries({'slots':{'action':[row]}},AUTHORIAL_CORE_V3_INTENT_LOCK_DIMENSIONS)
errors=[]; validate_selection_contracts({'slots':{'action':[row]}},errors)
assert not errors,errors
subject={'en':'synthetic human category carrier','tags':['human','potter'],'kind':['human']}
location={'en':'synthetic neutral carrier','tags':['interior']}
event={'en':'synthetic prerequisite carrier','tags':['wheel','clay','wet']}
with_event={'subject':subject,'location':location,'action':event}
without_event={k:v for k,v in with_event.items() if k!='action'}
with_other_carrier={'subject':subject,'location':{'en':'tokens only, relations unspecified','tags':['wheel','clay','wet']}}
lock={'contract_version':'photo-intent-lock/v2','semantic_anchors':[{'dimension':'camera','target':'image_plane','property':'viewpoint.direction'}]}
probes=read('schema_probe.json')
actual_probes={
 'prerequisites_in_action_carrier':pg.compatible_with_slot_context('action',row,with_event),
 'same_prerequisites_after_action_carrier_removed':pg.compatible_with_slot_context('action',row,without_event),
 'disconnected_token_carrier_without_semantic_relation_check':pg.compatible_with_slot_context('action',row,with_other_carrier),
 'wildcard_effects_allowed_under_unrelated_partial_camera_lock':property_effects_allowed(lock,row['affected_dimensions'],row['affected_properties'])
}
assert actual_probes==probes['expected']
probes.update(actual_probes)
probes['version']=2
probes['candidate_entries_schema']='pass'
probes['selection_contract_shape']='pass'
probes['scope']='V1 structural/helper micro-probes rerun locally on the V2 row; not ordinary full-pipeline retrieval or qualification controls.'
probes['sidecar_limit']='compiled_prerequisites.json is not claimed to be emitted/audited by the ordinary slot path.'
write('schema_probe.json',probes)

bounds=read('acceptance_boundaries.json')
bounds['status']='v2_source_revision_frozen_without_evaluation_access'
bounds['decision']='REVIEW_REQUIRED_UNINSTALLED_V2'
bounds['immutable_proposal']['row_sha256']=sha(OUT/'proposed_action_row.json')
bounds['immutable_proposal']['embedding_text_sha256']=sha(OUT/'embedding_text.txt')
bounds['immutable_proposal']['provider_input_sha256']=sha(OUT/'embedding_input.txt')
bounds['revision_scope']='Remove only the unnecessary setting effect. All source-derived semantic boundaries, guards, contact duties and remaining limitations remain unchanged. Existing wheel/support is prerequisite context, not an added setting change.'
bounds['effect_dimensions']=['action','pose','material']
bounds['stopping_condition']='Complete V2 and its immutable comparison/manifest, then stop for the independent reviewer. No installation, index build, provider call, image, Git publication or evaluation-control/output access.'
write('acceptance_boundaries.json',bounds)

binding=read('source_binding.json')
assert all(sha(REPO/p)==h for p,h in binding['repo_sources_sha256'].items())
binding['version']=2
binding['revision_sources']={
 '../source-draft/manifest.json':sha(V1/'manifest.json'),
 '../source-draft/proposed_action_row.json':sha(V1/'proposed_action_row.json'),
 '../review/REVIEW.md':sha(REVIEW)
}
binding['revision_read_scope']='V1 source proposal, the named independent REVIEW.md, and the real local semantic-text function/dependencies only. No evaluation controls, frozen requests/cores, outputs or lane traces were inspected.'
write('source_binding.json',binding)

comparison={
 'status':'EXACT_TWO_FIELD_REVISION_VERIFIED',
 'v1_row_sha256':sha(V1/'proposed_action_row.json'),
 'v2_row_sha256':sha(OUT/'proposed_action_row.json'),
 'changed_top_level_keys':changed,
 'removed_dimension':'setting',
 'removed_property_effect':removed[0],
 'all_other_row_fields_byte_value_equivalent':all(row[k]==old[k] for k in row if k not in changed),
 'embedding_recipe':pg.SEMANTIC_TEXT_RECIPE_VERSION,
 'provider_input_generated_by':'prompt_generator.semantic_text_for_entry(row, "action", kind="slot")',
 'provider_input_bytes_changed':actual!=(V1/'embedding_input.txt').read_bytes(),
 'provider_input_byte_length':len(actual),
 'provider_input_sha256':sha(OUT/'embedding_input.txt'),
 'authored_embedding_text_bytes_changed':(OUT/'embedding_text.txt').read_bytes()!=(V1/'embedding_text.txt').read_bytes(),
 'source_provenance_bytes_changed':(OUT/'source_provenance.json').read_bytes()!=(V1/'source_provenance.json').read_bytes(),
 'compiled_prerequisites_bytes_changed':(OUT/'compiled_prerequisites.json').read_bytes()!=(V1/'compiled_prerequisites.json').read_bytes(),
 'input_recipe_reason':'Affected dimensions/properties are control metadata excluded from semantic-text-v5; all public semantic wording is unchanged.',
 'provider_calls':0,'index_builds':0,'installed':False,
 'v1_files_unchanged':v1_before=={p.name:sha(p) for p in V1.iterdir() if p.is_file()},
 'repository_clean':repo_status()==''
}
assert comparison['v1_files_unchanged'] and comparison['repository_clean']
write('revision_comparison.json',comparison)
print(json.dumps(comparison,ensure_ascii=False,indent=2))
