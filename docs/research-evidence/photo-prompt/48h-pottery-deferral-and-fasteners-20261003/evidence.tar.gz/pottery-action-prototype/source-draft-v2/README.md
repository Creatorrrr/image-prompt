# Pottery action proposal V2

Status: REVIEW_REQUIRED_UNINSTALLED_V2

The independent review recommended one footprint correction. V2 removes only `setting` from `affected_dimensions` and its `setting / * / *` property-effect row. Existing wheel/support is a prerequisite, not a new setting change. The remaining action, pose and material effects are retained.

All source wording, English/Korean labels, synonyms, concept units, relations, guards, action/material wildcards and the pose property path are unchanged. The original V1 files remain intact.

## Exact semantic input

`embedding_input.txt` was regenerated with the real local `prompt_generator.semantic_text_for_entry` function using the current `semantic-text-v5` recipe. Its bytes are **identical to V1**. No provider was called. Effect metadata is excluded from this semantic text recipe.

`revision_comparison.json` records the exact two changed fields, hashes, byte comparisons, unchanged V1 verification and clean repository state. `manifest.json` binds the V2 artifacts and reviewer/V1 provenance.

## Boundaries retained

The maker, supported wheel/workpiece, workable opened clay and feasible access remain prerequisites. The paired same-wall hand contact and rising-wall effect remain the proposed visible refinement. No apparatus relocation or creation is allowed by this row.

The current English token guards remain coarse and can miss event-only or Korean-only prerequisite evidence. They cannot establish same-owner physical compatibility. Source-complete ordinary candidate review and embodiment review remain necessary. The generic compiled prerequisite sidecar is a diagnostic projection; it is not a claim that the ordinary slot pipeline emits or audits that adult-context contract.

Action/material wildcards still cause later property-applicability rejection under any partial property anchor. Removing the setting effect does not cure that limitation, and the property helper does not independently check whole-dimension locks. No narrower path or relaxed guard is introduced.

The shape checks and V1 helper probes were rerun on V2. No evaluation control/output was accessed and no ordinary retrieval trial, installation, index build, provider request, image generation or Git change/publication occurred. Independent confirmation is pending.
