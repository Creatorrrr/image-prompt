# Pottery action prototype — frozen qualification plan

Created 2026-10-03 22:26 UTC before proposal wording or new control outputs. Source pin: 9641e981b7bf7a57ba108a655546098b0b0006cd. Uninstalled DATA-only investigation; not a committed improvement.

## Goal

Test whether one source-grounded ordinary wet-wheel wall-pulling action can provide an actually usable, truthful visible refinement through the existing public pipeline. Missing data and existing broad/focal ranking limitations are separate hypotheses. Do not change ranking, authoring procedure, property vocabulary, request queries or source meaning to force a positive result.

## Inputs and independent roles

- Source author sees primary process sources and narrowly named existing schema examples, not the current test requests/queries/results
- Four new source-unexposed, theme-targeted synthetic requests: open pottery operation, specified wet-wall operation, finished glazed object, unrelated craft
- Preserve the earlier two pottery stage-specific requests unchanged; their stage locks can legitimately prevent action adoption
- Schema adaptation may add necessary source-supported bookkeeping but cannot alter user meaning, frozen baseline, controls or openness. Preserve failed attempts and explain repairs
- Freeze proposal and all admitted inputs before after-arm generation. Any later wording change requires a new version and new independent controls for any claimed held-out improvement

## Normal-path test

Use the same installed runtime, normal default controls and seed 1003. Build full real indexes with authentic unchanged cached vectors and genuine embeddings only for actually new texts. No synthetic vectors, candidate-ID hints, forced opt-ins, partial fake registries, query replacement or hidden provider retries. Initially no provider calls; any later call requires the parent worker's existing scoped permission and cumulative budget check.

Compare baseline and isolated proposed DATA arms. Record every admitted input, query hash, eligibility, candidate rank/exposure, optional and ordinary displacement, request-owned stage/actor/material constraints, and full composed audit. Name API/public-function versus command-line evidence accurately.

## Acceptance boundary

1. The row must be source-supported and have honest prerequisites and effect declarations using current schema. If those cannot be represented safely, DEFER
2. At least one fresh compatible request must expose the new action as eligible through the normal public path, without rewriting its query or core
3. A separate composition step must decide whether to use the candidate from its ordinary pack. Do not require its ID or acceptance. A useful gain requires truthful, nonredundant visible refinement adopted in the final composition and a passing complete audit while preserving requester intent
4. Trimming, finished-object and unrelated-craft controls must not adopt the wet-wall process; any exposure must be honestly marked/declined under existing compatibility contracts. No new hard obligation may be forced
5. No unintended loss of known requester constraints or accepted control fidelity. Disclose optional displacement and any eligible-but-unadopted result
6. Independent source/contract and before-after review must support the bounded result. Small synthetic evidence does not prove general ranking or image-quality improvement

If no normal-path eligible adoption with useful refinement is demonstrated, record DEFER and do not publish source changes. Keep zero-gain or adverse results; do not accumulate aliases or alter acceptance criteria after seeing them.

## Costs and stop

No images or new provider service. Existing authorized Gemini budget is cumulative, not reset. Max one transport attempt for any genuine embedding call, reservation and uncertainty logged before dispatch. Stop this prototype at a defensible KEEP/DEFER/qualified narrow result; the surrounding 48h task continues until its existing deadline.
