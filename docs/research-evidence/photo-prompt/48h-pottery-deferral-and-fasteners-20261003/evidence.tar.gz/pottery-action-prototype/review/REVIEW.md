# Independent pottery-action proposal review

## Decision: revise-before-trial

Do not spend on embeddings for the frozen v1 row yet. Its process meaning is sound, but its effect declaration treats an already-required support arrangement as a new setting effect. Under the proposal's own prerequisite boundary, the apparatus and supported workpiece already exist. Referencing that support does not require changing the setting. A newly versioned proposal should remove the setting effect, retaining the actual action, pose, and material-deformation effects and all physical compatibility conditions. No synonym, retrieval guard, query, runtime, or frozen input change is recommended.

This is a narrowly correctable DATA footprint issue, not a finding that ordinary semantic review must provide universal physical proof. The existing schema can conservatively describe the remaining effects. If its coarse scope or current guards leave no useful normal-path adoption, the trial should end DEFER rather than broaden permission or alter the tests.

## Reviewed object and independence

- Repository pin: `9641e981b7bf7a57ba108a655546098b0b0006cd`, clean before and after
- Row: `action:pulling_wet_clay_wall_on_pottery_wheel`
- Frozen row SHA-256: `5ce789139e1fe440be07c7a1aba9b62cf50130887c9844826e884e9eceaa5405`
- Read the prototype PLAN, source-draft artifacts, repository skill/maintenance/composition/embodiment rules, runtime implementation, and authored schema examples
- No fresh-controls, qualification, or next-scene-target-audit files were read, including the two permitted audit extracts
- All helper scenarios were authored independently for this review. They are diagnostics, not new qualification controls or substitutes for the frozen evaluation
- No frozen proposal, corpus, generated index, repository source, or fixture was edited. No provider call, synthetic vector, publication, or image generation occurred

## Primary-source accuracy and synonyms

The proposal faithfully abstracts one technique in The Crucible's [wheel-throwing guide](https://www.thecrucible.org/guides/ceramics/wheel-throwing/), especially Steps 3–4: an accessible wet-clay wall receives inner stabilization and outer pressure, raising its height while wheel-supported. The guide separately describes later leather-hard trimming. This supports a sub-action, not an equivalence between all throwing and wall pulling.

Lea Durie's [Plant Pot Chuck](https://ceramicartsnetwork.org/ceramics-monthly/ceramics-monthly-article/quick-tip-plant-pot-chuck) independently confirms that trimming can involve an inverted leather-hard workpiece and a chuck. A wheel, clay, and a maker therefore do not establish this particular operation. The supplementary studio-talk PDF was not independently opened here; no conclusion depends on its unverified caption.

The English label and Korean wording retain the same narrow meaning. The two aliases are appropriate. Keywords about inner support and outer pressure are component search terms, not sufficient synonyms or prerequisites by themselves. Neither broad wheel-throwing aliases nor unrelated preparation terms should be added. No mandatory side assignment, special clothing, brand, camera recipe, bat, sponge, or trimming tool is justified by this row.

## Prerequisites and resulting duties

The source-draft's final distinction is correct: the exact paired hand placement is the proposed refinement, not a state that must already be present. An initially exterior hand position is not by itself a rejection if the relevant pose/action choices are open. Requiring the completed relation before adoption would make the candidate largely redundant.

Nevertheless, the supported apparatus, same workable opened workpiece, established human maker, reach/access, and availability of both hands must genuinely permit that refinement. Flat tags do not bind ownership, material state, support, or stage. A locked incompatible operation, retained occupied hand, inaccessible interior, or wrong workpiece stage must defeat adoption. Replacing an unbound incidental hand action can be valid only within the existing open scope and after reviewing the full resulting scene.

The candidate's three relations keep the support, shared target, and forming consequence together. All must survive adoption in one coherent final scene. These are optional-candidate duties upon selection; they are not grounds for introducing a new hard profile or mandatory render gate.

## Minimal honest effect footprint

This conclusion is derived from the frozen candidate meaning and its stated prerequisites, without viewing evaluation requests.

1. **Action is genuinely affected.** The proposed operation includes actor action and non-actor motion. The existing `main_subject / body.action_configuration` path alone does not clearly own the tool or workpiece effects. Keep the currently supported wildcard action declaration unless an independently justified existing path actually covers the full meaning. Do not fabricate a wheel-specific path.
2. **Pose is genuinely affected.** `main_subject / body.support_and_configuration` is an existing ordinary-action path and reasonably covers the selected hand/support configuration. It does not authorize changing identity or anatomy.
3. **Material is genuinely affected.** Wetness is a prerequisite, but the forming consequence adds deformation. Therefore material is not merely a reference to existing inventory. The authored tactile action examples `tactile_crease_contact_action` and `tactile_gather_contact_action` likewise declare action/material/pose for manipulation of an already-existing material. The only narrow non-actor material path found in the inspected authored property inventory was `depicted_artifact / surface.finish`, which is not a truthful substitute for this process. Retain the material wildcard and accept its cost.
4. **Setting is not an added effect under this proposal.** The source-draft requires the wheel and supported workpiece to be established. It neither relocates them nor installs an apparatus. Rotation belongs to the operation. Accordingly `setting / * / *` is unnecessary for the bounded refinement. If the intended candidate instead creates or relocates its apparatus, that is a different scope and conflicts with the frozen prerequisite account; it should not be smuggled in by retaining a broad declaration.

The recommended revision is exactly to remove `setting` from `affected_dimensions` and its one wildcard `affected_properties` row, then correct the rationale and freeze a new version for independent review. Keep the frozen v1 intact. This change would **not** remove the current cross-property rejection: either remaining action/material wildcard still overlaps every partial property anchor. It is an accuracy correction, not a claim that a smaller footprint guarantees useful eligibility.

## Actual ordinary-runtime guard and audit boundaries

The six checks in `independent-helper-results.json` ran with the full, validated installed runtime and its genuine existing indexes: 9,840 authored slot candidates. The proposed row was a separate helper argument and was never inserted into that corpus.

### Admission

`prompt_generator.py:11390–11418` (`core_slot_entry_eligible`) applies slot/category restrictions, human/category metadata, domain restrictions, facets/coherence/conflicts, declared token guards, and requester exclusions. It removes the current action carrier before evaluating context. The tested row has no additional derived quality-layer primary-context requirements.

The helper results were:

- Compatible support/material context with hands not yet paired: eligible
- Same physical prerequisites stated only in the event carrier: ineligible
- Separate wet cloth, clay bricks, cart wheel, and a finished vase: eligible, but semantically unsuitable
- One retained occupied hand: eligible, but incompatible if that action is required to remain
- Korean-only equivalent prerequisite prose: ineligible
- Nonhuman helper subject: ineligible

These are bounded manifestations of existing guards. They do not establish normal-path rank, exposure, adoption, full-core validity, or final quality.

### Property protection occurs later too

The initial ordinary eligibility helper does not apply property-effect checks. `build_candidate_pack` at `prompt_generator.py:10391–10410` subsequently marks exposed candidates ineligible when source effects overlap a protected property. Thus the frozen report's partial-lock rejection is real in the final pack, but it is not an initial retrieval filter; such a row can occupy retrieval capacity before the later rejection.

`property_effects_allowed` rejects this row for an unrelated camera property because its wildcard targets/properties overlap across carrier dimensions. With no partial property anchors it returns true, even for a whole-dimension action lock. That helper is explicitly not a whole-dimension or semantic solver. The usual requester-meaning, open-scope authorial-decision and embodiment contracts remain necessary.

### Ordinary candidate evidence is not the adult-context contract

The sidecar `compiled_prerequisites.json` is a valid projection of `compile_context`, but that does not show the normal ordinary slot pipeline emits or audits it. The inspected call sites use that context-evidence contract for adult contextual candidates. Ordinary `semantic_source` preserves concepts, relations and effects, while the ordinary selection audit requires newly authored literal interpretation and relation evidence. Its relation check binds IDs and phrases; it does not prove ownership, stage, direction, or physics.

The model-guided full-candidate review in `references/composition-contract.md`, preservation of actual requester meaning, and current embodiment review therefore carry the semantic judgment. This is an existing division of responsibility, not permission to treat a token match or literal evidence map as truth. Do not claim a fully machine-enforced prerequisite contract for this ordinary row, and do not add a parallel potter-specific gate to manufacture one.

## Required boundary for a later isolated trial

After a separately frozen footprint correction is independently accepted:

- Preserve every frozen request, core, control and query; follow PLAN's version/independence requirements rather than adapting tests to the row
- Use the real normal public path, genuine index data, and a separate composer who may decline the row
- Distinguish token admission, rank/exposure, final pack applicability, optional adoption, and useful nonredundant refinement
- Require compatible material/stage/actor ownership and the complete final relation, together with the existing full composed and embodiment audit
- Preserve trimming, finished-object and unrelated-craft constraints, including cases where optional exposure occurs but adoption must be declined
- Do not interpret these helpers or a later audit pass as an image-quality or universal safety result
- If no normal-path eligible, truthful, useful adoption appears, report DEFER without removing prerequisites, effects, negatives, or runtime guards

The present review authorizes no installation or provider call. It recommends a source-semantic correction before the trial rather than spending to test a known overdeclared footprint.
