# V2 independent review addendum

## Decision: approve-for-small-isolated-trial

V2 resolves the sole source-footprint blocker identified in the V1 review. Exact structural comparison verifies that only `setting` and its `setting / * / *` effect were removed. Every other row field/value is unchanged, including wording, translations, aliases, keywords, concept units, relations, human/primary-context/token guards, action/material wildcards, pose path, weight, and disabled assertion discovery.

- V2 row SHA-256: `8cce52650b055bbc213c9934292a07a2395901b17e349375abbd7b1f00280231`
- V1 row SHA-256 remains `5ce789139e1fe440be07c7a1aba9b62cf50130887c9844826e884e9eceaa5405`
- All files bound by both version manifests were verified
- Compiled prerequisite and primary-source provenance files are byte-identical
- The actual local `semantic_text_for_entry` function regenerated identical `semantic-text-v5` provider input: 1,150 bytes; SHA-256 `362287ab80f9704f2c44b4b70c73a1f2944d475cb45b1353740e782f64cb68ff`
- Candidate/selection-contract shape checks pass
- The remaining wildcard declarations still reject an unrelated partial camera-property lock, as expected
- Repository remains clean at `9641e981b7bf7a57ba108a655546098b0b0006cd`

The corrected explanation also accurately distinguishes the diagnostic prerequisite sidecar from the ordinary public candidate machinery. It preserves established apparatus/workpiece support as a prerequisite and paired hand contact as an added refinement. No new path, relaxed guard, hard profile, or runtime alteration was introduced.

Approval is limited to the small isolated normal-path trial in PLAN. It does not establish rank, eligible exposure, adoption, improvement, or rendered quality. Existing token-ownership ambiguity, event-carrier and Korean-only false negatives, conservative property rejection, requester-stage constraints, and the need for genuine composition/embodiment review remain. If the planned trial cannot show truthful useful adoption, its result remains DEFER without changing frozen inputs or weakening effects/guards.

No fixture/query/qualification access, provider request, installation, corpus/index edit, or publication was performed for this addendum. This review recommendation does not itself grant spending or publication authorization. Machine-readable verification: `decision-v2.json`.
