"""Read-only helper diagnostics, not qualification or public-pack generation.
No evaluation inputs, embeddings, retrieval, provider calls or corpus writes.
"""
import copy
import hashlib
import json
import subprocess
import sys
from pathlib import Path
ROOT = Path('/workspace/scratch/ce8f20680f5a')
REPO = ROOT / 'image-prompt'
OUT = ROOT / 'data-progress-48h-20261003/pottery-action-prototype/review'
DRAFT = OUT.parent / 'source-draft'
sys.dont_write_bytecode = True
sys.path.insert(0, str(REPO / 'skills/photo-prompt-image-generator/scripts'))
import prompt_generator as pg
import photo_candidate_semantics as pcs
from photo_contracts import property_effects_allowed, AUTHORIAL_CORE_V3_INTENT_LOCK_DIMENSIONS
from validate_photo_prompt_dictionary import validate_selection_contracts

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

row = json.loads((DRAFT / 'proposed_action_row.json').read_text())
manifest = json.loads((DRAFT / 'manifest.json').read_text())
manifest_results = {name: sha(DRAFT / name) == value for name, value in manifest['files'].items()}
assert all(manifest_results.values()), manifest_results
head = subprocess.check_output(['git','-C',str(REPO),'rev-parse','HEAD'], text=True).strip()
assert head == '9641e981b7bf7a57ba108a655546098b0b0006cd'
status_before = subprocess.check_output(['git','-C',str(REPO),'status','--porcelain'], text=True)
assert not status_before
# Load the complete installed runtime, including its genuine existing indexes.
# The proposed row remains a separate argument and is not inserted into the corpus.
data = pg.load_runtime_data()
pcs.validate_candidate_entries({'slots': {'action': [row]}}, AUTHORIAL_CORE_V3_INTENT_LOCK_DIMENSIONS)
errors = []
validate_selection_contracts({'slots': {'action': [row]}}, errors)
assert not errors, errors
contract = {
    'subject_category': 'human', 'domains': [], 'adult_allowed': False,
    'intent_constraints': {'subject_categories': ['human'], 'domains': [], 'no_people': False},
}

def picked(subject, setting, event, human=True):
    return {
        slot: {'en': text, 'tags': sorted(pg.candidate_pack_relevance_tokens(text)),
               'kind': ['human'] if slot == 'subject' and human else []}
        for slot, text in [('subject', subject), ('location', setting), ('action', event)]
    }

cases = [
    {
        'id': 'supported_open_hands',
        'subject': 'A human pottery maker',
        'setting': 'An opened wet clay vessel rests on a pottery wheel in the workshop.',
        'event': 'The maker brings both unoccupied hands close to the vessel while studying its wall.',
        'expected': True,
        'semantic_judgment': 'Compatible prerequisite setting; exact paired inside/outside contact is absent and may be added if action/pose/material are open. Rotation must also be allowed.',
    },
    {
        'id': 'event_only_prerequisites',
        'subject': 'A human pottery maker',
        'setting': 'A quiet room with a plain work area.',
        'event': 'The maker brings both hands toward an opened wet clay vessel supported on a pottery wheel.',
        'expected': False,
        'semantic_judgment': 'Plausible prerequisites are stated only in the removed action carrier. This is an eligibility false negative, not lack of physical compatibility.',
    },
    {
        'id': 'unbound_wrong_workpiece',
        'subject': 'A human pottery maker',
        'setting': 'A finished glazed vase stands by dry clay bricks, a wet floor cloth, and a cart wheel.',
        'event': 'The maker examines the fired vase with both hands free.',
        'expected': True,
        'semantic_judgment': 'Reject adoption: wet, clay and wheel belong to different objects and the target vessel is fired. Token eligibility does not establish ownership, apparatus identity or workable stage.',
    },
    {
        'id': 'retained_occupied_hand',
        'subject': 'A human pottery maker',
        'setting': 'An opened wet clay vessel rests on a pottery wheel in the workshop.',
        'event': 'The maker keeps one hand firmly holding a bowl while the other hand rests beside the vessel.',
        'expected': True,
        'semantic_judgment': 'Reject if the held-bowl action must be retained; the paired action needs both hands available. If this is unbound staging on open dimensions it may instead be replaced, which needs a real final embodiment review.',
    },
    {
        'id': 'korean_only_prerequisites',
        'subject': '한 명의 도예가',
        'setting': '작업실의 물레에 젖은 점토 기물이 놓여 있고 윗부분이 열려 있다.',
        'event': '두 손이 기벽 가까이 다가간다.',
        'expected': False,
        'semantic_judgment': 'The row does not encode per-role English-or-Korean equivalents for its English conjunction. Korean wording alone does not ensure eligibility.',
    },
    {
        'id': 'no_human_subject',
        'subject': 'A ceramic vase',
        'setting': 'An opened wet clay vessel rests on a pottery wheel in the workshop.',
        'event': 'The vessel remains centered.',
        'human': False,
        'expected': False,
        'semantic_judgment': 'The for_any human constraint rejects the proposed human action for this helper subject.',
    },
]
results = []
for case in cases:
    p = picked(case['subject'], case['setting'], case['event'], case.get('human', True))
    eligible = pg.core_slot_entry_eligible(data, {'user_exclusions': []}, contract, p, 'action', row)
    assert eligible == case['expected'], (case['id'], eligible)
    results.append({**case, 'picked_tokens': {s: v['tags'] for s,v in p.items()},
                    'core_slot_entry_eligible': eligible,
                    'helper_context_with_action_carrier': pg.compatible_with_slot_context('action', row, p, data),
                    'helper_context_without_action_carrier': pg.compatible_with_slot_context('action', row, {s:v for s,v in p.items() if s != 'action'}, data)})
locks = {
    'no_property_anchors': {'contract_version': 'photo-intent-lock/v2', 'semantic_anchors': []},
    'unrelated_camera_property': {'contract_version': 'photo-intent-lock/v2', 'semantic_anchors': [
        {'dimension':'camera','target':'image_plane','property':'viewpoint.direction'}]},
    'whole_dimension_action_lock_without_property': {'contract_version': 'photo-intent-lock/v2',
        'semantic_anchors': [], 'locked_dimensions':['action'], 'open_dimensions':['pose','material','setting']},
}
property_results = {name: property_effects_allowed(lock, row['affected_dimensions'], row['affected_properties'])
                    for name,lock in locks.items()}
assert property_results == {'no_property_anchors': True, 'unrelated_camera_property': False,
                            'whole_dimension_action_lock_without_property': True}
# This is only source-shape projection. compile_context is not an ordinary-pack call site.
projected_semantics = pcs.semantic_source(row, 'action', data.get('candidate_semantic_policy'))
quality_sources = pg.quality_layer_primary_context_requirement_sources(data, 'action', row)
status_after = subprocess.check_output(['git','-C',str(REPO),'status','--porcelain'], text=True)
assert status_after == status_before
assert all(sha(DRAFT / name) == value for name,value in manifest['files'].items())
output = {
    'scope': 'Independently authored helper cases against real loaded runtime; no full normalized core, public retrieval/pack, composed audit or quality claim.',
    'runtime_head': head, 'repository_clean_before_and_after': True,
    'runtime_loaded': True, 'runtime_slot_count':len(data['slots']),
    'runtime_candidate_count':sum(len(rows) for rows in data['slots'].values()),
    'proposal_inserted_into_runtime_corpus': False,
    'proposal_row_sha256':sha(DRAFT/'proposed_action_row.json'),
    'proposal_manifest_verified_unchanged':manifest_results,
    'schema_shape':'pass', 'selection_contract_shape':'pass',
    'eligibility_cases':results, 'property_effects_allowed':property_results,
    'property_scope_interpretation': 'False rejects ordinary pack applicability at build_candidate_pack. True without property anchors does not validate whole-dimension or semantic truth; those remain separate contracts and review.',
    'derived_quality_primary_requirements':quality_sources,
    'semantic_source_projection':projected_semantics,
    'not_run':['frozen-controls inspection','qualification inspection','next-scene-target-audit inspection','index build','new embeddings','provider calls','retrieval rank test','full candidate pack','full composed audit','image generation','corpus edit','Git publication'],
}
(OUT / 'independent-helper-results.json').write_text(json.dumps(output,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'schema':'pass','helper_cases':len(results),'case_results':{r['id']:r['core_slot_entry_eligible'] for r in results},'property_results':property_results,'real_runtime_candidates':output['runtime_candidate_count'],'repository_clean':not status_after,'output':str(OUT / 'independent-helper-results.json')},indent=2))
