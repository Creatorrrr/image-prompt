# Final independent eligibility-ceiling review

## Decision: DEFER before paid embeddings

The frozen V2 proposal cannot be eligible in any of the four fresh controls under the pinned runtime's necessary property-applicability check. The two earlier unchanged diagnostics also fail. This defeats PLAN acceptance condition 2 before ranking, adoption, or paid embedding work could help. Stop this prototype without installing the row, rebuilding an index, or weakening any source effect, prerequisite, fixture, or runtime guard.

The source/contract approval for a small isolated trial remains valid as an earlier phase finding. This later feasibility result supplies the trial's stopping outcome; it does not reverse the source meaning review or justify rewriting the row to fit the now-visible controls.

## Verified freeze and independent recomputation

I waited for the producer's final manifest notification before reading eligibility-ceiling contents. Qualification was already frozen. The parent then explicitly released the two earlier diagnostic input directories and their matching before-pack artifacts for read/hash verification.

- Pinned repository: `9641e981b7bf7a57ba108a655546098b0b0006cd`, still clean
- Exact V2 row SHA-256: `8cce52650b055bbc213c9934292a07a2395901b17e349375abbd7b1f00280231`
- Final ceiling manifest SHA-256: `283b20dee0eca3d1aca18a24f89f17b4fdeeadf10dfa26bd9df7afbc8912a63f`
- All 8 ceiling artifacts and 10 source-manifest references match their frozen hashes
- All 119 qualification files match the final before-phase manifest
- Both source-draft version manifests remain valid, and both earlier 12-file input freezes remain unchanged
- All six raw cores were independently normalized with their genuine request envelopes and control snapshots; normalized cores match their saved before packs and reported canonical hashes
- The actual runtime function snapshots and exact later build-property block match installed source
- Seven property-predicate checks on genuine existing pack members independently match their saved public applicability statuses

Full raw/core/query hashes and machine-readable verification are in `qualification-hash-verification.json`, `independent-fresh-results.json`, `independent-old-results.json`, and `verified-decision.json`. The four fresh controls are the previously disclosed baseline-repaired V2 cohort, not unchanged first-pass inputs.

## Distinct gate outcomes

| Frozen case | Initial ordinary gates | Necessary later property applicability | Eligible ceiling |
|---|---|---|---|
| Fresh 01, open wet forming | Pass | Reject | No |
| Fresh 02, specified wall pull | Pass | Reject | No |
| Fresh 03, finished glazed objects | Reject | Reject independently | No |
| Fresh 04, leather hand-stitching | Reject | Reject independently | No |
| Earlier wet-wall diagnostic | Reject | Reject independently | No |
| Earlier leather-hard trimming | Reject | Reject independently | No |

Initial eligibility was recomputed with the real `frozen_core_context` and `core_slot_entry_eligible` functions using the full loaded installed runtime. The proposed row remained a separate argument throughout; it was never a corpus, index, or pack member.

Fresh 01/02 have the prerequisite context necessary to clear those initial gates. Fresh 03 lacks an admissible human actor and making context. Fresh 04 lacks primary pottery context and wet/clay/wheel prerequisites. The earlier wall-pull diagnostic loses wet/clay support when the action carrier is excluded; this is an existing context-projection limitation, not evidence that its actual scene lacks wet clay. Earlier trimming lacks the required surviving token context and also represents a different protected material/process stage.

The later check is separate. `build_candidate_pack` applies `property_effects_allowed` to the source's actual semantic effect projection and marks an exposed candidate ineligible on failure. The unchanged action/material wildcard declarations overlap each case's partial property anchors across carrier dimensions. Both compatible fresh pottery cases already protect requester-owned wet-clay state; the specified-pull case also protects its operation phase. These are legitimate requester constraints.

A wildcard rejection does not prove the actual physical refinement would violate those constraints. It proves that this row's honest available coarse declaration cannot establish permitted property scope in these frozen cases. The machine predicate is intentionally conservative; this bounded result does not establish that the runtime is buggy.

## Why stopping before embedding is warranted

An embedding or ranking improvement cannot change the fixed source effects, frozen locks, or unconditional later property predicate. Even granting hypothetical perfect exposure, the fresh eligible ceiling remains zero. Consequently no genuine eligible adoption satisfying PLAN can result for this row/cohort without changing a frozen premise. Paid index/embedding work would not resolve the demonstrated blocker.

This conclusion is a necessary-condition ceiling, not an executed after-arm pack or a proposed ordinary-selection audit. No membership was fabricated to test selection. Ranking, optional displacement, actual adoption, full proposed composition/audit, rendered fidelity, and user preference were not established. The existing before-arm audits remain before-arm evidence only.

## Final scope

DEFER applies to this one source-reviewed V2 row, this pinned runtime, and these six frozen cases. It is not evidence that all pottery candidates are impossible, that other genuinely different open requests cannot use the action, or that a universal semantic solver is required. Preserve the zero-gain result and all artifacts. Any later independently justified investigation must be a separate task with its own source reasoning and frozen evaluation, rather than a repair of these tests.

No provider calls, embeddings, index builds, source/fixture mutations, installation, or publication were performed during this review.
