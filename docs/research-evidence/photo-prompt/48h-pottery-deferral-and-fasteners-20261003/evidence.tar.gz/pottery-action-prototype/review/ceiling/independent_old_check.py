"""Read-only verification of the two released unchanged stage diagnostics."""
import pathlib,json,hashlib,sys,subprocess
repo=pathlib.Path('/workspace/scratch/ce8f20680f5a/image-prompt');base=repo.parent/'data-progress-48h-20261003';root=base/'pottery-action-prototype';out=root/'review/ceiling'
H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();J=lambda p:json.loads(p.read_text());C=lambda obj:hashlib.sha256(json.dumps(obj,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()
sys.dont_write_bytecode=True;sys.path.insert(0,str(repo/'skills/photo-prompt-image-generator/scripts'))
import prompt_generator as pg
from photo_contracts import property_effects_allowed
row=J(root/'source-draft-v2/proposed_action_row.json');data=pg.load_runtime_data();results=[]
for name in ['potter_pulling_wall','potter_trimming_foot']:
 d=base/'next-scene-target-audit/fresh-inputs'/name;manifest=J(d/'freeze_manifest.json')
 for n,h in manifest['file_sha256'].items():assert H(d/n)==h,(name,n)
 assert H(d/'freeze_manifest.json')==J(root/'qualification/frozen-v2-manifest.json')['earlier_two_cores'][name]['freeze_manifest_sha256']
 raw=J(d/'authorial_core.json');assert C(raw)==manifest['core_json_canonical_sha256'];assert C(raw['intent_lock'])==manifest['intent_lock_raw_canonical_sha256']
 controls=J(d/'creative_controls.json');env=pg.load_request_envelope_arg(str(d/'request_envelope.json'))
 core=pg.load_authorial_core_arg(str(d/'authorial_core.json'),request_envelope=env,creative_control_snapshot=controls)
 pack=J(d/'candidate-pack.json')[0];assert core==pack['authorial_core']
 query,_=pg.authorial_core_retrieval_text(core);queryhash=hashlib.sha256(query.encode()).hexdigest();assert queryhash==pack['core_retrieval']['whole_scene_query_sha256']
 contract,picked=pg.frozen_core_context(data,core,controls);others={k:v for k,v in picked.items()if k!='action'}
 semantic=pg.photo_candidate_semantics.semantic_source(row,'action',data.get('candidate_semantic_policy'))
 eligible=pg.core_slot_entry_eligible(data,core,contract,picked,'action',row);prop_ok=property_effects_allowed(core['intent_lock'],semantic['affected_dimensions'],semantic.get('affected_properties',[]))
 assert not eligible and not prop_ok
 results.append({'id':name,'freeze_manifest_sha256':H(d/'freeze_manifest.json'),'frozen_files_verified':len(manifest['file_sha256']),'core_file_sha256':H(d/'authorial_core.json'),'canonical_core_sha256':core['canonical_sha256'],'core_matches_before_pack':True,'before_pack_sha256':H(d/'candidate-pack.json'),'audit_result_sha256':H(d/'audit.stdout.json'),'source_request_sha256':H(d/'source_request.txt'),'baseline_sha256':hashlib.sha256(core['baseline_prompt_en'].encode()).hexdigest(),'query_sha256':queryhash,'subject_category':contract['subject_category'],'slot_block_reason':pg.slot_block_reason(data,'action',contract),'entry_block_reason':pg.entry_block_reason(row,'action',contract),'for_any_pass':bool(set(row['for_any'])&(pg.entry_tags(picked['subject'])|pg.entry_kinds(picked['subject']))),'context_prerequisite_check':pg.compatible_with_slot_context('action',row,others,data),'initial_ordinary_eligibility':eligible,'later_property_applicability':prop_ok,'eligible_after_both_required_gates':eligible and prop_ok,'property_anchors':[a for a in core['intent_lock']['semantic_anchors']if 'property'in a]})
assert not any(e['id']==row['id']for e in data['slots']['action'])
result={'status':'verified','evidence_kind':'Exact unchanged earlier diagnostic files, normalized through real runtime and matched to saved before packs; row not inserted','row_sha256':H(root/'source-draft-v2/proposed_action_row.json'),'cases':results,'earlier_eligible_ceiling':0,'repository_clean':subprocess.check_output(['git','-C',str(repo),'status','--porcelain'],text=True)==''}
(out/'independent-old-results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'earlier_eligible_ceiling':0,'cases':[{'id':r['id'],'canonical_core_sha256':r['canonical_core_sha256'],'initial_ordinary_eligibility':r['initial_ordinary_eligibility'],'later_property_applicability':r['later_property_applicability']}for r in results]},indent=2))
