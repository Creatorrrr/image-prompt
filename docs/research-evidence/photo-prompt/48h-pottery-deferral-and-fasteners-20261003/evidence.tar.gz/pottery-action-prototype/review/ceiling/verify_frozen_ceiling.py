"""Verify producer freeze against independent computations, without rewriting it."""
import pathlib,json,hashlib,sys,inspect,subprocess
work=pathlib.Path('/workspace/scratch/ce8f20680f5a');repo=work/'image-prompt';root=work/'data-progress-48h-20261003/pottery-action-prototype';out=root/'review/ceiling';p=root/'eligibility-ceiling';q=root/'qualification'
J=lambda f:json.loads(f.read_text());H=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
manifest_hash='283b20dee0eca3d1aca18a24f89f17b4fdeeadf10dfa26bd9df7afbc8912a63f';assert H(p/'artifact-manifest.json')==manifest_hash
for name,rec in J(p/'artifact-manifest.json').items():
 f=p/name;assert H(f)==rec['sha256']and len(f.read_bytes())==rec['bytes'],name
for name,h in J(p/'source-manifest.json').items():assert H(work/name)==h,name
for name,rec in J(q/'before-phase-final-manifest.json').items():assert H(q/name)==rec['sha256']and len((q/name).read_bytes())==rec['bytes'],name
own=J(out/'independent-fresh-results.json')['cases']+J(out/'independent-old-results.json')['cases'];own={r['id']:r for r in own}
reported=J(p/'eligibility-results.json');assert set(own)=={r['id']for r in reported}
for r in reported:
 a=own[r['id']]
 assert a['canonical_core_sha256']==r['source_core_sha256']==J(p/'final-integrity.json')['six_input_core_hashes'][r['id']]
 assert a['core_file_sha256']==r['raw_core_file_sha256']
 assert a['initial_ordinary_eligibility']==r['ordinary_prerequisite_eligible']
 assert a['later_property_applicability']==r['later_property_eligible']
 assert a['eligible_after_both_required_gates']==r['could_be_eligible_if_ranked']
sys.dont_write_bytecode=True;sys.path.insert(0,str(repo/'skills/photo-prompt-image-generator/scripts'))
import prompt_generator as pg
import photo_candidate_semantics as pcs
funcs=[pg.frozen_core_context,pg.core_slot_entry_eligible,pg.compatible_with_slot_context,pg.entry_context_tokens,pg.picked_context_tokens,pg.picked_core_context_tokens,pcs.semantic_source,pg.property_effects_allowed]
assert '\n\n'.join(inspect.getsource(f)for f in funcs)==(p/'runtime-functions.snapshot.py.txt').read_text()
build=inspect.getsource(pg.build_candidate_pack);start=build.index('    for slot, payload in (pack.get("slots") or {}).items():');stop=build.index('    pack["candidate_bundles"]',start)
assert build[start:stop]==(p/'actual-build-property-block.snapshot.py.txt').read_text()
data=pg.load_runtime_data();row=J(root/'source-draft-v2/proposed_action_row.json');assert pg.candidate_pack_slot_entry_by_id(data,'action',row['id'])is None
real_checks=[]
for r in reported:
 if r['id'].startswith('fresh_'): packpath=q/'before'/r['id']/'candidate-pack.json'
 else: packpath=root.parent/'next-scene-target-audit/fresh-inputs'/r['id']/'candidate-pack.json'
 assert H(packpath)==r['pack_sha256'];pack=J(packpath)[0]
 for c in r['existing_genuine_action_member_predicate_checks']:
  current=next(x for x in pack['slots']['action']['candidates']if x['id']==c['id'])
  entry=pg.candidate_pack_slot_entry_by_id(data,'action',current['entry_id']);assert entry is not None
  sem=pcs.semantic_source(entry,'action',data.get('candidate_semantic_policy'))
  ok=pg.property_effects_allowed(pack['authorial_core']['intent_lock'],sem['affected_dimensions'],sem.get('affected_properties',[]))
  assert ok==c['predicate_allows']and current['applicability']==c['observed_public_applicability']
  assert current['applicability']['status']==('eligible'if ok else'ineligible')
  real_checks.append({'case':r['id'],'candidate_id':c['id'],'predicate_allows':ok,'matches_saved_public_status':True})
assert len(real_checks)==7
head=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip();status=subprocess.check_output(['git','-C',str(repo),'status','--porcelain'],text=True)
assert head=='9641e981b7bf7a57ba108a655546098b0b0006cd'and not status
result={'decision':'DEFER','basis':'No fresh frozen case can pass both the actual initial ordinary gates and the necessary later property applicability predicate for this unchanged row. Paid embedding/index work cannot change these fixed predicates.','frozen_ceiling_manifest_sha256':manifest_hash,'producer_artifacts_verified':8,'producer_source_links_verified':len(J(p/'source-manifest.json')),'qualification_files_reverified':119,'independent_case_results_match_producer':True,'six_recomputed_core_hashes':{k:v['canonical_core_sha256']for k,v in own.items()},'source_row_sha256':H(root/'source-draft-v2/proposed_action_row.json'),'exact_runtime_snapshot_match':True,'exact_build_property_block_match':True,'genuine_member_crosschecks':real_checks,'initial_ordinary_pass':2,'later_property_pass':0,'fresh_eligible_ceiling':0,'six_case_eligible_ceiling':0,'repository_head':head,'repository_clean':True,'proposed_row_installed_or_fabricated_as_member':False,'after_pack_generation':False,'proposed_selection_audit':False,'provider_calls':0,'embeddings':0,'index_builds':0,'generalization':'Only this reviewed row, pinned runtime and six frozen cases; not impossibility of pottery DATA or proof of a runtime bug.'}
(out/'verified-decision.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items()if k not in ['six_recomputed_core_hashes','genuine_member_crosschecks']},indent=2))
