"""Independent read-only ceiling checks; row remains outside installed corpus."""
import pathlib,json,hashlib,sys,subprocess,inspect
repo=pathlib.Path('/workspace/scratch/ce8f20680f5a/image-prompt');root=repo.parent/'data-progress-48h-20261003/pottery-action-prototype';q=root/'qualification';out=root/'review/ceiling'
H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();J=lambda p:json.loads(p.read_text())
sys.dont_write_bytecode=True;sys.path.insert(0,str(repo/'skills/photo-prompt-image-generator/scripts'))
import prompt_generator as pg
from photo_contracts import property_effects_allowed
row=J(root/'source-draft-v2/proposed_action_row.json')
assert H(root/'source-draft-v2/proposed_action_row.json')=='8cce52650b055bbc213c9934292a07a2395901b17e349375abbd7b1f00280231'
data=pg.load_runtime_data()
assert not any(e['id']==row['id']for e in data['slots']['action'])
frozen=J(q/'frozen-v2-manifest.json');results=[]
for case in frozen['cases']:
 d=pathlib.Path(case['input_directory']);controls=J(d/'creative-controls.json')
 envelope=pg.load_request_envelope_arg(str(d/'request-envelope.json'))
 core=pg.load_authorial_core_arg(str(d/'authorial-core.json'),request_envelope=envelope,creative_control_snapshot=controls)
 assert core['canonical_sha256']==case['normalization']['canonical_core_sha256']
 contract,picked=pg.frozen_core_context(data,core,controls)
 others={k:v for k,v in picked.items()if k!='action'}
 eligible=pg.core_slot_entry_eligible(data,core,contract,picked,'action',row)
 semantic=pg.photo_candidate_semantics.semantic_source(row,'action',data.get('candidate_semantic_policy'))
 prop_ok=property_effects_allowed(core['intent_lock'],semantic['affected_dimensions'],semantic.get('affected_properties',[]))
 results.append({'id':case['id'],'core_file_sha256':H(d/'authorial-core.json'),'canonical_core_sha256':core['canonical_sha256'],'subject_category':contract['subject_category'],'slot_block_reason':pg.slot_block_reason(data,'action',contract),'entry_block_reason':pg.entry_block_reason(row,'action',contract),'for_any_pass':bool(set(row['for_any'])&(pg.entry_tags(picked['subject'])|pg.entry_kinds(picked['subject']))),'context_prerequisite_check':pg.compatible_with_slot_context('action',row,others,data),'initial_ordinary_eligibility':eligible,'later_property_applicability':prop_ok,'eligible_after_both_required_gates':eligible and prop_ok,'property_anchors':[a for a in core['intent_lock']['semantic_anchors']if 'property'in a]})
assert [r['initial_ordinary_eligibility']for r in results]==[True,True,False,False]
assert all(not r['later_property_applicability']for r in results)
assert not any(e['id']==row['id']for e in data['slots']['action'])
summary={'evidence_kind':'Necessary-condition ceiling from exact real-runtime functions on frozen normalized inputs; not a generated after pack or full composed audit','row_was_never_a_corpus_member':True,'fake_membership_or_embeddings':False,'runtime_slot_candidates':sum(len(v)for v in data['slots'].values()),'row_sha256':H(root/'source-draft-v2/proposed_action_row.json'),'cases':results,'fresh_eligible_ceiling':0,'source_functions':{f.__name__:hashlib.sha256(inspect.getsource(f).encode()).hexdigest()for f in [pg.frozen_core_context,pg.core_slot_entry_eligible,pg.compatible_with_slot_context,property_effects_allowed]},'repository_clean':subprocess.check_output(['git','-C',str(repo),'status','--porcelain'],text=True)==''}
(out/'independent-fresh-results.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'fresh_eligible_ceiling':0,'initial_ordinary_eligibility':{r['id']:r['initial_ordinary_eligibility']for r in results},'later_property_applicability':{r['id']:r['later_property_applicability']for r in results}},indent=2))
