# Bounded garment fastening/opening meaning audit

## Result: KEEP all six; no DATA correction justified

Read-only audit on clean `9641e981b7bf7a57ba108a655546098b0b0006cd`, 2026-10-03. Six existing concepts were manually compared for EN/KO meaning, selected visible construction, prerequisite versus visible duty, and owner/opening consistency. No source, index, runtime, or Git changes; no provider calls, images, or private transmissions. This is a six-concept audit, not a full-corpus semantic or bilingual certification.

Useful boundary: an exposed zipper describes visible zipper hardware, not necessarily an unzipped garment. A concealed zipper may retain a visible pull while hiding its elements. A garment opening is a construction location; it does not by itself mean a skin-revealing gap. Buttoned cuffs and inserted toggles specify fastening state. None of the six selected contracts supplies an automatic skin-exposure obligation.

## Prior coverage and fixed sample

Read the photo skill, maintenance reference, both improvement ledgers, and the earlier `daylong-progress-20261002/garment-closure-alternative-audit/report.md` before choosing the sample. Earlier wrap-front/wrap-skirt, kebaya, wetsuit, halter, qipao, racerback, and sarong conclusions are not counted again. Existing opacity, CT098, accessory, and appearance-alignment work is excluded.

CT055-v1 lacing was considered for availability only, then excluded: `subculture-appearance-integration-20261003/INTEGRATION-MAINTENANCE.json` explicitly records its bilingual full-paraphrase reuse. The sample below therefore uses the exposed zipper counterpart instead. Discovery found no exact `unbuttoned` row in the bounded authored-asset lexical search; that observation is not evidence of semantic absence across the corpus.

Fixed selected candidates:

1. `clt_ct049_v2` / `clothing_ct049_v2`: buttoned cuff band
2. `clt_ct052_v1` / `clothing_ct052_v1`: exposed zipper
3. `clt_ct052_v2` / `clothing_ct052_v2`: concealed zipper
4. `clt_ct053_v2` / `clothing_ct053_v2`: covered trouser fly
5. `clt_ct054_v2` / `clothing_ct054_v2`: toggle through the opposite panel's loop
6. `sff_pro_h10`: snap fastener pair, source atom `pro:H10`

The five clothing pairs are in `photo_prompt_clothing_structure_extension.json` and `photo_prompt_visual_obligations_clothing_structure.json`. The snap candidate is in `photo_prompt_sensual_fetish_fashion_extension.json`; its source atom is in `sensual-fetish-20260928/source_pool.json`. Full selected rows and family-source extracts are saved in `source-extracts.json`.

## Meaning review

### 1. Buttoned cuff: KEEP

English: “a buttoned cuff band at the sleeve end.” Korean: “소매 끝에 버튼으로 여민 커프 밴드.” `buttoned` and `버튼으로 여민` both select a fastened sleeve-end band. They do not mean a shirt merely possessing decorative buttons, an open cuff, a bracelet, or a cufflink-only double cuff.

CT049's source family covers alternative cuff constructions, but explicitly makes feature pools alternatives rather than all-of duties. This particular variant does not collapse those alternatives: its definition, exact terms, component evidence, instruction, and gate all preserve the same buttoned band. A visible state is required when the selected profile applies; no fastening action, hand, cufflink, or hidden interlining is added.

### 2. Exposed zipper: KEEP

English: “an exposed zipper with visible teeth and slider.” Korean: “이빨과 슬라이더가 노출된 지퍼.” Both refer to hardware visibility. `노출된` modifies the zipper hardware, not skin. Visible teeth may be engaged; neither language specifies separated teeth, an opening gap, garment removal, or exposed body.

The paired selected profile repeats this same meaning through evidence and native gate. It does not demand that the zipper be concealed or borrow the concealed variant's pull-only condition. No contradiction was found.

### 3. Concealed zipper: KEEP

English: “a concealed zipper seam with only the small pull visible.” Korean: “작은 풀만 보이는 가려진 지퍼 솔기.” `풀` is a loanword for the zipper pull here, not an instruction to undo the closure. The row and bilingual paired exact terms consistently select the same seam/pull relation.

The visible duty is the selected seam and pull relationship, not a demand that concealed teeth become visible. The generic native instruction to inspect the stated boundary/connection does not supersede the explicit “only the small pull visible” sentence. A completely featureless seam would not establish the claimed hardware; this is distinct from demanding a view of every hidden component.

The current primary [YKK CONCEAL product description](https://ykkamericas.com/product/conceal/) supports a seam-like appearance when the slider is closed; [YKK's product specification](https://www.ykkfastening.com/products/search/detail.html?pdid1=CONCEAL%28R%29) identifies hidden elements. These support the distinction, not universal claims about every concealed installation or every photograph.

### 4. Covered trouser fly: KEEP; do not promote family-owner wording into an unproved defect

English: “a trouser fly covered by an overlapping fabric flap.” Korean: “겹친 천 플랩 아래 가려진 바지 플라이.” Both locate the construction on trousers and describe overlapping cover. Neither requires showing the concealed fastening mechanism or opening the fly. The selected definition, evidence, instruction, and gate remain explicitly trouser-specific.

The candidate relation's `subject` and its generated-style paraphrase still say “shirt or trousers,” inherited from the CT053 family containing shirt placket and trouser fly alternatives. This is imprecise family context. It is not enough to establish that the selected trouser fly becomes a shirt placket: the same relation object, selected definition, and required visible phrase expressly say “trouser.” The source contrast also warns against treating a front button row and trouser fly as the same owner. No runtime wrong-owner consequence was established; no broad owner/property cleanup is proposed.

The existing provenance is only family-level support. [Coats' work-trouser guidance](https://www.coats.com/en-us/industries/apparel/applications/workwear-uniforms/work-trousers/) independently confirms fly application on trousers, but does not prove the exact selected flap geometry. The flap remains the repository's authored narrow variant.

### 5. Inserted toggle: KEEP

English: “a toggle passing through a cord loop on the opposite front panel.” Korean: “반대 앞판의 끈 고리를 통과한 토글.” `passing through` can describe the visible installed relation and is compatible with the Korean completed-state phrasing. It need not be reinterpreted as an actor currently threading the toggle.

The opposite-panel relation distinguishes a functioning pair from one decorative knot. Source CT054, candidate, selected definition, evidence, instruction, and gate agree. No unnecessary hand, movement, skin gap, or requirement to show all coat fasteners was added. [Original Montgomery's own duffle-coat description](https://www.originalmontgomery.com/products/womens-classic-fit-duffle-coat-with-wooden-toggles-black) supports wooden toggles secured with rope as an actual construction; the exact selected opposite-panel geometry remains authored in the repository.

### 6. Snap fastener pair: KEEP, with visibility limits retained

English: “snap fastener pair.” Korean: “스냅 여밈의 대응 반쪽.” The Korean points to corresponding halves of the snap fastening. The candidate's additional concept unit specifies matching circular parts on outer/inner edges, and its owner relation selects `소매 커프` (sleeve cuff). Those fields match the original H10 source atom exactly. The broad English label is read with these complete candidate fields, not as a universal or owner-free definition.

[YKK's snap-button explanation](https://www.ykk.dk/en/produkter/trykknapper) distinguishes socket and stud engagement; its [January 2026 product announcement](https://www.ykk.com/english/newsroom/g_news/2026/20260113.html) also distinguishes visible cap from underparts. That supports the physical prerequisite of complementary parts, without establishing that both parts are visible in every closed cuff photograph. The authored candidate is an optional visible-pair choice. It does not say that any snap label proves both halves in pixels, that a cuff must be opened, or that an open cuff exposes skin. If a requested closed/occluded arrangement cannot show the selected relation, that is a compatibility/visibility question; no concrete erroneous consumer consequence was found here.

## Evidence and stopping boundary

`capture_evidence.py` re-reads only the named records and provenance, checks the fixed pin and clean worktree, and saves hashes. Its 29 scalar comparisons pass: EN/KO fields, source atoms, and selected profile surfaces are consistently copied. These checks are transcription evidence only. The semantic judgments above also consider fastening state, hidden hardware, required visible relations, and narrow authored alternatives.

No concrete discrepancy remained that justified a downstream consumer experiment. Therefore no public CLI, binding probe, synthetic index, runtime test, or image evaluation was run. Existing test source was inspected only; no new test pass is claimed. No natural-query accuracy, broad retrieval improvement, native-pixel correctness, or general contradiction detection is claimed.

Stop at KEEP. Do not count this as an accepted data cycle or force a correction from transliteration, generic family context, or absent lexical hits.
