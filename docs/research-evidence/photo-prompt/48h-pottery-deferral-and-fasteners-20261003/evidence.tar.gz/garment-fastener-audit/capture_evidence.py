import hashlib,json,subprocess
from pathlib import Path
ROOT=Path('/workspace/scratch/ce8f20680f5a/image-prompt')
OUT=Path(__file__).parent
EXPECTED='9641e981b7bf7a57ba108a655546098b0b0006cd'
def read(rel): return json.loads((ROOT/rel).read_text())
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
status=subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,text=True)
assert head==EXPECTED,(head,EXPECTED)
assert status=='',status
cf='skills/photo-prompt-image-generator/assets/photo_prompt_clothing_structure_extension.json'
pf='skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations_clothing_structure.json'
sf='skills/photo-prompt-image-generator/assets/photo_prompt_sensual_fetish_fashion_extension.json'
rf='docs/research-evidence/photo-prompt/clothing-terminology-20261001/semantic-records.json'
sp='docs/research-evidence/photo-prompt/sensual-fetish-20260928/source_pool.json'
ids=['clt_ct049_v2','clt_ct052_v1','clt_ct052_v2','clt_ct053_v2','clt_ct054_v2','sff_pro_h10']
profiles={r['id']:r for r in read(pf)['profiles']}
rows=[]
for filename in [cf,sf]:
 for slot,rs in read(filename)['slots'].items():
  for row in rs:
   if row['id'] not in ids:continue
   pid=row['id'].replace('clt_','clothing_') if row['id'].startswith('clt_') else None
   rows.append({'candidate_path':filename,'slot':slot,'candidate':row,'profile_path':pf if pid else None,'profile':profiles.get(pid)})
assert len(rows)==6
research=[r for r in read(rf)['records'] if r['id'] in ['CT049','CT052','CT053','CT054']]
snap=next(r for r in read(sp)['pro_atoms'] if r['id']=='H10')
checks=[]
for r in rows:
 c=r['candidate'];p=r['profile']
 if p:
  comp=p['authored_components']['components'][0]
  checks.append({'id':c['id'],'english_matches_definition':c['en']==p['semantics']['definition'],'english_is_evidence_anchor':c['en'] in comp['evidence_terms'],'bilingual_exact_terms_match':set(p['activation']['exact_terms'])=={c['en'],c['ko']},'english_in_instruction':c['en'] in comp['instruction'],'english_in_render_gate':c['en'] in comp['render_gate']['description'],'scope':'scalar consistency only; manual meaning review is separate'})
 else:
  checks.append({'id':c['id'],'english_matches_source':c['en']==snap['term_en'],'korean_matches_source':c['ko']==snap['term_ko'],'owner_matches_source':c['relations'][0]['object']==snap['visible_owner'],'visible_component_preserved':all(t in c['concept_units'] for t in snap['visible_components']),'scope':'source-atom consistency only; no standalone paired hard profile is asserted'})
assert all(v for row in checks for k,v in row.items() if isinstance(v,bool))
files=[cf,pf,sf,rf,sp,'skills/photo-prompt-image-generator/SKILL.md','skills/photo-prompt-image-generator/references/maintenance.md','docs/research-evidence/photo-prompt/clothing-terminology-20261001/sources.json','docs/research-evidence/photo-prompt/subculture-appearance-integration-20261003/INTEGRATION-MAINTENANCE.json']
(OUT/'source-extracts.json').write_text(json.dumps({'source_pin':head,'selected_six':rows,'research_family_records':research,'snap_source_atom':snap,'scalar_checks':checks},ensure_ascii=False,indent=2)+'\n')
manifest={'source_pin':head,'worktree_status':status,'source_files':{f:sha(ROOT/f) for f in files},'prior_ledgers':{str(p):sha(p) for p in [ROOT.parent/'daylong-progress-20261002/ledger.json',ROOT.parent/'data-progress-48h-20261003/ledger.json']},'prior_garment_audit':str(ROOT.parent/'daylong-progress-20261002/garment-closure-alternative-audit/report.md'),'selected_candidates':ids,'profiles_reviewed':5,'ordinary_candidate_without_paired_profile':1,'scalar_comparisons_passed':29,'semantic_disposition':'KEEP','accepted_data_changes':0,'production_writes':0,'provider_calls':0,'public_cli_runs':0,'consumer_runtime_probes':0,'tests_run':0,'images':0,'limits':['Manual six-concept semantic audit, not full-corpus bilingual assurance.','Scalar identity checks establish transcription consistency only, not semantic correctness.','No discrepancy warranted downstream runtime experiment or DATA edit.','No index rebuild, source edit, Git mutation, image generation or private data transmission.']}
(OUT/'RESULTS.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'source_pin':head,'selected':len(rows),'scalar_checks':sum(sum(isinstance(v,bool) for v in row.values()) for row in checks),'worktree_status':status},indent=2))
