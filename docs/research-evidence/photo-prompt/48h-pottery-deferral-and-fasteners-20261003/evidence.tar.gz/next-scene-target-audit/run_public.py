"""Public normal v6 consumer; frozen inputs, no query embedding or forced candidates."""
import hashlib,json,os,subprocess,sys,time
from pathlib import Path
ROOT=Path('/workspace/scratch/ce8f20680f5a/image-prompt');OUT=Path(__file__).resolve().parent;S=ROOT/'skills/photo-prompt-image-generator'
sys.dont_write_bytecode=True
ENV={k:v for k,v in os.environ.items() if not any(t in k.upper() for t in ['TOKEN','API_KEY','CREDENTIAL'])};ENV['PYTHONDONTWRITEBYTECODE']='1'
def W(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
results=[]
for d in sorted((OUT/'fresh-inputs').iterdir()):
 if not d.is_dir():continue
 m=json.loads((d/'freeze_manifest.json').read_text())
 for f,h in m['file_sha256'].items():assert hashlib.sha256((d/f).read_bytes()).hexdigest()==h,f
 base=['--request-envelope-json',str(d/'request_envelope.json'),'--authorial-core-json',str(d/'authorial_core.json'),'--creative-controls-json',str(d/'creative_controls.json'),'--embodiment-review-json',str(d/'embodiment_review.json')]
 cmd=[sys.executable,str(S/'scripts/generate_photo_prompt.py'),*base,'--seed','103','--output-file',str(d/'candidate-pack.json')]
 t=time.time()
 reused=(d/'candidate-pack.json').exists()
 p=(subprocess.CompletedProcess(cmd,0,(d/'public.stdout.txt').read_text(),(d/'public.stderr.txt').read_text()) if reused else subprocess.run(cmd,cwd=ROOT,env=ENV,text=True,capture_output=True,timeout=300))
 (d/'public.stdout.txt').write_text(p.stdout);(d/'public.stderr.txt').write_text(p.stderr)
 row=dict(id=d.name,command=cmd,returncode=p.returncode,elapsed_seconds=round(time.time()-t,2),error=p.stderr,reused_successful_pack_after_summary_error=reused)
 if p.returncode==0:
  pack=json.loads((d/'candidate-pack.json').read_text())[0]
  row.update(pack_id=pack['pack_id'],pack_sha256=hashlib.sha256((d/'candidate-pack.json').read_bytes()).hexdigest(),slots={s:[c['id']for c in r['candidates']]for s,r in pack['slots'].items()},visual_candidate_ids=[c['id']for c in pack['visual_concept_candidates']['candidates']],hard_obligation_ids=[c['id']for c in pack.get('visual_obligations',{}).get('obligations',[])],core_retrieval=pack['core_retrieval'])
 results.append(row);W(OUT/'public-results.json',results)
 print(d.name,p.returncode,p.stderr[:1600],flush=True)
