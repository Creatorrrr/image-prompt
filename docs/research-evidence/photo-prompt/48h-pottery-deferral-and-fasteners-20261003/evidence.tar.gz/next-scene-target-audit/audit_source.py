"""Read-only narrow pottery lookup; never mutates corpus or indexes."""
from pathlib import Path
import hashlib,json,re,subprocess,sys
ROOT=Path('/workspace/scratch/ce8f20680f5a/image-prompt')
OUT=Path(__file__).resolve().parent
S=ROOT/'skills/photo-prompt-image-generator'
sys.dont_write_bytecode=True;sys.path.insert(0,str(S/'scripts'))
import prompt_generator as g
D=g.load_runtime_data()
PAT=re.compile(r'\b(?:potter|pottery|ceramics|ceramic|clay|kiln|glaz\w*|greenware|leather[- ]hard|wheel[- ]throw\w*|wheel[- ]head|wedg\w*|loop tool|trimming tool)\b|물레|도예|도자|점토|양봉|honeycomb|beekeep',re.I)
STAGE=re.compile(r'pottery wheel|potter.s wheel|wheel[- ]throw|leather[- ]hard|loop tool|foot ring|물레|굽깎|굽 깎',re.I)
rows=[dict(slot=s,row=r) for s,rs in D['slots'].items() for r in rs if PAT.search(json.dumps(r,ensure_ascii=False))]
profiles=[p for p in D[g.VISUAL_OBLIGATIONS_DATA_KEY]['profiles'] if PAT.search(json.dumps(p,ensure_ascii=False))]
res=dict(head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),query_pattern=PAT.pattern,stage_pattern=STAGE.pattern,semantic_inspection_scope='Two pottery-process stages only. Bee reconnaissance had zero hits and was abandoned. Lexical lookup across the merged corpus is not an exhaustive semantic audit.',merged_candidate_count=sum(map(len,D['slots'].values())),matched_candidate_count=len(rows),candidate_matches=rows,matched_profile_count=len(profiles),profile_match_ids=[p['id'] for p in profiles],named_existing_companions=['subject:ceramic_potter','subject:ceramic_artist','location:ceramics_studio','prop:handmade_ceramic_cup_prop','prop:craft_tools_scattered_prop','action:prepping_workshop_materials'],direct_new_process_matches=[dict(slot=s,id=r['id'])for s,rs in D['slots'].items()for r in rs if STAGE.search(json.dumps(r,ensure_ascii=False))],direct_new_process_profile_matches=[p['id']for p in D[g.VISUAL_OBLIGATIONS_DATA_KEY]['profiles']if STAGE.search(json.dumps(p,ensure_ascii=False))],source_hashes={str(f.relative_to(ROOT)):hashlib.sha256(f.read_bytes()).hexdigest()for f in [S/'SKILL.md',S/'references/maintenance.md',S/'assets/photo_prompt_tags.json',S/'assets/photo_prompt_visual_obligations.json',S/'assets/photo_prompt_semantic_index.json',S/'assets/photo_prompt_visual_profile_index.json',S/'scripts/prompt_generator.py']})
(OUT/'bounded-source-sample.json').write_text(json.dumps(res,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in res.items() if k not in ['candidate_matches','source_hashes']},indent=2))
