"""Validate preserved baselines; this is not optional-adoption benefit evidence."""
import copy,hashlib,json,os,subprocess,sys
from pathlib import Path
ROOT=Path('/workspace/scratch/ce8f20680f5a/image-prompt');O=Path(__file__).resolve().parent;S=ROOT/'skills/photo-prompt-image-generator'
E={k:v for k,v in os.environ.items()if not any(t in k.upper()for t in ['TOKEN','API_KEY','CREDENTIAL'])};E['PYTHONDONTWRITEBYTECODE']='1'
def W(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
results=[]
for d in sorted((O/'fresh-inputs').iterdir()):
 if not d.is_dir():continue
 p=json.loads((d/'candidate-pack.json').read_text())[0];core=p['authorial_core'];lock=core['intent_lock'];review=copy.deepcopy(p['embodiment_preflight']['baseline_review']);review['provenance']='agent_postcomposition'
 assert not p.get('visual_obligations',{}).get('obligations',[])
 c=dict(pack_id=p['pack_id'],core_retrieval_sha256=p['core_retrieval']['canonical_sha256'],prompt_en=core['baseline_prompt_en'],negative_en=p['negative_en'],chosen_candidate_ids=[],chosen_visual_concept_ids=[],composer='agent',candidate_interpretations=[],authorial_core_binding=dict(source_authorial_core_sha256=core['canonical_sha256'],source_intent_lock_sha256=lock['canonical_sha256'],preserved_anchor_ids=[a['anchor_id']for a in lock['semantic_anchors']],preserved_evidence=[],authorial_decisions=[]),embodiment_review=dict(source_contract_sha256=p['embodiment_preflight']['canonical_sha256'],review=review),semantic_clarification_decisions=[dict(clarification_id=x['id'],decision='applied'if x.get('required_in_final_prompt')else'rejected',rationale='Preserve the independently frozen pottery operation and decline unrelated optional interpretations.',prompt_evidence=lock['semantic_anchors'][0]['prompt_evidence'])for x in p['semantic_clarification']['candidates']],creative_augmentation_brief=dict(decisions=[dict(candidate_id=x['id'],decision='rejected',rationale='Keep the independently authored pottery operation and its coherent material state.')for x in p['creative_augmentation']['candidates']]))
 contract=p.get('semantic_assertion_obligations')
 if contract:c['semantic_assertion_evidence']=dict(source_contract_sha256=contract['canonical_sha256'],evidence={x['assertion_id']:x['frozen_evidence']for x in contract['obligations']})

 adult=p.get('adult_appeal',{})
 if adult.get('enabled'):
  reasons={
   'clt_ct003_v2':('relevant','The baseline already uses an open-collared working shirt. Its light, relaxed presence serves the subtle attraction without adding a second wardrobe direction.'),
   'pr_fabric_tension_fold_attachment_candidate':('relevant','Rolled sleeves and bent arms make plausible cloth folds available, but a full seam-and-tension description would draw attention away from the wet clay contact. Retain the baseline at the same sensual strength.'),
   'ae_smolder_attraction':('uncertain','The potter already looks toward delicate work. A stronger interpersonal smolder is not supported by this moment, so preserve absorbed attention and existing adult presence.'),
   'cr_candidate_split_complementary':('irrelevant','A deliberately three-region color construction would compete with the existing restrained skin and clay hierarchy; it offers no needed improvement to the working moment.'),
   'rail_platform_dispatch_uniform':('irrelevant','Rail dispatch equipment would create a new professional context unrelated to the requested pottery operation.'),
   'pv_cross_shins_seated_surface':('irrelevant','Crossed shins on the sitting surface would replace the chosen close wheel-working support and is unnecessary for the subtle appeal of this controlled hand action.'),
   'stirrup_legging_underfoot_loop':('irrelevant','An underfoot garment loop has no visible role in this face-and-hands composition and would introduce an unrelated clothing focus.')}
  records=[]
  for cid in adult['contextual_retrieval']['review_candidate_ids']:
   reading,reason=reasons[cid.rsplit(':',1)[-1]];records.append(dict(candidate_id=cid,reading=reading,reason=reason))
  evidence=('an open-collared linen shirt loose at the throat and its sleeves pushed above the forearms' if d.name=='potter_pulling_wall' else 'A relaxed neckline and rolled sleeves give the adult maker an easy, quietly attractive presence')
  c['adult_appeal_brief']=dict(adult_subject_phrase='an adult potter',agency_phrase=lock['semantic_anchors'][2]['prompt_evidence'],contextual_review=records,contextual_comparison='Retain the baseline at the frozen sensual intensity: working concentration, relaxed clothing and shaped light support quiet adult attraction. The offered alternatives add no necessary improvement to the clay operation, and none is selected.',axes={axis:dict(intensity=state['intensity'],realization='baseline',affected_dimensions=[],affected_properties=[],artistic_interpretation='Retain the authored quietly attractive adult presence around the precise working action.',prompt_evidence=evidence if state['intensity']>0 else '') for axis,state in adult['axes'].items()},blend=dict(emphasis=adult['blend']['emphasis']))
 W(d/'composed-baseline.json',c)
 cmd=[sys.executable,str(S/'scripts/audit_composed_prompt.py'),'--pack',str(d/'candidate-pack.json'),'--composed',str(d/'composed-baseline.json')]
 r=subprocess.run(cmd,cwd=ROOT,env=E,text=True,capture_output=True,timeout=300)
 (d/'audit.stdout.json').write_text(r.stdout);(d/'audit.stderr.txt').write_text(r.stderr)
 results.append(dict(id=d.name,returncode=r.returncode,command=cmd,result=json.loads(r.stdout)if r.stdout.startswith('{')else r.stdout,stderr=r.stderr,claim='Unchanged baseline validation only; zero optional adoption and no measured DATA benefit.'));W(O/'baseline-audit-results.json',results);print(d.name,r.returncode,r.stderr[:600],flush=True)
