# Bounded pottery-process opportunity

Pinned source: `9641e981b7bf7a57ba108a655546098b0b0006cd`. Read-only investigation; no corpus/index/runtime/procedure changes, provider calls, images, or publication.

## Result

**PROPOSE ONE BOUNDED TRIAL: wet-clay wall-pulling action on a pottery wheel.** Use leather-hard foot trimming only as its stage-confusion control. This is a genuine new DATA opportunity with an existing ordinary `action` consumer, **not a qualified or accepted improvement**. Actual admission, eligibility and adoption of a new row remain unmeasured because no row or index was changed. If the next trial cannot expose and truthfully adopt the complete new action through the normal public CLI, DEFER it rather than expanding aliases or weakening scope.

A useful scene is an adult maker's supported fingers raising a wet vessel wall while the wheel turns: the opposing contact, yielding clay and upward growth express skilled work instead of a generic person in a studio. The contrasting trimming scene has an inverted, partly dried bowl, cutting contact and removed clay. These stages should not be combined, nor should a finished glazed cup or decorative ceramic surface substitute for the operation.

## Why this is new

Read both progress ledgers and the current skill/maintenance rules first. No completed cycle in either ledger concerns pottery process data. The older pottery-shelf query was only a shallow-depth-of-field control; it did not add pottery operations.

The lexical lookup covers the merged corpus only to locate the named ceramic family. It returns 36 loosely matching candidate records and 9 loosely matching profile IDs; unrelated matches include fictional clay bodies, ceramic iconography and word-fragment collisions. This is not a semantic audit of all records. Semantic inspection is bounded to six existing companion records (`ceramic_potter`, `ceramic_artist`, `ceramics_studio`, `handmade_ceramic_cup_prop`, `craft_tools_scattered_prop`, `prepping_workshop_materials`) and two ceramic finish controls (`porcelain_ceramic_glaze_texture`, `porcelain_craquelure_surface`). A preliminary craft-tag listing was reconnaissance, not a 35-record correctness audit.

No candidate or profile matches the targeted stage expressions pottery/potter's wheel, wheel-throwing, leather-hard, loop tool or foot ring, including the checked Korean forms. This is bounded lexical absence evidence, not proof that no broad existing wording could suggest clay work. The established potter/studio nouns do not encode either physical operation. The robot-oriented glaze texture explicitly describes automaton casing; it should remain that source meaning.

## Primary-source meaning

[The Crucible's teaching guide](https://www.thecrucible.org/guides/ceramics/wheel-throwing/) separates wet-wheel forming from later leather-hard trimming and describes an interior supporting hand with controlled pressure outside the wall. [Lea Durie's studio technique](https://ceramicartsnetwork.org/ceramics-monthly/ceramics-monthly-article/quick-tip-plant-pot-chuck) establishes that inverted leather-hard work needs compatible support and that a chuck is a legitimate alternative. [Lansing Wagner's illustrated process](https://ceramicartsnetwork.org/docs/default-source/magazine-archives/studiotalk_2022_online.pdf?sfvrsn=5d624b08_5), page 30, documents loop-tool foot definition and clay removal. These support stage, contact and consequence, not mandatory handedness, wheel direction, camera, clothing or a single support device.

## Actual public consumer

Two separately authored, source-unexposed synthetic requests were frozen with default controls, complete baselines, feature selections, v3 cores and embodiment reviews. No candidate IDs, visual opt-ins, new settings or query embeddings were supplied. The requests explicitly name their respective stages, so these are targeted maintenance scenes, not population/natural-query accuracy evidence.

Both normal public CLI generations exit 0. Both reach the ordinary `action` slot. The wet-wall pack contains 64 ordinary slots/64 candidates; the trimming pack contains 63 slots/64 candidates. Current action offers are respectively `ctx_function_texture_conflict` and `hair_tie_mid_action`, both marked **ineligible** under property scope and neither semantically suitable. `ceramic_potter` is genuinely exposed and eligible only in the trimming pack. Existing `ceramics_studio` is absent in both; `texture`, `prop` and `surface_material` slots are also absent. Eight optional visual candidates in each pack are not evidence of pottery-process adoption. No automatic pottery hard obligation is introduced.

The reachable consumer is therefore the existing ordinary **action** lane, not a demonstrated new material/detail lane or an existing usable stage candidate. The future proposal must respect the frozen wetness/tool/geometry properties and preserve the requested event. Complete effect declarations and real prerequisites matter; do not declare effects artificially narrow merely to pass these two fixtures. Baseline-only audits, recorded separately, measure contract integrity rather than gain.

## Absence versus retrieval behavior

`named-consumer-trace.json` records the exact global query, frozen subject/location/action projections, same-slot focal queries and source fields. Recomputed query hashes equal the public pack for all six slot traces. The subject query is literally `an adult potter` in both cores. Actions use each frozen `event` sentence; neither was rewritten to dictionary language.

For wall-pulling, the existing `ceramic_potter` is eligible and focal rank 1, but absent from the capped broad lane (24 returned positions); the performer is present in both lanes. For trimming, the potter is broad rank 24 and focal rank 1 and reaches the pack. The working-ceramics location is eligible but misses the broad cutoff in both; it is focal rank 3 for wall-pulling and absent from the trimmed focal list for trimming. These companion omissions are existing broad/focal intersection and bounded-admission behavior, not missing potter/studio data. New aliases on those existing nouns are not justified by this audit. The process gap is separate: there is no source-authored pottery action for the action lane to rank. A new row could still fail the existing ranking/property gates, so a prototype is required.

Both complete unchanged-baseline audits pass after adding the genuinely required default-control adult-appeal review to the composition record. The first omitted-brief failures are preserved in `baseline-audit-results.attempt1-missing-adult-brief.json`; input request, baseline, controls and source were unchanged. No optional candidate was adopted, so these passes establish only usable frozen test scaffolds, not a benefit.

## Next qualification and stopping rule

Start with one source-grounded ordinary wall-pulling action plus its genuine EN/KO descriptions and supported process relations, reusing the existing potter and studio concepts. Avoid a new hard profile or a broad new craft family. Check a fresh compatible wall-pulling scene, the frozen trimming contrast, a finished-ceramic still life and an unrelated craft control. Do not promote a supplied request term into a required profile or change controls to make the row appear.

Acceptance requires a normal public pack actually exposing an eligible row, followed by a coherent final composition that adopts its complete action and provides a visible useful refinement within the request. Freeze the refinement and meaning before comparing arms, preserve unrelated displacement, and require the trimming/still-life controls to decline it. An in-memory slot score, helper projection, synthetic vector, forced ID, baseline-only pass or proposer-authored source phrase is insufficient. This report justifies that next small trial; it does not justify source publication now.

## Reproduce

- `python audit_source.py`: merged narrow lookup, named companions, zero targeted-stage matches and hashes
- `fresh-inputs/`: independent raw requests, baselines, control/catalog snapshots, ownership records and freeze manifests
- `python run_public.py`: normal generator with preserved input hashes and credential-free environment; existing completed outputs are reused
- `public-results.json`: exact invocations, full pack IDs/hashes and admitted inventory
- `python audit_public_baselines.py`: unchanged-baseline composed audits, explicitly zero adoption
- `primary-source-evidence.json`: public source boundaries
- `python trace_named_consumers.py`: exact query hashes and named eligible source/ranking traces; no candidate or query intervention

An initial summary-only `KeyError` on the absent optional `visual_obligations` field is preserved in `initial-summary-error.txt` and the original script. Generation had already succeeded; its output was reused rather than counted twice. No source failure or DATA benefit is attributed to this harness error.
