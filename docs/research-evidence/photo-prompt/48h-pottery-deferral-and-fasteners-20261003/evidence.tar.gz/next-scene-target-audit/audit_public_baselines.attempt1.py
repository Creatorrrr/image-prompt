"""Validate preserved baselines; this is not optional-adoption benefit evidence."""
import copy,hashlib,json,os,subprocess,sys
from pathlib import Path
ROOT=Path('/workspace/scratch/ce8f20680f5a/image-prompt');O=Path(__file__).resolve().parent;S=ROOT/'skills/photo-prompt-image-generator'
E={k:v for k,v in os.environ.items()if not any(t in k.upper()for t in ['TOKEN','API_KEY','CREDENTIAL'])};E['PYTHONDONTWRITEBYTECODE']='1'
def W(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
results=[]
for d in sorted((O/'fresh-inputs').iterdir()):
 if not d.is_dir():continue
 p=json.loads((d/'candidate-pack.json').read_text())[0];core=p['authorial_core'];lock=core['intent_lock'];review=copy.deepcopy(p['embodiment_preflight']['baseline_review']);review['provenance']='agent_postcomposition'
 assert not p.get('visual_obligations',{}).get('obligations',[])
 c=dict(pack_id=p['pack_id'],core_retrieval_sha256=p['core_retrieval']['canonical_sha256'],prompt_en=core['baseline_prompt_en'],negative_en=p['negative_en'],chosen_candidate_ids=[],chosen_visual_concept_ids=[],composer='agent',candidate_interpretations=[],authorial_core_binding=dict(source_authorial_core_sha256=core['canonical_sha256'],source_intent_lock_sha256=lock['canonical_sha256'],preserved_anchor_ids=[a['anchor_id']for a in lock['semantic_anchors']],preserved_evidence=[],authorial_decisions=[]),embodiment_review=dict(source_contract_sha256=p['embodiment_preflight']['canonical_sha256'],review=review),semantic_clarification_decisions=[dict(clarification_id=x['id'],decision='applied'if x.get('required_in_final_prompt')else'rejected',rationale='Preserve the independently frozen pottery operation and decline unrelated optional interpretations.',prompt_evidence=lock['semantic_anchors'][0]['prompt_evidence'])for x in p['semantic_clarification']['candidates']],creative_augmentation_brief=dict(decisions=[dict(candidate_id=x['id'],decision='rejected',rationale='Keep the independently authored pottery operation and its coherent material state.')for x in p['creative_augmentation']['candidates']]))
 contract=p.get('semantic_assertion_obligations')
 if contract:c['semantic_assertion_evidence']=dict(source_contract_sha256=contract['canonical_sha256'],evidence={x['assertion_id']:x['frozen_evidence']for x in contract['obligations']})
 W(d/'composed-baseline.json',c)
 cmd=[sys.executable,str(S/'scripts/audit_composed_prompt.py'),'--pack',str(d/'candidate-pack.json'),'--composed',str(d/'composed-baseline.json')]
 r=subprocess.run(cmd,cwd=ROOT,env=E,text=True,capture_output=True,timeout=300)
 (d/'audit.stdout.json').write_text(r.stdout);(d/'audit.stderr.txt').write_text(r.stderr)
 results.append(dict(id=d.name,returncode=r.returncode,command=cmd,result=json.loads(r.stdout)if r.stdout.startswith('{')else r.stdout,stderr=r.stderr,claim='Unchanged baseline validation only; zero optional adoption and no measured DATA benefit.'));W(O/'baseline-audit-results.json',results);print(d.name,r.returncode,r.stderr[:600],flush=True)
