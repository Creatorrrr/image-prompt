"""Exact frozen query/provenance and named companion diagnostics, no intervention."""
import copy,json,sys,hashlib
from pathlib import Path
R=Path('/workspace/scratch/ce8f20680f5a/image-prompt');O=Path(__file__).resolve().parent;S=R/'skills/photo-prompt-image-generator/scripts';sys.dont_write_bytecode=True;sys.path.insert(0,str(S));import prompt_generator as g
D=g.load_runtime_data();idx=g._core_slot_index(json.dumps(D['slots'],ensure_ascii=False,sort_keys=True,separators=(',',':')))
results=[]
for d in sorted((O/'fresh-inputs').iterdir()):
 if not d.is_dir():continue
 p=json.loads((d/'candidate-pack.json').read_text())[0];core=p['authorial_core'];ctl=json.loads((d/'creative_controls.json').read_text());contract,picked=g.frozen_core_context(D,core,ctl);global_query,global_fields=g.authorial_core_retrieval_text(core)
 item=dict(id=d.name,global_query=global_query,global_query_sources=global_fields,frozen_context=copy.deepcopy(contract),picked_frozen_core_projections=picked,slots={})
 item['frozen_context'].pop('_authorial_core',None)
 for slot,names in [('subject',['ceramic_potter','ceramic_artist','adult_electronic_instrument_performer']),('location',['ceramics_studio','fantasy_armor_campaign_studio','electronic_instrument_signal_studio']),('action',['ctx_function_texture_conflict','hair_tie_mid_action','prepping_workshop_materials'])]:
  queries,fields=g.core_slot_focus_queries(D,core,slot);eligible={e['id']:e for e in D['slots'][slot]if g.core_slot_entry_eligible(D,core,contract,picked,slot,e)};ids=[f'slot:{slot}:{eid}'for eid in eligible];limit=g.candidate_pack_slot_limit(slot);broad=g.rank_bm25f(idx,{'global_context':global_query},allowed_ids=ids,limit=max(12,limit*6));focals=[]
  for q in queries:
   hits=g.rank_bm25f(idx,{'slot_focus':q},allowed_ids=ids,limit=max(12,limit*6));terms=set(g.tokenize_bm25f_text(q,lexicon=idx.get('lexicon')or[]))-g.CANDIDATE_PACK_CONCEPT_STOPWORDS;hits=[r for r in hits if g.core_focal_hit_supported(idx,terms,r['document_id'])];focals.append(hits)
  named=[]
  for eid in names:
   row=next((x for x in D['slots'][slot]if x['id']==eid),None)
   if not row:continue
   document_id=f'slot:{slot}:{eid}';named.append(dict(id=eid,source=row,eligible_before_public_property_projection=eid in eligible,broad_rank=next((i+1 for i,r in enumerate(broad)if r['document_id']==document_id),None),focal_ranks=[next((i+1 for i,r in enumerate(h)if r['document_id']==document_id),None)for h in focals],admitted_candidate=next((r for r in p['slots'].get(slot,{}).get('candidates',[])if r['id']==document_id),None)))
  query_hash=hashlib.sha256(' | '.join(queries).encode()).hexdigest();expected=p['core_retrieval']['active_slots'].get(slot,{}).get('focus_query_sha256');assert query_hash==expected,(d.name,slot)
  item['slots'][slot]=dict(queries=queries,query_source_fields=fields,query_sha256=query_hash,public_query_hash_equal=True,slot_limit=limit,named_source_rows=named,broad_ids=[r['document_id']for r in broad],focal_ids=[[r['document_id']for r in h]for h in focals],diagnostic_limit='Actual unmodified helper ranking over full current corpus; rankings are not adoption proof. Full public artifacts are separate.')
 results.append(item)
(O/'named-consumer-trace.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n')
for row in results:
 print(row['id'])
 for slot,tr in row['slots'].items():print(slot,'queries',tr['queries'],'named',[(x['id'],x['eligible_before_public_property_projection'],x['broad_rank'],x['focal_ranks'],bool(x['admitted_candidate']))for x in tr['named_source_rows']])
