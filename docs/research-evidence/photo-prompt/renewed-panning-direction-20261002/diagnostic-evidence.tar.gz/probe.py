import sys,json,hashlib
from pathlib import Path
root=Path('REPOSITORY_ROOT')
out=Path(__file__).resolve().parent
sys.dont_write_bytecode=True
sys.path.insert(0,str(root/'skills/photo-prompt-image-generator/scripts'))
import prompt_generator as pg
assets=root/'skills/photo-prompt-image-generator/assets'
r=pg.load_visual_obligation_registry(assets/'photo_prompt_visual_obligations.json')
p=next(p for p in r['profiles'] if p['id']=='panning_subject_tracking_motion_relation')
# Full merged registry, fresh in-memory lexical index, no embeddings or networking.
idx=pg.build_visual_profile_index_payload(r)
base='; '.join(g['any_terms'][0] for g in p['semantics']['component_semantics']['groups'])
cases={
'exact_vertical':'A tracked-subject panning blur photograph of an adult diver moving vertically downward. Follow vertically, with vertical background streaks.',
'exact_lateral':'A tracked-subject panning blur photograph of an adult cyclist moving laterally across the frame. Follow horizontally, with horizontal background streaks.',
'ko_exact_vertical':'피사체 추적 패닝 블러 사진. 성인 다이버가 수직으로 내려가는 움직임을 따라 수직으로 패닝하며 배경도 수직 방향으로 흐른다.',
'plain_vertical':'A vertical panning photograph of an adult diver descending from a diving board, tracked sharply against vertical background streaks.',
'plain_lateral':'A horizontal panning photograph of an adult cyclist moving laterally, tracked sharply against horizontal background streaks.',
'components_lateral':base,
'components_vertical':base.replace('one lateral movement vector','one vertical movement vector'),
'slot_composition_vertical':'panning motion blur with the subject sharp; track a diver vertically downward',
'slot_motion_vertical':'panning blur following the subject; track a diver vertically downward',
}
res=[]
for name,t in cases.items():
 result={'provenance':{'concept_lock':[t]}}
 rows=pg.candidate_pack_visual_obligation_request_sources(result,{})
 resolution=pg.resolve_visual_profile_hits(r,rows,visual_profile_index=idx,adult_context=True)
 pub=pg.candidate_pack_visual_obligations({pg.VISUAL_OBLIGATIONS_DATA_KEY:r},result,{},None,visual_profile_resolution=resolution)
 res.append({'case':name,'text':t,'target_hits':[h for h in resolution['hits'] if h['profile_id']==p['id']], 'component_match':pg.candidate_pack_visual_component_match(p,t),'public_contract':pub})
(out/'current-results.json').write_text(json.dumps(res,ensure_ascii=False,indent=2))
(out/'profile-snapshot.json').write_text(json.dumps(p,ensure_ascii=False,indent=2))
(out/'source-hashes.json').write_text(json.dumps({str(f.relative_to(root)):hashlib.sha256(f.read_bytes()).hexdigest() for f in [assets/'photo_prompt_visual_obligations.json',root/'skills/photo-prompt-image-generator/scripts/prompt_generator.py',root/'tests/test_photo_capture_elements_visual_semantics.py']},indent=2))
for x in res: print(x['case'], 'hits',[(h['match_basis'],h['hard_eligible']) for h in x['target_hits']], 'component',x['component_match'],'public',[o['id'] for o in (x['public_contract'] or {}).get('obligations',[])])
