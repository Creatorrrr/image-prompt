# Source-known public CLI panning direction diagnostic

BEFORE completed successfully for all three cases on clean 56fa035716021c9129e310141a8facb4c2162126. `before/run-manifest.json` saves exact commands, source/index hashes, exit codes, durations and extracted public evidence. `before/verification.json` verifies five required panning gates and forced lateral instructions/evidence.

The English and Korean vertical adult-diver cases retain downward vertical motion in their frozen baseline and request, but their public packs require lateral tracking and a lateral-only evidence phrase. The lateral cyclist control gets the same contract without that direction contradiction. Gate descriptions themselves do not impose lateral motion; the contradiction is in the instruction/component/literal evidence bundled with the five required gates. No image was generated, and no pixel verdict is claimed.

`inputs/` holds the immutable four CLI input contracts per case; `frozen-input-manifest.json` records their exact byte hashes. `normalized/` separately retains normalized envelope/core outputs. The normal public CLI expects raw envelope/core fields and normalizes them itself. The initial attempt passing normalized envelope metadata failed before runtime loading and is retained in `rejected-normalized-cli-attempt/`, its log and corresponding rejected input directory. Those rejected inputs are not the frozen replay inputs.

All cases are source-known authored diagnostics, not independently held-out cases. Positive scene baselines and body-action reviews were authored before runtime corpus loading. No mocked calls, fabricated query vectors, model/image calls or paid APIs were used. No repository source or tests were changed.

For approved after replay run `python run_phase.py after` from any directory. It verifies every frozen input byte hash before invoking the same public CLI with seed 706; do not rerun `freeze_inputs.py` or alter any file under `inputs/`.
