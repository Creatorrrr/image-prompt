import json,hashlib
from pathlib import Path
P=Path(__file__).resolve().parent

def diff(a,b,path=''):
 if type(a)!=type(b):return [{'path':path,'before':a,'after':b}]
 if isinstance(a,dict):
  out=[]
  for k in sorted(a.keys()|b.keys()):
   if k not in a or k not in b:out.append({'path':path+'/'+k,'before':a.get(k),'after':b.get(k)})
   else:out+=diff(a[k],b[k],path+'/'+k)
  return out
 if isinstance(a,list):
  if len(a)!=len(b):return [{'path':path,'before':a,'after':b}]
  return [d for i,(x,y) in enumerate(zip(a,b)) for d in diff(x,y,path+'/'+str(i))]
 return [] if a==b else [{'path':path,'before':a,'after':b}]

def inventory(v,path=''):
 out={}
 if isinstance(v,dict):
  for k,x in v.items():out.update(inventory(x,path+'/'+k))
 elif isinstance(v,list):
  out[path]={'count':len(v),'ids':[x.get('id',x.get('profile_id',x.get('candidate_id'))) for x in v if isinstance(x,dict) and any(k in x for k in ['id','profile_id','candidate_id'])]}
  for i,x in enumerate(v):out.update(inventory(x,path+'/'+str(i)))
 return out
summary=[]
for m in json.loads((P/'frozen-input-manifest.json').read_text()):
 case=m['case']
 for name,h in m['inputs'].items():assert hashlib.sha256((P/'inputs'/case/name).read_bytes()).hexdigest()==h
 a=json.loads((P/'before'/f'{case}-pack.json').read_text())[0]; b=json.loads((P/'after'/f'{case}-pack.json').read_text())[0]
 ao=next(o for o in a['visual_obligations']['obligations'] if o['id']=='panning_subject_tracking_motion_relation');bo=next(o for o in b['visual_obligations']['obligations'] if o['id']==ao['id'])
 assert a['authorial_core']==b['authorial_core'];assert a['creative_controls']==b['creative_controls'];assert a['embodiment_preflight']==b['embodiment_preflight']
 assert ao['render_gates']==bo['render_gates'];assert ao['reject_substitutes']==bo['reject_substitutes'];assert a['visual_obligations']['required_hard_gates']==b['visual_obligations']['required_hard_gates']
 assert 'laterally' not in bo['composition_instruction'];assert bo['evidence_requirements']['pan_vector_phrase']['must_mention_any'][1:]==ao['evidence_requirements']['pan_vector_phrase']['must_mention_any']
 ag=next(g for g in ao['component_semantics']['groups'] if g['id']=='pan_vector_consistency');bg=next(g for g in bo['component_semantics']['groups'] if g['id']=='pan_vector_consistency');assert bg['any_terms'][2:]==ag['any_terms']
 changes=diff(a,b); inv=diff(inventory(a),inventory(b))
 (P/'after'/f'{case}-full-pack-diff.json').write_text(json.dumps(changes,ensure_ascii=False,indent=2)+'\n')
 (P/'after'/f'{case}-inventory-diff.json').write_text(json.dumps(inv,ensure_ascii=False,indent=2)+'\n')
 summary.append({'case':case,'inputs_byte_identical':True,'authorial_core_identical':True,'core_sha256':b['authorial_core']['canonical_sha256'],'controls_and_embodiment_identical':True,'same_five_gates':True,'same_reject_substitutes':True,'legacy_component_alternatives_retained':True,'neutral_evidence_first_legacy_retained':True,'lateral_instruction_removed':True,'pack_id_before':a['pack_id'],'pack_id_after':b['pack_id'],'changed_top_level_keys':sorted(set(c['path'].split('/')[1] for c in changes)),'diff_paths':[c['path'] for c in changes],'inventory_diff_paths':[c['path'] for c in inv]})
(P/'after/comparison.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
for s in summary:print(s['case'],s['changed_top_level_keys'],'diffs',len(s['diff_paths']),'inventory differences',len(s['inventory_diff_paths']))
