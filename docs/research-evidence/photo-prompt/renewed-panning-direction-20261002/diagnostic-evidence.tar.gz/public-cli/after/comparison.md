# Public CLI AFTER comparison

All three CLI runs exited 0 against the applied single-profile change and refreshed real index. Each original input byte hash was checked before execution. Frozen authorial cores, controls and embodiment contracts are exactly unchanged.

Both vertical adult-diver cases now receive a direction-neutral composition instruction and neutral evidence first. The legacy lateral evidence remains an alternative, and old EN/KO lateral component phrases remain after the neutral EN/KO phrases. The lateral cyclist control retains its horizontal core and can satisfy the same preserved lateral alternative. All five hard gates, their descriptions, activation aliases/exclusions and reject-substitute boundaries remain unchanged.

Full recursive public-pack comparison finds exactly six changed paths per case: pack ID; this profile's clarification definition; its fourth meaning component; its vector-component phrase array; its composition instruction; and its vector-evidence phrase array. Clarification wording is an expected public effect beyond the obligation itself. No other public-pack values changed.

Candidate inventories, membership, order and counts are unchanged across slots, optional visual concepts, semantic clarification, bundles and creative augmentation. The only changed array lengths anywhere in the packs are the vector component alternatives (2 to 4) and vector evidence alternatives (1 to 2). Pack IDs changed as expected. There are no observed unrelated public-pack changes in these three source-known cases; this is not a corpus-wide recall claim.

See `comparison.json`, per-case `*-full-pack-diff.json`, per-case `*-inventory-diff.json`, and `source-boundary-verification.json`. Exact commands, statuses and source/index hashes are in `run-manifest.json`. No inputs/tests/repository source were rewritten, and no model, image, embedding or other paid calls were used during this replay.
