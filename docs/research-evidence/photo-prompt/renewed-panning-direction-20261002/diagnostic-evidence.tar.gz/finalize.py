from pathlib import Path
import json,copy,hashlib
out=Path(__file__).resolve().parent
root=Path('REPOSITORY_ROOT')
p=json.loads((out/'profile-snapshot.json').read_text())
n=copy.deepcopy(p)
neutral='background streaks subject travel and local motion cues agree on one coherent image-plane movement direction'
neutral_ko='배경 스트리크 피사체 이동과 국소 움직임 단서가 영상 평면에서 하나의 일관된 이동 방향에 일치함'
n['semantics']['definition']=n['semantics']['definition'].replace('a laterally moving subject','a moving subject along its image-plane path, whether horizontal, vertical, or diagonal')
n['composition_instruction']=n['composition_instruction'].replace('Track one clearly moving subject laterally during a slow exposure.', 'Track one clearly moving subject along its requested image-plane path during a slow exposure, preserving horizontal, vertical, or diagonal travel as specified.')
n['semantics']['paraphrase_examples'].append('an adult diver descending vertically remains comparatively readable as the camera follows the descent and background texture streaks vertically')
g=next(g for g in n['semantics']['component_semantics']['groups'] if g['id']=='pan_vector_consistency')
g['any_terms'].extend([neutral,neutral_ko])
n['evidence_requirements']['pan_vector_phrase']['must_mention_any'].insert(0,neutral)
n['concept_candidate']['concept_terms']=[x.replace('single lateral travel vector','single coherent image-plane travel direction') for x in n['concept_candidate']['concept_terms']]
(out/'proposed-profile.json').write_text(json.dumps(n,ensure_ascii=False,indent=2)+'\n')
assets=root/'skills/photo-prompt-image-generator/assets'
(out/'completion-hashes.json').write_text(json.dumps({str(f.relative_to(root)):hashlib.sha256(f.read_bytes()).hexdigest() for f in [assets/'photo_prompt_visual_obligations.json',assets/'photo_prompt_visual_profile_index.json']},indent=2)+'\n')
assert all(x in g['any_terms'] for x in p['semantics']['component_semantics']['groups'][3]['any_terms'])
assert len(neutral.split())>=13
