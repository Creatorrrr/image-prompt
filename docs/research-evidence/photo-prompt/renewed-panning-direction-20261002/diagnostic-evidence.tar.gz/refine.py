import sys,json,copy,unittest
from pathlib import Path
sys.dont_write_bytecode=True
out=Path(__file__).resolve().parent
root=Path('REPOSITORY_ROOT')
sys.path.insert(0,str(root/'skills/photo-prompt-image-generator/scripts'))
import prompt_generator as pg
from audit_composed_prompt import authorial_evidence_tokens
p=json.loads((out/'profile-snapshot.json').read_text()); n=copy.deepcopy(p)
neutral='background streaks subject travel and local motion cues remain coherent with the tracked movement direction throughout the exposure'
ko='배경 스트리크 피사체 이동과 국소 움직임 단서가 노출 동안 추적하는 이동 방향과 일관된 관계를 유지함'
n['semantics']['definition']=n['semantics']['definition'].replace('a laterally moving subject','a moving subject')
n['composition_instruction']=n['composition_instruction'].replace('subject laterally during','subject along its direction of travel during')
n['concept_candidate']['concept_terms']=[x.replace('single lateral travel vector','single coherent travel direction') for x in n['concept_candidate']['concept_terms']]
g=next(g for g in n['semantics']['component_semantics']['groups'] if g['id']=='pan_vector_consistency'); g['any_terms']=[neutral,ko]+g['any_terms']
req=n['evidence_requirements']['pan_vector_phrase']; req['must_mention_any']=[neutral]+req['must_mention_any']
(out/'proposed-profile.json').write_text(json.dumps(n,ensure_ascii=False,indent=2)+'\n')
assert n['semantics']['paraphrase_examples']==p['semantics']['paraphrase_examples']
tokens=sorted(authorial_evidence_tokens(neutral)); assert len(tokens)>=req['min_content_words']
pg.validate_visual_intent_binding(obligation_index=0,field='pan_vector_phrase',phrase=neutral,requirement=req)
r=pg.load_visual_obligation_registry(root/'skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations.json')
r=copy.deepcopy(r); r['profiles']=[n if x['id']==p['id'] else x for x in r['profiles']]
# Target-only index avoids unrelated retrieval work; all public functions remain real.
r={**r,'profiles':[n]}; idx=pg.build_visual_profile_index_payload(r)
checks=[]
for label,profile in [('old_lateral',p),('new_neutral',n)]:
 for lang in [0,1]:
  text='; '.join(g['any_terms'][lang] for g in profile['semantics']['component_semantics']['groups'])
  if label=='new_neutral': text+='; adult diver moves vertically downward' if lang==0 else '; 성인 다이버가 수직으로 내려간다'
  assert pg.candidate_pack_visual_component_match(n,text)=='component_semantics'
  for e in n['activation']['exclude_if_any_terms']:
   assert pg.candidate_pack_visual_component_match(n,text+'; '+e) is None
  for missing in range(5):
   incomplete='; '.join(g['any_terms'][lang] for i,g in enumerate(profile['semantics']['component_semantics']['groups']) if i!=missing)
   assert pg.candidate_pack_visual_component_match(n,incomplete) is None
  checks.append({'case':label,'language':lang,'text':text,'match':'component_semantics','exclusions_passed':4,'missing_groups_passed':5})
contracts=[]
for axis in ['vertical','lateral']:
 text='tracked-subject panning blur photograph; an adult subject moves '+axis
 result={'provenance':{'concept_lock':[text]}}
 resolution=pg.resolve_visual_profile_hits(r,pg.candidate_pack_visual_obligation_request_sources(result,{}),visual_profile_index=idx,adult_context=True)
 contract=pg.candidate_pack_visual_obligations({pg.VISUAL_OBLIGATIONS_DATA_KEY:r},result,{},None,visual_profile_resolution=resolution)
 assert len(contract['obligations'])==1
 o=contract['obligations'][0]
 assert 'laterally' not in o['composition_instruction']
 assert o['evidence_requirements']['pan_vector_phrase']['must_mention_any'][0]==neutral
 contracts.append({'axis':axis,'request':text,'public_contract':contract})
for text in ['vertical panning','horizontal panning','motion blur','panning motion blur with the subject sharp','panning blur following the subject']:
 resolution=pg.resolve_visual_profile_hits(r,[{'source':'concept_lock','text':text,'polarity':'required','priority':'critical','mandatory':True}],visual_profile_index=idx,adult_context=True)
 assert not any(h['hard_eligible'] for h in resolution['hits'])
(out/'refined-results.json').write_text(json.dumps({'neutral_evidence_tokens':tokens,'neutral_evidence_count':len(tokens),'unchanged_floor':req['min_content_words'],'checks':checks,'contracts':contracts,'broad_negative_controls':5},ensure_ascii=False,indent=2)+'\n')
print('Neutral content tokens:',len(tokens),tokens,'floor:',req['min_content_words'])
print('Four bilingual complete component controls, 16 exclusions, 20 missing groups, two public exact projections, five broad negatives: PASS')
# Reuse the unchanged existing capture tests, substituting only proposal data in memory.
sys.path.insert(0,str(root/'tests'))
import test_photo_capture_elements_visual_semantics as fixture
T=fixture.PhotoCaptureElementsVisualSemanticsTests
T.setUpClass()
T.profiles[p['id']]=n
T.routing_registry['profiles']=[n if x['id']==p['id'] else x for x in T.routing_registry['profiles']]
for name in ['test_semantic_panning_paraphrase_projects_optional_candidate_only','test_three_arm_render_fixture_is_hash_bound_and_fail_closed']:
 t=T(name); getattr(t,name)(); print('Existing fixture PASS:',name)
