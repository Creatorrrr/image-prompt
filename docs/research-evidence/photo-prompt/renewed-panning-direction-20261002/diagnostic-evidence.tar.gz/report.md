# Panning direction audit — confirmed DATA scope mismatch

## Decision
Repair the direction constraint within `panning_subject_tracking_motion_relation`; do not rewrite general panning slot entries or adjacent motion effects. Current aliases and runtime labels identify tracked-subject blur without any lateral subtype qualifier. The source supports vertical tracking. The existing narrow slow-exposure/readable-core treatment can stay narrow: this audit does not expand it to every use of camera panning.

## Reproduced current behavior
`probe.py` uses the actual merged registry, an in-memory freshly built non-embedding index, actual `resolve_visual_profile_hits`, and actual public `candidate_pack_visual_obligations`. It does not patch source or mock matching. Query fields/vectors are omitted: these are exact-route diagnostics plus direct component-matcher diagnostics, not claims about full semantic retrieval recall.

- Exact English alias plus explicit downward vertical diver travel: hard eligible; public hard contract emitted
- Exact Korean alias plus explicit vertical descent: same result
- Exact English alias plus horizontal cyclist control: same result
- All three public contracts require “Track one clearly moving subject laterally” and the literal evidence anchor ending “one lateral movement vector”
- Plain vertical and horizontal panning language: neither hard-activates
- Existing complete lateral component text: `component_semantics` match; replacing only “lateral” with “vertical”: no component match
- Both general panning slot labels, with explicit vertical movement: no hard activation

Full inputs, resolver hits and public contracts are in `current-results.json`; compact output is in `run.log`. Four existing `test_photo_capture_boundary_data.py` tests pass (`boundary-tests.log`). No image-quality claim follows from these local data tests.

## Source and interpretation
Primary source: Nikon / Dave Black, [10 Tips for Better Camera Panning](https://www.nikonusa.com/learn-and-explore/c/tips-and-techniques/10-tips-for-better-camera-panning), read October 2, 2026. Its introduction says horizontal panning is common and explicitly includes vertical tracking of a diver descending from board to water. Later sections distinguish slow-shutter blur from fast-shutter action freezing, and discuss sharp elements and secondary-part blur.

Existing project source-research.md (capture-elements-visual-semantics-20260902) cites this same Nikon article. Its summary describes coherent motion without claiming a horizontal-only contract. The evidence therefore supports removing an accidental direction restriction, not redesigning panning.

Optical caveat: screen-space streak orientation is an axis, not necessarily a signed physical velocity vector. Rotating wheels/articulated limbs can have local directions that differ from the tracked core. Camera rotation, perspective and scene depth can produce curved/nonparallel flow. Nikon's vertical example alone does not validate changing all current parallel-streak or single-vector gates, nor does it establish a rigorous projection model. Preserve the existing coherent directional-background subtype for this patch and defer those separate questions rather than changing every panning effect by analogy.

## Refined minimal DATA proposal
`proposed-profile.json` is a review artifact outside the repository, not an applied patch. `refine.py` supersedes the initial `finalize.py` proposal builder.

1. Remove “laterally” from the definition; composition tracks the subject along its direction of travel, with no new technical projection requirement
2. Replace the lateral-only concept term with “single coherent travel direction”
3. Leave every existing paraphrase unchanged; do not add a vertical paraphrase shortcut
4. Put neutral English/Korean alternatives FIRST in the vector component, preserving both original lateral alternatives afterward
5. Put the neutral English evidence anchor FIRST, preserving the old lateral anchor afterward; keep the 13-content-word minimum unchanged
6. Keep slots, profile/field/gate IDs, other profiles, exclusions, thresholds and engine unchanged; refresh derived index through the established process when approved

Neutral evidence: “background streaks subject travel and local motion cues remain coherent with the tracked movement direction throughout the exposure”. `refine.py` checks it with actual `authorial_evidence_tokens` and actual `validate_visual_intent_binding`, rather than whitespace counting. Complete neutral components can accompany an explicit vertical scene description in the authorial core without making vertical direction a requirement for lateral requests.

`refined-results.json` stores bilingual old-lateral/new-neutral component checks, missing-group and exclusion checks, actual vertical/lateral public contract projections and broad negative controls. `refine.log` records the token count and unchanged existing capture fixture checks. These are in-memory proposal checks; no repository source/test change or paid execution occurred. The original full-registry current-behavior evidence remains unchanged in `current-results.json`.

## Provenance and limits
This was a read-only repository audit amid separate lighting/composition edits. `source-hashes.json` records actual source/test hashes at probe time; `profile-snapshot.json` preserves the exact audited panning data. Do not describe the whole working tree as a clean a21a08cb baseline. Parent confirms panning itself was unchanged while lighting changes were pending. At completion main HEAD was 56fa035716021c9129e310141a8facb4c2162126 with clean status; `completion-hashes.json` records current source and derived index hashes. The generated index at probe time was in memory; the checked-in index was not used for these diagnostics. No repository source/test edits, paid API, model, image, or embedding calls were made. Rebase the proposal against the parent's eventual clean tip before applying.
