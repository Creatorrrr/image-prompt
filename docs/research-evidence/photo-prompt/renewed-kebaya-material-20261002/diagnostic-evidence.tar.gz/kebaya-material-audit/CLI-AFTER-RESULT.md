# Actual AFTER public CLI and complete-composition result

All six frozen cases pass normal public candidate-pack generation against the live approved source and genuine refreshed index. Source profile equals `proposed-profile.json` exactly, all input hashes match BEFORE, seed remains 709, and observed source hashes remain stable during execution. No source edits or provider calls were made by this worker. BEFORE files were not overwritten.

## Exact complete-pack comparison

Every case has exactly three changed JSON paths:

1. `/pack_id`
2. `/visual_obligations/obligations/0/component_semantics/groups/1/any_terms`
3. `/visual_obligations/obligations/0/evidence_requirements/embroidered_surface_phrase/must_mention_any`

The latter two append only the independently approved plain fine-cloth anchor. All 30 candidate collections per case are identical as parsed JSON: counts, IDs, ordering and all records unchanged. No added, removed or changed candidates. All remaining full-pack fields are unchanged, including original user scene, core, front-opening construction, regional limits, required fields, gates, fastening alternatives, Korean terms and separate-sarong boundary.

## Complete composed-prompt audit

Six actual `audit_composed_prompt.py` CLI runs exit 0 with `status: pass` and zero failures. Each composed prompt preserves the original frozen baseline verbatim, adding five distinct literal evidence phrases describing the same ensemble, specific textile and selected fastening. Both closure variants are exercised for all three textiles. No body/pose/exposure or new material taxonomy is introduced into the profile.

Cross-checking those exact evidence phrases against immutable BEFORE obligations yields exactly one material-anchor failure for each plain fine-cloth case; the four embroidered/lace controls already pass. All six AFTER focused obligation audits pass.

Each full audit reports three disclosed `uncovered_intent` warnings indicating preservation through free description/assertion: the adult subject, standing studio scene, and specified blouse opening/fastening. They are not failures, and original text remains present. These results establish contract and composition consistency, not generated-image or pixel quality.

Live index validation succeeds. Independently inspected index entries show only the kebaya entry changed, with 1,495 other entries unchanged. This worker reused the parent’s genuine index and did not generate vectors.

## Evidence locations

- `public-cli/after/run-manifest.json`: exact commands, return codes, source/input/output hashes, actual obligations
- `public-comparison/summary.json`: all-case full comparison
- `public-comparison/*-full-pack-differences.json`: exact changed paths and values
- `public-comparison/*-candidate-inventory.json`: complete candidate inventory
- `after-evidence/*-complete-composed.json`: complete original-scene-preserving prompts
- `after-evidence/*-complete-audit.json`: actual audit CLI results
- `after-evidence/full-composition-summary.json`: six results, warnings, BEFORE/AFTER focused comparison
- `after-evidence/source-verification.json`: genuine loader/index and stable-source verification
- `run_public_after.py`, `compare_public.py`, `verify_after_composition.py`: reproduction scripts
