import json,sys,hashlib,copy,subprocess
from pathlib import Path
sys.dont_write_bytecode=True
O=Path(__file__).resolve().parent;R=O.parent.parent/'image-prompt';A=R/'skills/photo-prompt-image-generator/assets';P=O/'public-cli';P.mkdir(exist_ok=True)
sys.path.insert(0,str(A.parent/'scripts'));import prompt_generator as pg
save=lambda p,x:(p.parent.mkdir(parents=True,exist_ok=True),p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n'))
sha=lambda s:hashlib.sha256(s.encode()).hexdigest()
reg=pg.load_visual_obligation_registry(A/'photo_prompt_visual_obligations.json');pg.load_visual_profile_index(A/'photo_prompt_visual_profile_index.json',reg)
old=next(x for x in reg['profiles'] if x['id']=='kebaya_front_open_blouse_sarong_system');new=copy.deepcopy(old)
anchor='fine lightweight cloth retains visible weave and finished front edges'
group=next(x for x in new['semantics']['component_semantics']['groups'] if x['id']=='surface_and_edge_finish');group['any_terms'].append(anchor)
new['evidence_requirements']['embroidered_surface_phrase']['must_mention_any'].append(anchor)
leaves=[{'path':'/semantics/component_semantics/groups/1/any_terms','before':old['semantics']['component_semantics']['groups'][1]['any_terms'],'after':group['any_terms']},{'path':'/evidence_requirements/embroidered_surface_phrase/must_mention_any','before':old['evidence_requirements']['embroidered_surface_phrase']['must_mention_any'],'after':new['evidence_requirements']['embroidered_surface_phrase']['must_mention_any']}]
save(O/'before-profile.json',old);save(O/'proposed-profile.json',new);save(O/'exact-changed-leaves.json',leaves)
scaffold=json.loads((O.parent/'garment-closure-alternative-audit/public-cli/inputs/front-overlap-control/authorial-core.json').read_text());manifest=[]
for material,matphrase in [('plain','fine lightweight cloth retains visible weave and finished front edges'),('embroidered','fine embroidered voile with finished scalloped edges'),('lace','lightweight lace or embroidered cloth retains visible weave')]:
 for fastening,fastphrase in [('buttons','buttons visibly bridge the two front edges'),('kerongsang','a linked kerongsang brooch set fastens the center')]:
  case=material+'-'+fastening;d=P/'inputs'/case
  req=f'Photograph one adult wearing a shaped front-opening kebaya blouse with a separate wrapped sarong. The blouse textile is {matphrase}; {fastphrase}. Show the front opening, textile finish, functional fastening and distinct upper/lower layer boundary together, preserving the regional form.'
  subject='One adult';event='stands steadily to display the kebaya ensemble construction'
  start='One adult stands steadily in a daylight garment studio with both feet planted beneath the body.'
  concept=f'The shaped front-opening kebaya blouse has two visible front edges, and {fastphrase}.'
  arms='The arms hang relaxed beside the torso with continuous shoulders, elbows and wrists; the hands remain clear of the garment fastenings.'
  view='A clear camera view includes the blouse front and the separate wrapped lower garment, with both front edges and the blouse hem visible.'
  balance='The full adult body remains balanced and anatomically continuous, with the garment drape responding to gravity.'
  textile='The blouse textile is described precisely: '+matphrase+'.'
  base=' '.join([start,concept,textile,'A distinct wrapped sarong forms the lower garment, and the blouse hem and sarong boundary remain visible.','The center fastening physically holds the two front edges together as a functional closure, with the finished edges traceable into the upper garment.',arms,view,'Soft daylight makes the textile weave, edge finishing and layer boundaries legible without hiding the construction.','Regional length, fit and ornament remain coherent; garment construction does not imply wearer ethnicity or identity.','The connected upper and lower ensemble is shown together, and no isolated decorative detail substitutes for its opening, fastening or separate lower layer.',balance])
  envraw={'contract_version':'photo-request-envelope/v1','provenance':'requesting_user','request_id':'kebaya-'+case,'request_text':req,'request_sha256':sha(req),'active_spans':[{'span_id':'scene','start':0,'end':len(req),'text':req}]};env=pg.normalize_request_envelope(envraw)
  ctl=pg.creative_controls.resolve(req,overrides={'sensual':0,'fetish':0,'creativity':1,'surreal':0},seed=709)
  core=copy.deepcopy(scaffold);core.update(source_request=req,creative_controls_sha256=ctl['canonical_sha256'],interpreted_intent=req,subject=subject,setting='a daylight garment studio',event=event,visual_priorities=[subject,event,'visible front opening, textile finish, center fastening and separate sarong'],baseline_prompt_en=base,interpretation_provenance=[{'term':'governing request','source_text':req,'basis':'request_context','resolution':req,'sources':[]}],style={'domain':'general_photo','family':'garment construction photograph','evidence':['kebaya','front opening','sarong']},variation_key='kebaya-'+case)
  core['intent_lock']['semantic_anchors']=[{'anchor_id':'subject','source_text':req,'dimension':'subject','prompt_evidence':subject},{'anchor_id':'event','source_text':req,'dimension':'event','prompt_evidence':start},{'anchor_id':'concept','source_text':req,'dimension':'concept','prompt_evidence':concept}]
  norm=pg.normalize_authorial_core(core,request_envelope=env,creative_control_snapshot=ctl)
  ev={'body_ownership':('One adult owns the continuous body and limbs.',balance),'joint_chain_and_reach':('Arms have continuous joint chains.',arms),'support_and_balance':('Both planted feet support the body.',start),'contact_and_space':('Visible center fastening connects the garment front edges.',concept),'visibility_and_projection':('Both front edges and the upper/lower boundary remain visible.',view)}
  review={'contract_version':'photo-embodiment-review/v1','provenance':'agent_prepack','prompt_sha256':sha(base),'scope':'body_action','summary':'Synthetic text-only garment construction fixture; no pixel proof or new profile pose restriction.','checks':{k:{'status':'supported','reason':v[0],'prompt_evidence':[v[1]]} for k,v in ev.items()}}
  pg.photo_embodiment.build_policy(norm,review)
  for name,x in [('request-envelope',envraw),('authorial-core',core),('creative-controls',ctl),('embodiment-review',review)]:save(d/(name+'.json'),x)
  manifest.append({'case':case,'target_profile':old['id'],'seed':709,'inputs':{f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(d.glob('*.json'))}})
save(P/'frozen-input-manifest.json',manifest)
files=[*A.glob('*.json'),*(A.parent/'scripts').glob('*.py')]
save(P/'before-source-manifest.json',{'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'status':subprocess.check_output(['git','status','--short'],cwd=R,text=True),'execution':'Normal public CLI BEFORE kebaya proposal, after stable wrap-skirt working-tree refresh, publication may be pending; frozen six synthetic four-contract fixtures, no repository edits or provider calls. Adult/standing fixture details are not proposed profile conditions.','sha256':{str(f.relative_to(R)):hashlib.sha256(f.read_bytes()).hexdigest() for f in files}})
print('Frozen six cases.')
