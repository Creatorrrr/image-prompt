import sys,json,copy,hashlib,subprocess
from pathlib import Path
sys.dont_write_bytecode=True
O=Path(__file__).resolve().parent
R=O.parent.parent/'image-prompt'
S=R/'skills/photo-prompt-image-generator/scripts'
A=S.parent/'assets'
sys.path.insert(0,str(S))
import prompt_generator as pg
save=lambda n,v:(O/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
raw=json.loads((A/'photo_prompt_visual_obligations.json').read_text())
p=next(x for x in raw['profiles'] if x['id']=='kebaya_front_open_blouse_sarong_system')
q=copy.deepcopy(p)
anchor='fine lightweight cloth retains visible weave and finished front edges'
q['evidence_requirements']['embroidered_surface_phrase']['must_mention_any'].append(anchor)
next(g for g in q['semantics']['component_semantics']['groups'] if g['id']=='surface_and_edge_finish')['any_terms'].append(anchor)
save('before-profile.json',p)
save('proposed-profile.json',q)
rows=[]
for label,profile in [('before',p),('proposal_in_memory_only',q)]:
    obligation=pg.candidate_pack_visual_profile_obligation(profile,raw,activation_source='explicit_user_requirement',source_intent_ids=[])
    save(label+'-public-obligation.json',obligation)
    cases={
      'plain_fine_cloth':('embroidered_surface_phrase',anchor),
      'embroidered_existing':('embroidered_surface_phrase','fine embroidered voile with finished scalloped edges'),
      'lace_existing':('embroidered_surface_phrase','lightweight lace or embroidered cloth retains visible weave'),
      'generic_cloth_negative':('embroidered_surface_phrase','plain clothing with decorative styling'),
      'buttons_existing':('center_fastening_phrase','buttons visibly bridge the two front edges'),
      'kerongsang_existing':('center_fastening_phrase','a linked kerongsang brooch set fastens the center'),
      'no_fastening_negative':('center_fastening_phrase','decorative jewelry lies above the closed blouse'),
      'sarong_existing':('sarong_layer_phrase','a distinct wrapped sarong forms the lower garment'),
      'jeans_negative':('sarong_layer_phrase','denim jeans extend beneath the blouse')}
    for case,(field,phrase) in cases.items():
      try:
        pg.validate_visual_intent_binding(obligation_index=0,field=field,phrase=phrase,requirement=obligation['evidence_requirements'][field]);result='pass'
      except ValueError as e: result=str(e)
      rows.append({'state':label,'case':case,'field':field,'phrase':phrase,'result':result})
    texts={
      'plain_complete':'shaped front-opening blouse; '+anchor+'; readable center-front fastening; separate wrapped lower cloth',
      'embroidered_complete':'shaped front-opening blouse; embroidered voile; readable center-front fastening; separate wrapped lower cloth',
      'plain_without_fastening':'shaped front-opening blouse; '+anchor+'; separate wrapped lower cloth',
      'plain_without_lower':'shaped front-opening blouse; '+anchor+'; readable center-front fastening',
      'generic_lace_excluded':'generic lace blouse; shaped front-opening blouse; '+anchor+'; readable center-front fastening; separate wrapped lower cloth'}
    for case,text in texts.items():rows.append({'state':label,'component_case':case,'text':text,'result':pg.candidate_pack_visual_component_match(profile,text)})
save('consumer-controls.json',rows)
bt=pg.visual_profile_semantic_text(p);qt=pg.visual_profile_semantic_text(q)
save('semantic-text-impact.json',{'positive_semantic_text_changed':bt!=qt,'bm25f_fields_changed':pg.visual_profile_bm25f_fields(p)!=pg.visual_profile_bm25f_fields(q),'provider_calls':0,'fake_vectors':False})
save('provenance.json',{'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'profile_sha256':hashlib.sha256(json.dumps(p,sort_keys=True).encode()).hexdigest(),'note':'Only target profile captured; in-flight unrelated repository changes not frozen. All artifacts outside repository.'})
print(json.dumps(rows,indent=2))
