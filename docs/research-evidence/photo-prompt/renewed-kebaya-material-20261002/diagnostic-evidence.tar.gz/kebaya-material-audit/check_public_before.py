import json,sys,hashlib
from pathlib import Path
sys.dont_write_bytecode=True
O=Path(__file__).resolve().parent;R=O.parent.parent/'image-prompt';sys.path.insert(0,str(R/'skills/photo-prompt-image-generator/scripts'));import prompt_generator as pg
P=O/'public-cli';m=json.loads((P/'before/run-manifest.json').read_text());rows=[]
for c in m['cases']:
 case=c['case'];pack=json.loads((P/'before'/(case+'-pack.json')).read_text())[0]
 ob=next(x for x in pack['visual_obligations']['obligations'] if x['id']=='kebaya_front_open_blouse_sarong_system')
 mat={'plain':'fine lightweight cloth retains visible weave and finished front edges','embroidered':'fine embroidered voile with finished scalloped edges','lace':'lightweight lace or embroidered cloth retains visible weave'}[case.split('-')[0]]
 fast='buttons visibly bridge the two front edges' if case.endswith('buttons') else 'a linked kerongsang brooch set fastens the center'
 checks=[]
 for f,phrase in [('embroidered_surface_phrase',mat),('center_fastening_phrase',fast)]:
  try:pg.validate_visual_intent_binding(obligation_index=0,field=f,phrase=phrase,requirement=ob['evidence_requirements'][f]);outcome='pass'
  except ValueError as e:outcome=str(e)
  checks.append({'field':f,'phrase':phrase,'outcome':outcome})
 rows.append({'case':case,'public_cli_exit_code':c['exit_code'],'source_hashes_unchanged':c['source_hashes_unchanged'],'obligation_ids':c['obligation_ids'],'actual_public_obligation_binding_checks':checks})
assert len(rows)==6
assert all(r['public_cli_exit_code']==0 and r['source_hashes_unchanged'] for r in rows)
assert all((r['actual_public_obligation_binding_checks'][0]['outcome']=='pass') != r['case'].startswith('plain') for r in rows)
assert all(r['actual_public_obligation_binding_checks'][1]['outcome']=='pass' for r in rows)
(P/'before/public-controls.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps(rows,indent=2))
