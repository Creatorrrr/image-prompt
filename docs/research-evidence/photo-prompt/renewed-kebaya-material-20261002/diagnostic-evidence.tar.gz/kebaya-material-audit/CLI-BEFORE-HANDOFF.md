# Independent review handoff

- Exact proposal: `before-profile.json`, `proposed-profile.json`, `exact-changed-leaves.json` (two append-only arrays)
- Six immutable fixture sets: `public-cli/inputs/`, hashes in `public-cli/frozen-input-manifest.json`
- Actual baseline: `public-cli/before-source-manifest.json`, wrap-skirt-refreshed working tree before kebaya modification
- Public CLI execution, commands, return codes, output hashes, actual obligations and source stability: `public-cli/before/run-manifest.json`
- Actual emitted obligation binding checks: `public-cli/before/public-controls.json`
- Reproduction: `prepare_public_before.py` prepares inputs and should NOT be rerun after source mutation if preserving this baseline; `run_public_before.py` verifies frozen source/input hashes; `check_public_before.py` checks actual emitted obligations
- Existing in-memory proposal probes: `prove.py`, `consumer-controls.json`
- All six public CLI runs succeeded, target only; both plain variants fail material evidence before, embroidered/lace controls pass, both closure alternatives pass
- After any authorized implementation, reuse the six frozen inputs and record a distinct AFTER source manifest; do not overwrite BEFORE outputs or invent embeddings
