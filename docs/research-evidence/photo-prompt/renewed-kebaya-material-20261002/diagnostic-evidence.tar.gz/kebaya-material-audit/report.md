# Kebaya material alternative audit

Read-only audit, 2026-10-02. Repository HEAD observed: b85dcbca17156526e0a61b24e34a2c77829c06aa. No repository edits, providers, rendered images, fake embeddings, or index snapshots. Only one profile was captured outside the repository. Unrelated wrap-skirt work may be in flight.

## Finding and one minimal proposal

**Genuine internal alternative collapse, not evidence of a deliberately narrow regional embroidery-only style.** The complete current `kebaya_front_open_blouse_sarong_system` profile defines embroidered, lace, **or lightweight cloth** alternatives. Its composition explicitly leaves ornament variable, and native gate `vo_kebaya_textile_edge_finish` permits fine cloth weave or another finished edge treatment. The profile has no named regional embroidery-only restriction. Its source-research matrix likewise explicitly includes light cloth. Nevertheless, mandatory `embroidered_surface_phrase` permits only two literal anchors, both requiring embroidery or lace language. Its component lexicon encodes light cloth inside a single concatenated alternative phrase, which does not match a plain fine-cloth description in the actual consumer.

**Proposal:** append the same precise anchor, `fine lightweight cloth retains visible weave and finished front edges`, to these two existing arrays in `skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations.json`:

1. `profiles[id=kebaya_front_open_blouse_sarong_system].semantics.component_semantics.groups[id=surface_and_edge_finish].any_terms`
2. `profiles[id=kebaya_front_open_blouse_sarong_system].evidence_requirements.embroidered_surface_phrase.must_mention_any`

This is one aligned alternative repair, not two taxonomy expansions. Keep existing anchors and the legacy field identifier. Do not rename the field, lower its minimum word count, remove textile/edge evidence, or alter any other leaf. `before-profile.json` and `proposed-profile.json` contain the exact small proposal; `prove.py` recreates it in memory only.

## Source provenance and limits

- Repository `docs/research-evidence/photo-prompt/traditional-clothing-20260831/source-research.md`, Kebaya matrix row: fine embroidered/lace/light cloth, front opening, fastening, separate wrapped lower layer. Broader research scope separates garment construction from wearer identity and warns against generic regional styling.
- Same directory `evidence.jsonl`, record `traditional_clothing_unesco_kebaya`: regional variation in length, opacity, fit and fastening; lace/translucency/brooch/sarong alone insufficient.
- Primary source checked 2026-10-02: [UNESCO ICH nomination record 02090](https://ich.unesco.org/en/RL/kebaya-knowledge-skills-traditions-and-practices-02090). Direct open returned a JavaScript/human-verification page; no challenge was solved. The web search index returned the substantive primary-source text. It describes embroidery as frequent, front opening, brooch/button fasteners, variable lengths, and a possible matching sarong. The [UNESCO committee decision](https://ich.unesco.org/en/Decisions/19.COM/7.b.26) indexed text corroborates these points. Neither is treated as proof that all kebayas share one textile, cut, opacity, or ensemble.
- The plain fine-lightweight-cloth wording is justified primarily by this repository's already-authored definition and gate. The retrieved UNESCO summary supports non-universality of embroidery; it does **not** independently establish a detailed fabric taxonomy or universal mandatory sarong. The existing scoped blouse-plus-sarong profile remains intentionally narrower than all kebaya practice.

## Actual consumer proof

Executed the production functions from `scripts/prompt_generator.py`, with bytecode disabled, no providers, and no repository writes:

- `candidate_pack_visual_profile_obligation`: materialized the actual public obligation for before/proposal profiles, preserving evidence requirements and all gates. Saved as `before-public-obligation.json` and `proposal_in_memory_only-public-obligation.json`.
- `validate_visual_intent_binding`: fine lightweight cloth with visible weave and finished edges fails the before requirement and passes the proposed one. Existing embroidered and lace anchors pass both. Both buttons and kerongsang still pass; closed blouse with decorative jewelry and jeans in lieu of the lower wrap remain rejected by their respective evidence fields. Generic clothing/styling fails material evidence in both.
- `candidate_pack_visual_component_match`: the complete plain-cloth component description returns no match before and `component_semantics` after; this is advisory eligibility, **not hard activation**. Existing embroidered complete construction matches both. Missing fastening, missing separate lower layer, and the excluded generic lace blouse do not match in either state.
- `consumer-controls.json` contains all 28 results. These are actual consumer function tests, not full public-CLI generation or rendered-image validation. The independent composed-prompt auditor also checks declared anchors (`audit_composed_prompt.py`, around lines 1800–1813); its behavior was read, not executed in this audit.

## Keep / defer

KEEP the front-opening shaped construction; separate sarong/lower-wrap and visible layer boundary; functional buttons **or** kerongsang; all five required evidence fields; minimum four required component groups; all five gates; regional length/opacity/fit/material caveats; existing exclusions and reject substitutes. Add no person, age, ethnicity, pose, or exposure condition. Do not change the native textile gate, which already allows this alternative.

DEFER broadening the category to every kebaya style or removing the sarong relation: neither follows from this defect. The slot's embedding text and concept-candidate wording emphasize embroidered/lace material, but they are not evidence of an intentional regional restriction and are outside this minimal hard-contract repair. Keep those existing leaves rather than expanding the proposal without independent retrieval testing.

If accepted, add focused regressions and perform the established real index refresh. The actual production semantic text and BM25F field functions both change under the two-leaf proposal (`semantic-text-impact.json`), so derived retrieval/index artifacts need proper provenance refresh with genuine provider outputs where required. No simulated vectors or hand-edited vector state are supplied. No claim of rendered quality improvement is made.

## Frozen normal public CLI BEFORE follow-through (20:56 UTC)

Completed six normal `generate_photo_prompt.py` runs using frozen request-envelope, authorial-core, creative-controls and embodiment-review inputs, seed 709. Cases cross plain fine cloth, existing embroidered voile and existing lace wording with both buttons and kerongsang. All six CLI runs exited 0 and activated only the target kebaya profile. This is expected: the defect is the emitted hard evidence contract, not inability to generate a candidate pack. Each actual emitted obligation still rejects the plain-cloth evidence while accepting embroidered/lace evidence; both fastenings pass in all cases. These emitted-obligation checks are in `public-cli/before/public-controls.json` and are reproducible with `check_public_before.py`.

Baseline distinction: HEAD was still `b85dcbca17156526e0a61b24e34a2c77829c06aa`, with the already-refreshed wrap-skirt source/index and its regression test present as working-tree changes. Thus this is BEFORE the kebaya proposal, **after** the stable wrap-skirt working-tree refresh, not a clean-HEAD or pre-wrap baseline. `public-cli/before-source-manifest.json` records HEAD, status and hashes for source assets/scripts; `frozen-input-manifest.json` records all input hashes. All captured source hashes remained unchanged during all six runs. No source was edited by this audit.

`exact-changed-leaves.json` now records both complete before/after arrays. All pre-existing Korean alternatives are unchanged. Fixture-specific adult/standing details provide stable normal-CLI inputs only; they introduce no proposed person, pose or exposure condition. No new material taxonomy was added. Outputs are public candidate packs, not vectors or repository snapshots. The exact proposal and all original keep/defer limits remain unchanged.
