import json,sys,hashlib,copy,subprocess,os
from pathlib import Path
sys.dont_write_bytecode=True
O=Path(__file__).resolve().parent; A=O.parent/'kebaya-material-audit'; R=O.parent.parent/'image-prompt'; S=R/'skills/photo-prompt-image-generator/scripts';sys.path.insert(0,str(S));import prompt_generator as pg
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(n,v):(O/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
b=read(A/'before-profile.json');p=read(A/'proposed-profile.json');raw=read(S.parent/'assets/photo_prompt_visual_obligations.json');assert next(x for x in raw['profiles'] if x['id']==b['id'])==b
leaves=[]
def diff(x,y,path=''):
 if x==y:return
 if isinstance(x,dict) and isinstance(y,dict):
  assert x.keys()==y.keys()
  for k in x:diff(x[k],y[k],path+'/'+k)
 elif isinstance(x,list) and isinstance(y,list) and len(x)==len(y):
  for i,(u,v) in enumerate(zip(x,y)):diff(u,v,path+'/'+str(i))
 else:leaves.append({'path':path,'before':x,'after':y})
diff(b,p);assert len(leaves)==2
anchor='fine lightweight cloth retains visible weave and finished front edges'
for x in leaves:assert x['after']==x['before']+[anchor]
assert leaves==read(A/'exact-changed-leaves.json')
save('exact-approved-leaves.json',leaves);save('approved-profile.json',p)
rows=read(A/'consumer-controls.json');assert len(rows)==28
for row in rows:
 profile=b if row['state']=='before' else p
 ob=pg.candidate_pack_visual_profile_obligation(profile,raw,activation_source='explicit_user_requirement',source_intent_ids=[])
 if 'field' in row:
  try:pg.validate_visual_intent_binding(obligation_index=0,field=row['field'],phrase=row['phrase'],requirement=ob['evidence_requirements'][row['field']]);result='pass'
  except ValueError as e:result=str(e)
 else:result=pg.candidate_pack_visual_component_match(profile,row['text'])
 assert result==row['result'],row
save('reproduced-28-consumer-controls.json',rows)
# Check required groups individually: four required of five total; optional regional group cannot substitute.
cs=p['semantics']['component_semantics'];assert cs['minimum_component_groups']==4 and len(cs['required_group_ids'])==4 and len(cs['groups'])==5
parts={'shaped_front_open_upper':'shaped front-opening blouse','surface_and_edge_finish':anchor,'center_fastening':'readable center-front fastening','separate_wrapped_lower_layer':'separate wrapped lower cloth','regional_variation_boundary':'regional form controls length opacity and fit'}
extra=[]
for missing in cs['required_group_ids']:
 text='; '.join(v for k,v in parts.items() if k!=missing)
 result=pg.candidate_pack_visual_component_match(p,text);assert result is None
 extra.append({'missing_required_group':missing,'optional_regional_group_present':True,'result':result})
save('required-group-controls.json',extra)
source=read(A/'public-cli/before-source-manifest.json');assert all(sha(R/f)==h for f,h in source['sha256'].items())
manifest=read(A/'public-cli/before/run-manifest.json');frozen=read(A/'public-cli/frozen-input-manifest.json');assert len(manifest['cases'])==len(frozen)==6
public=[]
for c in manifest['cases']:
 case=c['case'];fc=next(x for x in frozen if x['case']==case);I=A/'public-cli/inputs'/case
 assert all(sha(I/n)==h for n,h in fc['inputs'].items());assert c['input_sha256']==fc['inputs']
 packpath=A/'public-cli/before'/(case+'-pack.json');assert sha(packpath)==c['output_sha256']
 pack=read(packpath)[0];obs=pack['visual_obligations']['obligations'];assert len(obs)==1 and obs[0]==c['target_obligation'] and obs[0]['id']==b['id']
 ob=obs[0];assert ob['component_semantics']==b['semantics']['component_semantics'];assert ob['evidence_requirements']==b['evidence_requirements']
 assert c['exit_code']==0 and c['source_hashes_unchanged']
 checks=[]
 for field,phrase in [('embroidered_surface_phrase',{'plain':anchor,'embroidered':b['evidence_requirements']['embroidered_surface_phrase']['must_mention_any'][0],'lace':b['evidence_requirements']['embroidered_surface_phrase']['must_mention_any'][1]}[case.split('-')[0]]),('center_fastening_phrase', 'buttons visibly bridge the two front edges' if case.endswith('buttons') else 'a linked kerongsang brooch set fastens the center')]:
  try:pg.validate_visual_intent_binding(obligation_index=0,field=field,phrase=phrase,requirement=ob['evidence_requirements'][field]);passed=True
  except ValueError:passed=False
  assert passed==(field!='embroidered_surface_phrase' or not case.startswith('plain'))
  checks.append({'field':field,'passed':passed})
 # Independently reproduce normal CLI without touching original frozen outputs.
 cmd=c['command'][:];cmd[-1]=str(O/(case+'-reproduced-pack.json'))
 run=subprocess.run(cmd,cwd=R,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},capture_output=True,text=True,timeout=600)
 assert run.returncode==0,run.stderr
 reproduced=read(Path(cmd[-1]))[0];assert reproduced['visual_obligations']==pack['visual_obligations']
 public.append({'case':case,'original_hash_verified':True,'input_hashes_verified':True,'original_exit_code':c['exit_code'],'independent_cli_exit_code':run.returncode,'actual_obligation_reproduced':True,'checks':checks})
 print(case,'verified',flush=True)
assert all(sha(R/f)==h for f,h in source['sha256'].items())
save('actual-consumer-review.json',{'decision':'approve_exactly','source_hashes_unchanged':True,'consumer_controls_reproduced':28,'required_group_negative_controls':extra,'public_cli_six_cases':public,'actual_group_counts':{'total':5,'required':4,'minimum':4},'evidence_fields':5,'each_evidence_min_content_words':4,'render_gates':5,'provider_calls':0,'fake_vectors':False,'repository_edits':False})
