# Applied source, index and AFTER review

Decision: PASS for the narrowly scoped DATA repair.

- Live profile exactly matches `approved-profile.json`. Relative to wrap-skirt HEAD `7a98e2dcf18a9d60e3505b71e735b88543a99b24`, no other source profile or top-level source field changes.
- Comparison with frozen `kebaya-material-original-index.json` finds exactly one changed entry: kebaya. All 1495 others remain identical. New semantic text/hash and 768-dimensional finite vector agree exactly with the saved new-vector cache and successful provider ledger record. Independent full deterministic payload reconstruction with the saved vectors equals the entire live index, including registry digest and BM25F metadata. No reviewer provider call or source write occurs. Provider provenance is supported by saved ledger/cache and refresh code, rather than a second provider request.
- Independently reran the three focused regression tests: all pass.
- All six genuine AFTER normal CLI outputs have verified hashes, successful return codes and original frozen input hashes. Independent whole-pack equality checks confirm that only `pack_id` and the two approved obligation arrays differ from each genuine BEFORE pack. Thus all candidate records, counts and ordering remain unchanged in these six fixtures.
- Independently reran all six complete composed-prompt audit CLIs and reproduced passing reports. Each has three disclosed `uncovered_intent` warnings: adult wording, the original standing studio scene and front-opening/selected closure wording are retained through free description/assertion. There are no failure findings.
- The original baseline text remains a verbatim prefix in each composition. On the same evidence, actual BEFORE emitted obligations reject only the new material anchor in both plain-cloth cases; all AFTER visual checks pass. Embroidered/lace and both fastening controls remain supported.

Machine-readable details: `applied-source-index-review.json`, `after-public-composition-review.json`, and six `*-independent-full-audit.json` reports. Reproduction scripts: `review_applied.py`, `review_after.py`.

## Limits and collateral

The six samples are frozen synthetic text fixtures; no images were rendered or pixel-reviewed. Composed evidence was authored explicitly, so this demonstrates contract expressibility/acceptance rather than spontaneous material selection by an independent composer. Normal BEFORE pack generation succeeded; the demonstrated rejection occurs when its emitted evidence contract is audited. No measured render-quality improvement is claimed.

Registry digest and BM25F metadata necessarily change. Even with 1495 preserved entry vectors, corpus statistics can affect rankings for unrelated queries. No such candidate movement occurred in these six cases; they are not exhaustive retrieval-regression coverage. UNESCO access/provenance limitations and the scoped blouse-plus-lower-wrap interpretation remain as in the initial review.
