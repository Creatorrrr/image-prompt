import json,sys,hashlib,copy,subprocess,os
from pathlib import Path
sys.dont_write_bytecode=True
O=Path(__file__).resolve().parent;A=O.parent/'kebaya-material-audit';R=O.parent.parent/'image-prompt';S=R/'skills/photo-prompt-image-generator/scripts';sys.path.insert(0,str(S));import audit_composed_prompt as ac
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=read(A/'public-cli/after/run-manifest.json');frozen=read(A/'public-cli/frozen-input-manifest.json');assert len(manifest['cases'])==6
rows=[]
for c in manifest['cases']:
 n=c['case'];f=next(x for x in frozen if x['case']==n);assert c['exit_code']==0 and c['source_hashes_unchanged'];assert c['input_sha256']==f['inputs'];assert all(sha(A/'public-cli/inputs'/n/k)==v for k,v in f['inputs'].items())
 path=A/'public-cli/after'/f'{n}-pack.json';assert sha(path)==c['output_sha256'];after=read(path)[0];before=read(A/'public-cli/before'/f'{n}-pack.json')[0];approved=read(O/'approved-profile.json');expected=copy.deepcopy(before);expected['pack_id']=after['pack_id'];ob=expected['visual_obligations']['obligations'][0];ob['component_semantics']=approved['semantics']['component_semantics'];ob['evidence_requirements']=approved['evidence_requirements'];assert expected==after
 composed=A/'after-evidence'/f'{n}-complete-composed.json';cc=read(composed);prompt=cc['prompt_en'];assert prompt.startswith(before['authorial_core']['baseline_prompt_en']);bef=ac.audit_visual_obligations(before,cc,prompt);aft=ac.audit_visual_obligations(after,cc,prompt);assert not aft;assert bool(bef)==n.startswith('plain')
 cmd=[sys.executable,str(S/'audit_composed_prompt.py'),'--pack',str(path),'--composed',str(composed)];run=subprocess.run(cmd,capture_output=True,text=True,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'});result=json.loads(run.stdout);assert run.returncode==0 and result['status']=='pass' and not result['failures'];assert result==read(A/'after-evidence'/f'{n}-complete-audit.json')
 (O/f'{n}-independent-full-audit.json').write_text(json.dumps(result,indent=2)+'\n');rows.append({'case':n,'after_pack_hash_verified':True,'all_original_frozen_inputs_verified':True,'entire_pack_equal_except_pack_id_and_two_approved_arrays':True,'full_composed_cli_independently_reproduced':'pass','warnings':result['warnings'],'before_visual_failures':bef,'after_visual_failures':aft})
 print(n,'pass',flush=True)
(O/'after-public-composition-review.json').write_text(json.dumps({'decision':'pass','cases':rows,'limits':['Six frozen synthetic text fixtures, not image rendering or population-wide retrieval regression coverage.','Composed prompts were authored with explicit full evidence; this proves the contract supports the option, not that an independent composer will spontaneously choose it.','BEFORE failures are re-audits of actual BEFORE emitted obligations with the same authored evidence; the normal BEFORE candidate-pack CLI itself succeeded.']},indent=2)+'\n')
