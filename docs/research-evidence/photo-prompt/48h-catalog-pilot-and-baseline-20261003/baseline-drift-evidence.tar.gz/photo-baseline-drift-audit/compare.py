import sys,json,hashlib,subprocess,collections
from pathlib import Path
root=Path('/workspace/scratch/ce8f20680f5a/image-prompt'); out=root.parent/'data-progress-48h-20261003/photo-baseline-drift-audit'; trial=out.parent/'undercut-trial-v2'
def git(*args): return subprocess.check_output(['git',*args],cwd=root).decode().strip()
manifest={}
for label,source,rev in [('before_8a0fb5',trial/'before','8a0fb5b8'),('before_6fb876',trial/'before','6fb87682'),('after_7e769e',trial/'after','7e769e3e')]:
    expected={}
    for row in git('ls-tree','-r',rev,'--','skills/photo-prompt-image-generator').splitlines():
        meta,path=row.split('\t'); expected[path]=meta.split()[2]
    files=sorted(p for p in (source/'skills/photo-prompt-image-generator').rglob('*') if p.is_file() and '__pycache__' not in p.parts)
    hashes=git('hash-object',*[str(f) for f in files]).splitlines()
    diffs=[]
    for p,sha in zip(files,hashes):
        rel=str(p.relative_to(source))
        if expected.get(rel)!=sha: diffs.append(dict(path=rel,actual_git_blob=sha,expected_git_blob=expected.get(rel)))
    all_py=[p for p in expected if p.endswith('.py') and ('/scripts/' in p or '/precore/' in p)]
    missing_py=[p for p in all_py if not (source/p).exists()]
    manifest[label]=dict(revision=git('rev-parse',rev),checked_snapshot_files=len(files),mismatches=diffs,missing_python_files=missing_py)
(out/'source-verification.json').write_text(json.dumps(manifest,indent=2)+'\n'); print(json.dumps(manifest,indent=2))
a=json.loads((out/'prior_snapshot.pack.json').read_text()); b=json.loads((out/'production.pack.json').read_text())
def diff(a,b,path=''):
    if type(a)!=type(b): return [dict(path=path,before=a,after=b)]
    if isinstance(a,dict):
        d=[]
        for k in sorted(a.keys()|b.keys()):
            if k not in a or k not in b: d.append(dict(path=path+'/'+k,before=a.get(k),after=b.get(k)))
            else: d+=diff(a[k],b[k],path+'/'+k)
        return d
    if isinstance(a,list):
        if len(a)!=len(b): return [dict(path=path,before=a,after=b)]
        return sum((diff(x,y,path+'/'+str(i)) for i,(x,y) in enumerate(zip(a,b))),[])
    return [] if a==b else [dict(path=path,before=a,after=b)]
d=diff(a,b); (out/'pack-leaf-diff.json').write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n'); print('LEAF DIFF',json.dumps(d,indent=2,ensure_ascii=False))
