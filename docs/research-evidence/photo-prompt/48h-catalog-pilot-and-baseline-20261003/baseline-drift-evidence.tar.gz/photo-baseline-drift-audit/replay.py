import os,sys,json,hashlib,subprocess,time
from pathlib import Path
root=Path('/workspace/scratch/ce8f20680f5a/image-prompt')
out=root.parent/'data-progress-48h-20261003/photo-baseline-drift-audit'
trial=root.parent/'data-progress-48h-20261003/undercut-trial-v2'
baseline=json.loads((root/'skills/subculture-illustration-image-generator/assets/photo_regression_baseline_v9.json').read_text())
env=os.environ.copy(); env.update(GEMINI_API_KEY='',GOOGLE_API_KEY='',PYTHONDONTWRITEBYTECODE='1')
results=[]
for label,source in [('prior_snapshot',trial/'before'),('nape_snapshot',trial/'after'),('production',root),('production_repeat',root)]:
    cmd=list(baseline['command'])
    if source!=root: cmd[1]=str(source/cmd[1])
    cmd[cmd.index('--output-file')+1]=str(out/f'{label}.pack.json')
    t=time.time(); p=subprocess.run(cmd,cwd=root,env=env,capture_output=True,text=True,timeout=100)
    (out/f'{label}.stdout.txt').write_text(p.stdout); (out/f'{label}.stderr.txt').write_text(p.stderr)
    result=dict(label=label,source=str(source),command=cmd,cwd=str(root),elapsed_s=time.time()-t,returncode=p.returncode)
    if p.returncode==0:
        raw=(out/f'{label}.pack.json').read_bytes(); pack=json.loads(raw)[0]
        preserved={k:pack.get(k) for k in ('authorial_core','creative_controls','embodiment_review','authorial_composition','negative_en')}
        h=lambda x: hashlib.sha256(x).hexdigest()
        result.update(sha256=h(raw),bytes=len(raw),pack_id=pack.get('pack_id'),preserved_contract_sha256=h(json.dumps(preserved,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()),contract_version=pack.get('contract_version'),public_candidate_count=sum(len(v['candidates']) for v in pack['slots'].values() if isinstance(v,dict) and isinstance(v.get('candidates'),list)),provenance=pack.get('provenance'),negative_unchanged=pack.get('negative_en')==baseline.get('negative_en'))
    results.append(result); print(json.dumps(result),flush=True)
(out/'replay-results.json').write_text(json.dumps(results,indent=2)+'\n')
