# Neutral pre-core data proposal: living nonhuman observations

Status: frozen hypothesis; no measured improvement is claimed.

## Scope

This proposes six short optional examples in three existing `added_examples` arrays. It adds no subject, species, preset, category, category field, schema, procedure, camera recipe, candidate identifier, or runtime behavior. The production catalog and SKILL.md are untouched. All 48 category IDs, names, groups, source numbers, source examples, existing added examples, other fields, and order are preserved.

Every added phrase begins with “이미 요청된 비인간 생물” (“an already-requested nonhuman living subject”). That phrase limits relevance to a living nonhuman subject already supplied by the request; it is not a trigger to create one. The existing SKILL.md makes catalog examples optional and subordinate to request meaning. This proposal does not change or replace those instructions.

## Exact additions and rationale

### feature.environmental_details
- 이미 요청된 비인간 생물 주변 표면에 보이는 자국
  - Literal gloss: visible marks on surfaces around an already-requested nonhuman living subject
  - Source relationship: extends existing dust, wetness, scratches, and signs of use to a relevant requested subject. A mark is observed without claiming who made it or when.
- 이미 요청된 비인간 생물 주변 표면의 젖음과 마름 경계
  - Literal gloss: wet/dry boundaries on surfaces around an already-requested nonhuman living subject
  - Source relationship: narrows existing surface wetness to a visible boundary. It does not specify rain, drinking, movement, weather, or another cause.

### feature.pose
- 이미 요청된 비인간 생물이 기존 표면에 닿거나 기대는 부위
  - Literal gloss: parts of an already-requested nonhuman living subject touching or leaning against an existing surface
  - Source relationship: extends the existing standing, sitting, leaning, and lying examples to contact that can be observed without requiring a particular anatomy or behavior.
- 이미 요청된 비인간 생물의 몸 기울기와 보이는 지지점
  - Literal gloss: body inclination and visible support points of an already-requested nonhuman living subject
  - Source relationship: extends the existing leaning and weight-support examples. “Visible” avoids treating inferred roots, hidden limbs, or unseen support as evidence.

### feature.realism_cues
- 이미 요청된 비인간 생물의 표면에 보이는 물방울이나 붙은 입자
  - Literal gloss: visible droplets or adhering particles on an already-requested nonhuman living subject's surface
  - Source relationship: extends existing small stains and realistic materials to observable surface interaction. It does not specify fur, scales, feathers, skin, leaves, or any universal biological covering.
- 이미 요청된 비인간 생물과 접촉한 재질의 휘어짐이나 눌림
  - Literal gloss: bending or indentation in a material contacting an already-requested nonhuman living subject
  - Source relationship: extends existing gravity and material realism to a visible contact consequence without fixing the material, organism, setting, or mechanism.

## Hypothesis

When living nonhuman subjects are already requested, these examples may make meaningful contact, support, traces, and material relationships easier to notice within existing categories. Their value is unknown. Catalog integrity and source-faithful wording cannot establish improved prompts, preference, or rendered images.

## Potential harms and limits

- Repetition of “nonhuman living subject” could prime a reader to introduce a living subject into human-only or object-only requests despite the explicit qualifier and unchanged optional-example rule.
- Wetness, marks, particles, and deformation could become generic texture additions, clutter a sparse scene, or contradict an explicitly clean, dry, pristine, still, or isolated presentation. They are not required details.
- Visible support/contact examples may overemphasize grounded or leaning poses and be irrelevant for floating, airborne, freely suspended, very close-cropped, or fully occluded subjects. They do not require an added support surface or reveal of a hidden one.
- A model could incorrectly infer movement, feeding, rain, injury, emotion, or the cause or age of a mark. The proposed strings describe visible states only and make none of those causal claims.
- A model could invent biologically inappropriate body parts or material responses. No new anatomical assumption is supplied here; contact and deformation must remain compatible with the actual subject and request.
- Pose contact, environmental marks, and material deformation can overlap. Rephrasing one visible relationship under multiple categories would not create independent observation axes under the existing SKILL.md.
- These additions favor visible physical relations and do not address other possible gaps in nonhuman observation. Their small scope is deliberate, not evidence that this is the most useful direction.

## Isolation and freezing

Only the exact source catalog and its SKILL.md were read for this proposal. No assets, runtime scripts, tests, prior reports, experiment designs, evaluation requests, or evaluation outputs were inspected. No web research, provider calls, or image generation were performed. The full proposed catalog was serialized and hashed before any evaluation material was received. The accompanying freeze manifest records byte-level hashes; it is a reproducibility record and timing attestation, not an independently enforced access barrier.

Do not revise this frozen proposal in response to later evaluation material. Any future revision should be a separately identified proposal with a new freeze and independent evaluation.
