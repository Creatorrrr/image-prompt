from pathlib import Path
import json,hashlib,random,datetime
P=Path(__file__).resolve().parent;O=P/'outputs/development';D=P/'design';J=P/'judging/development';J.mkdir(parents=True,exist_ok=True)
expected={'dev-m7-1.json':'1e2181d9195336431ff1b19b5ef586e52262637198e26c2b83b232a164f7fc8d','dev-m7-2.json':'c219b043513139338f5d6a7e5cfcb559c2cf5c0f198c8a8087c4a9d287af99d5','dev-p2-1.json':'7d815e09a14bb80c8dbb4da9b8fdadc9b2e7ee4b995db97f8d00857451d1b203','dev-p2-2.json':'d354fa42ee9999776c58b13d2453faf6ec83c157afd182d0267cf4a75d7a01db'}
reqs={r['request_id']:r for r in json.loads((D/'development_requests.json').read_text())['requests']};rng=random.Random(202610031649);ids=rng.sample(range(100000,999999),16);mapping={};items=[];integrity=[]
for name,h in expected.items():
 f=O/name;assert hashlib.sha256(f.read_bytes()).hexdigest()==h;x=json.loads(f.read_text());assert len(x['outputs'])==4;slot=name.removesuffix('.json');condition='m7' if '-m7-' in slot else 'p2'
 assert set(r['request_id']for r in x['outputs'])==set(reqs)
 cat=json.loads((P/f'conditions/{condition}/skills/photo-prompt-image-generator/precore/visual_feature_catalog.json').read_text());allowed={r['id']for r in cat['categories']}
 for row in x['outputs']:
  rid=row['request_id'];t=' '.join(row['baseline_prompt_en'].split());pid='P'+str(ids.pop());n=len(t.split());cats=row.get('selected_category_ids',[])
  integrity.append({'slot':slot,'request_id':rid,'word_count':n,'budget_ok':48<=n<=180,'selected_categories_valid':5<=len(cats)<=10 and len(set(cats))==len(cats) and set(cats)<=allowed})
  mapping[pid]={'slot':slot,'condition':condition,'request_id':rid,'source_file':name,'normalized_prompt_sha256':hashlib.sha256(t.encode()).hexdigest()}
  r=reqs[rid];items.append({'prompt_id':pid,'request_id':rid,'request_text':r['request_text'],'constraint_ledger':r['judge_only_constraint_ledger'],'open_scope':r['judge_only_open_scope'],'baseline_prompt_en':t})
for judge,seed in [(1,202610031650),(2,202610031651)]:
 batch=list(items);random.Random(seed).shuffle(batch);(J/f'individual-packet-{judge}.json').write_text(json.dumps({'phase':'individual only; no pair comparison yet','items':batch},ensure_ascii=False,indent=2)+'\n')
(J/'PRIVATE-MAPPING.json').write_text(json.dumps(mapping,indent=2)+'\n');(J/'output-integrity.json').write_text(json.dumps(integrity,indent=2)+'\n');(J/'blinding-freeze.json').write_text(json.dumps({'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_output_hashes':expected,'prompt_id_seed':202610031649,'judge_order_seeds':[202610031650,202610031651],'normalization':'whitespace only','rubric_sha256':hashlib.sha256((D/'judge_rubric.json').read_bytes()).hexdigest(),'packet_hashes':{f.name:hashlib.sha256(f.read_bytes()).hexdigest()for f in J.glob('individual-packet-*.json')}},indent=2)+'\n')
print('prompts',len(items),'word counts',[r['word_count']for r in integrity]);print('budget/category integrity',all(r['budget_ok'] and r['selected_categories_valid'] for r in integrity))
