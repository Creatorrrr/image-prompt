from pathlib import Path
import json,hashlib,datetime
P=Path(__file__).resolve().parent;E=P/'execution';assert (E/'heldout-pre-release-freeze.json').exists();R=json.loads((P/'design/sealed/heldout_requests.json').read_text())['requests'];envdir=E/'heldout-envelopes';envdir.mkdir(exist_ok=True);(P/'outputs/heldout').mkdir(exist_ok=True)
for r in R:
 t=r['request_text'];assert hashlib.sha256(t.encode()).hexdigest()==r['request_sha256'];env={'contract_version':'photo-request-envelope/v1','provenance':'requesting_user','request_id':'synthetic-precore-ab-'+r['request_id'],'request_text':t,'request_sha256':r['request_sha256'],'active_spans':[{'span_id':'request','start':0,'end':len(t),'text':t}]};(envdir/(r['request_id']+'.json')).write_text(json.dumps(env,ensure_ascii=False,indent=2)+'\n')
assign=[]
for c in ('m7','p2'):
 for n in (1,2):
  d=json.loads((E/f'dev-{c}-{n}.assignment.json').read_text());slot=f'held-{c}-{n}';d['author_slot']=slot;order=R if n==1 else list(reversed(R));d['requests']=[{'request_id':r['request_id'],'envelope_path':str(envdir/(r['request_id']+'.json'))}for r in order];d['output_path']=str(P/f'outputs/heldout/{slot}.json');f=E/f'{slot}.assignment.json';f.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');assign.append({'slot':slot,'path':str(f),'sha256':hashlib.sha256(f.read_bytes()).hexdigest()})
(E/'heldout-execution-freeze.json').write_text(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pre_release_freeze_sha256':hashlib.sha256((E/'heldout-pre-release-freeze.json').read_bytes()).hexdigest(),'heldout_requests_sha256':hashlib.sha256((P/'design/sealed/heldout_requests.json').read_bytes()).hexdigest(),'assignments':assign,'changes_from_development':'Only request set, opaque author slot/output path, and fresh contexts. Same snapshots/common packet/settings.'},indent=2)+'\n')
print('Frozen four heldout assignments')
