from pathlib import Path
import json,statistics,hashlib,datetime
P=Path(__file__).resolve().parent;out={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'decision':'DEFER; keep production catalog unchanged','splits':{}}
for split in ('development','heldout'):
 J=P/'judging'/split;pm=json.loads((J/'PRIVATE-MAPPING.json').read_text());bm=json.loads((J/'PRIVATE-PAIR-MAPPING.json').read_text());ind=[json.loads((J/f'individual-ratings-{i}.json').read_text())['ratings'] for i in (1,2)];pair=[json.loads((J/f'pair-ratings-{i}.json').read_text())['ratings']for i in (1,2)];adj=json.loads((J/'adjudication-ratings.json').read_text());ir={r['prompt_id']:r.copy()for r in ind[0]};pr={r['bundle_id']:r.copy()for r in pair[0]}
 for r in adj['individual_ratings']:
  k=r['prompt_id']
  for field in ('fidelity','coherence','grounded_specificity','critical_failure'):ir[k][field]=r[field]
 for r in adj['pair_ratings']:
  k=r['bundle_id'];pr[k]['raw_pair_variety']=r.get('raw_pair_variety',r.get('raw_variety'));assert pr[k]['raw_pair_variety'] is not None
 for k,r in pr.items():
  eligible=all(ir[pid]['fidelity']>=2 and ir[pid]['coherence']>=2 and not ir[pid]['critical_failure']for pid in bm[k]['prompt_ids']);r['pair_eligible']=eligible;r['quality_qualified_pair_variety']=r['raw_pair_variety'] if eligible else 0
 items=json.loads((J/'individual-packet-1.json').read_text())['items'];texts={x['prompt_id']:x['baseline_prompt_en']for x in items};rows=[]
 for rid in sorted({x['request_id']for x in pm.values()}):
  row={'request_id':rid}
  for c in ('m7','p2'):
   ids=[pid for pid,x in pm.items()if x['request_id']==rid and x['condition']==c];bid=next(k for k,x in bm.items()if x['request_id']==rid and x['condition']==c);row[c]={'variety':pr[bid]['quality_qualified_pair_variety'],'eligible':pr[bid]['pair_eligible'],'individual_fidelity':[ir[k]['fidelity']for k in ids],'mean_coherence':statistics.mean(ir[k]['coherence']for k in ids),'critical_failures':sum(ir[k]['critical_failure']for k in ids),'word_counts':[len(texts[k].split())for k in ids]}
  row['variety_difference_proposed_minus_original']=row['p2']['variety']-row['m7']['variety'];rows.append(row)
 lengths={c:[len(texts[k].split())for k,x in pm.items()if x['condition']==c]for c in ('m7','p2')};out['splits'][split]={'request_count':4,'prompt_count':16,'rows':rows,'lengths':{c:{'mean':statistics.mean(v),'median':statistics.median(v),'values':v}for c,v in lengths.items()},'initial_ratings_preserved':True,'adjudication_used_only_for_disputed_items':True}
out['heldout_gate_failures']=['Fern eligible case has no strict variety gain (0 to0).','Adult non-regression control loses variety (1 to0).','One proposed fern prompt fidelity2; not all proposed prompts fidelity3.'];out['heldout_eligible_mean_variety_delta']=0.5;out['judging_instruction_sensitivity']='Heldout handoff clarified no mandatory negative clauses when scene already satisfies exclusion; rubric unchanged, but handoff wording differs after development. Treat this as additional procedural limitation, not strict unchanged-confirmatory proof.';out['limits']=['Two eligible heldout requests only; purposeful synthetic internal sample.','Two prompts per condition/request; four requests per author context, so carryover possible.','Exact backend/temp/seed unavailable.','No complete core, retrieval, image render or pixel quality evaluation.','Acceptance would only support a larger pilot, never automatic production change.'];(P/'RESULTS.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps(out,indent=2))
