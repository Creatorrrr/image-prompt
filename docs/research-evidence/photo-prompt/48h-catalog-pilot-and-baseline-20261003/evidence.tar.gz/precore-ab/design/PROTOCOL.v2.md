# Frozen small pre-core catalog A/B design — version 2

## Scope and timing
This is a data-only experiment on initial English photographic prompt authoring. No image generation, retrieval, post-core candidate composition, provider calls, repository edits, or catalog intervention was performed while designing it. Eight original synthetic requests are balanced as four development and four held-out requests, with one living animal, one living plant, one explicitly adult person, and one nonliving object in each split. Each split has two Korean and two English requests. None is a translation duplicate.

The designer read only the permitted SKILL.md, precore/visual_feature_catalog.json, and precore/creative_controls.json. The resolver was not needed. The source hashes are recorded. Scene requirements and aesthetic criteria were written before any author output and without inspecting candidates, test fixtures, previous evaluations, assets, references, or scripts.

## Arms
A uses the original catalog identified by source_fingerprints.json. B uses one proposed catalog whose complete bytes and hash must be frozen by the intervention author. This design does not write that proposal. Use the same pre-core skill material, controls, author instructions, output shape, and word budget in both arms. The sole planned change is the catalog payload. If the actual proposal requires an instruction change, freeze and disclose the exact combined package before any outputs, and interpret the result as a package comparison rather than a catalog-only effect. No author may see the other arm's catalog or results.

Freeze the baseline and intervention bundles, common author packet, model name/version, available generation settings, and their hashes before development authoring. Development results may inform a documented B revision. After any such revision, freeze B and all analysis/authoring settings again before opening sealed/heldout_requests.json. Do not use held-out findings for this revision.

## Author sampling: frozen feasible plan
Use four fresh independent author contexts per split: two A and two B. Each context authors all four requests in its split, one at a time, for 16 prompts per split and 32 total. Use entirely new contexts for held-out authoring. Never reuse an author between arms or show another author's outputs.

Within each split, replicate 1 receives case order 01, 02, 03, 04; replicate 2 receives 04, 03, 02, 01. Match that same order to the corresponding replicate in both arms. Thus A1 and B1 have matched order, as do A2 and B2, while first/last positions are balanced. Use the appropriate D or H request prefix. The coordinator releases one request at a time; no author sees the judge-only constraint ledger, other-arm catalog, scores, or the paired author's output.

Give the same instruction to author each scene independently from its current request and allowed pre-core inputs. Do not invite cross-request diversification, re-use, comparison, or reference to a previous scene. A context may still retain its own earlier work: record this carryover limitation rather than pretending the 32 prompts have fully isolated contexts. Two authors are repeated samples, not independent request-level test cases. Only one author per arm is insufficient for the planned variety conclusion.

Keep the same model/version and available reasoning/sampling settings across arms. Record nondeterminism and seeds when available; do not pretend matching numeric seeds guarantees equivalent draws across different prompts. Assign anonymous author/arm slots before authoring and save the mapping privately. Retain every first output. A transport failure with no returned content may be retried and logged; a returned poor or overlength output may not be silently regenerated.

## Author output and budget
Collect baseline_prompt_en as a standalone single photograph of 48–180 whitespace-counted English words, preferably 90–140, without padding. This tighter but skill-compatible budget is identical in both arms. Preserve only optional identical, compact intent/priority metadata if needed to show the intended direction; judges see prose alone. If a complete neutral core/selection/embodiment record is separately collected, its structural validity is a separate integrity measure and cannot earn an aesthetic point. Do not invoke scripts or retrieve anything as part of initial authoring.

The controls are sensual=0, fetish=0, surreal=0, creativity=1 in both arms, with all other selections fixed in controls.json. A calm or still subject is valid. Requester facts outrank agent choices; negative source requirements stay semantically binding without a requirement to copy negative clauses into the positive prompt. No catalog example is required.

## Blind judging and analysis
Use judge_rubric.json unchanged. Two independent fresh judges first score anonymous individual prompts, then anonymous within-arm two-prompt bundles for each request. The coordinator privately shuffles individual identifiers, prompt order in each bundle, and bundle position independently per request. Judges see the original request and its frozen gold constraints, not the catalog or planning. Do not change prompt wording during blinding; canonical single-space whitespace is the only permitted normalization. A third fresh blinded judge adjudicates criterion-changing or large disagreements. Freeze ratings and quoted evidence before unblinding.

For each request, average the two author-level individual scores within each arm. Pair-variety already has one rating per arm/request. Average the two judges' scores unless a specific item is adjudicated, in which case retain both originals and use the documented adjudicated score for that item. Weight each request equally. Report both raw and quality-qualified variety. Report the development split separately. Apply acceptance_criteria.v2.json: the primary gain comparison is the two eligible living-nonhuman held-out requests, while human/object cases are non-regression checks. Also report all four comparisons descriptively. No post-hoc threshold changes or claim of statistical significance.

## Separation and seal
The held-out file contains original text plus judge-only gold constraints. The intervention designer and authors must not inspect it until the release condition is met. This is a procedural seal with content hashes, not encryption or access-control isolation: all agents share a filesystem. Its contents must not be printed to the parent before the parent asks for release after freezing the intervention. MANIFEST.sha256 commits the exact held-out file bytes without revealing its text. An exposure or modification must be logged honestly, not concealed by replacing hashes.

## Stop conditions
Design work ends when all files and hashes are verified. Authoring requires a separately frozen intervention and execution authorization. A missing second independent author, exposed holdout, missing output, protocol drift, or unmet decision gate yields defer, with the concrete limitation preserved. Acceptance only supports a larger pilot, never automatic deployment or pixel-quality claims.

## Version 2 pre-output amendment and rationale
The parent disclosed the intervention's eligibility boundary after the independent version 1 design freeze: it is limited to already-requested living nonhuman subjects. The designer has not inspected the proposal. No author output has been generated, according to the parent's pre-output review message.

Version 1 required gains on three of the four held-out requests. Because only two requests are eligible for the intervention, that rule necessarily demands a gain on an ineligible human or object control. It therefore mismatches the intended treatment population and would judge an appropriately targeted intervention partly on out-of-scope improvement. A broad four-request gain estimand would be appropriate only for a broad intervention claim, which is not the disclosed scope.

Version 2 uses the two living-nonhuman requests as the primary gain estimand. Both must individually improve strictly, and their mean improvement must be at least +0.5. Human and object controls must not regress; improvement is not required and cannot rescue a failed eligible case. All original fidelity, coherence, pair eligibility, word-budget, length-confound, blinding, missing-output, adjudication, and no-selective-redraw gates remain. The rubric, original requests, held-out content, and control configuration are byte-for-byte unchanged.

The original version 1 files, MANIFEST.sha256, and FREEZE.json remain intact. Amendment metadata records their hashes; MANIFEST.v2.sha256 commits the original files and the new criteria/protocol/amendment files, and FREEZE.v2.json binds that new manifest. Version 2 is the analysis version for subsequent authoring. This is still a small internal pilot with just two eligible held-out cases, not publication-ready or generalizable evidence.
