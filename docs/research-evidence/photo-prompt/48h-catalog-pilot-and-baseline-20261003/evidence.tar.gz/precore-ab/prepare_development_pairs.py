from pathlib import Path
import json,hashlib,random,datetime
P=Path(__file__).resolve().parent;J=P/'judging/development'
ratings=[J/f'individual-ratings-{i}.json' for i in (1,2)]
assert all(f.exists() for f in ratings),'Individual phase must be complete before pairing'
assert not (J/'pair-freeze.json').exists(),'Do not overwrite frozen phase'
mapping=json.loads((J/'PRIVATE-MAPPING.json').read_text());items={x['prompt_id']:x for x in json.loads((J/'individual-packet-1.json').read_text())['items']}
groups={}
for pid,m in mapping.items():groups.setdefault((m['request_id'],m['condition']),[]).append(pid)
rng=random.Random(202610031654);ids=rng.sample(range(10000,99999),len(groups));bundles=[];private={}
for (rid,c),pids in sorted(groups.items()):
 assert len(pids)==2
 rng.shuffle(pids);bid='B'+str(ids.pop());sample=items[pids[0]]
 bundles.append({'bundle_id':bid,'request_id':rid,'request_text':sample['request_text'],'constraint_ledger':sample['constraint_ledger'],'open_scope':sample['open_scope'],'prompts':[{'prompt_id':p,'baseline_prompt_en':items[p]['baseline_prompt_en']} for p in pids]})
 private[bid]={'request_id':rid,'condition':c,'prompt_ids':pids}
for i in (1,2):
 b=list(bundles);random.Random(202610031654+i).shuffle(b);(J/f'pair-packet-{i}.json').write_text(json.dumps({'phase':'pair variety after frozen individual scores','bundles':b},ensure_ascii=False,indent=2)+'\n')
(J/'PRIVATE-PAIR-MAPPING.json').write_text(json.dumps(private,indent=2)+'\n')
(J/'pair-freeze.json').write_text(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'individual_rating_hashes':{f.name:hashlib.sha256(f.read_bytes()).hexdigest()for f in ratings},'pair_packet_hashes':{f.name:hashlib.sha256(f.read_bytes()).hexdigest()for f in J.glob('pair-packet-*.json')}},indent=2)+'\n')
print('Frozen',len(bundles),'anonymous pairs')
