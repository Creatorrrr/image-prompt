from pathlib import Path
import os,subprocess,json,hashlib,time,datetime,sys
O=Path(__file__).resolve().parent;R=O.parent.parent/'image-prompt';PIN='7e769e3e4a0da7068723830bb0c5c5c2dfd784c8'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==PIN
assert not subprocess.check_output(['git','status','--short'],cwd=R,text=True).strip()
assert not (R/'.env').exists()
files=sorted((R/'tests').glob('test*.py'));assert len(files)==len(list((R/'tests').rglob('test*.py')))
env={k:v for k,v in os.environ.items()if not any(s in k.upper()for s in ['API_KEY','TOKEN','CREDENTIAL'])};env['PYTHONDONTWRITEBYTECODE']='1'
state={'pin':PIN,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'strategy':'All discovered top-level test modules, sequential isolated processes; no test edits or exclusions; live checkout held at the stated commit.','test_file_count':len(files),'test_file_sha256':{f.name:hashlib.sha256(f.read_bytes()).hexdigest()for f in files},'results':[]}
for i,f in enumerate(files):
 if (O/'STOP').exists():state['stopped_by_coordinator']=True;break
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==PIN,'Source commit changed'
 assert not subprocess.check_output(['git','status','--short'],cwd=R,text=True).strip(),'Tracked/untracked source tree changed'
 t=time.monotonic();cmd=[sys.executable,str(O/'one_module.py'),f.name,str(O/(f.stem+'.result.json'))]
 try:
  with (O/(f.stem+'.log')).open('w')as log:r=subprocess.run(cmd,cwd=R,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=600)
  rc=r.returncode
 except subprocess.TimeoutExpired:rc='timeout'
 row={'test_file':f.name,'returncode':rc,'seconds':round(time.monotonic()-t,3)};state['results'].append(row);print(f'{i+1}/{len(files)} {f.name}: {rc}',flush=True)
 (O/'progress.json').write_text(json.dumps(state,indent=2)+'\n')
state['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();state['all_modules_completed']=len(state['results'])==len(files);state['final_head']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();state['final_status']=subprocess.check_output(['git','status','--short'],cwd=R,text=True).strip();(O/'results.json').write_text(json.dumps(state,indent=2)+'\n')
