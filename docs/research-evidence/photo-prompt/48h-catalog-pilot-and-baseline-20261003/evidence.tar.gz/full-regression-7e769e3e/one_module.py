import sys,json,unittest,pathlib
pattern,out=sys.argv[1:]
suite=unittest.defaultTestLoader.discover('tests',pattern=pattern)
def flatten(s):
 for t in s:
  if isinstance(t,unittest.TestSuite):yield from flatten(t)
  else:yield t.id()
ids=list(flatten(suite));result=unittest.TextTestRunner(verbosity=2).run(suite)
payload={'discovered_ids':ids,'tests_run':result.testsRun,'successful':result.wasSuccessful(),'failure_ids':[t.id()for t,_ in result.failures],'error_ids':[t.id()for t,_ in result.errors],'skipped':[(t.id(),why)for t,why in result.skipped],'expected_failures':[t.id()for t,_ in result.expectedFailures],'unexpected_successes':[t.id()for t in result.unexpectedSuccesses]}
pathlib.Path(out).write_text(json.dumps(payload,ensure_ascii=False,indent=2)+'\n');sys.exit(0 if result.wasSuccessful() else 1)
