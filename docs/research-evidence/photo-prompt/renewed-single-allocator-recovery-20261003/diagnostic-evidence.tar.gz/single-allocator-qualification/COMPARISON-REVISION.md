# Source-derived comparison correction

Observed UTC: 2026-10-03T04:52:31Z.

Status: initial comparison preserved; bounded corrected comparator prepared before retry.

The first comparison (`compare.py`, `comparison.json`) expected every `semantic_clarification` byte to remain unchanged. It flagged only the target's `meaning_components[1]` in the three positive packs. Full CLI and composition outcomes already matched the frozen protocol, and every other comparison check passed.

Actual values are exactly the reviewed `/concept_candidate/concept_terms/1` old and new strings. The public clarification with `profile_id=household_food_depletion_portioning_event` projects that target source term. This is an intended actor-scope effect of the frozen proposal, not an unrelated semantic change.

`compare_v2.py` retains the original comparator and output, derives the expected target clarification from the before/after source snapshots, and asserts all other clarification bytes identical. It also requires every public top-level field outside pack identity and the two explicitly expected profile projections to remain equal. Its result is written separately to `comparison-final.json`.

No request, core, prompt, evidence, selection, expected audit outcome, source, runtime, candidate or index file is changed. No CLI rerun or provider call is needed: the correction compares the original frozen BEFORE/AFTER outputs. The initial failing assertion remains reproducible.
