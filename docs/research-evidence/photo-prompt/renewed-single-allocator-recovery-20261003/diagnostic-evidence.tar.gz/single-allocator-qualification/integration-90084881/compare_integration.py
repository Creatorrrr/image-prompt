from pathlib import Path
import copy,hashlib,json,subprocess,sys,importlib.util
sys.dont_write_bytecode=True
P=Path(__file__).resolve().parent;F=P.parent;R=F.parent.parent/'image-prompt'
sys.path.insert(0,str(R/'skills/photo-prompt-image-generator/scripts'));import prompt_generator as g
spec=importlib.util.spec_from_file_location('old_comparator',F/'compare_v2.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
read=mod.read;dump=mod.dump;diff=mod.diff;PID=mod.PID
man=read(F/'manifest.json');templates=read(F/'compositions.json');report=read(P/'run/report.json');issues=[]
frozen=all(hashlib.sha256((F/name).read_bytes()).hexdigest()==h for name,h in man['input_hashes'].items())
if not frozen:issues.append('Frozen inputs changed')
prior_artifacts={}
for name in ['artifact-manifest-before.json','artifact-manifest.json']:
 j=read(F/name);bad=[f for f,h in j['files'].items()if hashlib.sha256((F/f).read_bytes()).hexdigest()!=h];prior_artifacts[name]={'count':len(j['files']),'changed':bad}
 if bad:issues.append(name+': original artifacts changed')
state=read(P/'integration-source-state.json');current={str(x.relative_to(R)):hashlib.sha256(x.read_bytes()).hexdigest()for x in list((R/'skills/photo-prompt-image-generator/assets').rglob('*.json'))+list((R/'skills/photo-prompt-image-generator/scripts').glob('*.py'))}
source_stable=state['files']==current
if not source_stable:issues.append('Integration source changed during recheck')
reg=g.load_visual_obligation_registry(R/'skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations.json');idx=read(R/'skills/photo-prompt-image-generator/assets/photo_prompt_visual_profile_index.json');target=next(x for x in reg['profiles']if x['id']==PID);prior=read(F/'after-source-snapshot.json')
checks={'all_frozen_inputs_identical':frozen,'source_stable_during_run':source_stable,'source_bound_index':idx['registry_sha256']==g.visual_profile_registry_sha256(reg),'target_materialized_profile_identical':target==prior['profile'],'target_index_entry_identical':idx['entries'][PID]==prior['index_target_entry'],'no_unmerged_paths':not subprocess.check_output(['git','diff','--name-only','--diff-filter=U'],cwd=R,text=True).strip()}
for k,v in checks.items():
 if not v:issues.append('Source/fixture invariant failed: '+k)
upstream=read(P/'index-verification.json')['upstream'];oldfiles=read(F/'after/source-state.json')['files'];source_changes=[]
for path,h in current.items():
 if path in oldfiles and h==oldfiles[path]:continue
 p=subprocess.run(['git','show',upstream+':'+path],cwd=R,capture_output=True)
 source_changes.append({'path':path,'absent_from_original_after_snapshot':path not in oldfiles,'current_sha256':h,'upstream_sha256':hashlib.sha256(p.stdout).hexdigest()if p.returncode==0 else None,'matches_upstream':p.returncode==0 and hashlib.sha256(p.stdout).hexdigest()==h,'coupled_generated_index':path.endswith('/photo_prompt_visual_profile_index.json')})
# Added shard files were not included in the old flat manifest. Their direct upstream hash is still verified.
if any(not x['matches_upstream']and not x['coupled_generated_index']for x in source_changes):issues.append('A changed/added source is neither upstream-identical nor the coupled generated index')
out={'status':None,'issues':issues,'checks':checks,'original_artifact_preservation':prior_artifacts,'source_state':{'starting_head':state['head'],'merge_head':state['merge_head'],'ending_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'registry_profile_count':len(reg['profiles']),'registry_sha256':g.visual_profile_registry_sha256(reg),'source_changes_vs_original_after':source_changes},'cases':[],'compositions':[],'upstream_public_changes':[]}
for row in report['cases']:
 id=row['id'];spec=read(F/'inputs'/id/'spec.json')
 if row['exit_code']:
  issues.append(id+': CLI failed');continue
 a=read(P/'run'/id/'pack.json')[0];b=read(F/'after'/id/'pack.json')[0]
 ids=[x['id']for x in a.get('visual_obligations',{}).get('obligations',[])];wanted=[PID]if spec['profile']else[]
 cs={'cli_v6':a['contract_version']=='photo-candidate-pack/v6','expected_hard_profiles':ids==wanted,'no_optional_target':not any(x['id']=='visual-concept:'+PID for x in a.get('visual_concept_candidates',{}).get('candidates',[])),'target_and_other_hard_obligation_block_unchanged':a.get('visual_obligations')==b.get('visual_obligations'),'authorial_core_unchanged':a['authorial_core']==b['authorial_core'],'intent_and_count_locks_unchanged':a['authorial_core']['intent_lock']==b['authorial_core']['intent_lock'],'creative_controls_unchanged':a['creative_controls']==b['creative_controls'],'embodiment_preflight_unchanged':a['embodiment_preflight']==b['embodiment_preflight']}
 for k,v in cs.items():
  if not v:issues.append(id+': invariant failed '+k)
 changes=diff(b,a);out['cases'].append({'id':id,'checks':cs,'hard_profile_ids':ids,'explicit_participant_count':spec['expected_count'],'public_leaf_change_count':len(changes)})
 bytop={}
 for x in changes:bytop[x['path'].split('/')[1]]=bytop.get(x['path'].split('/')[1],0)+1
 out['upstream_public_changes'].append({'id':id,'top_level_leaf_counts':bytop,'leaf_changes':changes,'old_optional_ids':[x['id']for x in b.get('visual_concept_candidates',{}).get('candidates',[])],'current_optional_ids':[x['id']for x in a.get('visual_concept_candidates',{}).get('candidates',[])],'old_candidate_ids':{k:[x['id']for x in v.get('candidates',[])]for k,v in b['slots'].items()},'current_candidate_ids':{k:[x['id']for x in v.get('candidates',[])]for k,v in a['slots'].items()}})
for row in report['compositions']:
 t=next(x for x in templates if x['id']==row['id']);id=row['id'];a=read(P/'run/compositions'/id/'composed.json');b=read(F/'after/compositions'/id/'composed.json');own=row['direct_visual_failures'];other=[x for x in row['failures']if x not in own]
 cs={'expected_audit_outcome':row['status']==t['expected_after'],'no_unrelated_audit_failures':not other,'prompt_and_evidence_unchanged':all(a.get(k)==b.get(k)for k in['prompt_en','visual_obligation_evidence']),'ownership_binding_unchanged':a['authorial_core_binding']==b['authorial_core_binding'],'no_candidate_adoption':a['chosen_candidate_ids']==b['chosen_candidate_ids']==[]and a['chosen_visual_concept_ids']==b['chosen_visual_concept_ids']==[]}
 for k,v in cs.items():
  if not v:issues.append(id+': composition invariant failed '+k)
 out['compositions'].append({'id':id,'status':row['status'],'expected':t['expected_after'],'checks':cs,'failures':row['failures'],'direct_visual_failures':own,'other_full_audit_failures':other})
if len(report['cases'])!=7 or len(report['compositions'])!=17:issues.append('Incomplete 7/17 run')
out['issues']=issues;out['status']='pass'if not issues else'fail';dump(P/'comparison.json',out)
print(json.dumps({'status':out['status'],'issues':issues,'case_public_changes':[{'id':x['id'],'top_level_leaf_counts':x['top_level_leaf_counts']}for x in out['upstream_public_changes']]},indent=2));raise SystemExit(bool(issues))
