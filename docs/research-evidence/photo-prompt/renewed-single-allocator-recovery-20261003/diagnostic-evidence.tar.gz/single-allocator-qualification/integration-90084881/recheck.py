from pathlib import Path
import copy, hashlib, json, os, subprocess, sys, time, traceback, importlib.util
sys.dont_write_bytecode=True
P=Path(__file__).resolve().parent;F=P.parent;R=F.parent.parent/'image-prompt'
S=R/'skills/photo-prompt-image-generator/scripts';A=S.parent/'assets'
sys.path.insert(0,str(S));import prompt_generator as g;import audit_composed_prompt as audit
spec=importlib.util.spec_from_file_location('original_qualifier',F/'qualify.py');q=importlib.util.module_from_spec(spec);spec.loader.exec_module(q)
read=q.read;dump=q.dump;sha=q.sha;review=q.review;PID=q.PID;SEED=q.SEED

def run(arm):
 man=read(F/'manifest.json');assert all(sha((F/f).read_bytes())==h for f,h in man['input_hashes'].items()),'Frozen input drift'
 out=P/'run'
 if out.exists():raise SystemExit('Refusing to overwrite prior run')
 if arm.startswith('after') and not (P/'AFTER-AUTHORIZED.txt').exists():raise SystemExit('Explicit parent AFTER authorization marker required')
 out.mkdir();dump(out/'source-state.json',{'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'status':subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True),'files':{f:sha((R/f).read_bytes())for f in man['source_files']}})
 env={k:v for k,v in os.environ.items() if not any(t in k.upper() for t in ['API_KEY','TOKEN','SECRET','CREDENTIAL'])};env['PYTHONDONTWRITEBYTECODE']='1'
 report={'arm':arm,'cases':[],'compositions':[],'scope':'Actual public V6 CLI and full-composition audit with offline deterministic lexical retrieval. Canonical source metadata only.'};packs={}
 for id in man['case_ids']:
  d=F/'inputs'/id;dest=out/id;dest.mkdir();cmd=[str(R/'.venv/bin/python'),str(S/'generate_photo_prompt.py'),'--seed',str(SEED),'--request-envelope-json',str(d/'envelope.json'),'--authorial-core-json',str(d/'core.json'),'--creative-controls-json',str(d/'controls.json'),'--embodiment-review-json',str(d/'review.json'),'--output-file',str(dest/'pack.json')]
  t=time.time();p=subprocess.run(cmd,cwd=R,env=env,text=True,capture_output=True);dump(dest/'cli.json',{'command':cmd,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'seconds':time.time()-t});row={'id':id,'exit_code':p.returncode,'stderr':p.stderr}
  if p.returncode==0:
   pack=read(dest/'pack.json')[0];packs[id]=pack
   row.update(contract_version=pack['contract_version'],obligation_ids=[o['id']for o in pack.get('visual_obligations',{}).get('obligations',[])],visual_concept_ids=[v['id']for v in pack.get('visual_concept_candidates',{}).get('candidates',[])],slot_candidates=[{'slot':s,'id':v['id'],'applicability':v.get('applicability')}for s,b in pack['slots'].items() for v in b.get('candidates',[])],core_retrieval_sha256=pack['core_retrieval']['canonical_sha256'],core_sha256=pack['authorial_core']['canonical_sha256'])
  report['cases'].append(row);dump(out/'report.json',report);print(arm,id,p.returncode,row.get('obligation_ids'),flush=True)
 for template in read(F/'compositions.json'):
  id=template['id'];case=template['case']
  if case not in packs:continue
  pack=packs[case];core=pack['authorial_core'];lock=core['intent_lock'];c=read(F/'inputs'/case/'spec.json');prompt=template['prompt']
  composed={'core_retrieval_sha256':pack['core_retrieval']['canonical_sha256'],'pack_id':pack['pack_id'],'prompt_en':prompt,'negative_en':pack['negative_en'],'chosen_candidate_ids':[],'chosen_visual_concept_ids':[],'composer':'agent','candidate_interpretations':[],'authorial_core_binding':{'source_authorial_core_sha256':core['canonical_sha256'],'source_intent_lock_sha256':lock['canonical_sha256'],'preserved_anchor_ids':[a['anchor_id']for a in lock['semantic_anchors']],'preserved_evidence':[],'authorial_decisions':[]},'semantic_clarification_decisions':[{'clarification_id':r['id'],'decision':'applied' if r.get('required_in_final_prompt') else 'rejected','rationale':'Preserve frozen requested food-event meaning and decline optional reinterpretation.','prompt_evidence':lock['semantic_anchors'][0]['prompt_evidence']}for r in pack.get('semantic_clarification',{}).get('candidates',[])],'creative_augmentation_brief':{'decisions':[{'candidate_id':r['id'],'decision':'rejected','rationale':'The complete requested food scene needs no optional augmentation.'}for r in pack.get('creative_augmentation',{}).get('candidates',[])]},'embodiment_review':{'source_contract_sha256':pack['embodiment_preflight']['canonical_sha256'],'review':review(prompt,c,'agent_postcomposition')}}
  if c['profile']:composed['visual_obligation_evidence']={c['profile']:template['bindings']}
  dest=out/'compositions'/id;dump(dest/'composed.json',composed)
  # Isolate evidence checks using the same real CLI pack and exact full composed input.
  direct=audit.audit_visual_obligations(pack,composed,prompt);dump(dest/'direct-visual-evidence.json',{'failures':direct,'status':'pass'if not direct else 'fail'})
  cmd=[str(R/'.venv/bin/python'),str(S/'audit_composed_prompt.py'),'--pack',str(out/case/'pack.json'),'--composed',str(dest/'composed.json')];p=subprocess.run(cmd,cwd=R,env=env,text=True,capture_output=True);dump(dest/'cli.json',{'command':cmd,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr})
  try:result=json.loads(p.stdout)
  except Exception:result={'status':'error','failures':[{'reason':p.stderr}]}
  dump(dest/'audit.json',result);report['compositions'].append({'id':id,'case':case,'status':result['status'],'expected':template['expected_after' if arm.startswith('after')else'expected_before'],'failures':result['failures'],'direct_visual_failures':direct,'warnings':result.get('warnings',[]),'chosen_candidate_ids':[],'chosen_visual_concept_ids':[],'semantic_claim_limit':'Deliberately contradictory invalid evidence is a parser boundary probe, not a coherent final scene'if template.get('contradictory_content')else'Canonical source-aware contract qualification'})
  dump(out/'report.json',report);print(id,result['status'],[(r.get('check'),r.get('field'))for r in result['failures']],flush=True)
 dump(out/'ending-source-state.json',{'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'status':subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True),'files':{f:sha((R/f).read_bytes())for f in man['source_files']}})
 print('Completed',arm,flush=True)


if __name__=='__main__':run('after-integration-90084881')
