# Single-adult allocator BEFORE readiness

Status: valid BEFORE; waiting for explicit AFTER authorization and synchronized source/index refresh.

Baseline: `7307343d` (documentation-only successor of DATA `7d1bb2a5`). The frozen revised additive proposal is used. No source correction has been applied by this qualification.

## Measured result

- Seven frozen source-aware synthetic input sets passed request/core/control/embodiment preflight on the first attempt
- All seven actual `generate_photo_prompt.py` calls produced `photo-candidate-pack/v6` successfully
- All seventeen full `audit_composed_prompt.py` outcomes match the frozen BEFORE expectations; no unrelated full-audit failures occur
- Exact English and Korean single-adult requests each emit the target hard profile and all five gates. Their canonical new one-or-group evidence fails only `active_same_source_portioning_phrase`, because current source accepts only the original group string
- The two-adult compatibility fixture uses the byte-exact original group evidence and passes the complete audit
- Four coherent controls (plentiful supply, unoccupied still life, disconnected source, and present-but-inactive allocator) each emit no target hard or optional profile and pass their ordinary full composition audit
- Four invalid active-profile evidence probes each reject at the intended required field. All five individual missing-field probes reject. These deliberately invalid binding probes are separate from the coherent controls; they do not purport to be valid scene authorship
- An ordinary singular action paraphrase without the full frozen canonical anchor remains rejected. This correction does not add general language entailment or natural-query recall
- Source bytes remained unchanged throughout BEFORE. Frozen input bytes remain intact. Working-tree status was clean after BEFORE

Full machine-readable result: `before/summary.json`. Actual CLI commands, public packs, complete compositions, direct visual-evidence checks and full-audit output are retained under `before/`.

## What this establishes

1. Metadata semantics: the reviewed proposal restores the existing source choice of one adult or an adult household group. The current single-adult exact request is already accepted by activation, but its emitted action instruction and gate still demand a group
2. Canonical binding: the appended whole one-or-group sentence, used without changing it, is presently rejected while the original group sentence is accepted. Expected AFTER recovery is only the two single-adult canonical fixtures changing to pass
3. Public emission: these are actual public V6 CLI outputs and actual full-composition audits, not isolated compiler tests. Both language cases use exact aliases and source-aware synthetic authoring. This is not a clean pre-core, language-generalization, ranking, or recall experiment
4. Image fidelity: no image was generated or inspected. Embodiment checks review text plausibility. No population-level, income, diagnosis, nutrition, housing, protected-trait or social-class inference is supported

The complete literal new anchor contains an OR between actor alternatives. Both single-adult fixtures independently lock exactly one adult, all hand ownership and source count, and explicitly state that this one adult performs the whole transfer alone. The disjunction therefore uses its single-adult branch; the fixture does not add a group. The group fixture explicitly requests exactly two adults and preserves the original anchor. No extra person, duplicate source vessel, collage or inset is introduced to satisfy a binding.

The original before-/after-allocation language is preserved as source metadata. The proposed one-frame staging supplies a sparse source, final transfer, three bounded results, adjacency and residual grains. A single still cannot independently prove the prior quantity, elapsed sequence, or origin of every grain. Neither an audit pass nor this fixture is temporal or pixel proof.

## Exposure and adoption

The target profile is hard only in the three exact-positive cases. No case exposes it as an optional visual concept. None of the seven public packs exposes a `pov_food_` ordinary candidate in this frozen request/core/ownership configuration, even though the existing source records remain available in the corpus. All compositions choose zero ordinary candidates and zero optional visual concepts. Registry eligibility, actual public candidate exposure, and semantic adoption are separate claims.

The original source candidate permits one adult despite its historical group-named ID. Its source bytes are pinned in `manifest.json`; no assertion of actual candidate exposure is inferred from that ID or source eligibility.

## Frozen ownership and preservation checks

Every core locks concept, subject and event. Participant count, one source container, ownership, requested continuity and other concrete conditions use targeted property locks; camera, lighting and other authorial craft remain open. The same request, core, controls, review, prompt, evidence and selections will be used AFTER.

`compare.py` allows exactly the expected actor-scope changes in public component matching, evidence requirements, composition instruction and one gate description. It does not demand that the intended target gate remain byte-identical. It verifies the complete revised six-operation raw source; all four untouched components; all five component IDs, evidence fields, word minimums, gate IDs and scales; old group anchors; activation/exclusions/claim limits; all other source profiles and candidate sources; and public core/count locks, unrelated gates/effects and candidate adoption. It separately records every pack leaf delta.

`source_snapshot.py` captures source-bound registry hashes, materialized profile hashes, all positive-text hashes, exact lookup/policy/provider metadata, all index-entry hashes and all BM25F document hashes. AFTER must be captured only after the parent's genuine changed-profile vector refresh. No old vector will be relabeled by this harness.

## Run and artifact policy

Only `daylong-progress-20261002/single-allocator-qualification` was written. No runtime, test, registry, candidate corpus, index, remote or deferred-watch changes were made; no provider, embedding-query or image calls occurred. CLI execution strips credential-like environment values. The frozen public V6 path uses local BM25F retrieval; the index is loaded for source-bound operation, not queried through a paid provider.

No fixture revisions were needed. Expected product/boundary failures are preserved in the raw audit artifacts. `qualify.py` refuses input drift, arm overwrites, and an AFTER run without an explicit authorization marker. The parent must finish source and index synchronization before authorizing AFTER.
