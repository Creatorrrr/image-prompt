from pathlib import Path
import hashlib,json
P=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_text())
c=read(P/'comparison-final.json');b=read(P/'before/summary.json');a=read(P/'after/summary.json')
assert c['status']=='pass',c['issues']
rows=[]
for x in c['composition_changes']:rows.append(f"| {x['id']} | {x['before']} | {x['after']} |")
source=read(P/'after-source-snapshot.json')
text='''# Single-adult allocator source correction: qualification

## Result

The revised additive DATA correction passes the frozen offline qualification. Both exact English and Korean single-adult compositions change from the same isolated action-anchor failure to a complete audit pass. The original group fixture remains a complete pass using its untouched original group anchor.

- 7/7 actual public V6 CLI cases succeed in both arms
- 17/17 full-composition outcomes match the frozen expectation in each arm
- All four coherent controls still emit no target hard or optional profile and pass ordinary composition audit
- All four deliberately invalid hard-profile boundary bindings and all five individual missing-field probes remain rejected
- The natural singular paraphrase lacking the full canonical anchor remains rejected in both arms
- Zero unrelated full-audit failures, frozen-input changes, or source drift within either arm
- No fixture rescue edits or revised expected outcomes were needed

Qualification uses the exact same source-aware synthetic requests, cores, ownership/count locks, controls, baselines, composed prompts and evidence across arms. It is not clean pre-core authorship or natural-query/recall measurement.

## Full-composition matrix

| Fixture | BEFORE | AFTER |
|---|---|---|
'''+ '\n'.join(rows)+'''

The four `boundary_` rows deliberately insert inadequate or contradictory evidence into an active profile to check rejection. They are not valid authored scene demonstrations. Separately, the four coherent ordinary control requests exercise actual no-target routing and full composition. Missing-field probes establish that none of the five relations became optional.

## Source and generated-index preservation

The current raw poverty source equals the frozen guarded six-operation RFC 6902 patch applied to the preserved baseline. Exactly the target profile changes in the materialized registry, positive text, index entry and BM25F source document. The other 1,506 profile/index records and 3,661 exact lookup rows stay unchanged.

All five component IDs, required groups, evidence fields, word minimums, gate IDs and gate review scales remain. The other four authored components are identical. The old group match and evidence anchors remain at index zero; the new complete one-or-group anchor is appended at index one. All candidate sources, runtime files, exclusions, adult requirements, definition, claim limits, substitute rejections and definition-only policy remain unchanged.

Expected public changes are limited to the target actor-scope component terms, evidence terms, one composition-instruction fragment, the corresponding gate description, and the target clarification meaning component projected from the same reviewed source term. The comparator explicitly allows these intended changes; it does not incorrectly require the changed gate text to be identical. Every other public gate/effect, ordinary candidate projection, optional concept projection, core/count lock, creative-control value, embodiment preflight, negative guard and adoption choice is unchanged. All pack leaf differences are retained in `comparison-final.json`.

The parent performed the authorized genuine Gemini target-vector refresh and rebuilt the entire source-bound index. This harness independently checked source/index registry binding and entry/text hashes before AFTER. It made no provider call, source/index edit or vector substitution. The initial authorization pause is preserved in `PAUSED.json`; it was superseded by the parent's explicit source-ready go-ahead recorded in `AFTER-AUTHORIZED.txt`.

## Eligibility, exposure and adoption

The target is hard in all three exact positives and absent as an optional target in every case, before and after. No `pov_food_` ordinary slot candidate is publicly exposed in these frozen request/core/ownership configurations. Existing source candidate eligibility therefore is not claimed as candidate exposure. All seventeen compositions choose zero ordinary candidates and zero optional visual concepts in both arms.

The source candidate’s group-named historical ID does not change its explicit one-adult-or-group scope. All source candidate bytes stay unchanged. These results establish requested hard-profile emission and canonical binding recovery; they do not claim improvement in candidate discovery, ranking, organic-language coverage, or adoption.

## Adult ownership and image limits

The English and Korean single-adult cores explicitly own exactly one adult, one source pot, the whole transfer and every visible hand. The original group core explicitly requests two adults. Participant/source counts and ownership remain unchanged in both public packs and final compositions. A single serving mat carries three bounded mounds; no duplicate source container, extra person, collage or inset is introduced.

The new canonical evidence phrase is a literal OR between one adult and an adult group. The single-adult fixtures resolve that OR using their unchanged exactly-one-adult ownership and count locks. Arbitrary shorter natural singular prose does not contain the full accepted anchor and remains unsupported by this bounded correction.

The original source, transfer, bounded-portions, continuity and depletion relation contract remains intact. Sparse source residue, a final transfer and adjacent bounded portions offer coherent single-frame staging, but a still image cannot independently prove earlier quantity, elapsed order, or the provenance of every grain. Metadata semantics, accepted literal evidence, actual public contract emission and rendered fidelity remain different levels of evidence.

No images were generated or inspected. A full prompt audit pass is not a pixel result or socioeconomic diagnosis. The profile's prohibitions on inferring income, diagnosis, nutrition, housing, protected traits, social class or population-level poverty remain unchanged.

## Preserved comparison failure and bounded correction

The first comparator unnecessarily demanded that the entire semantic-clarification block remain byte-identical. It flagged only the three positives' target `meaning_components[1]`, whose value is exactly the approved actor-scope `concept_terms[1]` replacement. The actual seven CLI and seventeen full-audit outcomes were already correct. No fixture or audit expectation changed.

The original `compare.py` and failing `comparison.json` remain intact. `COMPARISON-REVISION.md` records the diagnosis before retry. `compare_v2.py` derives just the target clarification projection from the frozen source snapshots, then requires all other clarification fields and every other public field to stay identical. The passing `comparison-final.json` retains every raw pack delta. No product change or execution rerun was used to make the comparison pass.

## Reproduction and evidence

- `manifest.json`: frozen fixture and source hashes
- `artifact-manifest-before.json`: preserved valid BEFORE artifacts
- `preflight/attempt-01/report.json`: seven first-attempt passing preflights
- `before/summary.json`, `after/summary.json`: actual public emission and all audit outcomes
- `before/`, `after/`: exact public CLI commands, output packs, complete compositions, direct evidence checks, full audits and source-state checks
- `before-source-snapshot.json`, `after-source-snapshot.json`: source-bound profile/text/index/corpus projections
- `comparison-final.json`: all exact preservation checks and public pack leaf deltas
- `source-freeze/`: reviewed proposal, guarded patch and original source projections

Run commands from the repository use its `.venv/bin/python` and set `PYTHONDONTWRITEBYTECODE=1`. `qualify.py` refuses arm overwrite and frozen-input drift; AFTER additionally requires an explicit authorization marker. Credential-like environment values are removed from subprocesses. The public V6 CLI uses offline local BM25F retrieval. Only this qualification directory was written by the qualifier; runtime, tests, source, index, remote and deferred-watch files were not edited.
'''
(P/'REPORT.md').write_text(text)
# Preserve the original pre-AFTER manifest byte-for-byte and publish a separate complete manifest.
files=sorted(f for f in P.rglob('*')if f.is_file()and f.name!='artifact-manifest.json')
(P/'artifact-manifest.json').write_text(json.dumps({'status':'qualified frozen BEFORE/AFTER','files':{str(f.relative_to(P)):hashlib.sha256(f.read_bytes()).hexdigest()for f in files}},ensure_ascii=False,indent=2)+'\n')
print('Wrote REPORT.md and',len(files),'artifact hashes')
