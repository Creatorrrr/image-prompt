#!/usr/bin/env python3
"""Exact-source and actual emission comparison; expected actor gate change is allowed."""
from pathlib import Path
import copy,hashlib,json,sys
P=Path(__file__).resolve().parent
PID='household_food_depletion_portioning_event'
SOURCE='skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations_poverty.json'
INDEX='skills/photo-prompt-image-generator/assets/photo_prompt_visual_profile_index.json'
def read(p):return json.loads(p.read_text())
def dump(p,o):p.write_text(json.dumps(o,ensure_ascii=False,indent=2)+'\n')
def diff(a,b,path=''):
 if type(a)!=type(b):return [{'path':path,'before':a,'after':b}]
 if isinstance(a,dict):
  rows=[]
  for k in sorted(set(a)|set(b)):
   if k not in a or k not in b:rows.append({'path':path+'/'+k,'before':a.get(k),'after':b.get(k)})
   else:rows.extend(diff(a[k],b[k],path+'/'+k))
  return rows
 if isinstance(a,list):
  if len(a)!=len(b):return [{'path':path,'before':a,'after':b}]
  return [r for i,(x,y)in enumerate(zip(a,b))for r in diff(x,y,path+'/'+str(i))]
 return []if a==b else [{'path':path,'before':a,'after':b}]
def replace(obj,path,value):
 parts=path.strip('/').split('/');p=obj
 for key in parts[:-1]:p=p[int(key)]if isinstance(p,list)else p[key]
 key=int(parts[-1])if isinstance(p,list)else parts[-1];p[key]=copy.deepcopy(value)
def get(obj,path):
 for key in path.strip('/').split('/'):obj=obj[int(key)]if isinstance(obj,list)else obj[key]
 return obj

def summarize(arm):
 root=P/arm;report=read(root/'report.json');man=read(P/'manifest.json');templates=read(P/'compositions.json');issues=[]
 same=all(hashlib.sha256((P/p).read_bytes()).hexdigest()==h for p,h in man['input_hashes'].items())
 summary={'arm':arm,'input_hashes_unchanged':same,'cli_cases':[],'compositions':[]}
 if not same:issues.append('Frozen inputs changed')
 for row in report['cases']:
  id=row['id']
  if row['exit_code']:
   issues.append(id+': CLI failed');continue
  pack=read(root/id/'pack.json')[0];hard=pack.get('visual_obligations',{}).get('obligations',[]);optional=pack.get('visual_concept_candidates',{}).get('candidates',[])
  target=next((x for x in hard if x['id']==PID),None);spec=read(P/'inputs'/id/'spec.json')
  item={'id':id,'exit_code':row['exit_code'],'contract_version':pack['contract_version'],'hard_profile_ids':[x['id']for x in hard],'target_optional_candidate_exposed':any(x['id']=='visual-concept:'+PID for x in optional),'optional_visual_candidate_ids':[x['id']for x in optional],'ordinary_candidate_count':len(row['slot_candidates']),'food_slot_candidates':[x for x in row['slot_candidates']if 'pov_food_'in x['id']],'expected_participant_count':spec['expected_count'],'explicit_count_lock':next((x for x in pack['authorial_core']['intent_lock']['semantic_anchors']if x.get('property')=='participant_count'),None),'selected_candidate_ids':[],'selected_visual_concept_ids':[],'target_gate_ids':[x['id']for x in(target or{}).get('render_gates',[])],'source_authorial_core_sha256':pack['authorial_core']['canonical_sha256']}
  summary['cli_cases'].append(item)
  expected=[PID]if spec['profile']else[]
  if item['hard_profile_ids']!=expected:issues.append(id+': unexpected hard profile emission')
  if item['target_optional_candidate_exposed']:issues.append(id+': unexpected optional target exposure')
  if item['contract_version']!='photo-candidate-pack/v6':issues.append(id+': wrong actual public contract')
  if spec['profile']:
   if target['component_semantics']['minimum_component_groups']!=5 or len(target['render_gates'])!=5:issues.append(id+': original five relations/gates not preserved')
  if spec['expected_count'] and item['explicit_count_lock'] is None:issues.append(id+': missing explicit count lock')
 for row in report['compositions']:
  t=next(x for x in templates if x['id']==row['id']);wanted=t['expected_after'if arm.startswith('after')else'expected_before']
  own=row['direct_visual_failures'];other=[x for x in row['failures']if x not in own]
  item={'id':row['id'],'kind':t['kind'],'status':row['status'],'expected':wanted,'direct_visual_failures':own,'other_full_audit_failures':other,'deliberately_incoherent_boundary_probe':bool(t.get('contradictory_content'))}
  summary['compositions'].append(item)
  if row['status']!=wanted:issues.append(row['id']+': unexpected full audit result')
  if other:issues.append(row['id']+': unrelated audit failure')
  if wanted=='fail':
   field=t.get('failure_field','active_same_source_portioning_phrase')
   if not own or not any(f.get('field')==field for f in own):issues.append(row['id']+': intended field failure absent')
  comp=read(root/'compositions'/row['id']/'composed.json')
  if comp['chosen_candidate_ids'] or comp['chosen_visual_concept_ids']:issues.append(row['id']+': unexpected adoption')
 if len(report['cases'])!=len(man['case_ids']):issues.append('Incomplete CLI set')
 if len(report['compositions'])!=len(templates):issues.append('Incomplete full composition set')
 start=read(root/'source-state.json');end=read(root/'ending-source-state.json');summary['source_unchanged_during_arm']=start['files']==end['files']
 if not summary['source_unchanged_during_arm']:issues.append('Source changed during arm')
 if not arm.startswith('after')and start['files']!=man['source_files']:issues.append('BEFORE differs from pinned frozen source')
 summary.update(status='pass'if not issues else'fail',issues=issues);dump(root/'summary.json',summary);return summary

def compare_after(arm):
 s=summarize(arm);issues=s['issues'][:];man=read(P/'manifest.json');bsource=read(P/'before-source-snapshot.json');asource=read(P/'after-source-snapshot.json');patch=read(P/'source-freeze/revised-rfc6902-patch.json')
 expected=copy.deepcopy(bsource['raw_source'])
 for op in patch:
  if op['op']=='test':assert get(expected,op['path'])==op['value']
  else:replace(expected,op['path'],op['value'])
 source_checks={'exact_frozen_six_source_operations':expected==asource['raw_source'],'registry_profile_ids_unchanged':set(bsource['registry_profile_sha256'])==set(asource['registry_profile_sha256']),'only_target_materialized_profile_changed':[k for k in bsource['registry_profile_sha256']if bsource['registry_profile_sha256'][k]!=asource['registry_profile_sha256'].get(k)]==[PID],'only_target_positive_text_changed':[k for k in bsource['positive_text_sha256']if bsource['positive_text_sha256'][k]!=asource['positive_text_sha256'].get(k)]==[PID],'only_target_index_entry_changed':[k for k in bsource['index_entry_sha256']if bsource['index_entry_sha256'][k]!=asource['index_entry_sha256'].get(k)]==[PID],'index_positive_text_matches_current_source':asource['index_target_entry']['text']==asource['positive_text'],'only_target_bm25f_document_changed':[k for k in bsource['bm25f_document_sha256']if bsource['bm25f_document_sha256'][k]!=asource['bm25f_document_sha256'].get(k)]==[PID]}
 bm=copy.deepcopy(bsource['index_metadata']);am=copy.deepcopy(asource['index_metadata']);bm.pop('registry_sha256');am.pop('registry_sha256');source_checks['index_policy_provider_model_dimensions_recipe_exact_lookup_unchanged']=bm==am
 bfiles=read(P/'before/source-state.json')['files'];afiles=read(P/arm/'source-state.json')['files'];changed=[k for k in bfiles if bfiles[k]!=afiles[k]]
 source_checks['all_candidate_sources_and_runtime_unchanged']=set(changed)=={SOURCE,INDEX}
 bp=bsource['profile'];ap=asource['profile'];compb=bp['authored_components']['components'];compa=ap['authored_components']['components']
 source_checks['four_other_components_byte_equivalent']=all(compb[i]==compa[i]for i in[0,2,3,4])
 source_checks['original_group_anchors_retained']=all(compa[1][key][0]==compb[1][key][0]for key in['match_terms','evidence_terms'])
 source_checks['all_five_ids_fields_minimums_gate_ids_review_scales_unchanged']=all(all(x[k]==y[k]for k in['id','evidence_field','min_content_words'])and all(x['render_gate'][k]==y['render_gate'][k]for k in['id','review_scale'])for x,y in zip(compb,compa))and len(compb)==len(compa)==5
 source_checks['activation_exclusions_runtime_rejects_claim_limits_unchanged']=all(bp[k]==ap[k]for k in['activation','runtime_expression','reject_substitutes'])and all(bp['semantics'][k]==ap['semantics'][k]for k in['definition','contrast_examples','claim_limits'])
 for k,v in source_checks.items():
  if not v:issues.append('Source invariant failed: '+k)
 out={'source_checks':source_checks,'changed_source_files':changed,'source_leaf_changes':diff(bsource['raw_source'],asource['raw_source']),'public_pack_cases':[],'composition_changes':[],'limitations':read(P/'qualification-scope.json')}
 for id in man['case_ids']:
  b=read(P/'before'/id/'pack.json')[0];a=read(P/arm/id/'pack.json')[0]
  # The exact intended obligation projection changes four surfaces; gate ID and four other gates stay fixed.
  expectedvo=copy.deepcopy(b.get('visual_obligations'))
  if expectedvo:
   for ob in expectedvo['obligations']:
    if ob['id']==PID:
     ob['component_semantics']=copy.deepcopy(ap['semantics']['component_semantics']);ob['evidence_requirements']=copy.deepcopy(ap['evidence_requirements']);ob['composition_instruction']=ap['composition_instruction'];ob['render_gates']=copy.deepcopy(ap['render_gates'])
  expectedsc=copy.deepcopy(b.get('semantic_clarification'))
  if expectedsc:
   for clarification in expectedsc.get('candidates',[]):
    if clarification.get('profile_id')==PID:
     assert clarification['meaning_components']==bp['concept_candidate']['concept_terms']
     clarification['meaning_components']=copy.deepcopy(ap['concept_candidate']['concept_terms'])
  checks={'expected_actor_scope_public_projection':expectedvo==a.get('visual_obligations'),'expected_source_derived_target_clarification':expectedsc==a.get('semantic_clarification'),'all_other_public_fields_unchanged':{k:v for k,v in b.items()if k not in ['pack_id','visual_obligations','semantic_clarification']}=={k:v for k,v in a.items()if k not in ['pack_id','visual_obligations','semantic_clarification']}}
  for k in ['slots','core_retrieval','authorial_core','embodiment_preflight','negative_en','negative_intent_guard','intent_preservation','creative_controls','visual_concept_candidates','candidate_bundles','creative_augmentation','quality_profile','photographic_integration','photographic_craft','artistic_final_touch','safety','coverage','conflicts','authorial_composition']:
   checks[k+'_unchanged']=b.get(k)==a.get(k)
  checks['unrelated_hard_obligations_and_effects_unchanged']=[x for x in b.get('visual_obligations',{}).get('obligations',[])if x['id']!=PID]==[x for x in a.get('visual_obligations',{}).get('obligations',[])if x['id']!=PID]
  for k,v in checks.items():
   if not v:issues.append(id+': failed public invariant '+k)
  out['public_pack_cases'].append({'id':id,'checks':checks,'all_pack_leaf_changes':diff(b,a)})
 for t in read(P/'compositions.json'):
  id=t['id'];b=read(P/'before/compositions'/id/'composed.json');a=read(P/arm/'compositions'/id/'composed.json');ba=read(P/'before/compositions'/id/'audit.json');aa=read(P/arm/'compositions'/id/'audit.json')
  unchanged=all(b.get(k)==a.get(k)for k in['prompt_en','negative_en','visual_obligation_evidence','chosen_candidate_ids','chosen_visual_concept_ids','authorial_core_binding','semantic_clarification_decisions','creative_augmentation_brief','embodiment_review'])
  if not unchanged:issues.append(id+': composed authorship/evidence/adoption changed')
  if ba['status']!=t['expected_before']or aa['status']!=t['expected_after']:issues.append(id+': unintended audit transition')
  out['composition_changes'].append({'id':id,'before':ba['status'],'after':aa['status'],'expected_before':t['expected_before'],'expected_after':t['expected_after'],'prompt_evidence_ownership_and_adoption_unchanged':unchanged,'before_failures':ba['failures'],'after_failures':aa['failures']})
 out.update(status='pass'if not issues else'fail',issues=issues);dump(P/'comparison-final.json',out);return out

if __name__=='__main__':
 arm=sys.argv[1];s=compare_after(arm)if arm.startswith('after')else summarize(arm)
 print(json.dumps({'status':s['status'],'issues':s['issues']},indent=2));raise SystemExit(bool(s['issues']))
