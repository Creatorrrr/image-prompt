#!/usr/bin/env python3
"""Frozen, source-aware synthetic DATA qualification. No provider or source writes."""
from pathlib import Path
import copy, hashlib, json, os, subprocess, sys, time, traceback
sys.dont_write_bytecode=True
P=Path(__file__).resolve().parent;R=P.parent.parent/'image-prompt'
S=R/'skills/photo-prompt-image-generator/scripts';A=S.parent/'assets'
sys.path.insert(0,str(S))
import prompt_generator as g
import audit_composed_prompt as audit
PID='household_food_depletion_portioning_event'
PIN='7307343d'
SEED=2003
SOURCE='skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations_poverty.json'
REVIEW=P.parent/'single-allocator-source-review'
def sha(b):return hashlib.sha256(b).hexdigest()
def read(p):return json.loads(p.read_text())
def dump(p,o):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(o,ensure_ascii=False,indent=2)+'\n')
def anchor(id,src,ev,dim,target=None,prop=None):
 o={'anchor_id':id,'source_text':src,'prompt_evidence':ev,'dimension':dim}
 if prop:o.update(target=target,property=prop)
 return o

def review(prompt,c,phase='agent_prepack'):
 if not c['people']:
  return {'contract_version':'photo-embodiment-review/v1','provenance':phase,'prompt_sha256':sha(prompt.encode()),'scope':'not_applicable','summary':'This unoccupied food still life contains one pot and three bounded servings on a stable counter. No bodies, hands, living actors, or bodily contact appear.','checks':{}}
 phrases=c['review_phrases']
 reasons=['Every visible adult and hand has explicit ownership within the fixed participant count.','Each described hand reaches only nearby equipment with a continuous forearm connection.','The adult bodies have planted feet on level flooring and the food rests on a stable counter.','The participants and objects have distinct space and physically local contact.','The chosen view keeps relevant hands, source and portions separable within one frame.']
 return {'contract_version':'photo-embodiment-review/v1','provenance':phase,'prompt_sha256':sha(prompt.encode()),'scope':'body_action','summary':'The fixed adult participant count, hand ownership, local reach, floor support and source-to-serving spatial arrangement are explicitly reviewed in prose. This is not rendered-image or elapsed-time evidence.','checks':{k:{'status':'supported','reason':r,'prompt_evidence':[e]}for k,r,e in zip(['body_ownership','joint_chain_and_reach','support_and_balance','contact_and_space','visibility_and_projection'],reasons,phrases)}}

def prepare():
 assert not(P/'drafts').exists(),'Refusing to overwrite drafts'
 head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head.startswith(PIN)
 raw=read(R/SOURCE);profile=next(x for x in raw['profiles']if x['id']==PID)
 proposal=read(REVIEW/'frozen-revised-food-proposal.json')
 assert sha(json.dumps(profile,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())==proposal['baseline_profile_sha256']
 for n in ['frozen-revised-food-proposal.json','revised-rfc6902-patch.json','reviewed-revised-food-profile.json','unchanged-boundary-requirements.json','expected-index-implications.json']:
  dump(P/'source-freeze'/n,read(REVIEW/n))
 dump(P/'source-freeze/baseline-raw-profile.json',profile)
 # Production compiler and semantic text, read only. No changed-source indexing occurs here.
 reg=g.load_visual_obligation_registry(A/'photo_prompt_visual_obligations.json')
 material=next(x for x in reg['profiles']if x['id']==PID)
 dump(P/'source-freeze/baseline-materialized-profile.json',material)
 dump(P/'source-freeze/baseline-positive-text.json',{'text':g.visual_profile_semantic_text(material),'bm25f_fields':g.visual_profile_bm25f_fields(material)})
 comps=profile['authored_components']['components'];old={x['evidence_field']:x['evidence_terms'][0]for x in comps}
 new=copy.deepcopy(old);new['active_same_source_portioning_phrase']=proposal['exact_operations'][3]['after'][1]
 cases=[]
 positive_base='Exactly one unmistakably adult person stands at a kitchen counter, performing the entire transfer alone. The scene shows the last household staple supply being divided into three bounded portions. The adult lifts the final spoonful from a sparse layer of cooked grains at the bottom of one source pot and lowers it toward the third small mound on a single serving mat immediately beside the pot. The pot interior has a scraped base and only a few clinging grains; the three separate mounds and short falling grain path remain visible together. Every visible hand belongs to this same adult. The right hand grips one ladle close to the pot and the left hand steadies its handle. Both feet rest on the level kitchen floor. The one pot and single mat sit securely on the counter within easy reach. An oblique waist-high view separates the adult hands, pot interior and all three mounds in one continuous frame. Soft window light preserves the grain texture and the sparse residue.'
 enreq='Photograph an adult portions the last visible staple supply from one source container across several meals in the same frame. Exactly one unmistakably adult person performs the entire transfer alone. Use one source pot with only a sparse layer of cooked grains remaining. The adult lifts the final spoonful toward three bounded portions on one serving mat immediately beside the pot. Keep every portion physically connected to that same source through the adjacent layout and visible final transfer; the source ends nearly empty. All visible hands belong to the same adult. Show one continuous frame.'
 enanchors=[anchor('concept',profile['activation']['exact_terms'][1],'last household staple supply being divided into three bounded portions','concept'),anchor('subject','Exactly one unmistakably adult person','Exactly one unmistakably adult person','subject'),anchor('event','The adult lifts the final spoonful','The adult lifts the final spoonful','event'),anchor('participant_count','Exactly one unmistakably adult person performs the entire transfer alone','Exactly one unmistakably adult person stands at a kitchen counter, performing the entire transfer alone','composition','scene','participant_count'),anchor('source_count','one source pot','one source pot','composition','food_source','container_count'),anchor('source_condition','only a sparse layer of cooked grains remaining','a sparse layer of cooked grains at the bottom','material','food_source','available_supply'),anchor('portions','three bounded portions on one serving mat','three separate mounds','composition','result','bounded_portion_count'),anchor('continuity','every portion physically connected to that same source','the three separate mounds and short falling grain path remain visible together','relationship','food','source_portion_continuity'),anchor('ownership','All visible hands belong to the same adult','Every visible hand belongs to this same adult','body_geometry','adult','hand_ownership'),anchor('frame','one continuous frame','one continuous frame','composition','photograph','single_frame')]
 phrases=['Every visible hand belongs to this same adult','The right hand grips one ladle close to the pot and the left hand steadies its handle','Both feet rest on the level kitchen floor','The one pot and single mat sit securely on the counter within easy reach','An oblique waist-high view separates the adult hands, pot interior and all three mounds in one continuous frame']
 cases.append(dict(id='single_en',request=enreq,baseline=positive_base,anchors=enanchors,subject='exactly one unmistakably adult person',event='one adult transfers the last sparse staple supply into three bounded portions',setting='a kitchen counter with one source pot and one serving mat',profile=PID,people=True,review_phrases=phrases,expected_count=1,language='en'))
 koreq='남은 주식 한 용기를 같은 프레임의 여러 끼 분량으로 나누어 두는 성인을 촬영한다. 명백한 성인 한 명만 전체 옮기기를 혼자 수행한다. 공급원 냄비는 하나이며 바닥에 익힌 곡물이 얇게 남아 있다. 그 성인이 마지막 한 숟갈을 냄비 바로 옆 한 장의 받침 위 세 몫으로 옮긴다. 각 몫은 인접한 배치와 마지막 옮기기 동작을 통해 같은 공급원과 연결되고 냄비는 거의 비어 있다. 보이는 모든 손은 그 한 성인의 손이다. 연속된 단일 프레임으로 보여 준다.'
 koanchors=[anchor('concept',profile['activation']['exact_terms'][3],'last household staple supply being divided into three bounded portions','concept'),anchor('subject','명백한 성인 한 명만','Exactly one unmistakably adult person','subject'),anchor('event','그 성인이 마지막 한 숟갈을','The adult lifts the final spoonful','event'),anchor('participant_count','명백한 성인 한 명만 전체 옮기기를 혼자 수행한다','Exactly one unmistakably adult person stands at a kitchen counter, performing the entire transfer alone','composition','scene','participant_count'),anchor('source_count','공급원 냄비는 하나','one source pot','composition','food_source','container_count'),anchor('source_condition','바닥에 익힌 곡물이 얇게 남아 있다','a sparse layer of cooked grains at the bottom','material','food_source','available_supply'),anchor('portions','한 장의 받침 위 세 몫','three separate mounds','composition','result','bounded_portion_count'),anchor('continuity','각 몫은 인접한 배치와 마지막 옮기기 동작을 통해 같은 공급원과 연결','the three separate mounds and short falling grain path remain visible together','relationship','food','source_portion_continuity'),anchor('ownership','보이는 모든 손은 그 한 성인의 손','Every visible hand belongs to this same adult','body_geometry','adult','hand_ownership'),anchor('frame','연속된 단일 프레임','one continuous frame','composition','photograph','single_frame')]
 cases.append(dict(id='single_ko',request=koreq,baseline=positive_base,anchors=koanchors,subject='exactly one unmistakably adult person',event='one adult transfers the last sparse staple supply into three bounded portions',setting='a kitchen counter with one source pot and one serving mat',profile=PID,people=True,review_phrases=phrases,expected_count=1,language='ko'))
 greq='Photograph adults divide the nearly depleted contents of one household food container into several bounded portions, leaving the source visibly empty. Exactly two unmistakably adult household members coordinate the division. One adult transfers the last spoonful from one source pot while the second adult steadies one serving mat beside it. Three separate grain mounds stay immediately adjacent to the same scraped pot, with the final transfer visible. Each hand belongs to its own adult. Show one continuous frame.'
 gbase='Exactly two unmistakably adult household members coordinate the division of the last household staple supply. One adult transfers the last spoonful from one source pot while the second adult steadies one serving mat beside it. Three separate grain mounds stay immediately adjacent to the same scraped pot, with the final transfer visible. The sparse layer at the pot bottom is nearly exhausted, leaving only clinging grains beneath the final spoonful. Each hand belongs to its own adult. The first adult grips the ladle near the pot, while the second adult holds the nearby mat edge. Both adults stand with their feet planted on the level kitchen floor. Clear space separates their bodies and each arm stays within its own working area. An oblique waist-high view shows both adults, the pot interior and every mound in one continuous frame. Soft side light reveals the sparse residue and the grain path.'
 ga=[anchor('concept',profile['activation']['exact_terms'][0],'division of the last household staple supply','concept'),anchor('subject','two unmistakably adult household members','two unmistakably adult household members','subject'),anchor('event','One adult transfers the last spoonful','One adult transfers the last spoonful','event'),anchor('participant_count','Exactly two unmistakably adult household members','Exactly two unmistakably adult household members','composition','scene','participant_count'),anchor('source_count','one source pot','one source pot','composition','food_source','container_count'),anchor('portions','Three separate grain mounds','Three separate grain mounds','composition','result','bounded_portion_count'),anchor('continuity','immediately adjacent to the same scraped pot, with the final transfer visible','immediately adjacent to the same scraped pot, with the final transfer visible','relationship','food','source_portion_continuity'),anchor('ownership','Each hand belongs to its own adult','Each hand belongs to its own adult','body_geometry','adults','hand_ownership'),anchor('frame','one continuous frame','one continuous frame','composition','photograph','single_frame')]
 gp=['Each hand belongs to its own adult','The first adult grips the ladle near the pot, while the second adult holds the nearby mat edge','Both adults stand with their feet planted on the level kitchen floor','Clear space separates their bodies and each arm stays within its own working area','An oblique waist-high view shows both adults, the pot interior and every mound in one continuous frame']
 cases.append(dict(id='group_original',request=greq,baseline=gbase,anchors=ga,subject='exactly two unmistakably adult household members',event='two adults coordinate the final same-pot allocation into three bounded portions',setting='a kitchen counter with one source pot and one serving mat',profile=PID,people=True,review_phrases=gp,expected_count=2,language='en'))
 controls=[
 ('plentiful_source','abundant household grain supply','Exactly one unmistakably adult person','actively serves three portions from a full source pot','The full pot remains visibly plentiful after the serving','The adult keeps both hands close to the ladle and pot handle','Both feet rest on the level kitchen floor','The one pot and serving mat rest securely on the counter','An oblique view separates the adult hands, full pot and three portions',1),
 ('still_life','unoccupied food still life','one nearly empty source pot','sits beside three bounded grain portions on a single mat','The pot and portions are motionless and nobody appears',None,None,None,None,0),
 ('disconnected_source','visually disconnected food arrangement','Exactly one unmistakably adult person','lifts a final spoonful above one nearly empty source pot','A solid upright screen blocks the spatial connection between the pot and three grain mounds on one mat beyond it','The adult keeps both hands near the pot, with the right hand gripping a ladle','Both feet rest on the level kitchen floor','The pot rests securely on a counter and the separated mat stays beyond the screen','A wide view shows the adult hands and the spatial screen concealing the connection',1),
 ('no_active_allocator','inactive household food arrangement','Exactly one unmistakably adult person','rests beside one nearly empty pot and three bounded grain portions','The adult keeps both hands resting away from the food without any transfer','The adult rests both forearms locally on the counter edge','Both feet rest on the level kitchen floor','The pot and single serving mat remain stable and out of hand contact','An oblique view shows the adult resting hands apart from the food',1)]
 for id,concept,sub,event,condition,reach,support,space,visibility,count in controls:
  req=f'Photograph an {concept}. {sub} {event}. {condition}. Show one continuous frame.'
  base=f'An {concept} fills a quiet kitchen-counter photograph. {sub} {event}. {condition}. '
  if count:
   ownership='Every visible hand belongs to this same adult';base+=ownership+'. '+'. '.join([reach,support,space,visibility])+'. '
   rp=[ownership,reach,support,space,visibility]
  else:rp=[]
  base+='Soft window light describes the pot surface and separate grain textures. The plain counter supports the entire arrangement in one continuous frame, with no inset views or duplicate source vessels. The photographic treatment keeps the requested food state clear and does not attach a socioeconomic diagnosis to it.'
  aa=[anchor('concept',concept,concept,'concept'),anchor('subject',sub,sub,'subject'),anchor('event',event,event,'event'),anchor('condition',condition,condition,'relationship','food_event','control_boundary'),anchor('frame','one continuous frame','one continuous frame','composition','photograph','single_frame')]
  if count:aa.append(anchor('participant_count',sub,sub,'composition','scene','participant_count'))
  cases.append(dict(id=id,request=req,baseline=base,anchors=aa,subject=sub,event=event,setting='a kitchen counter containing the requested food arrangement',profile=None,people=bool(count),review_phrases=rp,expected_count=count,language='en'))
 templates=[]
 for c in cases:
  req=c['request'];base=c['baseline'];d=P/'drafts'/c['id']
  env={'contract_version':'photo-request-envelope/v1','provenance':'requesting_user','request_id':'synthetic-single-allocator-'+c['id'],'request_text':req,'request_sha256':sha(req.encode()),'active_spans':[{'span_id':'scene','start':0,'end':len(req),'text':req}]}
  controls=g.creative_controls.resolve(req,overrides={'sensual':0,'fetish':0,'creativity':0,'surreal':0},context={'subject_category':'human'if c['people']else'nonhuman','no_people':not c['people']},seed=SEED)
  core={'contract_version':'photo-authorial-core/v3','provenance':'agent_prepack','source_request':req,'creative_controls_sha256':controls['canonical_sha256'],'interpreted_intent':'A source-aware synthetic contract photograph of '+c['event']+'. Preserve requested participant and source count, concrete allocation state, and body ownership; craft choices remain open.','subject':c['subject'],'setting':c['setting'],'event':c['event'],'visual_priorities':[c['subject'],c['event'],'readable source and portion arrangement'],'baseline_prompt_en':base,'user_definitions':[],'interpretation_provenance':[{'term':'synthetic food allocation request','source_text':req,'basis':'request_context','resolution':'Show '+c['event']+' with the requested count and concrete food arrangement.','sources':[]}],'unresolved_ambiguities':[],'user_exclusions':[],'runtime_forbidden_labels':[],'intent_lock':{'contract_version':'photo-intent-lock/v2','priority':'requesting_user','semantic_anchors':c['anchors'],'locked_dimensions':['concept','subject','event'],'open_dimensions':['setting','appearance','pose','body_geometry','material','framing','composition','lighting','camera','color','atmosphere','relationship']},'semantic_assertions':[],'request_lineage':None,'style':{'domain':'general_photo','family':'context-led household food photograph','evidence':['clear material surfaces','legible local action']} ,'variation_key':'allocator-data-'+c['id']}
  for name,obj in [('envelope',env),('controls',controls),('core',core),('review',review(base,c)),('spec',c)]:dump(d/(name+'.json'),obj)
  bindings=old if c['id']=='group_original'else new if c['profile']else{}
  # Full canonical phrase is a literal source contract. Explicit count in base resolves the OR to one adult.
  prompt=base+(' '+'. '.join(bindings.values())+'.' if bindings else '')
  templates.append({'id':c['id'],'case':c['id'],'prompt':prompt,'bindings':bindings,'expected_before':'fail'if c['id'].startswith('single_')else'pass','expected_after':'pass','purpose':'canonical exact-request qualification'if bindings else'meaningful ordinary near-negative routing control','kind':'positive'if bindings else'ordinary_control'})
 # Hard-profile parser boundaries use the original group pack to avoid confounding the absent new anchor.
 # Their prompt/evidence intentionally conflict with the positive core. They test rejection, not valid scene authorship.
 invalid=[('plentiful_source','single_nearly_depleted_source_phrase','The source pot begins full with an abundant supply and remains plentiful during allocation'),('still_life','active_same_source_portioning_phrase','The motionless pot and arranged servings form a still life with nobody present'),('disconnected_source','source_to_portion_continuity_phrase','An opaque screen separates every portion from the pot so the source relationship cannot be traced'),('no_active_allocator','active_same_source_portioning_phrase','The adults stand with their hands resting away from the food and make no allocation')]
 for id,field,value in invalid:
  ev=copy.deepcopy(old);ev[field]=value
  templates.append({'id':'boundary_'+id,'case':'group_original','prompt':gbase+' '+'. '.join(ev.values())+'.','bindings':ev,'expected_before':'fail','expected_after':'fail','purpose':'Reject missing required canonical relation: '+field,'kind':'invalid_binding_probe','contradictory_content':True,'failure_field':field})
 for field in old:
  ev=copy.deepcopy(old);del ev[field]
  templates.append({'id':'missing_'+field,'case':'group_original','prompt':gbase+' '+'. '.join(ev.values())+'.','bindings':ev,'expected_before':'fail','expected_after':'fail','purpose':'Every original field remains required','kind':'invalid_binding_probe','failure_field':field})
 ev=copy.deepcopy(new);ev['active_same_source_portioning_phrase']='One adult alone transfers the final spoonful from the same source pot into three bounded portions'
 templates.append({'id':'natural_singular_limit','case':'single_en','prompt':positive_base+' '+'. '.join(ev.values())+'.','bindings':ev,'expected_before':'fail','expected_after':'fail','purpose':'Natural singular prose does not contain the frozen whole canonical OR anchor','kind':'natural_language_limit','failure_field':'active_same_source_portioning_phrase'})
 dump(P/'compositions.draft.json',templates)
 dump(P/'qualification-scope.json',{'synthetic_source_aware':True,'clean_precore':False,'natural_query_recall_experiment':False,'no_extra_people_or_duplicate_source_vessels':True,'canonical_disjunction_note':'The exact new one-or-group string is synthetic literal evidence. The explicit single-person scene/count/ownership lock fixes its one-adult branch; no group is added.','temporal_limit':'The canonical source contract retains before-allocation and after-allocation wording. One still frame depicts sparse residue, final transfer and bounded portions but cannot independently prove temporal order, prior quantity, or the history of every grain. No temporal or pixel validation is claimed.','claim_limits':profile['semantics']['claim_limits'],'control_layers':['ordinary coherent request/CLI/composition routing','deliberately invalid active-profile evidence binding probes, not coherent authored scenes'],'provider_calls':0,'images':0})
 print('Prepared',len(cases),'drafts and',len(templates),'composition templates')

def preflight():
 n=len(list((P/'preflight').glob('attempt-*')))+1;out=P/'preflight'/f'attempt-{n:02d}';out.mkdir(parents=True)
 rows=[]
 for d in sorted((P/'drafts').iterdir()):
  row={'id':d.name}
  for f in d.glob('*.json'):dump(out/d.name/f.name,read(f))
  try:
   env=g.load_request_envelope_arg(str(d/'envelope.json'));controls=read(d/'controls.json')
   core=g.load_authorial_core_arg(str(d/'core.json'),request_envelope=env,creative_control_snapshot=controls)
   policy=g.photo_embodiment.build_policy(core,read(d/'review.json'))
   row.update(status='pass',core_sha256=core['canonical_sha256'],lock_sha256=core['intent_lock']['canonical_sha256'],embodiment_contract=policy)
  except Exception as e:row.update(status='fail',error=str(e),traceback=traceback.format_exc())
  rows.append(row)
 dump(out/'report.json',rows);print(json.dumps([{'id':r['id'],'status':r['status'],'error':r.get('error')}for r in rows],indent=2));return rows

def freeze():
 assert not(P/'manifest.json').exists(),'Refusing to overwrite frozen manifest'
 rows=preflight();assert all(x['status']=='pass'for x in rows),'Preflight failed'
 for f in(P/'drafts').rglob('*.json'):dump(P/'inputs'/f.relative_to(P/'drafts'),read(f))
 dump(P/'compositions.json',read(P/'compositions.draft.json'))
 source_files=sorted(set(list(A.glob('*.json'))+list(S.glob('*.py'))+list((S.parent/'precore').glob('*.*'))))
 hashes={str(p.relative_to(R)):sha(p.read_bytes())for p in source_files if p.is_file()}
 source_artifacts=list((P/'source-freeze').rglob('*.json'))
 inputs=list((P/'inputs').rglob('*.json'))+[P/'compositions.json',P/'qualification-scope.json']+source_artifacts
 man={'baseline_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'synthetic_canonical_source_metadata_qualification':True,'wire_provenance_note':'Production requesting_user and agent_prepack enums exercise actual CLI with synthetic source-aware fixtures, not clean pre-core or organic query qualification.','offline':True,'provider_calls':0,'case_ids':sorted(d.name for d in(P/'inputs').iterdir()),'source_files':hashes,'input_hashes':{str(p.relative_to(P)):sha(p.read_bytes())for p in inputs}}
 assert man['baseline_head'].startswith(PIN)
 dump(P/'manifest.json',man);print('Frozen valid inputs:',len(man['case_ids']))

def run(arm):
 man=read(P/'manifest.json');assert all(sha((P/f).read_bytes())==h for f,h in man['input_hashes'].items()),'Frozen input drift'
 out=P/arm
 if out.exists():raise SystemExit('Refusing to overwrite prior run')
 if arm.startswith('after') and not (P/'AFTER-AUTHORIZED.txt').exists():raise SystemExit('Explicit parent AFTER authorization marker required')
 out.mkdir();dump(out/'source-state.json',{'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'status':subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True),'files':{f:sha((R/f).read_bytes())for f in man['source_files']}})
 env={k:v for k,v in os.environ.items() if not any(t in k.upper() for t in ['API_KEY','TOKEN','SECRET','CREDENTIAL'])};env['PYTHONDONTWRITEBYTECODE']='1'
 report={'arm':arm,'cases':[],'compositions':[],'scope':'Actual public V6 CLI and full-composition audit with offline deterministic lexical retrieval. Canonical source metadata only.'};packs={}
 for id in man['case_ids']:
  d=P/'inputs'/id;dest=out/id;dest.mkdir();cmd=[str(R/'.venv/bin/python'),str(S/'generate_photo_prompt.py'),'--seed',str(SEED),'--request-envelope-json',str(d/'envelope.json'),'--authorial-core-json',str(d/'core.json'),'--creative-controls-json',str(d/'controls.json'),'--embodiment-review-json',str(d/'review.json'),'--output-file',str(dest/'pack.json')]
  t=time.time();p=subprocess.run(cmd,cwd=R,env=env,text=True,capture_output=True);dump(dest/'cli.json',{'command':cmd,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'seconds':time.time()-t});row={'id':id,'exit_code':p.returncode,'stderr':p.stderr}
  if p.returncode==0:
   pack=read(dest/'pack.json')[0];packs[id]=pack
   row.update(contract_version=pack['contract_version'],obligation_ids=[o['id']for o in pack.get('visual_obligations',{}).get('obligations',[])],visual_concept_ids=[v['id']for v in pack.get('visual_concept_candidates',{}).get('candidates',[])],slot_candidates=[{'slot':s,'id':v['id'],'applicability':v.get('applicability')}for s,b in pack['slots'].items() for v in b.get('candidates',[])],core_retrieval_sha256=pack['core_retrieval']['canonical_sha256'],core_sha256=pack['authorial_core']['canonical_sha256'])
  report['cases'].append(row);dump(out/'report.json',report);print(arm,id,p.returncode,row.get('obligation_ids'),flush=True)
 for template in read(P/'compositions.json'):
  id=template['id'];case=template['case']
  if case not in packs:continue
  pack=packs[case];core=pack['authorial_core'];lock=core['intent_lock'];c=read(P/'inputs'/case/'spec.json');prompt=template['prompt']
  composed={'core_retrieval_sha256':pack['core_retrieval']['canonical_sha256'],'pack_id':pack['pack_id'],'prompt_en':prompt,'negative_en':pack['negative_en'],'chosen_candidate_ids':[],'chosen_visual_concept_ids':[],'composer':'agent','candidate_interpretations':[],'authorial_core_binding':{'source_authorial_core_sha256':core['canonical_sha256'],'source_intent_lock_sha256':lock['canonical_sha256'],'preserved_anchor_ids':[a['anchor_id']for a in lock['semantic_anchors']],'preserved_evidence':[],'authorial_decisions':[]},'semantic_clarification_decisions':[{'clarification_id':r['id'],'decision':'applied' if r.get('required_in_final_prompt') else 'rejected','rationale':'Preserve frozen requested food-event meaning and decline optional reinterpretation.','prompt_evidence':lock['semantic_anchors'][0]['prompt_evidence']}for r in pack.get('semantic_clarification',{}).get('candidates',[])],'creative_augmentation_brief':{'decisions':[{'candidate_id':r['id'],'decision':'rejected','rationale':'The complete requested food scene needs no optional augmentation.'}for r in pack.get('creative_augmentation',{}).get('candidates',[])]},'embodiment_review':{'source_contract_sha256':pack['embodiment_preflight']['canonical_sha256'],'review':review(prompt,c,'agent_postcomposition')}}
  if c['profile']:composed['visual_obligation_evidence']={c['profile']:template['bindings']}
  dest=out/'compositions'/id;dump(dest/'composed.json',composed)
  # Isolate evidence checks using the same real CLI pack and exact full composed input.
  direct=audit.audit_visual_obligations(pack,composed,prompt);dump(dest/'direct-visual-evidence.json',{'failures':direct,'status':'pass'if not direct else 'fail'})
  cmd=[str(R/'.venv/bin/python'),str(S/'audit_composed_prompt.py'),'--pack',str(out/case/'pack.json'),'--composed',str(dest/'composed.json')];p=subprocess.run(cmd,cwd=R,env=env,text=True,capture_output=True);dump(dest/'cli.json',{'command':cmd,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr})
  try:result=json.loads(p.stdout)
  except Exception:result={'status':'error','failures':[{'reason':p.stderr}]}
  dump(dest/'audit.json',result);report['compositions'].append({'id':id,'case':case,'status':result['status'],'expected':template['expected_after' if arm.startswith('after')else'expected_before'],'failures':result['failures'],'direct_visual_failures':direct,'warnings':result.get('warnings',[]),'chosen_candidate_ids':[],'chosen_visual_concept_ids':[],'semantic_claim_limit':'Deliberately contradictory invalid evidence is a parser boundary probe, not a coherent final scene'if template.get('contradictory_content')else'Canonical source-aware contract qualification'})
  dump(out/'report.json',report);print(id,result['status'],[(r.get('check'),r.get('field'))for r in result['failures']],flush=True)
 dump(out/'ending-source-state.json',{'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'status':subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True),'files':{f:sha((R/f).read_bytes())for f in man['source_files']}})
 print('Completed',arm,flush=True)

if __name__=='__main__':
 action=sys.argv[1]
 if action=='prepare':prepare()
 elif action=='preflight':preflight()
 elif action=='freeze':freeze()
 else:run(action)
