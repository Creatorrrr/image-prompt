from pathlib import Path
import copy, hashlib, json, sys
sys.dont_write_bytecode=True
P=Path(__file__).resolve().parent;R=P.parent.parent/'image-prompt';sys.path.insert(0,str(R/'skills/photo-prompt-image-generator/scripts'))
import prompt_generator as g
from visual_profile_contracts import compile_visual_profile
A=R/'skills/photo-prompt-image-generator/assets';PID='household_food_depletion_portioning_event'
def read(p):return json.loads(p.read_text())
def canon(j):return json.dumps(j,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
def sha(j):return hashlib.sha256(canon(j)).hexdigest()
def dump(p,j):p.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
arm=sys.argv[1];out=P/(arm+'-source-snapshot.json');assert not out.exists()
registry=g.load_visual_obligation_registry(A/'photo_prompt_visual_obligations.json');index=read(A/'photo_prompt_visual_profile_index.json');target=next(x for x in registry['profiles']if x['id']==PID)
assert index['registry_sha256']==g.visual_profile_registry_sha256(registry)
dump(out,{'raw_source':read(A/'photo_prompt_visual_obligations_poverty.json'),'profile':target,'registry_sha256':g.visual_profile_registry_sha256(registry),'registry_profile_sha256':{x['id']:sha(x)for x in registry['profiles']},'positive_text_sha256':{x['id']:hashlib.sha256(g.visual_profile_semantic_text(x).encode()).hexdigest()for x in registry['profiles']},'index_metadata':{k:v for k,v in index.items()if k not in['entries','bm25f']},'index_entry_sha256':{k:sha(v)for k,v in index['entries'].items()},'index_target_entry':index['entries'][PID],'bm25f_metadata':{k:v for k,v in index['bm25f'].items()if k not in ['documents','document_frequencies','lexicon']},'bm25f_document_sha256':{k:sha(v)for k,v in index['bm25f']['documents'].items()},'bm25f_full_sha256':sha(index['bm25f']),'positive_text':g.visual_profile_semantic_text(target)})
print(out.name)
