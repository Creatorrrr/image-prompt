from pathlib import Path
import copy, hashlib, json, subprocess, sys

ROOT=Path('REPOSITORY_ROOT')
OUT=ROOT.parent/'daylong-progress-20261002/single-allocator-source-review'
ORIGINAL=ROOT.parent/'daylong-progress-20261002/food-object-process-audit/frozen-adjacent-food-proposal.json'
PIN='7d1bb2a5104198804512b2b93082f9a100ee7238'
A='skills/photo-prompt-image-generator/assets/'
SOURCE=A+'photo_prompt_visual_obligations_poverty.json'
TARGET='household_food_depletion_portioning_event'
sys.dont_write_bytecode=True
sys.path.insert(0,str(ROOT/'skills/photo-prompt-image-generator/scripts'))
from visual_profile_contracts import compile_visual_profile
from photo_visual_retrieval import positive_visual_profile_fields, positive_visual_profile_text
from prompt_generator import load_visual_obligation_registry, visual_profile_registry_sha256, visual_profile_exact_term_rows

def canonical(x): return json.dumps(x, ensure_ascii=False, sort_keys=True, separators=(',',':')).encode()
def sha(x): return hashlib.sha256(x).hexdigest()
def recordsha(x): return sha(canonical(x))
def write(name,x): (OUT/name).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def at(x,path):
    for key in path.strip('/').split('/'):
        x=x[int(key)] if isinstance(x,list) else x[key]
    return x

def replace(x,path,value):
    parts=path.strip('/').split('/')
    parent=x
    for key in parts[:-1]: parent=parent[int(key)] if isinstance(parent,list) else parent[key]
    key=int(parts[-1]) if isinstance(parent,list) else parts[-1]
    parent[key]=copy.deepcopy(value)

head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
assert head==PIN
initial_status=subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,text=True)
assert initial_status==''
source_doc=json.loads((ROOT/SOURCE).read_bytes())
idx=next(i for i,p in enumerate(source_doc['profiles']) if p['id']==TARGET)
baseline=source_doc['profiles'][idx]
original=json.loads(ORIGINAL.read_bytes())
assert recordsha(baseline)==original['baseline_profile_sha256']
proposed=copy.deepcopy(baseline)
for operation in original['exact_operations']:
    assert operation['op']=='replace'
    assert at(proposed,operation['path'])==operation['before']
    replace(proposed,operation['path'],operation['after'])
assert recordsha(proposed)==original['reviewed_profile_sha256']
old=baseline['authored_components']['components'][1]['match_terms'][0]
new=proposed['authored_components']['components'][1]['match_terms'][0]
revised=copy.deepcopy(baseline)
operations=[]
for operation in original['exact_operations']:
    operation=copy.deepcopy(operation)
    if operation['path'] in ['/authored_components/components/1/match_terms/0','/authored_components/components/1/evidence_terms/0']:
        operation['path']=operation['path'][:-2]
        operation['before']=[old]
        operation['after']=[old,new]
    assert at(revised,operation['path'])==operation['before']
    replace(revised,operation['path'],operation['after'])
    operations.append(operation)
assert len(operations)==6
for name in ('activation','runtime_expression','reject_substitutes','id','category'):
    assert baseline[name]==revised[name]
for name in ('definition','claim_limits','contrast_examples'):
    assert baseline['semantics'][name]==revised['semantics'][name]
for component_index in [0,2,3,4]:
    assert baseline['authored_components']['components'][component_index]==revised['authored_components']['components'][component_index]
for name in ('id','evidence_field','min_content_words'):
    assert baseline['authored_components']['components'][1][name]==revised['authored_components']['components'][1][name]
for name in ('id','review_scale'):
    assert baseline['authored_components']['components'][1]['render_gate'][name]==revised['authored_components']['components'][1]['render_gate'][name]
compiled={name:compile_visual_profile(profile) for name,profile in [('baseline',baseline),('original_replacement',proposed),('revised_additive',revised)]}
field='active_same_source_portioning_phrase'
source_projection={}
for name,p in compiled.items():
    group=next(g for g in p['semantics']['component_semantics']['groups'] if g['id']=='active_same_source_portioning')
    anchors=p['evidence_requirements'][field]['must_mention_any']
    source_projection[name]={
       'raw_profile_sha256':recordsha({'baseline':baseline,'original_replacement':proposed,'revised_additive':revised}[name]),
       'compiled_profile_sha256':recordsha(p),
       'component_semantics':p['semantics']['component_semantics'],
       'required_evidence_fields':p['required_evidence_fields'],
       'action_evidence_requirement':p['evidence_requirements'][field],
       'action_render_gate':p['render_gates'][1],
       'composition_instruction':p['composition_instruction'],
       'legacy_group_string_is_preserved_in_match_terms':old in group['any_terms'],
       'legacy_group_string_is_preserved_in_evidence_terms':old in anchors,
       'legacy_group_literal_contains_an_accepted_anchor':any(anchor.casefold() in old.casefold() for anchor in anchors),
       'one_or_group_literal_contains_an_accepted_anchor':any(anchor.casefold() in new.casefold() for anchor in anchors),
       'positive_fields':positive_visual_profile_fields(p),
       'positive_text':positive_visual_profile_text(p),
       'positive_text_sha256':sha(positive_visual_profile_text(p).encode()),
    }
write('source-projections.json',{'review_level':'pure source compilation and deterministic string/set comparison, not runtime qualification','results':source_projection})

registry=load_visual_obligation_registry(ROOT/A/'photo_prompt_visual_obligations.json')
revised_registry=copy.deepcopy(registry)
registry_target_index=next(i for i,p in enumerate(registry['profiles']) if p['id']==TARGET)
assert registry['profiles'][registry_target_index]==compiled['baseline']
revised_registry['profiles'][registry_target_index]=compiled['revised_additive']
changed_texts=[p['id'] for p,q in zip(registry['profiles'],revised_registry['profiles']) if positive_visual_profile_text(p)!=positive_visual_profile_text(q)]
changed_documents=[p['id'] for p,q in zip(registry['profiles'],revised_registry['profiles']) if positive_visual_profile_fields(p)!=positive_visual_profile_fields(q)]
assert changed_texts==[TARGET] and changed_documents==[TARGET]
assert visual_profile_exact_term_rows(registry)==visual_profile_exact_term_rows(revised_registry)
index=json.loads((ROOT/A/'photo_prompt_visual_profile_index.json').read_bytes())
assert index['registry_sha256']==visual_profile_registry_sha256(registry)
assert index['entries'][TARGET]['text']==positive_visual_profile_text(compiled['baseline'])
unchanged_registry_metadata=all(registry[k]==revised_registry[k] for k in registry if k!='profiles')
write('expected-index-implications.json',{
  'status':'source-derived expectations only; no index written or provider invoked',
  'current_registry_sha256':visual_profile_registry_sha256(registry),
  'proposed_registry_sha256':visual_profile_registry_sha256(revised_registry),
  'current_index_registry_hash_matches_source':True,
  'registry_profile_count':len(registry['profiles']),
  'changed_profile_positive_text_ids':changed_texts,
  'changed_bm25f_document_ids':changed_documents,
  'changed_positive_fields':[k for k in positive_visual_profile_fields(compiled['baseline']) if positive_visual_profile_fields(compiled['baseline'])[k]!=positive_visual_profile_fields(compiled['revised_additive'])[k]],
  'target_positive_text_before_sha256':source_projection['baseline']['positive_text_sha256'],
  'target_positive_text_after_sha256':source_projection['revised_additive']['positive_text_sha256'],
  'exact_lookup_unchanged':True,
  'exact_lookup_rows':len(visual_profile_exact_term_rows(registry)),
  'registry_metadata_and_policies_unchanged':unchanged_registry_metadata,
  'provider':index['provider'],'embedding_model':index['embedding_model'],'embedding_dimensions':index['embedding_dimensions'],
  'semantic_text_recipe':index['semantic_text_recipe'],
  'expected_vector_cache_behavior':'The target text changes, so the current target vector must not be reused under the new text hash. Other profile texts are identical and remain reusable if provider/model/dimensions match. One fresh target embedding is expected absent an exact-text cache hit, followed by the normal complete index rebuild.',
  'bm25f_note':'Rebuild the complete BM25F payload and its metadata: one authored document changes, but aggregate statistics/postings and related ranking scores can also change. Do not hand-edit only the target entry.',
  'backward_compatibility_limit':'Legacy group evidence anchor text remains accepted by the revised declaration. Old registry/index hashes and persisted pack lineage are not promised byte-compatible; regenerate/rebind through supported flow after authorized application.',
  'not_claimed':['no retrieval ranking or recall measured','no embedding provider call','no new index generated','no public CLI/prompt audit executed','no image or pixel validation']
})

boundaries=[
 'Modify only the six recorded operation paths for the selected profile; retain every other profile, candidate record and runtime file byte-for-byte.',
 'Keep all four current exact activation strings, all six exclusions, requires_adult_character=true and semantic_discovery_requires_component_evidence=true.',
 'Keep definition, contrast examples, reject_substitutes, claim limits and the second paraphrase unchanged.',
 'Keep a visibly adult active allocator: either one adult or an adult household group; no absent operator, minors, passive portrait or still-life substitution.',
 'Keep one near-depleted source before allocation, actual same-source division/transfer, several bounded resulting portions, physical traceability of every portion, and empty/nearly empty post-allocation source.',
 'Keep all five components required, required group IDs, evidence fields, minimum content words, gate IDs and gate review scales unchanged; retain no omission/applicability exception.',
 'Keep the old group match and evidence strings at index 0 byte-for-byte; append the exact frozen one-or-group string at index 1 in each array.',
 'Keep definition_only runtime behavior, forbidden labels, request/definition/negation precedence and optional-versus-hard activation boundaries unchanged.',
 'Do not infer income, diagnosis, nutrition, housing status, protected traits, social class or population-level poverty from appearance; do not turn readable labels/numbers into sole evidence.',
 'Do not apply, import, or modify the separately deferred watchmaking proposal.',
 'Rebuild generated index by the existing source-bound workflow only after application is authorized; preserve provider, model, dimensions, recipe, thresholds, candidate limits and retrieval policy.',
 'No holdout/qualification inspection or tuning informed this review. No source/runtime edits, provider calls or remote writes occurred.'
]
proposal={
 'proposal_id':'single_allocator_food_portioning_source_recovery_compat_v1',
 'status':'frozen_source_review_recommendation_not_applied',
 'supersedes':{'path':str(ORIGINAL.relative_to(ROOT.parent)),'file_sha256':sha(ORIGINAL.read_bytes()),'reason':'Original anchor replacements remove a valid group canonical match and evidence string; retain it as an accepted alternative.'},
 'source_revision':PIN,
 'source_file':SOURCE,
 'profile_id':TARGET,
 'source_profile_pointer':'/profiles/'+str(idx),
 'baseline_profile_sha256':recordsha(baseline),
 'reviewed_profile_sha256':recordsha(revised),
 'classification':'restore originally explicit one-adult alternative without invalidating existing adult-group canonical evidence',
 'scope':'DATA-only one-profile source correction; application and later qualification remain with parent',
 'exact_operations':operations,
 'operation_convention':'Paths are relative to the selected raw profile. Replace requires exact before equality. The two array replacements preserve index 0 and append one term; they are not destructive term replacements.',
 'unchanged_boundaries':boundaries,
 'source_only_review_limit':'Pure authored-component compilation and deterministic source comparisons establish projected contract text, not end-to-end behavior or generated image correctness.',
 'natural_language_coverage_limit':'Accepted component anchors are complete literal strings. The retained group string and appended one-or-group string are canonical alternatives; arbitrary singular natural paraphrases are not claimed to bind or retrieve. No new heuristic or additional paraphrase expansion is proposed.',
 'not_claimed':['natural-query recall','ranking improvement','public CLI qualification','prompt audit pass','pixel validation','poverty/food-insecurity diagnosis','retroactive validity of old saved pack hashes']
}
write('frozen-revised-food-proposal.json',proposal)
write('reviewed-revised-food-profile.json',revised)
patch=[]
for op in operations:
    for action,key in [('test','before'),('replace','after')]:
        patch.append({'op':action,'path':'/profiles/'+str(idx)+op['path'],'value':op[key]})
write('revised-rfc6902-patch.json',patch)
write('unchanged-boundary-requirements.json',{'requirements':boundaries})
files=[SOURCE,A+'photo_prompt_poverty_extension.json','docs/research-evidence/photo-prompt/poverty-visual-semantics-20260907/candidate-data-proposal.json','docs/research-evidence/photo-prompt/poverty-visual-semantics-20260907/evidence.jsonl','docs/research-evidence/photo-prompt/poverty-visual-semantics-20260907/report-source.md','skills/photo-prompt-image-generator/scripts/visual_profile_contracts.py','skills/photo-prompt-image-generator/scripts/photo_visual_retrieval.py','skills/photo-prompt-image-generator/scripts/prompt_generator.py','skills/photo-prompt-image-generator/scripts/audit_composed_prompt.py','skills/photo-prompt-image-generator/scripts/build_visual_profile_index.py',A+'photo_prompt_visual_profile_index.json','skills/photo-prompt-image-generator/SKILL.md','GOAL_PLAN.md']
manifest=[]
for f in files:
    b=(ROOT/f).read_bytes()
    pinned=subprocess.check_output(['git','show',PIN+':'+f],cwd=ROOT)
    assert b==pinned,f
    manifest.append({'path':f,'file_sha256':sha(b),'equal_to_pinned_revision':True})
write('source-manifest.json',{'source_revision':PIN,'canonicalization':'UTF-8 JSON; ensure_ascii=False; sort_keys=True; separators=(comma,colon)','files':manifest,'original_proposal_file_sha256':sha(ORIGINAL.read_bytes()),'original_proposal_baseline_matches_current_target':True,'source_boundary':'Original research source documents, authored source/candidates, compiler/consumer code and generated index source projection only. No qualification reports, holdouts, retrieval scores or generated images inspected for decision-making.','repository_mutations':0,'runtime_edits':0,'provider_calls':0,'remote_writes':0,'external_agents':0,'notes':'No AGENTS.md was present in the checkout/ancestor inventory; the canonical photo-prompt skill and GOAL_PLAN source-bound maintenance constraints were read.'})
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==PIN
assert subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,text=True)==initial_status
(OUT/'ending-git-status.txt').write_text('HEAD '+PIN+'\nGit porcelain status: clean\nRepository files unchanged by this review\n')
print(json.dumps({'status':'frozen_not_applied','operations':len(operations),'baseline_sha256':recordsha(baseline),'reviewed_sha256':recordsha(revised),'legacy_group_anchor_before':source_projection['baseline']['legacy_group_literal_contains_an_accepted_anchor'],'legacy_group_anchor_original_replacement':source_projection['original_replacement']['legacy_group_literal_contains_an_accepted_anchor'],'legacy_group_anchor_revised':source_projection['revised_additive']['legacy_group_literal_contains_an_accepted_anchor'],'changed_positive_texts':changed_texts,'output':str(OUT)},indent=2))
