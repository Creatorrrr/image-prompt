# Single-allocator food-access source review

## Decision

**Recommend the revised, additive proposal; do not apply the original six scalar replacements unchanged.** The actor-count contradiction is genuine. The original authored intent expressly permits one adult allocator, but the action component, composition instruction and render gate currently require an adult group. This is recovery of an existing source alternative, not a new food-access scenario.

The original replacement proposal retains the scene's substantive limits, but it drops the only legacy group match/evidence anchor. The compiler copies those strings directly into literal matching requirements; it does not infer that the new one-or-group sentence logically includes the old group sentence. The smallest revision retains the original proposal's four descriptive replacements and changes its two term replacements into additive array updates. All six operations are frozen in `frozen-revised-food-proposal.json` and a guarded RFC 6902 equivalent is in `revised-rfc6902-patch.json`.

Status: **reviewed and frozen, not applied**. Source revision: `7d1bb2a5104198804512b2b93082f9a100ee7238`.

## Source and provenance

All paths in this section are relative to the repository.

1. Original authored proposal: `docs/research-evidence/photo-prompt/poverty-visual-semantics-20260907/candidate-data-proposal.json:118–131`. The food profile's definition has no group-count requirement. Its second English exact phrase says “an adult portions the last visible staple supply from one source container across several meals in the same frame”; the second Korean phrase likewise uses singular `성인`. The required groups are the five source/action/result relations, not an actor-count group.
2. Original subject candidate: the same source file, line 261, explicitly says “one unmistakably adult allocator or an adult household group dividing several portions from one source”. Current `skills/photo-prompt-image-generator/assets/photo_prompt_poverty_extension.json:45–69` preserves this exact alternative, including Korean wording, adult tags, and a one-person transfer in the embedding text. The candidate's historical ID ending in `adult_group_subject` is not evidence overriding its explicit content.
3. Current authoritative profile: `skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations_poverty.json:173–341`. Both singular exact terms remain at lines 178 and 180. Group-only language is repeated in the first paraphrase, second concept term, and the action component's match term, evidence term, instruction and gate. The definition, other four components, and all five required relations remain count-neutral.
4. Historical check: the profile at commit `56b774e6` already paired these singular exact terms with group-only paraphrase/concept wording. The target record is unchanged between the earlier proposal's pin and this review's pin: raw canonical profile SHA-256 is `f38117267f17c66f8a23d84ea74b2f3017d90271dbec5e0a57593a7169c2a92e`.
5. Research limits are explicit in `report-source.md:97–115` and `evidence.jsonl`, especially E04/S04 (FAO FIES), E05/S05 (IPC), E16/S16 (Dóchas) and E17/S17 (JRF). The project records translate food-access dimensions and respectful agency into visible events; they do not establish an allocator-count law, diagnosis, or pixel classifier. These local provenance records were inspected, not independently re-fetched or medically/statistically revalidated. The single-adult decision follows the project's explicit original authored scope, not an inference from FAO or ethical guidance.

## Six-operation review

| Original proposed path | Source-scope verdict | Required compatibility treatment |
|---|---|---|
| `/semantics/paraphrase_examples/0` | Restores the already-authored one-or-group alternative; the other four relations remain verbatim | Keep original proposed replacement |
| `/concept_candidate/concept_terms/1` | Restores allocator choice while retaining adult identity, active division and the same source | Keep original proposed replacement |
| `/authored_components/components/1/match_terms/0` | Semantically within scope, but deleting the old canonical term is an unnecessary matching regression | Preserve index 0; append the proposed term at index 1 |
| `/authored_components/components/1/evidence_terms/0` | Semantically within scope, but deleting the old canonical term invalidates the old group evidence anchor | Preserve index 0; append the proposed term at index 1 |
| `/authored_components/components/1/instruction` | Removes a mandatory extra-people demand while retaining active same-source adult allocation | Keep original proposed replacement |
| `/authored_components/components/1/render_gate/description` | Allows either authored actor-count choice without removing the adult/action/source gate | Keep original proposed replacement |

Each edited fragment owns only the action/actor relation. It need not repeat the four other required components. Their unchanged conjunction, rather than the edited fragment alone, preserves the whole event:

- Adult scope remains explicit for both branches; `requires_adult_character` remains true
- Actual allocation remains `actively divides contents from that one source`, supported by the unchanged transfer-oriented action candidate and original composition design
- A single household source must already be visibly near depletion
- Several bounded portions must be the result of division
- Every portion remains physically traceable to the same depleted source
- The source remains visibly empty or nearly empty after allocation
- All existing claim limits, exclusions, forbidden labels and definition-only behavior remain intact

No component is removed or made optional. No human appearance, small serving, empty bowl, label, or ordinary meal-prep scene becomes sufficient evidence.

## Why replacing the term strings breaks compatibility

`visual_profile_contracts.py:141–155` projects `match_terms` into `component_semantics.groups[].any_terms`, `evidence_terms` into `evidence_requirements[field].must_mention_any`, instructions into composition text, and gates into the generated render contract. The total required component groups remains five.

`prompt_generator.py:6756–6779` requires an evidence phrase to contain at least one declared anchor literally after whitespace/case normalization. `audit_composed_prompt.py:1799–1815`, using its literal boundary matcher at lines 457–468, imposes the same anchor condition. `prompt_generator.py:7133–7156` also uses any-term matching for the lexical component lane. These are not logical paraphrase entailment engines.

The old anchor is:

> the same group of unmistakably adult household members actively divides contents from that one source

The original proposal's sole replacement is:

> the same unmistakably adult allocator or adult household group actively divides contents from that one source

Neither sentence contains the other. A previously valid group evidence phrase equal to the first string loses its accepted anchor after replacement, even though the group event is semantically still within the new wording. Keeping exact group activation aliases does not repair that later evidence-binding failure. Removing a component match term can also remove a lexical five-component match; this is not a claim that every approximate retrieval lane would fail.

The source-only compiler projection confirms the declaration-level distinction:

| Projection | Legacy group anchor retained | Proposed one-or-group anchor retained |
|---|---:|---:|
| Baseline | Yes | No |
| Original destructive replacement | No | Yes |
| Revised additive proposal | Yes | Yes |

This is a direct structural/string consequence, not a holdout result, full runtime test, or pixel-quality claim. The revision is frozen from source provenance and consumer semantics before any future qualification.

## Exact revised operation policy

Four scalar replacements are byte-identical to the original proposal. For each of `match_terms` and `evidence_terms`, replace the one-element array `[old_group_string]` with `[old_group_string, proposed_one_or_group_string]`. The supplied operation file uses exact `before` and `after` arrays; the RFC 6902 patch includes a `test` before every replacement and uses the pinned file's `/profiles/1` owner.

This retains six source operations and does not add a new runtime path, standalone actor-count matcher, extra discovery policy, new scene variant, or further natural-language synonym. The appended whole sentence is a canonical literal alternative; the compiler does not split its word “or” into independent shorter anchors. Arbitrary one-person paraphrases are therefore **not** claimed to bind or retrieve. Adding further singular lexical variants would be a separate source change, not an implied part of this freeze.

Revised raw profile canonical SHA-256: `7254a7f59954bbb6c790ea8633fd13ef67087c379b9093024b6e7aa2f652f908`.

## Expected generated-index effects

Source-only projection used the actual authored-component compiler and positive-text functions. It did not run queries or qualification cases.

- The merged registry has 1,507 profiles. Exactly one positive profile text and one BM25F source document change: this food profile
- Positive fields changed: paraphrases, visual components and support cues. Definition and aliases are unchanged
- All 3,661 exact lookup rows remain identical. No activation term, exclusion, threshold, candidate limit, provider, model, dimensions, text recipe or retrieval policy changes
- Registry SHA changes from `639952b191bd1f1fecb4ba98e0d47e1561526d2a00e767c83d61d4bd5c0378c0` to `c7963d6dc6e13007527b5a7c65e8ecbbe2cb56ed1cd32232d72dcd40980c588c`
- Target positive-text SHA changes from `2fd9b171ba467c77164c8966ef194a5ab212097b692613b930b5eab5d409b1cf` to `617c0caa5c2629c2f818ef3b2936f3c829ee44d293e6b9180ce1f4bcf697be8e`
- The old index becomes stale under the proposed registry. Rebuild through the existing builder after authorized application. The changed target needs a matching new vector or exact-text cache hit; all other texts remain reusable with the same provider/model/dimensions
- The complete BM25F payload must be regenerated, since corpus statistics can change beyond the target row. Do not surgically relabel an old vector or hand-patch only the target index entry
- Preserving old literal group evidence does not preserve old saved registry/index hashes or pack provenance. Supported regeneration/rebinding is still necessary. No ranking, recall, full runtime compatibility or image fidelity has been established here

See `expected-index-implications.json` for the machine-readable expectations.

## Boundaries and review limits

`unchanged-boundary-requirements.json` records the required invariants. All four untouched components, five required IDs/evidence fields, minimum word counts, gate IDs/review scales, activation/exclusion policy, claim limits, runtime wording policy and candidate records remain unchanged in the in-memory revision. The deferred watchmaking proposal remains deferred and was not applied.

No repository source or runtime edits, index writes, provider calls, remote writes, external agents, qualification runs or holdout inspection occurred. The review wrote only its requested artifacts outside the checkout. The freeze completed against a clean checkout at the pinned commit. A later status observation showed a separate untracked `renewed-full-regression-complete-20261003` documentation directory; its contents were not opened, and it is not an output of this review.

These artifacts are sufficient for the parent to decide and apply the bounded DATA correction. They are not a substitute for any separately authorized qualification or generated-index rebuild.
