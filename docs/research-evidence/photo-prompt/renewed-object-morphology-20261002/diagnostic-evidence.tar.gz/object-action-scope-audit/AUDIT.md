# Object/action scope audit

Status: recommend both DATA-only fixes. Both defects reproduced through the real current public candidate-pack v6 CLI with independently frozen inputs; both CLI exits were 0.

Baseline commit: `904b5893c94e2d59d646e977c8400e270635a568`. Read-only checkout inspection. Two capture registry/index files and one capture test were already dirty; none touched. Exact initial hashes and status: `baseline-manifest.json`.

## Recommended defect 1: rapier morphology requires a person

Profile `rapier_acute_point_elaborate_guard` has ordinary exact aliases including `rapier` and `레이피어`, with `requires_adult_character: false`. Yet its required `guard_phrase`, component group, composition instruction and `vo_weapon_rapier_elaborate_guard` demand an actual gripping hand. Object-only museum still life correctly satisfies the noun but is forced into an incompatible person relation.

Existing source evidence identifies guard function, not compulsory pictured use. Keep exact activation and object identity hard. Replace only the actual-hand relation with the protective guard structure around the grip, in definition, component lexicon, required evidence, composition and gate. This accommodates hand-held pictures without adding or prescribing an action. Proposed full profile in `proposed-profiles.json`.

## Recommended defect 2: compound-bow morphology requires a person and upright orientation

Profile `compound_bow_cam_cable_system` has ordinary exact aliases and `requires_adult_character: false`. Gate `vo_weapon_compound_bow_grip_relation` nevertheless demands that a hand meet the riser grip. Definition, composition and full-riser gate also hardcode vertical presentation. A horizontal product still life is a legitimate object scene, so object identity should not overwrite its requested orientation or population.

Keep morphology and aliases hard; describe grip continuity within the riser instead of requiring a hand, and preserve the requested orientation. No operation, handling, aiming or construction information is added. Exact proposed profile in `proposed-profiles.json`.

## Evidence and limited scope

- Current real visual-profile index was loaded with runtime validation, not rebuilt or replaced. `resolver-diagnostic.json` confirms both object-only cases are hard eligible, while ordinary adult-held portrait controls also remain hard eligible.
- `baseline-profiles.json` contains full unchanged relevant source records.
- `SOURCES.md` records reopened existing Met / World Archery primary sources and limited Hoyt terminology corroboration.
- No still-life exceptions, action-phrase lists, runtime negation changes or broad routing suppression are proposed. This differs from the deferred instrument split: these two profiles already claim object morphology and can retain their identity duties without inventing a performance profile.
- No corpus/index mutation, fake vectors, image generation, paid calls or physical-world operations performed.
- Proposed-data semantic text changes require a legitimate index refresh by the integrator before public before/after acceptance. This audit does not pretend that stale vectors validate changed text.

Other inspected profiles (halberd, revolver, high jewelry) contain weaker composition assumptions, but are not nominated to keep this audit to two clear defects. Musical instruments excluded.

## Final public materialization

Both `rapier-public-pack.json` and `compound-bow-public-pack.json` were emitted by the unchanged `generate_photo_prompt.py` CLI, seed 0, with the current real semantic and visual-profile indexes. API-key environment variables were removed for the invocation. No helper mock, fake index, or fixture runner replaced public materialization. `public-summary.json` extracts evidence.

Both source cores passed pre-core validation without warnings and retain their original baseline text in the pack. Their input core byte hashes remain `11b4d1f65079324d70951cb730653837254cf8013f01e6a806d843c163e34b7c` (rapier) and `7d362c5c3e3ae4d5c65becea0cd02c0da5e3e848245c1dba6e76bfc8d1816e29` (compound bow). Synthetic audit request provenance is explicit in `inputs/FIXTURE-PROVENANCE.md`; these were independently authored, not actual user image requests.

Each public pack adds the targeted morphology obligation and all five hard render gates, including the incompatible hand gate, despite the core excluding people and hands. Rapier additionally exposes compulsory gripping-hand literal evidence; the horizontal compound-bow core is preserved but its hard full-riser gate still says vertical. This establishes public contract contradiction, not a claim about generated pixels. No final image or composed prompt was generated.

Proposed profiles are review artifacts only, not integrated or vector-refreshed. Recommended integrator checks: retain these frozen cases, add independently authored held-object controls, regenerate only legitimately affected index entries, rerun public packs, and confirm morphology duties remain while person/orientation invention disappears.
