import hashlib,json,pathlib,shutil
ROOT=pathlib.Path('EVIDENCE_ROOT/object-action-scope-audit/inputs')
REPO=pathlib.Path('REPOSITORY_ROOT')
CAT=REPO/'skills/photo-prompt-image-generator/precore/visual_feature_catalog.json'
sha=lambda v:hashlib.sha256(v).hexdigest()
def save(p,v): p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
# These five observation categories were selected from the permitted neutral catalog before drafting.
selected_categories=['feature.situation','feature.primary_object','feature.background','feature.light_quality','feature.framing']
cases={
'rapier':{
'baseline':'A museum still-life photograph shows a single rapier resting alone on dark cloth. The scene is a quiet object study, with the sword as the sole displayed artifact. Its slender straight blade, protective guard, grip, and pommel form one continuous object. The cloth supports it along the table surface and spreads into a dark, softly folded background. A high oblique view includes the entire length with breathing room at each end. Broad soft side light draws a restrained metallic highlight along the blade and separates the guard from the fabric while keeping cloth detail visible.',
'intent':'Preserve the requested museum still life as an isolated object photograph of a rapier at rest on dark cloth. The sword is the only displayed artifact, and the request explicitly excludes people and hands. The agent chooses quiet catalogue-like presentation, a complete view, and restrained reflected light to make the long blade and guard legible.',
'subject':'One rapier, a slender straight-bladed sword with a guard, grip, and pommel',
'setting':'Dark cloth supporting the displayed sword',
'event':'The rapier rests alone on the cloth as a still-life object',
'priorities':['The complete rapier is the sole displayed artifact at rest on dark cloth','The long straight blade remains visually continuous with its protective guard and grip','Restrained metal highlights separate the sword from the dark fabric'],
'anchors':[('core_concept','museum still-life photograph','concept','museum still-life photograph'),('core_subject','a rapier','subject','single rapier'),('core_event','lying alone','event','resting alone'),('core_setting','on dark cloth','setting','on dark cloth'),('core_count','alone','count','sole displayed artifact')],
'domain':'museum object photography','family':'restrained catalogue still life','style_evidence':['complete object against dark cloth','soft metallic highlights'],
'selection':[
('feature.situation','explicit_request','lying alone',None,'The photograph concerns a motionless displayed object rather than a performed activity.','resting alone'),
('feature.primary_object','explicit_request','a rapier',None,'The sword itself must be the recognizable primary subject.','single rapier'),
('feature.background','explicit_request','dark cloth',None,'The specified cloth gives the object its immediate supporting background.','on dark cloth'),
('feature.light_quality','agent_visual_choice',None,None,'Soft reflected light clarifies polished metal without overpowering the quiet still life.','Broad soft side light'),
('feature.framing','agent_visual_choice',None,None,'An entire-object view makes the slender blade and guard readable together.','includes the entire length with breathing room at each end')]
},
'compound-bow':{
'baseline':'A product photograph presents one compound bow resting alone horizontally on a plain display table. The bow is the sole displayed product, its long axis running left to right. The central riser and grip, paired limbs, end cams, bowstring, and cables are visibly connected as parts of the same object. It lies in its resting shape on the table with soft contact shadows locating the supporting points. The frame holds the entire outline with modest surrounding space. Broad diffused studio light and a slightly elevated oblique view separate the dark components from the pale matte tabletop, giving the product a precise, readable silhouette and natural material texture.',
'intent':'Preserve the requested product photograph of a compound bow resting alone horizontally on a plain display table. It is an isolated displayed product, with people and hands explicitly excluded. The agent chooses a clear complete-object view, simple tonal separation, and soft studio light that make the compound bow construction legible in its resting state.',
'subject':'One compound bow with its riser, limbs, cams, bowstring, and cables',
'setting':'A plain display table holding the bow',
'event':'The compound bow rests alone horizontally on the table',
'priorities':['The compound bow is the sole displayed product resting horizontally on the plain table','Its central riser, limbs, cams, and string system read as one connected object','Soft contact shadows establish the bow resting on the tabletop'],
'anchors':[('core_concept','product photograph','concept','product photograph'),('core_subject','a compound bow','subject','one compound bow'),('core_event','resting alone horizontally','event','resting alone horizontally'),('core_setting','on a plain display table','setting','on a plain display table'),('core_count','alone','count','sole displayed product')],
'domain':'product photography','family':'clear studio product study','style_evidence':['complete bow on a plain table','diffused light and natural material texture'],
'selection':[
('feature.situation','explicit_request','resting alone horizontally',None,'The horizontal resting state is central to the requested product presentation.','resting alone horizontally'),
('feature.primary_object','explicit_request','a compound bow',None,'The compound bow construction identifies the intended product.','one compound bow'),
('feature.background','explicit_request','plain display table',None,'The plain table must visibly support the product and remain subordinate.','on a plain display table'),
('feature.light_quality','agent_visual_choice',None,None,'Diffused studio light keeps fine cable and limb structure legible.','Broad diffused studio light'),
('feature.framing','agent_visual_choice',None,None,'The full outline lets the viewer inspect the bow as a complete product.','The frame holds the entire outline with modest surrounding space')]
}}
for case,d in cases.items():
 p=ROOT/case;env=json.loads((p/'request-envelope.json').read_text());controls=json.loads((p/'creative-controls.json').read_text());b=d['baseline']
 assert b==' '.join(b.split())
 (p/'source-request.txt').write_text(env['request_text'])
 core={'contract_version':'photo-authorial-core/v3','provenance':'agent_prepack','source_request':env['request_text'],'creative_controls_sha256':controls['canonical_sha256'],'interpreted_intent':d['intent'],'subject':d['subject'],'setting':d['setting'],'event':d['event'],'visual_priorities':d['priorities'],'baseline_prompt_en':b,'user_definitions':[],'interpretation_provenance':[{'term':'requested object still life','source_text':env['request_text'],'basis':'request_context','resolution':d['intent'].split(' The agent chooses')[0],'sources':[]}],'unresolved_ambiguities':[],'user_exclusions':['people or hands'],'runtime_forbidden_labels':[],'intent_lock':{'contract_version':'photo-intent-lock/v2','priority':'requesting_user','semantic_anchors':[{'anchor_id':aid,'source_text':src,'dimension':dim,'prompt_evidence':evi} for aid,src,dim,evi in d['anchors']],'locked_dimensions':['concept','subject','event','setting','count'],'open_dimensions':['framing','composition','lighting','camera','color','material']},'semantic_assertions':[],'request_lineage':None,'style':{'domain':d['domain'],'family':d['family'],'evidence':d['style_evidence']},'variation_key':f'object-stilllife-audit-{case}'}
 save(p/'authorial-core.json',core)
 save(p/'embodiment-review.json',{'contract_version':'photo-embodiment-review/v1','provenance':'agent_prepack','prompt_sha256':sha(b.encode()),'scope':'not_applicable','summary':'An isolated inanimate object rests on a support surface. The request excludes people and hands; the scene has no material bodily mechanism to review.','checks':{}})
 save(p/'precore-feature-selection.json',{'contract_version':'photo-precore-feature-selection/v1','request_id':env['request_id'],'active_span_ids':['scene'],'catalog_path':'skills/photo-prompt-image-generator/precore/visual_feature_catalog.json','catalog_schema_version':'photo-precore-feature-catalog/v1','catalog_sha256':sha(CAT.read_bytes()),'request_sha256':env['request_sha256'],'baseline_prompt_sha256':sha(b.encode()),'selected':[{'category_id':cat,'basis':basis,'source_span_ids':['scene'] if basis!='agent_visual_choice' else [],'source_text':source,'derivation':derive,'reason':reason,'baseline_evidence':evidence} for cat,basis,source,derive,reason,evidence in d['selection']]})
 shutil.copyfile(CAT,p/'visual-feature-catalog.snapshot.json')
 freeze={'phase':'independent_prepack_freeze','authorship_inputs':['coordinator-authored synthetic envelope','skills/photo-prompt-image-generator/SKILL.md','skills/photo-prompt-image-generator/precore/creative_controls.json','candidate-free precore/creative_controls.py output','skills/photo-prompt-image-generator/precore/visual_feature_catalog.json','independent visual reasoning'],'candidate_reference_runtime_material_read':False,'files':{name:sha((p/name).read_bytes()) for name in ['request-envelope.json','source-request.txt','creative-context.json','creative-controls.json','authorial-core.json','embodiment-review.json','precore-feature-selection.json','visual-feature-catalog.snapshot.json']},'baseline_words':len(b.split())}
 save(p/'freeze-manifest.json',freeze)
 print(case,freeze['files']['authorial-core.json'],freeze['baseline_words'])
