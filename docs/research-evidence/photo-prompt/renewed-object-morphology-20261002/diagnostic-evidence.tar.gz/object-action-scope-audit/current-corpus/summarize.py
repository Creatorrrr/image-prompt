import json,hashlib
from pathlib import Path
O=Path(__file__).resolve().parent
ROOT=O.parent
out=[]
for n in ['rapier','compound-bow','rapier-held','compound-bow-held']:
 p=O/f'{n}-public-pack.json'
 if not p.exists():continue
 d=ROOT/('held-inputs' if n.endswith('-held') else 'inputs')/n
 corepath=d/('authorial-core.validated.raw.json' if n.endswith('-held') else 'authorial-core.json')
 raw=json.loads(corepath.read_text());pack=json.loads(p.read_text())[0]
 ob=pack['visual_obligations'];target='rapier_acute_point_elaborate_guard' if n.startswith('rapier') else 'compound_bow_cam_cable_system'
 targetob=next(x for x in ob['obligations'] if x['id']==target)
 out.append({'case':n,'public_contract':pack['contract_version'],'core_file_sha256':hashlib.sha256(corepath.read_bytes()).hexdigest(),'source_request':raw['source_request'],'baseline_unchanged':raw['baseline_prompt_en']==pack['authorial_core']['baseline_prompt_en'],'user_exclusions':raw['user_exclusions'],'baseline':raw['baseline_prompt_en'],'target_obligation':targetob,'required_hard_gates':ob['required_hard_gates'],'embodiment':pack['embodiment_preflight']})
(O/'public-summary.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
for c in out:
 print(c['case'],c['public_contract'],c['baseline_unchanged'],len(c['required_hard_gates']))
