import json,copy
from pathlib import Path
O=Path(__file__).resolve().parent
ps=json.loads((O/'baseline-profiles.json').read_text());out=[]
for p in ps:
 p=copy.deepcopy(p)
 if p['id'].startswith('rapier'):
  old='a swept or cup guard visibly encloses and protects the gripping hand'
  new='a swept or cup guard forms an elaborate protective enclosure around the grip'
  g=next(g for g in p['semantics']['component_semantics']['groups'] if g['id']=='elaborate_hand_guard')
  g['any_terms']=[new,'스웹트 또는 컵 가드가 그립 둘레에 정교한 보호 구조를 형성']
  p['evidence_requirements']['guard_phrase']['must_mention_any']=[new]
  p['semantics']['definition']=p['semantics']['definition'].replace('that encloses the hand','around the grip')
  p['composition_instruction']='Use an unobstructed side or three-quarter profile that keeps the elaborate guard, grip, pommel, complete slender blade, and acute point on one continuous readable axis. Preserve the requested object placement and whether any person is present.'
  next(g for g in p['render_gates'] if g['id']=='vo_weapon_rapier_elaborate_guard')['description']='A swept or cup guard forms an elaborate protective structure around the grip rather than becoming a plain crossguard; no hand is required.'
 else:
  p['semantics']['definition']=p['semantics']['definition'].replace('complete vertical bow','complete bow')
  p['semantics']['paraphrase_examples']=[s.replace('a vertical modern bow','a modern bow') for s in p['semantics']['paraphrase_examples']]
  p['composition_instruction']='Keep the entire bow inside frame in the requested orientation, with both limb-tip cams, split limbs, central riser and grip, bowstring, and separate cable routes unobstructed. Preserve the requested object placement and whether any person is present.'
  next(g for g in p['render_gates'] if g['id']=='vo_weapon_compound_bow_full_riser_limbs')['description']='The complete riser and both limb systems fit inside the frame in the requested orientation.'
  next(g for g in p['render_gates'] if g['id']=='vo_weapon_compound_bow_grip_relation')['description']='The grip remains a coherent part of the central riser without hiding either cam or inventing extra strings; no hand is required.'
 out.append(p)
(O/'proposed-profiles.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
