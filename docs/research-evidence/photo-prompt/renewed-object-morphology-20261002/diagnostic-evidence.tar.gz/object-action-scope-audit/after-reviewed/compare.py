import json,hashlib,collections
from pathlib import Path
O=Path(__file__).resolve().parent;B=O.parent/'current-corpus'
def leaves(a,b,path=''):
 if type(a)!=type(b):return [{'path':path,'before':a,'after':b}]
 if isinstance(a,dict):
  out=[]
  for k in sorted(a.keys()|b.keys()):
   if k not in a or k not in b:out.append({'path':path+'/'+k,'before':a.get(k),'after':b.get(k)})
   else:out+=leaves(a[k],b[k],path+'/'+k)
  return out
 if isinstance(a,list):
  out=[]
  if len(a)!=len(b):out.append({'path':path+'/length','before':len(a),'after':len(b)})
  for i,(x,y) in enumerate(zip(a,b)):out+=leaves(x,y,path+'/'+str(i))
  for i in range(min(len(a),len(b)),max(len(a),len(b))):out.append({'path':path+'/'+str(i),'before':a[i] if i<len(a) else None,'after':b[i] if i<len(b) else None})
  return out
 return [] if a==b else [{'path':path,'before':a,'after':b}]
def inventories(x,path=''):
 out={}
 if isinstance(x,dict):
  for k,v in x.items():out.update(inventories(v,path+'/'+k))
 elif isinstance(x,list):
  if any(isinstance(z,dict) and 'id' in z for z in x):out[path]=[z.get('id') if isinstance(z,dict) else z for z in x]
  for i,v in enumerate(x):out.update(inventories(v,path+'/'+str(i)))
 return out
result=[]
for n in ['rapier','compound-bow','rapier-held','compound-bow-held']:
 a=json.loads((B/f'{n}-public-pack.json').read_text())[0];b=json.loads((O/f'{n}-public-pack.json').read_text())[0]
 diff=leaves(a,b);ia=inventories(a);ib=inventories(b)
 row={'case':n,'whole_pack_changed_leaves':diff,'changed_top_level_fields':sorted({r['path'].split('/')[1] for r in diff}),'all_id_arrays_equal':ia==ib,'id_array_changes':leaves(ia,ib),'slot_candidate_ids_before':{k:[c['id'] for c in v['candidates']] for k,v in a['slots'].items()},'slot_candidate_ids_after':{k:[c['id'] for c in v['candidates']] for k,v in b['slots'].items()},'slots_exactly_equal':a['slots']==b['slots'],'authorial_core_exactly_equal':a['authorial_core']==b['authorial_core'],'before_pack_sha256':hashlib.sha256((B/f'{n}-public-pack.json').read_bytes()).hexdigest(),'after_pack_sha256':hashlib.sha256((O/f'{n}-public-pack.json').read_bytes()).hexdigest()}
 result.append(row);print(n,len(diff),row['changed_top_level_fields'],'ids equal',row['all_id_arrays_equal'],'slots equal',row['slots_exactly_equal']);print('\n'.join(r['path'] for r in diff))
(O/'comparison.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
