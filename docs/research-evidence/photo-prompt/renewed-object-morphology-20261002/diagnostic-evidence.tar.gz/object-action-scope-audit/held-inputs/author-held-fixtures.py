import json, hashlib, pathlib, shutil, datetime
root=pathlib.Path('EVIDENCE_ROOT/object-action-scope-audit/held-inputs')
repo=pathlib.Path('REPOSITORY_ROOT')
catalog=repo/'skills/photo-prompt-image-generator/precore/visual_feature_catalog.json'
sha=lambda b:hashlib.sha256(b).hexdigest()
write=lambda p,v:p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
records={
'rapier-held':{
 'object':'rapier','place_source':'museum','place_evidence':'inside a museum gallery',
 'concept_source':'A museum portrait','concept_evidence':'A museum portrait photograph',
 'holding_source':'holding a rapier','holding_evidence':'holding a rapier',
 'event_source':'as a displayed artifact','event_evidence':'the sword presented as a displayed artifact',
 'visibility_source':'with the complete sword visible','visibility_evidence':'the complete sword visible from pommel to tip',
 'prompt':"A museum portrait photograph of an adult person holding a rapier, the sword presented as a displayed artifact inside a museum gallery. The adult stands beside a warm gray wall, wearing a charcoal linen shirt with an open collar and straight trousers. A soft direct gaze and easy shoulders bring a quiet personal warmth to the formal presentation. Their right hand encloses the grip below the complex ringed guard; a gently bent right elbow keeps the hand at hip height. The long, slender, straight blade tapers to a fine point and descends diagonally through open space beside the right leg, its tip suspended above the floor. The rounded pommel and looping metal guard remain individually readable. The left arm rests loosely at the person's side, and both feet bear their weight on the gallery floor. A vertical full-length composition keeps the complete sword visible from pommel to tip, with space around its outline. Diffuse window light catches a narrow silver line along the blade and softly illuminates the face; the quiet wall gives the hand-held artifact a clear silhouette.",
 'intent':"The requested meaning is an adult museum portrait with a complete rapier held for display. I choose a quiet gallery encounter over a theatrical ceremonial portrait: the person's open expression and the sword's slender outline share attention. Subtle supporting attraction comes from easy bearing, an open collar, and soft light; restrained creativity leaves the ordinary setting and static display coherent. The clothing, stance, hand arrangement, light, and composition are agent-owned realizations, not requester requirements.",
 'subject':'An adult person holding a rapier', 'setting':'A museum gallery', 'event':'The adult holds the complete rapier as a displayed artifact',
 'priorities':['The adult visibly holds the complete rapier for display','The slender straight blade and ringed guard read as a continuous complete sword','A warm, relaxed presence balances the formal artifact portrait'],
 'meaning':'A rapier is interpreted through general visual knowledge as a sword with a long slender straight blade, a protective complex guard, a grip, and a pommel; the request specifies static display rather than an operating action.',
 'morphology':'The long, slender, straight blade tapers to a fine point',
 'pose':'a gently bent right elbow keeps the hand at hip height',
 'gaze':'A soft direct gaze and easy shoulders',
 'light':'Diffuse window light catches a narrow silver line along the blade',
 'support':'both feet bear their weight on the gallery floor',
 'contact':'Their right hand encloses the grip below the complex ringed guard',
 'clearance':'descends diagonally through open space beside the right leg, its tip suspended above the floor',
 'display_axis':'held_artifact_display','style':'quiet museum portrait','style_evidence':['warm gray wall','narrow silver line along the blade'],
 'review_summary':'One standing adult holds a complete rapier with the right hand as a stationary display object. The chosen hand contact, elbow reach, balance, blade clearance, and viewpoint form a plausible ordinary human pose.',
 'review_joint':'The right shoulder, gently bent elbow, wrist, and hand form one reachable chain at hip height; the free left arm has its own relaxed position.',
 'review_contact':'The hand contacts the grip, while the long blade occupies open space beside the leg with its tip above the floor. The display relation remains held rather than transferred to a stand.',
 'review_visibility':'The full-length view includes the hand, guard, pommel, entire blade, and tip. Separation beside the leg keeps the complete sword outline assessable.',
},
'compound-bow-held':{
 'object':'compound bow','place_source':'studio','place_evidence':'inside a photography studio',
 'concept_source':'A studio portrait','concept_evidence':'A studio portrait photograph',
 'holding_source':'holding a compound bow','holding_evidence':'holding a compound bow',
 'event_source':'as a displayed object','event_evidence':'the bow presented as a displayed object',
 'visibility_source':'with the complete bow visible','visibility_evidence':'the complete bow visible from upper cam to lower cam',
 'prompt':"A studio portrait photograph of an adult person holding a compound bow, the bow presented as a displayed object inside a photography studio. The adult stands against a pale sand seamless backdrop in a fitted olive cotton shirt with the sleeves loosely rolled and dark trousers. A calm direct gaze and relaxed shoulders lend an easy, attractive presence. Their right hand encloses the central grip, and a softly bent right elbow keeps the hand beside the waist. The bow stands upright at the person's right side, its rigid sculpted central riser, short paired upper and lower limbs, oval cams at both ends, and fine parallel string and cable lines clearly readable. The bow's broad side faces the camera, separated from the torso by open background. The left hand rests beside the left thigh, and the adult's feet stand evenly on the studio floor. A vertical full-body frame keeps the complete bow visible from upper cam to lower cam, with generous space around both ends. Broad softbox light reveals the matte dark surfaces and the person's face, giving the object a distinct graphic outline against the quiet backdrop.",
 'intent':"The requested meaning is an adult studio portrait holding a complete compound bow as a displayed object. I choose a light, graphic studio arrangement over a moody close portrait so the complete shape is immediately legible beside the adult. A direct gaze, relaxed bearing, and fitted cotton shirt provide subtle supporting attraction; all styling and hand placement remain agent-owned choices. The state is a stationary held display, with morphology described only as visible appearance.",
 'subject':'An adult person holding a compound bow','setting':'A photography studio','event':'The adult holds the complete compound bow as a displayed object',
 'priorities':['The adult holds the complete compound bow beside the body for display','The riser, limbs, end cams, and cable lines read together as one object','The person and the bow share a calm, clear studio portrait'],
 'meaning':'A compound bow is interpreted through general visual knowledge as a bow with a central riser, short upper and lower limbs, visible end cams, and strings or cables; the request specifies static display rather than an operating action.',
 'morphology':'its rigid sculpted central riser, short paired upper and lower limbs, oval cams at both ends, and fine parallel string and cable lines clearly readable',
 'pose':'a softly bent right elbow keeps the hand beside the waist',
 'gaze':'A calm direct gaze and relaxed shoulders',
 'light':"Broad softbox light reveals the matte dark surfaces and the person's face",
 'support':"the adult's feet stand evenly on the studio floor",
 'contact':'Their right hand encloses the central grip',
 'clearance':"The bow's broad side faces the camera, separated from the torso by open background",
 'display_axis':'held_object_display','style':'clear studio portrait','style_evidence':['pale sand seamless backdrop','distinct graphic outline'],
 'review_summary':'One standing adult holds a complete compound bow in the right hand as a stationary displayed object. The hand supports the central grip beside the waist and the bow is fully visible alongside the body.',
 'review_joint':'The right arm has a softly bent elbow beside the waist, keeping the grip within a comfortable reach. The left hand belongs to the separate left arm and rests alongside its own thigh.',
 'review_contact':'The right hand closes around the central grip. The upright bow remains in the open space to the actor\'s right with a visible gap against the background; it is held rather than placed on a separate support.',
 'review_visibility':'The broad side facing the camera reveals the central riser, both end cams, limbs, and string lines. The full-body frame and end margins preserve the complete object silhouette.',
}}
for name,r in records.items():
 d=root/name;env=json.loads((d/'request-envelope.json').read_text()); controls=json.loads((d/'creative-controls.json').read_text());p=' '.join(r['prompt'].split());psha=sha(p.encode())
 anchors=[
  {'anchor_id':'core_concept','source_text':r['concept_source'],'dimension':'concept','prompt_evidence':r['concept_evidence']},
  {'anchor_id':'core_subject','source_text':'an adult','dimension':'subject','prompt_evidence':'an adult person'},
  {'anchor_id':'core_event','source_text':r['event_source'],'dimension':'event','prompt_evidence':r['event_evidence']},
  {'anchor_id':'held_action','source_text':r['holding_source'],'dimension':'action','prompt_evidence':r['holding_evidence']},
  {'anchor_id':'portrait_setting','source_text':r['place_source'],'dimension':'setting','prompt_evidence':r['place_evidence']},
  {'anchor_id':'complete_object_visible','source_text':r['visibility_source'],'dimension':'framing','target':'displayed_object','property':'visibility.complete','prompt_evidence':r['visibility_evidence']},
 ]
 core={'contract_version':'photo-authorial-core/v3','provenance':'agent_prepack','source_request':env['request_text'],'creative_controls_sha256':controls['canonical_sha256'],'interpreted_intent':r['intent'],'subject':r['subject'],'setting':r['setting'],'event':r['event'],'visual_priorities':r['priorities'],'baseline_prompt_en':p,'user_definitions':[],
 'interpretation_provenance':[{'term':'complete held-object portrait','source_text':env['active_spans'][0]['text'],'basis':'request_context','resolution':'An adult portrait at the named setting, physically holding the named complete object as a stationary display; the entire object stays within the photograph.','sources':[]},{'term':r['object'],'source_text':r['object'],'basis':'agent_general_knowledge','resolution':r['meaning'],'sources':[]}],
 'unresolved_ambiguities':[],'user_exclusions':[],'runtime_forbidden_labels':[],
 'intent_lock':{'contract_version':'photo-intent-lock/v2','priority':'requesting_user','semantic_anchors':anchors,'locked_dimensions':['concept','subject','event','action','setting'],'open_dimensions':['appearance','pose','body_geometry','expression','framing','composition','lighting','camera','color','material','atmosphere']},
 'semantic_assertions':[{'assertion_id':'held_display_action','dimension':'action','polarity':'required','source_span_ids':['scene'],'affected_dimensions':['action'],'axes':{'interaction_state':r['display_axis'],'object_identity':r['object']},'evidence':{'held_interaction_phrase':r['holding_evidence'],'display_state_phrase':r['event_evidence']}}],
 'request_lineage':None,'style':{'domain':'portrait photography','family':r['style'],'evidence':r['style_evidence']},'variation_key':name+'-independent-v1'}
 write(d/'authorial-core.raw.json',core)
 checks={
 'body_ownership':{'status':'supported','reason':'The portrait has one adult. The right hand belongs to the arm supporting the object, while the left arm is separately placed; the prose assigns every material contact to that same adult.','prompt_evidence':[r['contact']]},
 'joint_chain_and_reach':{'status':'supported','reason':r['review_joint'],'prompt_evidence':[r['pose']]},
 'support_and_balance':{'status':'supported','reason':'The stationary adult is supported on both feet. The object is supported at the hand and the chosen relaxed stance does not require a second concealed actor or support.','prompt_evidence':[r['support'],r['contact']]},
 'contact_and_space':{'status':'supported','reason':r['review_contact'],'prompt_evidence':[r['contact'],r['clearance']]},
 'visibility_and_projection':{'status':'supported','reason':r['review_visibility'],'prompt_evidence':[r['visibility_evidence'],r['clearance']]}}
 review={'contract_version':'photo-embodiment-review/v1','provenance':'agent_prepack','prompt_sha256':psha,'scope':'body_action','summary':r['review_summary'],'checks':checks};write(d/'embodiment-review.json',review)
 def feat(id,basis,evidence,reason,source=None,derivation=None):return {'category_id':id,'basis':basis,'source_span_ids':['scene'] if basis!='agent_visual_choice' else [],'source_text':source,'derivation':derivation,'reason':reason,'baseline_evidence':evidence}
 selected=[
 feat('feature.subject','explicit_request','an adult person','Adult status identifies the requested human subject.',source='an adult'),
 feat('feature.location','explicit_request',r['place_evidence'],'The named photographic setting situates the portrait.',source=r['place_source']),
 feat('feature.action','explicit_request',r['holding_evidence'],'The holding relation must remain visible rather than becoming an adjacent display.',source=r['holding_source']),
 feat('feature.props','request_derived',r['morphology'],'Visible morphology distinguishes the named object as one complete artifact.',derivation='The named '+r['object']+' is realized through ordinary recognizable visible morphology using general visual knowledge.'),
 feat('feature.pose','agent_visual_choice',r['pose'],'A relaxed reachable arm arrangement makes the stationary held display plausible.'),
 feat('feature.gaze','agent_visual_choice',r['gaze'],'Direct acknowledgment lends the portrait a personal presence.'),
 feat('feature.framing','explicit_request',r['visibility_evidence'],'The entire object must fit within the image boundary.',source=r['visibility_source']),
 feat('feature.lighting_source','agent_visual_choice',r['light'],'Soft illumination makes the person and the object surfaces legible together.')]
 selection={'contract_version':'photo-precore-feature-selection/v1','request_id':env['request_id'],'active_span_ids':['scene'],'catalog_path':'skills/photo-prompt-image-generator/precore/visual_feature_catalog.json','catalog_schema_version':'photo-precore-feature-catalog/v1','catalog_sha256':sha(catalog.read_bytes()),'request_sha256':env['request_sha256'],'baseline_prompt_sha256':psha,'selected':selected}
 write(d/'precore-feature-selection.json',selection);shutil.copyfile(catalog,d/'visual-feature-catalog.snapshot.json')
 (d/'baseline-prompt.txt').write_text(p+'\n')
 files=['request-envelope.json','source-request.txt','creative-context.json','creative-controls.json','authorial-core.raw.json','embodiment-review.json','precore-feature-selection.json','visual-feature-catalog.snapshot.json','baseline-prompt.txt']
 manifest={'schema_version':'object-action-held-input-freeze/v1','fixture_type':'coordinator-authored synthetic audit request, not an actual user image request','fixture_name':name,'frozen_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'authoring_boundary':'Only coordinator request envelope, SKILL.md, exact current precore creative-controls definitions/resolver and neutral visual-feature catalog were used. No assets, scripts, references, tests, earlier packs, or other experiment arms were read before freeze.','baseline_prompt_sha256':psha,'raw_core_file_sha256':sha((d/'authorial-core.raw.json').read_bytes()),'raw_core_json_canonical_sha256':sha(json.dumps(core,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()),'creative_controls_canonical_sha256':controls['canonical_sha256'],'files':{f:sha((d/f).read_bytes()) for f in files},'validation_status_at_freeze':'not_yet_run','paid_calls':0}
 write(d/'freeze-manifest.json',manifest)
 print(name,json.dumps({'raw_core_file_sha256':manifest['raw_core_file_sha256'],'baseline_prompt_sha256':psha,'freeze_manifest_file_sha256':sha((d/'freeze-manifest.json').read_bytes())}))
