import sys,json,pathlib,hashlib,datetime
root=pathlib.Path(__file__).resolve().parent
repo=pathlib.Path('REPOSITORY_ROOT');opened=[]
def guard(event,args):
 if event!='open':return
 path=args[0]
 if not isinstance(path,(str,bytes)):return
 s=str(path);opened.append(s)
 if any(t in s for t in ('/assets/','/references/','/tests/','candidate_pack','candidate-pack')):raise RuntimeError('Candidate-free validation refused open: '+s)
sys.addaudithook(guard);sys.dont_write_bytecode=True
sys.path.insert(0,str(repo/'skills/photo-prompt-image-generator/scripts'))
import prompt_generator as pg,photo_embodiment
for name in ('rapier-held','compound-bow-held'):
 d=root/name
 env=pg.normalize_request_envelope(json.loads((d/'request-envelope.json').read_text()))
 controls=json.loads((d/'creative-controls.json').read_text())
 raw=json.loads((d/'authorial-core.validated.raw.json').read_text())
 try:
  core=pg.normalize_authorial_core(raw,request_envelope=env,creative_control_snapshot=controls)
  review=photo_embodiment.validate_review(json.loads((d/'embodiment-review.json').read_text()),core['baseline_prompt_en'],core,'agent_prepack')
  (d/'authorial-core.normalized.json').write_text(json.dumps(core,ensure_ascii=False,indent=2)+'\n')
  result={'valid':True,'canonical_core_sha256':core['canonical_sha256'],'canonical_intent_lock_sha256':core['intent_lock']['canonical_sha256'],'embodiment_review_valid':True,'candidate_data_opened':False,'validated_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 except Exception as e: result={'valid':False,'error':str(e),'error_type':type(e).__name__}
 (d/'core-validation.repaired.json').write_text(json.dumps(result,indent=2)+'\n');print(name,json.dumps(result))
(root/'candidate-free-validation-open-log.repaired.json').write_text(json.dumps(opened,indent=2)+'\n')
