import json,copy,sys,hashlib
from pathlib import Path
O=Path(__file__).resolve().parent
A=O.parent/'object-action-scope-audit'
R=O.parents[1]/'image-prompt'
sys.path.insert(0,str(R/'skills/photo-prompt-image-generator/scripts'))
import prompt_generator as p
import validate_photo_prompt_dictionary as v
old=json.loads((A/'baseline-profiles.json').read_text()); proposed=json.loads((A/'proposed-profiles.json').read_text()); reviewed=copy.deepcopy(proposed)
# Additive lexical repair: retain existing legitimate held-object alternatives.
r=reviewed[0]; g=r['semantics']['component_semantics']['groups'][2]
g['any_terms']=old[0]['semantics']['component_semantics']['groups'][2]['any_terms']+g['any_terms']
r['evidence_requirements']['guard_phrase']['must_mention_any']+=old[0]['evidence_requirements']['guard_phrase']['must_mention_any']
# The emitted label should describe structure consistently with the revised definition.
r['runtime_expression']['prompt_label_terms']=['rapier with an elaborate swept or cup guard']
# Keep the old vertical example as an OPTIONAL example, adding neutral morphology.
b=reviewed[1]; b['semantics']['paraphrase_examples']=old[1]['semantics']['paraphrase_examples']+[proposed[1]['semantics']['paraphrase_examples'][1]]
(O/'reviewed-profiles.json').write_text(json.dumps(reviewed,ensure_ascii=False,indent=2)+'\n')
def differences(a,b,path=''):
 if isinstance(a,dict):
  return [d for k in a for d in differences(a[k],b[k],path+'/'+k)]
 if a!=b:return [{'path':path,'before':a,'after':b}]
 return []
(O/'reviewed-leaf-changes.json').write_text(json.dumps({x['id']:differences(x,y) for x,y in zip(old,reviewed)},ensure_ascii=False,indent=2)+'\n')
checks=[]
def check(name,value,detail=None):
 checks.append({'name':name,'passed':bool(value),'detail':detail}); assert value,name
for a,b in zip(old,reviewed):
 for key in ['activation','category','concept_candidate','required_evidence_fields','reject_substitutes']:
  check(a['id']+': unchanged '+key,a[key]==b[key])
 check(a['id']+': unchanged gates identities and scales',[(x['id'],x['review_scale']) for x in a['render_gates']]==[(x['id'],x['review_scale']) for x in b['render_gates']])
 for field,req in a['evidence_requirements'].items():
  check(a['id']+': floor '+field,req['min_content_words']==b['evidence_requirements'][field]['min_content_words'])
  check(a['id']+': old evidence retained '+field,set(req['must_mention_any'])<=set(b['evidence_requirements'][field]['must_mention_any']))
 for ga,gb in zip(a['semantics']['component_semantics']['groups'],b['semantics']['component_semantics']['groups']):
  check(a['id']+': old EN/KO components retained '+ga['id'],set(ga['any_terms'])<=set(gb['any_terms']))
 for language in [0,1]:
  text='; '.join(x['any_terms'][language] for x in a['semantics']['component_semantics']['groups'])
  check(a['id']+': old component match '+str(language),p.candidate_pack_visual_component_match(b,text)=='component_semantics')
 for omit in range(5):
  text='; '.join(x['any_terms'][0] for i,x in enumerate(b['semantics']['component_semantics']['groups']) if i!=omit)
  check(a['id']+': missing group rejected '+str(omit),p.candidate_pack_visual_component_match(b,text) is None)
for language in [0,1]:
 text='; '.join(x['any_terms'][2+language] if x['id']=='elaborate_hand_guard' else x['any_terms'][language] for x in r['semantics']['component_semantics']['groups'])
 check('rapier: new object-only component match '+str(language),p.candidate_pack_visual_component_match(r,text)=='component_semantics')
bindings=[]
for anchor in r['evidence_requirements']['guard_phrase']['must_mention_any']:
 phrase=anchor+' with distinct curved metalwork clearly separated from the slender blade'
 p.validate_visual_intent_binding(obligation_index=0,field='guard_phrase',phrase=phrase,requirement=r['evidence_requirements']['guard_phrase'])
 bindings.append({'phrase':phrase,'anchor_tokens':len(p.visual_intent_evidence_tokens(anchor)),'binding_tokens':len(p.visual_intent_evidence_tokens(phrase)),'floor':11})
 check('rapier guard binding: '+anchor,True,bindings[-1])
try:
 p.validate_visual_intent_binding(obligation_index=0,field='guard_phrase',phrase=r['evidence_requirements']['guard_phrase']['must_mention_any'][0],requirement=r['evidence_requirements']['guard_phrase'])
 short_rejected=False
except ValueError:short_rejected=True
check('underfloor neutral anchor remains rejected',short_rejected)
assets=R/'skills/photo-prompt-image-generator/assets'
registry=p.load_visual_obligation_registry(assets/'photo_prompt_visual_obligations.json')
index=p.load_visual_profile_index(assets/'photo_prompt_visual_profile_index.json',registry)
controls=[('rapier','An adult curator holds a rapier beside a museum display for a full-object catalog portrait.',True),('rapier','성인 큐레이터가 레이피어를 손에 든 박물관 도록 사진.',True),('compound bow','An adult museum presenter holds a compound bow diagonally for an equipment catalog portrait.',True),('compound bow','성인 전시 안내원이 컴파운드 보우를 손에 든 도록 인물 사진.',True),('rapier','A rapier rests alone across a velvet display cushion with no person in frame.',False),('compound bow','A compound bow rests horizontally across a plain tabletop with no person in frame.',False)]
results=[]
for noun,text,adult in controls:
 resolution=p.resolve_visual_profile_hits(registry,[{'source':'concept_lock','text':text,'polarity':'required','priority':'critical','mandatory':True}],visual_profile_index=index,adult_context=adult)
 target=old[0 if noun=='rapier' else 1]['id']
 check('real baseline index control: '+text,any(h['profile_id']==target and h['hard_eligible'] and h['match_basis']=='exact' for h in resolution['hits']))
 results.append({'source_request':text,'synthetic':True,'adult_context':adult,'resolution':resolution})
(O/'independent-controls.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n')
for noun in ['greatsword','plain cruciform sword','recurve bow','longbow','bow','활']:
 resolution=p.resolve_visual_profile_hits(registry,[{'source':'concept_lock','text':noun,'polarity':'required','mandatory':True}],visual_profile_index=index)
 check('adjacent noun does not hard-activate: '+noun,not any(h['profile_id'] in {x['id'] for x in old} and h['hard_eligible'] for h in resolution['hits']))
# Validate a copy of the entire actual registry, never writing the repository or creating an index.
local=copy.deepcopy(registry)
for i,profile in enumerate(local['profiles']):
 for replacement in reviewed:
  if profile['id']==replacement['id']:local['profiles'][i]=replacement
path=O/'reviewed-registry.schema-only.json';path.write_text(json.dumps(local,ensure_ascii=False))
errors=[];v.validate_visual_obligation_registry(path,errors)
check('reviewed full registry schema',not errors,errors)
(O/'measured-checks.json').write_text(json.dumps({'passed':sum(c['passed'] for c in checks),'total':len(checks),'checks':checks},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'passed':len(checks),'binding_details':bindings}))
