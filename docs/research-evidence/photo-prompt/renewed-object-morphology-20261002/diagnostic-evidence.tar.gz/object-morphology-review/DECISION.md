# Independent morphology review

Decision: approve the two DATA-only repairs **with the compatibility amendments in reviewed-profiles.json**, rather than accepting proposed-profiles.json byte-for-byte. Do not edit runtime routing or introduce still-life phrase exceptions. No repository files were edited by this review.

## Exact amendments to the submitted proposal

1. Rapier elaborate_hand_guard.any_terms retains both original EN/KO alternatives and adds both neutral alternatives. They are alternatives, so retaining legitimate held-object descriptions does not require a hand in every scene. Replacing the originals would unnecessarily regress component discovery for established language.
2. Rapier guard_phrase.must_mention_any puts the new neutral anchor first and retains the old held-hand anchor as another allowed alternative. Both accept the same unchanged min_content_words=11. Original anchor alone has 8 counted content words; new anchor alone has 9. Complete tested bindings have 15 and 16 respectively. The incomplete new anchor is still rejected. Do not mistake anchor length for a reason to weaken evidence floors.
3. Rapier runtime label becomes “rapier with an elaborate swept or cup guard” so the emitted label agrees with the neutral definition/gate. The existing optional Korean paraphrase describing a hand-protecting guard remains valid; it does not compel scene population.
4. Compound bow retains the old vertical paraphrase as an optional example and adds the orientation-neutral counterpart. This preserves a legitimate vertical depiction while removing vertical orientation from mandatory definition/composition/gate language.
5. All other proposed changes are accepted as written. No aliases, activation constraints, five-group requirements, evidence floors, gate IDs/scales, confound controls, or reject-substitute IDs are weakened. The references to upper/lower limbs remain anatomical labels; they do not mandate a vertical photograph.

Exact before/after arrays and fields are in reviewed-leaf-changes.json; complete replacement source records are in reviewed-profiles.json. These files are review artifacts, not a modified repository/index.

## Source grounding

Independently reopened on 2026-10-02:
- https://www.metmuseum.org/art/collection/search/24677 describes an acute-point blade and elaborate protective guard. Its object record supports guard morphology/function. It does not establish an actual in-frame gripping hand as a condition of rapier identity.
- https://www.worldarchery.sport/sport/equipment distinguishes compound equipment through pulleys/cables and provides an annotated object illustration. It does not establish a mandatory photographed hand or upright orientation.

The inference is strictly photographic: retain recognizable structure while respecting the requested scene population and orientation. No operating, aiming, constructing, tuning, optimization, or functional-status claims are added.

## Measured verification

review.py completed successfully: **74/74 assertions passed**, recorded in measured-checks.json.
- All old EN/KO component alternatives remain recognized by the actual component matcher
- New neutral rapier EN/KO component sets are recognized
- Dropping each required group fails component recognition for both profiles
- All original evidence alternatives and numerical floors are retained
- Both old held-hand and new neutral rapier evidence validate with sufficient descriptive words; the short new anchor fails
- Four independently authored EN/KO adult-held controls plus two object-only controls preserve exact hard activation through the actual loaded, metadata-validated current index
- Six adjacent/generic nouns do not hard-activate either profile
- A copied full registry with the reviewed replacements passes the actual registry schema validator

The controls are explicitly synthetic. They test exact routing, not semantic-vector relevance or generated pixels. These tests do not reuse the audit's authored requests. Source-only component tests call the real matcher directly, not a fabricated index. reviewed-registry.schema-only.json is a schema-validation copy only; do not use it as a production artifact or pair it with the old index.

## Limits and integration gate

The original public candidate-pack defects were independently inspected in the supplied audit artifacts, but no new public pack was generated against changed text. No vectors were generated or fabricated. A legitimate semantic index refresh for changed profile text and public before/after packs remain necessary before claiming integrated acceptance. Held-object controls should remain present and their requested contact should be retained by the authored core. The new gates allow held scenes; they do not independently audit hand contact, which belongs to a requested relation rather than a noun-only object contract.

The repository's existing weapon suite result is recorded separately in baseline-weapon-tests.log. It is a baseline regression check, not proof of post-integration behavior.

Final baseline regression result: `python -m unittest tests.test_photo_weapon_visual_semantics -v` passed **8/8 tests** in 77.107 seconds, exit 0. Final hashes are recorded in repo-hashes.json. They differ from the earlier audit snapshot, indicating concurrent workspace updates; this reviewer did not modify repository files. See final-repo-status.txt for the observed status. The loaded real index passed its runtime metadata check at test time.
