# Integrated AFTER evidence check

PASS at the focused visual-obligation layer. Both integrated source profiles exactly equal reviewed-profiles.json, and the actual visual-profile index loads with runtime metadata validation. Current commit and profile count are recorded in summary.json.

Four genuine public AFTER packs supplied by the scope worker were consumed without changing any pack bytes. Each has a complete evidence bundle with five independent component bindings, the required runtime label, explicit empty optional-concept selection, and the entire frozen baseline as an unchanged prompt prefix. The actual `audit_composed_prompt.audit_visual_obligations` returns no failures for all four. Removing any of the five required fields or its literal prompt occurrence is rejected: 40/40 negative checks.

- Rapier still-life: neutral guard/grip geometry satisfies all five obligations without requiring a pictured hand
- Rapier held portrait: the original held-hand guard evidence remains accepted; the authored person's grip and portrait survive verbatim
- Compound-bow still-life: baseline preserves its horizontal left-to-right table placement, with object-part “hand grip” terminology introducing no actual person
- Compound-bow held portrait: the authored grip contact and upright pose survive verbatim, showing that removing the mandatory upright rule does not prohibit a requested upright composition

The emitted obligations exactly retain the reviewed component groups, evidence rules, composition instruction, runtime label, and five render gates. None of the ten numerical evidence floors was reduced. Actual evidence counts range from 13 to 17 content tokens and exceed each field's floor (9–12).

Artifacts:
- `*-evidence-bundle.json`: complete bindings and focused prompt specimens
- `*-checks.json`: actual pack SHA-256/ID, five field token counts, positive result, and ten mutation rejection results per pack
- `summary.json`: machine-readable consolidated result
- `verify_after.py`: reproducible verification using repository functions and actual public packs

Scope: these are real focused composed-auditor visual-evidence checks, not schema-complete final compositions, full composed-audit passes, or rendered-pixel validation. No image generation, paid calls, runtime changes, vectors, or fabricated indexes were used. The original audit and review artifacts were preserved.
