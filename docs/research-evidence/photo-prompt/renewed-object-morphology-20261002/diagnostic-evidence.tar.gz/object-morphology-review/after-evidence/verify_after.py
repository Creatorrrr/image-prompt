import json,copy,sys,hashlib,subprocess
from pathlib import Path
O=Path(__file__).resolve().parent;ROOT=O.parents[2];R=ROOT/'image-prompt';A=O.parents[1]/'object-action-scope-audit/after-reviewed'
sys.path.insert(0,str(R/'skills/photo-prompt-image-generator/scripts'))
import prompt_generator as pg
import audit_composed_prompt as audit
profiles=json.loads((O.parent/'reviewed-profiles.json').read_text());assets=R/'skills/photo-prompt-image-generator/assets'
registry=pg.load_visual_obligation_registry(assets/'photo_prompt_visual_obligations.json');index=pg.load_visual_profile_index(assets/'photo_prompt_visual_profile_index.json',registry)
byid={p['id']:p for p in registry['profiles']}
assert all(byid[p['id']]==p for p in profiles)
phrases={
'rapier_acute_point_elaborate_guard':{
'blade_profile_phrase':'a long slender straight double-edged blade remains visible from guard to point, its narrow polished silhouette fully separated from the background',
'acute_point_phrase':'the narrow blade converges continuously into one acute thrusting point, with a single uncropped tip and uninterrupted taper',
'guard_phrase':'a swept or cup guard forms an elaborate protective enclosure around the grip, its distinct curved metalwork clearly separated from the slender blade',
'hilt_axis_phrase':'one hand grip and pommel align continuously with guard and blade, preserving the complete connected hilt silhouette and straight longitudinal axis',
'sword_confound_phrase':'a broad greatsword, short smallsword, or plain cruciform sword does not substitute for the long narrow rapier silhouette and intricate protective guard'},
'compound_bow_cam_cable_system':{
'riser_phrase':'a rigid central riser contains the hand grip and arrow window, with their distinct continuous contours readable in the central frame',
'split_limb_phrase':'upper and lower split limbs connect the riser to both cam assemblies, their paired outlines separated clearly against the plain background',
'paired_cam_phrase':'distinct cams or pulleys remain visible at both limb tips, each rounded assembly fully inside the uncropped object silhouette',
'cable_path_phrase':'bowstring and separate cable paths remain visually traceable around the cams, with distinct thin contours and clear background separation',
'bow_confound_phrase':'a recurve bow, longbow, or stock-mounted crossbow does not substitute for the recognizable central riser, paired cams, and distinct cables'}}
files=sorted(A.glob('*public-pack.json'))
if len(files)!=4:raise RuntimeError(f'Expected four actual AFTER public packs, found {files}')
results=[]
for file in files:
 raw=json.loads(file.read_text());pack=raw[0] if isinstance(raw,list) else raw
 obligations=pack['visual_obligations']['obligations'];assert len(obligations)==1
 ob=obligations[0];pid=ob['id'];profile=byid[pid]
 assert ob['render_gates']==profile['render_gates'] and len(ob['render_gates'])==5
 assert ob['composition_instruction']==profile['composition_instruction']
 assert ob['evidence_requirements']==profile['evidence_requirements']
 assert ob['component_semantics']==profile['semantics']['component_semantics']
 assert ob['runtime_expression']==profile['runtime_expression']
 core=pack['authorial_core'];held='held' in file.name
 binding=copy.deepcopy(phrases[pid])
 if held and pid.startswith('rapier'):
  binding['guard_phrase']='a swept or cup guard visibly encloses and protects the gripping hand, with distinct curved metalwork clearly separated from the slender blade'
 # Reuse the full frozen baseline verbatim, retaining contact/population/orientation as authored.
 baseline=core['baseline_prompt_en'];label=profile['runtime_expression']['prompt_label_terms'][0]
 prompt=baseline+' '+label+'. '+'. '.join(binding.values())+'.'
 composed={'prompt_en':prompt,'chosen_visual_concept_ids':[],'visual_obligation_evidence':{pid:binding}}
 failures=audit.audit_visual_obligations(pack,composed,prompt)
 assert not failures,failures
 counts={field:{'actual':len(audit.authorial_evidence_tokens(phrase)),'minimum':ob['evidence_requirements'][field]['min_content_words']} for field,phrase in binding.items()}
 negatives=[]
 for field in binding:
  missing=copy.deepcopy(composed);del missing['visual_obligation_evidence'][pid][field]
  fs=audit.audit_visual_obligations(pack,missing,prompt);assert fs
  negatives.append({'field':field,'mutation':'remove_required_field','failures':fs})
  unbound=prompt.replace(binding[field],'')
  fs=audit.audit_visual_obligations(pack,composed,unbound);assert any(f['check']=='visual_obligation_prompt_binding' for f in fs)
  negatives.append({'field':field,'mutation':'remove_literal_phrase','failures':fs})
 result={'pack_path':str(file),'pack_sha256':hashlib.sha256(file.read_bytes()).hexdigest(),'pack_id':pack['pack_id'],'source_request':core['source_request'],'held_control':held,'profile_id':pid,'five_gates_retained':True,'baseline_verbatim_prefix':prompt.startswith(baseline),'token_counts':counts,'focused_visual_audit_failures':failures,'negative_checks':negatives,'limitations':'Focused real composed-auditor visual-obligation check only. This evidence bundle is not a schema-complete composition or generated image.'}
 stem=file.name.replace('-public-pack.json','');(O/(stem+'-evidence-bundle.json')).write_text(json.dumps(composed,ensure_ascii=False,indent=2)+'\n');(O/(stem+'-checks.json')).write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');results.append(result)
(O/'summary.json').write_text(json.dumps({'exact_reviewed_sources':True,'current_commit':subprocess.check_output(['git','-C',str(R),'rev-parse','HEAD'],text=True).strip(),'real_index_metadata_validated':True,'profile_count':len(registry['profiles']),'positive_focused_passes':len(results),'negative_rejections':sum(len(x['negative_checks']) for x in results),'results':results},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'focused_positive_passes':len(results),'negative_rejections':sum(len(x['negative_checks']) for x in results)}))
