# Independent clearance representation review

## Decision

**Freeze one narrow `subject_framing` representation for independent qualification; KEEP the current corpus until qualification establishes a useful gain.** No repository addition is recommended yet. The frozen artifact is `frozen-representation.json`; its byte hash is recorded separately. No transfer/holdout tests informed this proposal.

The potentially useful increment is **joint crop retention of the already-authored constraining load contour, corresponding opening boundary, and carrying support**. It is not a new maneuver, a new clearance, or a newly chosen camera view. This core slot can own crop coverage honestly. The concept is transferable among rigid carried objects and physical apertures without selecting an object noun, location, pose angle, helper count, lens or lighting package.

This is a modest photographic evidence refinement. It does not establish a new scene family by itself, and its novelty relative to generic evidence-preserving framing remains a substantive qualification question.

## Ownership comparison

- **Action:** Reorienting a load to clear an opening is a real action, but adding it changes the event or its mechanics unless already authored. It can also alter the actor's body configuration/contact and the object's orientation. Merely declaring `action` does not give permission to change locked support or geometry. If all of that is already fixed, restating the maneuver gives little incremental action value. Do not relabel this as composition to obtain admission.
- **Body pose:** A new brace, pivot or supporting stance changes the actor's configuration, and potentially support. Not a compliant increment under the present frozen-event/support scope.
- **Composition:** Image-plane layout is an existing honest owner for layout refinements (`pe_level_horizon`, etc.). But separating previously overlapping physical contours or selecting another view to expose a hidden gap can require camera, framing, or physical scene changes. A vague “clearance-reading composition” conceals this distinction. The narrower crop-only proposal avoids promising it.
- **Camera direction:** Could own an explicitly permitted view change, but that is not the chosen proposal and should not be silently inferred from a framing row. A new angle could reveal or conceal required support and is not needed when the existing view already offers the required evidence.
- **Subject framing:** Reachable core slot, default dimension `framing`. Owns retaining the specified already-visible evidence within the image boundary. This is the smallest coherent candidate for the stated scope.
- **Prop/location:** Adding an opening, changing load rigidity or size, or adding a support is outside scope. New object/place rows would largely miss the operative relation.

## Frozen candidate and truthful effects

The row declares `affected_dimensions: ["framing"]` and `affected_properties: [{"dimension":"framing","target":"image_plane","property":"crop"}]`.

`crop` is a literal description of the permitted effect, not a lock-evasion alias. The schema accepts authored nonempty property paths; it does not provide a global canonical crop vocabulary. That absence is a limitation, not license to treat differently named locks as unrelated. A locked crop/framing/coverage requirement must be checked semantically even when the low-level string-overlap function would not recognize an equivalent path. The proposal cannot override whole-dimension framing locks. Do not substitute a special target such as `clearance_patch` to make the same crop appear compatible.

Avoid `target: "*", property: "*"`: the current compatibility helper compares target/property overlap across dimensions, so broad wildcard effects can collide with unrelated physical locks. Avoid expanding effects until the proposed change actually needs them. Conversely, if adoption changes camera, object geometry, action, support, or crop-excluded required evidence, reject this row rather than understating effects.

## Public scope and guard limitation

Both essential conditions and preservation boundaries are in the authored `concept_units`. `semantic_source` includes these units, relations, dimensions and effects; `apply_public_semantics` preserves them in the public unordered inspiration surface. The local projection check confirms this exact scope survives. There is no `contextual_usage` dependency.

The scope requires:
1. An already-authored adult carrying a rigid load through a narrow opening
2. Orientation, physical clearance and carrying support already established
3. All retained evidence available from the existing view
4. Freedom to change the crop while respecting all other required contents and locks

These are **public semantic adoption conditions, not an executable presence detector**. `for_any: ["human"]` is only a coarse applicability hint. Assertion discovery remains lexical and effect-gated; it does not prove the complete scene relation. A sampled row must still be declined on a near miss or insufficient context. No runtime/routing change is proposed to enforce those conditions.

If the intended acceptance criterion demands automatic mechanical rejection of every adult-with-doorway near miss, the current DATA-only representation does not provide that guarantee: KEEP/defer rather than pretend the prose is a machine guard.

## Existing-corpus overlap

Read-only review of current source assets found close compositional primitives but no inspected row stating this exact three-part crop relation:

- `frame_within_frame`, `doorway_frame_subject`, `doorway_threshold_framing`, `frame_within_frame_boundary_relation`: enclosing/framing a subject, not the controlling load/opening boundary with carrying support
- `pc_pc20_component_4`: preserve opening enclosure in crop; close but generic and portrait-focused
- `pc_px10_component_3`: keep nominated contour boundaries visible in crop; closest generic building block
- `pc_px05_component_3`: retain surviving facial/action evidence through occlusion; generic evidence retention
- `pc_px06_component_3`: keep contact readable; covers support/contact visibility separately
- `checking_accessible_route_clearance`: checking route usability, a different event
- `ducking_ear_clearance_doorway`: bodily clearance for ears, a different actor/object relation
- `pv_pivot_grounded`: grounded body pivot, not rigid carried-load clearance
- `ed_bus_stop_ready_candidate`, `ed_rain_threshold_candidate`: boarding and wet-umbrella threshold events, respectively

The proposed conjunction has a specific physical reason for retaining those contours together, but conjunction alone is not proof of novelty or utility. Compare against combinations of those existing rows, not only single-row keyword matches. If existing rows give equally faithful joint evidence with no extra authoring burden, KEEP.

## Evidence boundaries

The supplied primary-source addendum supports only the fact that rigid-item orientation relative to an opening matters to passage. Crop retention is a modest photographic inference from that spatial relation. It does not prove that a chosen load fits, a particular diagonal is best, a carrying technique is safe, or the image model will render correct geometry.

Primary source identified in the supplied evidence: West Elm, “How to Measure for Delivery,” page 2, https://www.westelm.com/weimgs/rk/images/i/201928/0021/images/pdf/design-details/guides/how_to_measure.pdf . Corroboration: DFS, https://www.dfs.co.uk/help/measuring-buying-guide . These sources were not reopened for this representation review; their supplied bounded summaries were used.

## Qualification boundaries, frozen before testing

Potentially usable input class: author already supplies the adult, rigid carried object, aperture, exact passage state, orientation, physical clearance and support; the same camera view exposes all three diagnostic regions; framing is open and the final crop can retain required evidence without changing geometry or other contents.

KEEP/defer if any of the following holds:
- Input lacks a carrying-through-opening event, rigid load, established physical clearance, or support ownership
- Proposed crop invents a gap, rotates the object, changes the passage phase, or substitutes another camera angle
- Required evidence is hidden from the fixed view, or cannot fit in an allowed crop
- Framing or equivalent crop/coverage intent is locked
- Public emission loses either the precondition or preservation boundary
- The gain is only repetition of existing generic contour/contact crop instructions
- Transfer performance depends on one fixed object, location, diagonal angle, phrase, or helper arrangement

Qualification must distinguish source eligibility, public emission, semantic adoption, and visible benefit. A schema pass or lexical retrieval hit is not a successful scene. Do not edit this frozen row to chase transfer results; any later revision is a new proposal with a new freeze and independent evidence.

## Read-only checks performed

- Read the two specifically permitted research documents; did not read original held-out lines, pre-existing proposal files, or prior test outcomes
- Inspected neutral current source assets and consumer/schema code only
- `validate_candidate_entries`: passed on the standalone row
- `CANDIDATE_PACK_CORE_SLOTS`: confirms `subject_framing` is core
- `semantic_source` → `apply_public_semantics`: exact concept units/effects survived
- No retrieval, selection, transfer, holdout, paid rendering or pixel validation was performed
- No repo edits, runtime/routing changes, or new external actions

Relevant implementation locations: `photo_candidate_semantics.py` (`validate_candidate_entries`, `semantic_source`, `apply_public_semantics`); `photo_contracts.py` (`property_effects_allowed`); `prompt_generator.py` (`CANDIDATE_PACK_CORE_SLOTS`, `candidate_pack_assertion_discovery`, `candidate_pack_summarize_slot_candidate`, `candidate_pack_compose_current`); `photo_prompt_tags.json` (`candidate_semantic_policy.slot_dimensions`).
