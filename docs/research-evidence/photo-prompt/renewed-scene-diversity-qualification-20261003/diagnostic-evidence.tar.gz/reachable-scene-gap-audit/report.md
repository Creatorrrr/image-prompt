# Reachable scene DATA gap audit

## Decision
Freeze one **bounded, provisional DATA hypothesis**: `carried_rigid_load_opening_clearance_relation` in `action`. The distinct relation is an already carried rigid load being reoriented relative to an existing narrow opening, while the established carriers retain continuous support. The closest reviewed rows contain cargo, narrow spaces, cooperative handling or supported pauses, but do not combine orientation, boundary clearance and carried support. This is a semantic difference, not a missing-word claim.

This is not a finding that the entire corpus lacks every equivalent, nor a recommendation to merge immediately. The audit deliberately reviews only 15 nearest corpus candidates per family. Current consumer ranking/category/cap issues limit inference from visible output. No DATA addition, runtime change, paid call or render was performed.

## Input and provenance boundary
Read only `scene-diversity-research/development-families.md` for research scenes. The original research document and transfer holdouts were not opened. Read actual merged runtime corpus through `load_runtime_data()` and current consumer code. Source S2 (bus-stop infrastructure) and S3 (carried-object/obstacle action in video) motivate Family B; the specific candidate is an independently authored extrapolation, not a claim that either public source contains this exact operation. Their previously recorded originals were not revalidated here:
- https://x.com/underwoodxie96/status/2072225990605230294
- https://x.com/aiwithaly/status/2100462425308901480

## Bounded nearest-alternative method
For each development family, a single family-relation query ranks the merged inventory restricted to `action`, `prop`, `location`, `narrative_core`, and `concept_tension`, with the existing BM25F index. Only its top 15 entries are semantically reviewed; full records, ranks and query code are saved. These are lexical shortlists, not guaranteed semantically nearest neighbors. Corpus-scope and actual consumer eligibility are separately recorded; a gated row is not declared absent, and a row technically eligible is not declared semantically appropriate. All five target slots were included even where no narrative/concept entry ranked into a family shortlist.

## Preliminary current-consumer reachability
Three independent development cores were normalized as v3 inputs with creative-control snapshots and generated through `generate_candidate_pack`, without changing source or routing. Each uses explicit `subject_category: human`; returned categories are exactly `[human]`. Each includes a literal-evidence `body_action` review for ownership, reach, balance, contact and visibility. These are human-authored text checks, not synthetic `not_applicable` reviews and not pixel validation.

Important limit: core construction uses the fixture helper's ordinary concept/subject/event locks and generic style scaffold. It does **not** exhaustively author requested property locks. Therefore this establishes preliminary action-slot reachability only, not full current-workflow qualification, safe adoption or prompt/embodiment efficacy. The final acceptance must use independently authored property-complete inputs; keep this limitation even though normalization and generation pass.

All three packs hit the unchanged 64-candidate cap. B1 actually publishes the action slot with four candidates. Prop is absent in B1. The proof therefore does not rely on adding a prop or moving a candidate to a later slot. B1's exposed actions are unrelated material-process/portal/summoning rows: their appearance is evidence that the slot is reachable, not evidence that the scene is covered. No knobs were changed to make an addition appear.

### A1
- Categories: ['human']
- Total published preprojection candidates: 64
- action: weaving_leather_strips_by_hand, supporting_crossbow_mechanism_profile, tactile_crease_contact_action, ed_library_page_turn_candidate
- concept_tension: vulnerability_vs_protection_tension, human_touch_vs_automation_tension, analog_vs_ai_tension, realistic_vs_dreamlike_tension
- location: biaoju_gate_loading_yard_road, market_stare_documentary_lane
- narrative_core: quiet_rebellion_core, near_future_nostalgia_core, analog_diary_memory_core, digital_privacy_core
- prop: pr_instant_print_material_object_candidate, repeated_dream_orientation_anchor_prop, basted_toile_dress_form_prop, cello_endpin_bowed_prop
### B1
- Categories: ['human']
- Total published preprojection candidates: 64
- action: cooling_transmuted_material, distilling_visible_material_transition, opening_two_world_threshold_crossing, summoning_distinct_entity_arrival
- concept_tension: vulnerability_vs_protection_tension, organic_vs_synthetic_tension, realistic_vs_dreamlike_tension, polished_vs_imperfect_tension
- location: jianghu_mountain_pass_waystation, biaoju_gate_loading_yard_road, heritage_travel_case_workshop, pf_drawbridge_location
- narrative_core: ordinary_magic_core, private_ritual_core, ai_companion_core, fragile_intimacy_core
### C1
- Categories: ['human']
- Total published preprojection candidates: 64
- action: geomungo_suldae_strike_action, ed_library_page_turn_candidate, supporting_crossbow_mechanism_profile, ed_cafe_pickup_wait_candidate
- concept_tension: organic_vs_synthetic_tension, vulnerability_vs_protection_tension, human_touch_vs_automation_tension, analog_vs_ai_tension
- location: private_client_material_salon, professional_kitchen_pass_hygiene_station
- narrative_core: quiet_rebellion_core, urban_solitude_core, analog_diary_memory_core, near_future_nostalgia_core
- prop: matched_gemstone_setting_layout_tray, instant_ramen_cup_prop, cello_endpin_bowed_prop, y2kr_cd_player_tabletop

## Family judgments
A has real overlap in flexible-surface continuity, support contacts, sag and rolling, plus narrowly authored care and threshold concepts. A drainage/containment relation may merit later work, but this audit does not propose one.

C has real overlap in component containment, tool contact, restraint and repair work across specialized domains. Those rows must stay narrow. More ordinary repair coverage might be useful, but neither noun absence nor inaccessible specialized rows is enough to justify broadening them here. No C proposal.

B supplies the single provisional relation above. Its development-positive scope is B1. B2 is wheeled cart steering with branch/rail clearance and is deliberately **not** a positive for a carried-load action. B3 is temporary resting support plus strap tightening and is also **not** a positive. Scene transfer should vary the rigid object and opening, not silently extend to wheeled or flexible loads.

## Reviewed alternatives (15 per family)

### Family A
1. `action.tactile_gather_contact_action` — Genuine partial overlap: continuous flexible surface, support contacts and gravity sag. Does not assert receiving material or directing runoff; preserve its existing sheet-only scope. Preliminary A1 corpus eligibility: True.
2. `location.bt_critical_containment_location` — Deliberately narrow critical-threshold test system, not ordinary spill containment. Preliminary A1 corpus eligibility: False.
3. `prop.character_creepy_cute_scene_prop` — Tarp noun exists only in a character-scene prerequisite; noun presence does not establish the practical containment relation. Preliminary A1 corpus eligibility: False.
4. `prop.working_broom_prop` — Flight-specific broom; never repurpose this row into mundane tarp support. Preliminary A1 corpus eligibility: False.
5. `action.tactile_roll_contact_action` — Genuine continuous-sheet rolling geometry, but not blocking fluid at a doorway. Preserve its specific operation. Preliminary A1 corpus eligibility: True.
6. `action.broom_flight_across_moon` — Witch-flight operation, incompatible with mundane work. Preliminary A1 corpus eligibility: False.
7. `action.character_creepy_cute_scene_action` — Actual tarp bracing and rain shielding, but fixed creature/surveyor scene and gated prerequisites; not a decomposable everyday containment carrier. Preliminary A1 corpus eligibility: False.
8. `action.character_observable_personality_scene_action` — Practical work coordination exists; it redirects attention, not material flow. Preliminary A1 corpus eligibility: False.
9. `prop.rain_towel_prop` — Towel after rain is a care prop; do not broaden it into a threshold seal. Preliminary A1 corpus eligibility: True.
10. `prop.ice_pack_wrapped_in_towel_prop` — Clinical wrapped ice pack, deliberately distinct from containment. Preliminary A1 corpus eligibility: True.
11. `action.bt_critical_driver_action` — Accumulating physical load before a critical transition differs from local controlled drainage. Preliminary A1 corpus eligibility: False.
12. `action.ctx_rolled_sleeve_task` — Sleeve-folding preparation differs from manipulating a barrier. Preliminary A1 corpus eligibility: False.
13. `action.karst_losing_stream_spring_connection` — Natural karst drainage has a real source-path relation but no actor-directed containment; preserve geology. Preliminary A1 corpus eligibility: False.
14. `action.des_recognition_present_work_action` — Audience attention toward work differs from handling runoff. Preliminary A1 corpus eligibility: False.
15. `prop.des_recognition_textless_marker_prop` — Textless achievement marker has no containment relation. Preliminary A1 corpus eligibility: False.

### Family B
1. `location.biaoju_gate_loading_yard_road` — Cargo plus gate-to-road affordance exists, but this broad-gate location explicitly leaves turning space; it does not express a carried load reoriented because an opening is too narrow. Preliminary B1 corpus eligibility: True.
2. `action.biaoju_guarded_convoy_departure` — Guarded convoy transport is genuine cargo movement, but its operative relation is protection/distribution and departure, not carried-load orientation for clearance. Preliminary B1 corpus eligibility: False.
3. `prop.wuxia_jianghu_escort_handoff_prop` — Specialized wuxia handoff prop bundle; repaired wheels and cases do not imply constrained passage. Preliminary B1 corpus eligibility: False.
4. `prop.biaoju_loaded_cart_sealed_cargo_set` — Roadworthy loaded cart and coherent wheels express wheeled support; cannot stand in for hand-supported rigid-load passage. Preliminary B1 corpus eligibility: True.
5. `prop.multispecies_world_corridor_prop` — Crossing gate noun in a multi-species world bundle does not establish the proposed relation. Preliminary B1 corpus eligibility: False.
6. `prop.character_relationship_chemistry_scene_prop` — Cooperative worker tool/brace control is real shared manipulation but not load-axis/opening clearance; fixed character prerequisites remain. Preliminary B1 corpus eligibility: False.
7. `prop.punk_atompunk_maintenance_handoff_prop` — Service-cart shift handoff is wheeled maintenance logistics, not manual carried-load negotiation. Preliminary B1 corpus eligibility: False.
8. `location.har_ottoman_layered_domestic_complex_location` — Narrow circulation is architectural context in a deliberately historical household; no relevant load movement is asserted. Preliminary B1 corpus eligibility: False.
9. `narrative_core.conlang_conculture_world_narrative_core` — Negotiation means community authority here; unrelated to physical orientation. Preliminary B1 corpus eligibility: False.
10. `location.pf_arrow_loop_location` — Narrow slit geometry exists but is a defensive wall opening, not an established cargo passage. Preliminary B1 corpus eligibility: True.
11. `location.pf_bosquet_location` — Narrow garden entrance is a location affordance alone; no load orientation or support continuity. Preliminary B1 corpus eligibility: True.
12. `action.ed_park_rest_candidate` — Best everyday partial alternative: supported pause beside path with carried item. It can cover a rest aspect of B3, but neither object-axis clearance nor strap adjustment is entailed. Preliminary B1 corpus eligibility: True.
13. `action.character_creepy_cute_scene_action` — Tarp support involves a flexible shelter, not a rigid carried object moving through an opening. Preliminary B1 corpus eligibility: False.
14. `action.ctx_rolled_sleeve_task` — Sleeve folding is unrelated action preparation. Preliminary B1 corpus eligibility: False.
15. `prop.retrofuture_infrastructure_world_archive_prop` — Archive disposition cart is an object-world prop, no constrained carried passage. Preliminary B1 corpus eligibility: False.

### Family C
1. `prop.removed_suspect_component_tray` — Genuine removed-component containment beside assessed product, but reuse-assessment scope is deliberate; no stabilization/tool operation implied. Preliminary C1 corpus eligibility: False.
2. `prop.matched_gemstone_setting_layout_tray` — Genuine parts layout and mounting structure, but jewelry-specific; not generic loose caster repair. Preliminary C1 corpus eligibility: True.
3. `prop.tuner_alignment_targets_data_logger_and_shop_tools` — Genuine wrench and wheel chocks, but tuner practice remains narrower than generic repair. Preliminary C1 corpus eligibility: False.
4. `prop.machined_component_tray_prop` — Genuine component tray; manufacturing residue and repeatable geometry should not be broadened into removed washers. Preliminary C1 corpus eligibility: True.
5. `prop.bt_limiter_restraint_prop` — Functional mechanical constraint exists, but releasing a limiter differs from stabilizing a workpiece during repair. Preliminary C1 corpus eligibility: False.
6. `prop.punk_magipunk_maintenance_handoff_prop` — Component replacement/repair completion in magipunk world, not the proposed generic in-progress manipulation. Preliminary C1 corpus eligibility: False.
7. `location.community_repair_bench` — Explicit open device, reusable parts and organized tools; electronics-specific context should stay narrow. Preliminary C1 corpus eligibility: False.
8. `action.testing_component_continuity` — Explicit tool-component contact and diagnosis; real partial coverage, but continuity measurement differs from mechanical fastening or retrieval. Preliminary C1 corpus eligibility: False.
9. `location.bt_overload_dependency_location` — Failure network exposure is system diagnostic framing, not supported small-part manipulation. Preliminary C1 corpus eligibility: False.
10. `prop.punk_cyberpunk_maintenance_handoff_prop` — Working hardware handoff after repair does not imply in-progress physical stabilization. Preliminary C1 corpus eligibility: False.
11. `action.character_attribute_composition_scene_action` — Repairing a loose strap is a narrow signature-personality scene, not a generic stabilization relation. Preliminary C1 corpus eligibility: False.
12. `action.living_armor_independent_motion` — Articulated armor independent agency differs from repairing an ordinary object. Preliminary C1 corpus eligibility: False.
13. `prop.punk_dieselpunk_mechanism_prop` — Explicit active mechanic tool contact and opened engine, genuine repair coverage within dieselpunk scope. Preliminary C1 corpus eligibility: False.
14. `action.performing_tethered_eva_repair_action` — Strongest partial relation: restrained actor plus direct tool-component contact. EVA-specific support/scene should not be broadened to mundane work. Preliminary C1 corpus eligibility: False.
15. `prop.socket_wrench_prop` — Wrench noun alone is not repair geometry; preserves straightforward tool availability. Preliminary C1 corpus eligibility: True.

## Frozen candidate and adoption limits
`frozen-candidate-proposal.json` is schema-valid in isolation using the existing candidate-entry validator; it has not been inserted into a corpus, indexed, or tested as an actual candidate. Its SHA-256 and no-holdout-exposure declaration are in `proposal-freeze.json`.

The proposal has two concept units and one supported-orientation-for-clearance relation; no named place, outfit, lighting, camera, genre, helper count, fixed prop species or scene package. It carries explicit `action`, `pose`, and `relationship` effects with broad wildcard property scope. This is intentionally conservative: partial requester property locks should reject the candidate rather than exploit the missing-affected-properties path. All affected dimensions must be explicitly open. The already frozen event must establish reorientation for passage; the candidate cannot insert a new tilting operation into a generic or incompatible locked event. This is why action-slot publication in B1 must not be reported as adoption qualification.

Before an addition is recommended: independently review the frozen semantic difference, obtain property-complete cores with appropriate action/pose/relationship openness and real scene-specific embodiment evidence, test actual proposal retrieval without changing runtime, then evaluate untouched transfer holdouts. Wrong interpretations include decorative mirror posing, wall-mounted mirror, no passage through the boundary, unsupported/telekinetic load, a substitute reflection for a helper, and wheeled-cart steering. Any metadata change requires a new explicit freeze before holdout use; do not tune against holdouts.

## Artifacts and reproducibility
- `probe.py`, `probe.log`: merged-data shortlist and current-consumer development probes
- `nearest-candidates.json`: complete 45 reviewed rows, lexical ranks and scores
- `A1/B1/C1-inputs.json`, corresponding `*-pack.json`: normalized inputs, text reviews and complete public packs
- `reachability.json`: categories, actual core-slot inventory, cap counts and shortlist eligibility
- `frozen-candidate-proposal.json`, `proposal-freeze.json`: candidate definition and freeze
- `freeze_proposal.py`: isolated existing-schema validation

Run `.venv/bin/python ../daylong-progress-20261002/reachable-scene-gap-audit/probe.py` from the repository for the zero-cost probe. No image generation or network call is used.
