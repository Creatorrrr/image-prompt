"""Zero-cost boundary probe. Never edits the frozen proposal or repository corpus.
An isolated in-memory appended row tests actual producer emission, not source installation.
"""
import json,sys,copy,hashlib
from pathlib import Path
P=Path(__file__).parent;R=Path('REPOSITORY_ROOT')
sys.path.insert(0,str(R/'skills/photo-prompt-image-generator/scripts'))
import prompt_generator as g
import photo_contracts as c
proposal_bytes=(P/'frozen-candidate-proposal.json').read_bytes();row=json.loads(proposal_bytes)
source=g.photo_candidate_semantics.semantic_source(row,'action')
checks={}
for dim,prop in [('action','operation'),('pose','stance'),('relationship','support'),('appearance','wardrobe.color'),('color','palette'),('setting','location.identity'),('subject','object.identity'),('camera','focal_length')]:
 lock={'contract_version':'photo-intent-lock/v2','semantic_anchors':[{'dimension':dim,'target':'unrelated_target','property':prop}]}
 checks[dim+':'+prop]=c.property_effects_allowed(lock,row['affected_dimensions'],row['affected_properties'])
checks['no_partial_property_locks']=c.property_effects_allowed({'contract_version':'photo-intent-lock/v2','semantic_anchors':[]},row['affected_dimensions'],row['affected_properties'])
D=g.load_runtime_data();D['slots']['action'].append(copy.deepcopy(row))
inputs=json.loads((P/'B1-inputs.json').read_text())
pack=g.generate_candidate_pack(D,inputs['core'],inputs['controls'],inputs['review'],seed=7)
public=[x for x in pack.get('slots',{}).get('action',{}).get('candidates',[]) if x['entry_id']==row['id']]
(P/'frozen-proposal-in-memory-pack.json').write_text(json.dumps(pack,ensure_ascii=False,indent=2))
contract,picked=g.frozen_core_context(D,inputs['core'],inputs['controls'])
# Use real current eligibility function with established incompatible scene contexts;
# these are function-boundary negative probes, not qualified workflow cores.
negative={}
for name,subject,event in [('posed_portrait','one adult person','the adult stands empty handed for a portrait'),('wheeled_cart','one adult person','the adult steers a wheeled handcart around a bend'),('locked_incompatible_event','one adult person','the adult sits still beside a wall-mounted mirror')]:
 core=copy.deepcopy(inputs['core']); core['subject']=subject;core['event']=event
 con,pi=g.frozen_core_context(D,core,inputs['controls'])
 negative[name]=g.core_slot_entry_eligible(D,core,con,pi,'action',row)
summary={'frozen_sha256':hashlib.sha256(proposal_bytes).hexdigest(),'frozen_bytes_unchanged':proposal_bytes==(P/'frozen-candidate-proposal.json').read_bytes(),'semantic_source':source,'source_contains_contextual_usage':'contextual_usage' in source,'property_guard_results':checks,'actual_public_candidate':public,'public_candidate_present':bool(public),'public_contains_contextual_usage':any('contextual_usage' in x for x in public),'public_contains_application_conditions':'application_conditions' in json.dumps(public),'open_dimensions':inputs['core']['intent_lock']['open_dimensions'],'declared_effect_dimensions_explicitly_open':set(row['affected_dimensions']).issubset(inputs['core']['intent_lock']['open_dimensions']),'incompatible_context_entry_eligibility':negative,'probe_limits':'Appended an unchanged proposal only to a private in-memory runtime data object; no repository source or index writes. Original B1 fixture core is preliminary and under-locks properties. Negative probes inspect eligibility function only and do not normalize altered cores or claim full workflow validity.'}
(P/'frozen-boundary-results.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
print(json.dumps(summary,ensure_ascii=False,indent=2))
