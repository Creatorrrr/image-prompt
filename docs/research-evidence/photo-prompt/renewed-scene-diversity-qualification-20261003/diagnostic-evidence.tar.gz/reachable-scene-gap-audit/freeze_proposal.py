import json,hashlib,sys
from pathlib import Path
OUT=Path(__file__).parent
ROOT=Path('REPOSITORY_ROOT')
sys.path[:0]=[str(ROOT/'skills/photo-prompt-image-generator/scripts')]
import prompt_generator as g
proposal={
'id':'carried_rigid_load_opening_clearance_relation',
'ko':'이미 운반 중인 단단한 물체의 방향을 틀어 좁은 통과 경계와의 여유를 확보하는',
'en':'reorienting an already carried rigid load to clear an existing narrow opening while keeping its supports continuous',
'weight':0.45,'tags':['human','physical_relation','carried_load'],'for_any':['human'],
'aliases':[],
'keywords':['load orientation','opening clearance','continuous carrying support'],
'concept_units':['the already carried rigid load changes orientation relative to an existing narrow opening','its visible supported points remain connected to the established carriers while the load clears the boundary'],
'relations':[{'id':'carried_rigid_load_opening_clearance','type':'supported_orientation_for_clearance','subject':'the established carriers and their already carried rigid load','object':'the existing narrow opening whose boundary determines the required load orientation'}],
'affected_dimensions':['action','pose','relationship'],
'affected_properties':[{'dimension':d,'target':'*','property':'*'} for d in ['action','pose','relationship']],
'embedding_text':'An already carried rigid load is tilted or turned relative to an existing narrow opening so its occupied width clears the boundary, with the established carriers maintaining visible hand support. This refines an already authored reorientation-for-passage event.',
'contextual_usage':{'contexts':[{'id':'carried_load_clearance_scope','application_conditions':[
'The frozen core must already establish the adult carriers, a rigid carried load, a narrow opening, and a reorientation-for-passage operation. This relation refines that operation; it does not invent the object, opening, helper, goal, or a different event.',
'Action, pose, and relationship effects must all be explicitly open. The broad wildcard property declarations intentionally fail closed against partial requester property locks; do not remove them to evade a guard.',
'Any event or load orientation fixed by the requester remains authoritative. A locked incompatible orientation, support arrangement, or event makes this candidate inapplicable.',
'The object is carried with continuous support from the established carrier or carriers. Wheeled cart steering, rotating a vehicle, flexible-sheet deformation, strap tightening and decorative mirror posing are outside this candidate.',
'No place, wardrobe, weather, visual genre, camera, light, identity, material or object-category change is supplied.'
]}]}}
g.photo_candidate_semantics.validate_candidate_entries({'slots':{'action':[proposal]}},g.AUTHORIAL_CORE_V3_INTENT_LOCK_DIMENSIONS)
text=json.dumps(proposal,ensure_ascii=False,indent=2)+'\n'
(OUT/'frozen-candidate-proposal.json').write_text(text)
(OUT/'proposal-freeze.json').write_text(json.dumps({'frozen_at_utc':'2026-10-03T01:55:00Z','sha256':hashlib.sha256(text.encode()).hexdigest(),'holdout_exposure':False,'status':'bounded-gap hypothesis; schema-valid proposal, no repository insertion, no efficacy claim','effects_policy':'Broad wildcard scope deliberately fails closed for any intersecting requester property lock.'},indent=2)+'\n')
print(hashlib.sha256(text.encode()).hexdigest())
