import sys,json,hashlib
from pathlib import Path
ROOT=Path('REPOSITORY_ROOT'); OUT=Path(__file__).parent
sys.path[:0]=[str(ROOT/'skills/photo-prompt-image-generator/scripts'),str(ROOT/'tests')]
import prompt_generator as g
import photo_prompt_fixtures as f
D=g.load_runtime_data()
queries={
'A':'temporary containment redirect runoff spill flexible sheet sagging tarp tension broom bucket dustpan soil rolled towel threshold barrier',
'B':'awkward bulky cargo negotiate narrow opening rotate tilt brace long rigid carried object gate handrail cart rolled rug temporary support strap',
'C':'repair opened device loose component stabilize clamp wrench tighten fastener caster mounting plate retrieve screw magnet shallow tray removed wheel thorn'}
slots={'action','prop','location','narrative_core','concept_tension'}
idx=g._core_slot_index(json.dumps(D['slots'],ensure_ascii=False,sort_keys=True,separators=(',',':')))
ids=[f'slot:{s}:{r["id"]}' for s in slots for r in D['slots'][s]]
result={}
for family,q in queries.items():
 rows=g.rank_bm25f(idx,{'slot_focus':q},allowed_ids=ids,limit=15)
 result[family]=[{'rank':n+1,'slot':r['document_id'].split(':')[1],'entry':g.candidate_pack_slot_entry_by_id(D,*r['document_id'].split(':')[1:]),'retrieval':r} for n,r in enumerate(rows)]
(OUT/'nearest-candidates.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
for family,rows in result.items():
 print('\nFAMILY',family)
 for r in rows:print(r['rank'],r['slot'],json.dumps(r['entry'],ensure_ascii=False))
scenes={
'A1':dict(subject='an adult vendor',setting='a market stall after a shower',event='the vendor raises a sagging tarp corner with a broom handle so a narrow stream pours from its low edge into a bucket',priority='the supported tarp edge and the stream entering the bucket'),
'B1':dict(subject='two adult people carrying a tall rigid framed mirror',setting='a station luggage gate beside empty narrow turnstiles',event='one adult tilts the tall framed mirror diagonally through the opening while the companion steadies its bottom corner from the far side',priority='the long mirror axis angled through the gate with the supported bottom corner visible'),
'C1':dict(subject='an adult caretaker',setting='a library service alcove',event='the caretaker holds a loose caster against the mounting plate of a book trolley laid on its side and tightens a bolt with a short wrench; removed washers lie in a shallow lid',priority='the supporting hand, caster mounting plate and contacting wrench tip'),
}
output={}
for name,s in scenes.items():
 request=f"Photograph {s['subject']} at {s['setting']}: {s['event']}."
 baseline=f"At {s['setting']}, {s['event']}. Show {s['priority']}. The adult feet remain grounded with stable balance and the working hands remain visibly connected to their own arms. A clear oblique view separates the hands, the carried or manipulated object and its supports without hiding the relevant contact points. Restrained daylight preserves natural proportions and readable surface details."
 controls=g.creative_controls.resolve(request,overrides={'sensual':0,'fetish':0,'creativity':1,'surreal':0},context={'subject_category':'human'},seed=7)
 raw=f.core(request,subject=s['subject'],setting=s['setting'],event=s['event'],visual_priorities=(s['priority'],'visible grounded adult support'),interpreted_intent=s['event'],baseline_prompt_en=baseline)
 raw['creative_controls_sha256']=controls['canonical_sha256']
 core=g.normalize_authorial_core(raw,request_envelope=f.envelope(request),creative_control_snapshot=controls)
 review={'contract_version':'photo-embodiment-review/v1','provenance':'agent_prepack','prompt_sha256':hashlib.sha256(core['baseline_prompt_en'].encode()).hexdigest(),'scope':'body_action','summary':'Text-only development-scene review; plausible visible support and contact, not image validation.','checks':{}}
 ev={'body_ownership':('working hands remain visibly connected to their own arms','Hands are explicitly tied to their own actor arms.'),'joint_chain_and_reach':(s['event'],'The action uses supported objects and nearby hand contact without requiring dislocated joints.'),'support_and_balance':('adult feet remain grounded with stable balance','The actors remain standing on the surface and maintain stable support.'),'contact_and_space':(s['priority'],'The priority makes the relevant hand, object, boundary and contact relationships inspectable.'),'visibility_and_projection':('clear oblique view separates the hands','The view separates the manipulation contact points from the object and supports.')}
 for check,(evidence,reason) in ev.items(): review['checks'][check]={'status':'supported','reason':reason,'prompt_evidence':[evidence]}
 pack=g.generate_candidate_pack(D,core,controls,review,seed=7)
 (OUT/(name+'-pack.json')).write_text(json.dumps(pack,ensure_ascii=False,indent=2))
 (OUT/(name+'-inputs.json')).write_text(json.dumps({'core':core,'controls':controls,'review':review,'envelope':f.envelope(request)},ensure_ascii=False,indent=2))
 slot_data,binding,contract=g.retrieve_core_slots(D,core,controls)
 output[name]={'categories':contract['intent_constraints']['subject_categories'],'visible_slots':{slot:[r['entry_id'] for r in item['candidates']] for slot,item in slot_data.items() if slot in slots},'total_candidates':sum(len(item['candidates']) for item in slot_data.values()),'nearest_eligibility':[{ 'id':x['entry']['id'],'slot':x['slot'],'eligible':g.core_slot_entry_eligible(D,core,contract,g.frozen_core_context(D,core,controls)[1],x['slot'],x['entry'])} for x in result[name[0]]]}
 print('REACH',name,json.dumps(output[name]))
(OUT/'reachability.json').write_text(json.dumps(output,ensure_ascii=False,indent=2))
