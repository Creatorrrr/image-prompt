# Frozen proposal boundary review

## Decision: do not accept this proposal as usable DATA gain

The physical-relation hypothesis remains a potentially useful bounded finding, but the frozen first proposal is not ready for acceptance. This review supersedes any inference that its prose application conditions provide executable safe applicability. The original proposal and preliminary report/results remain unchanged for independent review.

Frozen proposal SHA-256 remains `988605e249a3ccd6034a332b5e1eb2bdbd2dc1d375a380e7897455b2d7bc339f`.

## 1. Wildcard property effects reject every partial property lock

The existing `photo_contracts.property_effects_allowed` compares target/property overlap across dimensions, intentionally preventing a carrier-dimension trick. Each proposal effect has `target: *`, `property: *`. Therefore **any** v2 semantic anchor with a property rejects this candidate, including an unrelated actor's wardrobe color, palette, location identity, object identity or camera focal length. It is not limited to action/pose/relationship locks.

Direct tests against action, pose, relationship, appearance, color, setting, subject and camera property anchors all returned false. The no-partial-property-lock control returned true. This means our preliminary underlocked B1 core is precisely the kind of permissive input that can show a superficially eligible proposal; that output cannot establish usable gain under a property-complete real request.

The earlier report's wording about 'intersecting requester property locks' was insufficiently explicit. Actual restriction: any partial property lock, even in a seemingly unrelated dimension or target, conflicts with these wildcard effects.

## 2. The core-slot public semantic surface drops all application conditions

The actual `photo_candidate_semantics.semantic_source` copies concept units, relations, affected dimensions, affected properties and optional canonical concept ID. It does not copy contextual_usage/application_conditions.

The ordinary core-slot summarizer does not copy them either. `build_candidate_pack` adds the semantic source and property-compatibility result; final projection restores the semantic units/relations/effects, not contextual usage.

To verify actual emission without changing source files, the byte-identical frozen row was appended only to a private in-memory copy of loaded runtime data, and normal `generate_candidate_pack` ran with the existing B1 inputs. The new row was actually retrieved and published as `eligible` in the action slot. The final emitted candidate contains its concept units, one relation, three dimensions and three wildcard effects, but **neither contextual_usage nor application_conditions**. Complete resulting pack: `frozen-proposal-in-memory-pack.json`.

This is an emission test, not a repository addition or a production qualification. No corpus/index files or frozen proposal were modified.

## 3. The prose preconditions are not executable core-slot guards

`core_slot_entry_eligible` checks slot/category/domain controls, for_any/exclude_for_any, declared prerequisite tags/facets/slot rules and exclusions. `compatible_with_slot_context` checks structured requires/exclude keys and authored slot rules. Neither evaluates free-form contextual_usage.application_conditions.

Function-boundary negative probes returned eligible for the unchanged row when the preliminary B1 core's subject/event were replaced with (a) an empty-handed posed portrait, (b) wheeled-cart steering, and (c) sitting beside a wall-mounted mirror. These are deliberately **function-boundary** probes, not normalized full-workflow cores, so they prove only that this eligibility function does not enforce those prose restrictions.

The proposal has only `for_any: human` among direct scene-category restrictions. Its instructions that the core already contain the carried load, opening and passage operation, that wheeled support be excluded, and that all three affected dimensions be explicitly open are maintenance prose in this path. They are not carried to the ordinary public candidate or executed as candidate prerequisites.

The actual in-memory B1 public row is marked eligible even though B1's explicit open_dimensions do not include action or pose. This does not mean final composition adoption would pass: downstream open-dimension and property checks are separate. It does show that published eligibility is insufficient evidence of safely usable adoption.

Some other lanes copy contextual_usage (for example contextual adult augmentation), but that is not proof for this ordinary action/core-slot path and was not used to rescue this proposal.

## Result interpretation

- Source schema consistency: passes
- Frozen bytes preserved: yes
- Actual ordinary action-slot retrieval/public emission in underlocked B1: yes
- Application conditions present in emitted candidate: no
- Prose application conditions executed as eligibility guards: no
- Compatible with any partial property lock: no
- Full property-complete workflow/adoption qualification: not established
- Usable eligible DATA benefit: **not established; do not count as progress or merge**

No property paths were tuned, effects omitted, prerequisite tags invented, routing changed or runtime repaired. Any future revision must be explicitly reviewed and independently frozen; this first proposal remains an unchanged failed applicability/emission-boundary artifact.

## Reproduction

Run `.venv/bin/python ../daylong-progress-20261002/reachable-scene-gap-audit/probe_frozen_boundaries.py` from the repository. It writes only audit artifacts outside the repository and uses no paid/network calls. See `frozen-boundary-results.json` for source output, full emitted candidate, property-guard controls and eligibility negatives.
