import json,datetime,subprocess
from pathlib import Path
P=Path(__file__).parent; R=Path('REPOSITORY_ROOT')
n=json.loads((P/'nearest-candidates.json').read_text()); reach=json.loads((P/'reachability.json').read_text())
comments={
'A':[
'Genuine partial overlap: continuous flexible surface, support contacts and gravity sag. Does not assert receiving material or directing runoff; preserve its existing sheet-only scope.',
'Deliberately narrow critical-threshold test system, not ordinary spill containment.',
'Tarp noun exists only in a character-scene prerequisite; noun presence does not establish the practical containment relation.',
'Flight-specific broom; never repurpose this row into mundane tarp support.',
'Genuine continuous-sheet rolling geometry, but not blocking fluid at a doorway. Preserve its specific operation.',
'Witch-flight operation, incompatible with mundane work.',
'Actual tarp bracing and rain shielding, but fixed creature/surveyor scene and gated prerequisites; not a decomposable everyday containment carrier.',
'Practical work coordination exists; it redirects attention, not material flow.',
'Towel after rain is a care prop; do not broaden it into a threshold seal.',
'Clinical wrapped ice pack, deliberately distinct from containment.',
'Accumulating physical load before a critical transition differs from local controlled drainage.',
'Sleeve-folding preparation differs from manipulating a barrier.',
'Natural karst drainage has a real source-path relation but no actor-directed containment; preserve geology.',
'Audience attention toward work differs from handling runoff.',
'Textless achievement marker has no containment relation.'
],
'B':[
'Cargo plus gate-to-road affordance exists, but this broad-gate location explicitly leaves turning space; it does not express a carried load reoriented because an opening is too narrow.',
'Guarded convoy transport is genuine cargo movement, but its operative relation is protection/distribution and departure, not carried-load orientation for clearance.',
'Specialized wuxia handoff prop bundle; repaired wheels and cases do not imply constrained passage.',
'Roadworthy loaded cart and coherent wheels express wheeled support; cannot stand in for hand-supported rigid-load passage.',
'Crossing gate noun in a multi-species world bundle does not establish the proposed relation.',
'Cooperative worker tool/brace control is real shared manipulation but not load-axis/opening clearance; fixed character prerequisites remain.',
'Service-cart shift handoff is wheeled maintenance logistics, not manual carried-load negotiation.',
'Narrow circulation is architectural context in a deliberately historical household; no relevant load movement is asserted.',
'Negotiation means community authority here; unrelated to physical orientation.',
'Narrow slit geometry exists but is a defensive wall opening, not an established cargo passage.',
'Narrow garden entrance is a location affordance alone; no load orientation or support continuity.',
'Best everyday partial alternative: supported pause beside path with carried item. It can cover a rest aspect of B3, but neither object-axis clearance nor strap adjustment is entailed.',
'Tarp support involves a flexible shelter, not a rigid carried object moving through an opening.',
'Sleeve folding is unrelated action preparation.',
'Archive disposition cart is an object-world prop, no constrained carried passage.'
],
'C':[
'Genuine removed-component containment beside assessed product, but reuse-assessment scope is deliberate; no stabilization/tool operation implied.',
'Genuine parts layout and mounting structure, but jewelry-specific; not generic loose caster repair.',
'Genuine wrench and wheel chocks, but tuner practice remains narrower than generic repair.',
'Genuine component tray; manufacturing residue and repeatable geometry should not be broadened into removed washers.',
'Functional mechanical constraint exists, but releasing a limiter differs from stabilizing a workpiece during repair.',
'Component replacement/repair completion in magipunk world, not the proposed generic in-progress manipulation.',
'Explicit open device, reusable parts and organized tools; electronics-specific context should stay narrow.',
'Explicit tool-component contact and diagnosis; real partial coverage, but continuity measurement differs from mechanical fastening or retrieval.',
'Failure network exposure is system diagnostic framing, not supported small-part manipulation.',
'Working hardware handoff after repair does not imply in-progress physical stabilization.',
'Repairing a loose strap is a narrow signature-personality scene, not a generic stabilization relation.',
'Articulated armor independent agency differs from repairing an ordinary object.',
'Explicit active mechanic tool contact and opened engine, genuine repair coverage within dieselpunk scope.',
'Strongest partial relation: restrained actor plus direct tool-component contact. EVA-specific support/scene should not be broadened to mundane work.',
'Wrench noun alone is not repair geometry; preserves straightforward tool availability.'
]}
text='''# Reachable scene DATA gap audit

## Decision
Freeze one **bounded, provisional DATA hypothesis**: `carried_rigid_load_opening_clearance_relation` in `action`. The distinct relation is an already carried rigid load being reoriented relative to an existing narrow opening, while the established carriers retain continuous support. The closest reviewed rows contain cargo, narrow spaces, cooperative handling or supported pauses, but do not combine orientation, boundary clearance and carried support. This is a semantic difference, not a missing-word claim.

This is not a finding that the entire corpus lacks every equivalent, nor a recommendation to merge immediately. The audit deliberately reviews only 15 nearest corpus candidates per family. Current consumer ranking/category/cap issues limit inference from visible output. No DATA addition, runtime change, paid call or render was performed.

## Input and provenance boundary
Read only `scene-diversity-research/development-families.md` for research scenes. The original research document and transfer holdouts were not opened. Read actual merged runtime corpus through `load_runtime_data()` and current consumer code. Source S2 (bus-stop infrastructure) and S3 (carried-object/obstacle action in video) motivate Family B; the specific candidate is an independently authored extrapolation, not a claim that either public source contains this exact operation. Their previously recorded originals were not revalidated here:
- https://x.com/underwoodxie96/status/2072225990605230294
- https://x.com/aiwithaly/status/2100462425308901480

## Bounded nearest-alternative method
For each development family, a single family-relation query ranks the merged inventory restricted to `action`, `prop`, `location`, `narrative_core`, and `concept_tension`, with the existing BM25F index. Only its top 15 entries are semantically reviewed; full records, ranks and query code are saved. These are lexical shortlists, not guaranteed semantically nearest neighbors. Corpus-scope and actual consumer eligibility are separately recorded; a gated row is not declared absent, and a row technically eligible is not declared semantically appropriate. All five target slots were included even where no narrative/concept entry ranked into a family shortlist.

## Preliminary current-consumer reachability
Three independent development cores were normalized as v3 inputs with creative-control snapshots and generated through `generate_candidate_pack`, without changing source or routing. Each uses explicit `subject_category: human`; returned categories are exactly `[human]`. Each includes a literal-evidence `body_action` review for ownership, reach, balance, contact and visibility. These are human-authored text checks, not synthetic `not_applicable` reviews and not pixel validation.

Important limit: core construction uses the fixture helper's ordinary concept/subject/event locks and generic style scaffold. It does **not** exhaustively author requested property locks. Therefore this establishes preliminary action-slot reachability only, not full current-workflow qualification, safe adoption or prompt/embodiment efficacy. The final acceptance must use independently authored property-complete inputs; keep this limitation even though normalization and generation pass.

All three packs hit the unchanged 64-candidate cap. B1 actually publishes the action slot with four candidates. Prop is absent in B1. The proof therefore does not rely on adding a prop or moving a candidate to a later slot. B1's exposed actions are unrelated material-process/portal/summoning rows: their appearance is evidence that the slot is reachable, not evidence that the scene is covered. No knobs were changed to make an addition appear.

'''
for key,v in reach.items():
 text+=f"### {key}\n- Categories: {v['categories']}\n- Total published preprojection candidates: {v['total_candidates']}\n"
 for slot,ids in v['visible_slots'].items():text+=f"- {slot}: {', '.join(ids)}\n"
text+='''
## Family judgments
A has real overlap in flexible-surface continuity, support contacts, sag and rolling, plus narrowly authored care and threshold concepts. A drainage/containment relation may merit later work, but this audit does not propose one.

C has real overlap in component containment, tool contact, restraint and repair work across specialized domains. Those rows must stay narrow. More ordinary repair coverage might be useful, but neither noun absence nor inaccessible specialized rows is enough to justify broadening them here. No C proposal.

B supplies the single provisional relation above. Its development-positive scope is B1. B2 is wheeled cart steering with branch/rail clearance and is deliberately **not** a positive for a carried-load action. B3 is temporary resting support plus strap tightening and is also **not** a positive. Scene transfer should vary the rigid object and opening, not silently extend to wheeled or flexible loads.

## Reviewed alternatives (15 per family)
'''
for fam,rows in n.items():
 text+=f'\n### Family {fam}\n'
 eligibility={r['id']:r['eligible'] for r in reach[fam+'1']['nearest_eligibility']}
 for i,row in enumerate(rows):
  e=row['entry']; text+=f"{i+1}. `{row['slot']}.{e['id']}` — {comments[fam][i]} Preliminary {fam}1 corpus eligibility: {eligibility[e['id']]}.\n"
text+='''
## Frozen candidate and adoption limits
`frozen-candidate-proposal.json` is schema-valid in isolation using the existing candidate-entry validator; it has not been inserted into a corpus, indexed, or tested as an actual candidate. Its SHA-256 and no-holdout-exposure declaration are in `proposal-freeze.json`.

The proposal has two concept units and one supported-orientation-for-clearance relation; no named place, outfit, lighting, camera, genre, helper count, fixed prop species or scene package. It carries explicit `action`, `pose`, and `relationship` effects with broad wildcard property scope. This is intentionally conservative: partial requester property locks should reject the candidate rather than exploit the missing-affected-properties path. All affected dimensions must be explicitly open. The already frozen event must establish reorientation for passage; the candidate cannot insert a new tilting operation into a generic or incompatible locked event. This is why action-slot publication in B1 must not be reported as adoption qualification.

Before an addition is recommended: independently review the frozen semantic difference, obtain property-complete cores with appropriate action/pose/relationship openness and real scene-specific embodiment evidence, test actual proposal retrieval without changing runtime, then evaluate untouched transfer holdouts. Wrong interpretations include decorative mirror posing, wall-mounted mirror, no passage through the boundary, unsupported/telekinetic load, a substitute reflection for a helper, and wheeled-cart steering. Any metadata change requires a new explicit freeze before holdout use; do not tune against holdouts.

## Artifacts and reproducibility
- `probe.py`, `probe.log`: merged-data shortlist and current-consumer development probes
- `nearest-candidates.json`: complete 45 reviewed rows, lexical ranks and scores
- `A1/B1/C1-inputs.json`, corresponding `*-pack.json`: normalized inputs, text reviews and complete public packs
- `reachability.json`: categories, actual core-slot inventory, cap counts and shortlist eligibility
- `frozen-candidate-proposal.json`, `proposal-freeze.json`: candidate definition and freeze
- `freeze_proposal.py`: isolated existing-schema validation

Run `.venv/bin/python ../daylong-progress-20261002/reachable-scene-gap-audit/probe.py` from the repository for the zero-cost probe. No image generation or network call is used.
'''
(P/'report.md').write_text(text)
meta=json.loads((P/'proposal-freeze.json').read_text());meta['freeze_recorded_at_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();meta['candidate_first_frozen_at_utc_approx']=meta.pop('frozen_at_utc');(P/'proposal-freeze.json').write_text(json.dumps(meta,indent=2)+'\n')
print(P/'report.md')
