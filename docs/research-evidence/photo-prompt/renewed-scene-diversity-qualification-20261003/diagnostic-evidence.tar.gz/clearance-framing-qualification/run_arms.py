"""Offline synthetic qualification. Never writes repository or calls providers."""
import copy,hashlib,json,sys,time
from pathlib import Path
P=Path(__file__).parent;R=P.parent.parent/'image-prompt';sys.path.insert(0,str(R/'skills/photo-prompt-image-generator/scripts'))
import prompt_generator as g
import photo_contracts as contracts
revision=sys.argv[1];proposal=P.parent/'clearance-representation-review/frozen-representation.json';frozen=proposal.read_bytes();row=json.loads(frozen)['entry'];spec=json.load(open(P/'qualification-spec.json'));assert hashlib.sha256(frozen).hexdigest()==spec['proposal_sha256']
pre=json.load(open(P/f'preflight-{revision}.json'));assert len(pre['prepared'])==6 and not pre['failures']
original=g.load_runtime_data();summary=[]
for name in pre['prepared']:
 inp=json.load(open(P/f'adapted-{revision}'/name/'inputs.json'));core=inp['normalized_core'];outputs={};started=time.time()
 for arm in ['baseline','opt_in','normal_lane']:
  D=copy.deepcopy(original)
  if arm!='baseline':
   entry=copy.deepcopy(row)
   if arm=='normal_lane':entry['core_assertion_discovery']=False
   D['slots']['subject_framing'].append(entry)
  pack=g.generate_candidate_pack(D,core,inp['controls'],inp['review'],seed=829)
  assert pack['authorial_core']['baseline_prompt_en']==core['baseline_prompt_en']
  assert pack['authorial_core']['source_request']==core['source_request']
  assert pack['authorial_core']['intent_lock']==core['intent_lock']
  out=P/'results'/name;out.mkdir(parents=True,exist_ok=True);(out/(arm+'.json')).write_text(json.dumps(pack,ensure_ascii=False,indent=2)+'\n')
  visible=[x for block in pack.get('slots',{}).values() for x in block.get('candidates',[])]
  selected=[x for x in visible if x.get('entry_id')==row['id']]
  contract,picked=g.frozen_core_context(D,core,inp['controls'])
  outputs[arm]={'total':len(visible),'ids':[x['id']for x in visible],'proposal':selected,'source_eligible':g.core_slot_entry_eligible(D,core,contract,picked,'subject_framing',row),'property_compatible':contracts.property_effects_allowed(core['intent_lock'],row['affected_dimensions'],row['affected_properties']),'baseline_preserved':pack['authorial_core']['baseline_prompt_en']==core['baseline_prompt_en'],'subject_categories':contract['intent_constraints']['subject_categories']}
  print(name,arm,len(visible),bool(selected),selected[0]['applicability']if selected else None,flush=True)
 base=set(outputs['baseline']['ids'])
 for arm in ['opt_in','normal_lane']:
  ids=set(outputs[arm]['ids']);outputs[arm]['added_ids']=sorted(ids-base);outputs[arm]['removed_ids']=sorted(base-ids)
 summary.append({'case':name,'elapsed_seconds':time.time()-started,'arms':outputs});(P/'results-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
assert proposal.read_bytes()==frozen
