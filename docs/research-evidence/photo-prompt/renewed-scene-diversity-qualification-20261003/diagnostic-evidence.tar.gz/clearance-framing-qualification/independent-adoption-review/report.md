# Independent semantic adoption review: rigid-load/opening crop

## Recommendation

**KEEP the current corpus and all six authored baselines. Defer promotion of the frozen proposal.** Here KEEP means no candidate addition or scene rewrite, not adoption of the proposed candidate. No case establishes a substantive useful increment. The drying-rack transfer is conditionally compatible but already expresses the proposed relationship; the mirror positive is weaker than its qualification label because it names a wide luggage gate. Labels such as positive_original were not treated as ground truth.

## Isolation, provenance and limits

This is an independent read-only semantic review of six explicitly synthetic audit inputs, not actual user messages. It inspected the frozen proposal, the named r4 manifest and records, and current authored source/ownership code. It did not execute retrieval, inspect retrieval outputs, previous proposal reviews or other qualification results, inspect generated indexes, call paid APIs, use external agents, generate images, or edit repository candidates. Only this report directory and temporary report-writing scripts were written.

All six record hashes, UTF-8 synthetic-request hashes and UTF-8 baseline hashes matched the r4 manifest. All six embodiment review hashes match their baseline. Source URLs are preserved in provenance.json exactly as inherited; the records say they were creative inspiration only and the original X pages were inaccessible. Those URLs were not opened or independently verified here and are not evidence that any external author requested these scenes.

- Repository HEAD: `3c3b3a649afc04a5b39abc23a0e57084ba34fec2`
- Frozen proposal SHA-256: `84bad9cd733961fc8ec4f881f0659d98b3efc0e2d7ec2ca5e5f9db4727a50fc0`
- r4 manifest SHA-256: `4518b6536364f1ce83196aee64c128c66042be57374fb25fa98903e1b5837557`
- Byte-exact proposal copy: `frozen-representation.exact.json`
- Complete source hashes, request-grounded anchors and original source links: `provenance.json`
- Exact inspected comparator entries and source JSON pointers: `inspected-candidate-sources.json`
- Structured case findings: `adoption-review.json`

No adapter, normal core validation, candidate selection, final-prompt audit, runtime or pixel result is claimed. The manifest retains its synthetic metadata caveats; this review did not fabricate a requester envelope or creative-control hash. Geometry is assessed from text, not a camera/kinematic solver or an image.

## What the unchanged proposal actually requires

`subject_framing:rigid_load_opening_evidence_crop` has two indivisible semantic units. It applies only to an already authored adult carrying a rigid load through a narrow opening, with orientation, clearance and carrying support established and visible from the existing view. The crop must retain the controlling load contour, the corresponding opening boundary and carrying support together. It keeps physical gap, orientation, passage phase, actor contacts and support unchanged, and introduces no viewpoint, object, helper or support. The relation retained_evidence joins that exact contour/boundary pair to the established carrying support.

This is a retention suggestion, not permission to solve missing geometry. A crop can discard scene regions; it cannot expose an occluded grip, create space at a jamb, change a load's orientation, relocate a companion, or reveal off-frame ground support without changing the authored realization. The candidate's “Only for” prerequisite remains a semantic condition even if an ordinary source filter or public pack admits it.

“Carrying support” does not unambiguously require visible feet. Existing hand/forearm support may supply the load support. A reviewer must not invent a universal full-body rule from this phrase. Conversely, if the actual support mechanism is off-view and necessary to establish the proposal's relation, a crop cannot manufacture it. The exact waist-up case deliberately keeps bodily standing support outside the image.

## Three separate evidence levels

1. **Source eligibility and public emission:** source inspection only. The proposal declares for_any human, affected_dimensions framing, affected_properties framing/image_plane/crop, and core_assertion_discovery true. `photo_prompt_tags.json` assigns subject_framing to framing. `photo_candidate_semantics.py` preserves concept units and optional adoption; its structural validation does not prove scene predicates. `prompt_generator.py` core_slot_entry_eligible applies ordinary category/domain/context/exclusion guards, and candidate_pack_assertion_discovery additionally checks open dimensions and property compatibility. `photo_contracts.py` explicitly says property declarations still require semantic review. Whole-dimension locks are independent of property checks. No retrieval/emission outcome was observed.

2. **Semantic adoption:** an eligible or emitted item must still preserve the complete authored meaning. Crop ownership does not authorize downstream loss of locked empty turnstiles, a bag between shoes, visible wheel angle, complete mirror or both contacts. Declared image_plane.crop cannot excuse changes to those other semantic properties. Likewise, words in an embedding cannot certify the “Only for” conjunction.

3. **Pixel benefit:** entirely untested. No claim of improved composition, more accurate clearance, successful generation, load capacity or balance verification follows from this report.

## Case-by-case review

### b1_mirror_gate

**Decision: DEFER_NOT_ESTABLISHED. Keep the baseline.**

Request: At a station's wide luggage gate, an adult tilts a tall framed mirror diagonally through the opening while a companion steadies its bottom corner from the far side; the adjacent narrow turnstiles remain empty.

The acted-on opening is a wide luggage gate, not the adjacent narrow turnstiles. The exact proposal requires an already authored narrow opening. The gate might be restrictive relative to the mirror, but neither baseline nor request establishes that relative bottleneck; do not supply it from the proposal. All other central load/contact/clearance conditions are present.

Preservation boundary: Only unchanged-view crop retention of the existing diagonal frame, both gate-edge gaps, carrier grips and far-side companion support, also preserving empty adjacent narrow turnstiles and reflection/actor distinction. No narrowing, helper movement, new feet/support or reorientation.

Increment assessment: The baseline already authors visible gate gaps and separate contacts. A generic evidence-preserving crop can retain them; the proposal adds narrow-opening conditionality rather than a demonstrated missing visual relation.

Closest inspected existing IDs: `crop_boundary_anchor_integrity`, `pc_px09_component_3`, `pc_px10_component_3`, `pc_px06_component_3`, `pc_px06_component_2`.

### b1_tight_crop

**Decision: DECLINE_LOCKED_FRAMING_AND_UNESTABLISHED_PREREQUISITE. Keep the baseline.**

Request: At a station's wide luggage gate, an adult tilts a tall framed mirror diagonally through the opening while a companion steadies its bottom corner from the far side; the adjacent narrow turnstiles remain empty. Use a tight waist-up crop ending at both adults’ waists, with both legs and feet entirely outside the image; keep the complete mirror and both hand-to-frame contacts visible.

Framing is wholly locked to both waists, excluding legs and feet, while complete mirror and both hand-to-frame contacts are separately anchored. The scene again acts at a wide luggage gate. A crop alteration cannot be justified by a framing-only candidate; unchanged repetition is not a material adoption benefit.

Preservation boundary: Keep the current waist endpoints, complete shallow-diagonal mirror above the edge, visible hand contacts and gate gaps. Do not widen downward to show feet, move the camera, raise/shrink/rotate the mirror or shift either actor.

Increment assessment: The baseline already supplies the exact co-visibility demanded within the fixed crop. Carrying support can mean visible grips; the proposal does not justify treating feet as mandatory.

Closest inspected existing IDs: `crop_boundary_anchor_integrity`, `pc_px01_component_1`, `pc_px07_component_3`, `pc_px12_component_1`, `pc_px06_component_3`.

### b2_wheeled_cart

**Decision: DECLINE_WRONG_MECHANISM. Keep the baseline.**

Request: On a ferry boarding ramp, a florist turns a handcart sideways at a bend, using one forearm to keep tall wrapped branches from scraping the handrail; the cart's front wheels are visibly angled.

Branches remain on a wheel-supported handcart moving around a ramp bend, not a rigid hand-carried load passing through a narrow opening. The forearm guides the stems away from one rail; it does not replace the cart support.

Preservation boundary: Generic crop preservation may retain angled front wheels, cart/floor contacts, hand/handle and opposite forearm/stem contacts, branch/rail gap and open ramp beyond the bend. Do not invent a doorway or lift the load.

Increment assessment: Existing general evidence/contour/contact preservation already describes the usable crop operation without misclassifying the action.

Closest inspected existing IDs: `crop_boundary_anchor_integrity`, `pc_px09_component_3`, `pc_px06_component_3`, `pc_px06_component_1`.

### b3_strap_adjustment

**Decision: DECLINE_WRONG_EVENT_AND_SUPPORT. Keep the baseline.**

Request: At a bus shelter in daylight, a traveller rests one end of a rolled rug on the bench while tightening a strap around its middle, with the free end projecting past the seat and a bag held between their shoes.

A bench supports one end of a rolled rug during strap tightening; the free end projects beyond the seat and a bag stays between the shoes. There is no narrow opening, carried-passage phase, or established rigid load.

Preservation boundary: Retain buckle/strap-hand ownership, bench contact, projecting roll, both grounded shoes and between-shoes bag in the existing oblique side frame. Do not turn bench or shelter edges into an opening or lift the rug.

Increment assessment: The baseline already says to show bench contact, projecting roll and hands together and retain shoes/bag. General evidence-preserving cropping suffices.

Closest inspected existing IDs: `crop_boundary_anchor_integrity`, `pc_px06_component_3`, `pc_px06_component_1`, `pc_px10_component_3`.

### b_empty_handed_pose

**Decision: DECLINE_CONTRADICTS_POSITIVE_INTENT. Keep the baseline.**

Request: An empty-handed adult stands in a narrow municipal doorway, shoulders square to the opening and both hands relaxed beside their hips, posing for a photograph.

The adult is explicitly empty-handed, stationary, square to the doorway, with relaxed hands beside the hips. A narrow doorway alone cannot supply a carried object, gripping support, rotation or passage phase. Empty user_exclusions do not negate the positive empty-handed anchors.

Preservation boundary: Keep full-length view, empty hands, square shoulders, jambs, threshold and complete stance. No load, helper or new contact may be added.

Increment assessment: Any useful preservation is generic portrait/contour crop work and does not realize the proposal compound meaning.

Closest inspected existing IDs: `crop_boundary_anchor_integrity`, `pc_px01_component_1`, `pc_px09_component_3`, `pc_px10_component_3`.

### b_transfer_drying_rack

**Decision: CONDITIONALLY_COMPATIBLE_BUT_REDUNDANT. Keep the baseline.**

Request: a caretaker rotating a folded drying rack edge-on through a narrow municipal doorway.

The folded metal-rail assembly is held off the floor, rotates edge-on through a narrow doorway, has a leading edge inside and trailing edge beside the caretaker, and has visible gaps at both jambs plus two readable grips in the same oblique view. The accompanying prepack review specifies an ordinary adult body model; the request and baseline do not independently state age.

Preservation boundary: A crop could retain the existing narrow rack profile, both jamb gaps, both grips and their actor ownership, while preserving folded state, passage phase, stance/support, public-building context and existing inside oblique viewpoint. No extra adult-age prose, rigidification, rotation, contact or new support is needed or justified.

Increment assessment: This co-visibility is already explicitly written. The proposal packages contour/boundary/contact retention into one conditional unit but demonstrates no missing relationship beyond general anchor-safe crop plus contour/contact preservation. No crop coordinates or pixels prove an improvement.

Closest inspected existing IDs: `crop_boundary_anchor_integrity`, `pc_px09_component_3`, `pc_px10_component_3`, `pc_px06_component_3`, `pc_px06_component_2`.

### Clarifications that affect the decisions

- The mirror can be large relative to a wide gate, so “wide” is not a mathematical impossibility proof. But the authored text establishes visible space, not that the acted-on luggage gate is a narrow bottleneck relative to this load. Inferring that from the proposal would supply a prerequisite after the fact. The adjacent narrow turnstiles belong to a different, explicitly empty route. A candidate label or broad similarity must not move the mirror into them. Therefore b1_mirror_gate is deferred on the exact frozen wording rather than asserted physically impossible.

- The tight-crop baseline places the mirror at a shallow diagonal with its lowest corner above the crop edge. This is a text-plausible authored arrangement, not a measured proof that every possible tall mirror fits there. It must not be “repaired” by enlarging the crop, changing scale, moving the camera or reorienting the mirror for this crop-only qualification. Keeping the same crop can be semantically harmless repetition, but does not establish a substantive adoption.

- The drying-rack prepack review calls its body model ordinary adult; the baseline itself merely says caretaker. Conditional compatibility uses that authored review context without inventing an adult-age lock or adding age prose. If the proposed entry demands explicit adulthood in requester/baseline text alone, that narrower interpretation makes this case deferred too. Either interpretation leaves the no-increment recommendation unchanged. The metal rail assembly is already folded, held and turned as one flat load; the candidate cannot lock its hinges or change its shape to make it more rigid.

## Closest current-source candidates: exact text and scope

These are direct source inspections, not a returned inventory or an assertion that the runtime will emit or admit every comparator in these six cases. In particular, several portrait entries have no property-scoped effects and carry portrait-specific owner relations. Their complete meaning must not be stripped away to claim a drop-in substitute.

### `crop_boundary_anchor_integrity` (`composition`)

Exact English label: “crop-boundary integrity that keeps every meaning-bearing anchor and its connection inside the frame”

Source: `skills/photo-prompt-image-generator/assets/photo_prompt_reactorprompt_visual_relations_extension.json` at `/slots/composition/0`.

Exact source embedding text: “the crop keeps every required landmark, contact point, connected limb, material edge, and directional continuation visible while incidental regions may leave the frame”

This is the strongest existing generic comparator: required landmarks, contact points, material edges and their connections can include a load/opening relationship already authored in the scene. The embedding expands the source meaning; this review does not claim every word of it appears in a public candidate surface. The source slot owns composition, so actual eligibility and property effects remain a separate check.

### `pc_px09_component_3` (`subject_framing`)

Exact English label: “the separation survives the final crop and display size”

Source: `skills/photo-prompt-image-generator/assets/photo_prompt_portrait_composition_extension.json` at `/slots/subject_framing/17`.

Caveat: this entry carries a portrait/frame owner relation; the exact source entry and affected dimensions are retained in the comparator file. No source-scope bypass or eligibility result is inferred.

### `pc_px10_component_3` (`subject_framing`)

Exact English label: “all nominated contour boundaries remain visible in the crop”

Source: `skills/photo-prompt-image-generator/assets/photo_prompt_portrait_composition_extension.json` at `/slots/subject_framing/18`.

Caveat: its aliases concern body-bounded negative space/arm-torso aperture, and its declared owner is the requester-supported main portrait and frame. It is related contour-preservation machinery, not unrestricted authority to reinterpret a body aperture as a municipal doorway.

### `pc_px06_component_3` (`composition`)

Exact English label: “the contact remains visible at the required final review scale”

Source: `skills/photo-prompt-image-generator/assets/photo_prompt_portrait_composition_extension.json` at `/slots/composition/51`.

Caveat: this entry carries a portrait/frame owner relation; the exact source entry and affected dimensions are retained in the comparator file. No source-scope bypass or eligibility result is inferred.

### `pc_px06_component_1` (`contact_point`)

Exact English label: “each visible hand connects to a plausible subject or entering frame-edge owner”

Source: `skills/photo-prompt-image-generator/assets/photo_prompt_portrait_composition_extension.json` at `/slots/contact_point/4`.

Caveat: this concerns body geometry or action rather than merely crop. It is a comparator for already established ownership/contact, not permission to move hands, change grips or add a new contact to repair a crop.

### `pc_px06_component_2` (`contact_point`)

Exact English label: “the nominated hand contacts the object at a traceable grip or support point”

Source: `skills/photo-prompt-image-generator/assets/photo_prompt_portrait_composition_extension.json` at `/slots/contact_point/5`.

Caveat: this concerns body geometry or action rather than merely crop. It is a comparator for already established ownership/contact, not permission to move hands, change grips or add a new contact to repair a crop.

### `pc_px01_component_1` (`subject_framing`)

Exact English label: “the crop endpoint explicitly describes the included body extent”

Source: `skills/photo-prompt-image-generator/assets/photo_prompt_portrait_composition_extension.json` at `/slots/subject_framing/13`.

Caveat: this entry carries a portrait/frame owner relation; the exact source entry and affected dimensions are retained in the comparator file. No source-scope bypass or eligibility result is inferred.

### `pc_px07_component_3` (`subject_framing`)

Exact English label: “the intended crop is preserved independently of the perspective choice”

Source: `skills/photo-prompt-image-generator/assets/photo_prompt_portrait_composition_extension.json` at `/slots/subject_framing/16`.

Caveat: this entry carries a portrait/frame owner relation; the exact source entry and affected dimensions are retained in the comparator file. No source-scope bypass or eligibility result is inferred.

### `pc_px12_component_1` (`subject_framing`)

Exact English label: “the nominated facial and action regions remain inside the declared output crop”

Source: `skills/photo-prompt-image-generator/assets/photo_prompt_portrait_composition_extension.json` at `/slots/subject_framing/19`.

Caveat: this entry carries a portrait/frame owner relation; the exact source entry and affected dimensions are retained in the comparator file. No source-scope bypass or eligibility result is inferred.

### Other inspected alternatives that are not equivalent fixes

- `cropped_companion_visible_contact_relation` retains an entering owned limb, contact and compatible response. It is nearby for the mirror, but cannot authorize hiding the actual companion or losing the far-side relationship.
- `forward_torso_lean_close_crop` would introduce or rely on a specific lean/depth mechanism and does not replace upright mirror or rack staging.
- `load_bearing_contact_deformation` adds local receiver deformation; a rigid framed mirror or folded rail assembly must not acquire that deformation merely to satisfy an alternative.
- `tactile_contact_front_underside_composition` and `tactile_lifted_edge_contact_shadow_composition` require already authored manipulation/deformation/underside/lifted-edge context. These scenes do not grant that context. They demonstrate why a superficially similar contact-plus-boundary conjunction is not automatically safe.

## Is the conjunction a substantive corpus increment?

The proposal has a real packaging difference: one crop-owned unit explicitly binds the controlling load contour, corresponding opening boundary and carrying support in the same existing view, while forbidding geometry changes. The most generic contour and hand-contact entries do not individually say all of that. This makes it clearer wording for a narrow class of scenes, not by itself a new useful visual operation.

Across these six scenes the difference does not establish value beyond existing evidence-preserving crop work. The only compatible transfer baseline already states the narrow presented profile, both jamb gaps, both hand contacts, existing viewpoint and passage phase. The mirror baseline likewise already carries visible gaps and support, even though narrow-opening eligibility is unestablished. There is no authored missing visual fact for the conjunction to add without becoming redundant or violating a prerequisite. Generic anchor-safe crop retention plus suitable contour/contact preservation covers the functional retention task; scene-grounded authorial preservation can also simply keep the baseline. This is a semantic comparison, not proof that a particular multi-ID combination passes current runtime property filters.

All eligible additions are optional under the current composition contract, and selecting none is valid. It would be misleading to count candidate exposure, successful hash binding, or one explicit relation record as demonstrated artistic improvement.

## Disposition and stopping condition

Defer the exact frozen proposal; do not narrow gates, re-stage the mirror, fabricate rigid loads, transfer cart support to a person, or turn the stationary portrait/bench task into passage scenes. Do not rewrite the six inputs or the proposal to turn these results positive. A later promotion would need a genuinely authored compatible case where the new retained relationship adds useful, nonredundant direction under all existing locks, followed by separate pixel evidence if visual improvement is claimed. This review is complete at the semantic/source comparison boundary.
