import json,sys,copy
from pathlib import Path
P=Path(__file__).parent;R=P.parent.parent/'image-prompt';sys.path.insert(0,str(R/'skills/photo-prompt-image-generator/scripts'))
import prompt_generator as g
D=g.load_runtime_data();row=json.load(open(P.parent/'clearance-representation-review/frozen-representation.json'))['entry'];D['slots']['subject_framing'].append(row)
idx=g._core_slot_index(json.dumps(D['slots'],ensure_ascii=False,sort_keys=True,separators=(',',':')))
id='slot:subject_framing:'+row['id'];t=g.candidate_pack_relevance_tokens(g.candidate_pack_entry_blob(row,extra=row['concept_units']));out=[]
for p in sorted((P/'adapted-r4').glob('*/inputs.json')):
 x=json.load(open(p));c=x['normalized_core'];contract,picked=g.frozen_core_context(D,c,x['controls']);docs={f'slot:{s}:{r["id"]}':r for s,rows in D['slots'].items()for r in rows if g.core_slot_entry_eligible(D,c,contract,picked,s,r)}
 discovery=g.candidate_pack_assertion_discovery(D,c,docs,idx,include_visual_priorities=True)
 q,fields=g.core_slot_focus_text(D,c,'subject_framing');whole,_=g.authorial_core_retrieval_text(c);ids=[k for k in docs if k.startswith('slot:subject_framing:')];limit=max(12,g.candidate_pack_slot_limit('subject_framing')*6)
 broad=g.rank_bm25f(idx,{'global_context':whole},allowed_ids=ids,limit=limit);focal=g.rank_bm25f(idx,{'slot_focus':q},allowed_ids=ids,limit=limit)
 out.append({'case':p.parent.name,'policy':D['candidate_semantic_policy']['core_assertion_discovery'],'framing_open':'framing'in c['intent_lock']['open_dimensions'],'framing_locked':'framing'in c['intent_lock']['locked_dimensions'],'priority_shared_tokens':[{'text':v,'shared':sorted(t&g.candidate_pack_relevance_tokens(v))}for v in c['visual_priorities']],'discovered':id in discovery,'all_discovered_ids':discovery,'slot_focus':q,'slot_focus_fields':fields,'broad_rank':next((i+1 for i,h in enumerate(broad)if h['document_id']==id),None),'focal_rank':next((i+1 for i,h in enumerate(focal)if h['document_id']==id),None)})
(P/'discovery-trace.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print([(x['case'],x['discovered'],x['broad_rank'],x['focal_rank'])for x in out])
