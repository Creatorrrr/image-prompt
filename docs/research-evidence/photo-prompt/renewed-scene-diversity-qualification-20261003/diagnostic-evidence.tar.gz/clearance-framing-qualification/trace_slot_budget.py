import json,sys,inspect
from pathlib import Path
P=Path(__file__).parent;R=P.parent.parent/'image-prompt';sys.path.insert(0,str(R/'skills/photo-prompt-image-generator/scripts'))
import prompt_generator as g
D=g.load_runtime_data();row=json.load(open(P.parent/'clearance-representation-review/frozen-representation.json'))['entry'];D['slots']['subject_framing'].append(row)
lines,start=inspect.getsourcelines(g.retrieve_core_slots);target=start+next(i for i,l in enumerate(lines)if l.strip()=='candidates = []');out=[]
for p in sorted((P/'adapted-r4').glob('*/inputs.json')):
 x=json.load(open(p));capture=[]
 def trace(frame,event,arg):
  if frame.f_code is g.retrieve_core_slots.__code__:
   if event=='line' and frame.f_lineno==target and frame.f_locals.get('slot')=='subject_framing':
    z=frame.f_locals;capture.append({k:z[k]for k in ['slot','total','limit','ranked','observed']})
   return trace
  return None
 sys.settrace(trace)
 try:slots,binding,contract=g.retrieve_core_slots(D,x['normalized_core'],x['controls'])
 finally:sys.settrace(None)
 out.append({'case':p.parent.name,'actual_function_trace':capture,'emitted_subject_framing_ids':[r['entry_id']for r in slots.get('subject_framing',{}).get('candidates',[])]});print(p.parent.name,capture,flush=True)
(P/'slot-budget-trace.json').write_text(json.dumps(out,indent=2)+'\n')
