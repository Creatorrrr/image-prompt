import copy,hashlib,json,sys
from pathlib import Path
P=Path(__file__).parent;R=P.parent.parent/'image-prompt';I=P.parent/'scene-diversity-research/qualification-inputs/r3'
sys.path[:0]=[str(R),str(R/'skills/photo-prompt-image-generator/scripts')]
import prompt_generator as g
from tests import photo_prompt_fixtures as f
manifest=json.loads((I/'manifest-r3.json').read_text());out=[];fail=[]
for m in manifest['records']:
 p=I/m['file'];assert hashlib.sha256(p.read_bytes()).hexdigest()==m['sha256'];x=json.loads(p.read_text());c=copy.deepcopy(x['core_fields']);q=x['synthetic_request_text'];b=c['baseline_prompt_en']
 controls=g.creative_controls.resolve(q,overrides={'sensual':0,'fetish':0,'creativity':1,'surreal':0},context={'subject_category':'human'},seed=829)
 c['creative_controls_sha256']=controls['canonical_sha256'];c['intent_lock']['priority']='requesting_user'
 env=f.envelope(q);env['request_id']='synthetic-qualification-'+x['id']
 d=P/'adapted-r3'/x['id'];d.mkdir(parents=True,exist_ok=True)
 payload={'synthetic_audit_fixture':True,'not_actual_user_message':True,'wire_adapter_explanation':'The existing test envelope factory supplies production wire enum values solely to exercise contract functions on explicitly synthetic audit fixtures. This does not claim requester provenance or production use. Controls resolved deterministically after independent content freeze; no candidate data informs controls.','original_record_sha256':m['sha256'],'core':c,'controls':controls,'envelope':env,'review':x['embodiment_review']}
 (d/'inputs.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2)+'\n')
 try:
  norm=g.normalize_authorial_core(c,request_envelope=g.normalize_request_envelope(env),creative_control_snapshot=controls);g.photo_embodiment.build_policy(norm,x['embodiment_review']);assert norm['baseline_prompt_en']==b
  payload['normalized_core']=norm;(d/'inputs.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2)+'\n');out.append(x['id'])
 except Exception as e:fail.append({'case':x['id'],'type':type(e).__name__,'error':str(e)})
summary={'prepared':out,'failures':fail,'no_retrieval_performed':True};(P/'preflight-r3.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
