"""Offline source/retrieval diagnostic, not a public-core or image qualification.
Reads live runtime source and only Family A from the permitted development file.
Writes exclusively into this audit folder. No network or source modifications.
"""
from pathlib import Path
import hashlib,json,re,sys,subprocess
ROOT=Path('/workspace/scratch/ce8f20680f5a')
REPO=ROOT/'image-prompt'
OUT=Path(__file__).resolve().parent
SCRIPTS=REPO/'skills/photo-prompt-image-generator/scripts'
ASSETS=SCRIPTS.parent/'assets'
sys.path.insert(0,str(SCRIPTS))
import prompt_generator as g
source=ROOT/'daylong-progress-20261002/scene-diversity-research/development-families.md'
family=source.read_text().split('## Family A —',1)[1].split('## Family B —',1)[0]
scenes={key:text for key,text in re.findall(r'^- (A[123]): (.*?) Wrong:',family,re.M)}
data=g.load_json(ASSETS/'photo_prompt_tags.json')
data[g.QUALITY_LAYERS_DATA_KEY]=g.load_quality_layers(ASSETS/g.QUALITY_LAYERS_FILENAME)
selected={
 'composition':['crop_boundary_anchor_integrity','peak_action_event_phase','tactile_contact_front_underside_composition','pr_environmental_portrait_subject_place_candidate','des_overflow_causal_line_composition'],
 'focus':['subject_anchor_focus_plane_priority','pr_focus_plane_subject_falloff_candidate'],
 'action':['using_tool_at_visible_change_boundary','tool_contact_active_process_visible_result','tactile_gather_contact_action','pov_trace_mitigate_defect_action','character_creepy_cute_scene_action'],
 'contact_point':['load_bearing_contact_deformation','hand_gripping_tool_handle'],
 'relational_action':['working_same_target_from_two_sides','pr_observed_action_trace_candidate'],
 'prop':['pov_leak_damp_draft_mitigation_prop','character_creepy_cute_scene_prop'],
}
subjects={'A1':'a vendor','A2':'two workers','A3':'a caretaker'}
settings={'A1':'At a market stall after a shower','A2':'In a plant nursery loading bay','A3':"At an indoor pool's closed side entrance"}
rows=[]
for key,text in scenes.items():
 controls=g.creative_controls.resolve(text,overrides={'sensual':0,'fetish':0,'surreal':0},context={'subject_category':'human','no_people':False,'explicit_nonsexual':False},seed=0)
 # A maintenance-only carrier: no authored prompt or validated public core is claimed.
 core={'contract_version':'photo-authorial-core/v3','source_request':text,
       'subject':subjects[key],'setting':settings[key],'event':text,
       'interpreted_intent':'','baseline_prompt_en':text,'visual_priorities':[],
       'style':{'domain':'photography','family':'observational','evidence':[]},
       'user_exclusions':[],'semantic_assertions':[],
       'request_binding':{'active_spans':[{'text':text}]},
       'intent_lock':{'locked_dimensions':['action','setting','pose','material','relationship','subject','count'],
                      'open_dimensions':['composition','framing','camera','lighting','color'],
                      'canonical_sha256':'maintenance-diagnostic-only'},
       'creative_controls_sha256':controls['canonical_sha256'],
       'canonical_sha256':'maintenance-diagnostic-only'}
 contract,picked=g.frozen_core_context(data,core,controls)
 slots,binding,_=g.retrieve_core_slots(data,core,controls)
 result={'scene':key,'source_text':text,'diagnostic_core':core,
         'inferred_categories':contract['intent_constraints']['subject_categories'],
         'inferred_domains':contract['intent_constraints']['domains'],
         'retrieved':{slot:[r['entry_id'] for r in payload['candidates']] for slot,payload in slots.items() if slot in selected},'candidates':[]}
 for slot,ids in selected.items():
  for entry_id in ids:
   entry=g.candidate_pack_slot_entry_by_id(data,slot,entry_id)
   others={k:v for k,v in picked.items() if k!=slot}
   result['candidates'].append({'slot':slot,'id':entry_id,
       'eligible':g.core_slot_entry_eligible(data,core,contract,picked,slot,entry),
       'slot_block_reason':g.slot_block_reason(data,slot,contract),
       'entry_block_reason':g.entry_block_reason(entry,slot,contract),
       'slot_context_compatible':g.compatible_with_slot_context(slot,entry,others,data),
       'facet_compatible':g.compatible_with_facet_guards(entry,others),
       'retrieved':entry_id in result['retrieved'].get(slot,[]),
       'source_effect':g.photo_candidate_semantics.semantic_source(entry,slot,data.get('candidate_semantic_policy'))})
 rows.append(result)
paths=[ASSETS/'photo_prompt_tags.json',ASSETS/g.QUALITY_LAYERS_FILENAME,
       SCRIPTS/'prompt_generator.py',SCRIPTS/'photo_candidate_semantics.py',SCRIPTS/'photo_contracts.py']
paths += [ASSETS/name for name in g.RESEARCH_EXTENSION_FILENAMES if (ASSETS/name).exists()]
report={'audit_type':'offline development-only reachability diagnostic',
        'limitations':['No public authorial-core validation, candidate-pack generation, final-composition audit, paid call or rendering was performed.','Diagnostic projections reuse exact Family A development scenes and are not holdout qualification.','Eligibility and lexical selection do not prove adoption compatibility or pixel fidelity.'],
        'source_file':str(source),'development_file_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
        'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip(),
        'slot_count':len(data['slots']),'entry_count':sum(map(len,data['slots'].values())),
        'source_sha256':{str(p.relative_to(REPO)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths},
        'scenes':rows}
(OUT/'reachability-diagnostic.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
for r in rows:
 print(r['scene'], 'categories',r['inferred_categories'],'domains',r['inferred_domains'])
 print('RETRIEVED',json.dumps(r['retrieved']))
 print('ELIGIBILITY',json.dumps({v['id']:v['eligible'] for v in r['candidates']}))
print('Saved',OUT/'reachability-diagnostic.json')
