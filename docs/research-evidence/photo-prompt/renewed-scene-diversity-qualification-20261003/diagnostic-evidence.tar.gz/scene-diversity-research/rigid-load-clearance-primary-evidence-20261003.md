# Primary evidence: reorienting a carried item to clear an opening

Checked 2026-10-03 UTC. No repository, candidate proposal, or holdout-result data was read. This is an evidence addendum; the earlier independent scene tests remain unchanged.

## Recommended source

West Elm, official retailer document, “How to Measure for Delivery,” PDF page 2:
https://www.westelm.com/weimgs/rk/images/i/201928/0021/images/pdf/design-details/guides/how_to_measure.pdf

Successfully opened the original PDF, not a mirror. The publication date is not printed in the extracted relevant page; do not portray this as recent social evidence.

Relevant content, paraphrased: the guide distinguishes straight, angled and on-end entry. It compares the dimensions presented in the chosen orientation with doorway dimensions and calls for unobstructed space before and beyond the opening. For on-end entry it explicitly compares item width to doorway height and diagonal depth to doorway width. The document also describes furniture delivery being carried into the home on page 1.

Exact limited supported claim: A furniture item's orientation relative to an opening matters to passage; different orientations present different dimensions, and the item must clear the opening and the surrounding route.

Permissible modest scene generalization (inference, not a quoted manufacturer claim): A rigid carried item may be shown being reoriented relative to a doorway so that its edges clear the opening. This supplies a concrete distinction between “carrying an object near a doorway” and “adjusting the object's orientation while passing through it.”

Not established: that an arbitrary mirror, board or other candidate fits an unspecified opening; a full collision-free trajectory; quantified clearances; safe lifting, loading, grip, staffing, weight limits or handling instructions; superiority of a diagonal orientation in every case; or that any image model renders the relationship reliably. These must not be inferred as validations from this document.

## Corroborating primary source

DFS, official retailer page, “Your guide to measuring a sofa,” section “Will the sofa fit through my door?”:
https://www.dfs.co.uk/help/measuring-buying-guide

Successfully opened the original HTML. No publication date visible. The retailer describes its delivery teams rotating furniture onto its back to make doorway passage easier, as well as allowing room to pivot at bends. Only the existence of orientation-dependent passage is needed here; the surrounding delivery instructions are not adopted as prompt-data obligations.

## Separation from creative inspiration

The earlier X-attributed mirrors remain creative inspiration only. This official-source evidence supports one ordinary spatial relation, independently of those mirrors. It does not make the earlier independent scenes physically validated in their entirety.
