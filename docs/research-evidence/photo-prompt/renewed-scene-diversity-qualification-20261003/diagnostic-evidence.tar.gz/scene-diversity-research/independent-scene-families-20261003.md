# Independent scene-family research

Research time: 2026-10-03 UTC. Drafted without reading the repository or project candidate lists. These are proposed relational ingredients and test scenes, not additions already justified as novel or reachable.

## Evidence and limits

Public search found a few relevant X-attributed examples through mirrors. Direct opens of the original X URLs returned Internal Error; no usable original Threads post was retrieved. The mirrors establish that these examples are publicly indexed and attribute these URLs, not that their engagement, model performance, or popularity is independently verified. No popularity trend is claimed. Source date labels below agree with dates decoded from their X status identifiers; that consistency check is not independent proof that the originals remain accessible.

- S1: Alexey Fateev / @superalesha, “Rain cloud in the laundromat,” mirror dated 2026-09-20. Original attributed URL: https://x.com/superalesha/status/2101736041019260992 ; indexed mirror: https://www.wikiprompt.org/rain-cloud-in-the-laundromat . Reusable observation: an ordinary utilitarian interior becomes legible through one local disturbance, nearby objects, and a person's reaction. The source's impossible cloud is deliberately NOT retained in the proposals. The original status ID encodes 2026-09-20T18:11:35Z.
- S2: @underwoodxie96, bus-stop smartphone street photo, mirror dated 2026-07-01. Original attributed URL: https://x.com/underwoodxie96/status/2072225990605230294 ; successfully opened mirror: https://www.meigen.ai/prompt/2072225990605230294 . Reusable observation: street furniture and imperfect framing locate the person within functioning public space. The posed subject/outfit is not retained. Original ID encodes 2026-07-01T07:49:10Z. Older supporting example, not recent September evidence.
- S3: Ali / @aiwithaly, “Photorealistic Urban Chase Thriller Video Prompt,” mirror created 2026-09-17 and updated 2026-09-20. Original attributed URL: https://x.com/aiwithaly/status/2100462425308901480 ; indexed mirror: https://www.wikiprompt.org/photorealistic-urban-chase-thriller-video-prompt . Reusable observation: people, carried objects, obstacles, occlusion and balance jointly describe action. This is VIDEO evidence used only to inspire single-frame relationships; chase/thriller content and temporal camera instructions are not retained. Original ID encodes 2026-09-17T05:50:41Z.
- S4: @dongfei111, “Cyberpunk Rainy Street Robot Repair.” Original attributed URL: https://x.com/dongfei111/status/2048562221731680281 ; indexed mirror: https://freesoragenerator.com/tw/prompts/862-cyberpunk-rainy-street-robot-repair . Reusable observation: contact between hand, tool, opened device and constrained loose parts communicates active repair. Robot, neon-cyberpunk world and face blur are not retained. No mirror publication date was visible; ID encodes 2026-04-27T00:37:48Z, so use only as older supporting provenance.

All following scenes are independently drafted extrapolations. They are not source paraphrases or claims about what a model reliably generates.

## Family A — Improvised containment during routine work

Rationale: S1 suggests making an everyday place distinctive through a localized disturbance and practical response. Replace surreal weather with physically visible containment: a sheet, tray, cloth or temporary barrier bends under a load or stops material crossing a boundary. Boldness comes from the geometry of the response and inconvenient placement, not disaster spectacle.

Decomposable elements:
1. Adult actor applying tension, pressure or a supporting grip
2. Flexible or shallow containment prop with a visible deformation
3. Material whose location and movement can be inspected: water, dust, loose leaves, granular spill
4. Work boundary: loading-bay threshold, market aisle, washroom corner, sheltered walkway
5. Evidence of ongoing mundane work: stacked crates, parked cart, folded cloths, displaced bucket

Independent positive scenes and nearby wrong interpretations:
- A1: At a market stall after a shower, a vendor raises one sagging corner of a tarp with a broom handle; a narrow stream pours from the lowest edge into a bucket while the other corners remain tied above the crates. Wrong: the broom sweeps the ground; rain falls everywhere from the sky; the tarp becomes an umbrella; the bucket sits away from the stream.
- A2: In a plant nursery loading bay, one worker holds a wide dustpan against the floor while another tilts a split sack so loose potting mix enters the pan, with the undamaged sacks still on a trolley. Wrong: both workers simply carry intact sacks; soil pours into a plant pot; the dustpan floats without contacting the floor.
- A3: At an indoor pool's closed side entrance, a caretaker wedges a rolled towel against the bottom of the door while a shallow wet patch stops on the near side and a mop leans against the wall. Wrong: drying a person; wiping the upper glass; a flooded room; towel hung neatly on a rail.

Holdout combination: an adult at a ferry terminal securing the lifted corner of a floor-protection sheet with a weighted crate, keeping windblown grit on one side. This tests transfer beyond water or laundromats.

## Family B — Awkward cargo negotiation in public circulation

Rationale: S2 provides observable transit infrastructure; S3 contributes carried-object physics and obstacle-relative action. Substitute useful awkward objects for generic walking/posing. The composition should show why an actor rotates, braces or pauses, not merely that a large prop exists.

Decomposable elements:
1. Rigid bulky carried object with a salient long axis or wide face
2. Narrow gate, turnstile, door opening, platform barrier or stair landing
3. Rotation, bracing, passing or temporary support at a visible contact point
4. Adult helper or nearby traveller whose position clarifies available space
5. Public-space identifiers that remain background rather than title-like text

Independent positive scenes and nearby wrong interpretations:
- B1: At a station's wide luggage gate, an adult tilts a tall framed mirror diagonally through the opening while a companion steadies its bottom corner from the far side; the adjacent narrow turnstiles remain empty. Wrong: admiring a mirror; mirror mounted on a wall; both helpers stand on the same side with no passage; reflection substitutes for the second person.
- B2: On a ferry boarding ramp, a florist turns a handcart sideways at a bend, using one forearm to keep tall wrapped branches from scraping the handrail; the cart's front wheels are visibly angled. Wrong: carrying a bouquet for a portrait; straight effortless pushing; branches growing from the ramp; balancing the cart on a single impossible wheel.
- B3: At a bus shelter in daylight, a traveller rests one end of a rolled rug on the bench while tightening a strap around its middle, with the free end projecting past the seat and a bag held between their shoes. Wrong: sitting on the rug; laying carpet across the shelter floor; carrying a yoga mat normally; tightening the strap around the bench.

Holdout combination: a caretaker rotating a folded drying rack edge-on through a narrow municipal doorway. Same bottleneck relationship without transit travel, mirrors or glamorous styling.

## Family C — Repair-in-progress with constrained loose parts

Rationale: S4's useful part is the visible hand-tool-device relationship, not its elaborate world. Introduce a small component that needs both retrieval and stabilization, or a partially opened object with one component still attached. This is potentially more discriminative than a generic “person repairing” label.

Decomposable elements:
1. Ordinary object in an intermediate disassembled state
2. Tool tip or hand contacting a particular fastener, axle, hinge or component
3. Stabilizer: foot, clamp, second hand, block, or helper
4. Bounded parts holder or retrieval aid: shallow tray, magnet, folded cloth
5. Contextual surface: public repair bench, cart underside, service counter, maintenance alcove

Independent positive scenes and nearby wrong interpretations:
- C1: In a library service alcove, a caretaker lays a book trolley on its side, holds the loose caster against its mounting plate with one hand, and tightens a bolt with a short wrench; removed washers lie in a shallow lid beside the trolley. Wrong: changing a car tire; trolley upright and untouched; wrench held decoratively; washers scattered without a parts holder.
- C2: At a street bicycle repair stand, an adult braces a removed wheel between their knees and uses tweezers to pull a small thorn from the tire tread, while the bicycle remains clamped without its front wheel. Wrong: inflating an attached wheel; plucking a spoke; wheel levitating; tire tread and hands hidden behind a posed portrait.
- C3: At a community hall bench, a technician holds an open folding-chair hinge steady while a magnetic pickup tool lifts a fallen screw from a narrow crack between floorboards; a replacement hinge plate rests on a folded cloth. Wrong: assembling an unrelated table; sweeping all the floor; screw already seated in the hinge; pickup tool rendered as a screwdriver used on the chair.

Holdout combination: an adult holding a luggage wheel assembly against an upside-down suitcase while sorting axle spacers in a small dish. Same contact/constraint family without repair-shop styling.

## Suggested downstream audit

Audit these relationships against existing candidate DATA and actual eligible sampler lanes before proposing additions. Do not add a full scene, fixed wardrobe, named location, camera package or source prompt as one preset. Existing action/prop/place combinations may already express any of these concepts. Keep the independent positives and near misses frozen for semantic checks, but do not mistake vocabulary matching for scene success. A candidate must visibly preserve actor action, object constraint and place affordance together. If only a new noun is added while the operative relationship remains generic posing, the intended diversity gain has not been established.
