"""Separately authorized setting-only adapter repairs and two fresh layer controls."""
import copy, json, traceback
import evaluate as e
from evaluate import pg, sha, dump
ROOT_OUT=e.OUT
e.OUT=ROOT_OUT/'supplemental'
e.OUT.mkdir(exist_ok=True)
LAYER=e.BASE/'fresh-authored-controls/layered-controls.json'
EXPECTED='7030d43483e5b8a15e21e9e18f52180762198f13b44a2849b9dbbdef3fe656aa'
assert sha(LAYER.read_bytes())==EXPECTED
(e.OUT/'layered-controls.frozen.json').write_bytes(LAYER.read_bytes())

e.PLAN.update({
 'layered_fresh_01':('An adult woman','inside a ferry terminal','waiting inside a ferry terminal',
     ['ferry terminal','An adult woman','woman waits inside'],
     ['a layered dress','lining is visible through the outer cloth','lining itself conceals what lies beneath it']),
 'layered_fresh_02':('An adult guest','for a poetry reading at a neighborhood cafe','arriving for a poetry reading',
     ['at a neighborhood cafe','An adult guest','guest arrives for a poetry reading'],
     ['covers the chest, torso, hips, and upper legs','conceals skin and underwear through those covered areas']),
})
e.REVIEW_REASONS.update({
 'layered_fresh_01':'The waiting woman has loosely joined hands and watches the water; the dress layers share one wearer and the terminal provides ordinary standing space.',
 'layered_fresh_02':'One guest arrives, pauses near books and turns toward the reading area; the outer skirt and opaque inner layer have the same wearer with no inconsistent contact.'})
rows=json.loads(LAYER.read_text())['requests']
cases=e.materialize(rows)
for c in cases:c['population']='fresh_layered_extension_first_pass'
repairs={'fresh_03':'leafy benches in a greenhouse',
         'fresh_05':'a timetable on a railway platform',
         'fresh_07':'flowers at the shop counter'}
repair_receipts=[]
for rid,setting in repairs.items():
    raw=json.loads((ROOT_OUT/rid/'input-raw-core.json').read_text())
    before=copy.deepcopy(raw);assert setting in raw['baseline_prompt_en'];raw['setting']=setting
    assert {k for k in raw if raw[k]!=before[k]}=={'setting'}
    envelope=json.loads((ROOT_OUT/rid/'input-envelope.json').read_text())
    controls=json.loads((ROOT_OUT/rid/'input-controls.json').read_text())
    review=json.loads((ROOT_OUT/rid/'input-embodiment.json').read_text())
    repaired_id=rid+'_adapter_repair'
    receipt={'id':repaired_id,'original_request_id':rid,'population':'fresh_setting_only_adapter_repair',
       'first_pass_failure_preserved':str((ROOT_OUT/rid/'materialization-failure.json').relative_to(ROOT_OUT)),
       'authorized_change':'Only expand setting using a longer exact frozen-baseline span; no other field, property path, lock, request, or prompt changed.',
       'setting_before':before['setting'],'setting_after':setting,'setting_is_verbatim_baseline_span':True}
    dump(repaired_id+'/input-raw-core.json',raw);dump(repaired_id+'/input-envelope.json',envelope)
    dump(repaired_id+'/input-controls.json',controls);dump(repaired_id+'/input-embodiment.json',review)
    try:
        core=pg.normalize_authorial_core(raw,request_envelope=pg.normalize_request_envelope(envelope),creative_control_snapshot=controls)
        assert core['baseline_prompt_en']==before['baseline_prompt_en'] and core['source_request']==before['source_request']
        pg.photo_embodiment.build_policy(core,review)
        dump(repaired_id+'/normalized-core.json',core)
        cases.append({'id':repaired_id,'population':'fresh_setting_only_adapter_repair','core':core,'controls':controls,'review':review})
        receipt['normalization']='passed'
    except Exception as exc:
        receipt.update(normalization='failed',error=str(exc),traceback=traceback.format_exc(),retry='none; only the authorized setting change was attempted')
    dump(repaired_id+'/adapter-repair-receipt.json',receipt);repair_receipts.append(receipt)
dump('repair-summary.json',repair_receipts)
dump('supplement-input-freeze.json',{'layered_artifact_sha256':EXPECTED,'files':{str(p.relative_to(e.OUT)):sha(p.read_bytes()) for p in sorted(e.OUT.glob('*/input-*.json'))}})
print('Supplement materialized',len(cases),'cases; loading runtime DATA',flush=True)
data=pg.load_runtime_data();after=e.proposal(data)
results=[];failures=[]
for case in cases:
    for label,source in [('before',data),('after_opacity_only',after)]:
        try:results.append(e.evaluate_case(case,label,source))
        except Exception as exc:
            failure={'id':case['id'],'population':case['population'],'state':label,'error':str(exc),'traceback':traceback.format_exc(),'retry':'none'}
            dump(case['id']+'/'+label+'-runtime-failure.json',failure);failures.append(failure)
            print('FAIL',case['id'],label,str(exc),flush=True)
dump('results.json',{'layered_artifact_sha256':EXPECTED,'results':results,'runtime_failures':failures})
assert sha(LAYER.read_bytes())==EXPECTED
print('Finished supplement:',len(results),'builds;',len(failures),'preserved runtime failures',flush=True)
