# CT091-only public-path qualification

## Decision

**Read-only qualification supports the canonical CT091 opacity fix, with important coverage limits. Production publication remains paused by the parent; this report does not authorize or perform an edit. CT098 color is DEFER.**

- **Two source-guided canonical cores:** the real public build leaves CT091 in the ordinary inventory but changes its published applicability from `eligible / frozen_core_slot_contract` to `ineligible / authored_property_scope`. Selecting the actual public candidate triggers `candidate_applicability` and trusted-source property-preservation failures after the proposed metadata addition
- **Ten independently authored fresh requests:** seven normalize on first materialization. One more normalizes after the separately authorized setting-only adapter correction, and one after the final separately authorized event correction. **Nine distinct fresh requests reach the public build; one remains unadmitted.** Request/baseline bytes are never rewritten
- **Nine admitted fresh requests:** neither CT091 variant is naturally retrieved or publicly exposed, before or after. Their ordinary inventories and optional-profile lists are unchanged. This is **zero observed natural exposure and zero measured benefit**, not nine successful blocker tests
- Fresh opacity paths are valid but differ from the proposed path. The added `wardrobe.surface.sheer_opacity` effect does **not** overlap `wardrobe.main_garment.opacity`, `wardrobe.apron.opacity`, or the layer-specific paths. No aliases were retrofitted
- Exact-baseline, zero-adoption full composition audits pass after a separately recorded archive-order recovery. The original order-induced failures remain preserved; see below

The canonical development denominator and fresh-author denominator are kept separate throughout. No category-wide completeness, blind population sampling, rendered quality, provider-backed semantic retrieval, or general opacity coverage is claimed.

## Frozen source inputs

Repository source remains pinned to `7e769e3e4a0da7068723830bb0c5c5c2dfd784c8`.

1. `../fresh-authored-controls/requests.json`: eight requests, SHA-256 `7a8c7efcfce638c54faf865715b73eced57eea2cc955bba448fcb97b6d00618b`
2. `../fresh-authored-controls/layered-controls.json`: two additional requests, separately frozen, SHA-256 `7030d43483e5b8a15e21e9e18f52180762198f13b44a2849b9dbbdef3fe656aa`

Exact copies are retained as `requests.frozen.json` and `supplemental/layered-controls.frozen.json`. The independent author was source-unexposed; the mechanical evaluator was source-exposed. These are theme-targeted synthetic requests, not a blind sample of production traffic.

Each per-request directory retains its original raw core, envelope, controls, embodiment review, ownership-translation ledger, and either a normalized core or the first failure. The baseline and requesting-user text are asserted byte-equal to the independently frozen hashes. The original author’s property paths, targets, source text, and meanings are preserved.

## Proposal scope and runtime route

The exact in-memory proposal is `opacity-only-proposal.json`:

- `clt_ct091_v1` and `clt_ct091_v2`: append `appearance / main_subject / wardrobe.surface.sheer_opacity`
- Matching `clothing_ct091_v1` and `clothing_ct091_v2`: append the same property to `concept_candidate.affected_properties`
- Preserve existing family effects, dimensions, labels, aliases, component meanings, gates and ownership
- CT098 is unchanged

Each arm calls production functions:

1. `load_runtime_data` validates the existing authored corpus and generated indexes
2. `normalize_request_envelope` and `normalize_authorial_core` materialize evaluation inputs
3. `retrieve_core_slots` records the raw ordinary inventory separately
4. `generate_candidate_pack` calls `prepare_candidate_source`, the full `build_candidate_pack`, and the normal public projection
5. `build_candidate_pack` at `prompt_generator.py:10392–10412` assigns the source-recomputed `authored_property_scope` ineligibility before public projection
6. When a target is naturally present, `audit_composed_prompt` executes its actual `candidate_applicability` branch; `audit_candidate_semantic_contracts` separately exercises trusted-source property validation

The in-memory after source reuses existing vectors **only after proving unchanged semantic text and BM25F projections**. Dictionary/registry hash bindings are updated in memory, and production metadata validators pass. There is no provider call or disk index change. See `in-memory-index-rebinding.json` for bindings and limits. The same process is repeated for the supplement/final-adapter processes, without copying indexes into this evidence directory.

Full public packs are preserved as small gzip archives; their summaries retain all ordinary IDs, applicability, effects, target observations and retrieval-audit outcomes. Raw retrieved rows are never equated with published eligibility.

## Materialization denominators and preserved failures

| Cohort | Attempted | Normalized | Outcome |
| --- | ---: | ---: | --- |
| Initial independent eight, first pass | 8 | 5 | fresh_03, fresh_05, fresh_07 setting summaries failed the three-content-word minimum |
| Additional layered requests, first pass | 2 | 2 | Both admitted unchanged |
| Authorized setting-only adapter arm | 3 | 1 | fresh_07 admitted; fresh_03 then failed a priority minimum; fresh_05 then failed an event minimum |
| Authorized final adapter arm | 1 | 1 | fresh_05 admitted after the event-only correction |
| Distinct independent requests reaching runtime | 10 available | 9 | fresh_03 remains unadmitted |
| Separate canonical development cores | 2 | 2 | Already source-guided; never counted as fresh-author successes |

The first setting-only repairs use exact existing baseline spans:
- fresh_03: `leafy benches in a greenhouse`
- fresh_05: `a timetable on a railway platform`
- fresh_07: `flowers at the shop counter`

Only `setting` changed in those raw input variants. The final fresh_05 repair changes only `event` from `reading a timetable` to the complete verbatim clause `studies a timetable on a railway platform`; all property locks and prompt/request bytes remain identical.

fresh_03 is **not counted as tested at runtime**. Its `in a greenhouse` concept/priority excerpt has one content word. The final authorization disallowed a dangling excerpt merely to satisfy a word count, and the evaluator did not freeze an incidental author-selected color, bench, pose, or lighting choice as a requester lock. Both failed attempts are preserved. Its frozen author output is not itself classified as wrong; these are translator/schema admission failures.

`ownership-translation.json` records where short literal evidence was chosen before retrieval to avoid locking an incidental color. For example, the underlayer type uses `sleeveless top` rather than freezing the author's charcoal choice. Literal evidence is not a complete semantic proof: the unchanged requester text/source ledger retains qualifiers such as plainness. Creative defaults remain author-owned; the evaluator resolves the saved controls without overrides, including sensual 1, fetish 0, creativity 1 and surreal 0.

The generic supplement helper initially emitted an empty `input-freeze.json` with the inherited original-cohort label. Its exact bytes are preserved as `supplemental/inherited-helper-input-freeze.invalid.json`; the corrected manifest and `supplement-input-freeze.json` bind the separately frozen layered input and all supplemental inputs. This helper-label error did not alter runtime cores or effects.

## Canonical public applicability result: 2/2

The two original source-guided cores are replayed without request, baseline, lock, or control changes. Each is an explicit fashion-product scene with a canonical `wardrobe.surface.sheer_opacity` lock.

| Source-guided request | Raw ordinary row | Public before | Public after | Actual selected audit after |
| --- | --- | --- | --- | --- |
| CT091 v1 / opaque crisp cloth | Present in both arms | eligible | ineligible, authored_property_scope | candidate_applicability plus source-property failure |
| CT091 v2 / opaque fluid cloth | Present in both arms | eligible | ineligible, authored_property_scope | candidate_applicability plus source-property failure |

The selected audit probe deliberately keeps the baseline unchanged and supplies only a partial selection record. It therefore has other composition/evidence failures in both arms; no overall selected-composition pass is claimed. The interpreted differential is specifically the actual applicability and source-property checks, with every full audit result retained.

Matching CT091 optional profiles remain absent naturally. This continuation makes **no natural public-profile red/green claim**.

## Independent request outcomes: 9 admitted, 0 natural CT091 exposures

| Request | Meaning/control | Admission arm | CT091 before/after |
| --- | --- | --- | --- |
| fresh_01 | Main shirt fabric must stay fully opaque | first pass | absent / absent |
| fresh_02 | Main coat body and sleeves opaque | first pass | absent / absent |
| fresh_03 | Sheer overshirt with visible top | unadmitted | not run |
| fresh_04 | Uniform intrinsic brick-red dress color | first pass | absent / absent |
| fresh_05 | Blue hue fixed, lightness variation welcome | final adapter | absent / absent |
| fresh_06 | Background-wall color fixed; clothes open | first pass | absent / absent |
| fresh_07 | Coworker's apron opaque; primary outfit open | setting-only adapter | absent / absent |
| fresh_08 | Whole outfit open | first pass | absent / absent |
| layered_fresh_01 | Sheer outer cloth over opaque lining | first pass | absent / absent |
| layered_fresh_02 | Completed-outfit coverage/concealment; outer transmission open | first pass | absent / absent |

All nine admitted fresh cases have identical before/after ordinary inventory rows and optional-profile lists after normalizing only list order by candidate ID. They include no naturally exposed CT091 ordinary, augmentation, or optional-profile choice. Actual CT091 selection-audit checks are therefore **not exercised** for these fresh cases; no target was injected to manufacture coverage.

`reachability-gate-diagnostics.json` establishes the ordinary-route reason: all nine have a human primary subject without an allowed override domain, so the existing `surface_material` slot guard returns `subject_category_not_allowed`. The separately source-guided canonical product cases legitimately have an override domain. No product label was added to the fresh inputs to bypass this guard.

The direct source-effect predicate stays `true` for both CT091 variants under all nine fresh lock sets, because the valid independent paths are disjoint from the newly declared path. This is a **property-vocabulary coverage limit**, not proof that the opaque request would safely block a CT091 choice if some future retrieval exposed one. In particular, the source addition does not protect arbitrary natural-language equivalents of opacity. No broad wardrobe/appearance lock or post-hoc alias mapping was added to conceal that limit.

The layered cases preserve their distinctions:
- `wardrobe.main_garment.outer_layer.transmission` and `wardrobe.main_garment.lining.opacity` bind different predicates on different layers
- `wardrobe.completed_outfit.body_coverage` and `wardrobe.completed_outfit.visual_concealment` specify the completed result, leaving outer-layer transmission open
- No test assumes sheer outer cloth must reveal skin or that an opaque lining makes the outer cloth opaque

## Exact-baseline / zero-adoption full audits

**22/22 full retention audits pass after the serialization-order recovery:** 18 fresh-control runs (nine admitted requests × two arms), plus four canonical-development runs (two cores × two arms). Before that explicit recovery, all 22 archived-payload attempts fail the same order-sensitive control-binding checks; neither arm receives a hidden exemption.

The retention composition selects no candidates, rejects optional augmentations, applies required clarification, preserves all source anchor IDs, retains the exact baseline, and binds an unchanged prose-only embodiment review. Saved adult-axis strengths are retained rather than increased or rewritten. Optional contextual relevance is marked uncertain and unadopted; this is a retention control, not a new aesthetic assessment.

The first archive-based full audits failed in both arms because `packed()` wrote JSON with `sort_keys=True`. That reorders the embedded creative-control definitions; `creative_controls.validate` rebuilds the authoring brief by iterating those keys. Its stored brief retains the original order, so a semantically equal reordered snapshot is rejected as stale. These original failures remain in `*-baseline-no-adoption.json` and `baseline-no-adoption-summary.json`.

The separately labeled recovery reuses the **exact original input control snapshot order**, asserts deep value equality with the archived snapshot, and asserts unchanged canonical pack identity before auditing. It changes no source record, request, baseline, core, property lock, control value or declared strength. The recovery outputs are `*-baseline-no-adoption-serialization-recovery.json` and the corresponding summary.

This isolates an archive/validator ordering sensitivity from the CT091 DATA proposal. The successful retention audits establish contract compatibility only. They do not demonstrate that the independently authored baseline has a calibrated visual intensity or satisfies pixel-level opacity.

## Reproduction and artifact guide

Run from the pinned repository; all outputs remain outside it:

```text
PYTHONDONTWRITEBYTECODE=1 .venv/bin/python ../data-progress-48h-20261003/material-effect-audit/fresh-control-evaluation/evaluate.py
PYTHONDONTWRITEBYTECODE=1 .venv/bin/python ../data-progress-48h-20261003/material-effect-audit/fresh-control-evaluation/evaluate_supplement.py
PYTHONDONTWRITEBYTECODE=1 .venv/bin/python ../data-progress-48h-20261003/material-effect-audit/fresh-control-evaluation/evaluate_final_adapter.py
PYTHONDONTWRITEBYTECODE=1 .venv/bin/python ../data-progress-48h-20261003/material-effect-audit/fresh-control-evaluation/baseline_no_adoption.py
PYTHONDONTWRITEBYTECODE=1 .venv/bin/python ../data-progress-48h-20261003/material-effect-audit/fresh-control-evaluation/baseline_no_adoption_serialization_recovery.py
```

- `results.json`, `supplemental/results.json`, `final-adapter/results.json`: complete public-route summaries and preserved runtime failures
- `materialization-summary.json`, supplement repair receipts, final adapter receipt: first-pass versus repaired admission
- `*-public-pack.json.gz`: exact archived public objects, subject to the explicitly documented control-dictionary ordering sensitivity
- `*-selected-audit.json`: full partial-selection probe results and focused semantic checks for naturally present canonical rows
- `baseline-no-adoption-serialization-recovery-summary.json`: final full retention-audit results
- `qualification-summary.json`: machine-readable aggregate and denominator assertions
- `evidence-manifest.json`: final file hashes, source/input verification and command log references

No provider calls, repository edits, Git writes, generated index copies, source alias rewrites, or full regression runs were performed. The separate full-suite byte-drift issue and publication pause remain owned by the parent.
