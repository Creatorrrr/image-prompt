"""Eight frozen controls: provider-free real public builds, no repository writes."""
import copy, gzip, hashlib, json, pathlib, subprocess, sys, traceback
from unittest import mock
sys.dont_write_bytecode=True
OUT=pathlib.Path(__file__).resolve().parent
BASE=OUT.parent
ROOT=pathlib.Path('/workspace/scratch/ce8f20680f5a/image-prompt')
ASSETS=ROOT/'skills/photo-prompt-image-generator/assets'
sys.path[:0]=[str(ROOT),str(ASSETS.parent/'scripts')]
import prompt_generator as pg
import photo_candidate_semantics as sem
import photo_contracts as contracts
import audit_composed_prompt as audit
from tests import photo_prompt_fixtures as fixtures

FROZEN=BASE/'fresh-authored-controls/requests.json'
EXPECTED='7a8c7efcfce638c54faf865715b73eced57eea2cc955bba448fcb97b6d00618b'
TARGETS=['clt_ct091_v1','clt_ct091_v2']
def sha(b):return hashlib.sha256(b).hexdigest()
def dump(path,value):
    p=OUT/path;p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
def packed(path,value):
    p=OUT/path;p.parent.mkdir(parents=True,exist_ok=True)
    p.write_bytes(gzip.compress(json.dumps(value,ensure_ascii=False,sort_keys=True).encode(),mtime=0))

# Written once from the independent requests/baselines, before any new runtime
# result. Property paths remain byte-identical to the independent ledger.
# Each tuple supplies subject, setting, event, concept/subject/event literal
# evidence, and narrow property evidence excluding incidental author colors.
PLAN={
 'fresh_01':('An adult bicycle mechanic','outside the repair shop','taking a break outside the repair shop',
             ['repair shop','An adult bicycle mechanic','mechanic pauses'],
             ['shirt is made','fully opaque cloth, including the sleeves and torso']),
 'fresh_02':('An adult commuter','a street bus stop','waiting at a bus stop',
             ['beside a bus-stop','An adult commuter','commuter waits'],
             ['coat has','completely opaque body and sleeves']),
 'fresh_03':('An adult visitor','a greenhouse','the underlying plain sleeveless top is visible through the sheer overshirt',
             ['in a greenhouse','An adult visitor','top is clearly visible through the overshirt itself'],
             ['the overshirt itself','top is clearly visible through the overshirt itself','sleeveless top']),
 'fresh_04':('An adult woman','a small art gallery','arriving at a small art gallery',
             ['small art gallery','An adult woman','woman arrives'],
             ['Her dress','one even brick-red base color throughout']),
 'fresh_05':('An adult man','a railway platform','reading a timetable',
             ['railway platform','An adult man','man studies a timetable'],
             ['a blue sweater','a blue sweater']),
 'fresh_06':('An adult woman','against a wall painted a single pale peach color','being portrayed against the specified wall',
             ['a wall painted one pale peach color','An adult woman','against a wall painted one pale peach color'],
             ['a wall painted one pale peach color']),
 'fresh_07':('An adult florist and an adult coworker','at the shop counter','the adult coworker stands behind the florist',
             ['at the shop counter','An adult florist','stands behind'],
             ['apron whose fabric','fabric conceals the clothing directly beneath it']),
 'fresh_08':('An adult traveler','beside a train-station window','taking a relaxed short break',
             ['beside a train-station window','An adult traveler','traveler takes a short break'],[]),
}
REVIEW_REASONS={
 'fresh_01':'One mechanic rests one owned hand on a bicycle saddle; the bicycle is adjacent, with no contradictory contact or load specified.',
 'fresh_02':'A waiting commuter makes a slight weight shift beside a pole; no incompatible limb or support requirement is stated.',
 'fresh_03':'One visitor pauses among benches and glances along the plants; the layered clothes and torso framing do not require conflicting limb positions.',
 'fresh_04':'One woman pauses with one foot inside a doorway; the threshold and across-doorway view form a plausible paused step.',
 'fresh_05':'A man angles his head toward a posted timetable; the side view and supported platform stance impose no conflicting reach.',
 'fresh_06':'A woman stands with hands loosely at her sides; the direct gaze and three-quarter crop preserve a plausible uncomplicated stance.',
 'fresh_07':'The florist handles a small flower bunch at the counter; a distinct coworker stands behind and offset, with each garment clearly assigned.',
 'fresh_08':'A traveler leans lightly against the wall by a window and looks toward the tracks; the nearby wall supports the stated lean.',
}

def materialize(rows):
    usable=[];failures=[]
    for row in rows:
        rid=row['request_id'];request=row['request_text'];prompt=row['initial_prompt_en']
        assert sha(request.encode())==row['request_sha256']
        assert sha(prompt.encode())==row['initial_prompt_sha256']
        subject,setting,event,evidence,prop_evidence=PLAN[rid]
        envelope=fixtures.envelope(request);envelope['request_id']=rid
        controls=pg.creative_controls.resolve(request,context={'subject_category':'human','no_people':False,'explicit_nonsexual':False},seed=7)
        anchors=[{'anchor_id':'required_'+dim,'source_text':request,'dimension':dim,'prompt_evidence':proof}
                 for dim,proof in zip(['concept','subject','event'],evidence)]
        ledger=[]
        for i,(prop,proof) in enumerate(zip(row['requester_owned_property_ledger'],prop_evidence)):
            anchors.append({'anchor_id':'property_'+str(i+1),'source_text':prop['source_text'],
                'dimension':prop['dimension'],'target':prop['target'],'property':prop['property'],'prompt_evidence':proof})
            ledger.append({'original':prop,'core_prompt_evidence':proof,
                'evidence_adjustment':'Narrow literal excerpt chosen before retrieval to avoid freezing incidental author-selected color or styling; source text, owner, dimension and property path remain unchanged.' if proof!=prop['prompt_evidence'] else 'Copied unchanged.',
                'limitation':'Literal evidence is not a complete semantic proof; the unchanged source request and source-text ledger retain every qualifier, including plainness of the underlayer.'})
        if rid=='fresh_07':
            anchors.append({'anchor_id':'secondary_subject','source_text':'an adult coworker standing behind them','dimension':'subject','prompt_evidence':'An adult coworker'})
        raw={'contract_version':'photo-authorial-core/v3','provenance':'agent_prepack','source_request':request,
            'interpreted_intent':request,'subject':subject,'setting':setting,'event':event,
            'visual_priorities':[evidence[0],evidence[2]],'baseline_prompt_en':prompt,
            'user_definitions':[],'interpretation_provenance':[{'term':'governing request','source_text':request,'basis':'request_context','resolution':request,'sources':[]}],
            'unresolved_ambiguities':[],'user_exclusions':[],'runtime_forbidden_labels':[],
            'intent_lock':{'contract_version':'photo-intent-lock/v2','priority':'requesting_user','semantic_anchors':anchors,
                'locked_dimensions':['concept','subject','event'],
                'open_dimensions':['appearance','material','color','pose','expression','action','setting','timing','lighting','camera','framing','composition','atmosphere','style']},
            'semantic_assertions':[],'request_lineage':None,
            'style':{'domain':'general_photo','family':'photographic study','evidence':[evidence[0],evidence[2]]},
            'variation_key':rid,'creative_controls_sha256':controls['canonical_sha256']}
        # Real prose-only review, limited to absence of contradictions in these
        # uncomplicated unchanged synthetic scenes, not a synthetic pixel pass.
        ev=prompt.split('. ')[0].rstrip('.')
        review={'contract_version':'photo-embodiment-review/v1','provenance':'agent_prepack','prompt_sha256':sha(prompt.encode()),
            'scope':'body_action','summary':'Prose-only agent review of the unchanged synthetic baseline; this is neither kinematic nor rendered-pixel proof.',
            'checks':{check:{'status':'supported','reason':REVIEW_REASONS[rid], 'prompt_evidence':[ev]} for check in pg.photo_embodiment.CHECKS}}
        dump(rid+'/input-raw-core.json',raw);dump(rid+'/input-envelope.json',envelope)
        dump(rid+'/input-controls.json',controls);dump(rid+'/input-embodiment.json',review)
        dump(rid+'/ownership-translation.json',{'basis':'Source-unexposed authored requests, source-exposed mechanical evaluator; this materialization is not itself a blind authoring task.',
            'request_and_baseline_unchanged':True,'property_paths_preserved':True,'property_ledger':ledger,
            'author_choices_are_not_new_locks':row['freely_chosen_realization'],
            'scope_note':'Scoped negative color/visibility statements remain in the requester text and positive property ledger, not converted into broad runtime exclusions.',
            'defaults':'Saved controls resolved without overrides; sensual=1, fetish=0, creativity=1, surreal=0. These do not create requester locks.'})
        try:
            normalized_envelope=pg.normalize_request_envelope(envelope)
            core=pg.normalize_authorial_core(raw,request_envelope=normalized_envelope,creative_control_snapshot=controls)
            assert core['source_request']==request and core['baseline_prompt_en']==prompt
            pg.photo_embodiment.build_policy(core,review)
            dump(rid+'/normalized-core.json',core)
            usable.append({'id':rid,'population':'fresh_independently_authored','core':core,'controls':controls,'review':review})
        except Exception as e:
            failure={'id':rid,'stage':'input_materialization','error':str(e),'traceback':traceback.format_exc(),'retry':'none; semantic fields and frozen text not repaired'}
            dump(rid+'/materialization-failure.json',failure);failures.append(failure)
    dump('materialization-summary.json',{'attempted':len(rows),'normalized':len(usable),'failures':failures})
    dump('input-freeze.json',{'authoring_artifact_sha256':EXPECTED,'files':{str(p.relative_to(OUT)):sha(p.read_bytes()) for p in sorted(OUT.glob('fresh_*/input-*.json'))}})
    return usable

def proposal(data):
    changed=dict(data);changed['slots']=dict(data['slots']);changed['slots']['surface_material']=[]
    effect={'dimension':'appearance','target':'main_subject','property':'wardrobe.surface.sheer_opacity'}
    ops=[]
    for entry in data['slots']['surface_material']:
        if entry['id'] in TARGETS:
            after=copy.deepcopy(entry);after['affected_properties'].append(effect.copy())
            ops.append({'surface':'ordinary','id':entry['id'],'before':entry['affected_properties'],'after':after['affected_properties']})
        else:after=entry
        changed['slots']['surface_material'].append(after)
    reg=dict(data[pg.VISUAL_OBLIGATIONS_DATA_KEY]);reg['profiles']=[]
    for p in data[pg.VISUAL_OBLIGATIONS_DATA_KEY]['profiles']:
        if p['id'] in [v.replace('clt_','clothing_') for v in TARGETS]:
            new=copy.deepcopy(p);new['concept_candidate']['affected_properties'].append(effect.copy())
            ops.append({'surface':'profile','id':p['id'],'before':p['concept_candidate']['affected_properties'],'after':new['concept_candidate']['affected_properties']})
        else:new=p
        reg['profiles'].append(new)
    changed[pg.VISUAL_OBLIGATIONS_DATA_KEY]=reg
    # Effects are excluded from semantic text/BM25F projections. Reuse only after
    # checking identical projections, and rebind derived metadata in memory.
    oldvi=data[pg.VISUAL_PROFILE_INDEX_DATA_KEY]
    assert all(pg.visual_profile_semantic_text(p)==oldvi['entries'][p['id']]['text'] for p in reg['profiles'])
    assert pg.visual_profile_bm25f_documents(reg)==pg.visual_profile_bm25f_documents(data[pg.VISUAL_OBLIGATIONS_DATA_KEY])
    newvi={**oldvi,'registry_sha256':pg.visual_profile_registry_sha256(reg)}
    changed[pg.VISUAL_PROFILE_INDEX_DATA_KEY]=newvi
    assert pg.semantic_bm25f_documents(changed)==pg.semantic_bm25f_documents(data)
    for cid in TARGETS:
        b=pg.candidate_pack_slot_entry_by_id(data,'surface_material',cid);a=pg.candidate_pack_slot_entry_by_id(changed,'surface_material',cid)
        assert pg.semantic_text_for_entry(b,'surface_material',kind='slot')==pg.semantic_text_for_entry(a,'surface_material',kind='slot')
    oldsi=data[pg.SEMANTIC_INDEX_DATA_KEY]
    newsi={**oldsi,'dictionary_hash':pg.dictionary_hash(changed)}
    changed[pg.SEMANTIC_INDEX_DATA_KEY]=newsi
    pg.validate_semantic_index_metadata(newsi,changed);pg.validate_visual_profile_index_metadata(newvi,reg)
    dump('opacity-only-proposal.json',{'operations':ops,'ct098':'DEFER; unchanged','metadata_only':True})
    dump('in-memory-index-rebinding.json',{'semantic_text_unchanged':True,'bm25f_documents_unchanged':True,'vectors_reused_without_calls':True,
        'semantic_dictionary_hash_before':oldsi['dictionary_hash'],'semantic_dictionary_hash_after':newsi['dictionary_hash'],
        'visual_registry_hash_before':oldvi['registry_sha256'],'visual_registry_hash_after':newvi['registry_sha256'],
        'production_metadata_validators_passed':True,'disk_indexes_modified':False,'scope':'In-memory effect-only qualification, not a production rebuild receipt.'})
    return changed

def evaluate_case(case,label,data):
    rid=case['id'];core=case['core'];controls=case['controls'];review=case['review']
    rawslots,rawbind,_=pg.retrieve_core_slots(data,core,controls)
    pack=pg.generate_candidate_pack(data,core,controls,review,seed=7)
    packed(rid+'/'+label+'-public-pack.json.gz',pack)
    objects=audit.candidate_objects_from_pack(pack)
    ordinary={r['id']:r for s in pack['slots'].values() for r in s['candidates']}
    inventory=[{'id':r['id'],'entry_id':r.get('entry_id'),'applicability':r.get('applicability'),
                'affected_dimensions':r.get('affected_dimensions'),'affected_properties':r.get('affected_properties')}
               for r in ordinary.values()]
    targets={}
    for cid in TARGETS:
        full='slot:surface_material:'+cid
        entry=pg.candidate_pack_slot_entry_by_id(data,'surface_material',cid)
        targets[cid]={'raw_retrieved':any(r['id']==full for s in rawslots.values() for r in s['candidates']),
            'public_ordinary_present':full in ordinary,'public_candidate':ordinary.get(full),
            'all_public_surfaces':[key for key in objects if cid in key],
            'source_effect_guard_allowed':contracts.property_effects_allowed(core['intent_lock'],entry['affected_dimensions'],entry['affected_properties']),
            'selection_audit_status':'not_exercised_no_natural_public_candidate'}
        if full in ordinary:
            # Probe the real applicability branch without pretending this partial
            # composition is a complete user deliverable or repairing the baseline.
            composed={'pack_id':pack['pack_id'],'composer':'agent','prompt_en':core['baseline_prompt_en'],
                'negative_en':pack['negative_en'],'chosen_candidate_ids':[full],
                'core_retrieval_sha256':pack['core_retrieval']['canonical_sha256'],
                'candidate_interpretations':[]}
            original_loader=pg.load_json
            def source_loader(path):
                if pathlib.Path(path).name=='photo_prompt_tags.json':
                    # Avoid copying loaded vector indexes: source audit needs only
                    # authored DATA plus quality policy, not cached retrieval vectors.
                    return copy.deepcopy({k:v for k,v in data.items() if k not in {pg.SEMANTIC_INDEX_DATA_KEY,pg.VISUAL_PROFILE_INDEX_DATA_KEY}})
                return original_loader(path)
            with mock.patch.object(pg,'load_json',side_effect=source_loader):
                result=audit.audit_composed_prompt(pack,composed)
                semresult=audit.audit_candidate_semantic_contracts(pack,core['baseline_prompt_en'],{full},{full:ordinary[full]},[])
            dump(rid+'/'+label+'-'+cid+'-selected-audit.json',{'composed_probe':composed,'full_audit_output':result,
                'focused_semantic_audit':semresult,'limit':'Intentionally partial composition; only named applicability/property branches are interpreted. Baseline was not rewritten.'})
            targets[cid]['selection_audit_status']='actual_public_candidate_checked_with_partial_composition'
            targets[cid]['candidate_applicability_failures']=[f for f in result['failures'] if f.get('check')=='candidate_applicability']
            targets[cid]['source_property_failures']=[f for f in semresult if 'property effects' in f.get('reason','')]
            targets[cid]['other_focused_semantic_failures']=[f for f in semresult if 'property effects' not in f.get('reason','')]
    result={'id':rid,'population':case['population'],'state':label,'core_sha256':core['canonical_sha256'],
        'baseline_sha256':sha(core['baseline_prompt_en'].encode()),'source_request_sha256':sha(core['source_request'].encode()),
        'raw_candidate_count':sum(len(s['candidates']) for s in rawslots.values()),'public_candidate_count':len(ordinary),
        'public_inventory':inventory,'targets':targets,
        'public_profile_ids':[r['id'] for r in (pack.get('visual_concept_candidates') or {}).get('candidates',[])],
        'core_retrieval_audit_failures':audit.audit_core_retrieval(pack,data)}
    dump(rid+'/'+label+'-summary.json',result)
    print(rid,label,{k:(v['raw_retrieved'],v['public_ordinary_present'],(v.get('public_candidate') or {}).get('applicability'),v.get('candidate_applicability_failures')) for k,v in targets.items()},flush=True)
    return result

def main():
    assert sha(FROZEN.read_bytes())==EXPECTED
    (OUT/'requests.frozen.json').write_bytes(FROZEN.read_bytes())
    frozen=json.loads(FROZEN.read_text())
    usable=materialize(frozen['requests'])
    # The canonical source-guided cohort is a separate denominator, never mixed
    # into the eight independent controls or described as blind qualification.
    old=json.loads((BASE/'reachability-probes.json').read_text())
    for x in old:
        if x['case']['candidate'] not in TARGETS:continue
        rid='canonical_'+x['case']['candidate']
        case={'id':rid,'population':'canonical_source_guided_development','core':x['core'],'controls':x['controls'],
              'review':fixtures.review(x['core']['baseline_prompt_en'])}
        dump(rid+'/unchanged-source-guided-input.json',case);usable.append(case)
    print('Materialized',len(usable)-2,'fresh cores; loading validated runtime DATA',flush=True)
    data=pg.load_runtime_data();after=proposal(data)
    allresults=[];failures=[]
    for case in usable:
        for label,source in [('before',data),('after_opacity_only',after)]:
            try:allresults.append(evaluate_case(case,label,source))
            except Exception as e:
                failure={'id':case['id'],'population':case['population'],'state':label,'error':str(e),'traceback':traceback.format_exc(),'retry':'none; no prompt, candidate-word, or semantic-field tuning'}
                dump(case['id']+'/'+label+'-runtime-failure.json',failure);failures.append(failure)
                print('FAIL',case['id'],label,str(e),flush=True)
    dump('results.json',{'frozen_input_sha256':EXPECTED,'results':allresults,'runtime_failures':failures})
    assert sha(FROZEN.read_bytes())==EXPECTED
    print('Finished',len(allresults),'public-build evaluations and',len(failures),'preserved runtime failures',flush=True)

if __name__=='__main__':main()
