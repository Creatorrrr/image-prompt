"""Separate recovery of archive dictionary ordering, with every value unchanged."""
import copy, gzip, json, pathlib, re, traceback
from unittest import mock
import evaluate as e
from tests.test_photo_authorship_policy import PhotoAuthorshipPolicyTests
pg,audit=e.pg,e.audit
root=e.OUT
data=pg.load_json(e.ASSETS/'photo_prompt_tags.json')
data[pg.QUALITY_LAYERS_DATA_KEY]=pg.load_quality_layers(e.ASSETS/'photo_prompt_quality_layers.json')
after=dict(data);after['slots']=dict(data['slots']);after['slots']['surface_material']=[]
for entry in data['slots']['surface_material']:
    row=copy.deepcopy(entry) if entry['id'] in e.TARGETS else entry
    if entry['id'] in e.TARGETS:
        row['affected_properties'].append({'dimension':'appearance','target':'main_subject','property':'wardrobe.surface.sheer_opacity'})
    after['slots']['surface_material'].append(row)
results=[]
for path in sorted(root.rglob('*-public-pack.json.gz')):
    name=path.name.replace('-public-pack.json.gz','-baseline-no-adoption-serialization-recovery.json')
    if (path.parent/name).exists():
        saved=json.loads((path.parent/name).read_text())
        results.append({'case':str(path.parent.relative_to(root)),'arm':path.name.split('-public-pack')[0],
            'status':saved['status'],'failure_checks':[f.get('check') for f in saved['audit'].get('failures',[])],
            'result_file':str((path.parent/name).relative_to(root))})
        continue
    pack=json.loads(gzip.decompress(path.read_bytes()))
    original_controls_path=path.parent/'input-controls.json'
    if original_controls_path.exists():
        original_controls=json.loads(original_controls_path.read_text())
    else:
        original_controls=json.loads((path.parent/'unchanged-source-guided-input.json').read_text())['controls']
    assert original_controls==pack['creative_controls']
    old_pack_id=audit.computed_pack_id(pack)
    pack['creative_controls']=original_controls
    assert audit.computed_pack_id(pack)==old_pack_id
    pg.creative_controls.validate(pack['creative_controls'],pack['authorial_core']['source_request'])
    source=after if path.name.startswith('after_opacity_only') else data
    core=pack['authorial_core'];prompt=core['baseline_prompt_en']
    composed=PhotoAuthorshipPolicyTests.composed(pack)
    review=copy.deepcopy(pack['embodiment_preflight']['baseline_review']);review['provenance']='agent_postcomposition'
    composed['embodiment_review']={'source_contract_sha256':pack['embodiment_preflight']['canonical_sha256'],'review':review}
    for row in composed['semantic_clarification_decisions']:
        row['rationale']='Retain the exact independently frozen baseline and every required property; reject optional additions for the zero-adoption control.'
    adult=pack.get('adult_appeal') or {}
    if adult.get('enabled'):
        ev=prompt.split('. ')[0].rstrip('.')
        phrase=re.search(r'\b[Aa]n? adult [A-Za-z-]+',prompt).group(0)
        composed['adult_appeal_brief']={
            'adult_subject_phrase':phrase,'agency_phrase':ev,
            'axes':{axis:{'intensity':row['intensity'],'realization':'baseline','affected_dimensions':[],
                'artistic_interpretation':'Retain the authored everyday human presence and saved expression strength without adding an optional treatment; perceptual success is not asserted.',
                'prompt_evidence':ev} for axis,row in adult['axes'].items()},
            'blend':copy.deepcopy(adult['blend']),
            'contextual_review':[{'candidate_id':cid,'reading':'uncertain','reason':'This unchanged-baseline control makes no optional adoption. Aesthetic relevance remains unassessed, so the independently authored realization is retained.'} for cid in (adult.get('contextual_retrieval') or {}).get('review_candidate_ids',[])],
            'contextual_comparison':'Retain the exact initial baseline at the saved strengths; optional candidate effects are unnecessary for this zero-adoption contract control. This records retention, not an aesthetic ranking.'}
    assert composed['prompt_en']==prompt and composed['chosen_candidate_ids']==[]
    original=pg.load_json
    def source_loader(filename):
        if pathlib.Path(filename).name=='photo_prompt_tags.json':return copy.deepcopy(source)
        return original(filename)
    try:
        with mock.patch.object(pg,'load_json',side_effect=source_loader):
            result=audit.audit_composed_prompt(pack,composed)
        status='passed' if not result['failures'] else 'failed'
    except Exception as exc:
        status='exception';result={'error':str(exc),'traceback':traceback.format_exc()}
    output={'composition':composed,'audit':result,'request_and_prompt_unchanged':True,
        'serialization_recovery':'Restore the exact original control snapshot dictionary ordering from the saved input; assert value equality and identical canonical pack hash. No prompt, core, control value, source effect, or lock changes.',
        'status':status,'limit':'Full integrity/scope/record audit of exact-baseline retention; no render or aesthetic success claim. No generated alternatives adopted.'}
    (path.parent/name).write_text(json.dumps(output,ensure_ascii=False,indent=2)+'\n')
    results.append({'case':str(path.parent.relative_to(root)),'arm':path.name.split('-public-pack')[0],
        'status':status,'failure_checks':[f.get('check') for f in result.get('failures',[])],'result_file':str((path.parent/name).relative_to(root))})
    print(results[-1],flush=True)
(root/'baseline-no-adoption-serialization-recovery-summary.json').write_text(json.dumps(results,indent=2)+'\n')
print('Baseline no-adoption audits:',len(results),'; passed:',sum(r['status']=='passed' for r in results),flush=True)
