"""Final authorized adapter arm: fresh_05 event phrase only; fresh_03 remains blocked."""
import copy,json,traceback
import evaluate as e
root=e.OUT;e.OUT=root/'final-adapter';e.OUT.mkdir(exist_ok=True)
prior=root/'supplemental/fresh_05_adapter_repair'
raw=json.loads((prior/'input-raw-core.json').read_text());before=copy.deepcopy(raw)
raw['event']='studies a timetable on a railway platform'
assert raw['event'] in raw['baseline_prompt_en']
assert {k for k in raw if raw[k]!=before[k]}=={'event'}
rid='fresh_05_final_adapter'
envelope=json.loads((prior/'input-envelope.json').read_text())
controls=json.loads((prior/'input-controls.json').read_text())
review=json.loads((prior/'input-embodiment.json').read_text())
for name,val in [('raw-core',raw),('envelope',envelope),('controls',controls),('embodiment',review)]:e.dump(rid+'/input-'+name+'.json',val)
receipt={'id':rid,'population':'fresh_final_schema_adapter','earlier_failures_preserved':True,
  'change_this_arm':{'event_before':before['event'],'event_after':raw['event']},
  'request_prompt_paths_property_locks_unchanged':True,'event_is_complete_verbatim_baseline_clause':True,
  'fresh_03':'Unadmitted. Final authorization forbids dangling fragments merely to meet word minima. No further mutation of its concept/anchor is attempted.'}
try:
 core=e.pg.normalize_authorial_core(raw,request_envelope=e.pg.normalize_request_envelope(envelope),creative_control_snapshot=controls)
 e.pg.photo_embodiment.build_policy(core,review)
 e.dump(rid+'/normalized-core.json',core);receipt['normalization']='passed'
 e.dump('adapter-receipt.json',receipt)
 data=e.pg.load_runtime_data();after=e.proposal(data)
 case={'id':rid,'population':'fresh_final_schema_adapter','core':core,'controls':controls,'review':review}
 results=[];failures=[]
 for label,source in [('before',data),('after_opacity_only',after)]:
  try:results.append(e.evaluate_case(case,label,source))
  except Exception as exc:
   f={'id':rid,'state':label,'error':str(exc),'traceback':traceback.format_exc(),'retry':'none'}
   e.dump(rid+'/'+label+'-runtime-failure.json',f);failures.append(f)
 e.dump('results.json',{'results':results,'runtime_failures':failures})
except Exception as exc:
 receipt.update(normalization='failed',error=str(exc),traceback=traceback.format_exc(),retry='none; final adapter qualification')
 e.dump('adapter-receipt.json',receipt)
 print(receipt,flush=True)
