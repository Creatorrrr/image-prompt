"""Read-only, provider-free audit probes. Writes only next to this script."""
import copy
import hashlib
import json
import pathlib
import subprocess
import sys

sys.dont_write_bytecode = True
ROOT = pathlib.Path('/workspace/scratch/ce8f20680f5a/image-prompt')
OUT = pathlib.Path(__file__).resolve().parent
ASSETS = ROOT / 'skills/photo-prompt-image-generator/assets'
sys.path[:0] = [str(ROOT), str(ASSETS.parent / 'scripts')]
import prompt_generator as pg
import photo_candidate_semantics as sem
import photo_contracts as contracts
import audit_composed_prompt as audit
from tests import photo_prompt_fixtures as fixtures

IDS = ['clt_ct078_v2', 'clt_ct079_v1', 'clt_ct079_v2', 'clt_ct080_v1',
       'clt_ct080_v2', 'clt_ct085_v1', 'clt_ct086_v1', 'clt_ct086_v2',
       'clt_ct087_v1', 'clt_ct088_v1', 'clt_ct088_v2', 'clt_ct091_v1',
       'clt_ct091_v2', 'clt_ct093_v2', 'clt_ct094_v1', 'clt_ct098_v2']

def dump(name, value):
    (OUT/name).write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n')

def lock(path=None, target='main_subject', dimension='appearance'):
    return {'contract_version':'photo-intent-lock/v2', 'open_dimensions':['appearance'],
            'semantic_anchors': [] if path is None else [
                {'dimension':dimension, 'target':target, 'property':path}]}

def make_core(request, subject, event, priorities, baseline, path, evidence):
    controls = pg.creative_controls.resolve(request, overrides={
        'sensual':0, 'fetish':0, 'surreal':0, 'creativity':1},
        context={'subject_category':'human', 'no_people':False, 'explicit_nonsexual':False}, seed=7)
    raw = fixtures.core(request, interpreted_intent='A fashion product photograph preserves the specified fabric property while observing the dress folds.',
        subject=subject, setting='a plain studio wall', event=event,
        visual_priorities=tuple(priorities), baseline_prompt_en=baseline,
        open_dimensions=('appearance','material','color','lighting','composition','framing','camera','atmosphere'),
        anchor_evidence=(subject,event,priorities[0]))
    raw['creative_controls_sha256'] = controls['canonical_sha256']
    raw['intent_lock']['semantic_anchors'].append({'anchor_id':'fabric_property',
        'source_text':evidence, 'prompt_evidence':evidence, 'dimension':'appearance',
        'target':'main_subject', 'property':path})
    return pg.normalize_authorial_core(raw,
        request_envelope=pg.normalize_request_envelope(fixtures.envelope(request)),
        creative_control_snapshot=controls), controls

def main():
    source_files = [ASSETS/'photo_prompt_textile_surface_extension.json',
                    ASSETS/'photo_prompt_visual_obligations_textile_surface.json',
                    ROOT/'docs/research-evidence/photo-prompt/extension-maintenance/photo_prompt_textile_surface_extension.json',
                    ASSETS.parent/'scripts/photo_contracts.py',
                    ASSETS.parent/'scripts/photo_candidate_semantics.py',
                    ASSETS.parent/'scripts/prompt_generator.py',
                    ASSETS.parent/'scripts/audit_composed_prompt.py']
    hashes = {str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in source_files}
    ext = json.loads(source_files[0].read_text())
    source_rows = {e['id']:e for e in ext['slots']['surface_material']}
    profiles_raw = {p['id']:p for p in json.loads(source_files[1].read_text())['profiles']}
    data = pg.load_json(ASSETS/'photo_prompt_tags.json')
    data[pg.QUALITY_LAYERS_DATA_KEY] = pg.load_quality_layers(ASSETS/'photo_prompt_quality_layers.json')
    registry = pg.load_visual_obligation_registry(ASSETS/'photo_prompt_visual_obligations.json')
    data[pg.VISUAL_OBLIGATIONS_DATA_KEY] = registry
    profiles = {p['id']:p for p in registry['profiles']}
    dump('sampled-source-evidence.json', {'source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
        'source_hashes':hashes, 'sample_ids':IDS, 'sampling_note':'Judgmental sample of 16 textile ordinary candidates and their 16 matching profiles, not a category-wide or all-material audit.',
        'records':[{'ordinary':source_rows[i], 'profile':profiles_raw[i.replace('clt_','clothing_')]} for i in IDS]})
    matrix = []
    for i in IDS:
        e = source_rows[i]
        p = profiles[i.replace('clt_','clothing_')]['concept_candidate']
        tests = [(None,'main_subject','appearance'),
                 ('wardrobe','main_subject','appearance'),
                 ('wardrobe.surface','main_subject','appearance'),
                 ('wardrobe.surface.sheer_opacity','main_subject','appearance'),
                 ('wardrobe.color','main_subject','appearance'),
                 ('wardrobe.color','secondary_subject','appearance'),
                 ('wardrobe.color','main_subject','material'),
                 ('hair.color','main_subject','appearance')]
        matrix.append({'candidate':i, 'source_profile_effects_equal':e['affected_properties']==p['affected_properties'],
            'checks':[{'lock':path, 'target':target, 'lock_dimension':dim,
                       'ordinary_allowed':contracts.property_effects_allowed(lock(path,target,dim),e['affected_dimensions'],e['affected_properties']),
                       'profile_allowed':contracts.property_effects_allowed(lock(path,target,dim),p['affected_dimensions'],p['affected_properties'])}
                      for path,target,dim in tests]})
    dump('property-matrix.json',matrix)
    cases = [
        {'id':'opaque_crisp', 'candidate':'clt_ct091_v1', 'path':'wardrobe.surface.sheer_opacity',
         'subject':'one adult woman wearing an opaque light fabric dress with crisp angular folds',
         'event':'the woman stands still beside the wall',
         'priorities':['crisp angular fabric folds','complete fabric opacity'], 'evidence':'opaque light fabric',
         'request':'Make a fashion product photograph of one adult woman wearing an opaque light fabric dress with crisp angular folds. Preserve the complete fabric opacity while she stands still beside a plain wall.'},
        {'id':'opaque_fluid', 'candidate':'clt_ct091_v2', 'path':'wardrobe.surface.sheer_opacity',
         'subject':'one adult woman wearing an opaque soft fabric dress falling in small fluid folds',
         'event':'the woman stands still beside the wall',
         'priorities':['small fluid fabric folds','complete fabric opacity'], 'evidence':'opaque soft fabric',
         'request':'Make a fashion product photograph of one adult woman wearing an opaque soft fabric dress falling in small fluid folds. Preserve the complete fabric opacity while she stands still beside a plain wall.'},
        {'id':'uniform_color', 'candidate':'clt_ct098_v2', 'path':'wardrobe.color',
         'subject':'one adult woman wearing a uniform blue fabric dress',
         'event':'the woman stands still beside the wall',
         'priorities':['uniform blue fabric','a continuous gradient fading along the background wall'], 'evidence':'uniform blue fabric',
         'request':'Make a fashion product photograph of one adult woman wearing a uniform blue fabric dress beside a wall. Keep the dress color uniform while a continuous gradient fades along the background wall.'},
    ]
    results = []
    for case in cases:
        baseline = (f"A textile study shows {case['subject']}; {case['event']}. "
            f"The photographic priority is {case['priorities'][0]}. "
            f"{case['priorities'][1].capitalize()} is clearly visible. "
            "Soft side light gives the fabric gentle dimensional detail. The dress belongs to the same woman, with its hem and continuous surface visible against the uncluttered studio background.")
        core, controls = make_core(case['request'],case['subject'],case['event'],case['priorities'],baseline,case['path'],case['evidence'])
        slots,binding,_ = pg.retrieve_core_slots(data,core,controls)
        ids = [r['id'] for p in slots.values() for r in p['candidates']]
        cid = 'slot:surface_material:'+case['candidate']
        e = source_rows[case['candidate']]
        row = {'case':case, 'core':core, 'controls':controls,
            'ordinary_retrieved':cid in ids,
            'surface_candidate_ids':[r['id'] for r in slots.get('surface_material',{}).get('candidates',[])],
            'ordinary_source_guard_allowed':contracts.property_effects_allowed(core['intent_lock'],e['affected_dimensions'],e['affected_properties']),
            'core_retrieval_audit_failures':audit.audit_core_retrieval({'slots':slots,'core_retrieval':binding,'authorial_core':core,'creative_controls':controls},data)}
        # Real resolver; advisory authored term cannot become a required requester obligation.
        pid = case['candidate'].replace('clt_','clothing_')
        narrow = {**registry,'profiles':[profiles[pid]]}
        resolution = pg.resolve_visual_profile_hits(narrow,[{'source':'authorial_core_interpretation','text':e['en'],'polarity':'advisory'}],query_fields={'advisory_text':e['en']},adult_context=True)
        thin_data = {pg.VISUAL_OBLIGATIONS_DATA_KEY:narrow}
        optional = pg.candidate_pack_visual_concept_candidates(thin_data,{'provenance':{'authorial_core':core}},{},None,None,resolution)
        row['optional_advisory_resolution'] = resolution
        row['optional_profile_ids'] = [r['id'] for r in (optional or {}).get('candidates',[])]
        row['profile_real_resolver_admitted'] = 'visual-concept:'+pid in row['optional_profile_ids']
        row['profile_probe_limit'] = 'A separate advisory component-complete input to the real resolver; not a claim that this profile is discovered from the normalized opaque/solid baseline.'
        natural_profile_resolution = pg.candidate_pack_resolve_visual_profiles(data,{'provenance':{'authorial_core':core}},{},None)
        row['natural_core_profile_hits'] = [h for h in natural_profile_resolution['hits'] if h['profile_id']==pid]
        results.append(row)
        print(case['id'],row['ordinary_retrieved'],row['surface_candidate_ids'],row['profile_real_resolver_admitted'],flush=True)
    dump('reachability-probes.json',results)
    after = {str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in source_files}
    dump('source-immutability.json',{'before':hashes,'after':after,'identical':hashes==after})

if __name__=='__main__':main()
