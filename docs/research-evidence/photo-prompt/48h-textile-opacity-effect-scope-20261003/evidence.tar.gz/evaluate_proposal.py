"""Frozen source-guided development, not blind evaluation or a production edit."""
import copy
import json
import sys
from pathlib import Path
from unittest import mock
sys.dont_write_bytecode = True
import probe
from probe import pg, sem, contracts, audit, ROOT, ASSETS, OUT, dump, lock

PROPOSALS = {'clt_ct091_v1':'wardrobe.surface.sheer_opacity',
             'clt_ct091_v2':'wardrobe.surface.sheer_opacity',
             'clt_ct098_v2':'wardrobe.color'}

def main():
    data = pg.load_json(ASSETS/'photo_prompt_tags.json')
    data[pg.QUALITY_LAYERS_DATA_KEY] = pg.load_quality_layers(ASSETS/'photo_prompt_quality_layers.json')
    registry = pg.load_visual_obligation_registry(ASSETS/'photo_prompt_visual_obligations.json')
    profiles = {p['id']:p for p in registry['profiles']}
    fixtures = json.loads((OUT/'reachability-probes.json').read_text())
    operations = []
    for cid, path in PROPOSALS.items():
        row = pg.candidate_pack_slot_entry_by_id(data,'surface_material',cid)
        effect = {'dimension':'appearance','target':'main_subject','property':path}
        for filename, record_id, before in [
            ('photo_prompt_textile_surface_extension.json',cid,row['affected_properties']),
            ('photo_prompt_visual_obligations_textile_surface.json',cid.replace('clt_','clothing_'),profiles[cid.replace('clt_','clothing_')]['concept_candidate']['affected_properties'])]:
            operations.append({'file':str((ASSETS/filename).relative_to(ROOT)),
                'record_id':record_id,'field':'affected_properties' if filename.endswith('_extension.json') else 'concept_candidate.affected_properties',
                'before':before,'after':before+[effect]})
    dump('proposed-metadata-delta.json',{'status':'proposal_only',
        'development_basis':'Source-guided fixtures, not blind holdouts. No repository edits or provider calls.',
        'meaning_changes':False,'scope':'Three ordinary records and three matching profiles. Retain every existing effect; append one canonical owner-scoped property.',
        'operations':operations,
        'not_included':['index regeneration','maintenance receipt hash updates','new aliases','new candidates','dimension closure','rendered quality claims']})
    results=[]
    for fix in fixtures:
        cid=fix['case']['candidate'];pid=cid.replace('clt_','clothing_');path=PROPOSALS[cid]
        before=pg.candidate_pack_slot_entry_by_id(data,'surface_material',cid)
        after=copy.deepcopy(before)
        after['affected_properties'].append({'dimension':'appearance','target':'main_subject','property':path})
        p_before=profiles[pid]
        p_after=copy.deepcopy(p_before)
        p_after['concept_candidate']['affected_properties']=copy.deepcopy(after['affected_properties'])
        # A full-corpus in-memory source variant; disk assets and caches are not written.
        patched=dict(data)
        patched['slots']=dict(data['slots'])
        patched['slots']['surface_material']=[after if e['id']==cid else e for e in data['slots']['surface_material']]
        core=fix['core'];controls=fix['controls'];full_id='slot:surface_material:'+cid
        controls_matrix=[]
        paths=[(None,'main_subject','appearance'),(path,'main_subject','appearance'),
               (path+'.selected_panel','main_subject','appearance'),
               ('.'.join(path.split('.')[:-1]),'main_subject','appearance'),
               ('wardrobe','main_subject','appearance'),
               (path,'secondary_subject','appearance'),
               (path,'main_subject','material'),
               ('hair.color','main_subject','appearance'),
               ('wardrobe.garment_type','main_subject','appearance'),
               ('wardrobe.color.hue','main_subject','appearance'),
               ('wardrobe.surface.jersey_rib_interlock','main_subject','appearance'),
               ('wardrobe.color' if 'opacity' in path else 'wardrobe.surface.sheer_opacity','main_subject','appearance')]
        for prop,target,dim in paths:
            one={'path':prop,'target':target,'lock_dimension':dim}
            for label,entry,profile in [('before',before,p_before),('after',after,p_after)]:
                one[label]={'ordinary_allowed':contracts.property_effects_allowed(lock(prop,target,dim),entry['affected_dimensions'],entry['affected_properties']),
                    'profile_allowed':contracts.property_effects_allowed(lock(prop,target,dim),profile['concept_candidate']['affected_dimensions'],profile['concept_candidate']['affected_properties'])}
            controls_matrix.append(one)
        route_results={}
        for label,source,entry,profile in [('before',data,before,p_before),('after',patched,after,p_after)]:
            slots,binding,_=pg.retrieve_core_slots(source,core,controls)
            public_ids=[r['id'] for p in slots.values() for r in p['candidates']]
            semantic=sem.semantic_source(entry,'surface_material',source['candidate_semantic_policy'])
            candidate={'id':full_id,'slot':'surface_material','entry_id':cid,
                       'content_form':'unordered_inspiration_terms','semantic_surface_version':sem.SURFACE_VERSION,
                       'concept_terms':semantic['concept_units'],**semantic}
            pack={'contract_version':'photo-candidate-pack/v6','candidate_semantic_surface_version':sem.SURFACE_VERSION,
                  'authorial_core':core,'creative_controls':controls,'slots':slots,'core_retrieval':binding,
                  'provenance':{'seed':7}}
            pack['candidate_bundles']=pg.candidate_pack_candidate_bundles(source,pack)
            final_evidence='On the same dress, '+entry['en']+' becomes visible along its lower hem.'
            prompt=core['baseline_prompt_en']+' '+final_evidence
            interpretation={'candidate_id':full_id,'relation_evidence':{'visible_owner_relation':final_evidence}}
            # Explicit in-memory source substitution exercises the proposed DATA with
            # the real source-recomputed auditor. This is not a full composed audit.
            original_loader=audit.candidate_semantics_generator.load_json
            def proposed_loader(filename):
                if Path(filename).name=='photo_prompt_tags.json':
                    return copy.deepcopy(source)
                return original_loader(filename)
            with mock.patch.object(audit.candidate_semantics_generator,'load_json',side_effect=proposed_loader):
                failures=audit.audit_candidate_semantic_contracts(pack,prompt,{full_id},{full_id:candidate},[interpretation])
            narrow={**registry,'profiles':[profile]}
            resolution=pg.resolve_visual_profile_hits(narrow,[{'source':'authorial_core_interpretation','text':entry['en'],'polarity':'advisory'}],query_fields={'advisory_text':entry['en']},adult_context=True)
            optional=pg.candidate_pack_visual_concept_candidates({pg.VISUAL_OBLIGATIONS_DATA_KEY:narrow},{'provenance':{'authorial_core':core}},{},None,None,resolution)
            no_open_core=copy.deepcopy(core);no_open_core['intent_lock']['open_dimensions']=[]
            closed=pg.candidate_pack_visual_concept_candidates({pg.VISUAL_OBLIGATIONS_DATA_KEY:narrow},{'provenance':{'authorial_core':no_open_core}},{},None,None,resolution)
            route_results[label]={'core_sha256':core['canonical_sha256'],'ordinary_retrieved':full_id in public_ids,
                'surface_candidate_ids':[r['id'] for r in slots.get('surface_material',{}).get('candidates',[])],
                'ordinary_source_scope_guard_allowed':contracts.property_effects_allowed(core['intent_lock'],entry['affected_dimensions'],entry['affected_properties']),
                'core_retrieval_audit_failures':audit.audit_core_retrieval(pack,source),
                'source_recomputed_selected_semantic_audit_failures':failures,
                'optional_component_complete_advisory_profile_ids':[r['id'] for r in (optional or {}).get('candidates',[])],
                'optional_profile_with_closed_appearance_ids':[r['id'] for r in (closed or {}).get('candidates',[])],
                'selected_semantic_candidate':candidate,'selected_semantic_prompt':prompt,'selected_semantic_interpretation':interpretation}
        results.append({'candidate':cid,'case':fix['case'],
            'core_before':core,'core_after':copy.deepcopy(core),'controls':controls,
            'core_unchanged':True,'source_guided_development_only':True,
            'controls_matrix':controls_matrix,'routes':route_results,
            'natural_core_profile_hits_before':fix['natural_core_profile_hits'],
            'natural_profile_limit':'No claim of natural public-profile red/green: the baseline does not satisfy this profile component gate. Separate component-complete advisory input isolates the scope filter.'})
        print(cid, {k:(v['ordinary_retrieved'],v['ordinary_source_scope_guard_allowed'],v['source_recomputed_selected_semantic_audit_failures']) for k,v in route_results.items()},flush=True)
    dump('before-after-development-evidence.json',results)
    for r in results:
        assert r['core_before']==r['core_after']
        b,a=r['routes']['before'],r['routes']['after']
        assert b['ordinary_retrieved'] and b['ordinary_source_scope_guard_allowed']
        assert not b['core_retrieval_audit_failures'] and not a['core_retrieval_audit_failures']
        assert not b['source_recomputed_selected_semantic_audit_failures']
        assert not a['ordinary_source_scope_guard_allowed']
        assert len(a['source_recomputed_selected_semantic_audit_failures'])==1
        assert 'preserve requester property locks' in a['source_recomputed_selected_semantic_audit_failures'][0]['reason']
        assert b['optional_component_complete_advisory_profile_ids']
        assert not a['optional_component_complete_advisory_profile_ids']
        assert not b['optional_profile_with_closed_appearance_ids'] and not a['optional_profile_with_closed_appearance_ids']
        for c in r['controls_matrix']:
            assert c['before']['ordinary_allowed']==c['before']['profile_allowed']
            assert c['after']['ordinary_allowed']==c['after']['profile_allowed']
            if c['path'] is None or c['target']=='secondary_subject' or c['path'] in {'hair.color','wardrobe.garment_type','wardrobe.surface.jersey_rib_interlock'}:
                assert c['after']['ordinary_allowed']
    print('All source-guided before/after assertions passed; repository source unchanged.',flush=True)

if __name__=='__main__':main()
