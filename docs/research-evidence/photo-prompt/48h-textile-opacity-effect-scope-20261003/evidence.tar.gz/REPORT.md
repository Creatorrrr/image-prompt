# Bounded textile property-effect audit

## Result and promotion boundary

Audited repository HEAD: **7e769e3e4a0da7068723830bb0c5c5c2dfd784c8**, also recorded byte-for-byte in `sampled-source-evidence.json`.

Three source-guided counterexamples demonstrate ordinary-candidate property-scope gaps. The smallest proposal is an **additive property-effect entry** on three existing ordinary records and their three matching profile records. No source meanings, existing effects, labels, aliases, gates, dimensions, weights, or ownership are changed. No repository files were edited.

- **CT091 v1/v2: strong proposal for independent review.** Explicitly sheer/translucent fabric is compatible with the guard for a requester-locked opaque fabric because the source declares only the textile-family property. Append `wardrobe.surface.sheer_opacity`, with the existing `appearance` carrier and `main_subject` target
- **CT098 v2: confirmed discrepancy, proposed metadata needs special collateral review.** A fabric color gradient passes a `wardrobe.color` lock on a uniformly blue dress. The draft adds the existing canonical `wardrobe.color` path for the same `main_subject`; this closes no frame-wide color dimension. A narrow hue-only lock may nevertheless be overblocked, as explained below
- Four other color-related sampled records are **DEFER**, not swept into this patch
- Nine sampled records are **KEEP for this bounded review**. This is not a certification that their metadata covers every possible property

All findings and fixtures are **source-guided development**, not blind holdouts. Independent review and independently authored request/control fixtures remain required before any production change. There is no full composed-prompt, runtime, rendered-image, or public visual-profile red/green claim.

## Sampling

Judgmental sample of **16 ordinary records and their 16 matching profiles**, all in the textile-surface extension. This is not category-wide completeness, a random sample, or an audit of all material data. The matching profile ID replaces `clt_` with `clothing_` in each row below.

| Ordinary record | Authored meaning reviewed | Decision |
| --- | --- | --- |
| clt_ct078_v2 | Matte linen-look slub texture | KEEP; preserve look-versus-fiber limitation |
| clt_ct079_v1 | Sheer outer panel reveals separate lining | KEEP for opacity scope; its opacity path already exists. Do not infer visible skin or require a new underlayer from this review |
| clt_ct079_v2 | Opaque panel conceals the layer behind | KEEP; direct opacity-scope positive control |
| clt_ct080_v1 | Suede-like short diffuse nap | KEEP; no new composition or chemical-identity claim |
| clt_ct080_v2 | Patent finish reflects sharp highlights | KEEP; surface reflection is not a global lighting change |
| clt_ct085_v1 | Satin-like broad smooth highlights | KEEP; appearance does not establish silk content |
| clt_ct086_v1 | Denim diagonal twill yarn lines | KEEP; no automatic blue-color obligation |
| clt_ct086_v2 | Chambray-like colored/pale yarn mixture | DEFER color-distribution overlap; no dedicated reachable adoption/collateral fixture established here |
| clt_ct087_v1 | Rib-knit ridges and recessed channels | KEEP; no motion/stretch inference |
| clt_ct088_v1 | Pattern from contrasting woven textures | KEEP; textural contrast need not introduce another color |
| clt_ct088_v2 | Integrated colored jacquard-knit motifs | DEFER color scope; color versus textural-pattern choices need separate fixture |
| clt_ct091_v1 | Crisp sheer panel with angular folds | PROPOSE additive opacity property |
| clt_ct091_v2 | Soft translucent panel with fluid folds | PROPOSE additive opacity property |
| clt_ct093_v2 | Broad horizontal garment color bands | DEFER color scope; no dedicated reachable adoption/collateral fixture established here |
| clt_ct094_v1 | Two-color repeated checks | DEFER color scope despite explicit two-color meaning; not included by analogy alone |
| clt_ct098_v2 | Continuous fading fabric color gradient | PROPOSE with color-scope collateral review |

Camera data and the already-fixed H15/H16 records were not audited. A preliminary tactile-extension inventory was read only to choose a bounded sample; no tactile-family conclusion is claimed.

## Source evidence

These findings compare records with their **own authored canonical meanings**, not an external taxonomy or newly invented synonyms.

1. `skills/photo-prompt-image-generator/assets/photo_prompt_textile_surface_extension.json`
   - CT091 v1 begins at line 993, CT091 v2 at 1033. Their English meaning, concept unit, and directed relation explicitly say *sheer* and *translucent*, respectively. Their only effect is `appearance / main_subject / wardrobe.surface.chiffon_organza_taffeta`
   - CT098 v2 begins at 1519. Its English meaning, concept unit, and relation all require a continuous fabric color gradient. Its only effect is `appearance / main_subject / wardrobe.surface.wash_distress_dye`
   - CT079 v1/v2 at lines 47/88 establish the existing `wardrobe.surface.sheer_opacity` vocabulary and explicitly contrast visibility/transmission outcomes
2. `assets/photo_prompt_visual_obligations_textile_surface.json`, relative to the same skill
   - Matching profiles start at lines 2254, 2345, and 3437. Their definitions, authored components, evidence, and native gates preserve those same visible meanings. Their `concept_candidate.affected_properties` repeat the same omissions
   - All 16 sampled ordinary/profile effect lists are equal; this is **shared underspecification**, not ordinary/profile disagreement
3. `SKILL.md:247–249` explicitly documents `appearance / main_subject / wardrobe.color`, parent-path semantics, and keeping actual protected meaning across carriers
4. `references/maintenance.md:13` expressly says moving wardrobe color to another carrier cannot bypass the property anchor
5. `docs/research-evidence/photo-prompt/extension-maintenance/photo_prompt_textile_surface_extension.json`
   - CT091 binds S01/S05; CT098 binds S38. These are marked `family_context_only_authored_visible_variant`, with authored geometry and untested native pixels/user acceptance
   - The maintenance receipt itself limits external sources to family context. This audit therefore does **not** claim those sources prove every exact visible construction or gate

`sampled-source-evidence.json` includes the exact 16 record pairs and SHA-256 hashes of the seven relevant source/evidence/consumer files. No generated index snapshot was copied.

## Actual consumer path

- `photo_candidate_semantics.py:220–235`, `semantic_source`, preserves the authored affected dimensions and properties unchanged
- `photo_contracts.py:94–128`, `property_effects_allowed`, compares target/property equality and parent-child paths, across carrier dimensions. The two textile-family paths are siblings of the opacity/color properties, so they do not overlap
- `prompt_generator.py:11435–11548`, `retrieve_core_slots`, performs full-corpus ordinary retrieval. Focused assertion discovery uses the property guard at lines 2303–2308, but the ordinary broad/focal lane is advisory and can still expose a retrieved candidate
- `audit_composed_prompt.py:2848–2862`, within `audit_candidate_semantic_contracts`, reloads the source candidate, requires published effects to match it, and checks those trusted effects against property locks. Incomplete authored effects remain incomplete after recomputation
- `prompt_generator.py:7690–7697`, `candidate_pack_visual_concept_candidates`, applies the same declared property check before exposing an optional profile

This is a DATA-level omission, not a request to weaken or replace the generic guard. The proposed patch intentionally does not remove broad material dimensions or close appearance/color wholesale.

## Reachable ordinary counterexamples

The three complete normalized cores and creative-control snapshots are in `reachability-probes.json`, and the identical before/after core bytes are in `before-after-development-evidence.json`. They use existing fixture builders, true source-bound property anchors, a human context, zero sensual/fetish/surreal controls, and explicit fashion-product intent. Product intent is present in the request **and interpreted intent**, allowing the existing surface-material domain guard legitimately.

1. **Opaque crisp fabric**: requester preserves complete fabric opacity on a dress with crisp angular folds. The full authored corpus retrieves `slot:surface_material:clt_ct091_v1` alongside a crisp-poplin candidate and the explicitly opaque CT079 v2 candidate
2. **Opaque fluid fabric**: requester preserves complete fabric opacity on a soft dress with small fluid folds. Full-corpus retrieval exposes `clt_ct091_v2`
3. **Uniform blue dress, gradient background**: requester preserves uniform blue fabric on the dress while the wall has a continuous fading gradient. Full-corpus retrieval exposes `clt_ct098_v2`. The candidate's declared owner remains the main subject's wardrobe; the background does not license changing that owner

For each before state:
- The problematic ordinary ID is actually retrieved
- The source property guard returns true
- Core-retrieval recomputation returns no failures
- The source-recomputed **selected semantic-contract audit** accepts the candidate's declared effects and complete literal relation evidence

For each proposed after state, using **only an in-memory source variant**:
- The exact core and control bytes are unchanged
- Ordinary advisory retrieval still exposes the ID; this is expected and is **not** claimed as a retrieval red/green
- Source property compatibility becomes false
- Core-retrieval recomputation still passes using the corresponding source binding
- The selected semantic-contract audit returns exactly one source/property-preservation failure

The semantic audit is run as a focused real consumer, with its tags-file loader redirected to a deep copy of the in-memory source variant. Other loaders remain real. This is not a full `audit_composed_prompt` invocation or proof that an inconsistent final prompt would pass every other check. The deliberately inconsistent example final prose makes the metadata issue observable; it is not a proposed creative output.

An initial harness attempt substituted every `load_json` call and contaminated its own in-memory quality-layer context. That failed exploratory run is retained in `exploratory-harness-failure.log`. The corrected harness substitutes only the tags-file read and isolates each source copy; its successful output is `evaluation.log`.

## Matching-profile limit

The natural opaque/solid normalized cores produce **no hit for their matching profile**, before the proposal. Their component gates provide additional protection. Do not report a natural public-profile red/green result.

A separate, explicitly component-complete **advisory** input to the real BM25F resolver admits each matching profile as optional, never hard. The actual optional-profile projection then permits it with the current missing effects and rejects it with the added effect. That narrow probe isolates scope-filter behavior; it does not establish natural discovery from the conflicting core. The exact resolver results and this limitation are retained in the evidence.

## Controls and collateral false negatives

`property-matrix.json` tests all 16 existing source/profile pairs. `before-after-development-evidence.json` contains 12 before/after control conditions per proposed record, independently for ordinary and profile declarations:

- Fully open property scope remains allowed
- Exact opacity/color locks and child locks are rejected after the addition
- Ancestor `wardrobe` and parent surface/color locks remain rejected
- The same property on `secondary_subject` stays allowed
- A lock carried on `material` rather than `appearance` is still rejected for the same semantic owner/property
- Hair color, garment type, a sibling knit property, and opacity-versus-color unrelated property controls stay allowed where genuinely disjoint
- Optional profile exposure with appearance not open is rejected in both arms

Important semantic limits:

1. **Opacity is not skin exposure.** A sheer outer fabric over an opaque lining can leave the overall garment opaque. The counterexamples specifically preserve the fabric/panel's opacity, not merely modesty, skin visibility, or an opaque final silhouette. Add no skin/body/underlayer/color effects from inference
2. **Layer ownership remains coarse.** Existing records target `main_subject`, with a wardrobe property. Adding the existing opacity path can exclude an outer-panel refinement when a request really protects only a different panel or lining under that same owner. Independent fixtures should test target/panel specificity rather than silently replacing the target, expanding it to `*`, or closing all appearance
3. **Color hue can be preserved within a gradient.** The CT098 draft uses the documented parent `wardrobe.color`. The matrix explicitly shows it also rejects `wardrobe.color.hue`. A blue-only hue request could admit a blue-to-pale-blue gradient artistically; the conservative parent effect cannot prove that no hue change occurs. This is the main collateral issue for the independent reviewer. If that collateral is not acceptable, **defer CT098**, or establish a narrower canonical distribution property through separate design/review rather than inventing one to pass this case
4. **Already-required/retained meaning is distinct.** A requester may already require translucent cloth or a gradient. The proposal changes optional augmentation effect declarations; it does not rewrite source definitions or hard-profile activation. A baseline retained unchanged does not need a newly adopted incompatible augmentation. Independently authored compatible detail remains available under the existing contracts
5. A general texture change can leave opacity/color untouched. No opacity/color effect is added to linen look, satin highlights, suede nap, denim diagonal weave, ribs, or texture-only jacquard merely by material-family association

## Frozen proposal and next validation

`proposed-metadata-delta.json` is the exact six-record metadata draft: append one effect per record, retain the old list entries, and change nothing else. CT098 is separable from the two opacity records if collateral review rejects it.

Before production editing:
1. Have an independent reviewer judge the canonical property/owner mapping and author new request/control fixtures without deriving the answer from these development probes
2. Confirm exact-predicate opacity versus layered-garment visibility, and color distribution versus hue-only preservation
3. Apply only accepted record changes; update required maintenance receipts and derived metadata/index bindings through the existing supported rebuild workflow, without changing semantic text or making provider calls unnecessarily
4. Run focused real-source regression and the affected dictionary/index integrity checks; broaden only as required by changed surfaces

This read-only audit ran no providers and no full regression suite. It neither edits the ongoing regression source nor claims image quality improvement.

## Reproduce

From the pinned repository, with bytecode writes disabled:

```text
PYTHONDONTWRITEBYTECODE=1 .venv/bin/python ../data-progress-48h-20261003/material-effect-audit/probe.py
PYTHONDONTWRITEBYTECODE=1 .venv/bin/python ../data-progress-48h-20261003/material-effect-audit/evaluate_proposal.py
```

Both scripts write only beside themselves outside the repository. The second script creates in-memory proposed source variants; neither edits assets, tests, Git state, or generated indexes. Reproduction writes are development evidence only.
