# CT098 color-property design options

## Conclusion

**A narrowly named color descendant is structurally supported and can faithfully describe CT098's spatial-color relation. It is not yet justified as the sole complete effect declaration for this unrestricted gradient candidate.**

Both `wardrobe.color.distribution` and `wardrobe.color.spatial_gradient` would preserve a `wardrobe.color` parent lock while allowing a sibling `wardrobe.color.hue` lock. A real public-build experiment confirms this behavior for `distribution`. That is a useful design result, not sufficient acceptance evidence: the same declaration also permits saturation/lightness locks, simultaneous hue+saturation+lightness locks, and unrelated-looking pattern paths without establishing semantic compatibility.

The prior **DEFER for the broad `wardrobe.color` proposal remains unchanged**. No narrow replacement is promoted here. This document is separate from the frozen CT091 review, whose decision and evidence are unchanged.

Reviewed source: `7e769e3e4a0da7068723830bb0c5c5c2dfd784c8`. Source files and runtime behavior were not changed. Experiments substitute one ordinary source record only in memory.

## Existing vocabulary and precedent

I inventoried property declarations in 81 top-level authored asset JSON files, excluding generated index files and shards; the exact file list and relevant property occurrences are in `ct098-design-evidence.json`.

- The only authored wardrobe-color effect path found is **`wardrobe.color`**, on ordinary/profile `sca_g20`, a contrasting garment-edge trim
- There are **no authored `wardrobe.color` descendants** in that inventory: neither suggested new path, nor wardrobe hue/saturation/lightness paths
- There is relevant structural precedent in `photo_prompt_subculture_appearance_extension.json`: `hair.color.lateral_partition` at line 939, `hair.color.layer_partition` at 1001, and `hair.color.root_tip_transition` at 1063, with matching profile declarations
- The root-to-tip hair definition specifies a gradual spatial transition through intermediate colors. This supports the legitimacy of a spatial relation below a color property; it does not demonstrate that all color-coordinate collateral is already covered
- `tests/test_photo_subculture_appearance_alternatives.py:79–88` tests parent property protection and carrier independence. It does not qualify hue/saturation/lightness children under those hair-color declarations
- `photo_prompt_color_relations_extension.json:1358` already defines **Spatial Gradient / Ombré** as smooth color change along a specified physical surface or spatial path. Its counterpart `cr_spatial_gradient` at `photo_prompt_visual_obligations_color_relations.json:4683` preserves that position-dependent relation
- The same color-relation family explicitly separates a spatial gradient from gradient mapping, where tonal values rather than position determine color treatment; `tests/test_photo_color_relations.py:57` covers that distinction
- `cr_candidate_monochromatic`, at color-extension line 6, explicitly permits lightness/chroma differences within one recognizable hue family. This is direct repository support for the statement that a gradient need not require a hue change

These are semantic and structural precedents, not an existing canonical wardrobe-distribution path to reuse verbatim. The general color candidates do not supply an owner-scoped wardrobe effect schema. Importing their `color` carrier or frame-level scope would not be a justified CT098-only change.

## What the current hierarchy actually guarantees

`normalize_intent_lock` at `prompt_generator.py:4150–4154` checks lowercase dotted target/property syntax and request grounding; it does not consult a closed semantic property registry. `photo_candidate_semantics.py:182–191` validates the effect-row shape, carrier, and uniqueness. `photo_contracts.py:94–128` then uses exact equality, wildcard, and ancestor/descendant prefix overlap. It does not know synonyms, color coordinates, implications between siblings, endpoints, or layer identity.

Consequences for the candidate effect:

| Proposed effect | Parent color lock | Hue lock | Distribution lock | Spatial-gradient lock |
| --- | --- | --- | --- | --- |
| `wardrobe.color` | Reject | Reject | Reject | Reject |
| `wardrobe.color.distribution` | Reject | Allow | Reject | Allow |
| `wardrobe.color.spatial_gradient` | Reject | Allow | Allow | Reject |
| `wardrobe.color.distribution.spatial_gradient` | Reject | Allow | Reject | Allow |

“Allow” means only that this path is disjoint under the real guard. It is not proof that the final rendering preserves that property.

The two suggested direct descendants are therefore **not aliases**. A direct `spatial_gradient` effect would bypass an existing/requester-authored `distribution` sibling lock. A nested `distribution.spatial_gradient` design could make a distribution parent work, but would still not overlap the direct `spatial_gradient` spelling. A shared naming convention and scope definition must precede reliance on these alternatives. Selecting a spelling merely because one fixture locks its parent is not enough.

## Source-faithfulness and completeness

CT098 v2's ordinary meaning, concept unit, relation, and matching profile all say **a continuous color gradient fading along the fabric**. The original `wardrobe.surface.wash_distress_dye` effect remains necessary under any additive option.

### Distribution

`wardrobe.color.distribution` is a plausible property for the spatial allocation of garment color. CT098 necessarily establishes a nonuniform continuous spatial color field, so it affects that facet. It is more reusable than a value-specific name, but “distribution” needs a precise definition: spatial placement, proportions, transition arrangement, and region membership are not automatically the same property. There is no current wardrobe definition that settles the boundary.

### Spatial gradient

`wardrobe.color.spatial_gradient` tracks the CT098 source more closely and aligns with an existing named color relation. However, it can look like a selected state or effect type rather than a general variable. It does not, by itself, protect a sibling distribution/uniformity lock. The source names a gradient but does not define this proposed property hierarchy.

### Nested distribution / spatial gradient

`wardrobe.color.distribution.spatial_gradient` is a coherent possible future hierarchy if distribution is explicitly the parent property. It adds an extra convention, not evidence. It still does not express which color coordinates vary or resolve owner/garment/layer identity.

None of these names entails changing hue. Equally, none proves hue is invariant for every permitted realization of the current unrestricted source. A fading blue-to-paler-blue rendition can preserve hue; a blue-to-pale-violet rendition can change it. The definition does not choose fixed endpoints or a coordinate-preserving variant.

## Saturation, lightness, and combined locks

The independent matrix confirms that all three narrow options allow:

- `wardrobe.color.hue`
- `wardrobe.color.saturation`
- `wardrobe.color.lightness`
- All three of those locks together

The paths are prospective design probes, not claims that those exact wardrobe properties already exist in the corpus. Their intended coordinate meaning also requires a stated color model; the repository's “chroma” wording should not silently be treated as universally interchangeable with saturation.

A blue-hue-only request can be compatible with a lightness or saturation fade. A fixed-saturation request might permit an appropriate lightness change. But if a requester fixes hue, saturation, and lightness at every point in the same fabric field, a nontrivial intrinsic color gradient is incompatible under that stated coordinate interpretation. The narrow path alone would still mechanically admit it. This is a concrete completeness limit.

Blindly adding all three coordinate effects does not solve the original goal: the flat guard rejects when **any** effect overlaps, so a hue effect would again block hue-preserving gradients. The current source-effect list cannot encode “vary this coordinate or that one, depending on which realization the composer chooses.”

The existing interpretation contract does provide a relevant safeguard: `audit_composed_prompt.py:2980–2988` also checks the composer's declared actual effects. A truthful lightness-change declaration can therefore conflict with a lightness lock even if source metadata says distribution. This does not make incomplete source declarations self-validating. Semantic consistency remains agent-owned, and this design has not shown a complete composition that binds the selected gradient, its exact invariants, and honest realization-level effects. A narrow source facet could be useful with that discipline; it should not be advertised as proving coordinate safety at candidate eligibility time.

## Pattern and surface locks

Existing textile metadata uses separate paths such as `wardrobe.surface.check_patterns` and `wardrobe.surface.stripe_orientation`. All color options in the matrix, including the broad color parent, treat these as disjoint. A prospective `wardrobe.pattern` lock is also disjoint.

That is sometimes valid: a gradient can coexist with a retained check geometry or weave pattern. It is sometimes invalid: replacing an exact two-color check arrangement with a continuously changing color field can break the requested pattern meaning. A request preserving line placement alone is different from one preserving the pattern's color arrangement and two-color identity.

Do not infer that every gradient changes pattern geometry, and do not infer that a disjoint path proves every pattern survives. This needs requester-predicate and realization-level evidence. Adding a blanket pattern effect would create a different class of collateral rejection rather than settle the distinction.

## Owner, layer, and carrier ambiguity

Preserve `appearance / main_subject`; no source evidence here licenses global color closure, a background owner, skin effects, or a different carrier.

- Another explicit owner such as `secondary_subject` remains disjoint in the guard
- A parent color lock on `main_subject.lining` is rejected because the candidate's `main_subject` owner is its ancestor, even when only an outer panel would change
- If someone instead encodes lining color as `target=main_subject, property=wardrobe.color.lining`, a narrow `distribution` effect becomes a sibling and is allowed

These structurally valid but differently modeled locks show why a spelling change cannot establish layer-aware safety. The present CT098 source does not identify a particular garment, layer, panel, or gradient endpoint. Coarse-owner false rejections and incorrectly modeled sibling bypasses require a clear ownership convention and scoped evidence, not ad hoc aliases chosen to satisfy a test.

The ordinary CT098 candidate can be retrieved from background-gradient words. Its authored property owner nevertheless remains the main subject's wardrobe; background content cannot grant permission to modify that garment.

## Actual ordinary-route experiment

`ct098_design_probe.py` uses the real public `generate_candidate_pack` route, with the original uniform-blue fixture and a newly authored source-aware hue-only request that explicitly permits fabric lightness/saturation variation. The new request also puts a continuous fading gradient on the background wall. Both before/after pairs preserve identical normalized core/control bytes.

Only the exploratory `wardrobe.color.distribution` addition is public-build replayed; the other names are evaluated through the identical generic guard. No stored asset, profile, index, or runtime code is changed.

- **Original uniform-color fixture:** CT098 is retrieved and eligible before; it remains retrieved but becomes **ineligible / authored_property_scope** after
- **Independent blue-hue-only fixture:** CT098 is retrieved and eligible both before and after

This confirms real consumer reachability and the desired coarse distinction. It does **not** demonstrate that an admitted gradient realization actually preserves hue, lightness, saturation, or a pattern; no final composition was approved. The matching profile was not altered in this experiment, and no natural-profile or hard-profile repair is claimed. The previously reviewed profile evidence remains explicitly component-conditioned.

## Decision and next evidence needed

**Insufficient evidence to promote either new leaf as a complete CT098 metadata replacement.** The narrower facet is source-plausible and technically supported; the remaining issue is semantic coverage and stable naming, not inability of the current string hierarchy to represent a descendant.

Before reconsideration:

1. Define one property convention: what spatial distribution means, whether gradient is a child, how coordinate locks coexist, and where garment/layer identity belongs. Respect the existing pre-core authoring boundary; do not use retrieved project definitions to manufacture a compatible requester core
2. Decide whether the current source is an unrestricted gradient family requiring conservative effects, or whether reviewed coordinate-preserving variants and realization-level evidence will establish compatibility. A new variant would change source design and is outside this DATA-only review
3. Evaluate hue-only, saturation-only, lightness-only, combined-coordinate, parent uniform-color, and parent distribution requests. Include compatible and incompatible endpoint choices, with final declared effects and semantic review rather than eligibility booleans alone
4. Include geometric-pattern-only versus exact colored-pattern preservation, another garment/owner, outer panel versus lining, and background-only gradient controls
5. Exercise ordinary public projection and source-recomputed audits; qualify matching-profile routing separately. Refresh integrity bindings only after an actual reviewed design exists

The unchanged broad-color proposal remains **DEFER**, and CT091 remains independently decided. No provider calls, source edits, Git mutations, or promotion occurred.

## Evidence files

- `ct098-design-evidence.json`: vocabulary inventory, structural lock matrix, normalized request/control records, and public-build results
- `ct098-design-probe.log`: successful public-route outcomes
- `ct098_design_probe.py`: reproducible read-only exploration, writing only within this review directory

Run from the pinned repository: `PYTHONDONTWRITEBYTECODE=1 .venv/bin/python ../data-progress-48h-20261003/material-effect-audit/review/ct098_design_probe.py`
