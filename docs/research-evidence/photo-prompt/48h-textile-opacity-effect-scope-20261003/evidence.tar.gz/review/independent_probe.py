"""Read-only source review; independently authored, source-aware development fixtures.

Outputs stay in this review directory. No source/index/cache/provider writes.
"""
import copy
import hashlib
import json
import sys
from pathlib import Path
from unittest import mock

sys.dont_write_bytecode = True
ROOT = Path('/workspace/scratch/ce8f20680f5a/image-prompt')
ASSETS = ROOT / 'skills/photo-prompt-image-generator/assets'
HERE = Path(__file__).resolve().parent
sys.path[:0] = [str(ROOT), str(ASSETS.parent / 'scripts')]
import prompt_generator as pg
import photo_candidate_semantics as sem
import photo_contracts as contracts
import audit_composed_prompt as audit
from tests import photo_prompt_fixtures as fixtures

PROPOSALS = {'clt_ct091_v1': 'wardrobe.surface.sheer_opacity',
             'clt_ct091_v2': 'wardrobe.surface.sheer_opacity',
             'clt_ct098_v2': 'wardrobe.color'}

def create_core(cid):
    shape = {'clt_ct091_v1': 'crisp angular folds',
             'clt_ct091_v2': 'small fluid folds'}[cid]
    subject = 'an adult man wearing a completely opaque cape'
    event = 'the model holds both arms loosely at his sides'
    request = (f'Make a fashion product photograph of {subject}. '
               f'The cape has {shape}. Preserve opacity in every fabric panel; '
               f'{event} before a neutral gray studio backdrop.')
    baseline = (f'A fashion product photograph shows {subject} before a neutral gray studio backdrop. '
                f'The cape has {shape}, and {event}. '
                'Every cape panel remains completely opaque. Side illumination describes '
                'the folds without changing the fabric transmission. The cape occupies the '
                'center of the frame, with a clear edge against the quiet backdrop.')
    controls = pg.creative_controls.resolve(request,
        overrides={'sensual': 0, 'fetish': 0, 'surreal': 0, 'creativity': 1},
        context={'subject_category': 'human', 'no_people': False, 'explicit_nonsexual': False}, seed=17)
    raw = fixtures.core(request,
        interpreted_intent='A fashion product photograph documenting an opaque cape and its folds.',
        subject=subject, setting='a neutral gray studio backdrop', event=event,
        visual_priorities=(shape, 'every cape panel remains completely opaque'),
        baseline_prompt_en=baseline,
        open_dimensions=('appearance','material','color','lighting','composition','framing','camera','atmosphere'),
        anchor_evidence=(subject,event,shape))
    raw['creative_controls_sha256'] = controls['canonical_sha256']
    raw['intent_lock']['semantic_anchors'].append({
        'anchor_id':'cape_opacity','dimension':'appearance','target':'main_subject',
        'property':'wardrobe.surface.sheer_opacity','source_text':'completely opaque cape',
        'prompt_evidence':'completely opaque cape'})
    core = pg.normalize_authorial_core(raw,
        request_envelope=pg.normalize_request_envelope(fixtures.envelope(request)),
        creative_control_snapshot=controls)
    return core, controls

def locked(path=None, target='main_subject', dimension='appearance'):
    return {'contract_version':'photo-intent-lock/v2','open_dimensions':['appearance'],
            'semantic_anchors': [] if path is None else [
                {'dimension':dimension,'target':target,'property':path}]}

def main():
    data = pg.load_json(ASSETS / 'photo_prompt_tags.json')
    data[pg.QUALITY_LAYERS_DATA_KEY] = pg.load_quality_layers(ASSETS / 'photo_prompt_quality_layers.json')
    registry = pg.load_visual_obligation_registry(ASSETS / 'photo_prompt_visual_obligations.json')
    data[pg.VISUAL_OBLIGATIONS_DATA_KEY] = registry
    profiles = {p['id']:p for p in registry['profiles']}
    development = json.loads((HERE.parent / 'before-after-development-evidence.json').read_text())
    manifest = json.loads((HERE.parent / 'evidence-manifest.json').read_text())
    hash_checks = {name: hashlib.sha256((HERE.parent/name).read_bytes()).hexdigest()==row['sha256']
                   for name,row in manifest['files'].items()}
    sampled = json.loads((HERE.parent/'sampled-source-evidence.json').read_text())
    source_checks = {name: hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==sha
                     for name,sha in sampled['source_hashes'].items()}
    output = {'evidence_basis':'Independent reviewer, source-aware development; not blind holdout',
              'evidence_manifest_hashes_match':hash_checks,
              'recorded_source_hashes_match':source_checks,'routes':[],'controls':[]}
    for cid,path in PROPOSALS.items():
        entry = pg.candidate_pack_slot_entry_by_id(data,'surface_material',cid)
        after = copy.deepcopy(entry)
        after['affected_properties'].append({'dimension':'appearance','target':'main_subject','property':path})
        assert profiles[cid.replace('clt_','clothing_')]['concept_candidate']['affected_properties']==entry['affected_properties']
        controls = [(None,'main_subject','appearance'), (path,'main_subject','appearance'),
            (path,'secondary_subject','appearance'), (path,'main_subject','material'),
            ('wardrobe.color.hue','main_subject','appearance'),
            ('wardrobe.surface.sheer_opacity.lining','main_subject','appearance'),
            ('wardrobe.surface.sheer_opacity','main_subject.lining','appearance'),
            ('wardrobe.garment_type','main_subject','appearance')]
        output['controls'].append({'candidate':cid,'checks':[
            {'property':prop,'target':target,'carrier':dimension,
             'before':contracts.property_effects_allowed(locked(prop,target,dimension),entry['affected_dimensions'],entry['affected_properties']),
             'after':contracts.property_effects_allowed(locked(prop,target,dimension),after['affected_dimensions'],after['affected_properties'])}
            for prop,target,dimension in controls]})
        if cid=='clt_ct098_v2':
            continue
        core,snapshot = create_core(cid)
        # Replay the original fixture through the real public-pack projection,
        # rather than reconstructing a semantic candidate by hand.
        original = next(r for r in development if r['candidate']==cid)
        for fixture_label, frozen, control_snapshot in [
                ('independent_cape',core,snapshot),
                ('original_fixture_actual_row',original['core_before'],original['controls'])]:
            row = {'candidate':cid,'fixture':fixture_label,'core':frozen,'controls':control_snapshot,'arms':{}}
            for arm,source_entry in [('before',entry),('after',after)]:
                source=dict(data)
                source['slots']=dict(data['slots'])
                source['slots']['surface_material']=[source_entry if e['id']==cid else e for e in data['slots']['surface_material']]
                slots,binding,_=pg.retrieve_core_slots(source,frozen,control_snapshot)
                full_id='slot:surface_material:'+cid
                ordinary={c['id']:c for payload in slots.values() for c in payload['candidates']}
                chosen=ordinary.get(full_id)
                pack={'contract_version':'photo-candidate-pack/v6',
                    'candidate_semantic_surface_version':sem.SURFACE_VERSION,
                    'authorial_core':frozen,'creative_controls':control_snapshot,'slots':slots,
                    'core_retrieval':binding,'provenance':{'seed':17}}
                pack['candidate_bundles']=pg.candidate_pack_candidate_bundles(source,pack)
                natural=pg.candidate_pack_resolve_visual_profiles(
                    {**source,pg.VISUAL_OBLIGATIONS_DATA_KEY:registry},
                    {'provenance':{'authorial_core':frozen}},{},None)
                result={'retrieved':chosen is not None,
                    'source_guard_allowed':contracts.property_effects_allowed(frozen['intent_lock'],source_entry['affected_dimensions'],source_entry['affected_properties']),
                    'core_retrieval_audit':audit.audit_core_retrieval(pack,source),
                    'natural_matching_profile_hits':[h for h in natural['hits'] if h['profile_id']==cid.replace('clt_','clothing_')]}
                if chosen:
                    result['raw_row_has_semantic_surface']=chosen.get('semantic_surface_version') is not None
                if fixture_label=='original_fixture_actual_row':
                    current=pg.generate_candidate_pack(source,frozen,control_snapshot,
                        fixtures.review(frozen['baseline_prompt_en']),seed=17)
                    public_candidates={c['id']:c for payload in current['slots'].values() for c in payload['candidates']}
                    public_chosen=public_candidates.get(full_id)
                    result['public_candidate_retrieved']=public_chosen is not None
                    result['public_candidate_applicability']=public_chosen.get('applicability') if public_chosen else None
                    result['public_candidate_effects']=public_chosen.get('affected_properties') if public_chosen else None
                    result['public_semantic_surface']=public_chosen.get('semantic_surface_version') if public_chosen else None
                    evidence='The same cape includes '+source_entry['en']+'.'
                    prompt=frozen['baseline_prompt_en']+' '+evidence
                    original_loader=audit.candidate_semantics_generator.load_json
                    def loader(filename):
                        return copy.deepcopy(source) if Path(filename).name=='photo_prompt_tags.json' else original_loader(filename)
                    with mock.patch.object(audit.candidate_semantics_generator,'load_json',side_effect=loader):
                        result['public_selected_semantic_audit']=audit.audit_candidate_semantic_contracts(
                            current,prompt,{full_id},{full_id:public_chosen},[
                                {'candidate_id':full_id,'relation_evidence':{'visible_owner_relation':evidence}}])
                row['arms'][arm]=result
            output['routes'].append(row)
            print(cid,fixture_label,row['arms'],flush=True)
    assert all(hash_checks.values()) and all(source_checks.values())
    (HERE/'independent-probe-results.json').write_text(json.dumps(output,indent=2,ensure_ascii=False)+'\n')
    print('Evidence/source hashes verified; results written only in review directory.',flush=True)

if __name__=='__main__':
    main()
