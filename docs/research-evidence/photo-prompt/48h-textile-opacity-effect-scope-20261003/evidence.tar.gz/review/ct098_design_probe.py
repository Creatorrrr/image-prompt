"""Exploratory, read-only CT098 design; no accepted proposal or runtime patch."""
import copy
import hashlib
import json
import sys
from collections import defaultdict
from pathlib import Path
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
ROOT=Path('/workspace/scratch/ce8f20680f5a/image-prompt')
ASSETS=ROOT/'skills/photo-prompt-image-generator/assets'
sys.path[:0]=[str(ROOT),str(ASSETS.parent/'scripts')]
import prompt_generator as pg
import photo_contracts as contracts
from tests import photo_prompt_fixtures as fixtures

def lock(paths,target='main_subject',dimension='appearance'):
    return {'contract_version':'photo-intent-lock/v2','open_dimensions':['appearance'],
      'semantic_anchors':[{'dimension':dimension,'target':target,'property':p} for p in paths]}

def hue_core():
    subject='an adult woman wearing a blue fabric dress'
    event='the woman stands still beside the studio wall'
    request=(f'Make a fashion product photograph of {subject}. Keep the dress hue blue '
             f'while allowing fabric lightness and saturation to vary. A continuous gradient '
             f'fades along the background wall, and {event}.')
    baseline=(f'A fashion product photograph shows {subject}; {event}. '
              'The dress hue remains blue, with lightness and saturation free to vary across '
              'its fabric. A continuous gradient fades along the background wall. '
              'The fabric surface is clearly visible under soft neutral illumination, '
              'and the garment edge stays distinct from the studio wall behind her.')
    controls=pg.creative_controls.resolve(request,
        overrides={'sensual':0,'fetish':0,'surreal':0,'creativity':1},
        context={'subject_category':'human','no_people':False,'explicit_nonsexual':False},seed=23)
    raw=fixtures.core(request,interpreted_intent='A fashion product photograph preserves blue garment hue while leaving lightness and saturation variable.',
        subject=subject,setting='a plain gray studio wall',event=event,
        visual_priorities=('blue fabric dress','continuous gradient fading along the background wall'),
        baseline_prompt_en=baseline,
        open_dimensions=('appearance','material','color','lighting','composition','framing','camera','atmosphere'),
        anchor_evidence=(subject,event,'blue fabric dress'))
    raw['creative_controls_sha256']=controls['canonical_sha256']
    raw['intent_lock']['semantic_anchors'].append({'anchor_id':'dress_hue',
        'dimension':'appearance','target':'main_subject','property':'wardrobe.color.hue',
        'source_text':'Keep the dress hue blue','prompt_evidence':'The dress hue remains blue'})
    return pg.normalize_authorial_core(raw,
        request_envelope=pg.normalize_request_envelope(fixtures.envelope(request)),
        creative_control_snapshot=controls),controls

def main():
    vocab=defaultdict(list)
    scanned=[]
    def walk(node,filename,owner=None):
        if isinstance(node,list):
            for item in node:walk(item,filename,owner)
        elif isinstance(node,dict):
            owner=node.get('id',owner)
            path=node.get('property')
            if isinstance(path,str) and any(word in path for word in ('color','hue','saturation','lightness','pattern','print')):
                vocab[path].append({'file':filename,'record':owner,'dimension':node.get('dimension'),'target':node.get('target')})
            for item in node.values():walk(item,filename,owner)
    for file in sorted(ASSETS.glob('*.json')):
        if 'index' in file.name:continue
        scanned.append(file.name)
        walk(json.loads(file.read_text()),file.name)
    data=pg.load_json(ASSETS/'photo_prompt_tags.json')
    data[pg.QUALITY_LAYERS_DATA_KEY]=pg.load_quality_layers(ASSETS/'photo_prompt_quality_layers.json')
    data[pg.VISUAL_OBLIGATIONS_DATA_KEY]=pg.load_visual_obligation_registry(ASSETS/'photo_prompt_visual_obligations.json')
    entry=pg.candidate_pack_slot_entry_by_id(data,'surface_material','clt_ct098_v2')
    options=['wardrobe.color','wardrobe.color.distribution','wardrobe.color.spatial_gradient','wardrobe.color.distribution.spatial_gradient']
    tests=[[],['wardrobe'],['wardrobe.color'],['wardrobe.color.distribution'],
       ['wardrobe.color.spatial_gradient'],['wardrobe.color.hue'],['wardrobe.color.saturation'],
       ['wardrobe.color.lightness'],['wardrobe.color.hue','wardrobe.color.saturation','wardrobe.color.lightness'],
       ['wardrobe.pattern'],['wardrobe.surface.check_patterns'],['wardrobe.surface.stripe_orientation'],
       ['wardrobe.color.lining'],['wardrobe.color.distribution.lining']]
    matrix=[]
    for option in options:
        effects=entry['affected_properties']+[{'dimension':'appearance','target':'main_subject','property':option}]
        matrix.append({'exploratory_option':option,'checks':[
            {'locks':paths,'allowed':contracts.property_effects_allowed(lock(paths),entry['affected_dimensions'],effects)}
            for paths in tests],
            'other_owner_parent_lock_allowed':contracts.property_effects_allowed(lock(['wardrobe.color'],'secondary_subject'),entry['affected_dimensions'],effects),
            'other_carrier_parent_lock_allowed':contracts.property_effects_allowed(lock(['wardrobe.color'],'main_subject','material'),entry['affected_dimensions'],effects),
            'child_lining_owner_parent_lock_allowed':contracts.property_effects_allowed(lock(['wardrobe.color'],'main_subject.lining'),entry['affected_dimensions'],effects)})
    original=next(r for r in json.loads((HERE.parent/'before-after-development-evidence.json').read_text()) if r['candidate']=='clt_ct098_v2')
    new_core,new_controls=hue_core()
    results=[]
    for name,core,controls in [('original_uniform_color',original['core_before'],original['controls']),('independent_hue_only',new_core,new_controls)]:
        result={'fixture':name,'core':core,'controls':controls,'arms':{}}
        for option in [None,'wardrobe.color.distribution']:
            changed=copy.deepcopy(entry)
            if option:changed['affected_properties'].append({'dimension':'appearance','target':'main_subject','property':option})
            source=dict(data);source['slots']=dict(data['slots'])
            source['slots']['surface_material']=[changed if e['id']==entry['id'] else e for e in data['slots']['surface_material']]
            pack=pg.generate_candidate_pack(source,core,controls,fixtures.review(core['baseline_prompt_en']),seed=23)
            chosen=next((c for payload in pack['slots'].values() for c in payload['candidates'] if c['id']=='slot:surface_material:clt_ct098_v2'),None)
            result['arms'][option or 'current']={'retrieved':chosen is not None,
                'applicability':chosen.get('applicability') if chosen else None,
                'effects':chosen.get('affected_properties') if chosen else None,
                'source_guard_allowed':contracts.property_effects_allowed(core['intent_lock'],changed['affected_dimensions'],changed['affected_properties'])}
        results.append(result)
        print(name,result['arms'],flush=True)
    output={'status':'design_exploration_only_no_promotion','authored_top_level_json_files_scanned':scanned,
       'existing_relevant_effect_vocabulary':dict(vocab),'structural_matrix':matrix,
       'public_build_reachability':results,'limitations':[
         'New coordinate and distribution lock paths are design probes, not existing canonical wardrobe effect vocabulary.',
         'Only distribution is public-build replayed; other names use the same unaliased hierarchy consumer.',
         'Each replay changes one ordinary record in memory; matching profile and on-disk sources stay unchanged.',
         'No full composed audit, indexed runtime, provider, or rendered-image claim.']}
    (HERE/'ct098-design-evidence.json').write_text(json.dumps(output,ensure_ascii=False,indent=2)+'\n')

if __name__=='__main__':main()
