# Independent review: textile property-effect proposal

## Frozen decision

Reviewed source HEAD: `7e769e3e4a0da7068723830bb0c5c5c2dfd784c8`.

- **KEEP CT091 v1**: append `appearance / main_subject / wardrobe.surface.sheer_opacity` to `clt_ct091_v1` and the matching `clothing_ct091_v1.concept_candidate` declaration
- **KEEP CT091 v2**: append the same entry to `clt_ct091_v2` and `clothing_ct091_v2.concept_candidate`
- **DEFER CT098 v2**: do not promote the proposed `wardrobe.color` addition to either `clt_ct098_v2` or `clothing_ct098_v2` in this change

KEEP means retain the narrowly specified DATA proposal for acceptance testing. It does not authorize editing the pinned repository, certify every layered-garment case, or claim that the proposed source has passed the full regression. The accepted conceptual subset is four records, with one additive effect per record. Preserve existing effects, dimensions, target, semantic text, aliases, gates, weights, and activation behavior.

This review used independent source inspection and independently authored **source-aware development** requests, plus explicitly labeled replay of the original author's requests. It is not a blind holdout. I did not inspect the original author's subsequent controls requested by the coordinator.

## Why CT091 is a faithful addition

The ordinary definitions are explicit, not merely material-family associations:

- `photo_prompt_textile_surface_extension.json:993–1031`: “a crisp sheer panel holding angular folds”
- The next record at `1033–1071`: “a soft translucent panel falling in small fluid folds”

The concept units and directed visible-owner relations repeat these meanings. The matching profiles at `photo_prompt_visual_obligations_textile_surface.json:2254` and `2345` retain the same meanings in their definitions, components, and native render gates. Both ordinary and profile effects currently mention only `wardrobe.surface.chiffon_organza_taffeta`.

CT079 v1/v2 at ordinary-source lines `47–128` already establish the exact `wardrobe.surface.sheer_opacity` property for a sheer outer panel versus an opaque panel. Adding that same path to the explicitly sheer/translucent CT091 meanings is supported by the source itself. No inference about fiber chemistry, wearer identity, visible skin, body exposure, or a mandatory underlayer is needed or justified.

The existing carrier and owner are retained. This is not a reason to close appearance or material globally, to add a color effect, or to change target to `*`.

## Why CT098 should be deferred

`clt_ct098_v2` at ordinary-source line `1519` requires a continuous fading color gradient along fabric. The existing `wardrobe.surface.wash_distress_dye` declaration does not overlap a uniform-color lock. The original uniform-blue-dress counterexample therefore identifies a real DATA discrepancy.

But the proposed fix uses the broad color parent. The actual path-overlap algorithm makes an effect on `wardrobe.color` incompatible with a `wardrobe.color.hue` lock. A continuously fading blue fabric gradient can vary lightness or saturation while retaining hue; the authored definition does not entail changing hue. This is a concrete compatible realization that the parent effect cannot distinguish. The independent structural probe confirms allowed → disallowed under the hue-only child lock.

This is a representable property-lock case, not a claim that the repository has a closed canonical hue taxonomy. `SKILL.md:247–249` permits stable object/property paths and explicitly gives parents authority over children. Do not invent a new “distribution” property solely to make this example pass. CT098 needs a separately reviewed property-granularity decision and hue-preserving versus uniform-color fixtures before promotion. Deferral leaves the uniform-color omission unresolved; it is not a KEEP verdict on its current completeness.

## Verified real consumer behavior

1. `photo_candidate_semantics.py:220–235` preserves authored property declarations
2. `photo_contracts.py:94–128` tests target/path equality and ancestor/descendant overlap across carrier dimensions; the current family properties are siblings of the missing opacity/color properties
3. `prompt_generator.py:2303–2308` filters assertion discovery by these declared effects
4. `retrieve_core_slots:11435–11548` also has broad/focal advisory ranking, which can retain an ID even when assertion discovery rejects it
5. **Important omitted boundary in the original report:** `build_candidate_pack:10392–10412` attaches source semantics and explicitly changes a retained candidate to `applicability.status = ineligible`, with source `authored_property_scope`, when the source effect overlaps a protected property
6. Public v6 composition applies those semantics through `candidate_pack_compose_current` and `apply_public_semantics`
7. `audit_candidate_semantic_contracts:2848–2862` reloads the source and rejects a selected ordinary candidate whose trusted effects overlap the lock

The original report's limited claim about raw retrieval is correct. It should add the public eligibility boundary so readers do not equate “still retrieved” with “still eligible.” Its manually constructed semantic candidate proves the narrow source-recomputed audit transition, but does not by itself prove the public-pack transition. The independent public-build replay below supplies that missing check.

### Independent evidence

See `independent-probe-results.json` and `independent-probe.log` in this review directory. The script uses the real full-corpus ordinary retriever, real public `generate_candidate_pack`, and real source-recomputed selected semantic auditor. Proposed ordinary metadata exists only in memory, one CT091 record at a time, to isolate each record's causal effect. This is not a replay of the complete four-record promotion bundle and does not validate regenerated indexes.

| Fixture | Before | After |
| --- | --- | --- |
| Independently authored opaque cape with crisp angular folds, CT091 v1 | Retrieved; source guard permits | Not retrieved; source guard rejects |
| Independently authored opaque cape with small fluid folds, CT091 v2 | Retrieved; source guard permits | Not retrieved; source guard rejects |
| Original crisp opaque dress, actual public v6 candidate | Retrieved, eligible; selected semantic audit passes | Retrieved, **ineligible** by authored property scope; selected semantic audit returns exactly one property-lock failure |
| Original fluid opaque dress, actual public v6 candidate | Retrieved, eligible; selected semantic audit passes | Retrieved, **ineligible** by authored property scope; selected semantic audit returns exactly one property-lock failure |

Core-retrieval source recomputation passes in both arms of all four fixtures. Each before/after pair uses the same normalized core and controls. No matching natural profile hit appears in either arm. The deliberately inconsistent selected-evidence clause is only a mechanical audit probe, not an endorsed composition or a full prompt pass.

The original profile test uses a narrowed registry and a separate component-complete advisory input to the real resolver. It establishes the optional-profile effect filter's behavior after admission. It does **not** establish that opaque/solid requests naturally retrieve the matching profile, or that the hard-profile route was repaired. That qualification in the original report is appropriate and must remain.

### Controls confirmed

- No property lock remains allowed
- Exact opacity locks reject the CT091 addition
- The same opacity property on `secondary_subject` remains allowed
- The same semantic lock under the `material` carrier still rejects, preventing carrier bypass
- Garment-type and hue-only locks remain disjoint from the CT091 addition
- CT098's proposed color parent rejects a hue-only child lock
- A lining child target or a lining child property is also rejected by the CT091 parent owner/property effect

The lining paths are illustrative structural probes of the supported hierarchy, not proposed new canonical source metadata. These tests do not establish layer-aware semantic routing.

## Residual limitations and missing controls

1. **Fabric transmission and garment coverage are different.** A sheer outer panel over an opaque lining does not imply visible skin. A promise that the completed outfit conceals the body is insufficient evidence for locking every panel's transmission. Request interpretation must preserve the actual predicate.
2. **Owner and panel granularity remain coarse.** `main_subject` plus a parent wardrobe-opacity property cannot distinguish an affected outer panel from an independently protected lining under the same owner. The structural probes expose this conservative false-rejection risk; it must not be reported as evidence of no collateral. Do not solve it by widening targets or closing dimensions.
3. **Consistent baseline retention needs a separate control.** A requester who already requires sheer cloth should retain it without being forced to adopt a new optional augmentation. The generic selected-source guard still rejects a selected ordinary candidate that overlaps a lock even if the value would be semantically consistent. “An unchanged baseline needs no new selection” is the correct distinction, but a full public baseline-preservation case is not supplied by my isolated scope probes.
4. **The two CT091 records were isolated individually.** The final four-record ordinary/profile bundle must be tested together with source-bound derived metadata. Matching-profile parity and conditioned filtering are evidence for the profile additions, not a substitute for that bundle check.
5. **No full composition, runtime, provider, or pixel result.** Public pack generation and one selected semantic consumer are verified. Neither this review nor the author's original probe proves that a contradictory final prompt passes every composition audit. The existing maintenance receipts describe authored geometry and family-context evidence; native pixels and user acceptance remain untested.
6. **No untouched-source regression is an after-patch regression.** The coordinator's full run on the pinned source is useful baseline evidence, but cannot qualify changed DATA and derived hashes by itself.

## Minimum acceptance evidence before production promotion

1. Freeze a CT091-only delta containing exactly the two ordinary and two matching-profile effect additions. Verify no semantic text, existing effect, owner, dimension, gate, alias, or weight changed
2. Run the final four-record bundle through the real public build. For each ordinary record, retain at least one opaque **same-panel/all-panels** fixture showing before eligibility and after rejection or ineligibility. Keep source-recomputed selected audit evidence for a retained broad/focal candidate
3. Add independently authored/source-unexposed controls for open opacity, other-owner preservation, unrelated property preservation, already-required sheer/translucent baseline retention, and sheer outer fabric over an opaque lining. Bind each lock to the actual requester predicate. Report coarse-layer false rejections explicitly rather than rewording requests or silently remapping owners to obtain a pass
4. Test matched profile parity and optional filtering with the input stage clearly labeled. Test any natural profile route only if a request genuinely reaches it; do not synthesize component evidence and call that a natural hit
5. Refresh required receipts and derived bindings using the supported workflow, then run affected integrity checks and focused source regressions against the actual changed artifact. Preserve the existing full-suite source/run relationship
6. Keep CT098 and the other deferred color-overlap families outside this delta. Revisit CT098 only with explicit uniform-color-versus-hue-only acceptance criteria and a separately justified granularity design

## Reproducibility and integrity

Run from the pinned repository with bytecode disabled:

`PYTHONDONTWRITEBYTECODE=1 .venv/bin/python ../data-progress-48h-20261003/material-effect-audit/review/independent_probe.py`

All 11 original evidence-manifest hashes and all seven recorded source-file hashes matched when this review's successful probe began. The seven source hashes were checked again after report preparation and still matched. The repository remained read-only; no Git mutations, providers, regenerated indexes, or large source copies were used. Only small review artifacts were written outside the repository.

Two exploratory artifacts are retained for transparency: an initial independently authored fixture failed the concrete-setting minimum and was corrected; an initial raw-retrieval-row audit was nonprobative because those rows precede v6 semantic projection. `raw-preprojection-probe*` must not be counted as semantic-audit pass evidence. The successful public-build result is `independent-probe-results.json`.
