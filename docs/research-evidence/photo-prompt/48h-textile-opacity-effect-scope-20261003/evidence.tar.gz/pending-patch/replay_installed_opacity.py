from pathlib import Path
import json,gzip,copy,sys,hashlib,datetime
P=Path(__file__).resolve().parents[2];R=P.parent/'image-prompt';F=P/'material-effect-audit/fresh-control-evaluation';O=P/'material-effect-audit/production-integration/replays';O.mkdir(parents=True,exist_ok=True)
sys.path[:0]=[str(R),str(R/'skills/photo-prompt-image-generator/scripts')];import prompt_generator as pg;import audit_composed_prompt as auditor

def forbidden(*a,**kw):raise AssertionError('No provider calls allowed')
pg.embed_texts_with_gemini=forbidden
data=pg.load_runtime_data();results=[]
for f in sorted(F.rglob('after_opacity_only-public-pack.json.gz')):
 rel=f.parent.relative_to(F);expected=json.loads(gzip.decompress(f.read_bytes()));cp=f.parent/'input-controls.json'
 if cp.exists():controls=json.loads(cp.read_text())
 else:controls=json.loads((f.parent/'unchanged-source-guided-input.json').read_text())['controls']
 assert controls==expected['creative_controls'];core=expected['authorial_core'];review=expected['embodiment_preflight']['baseline_review'];actual=pg.generate_candidate_pack(data,core,controls,review,seed=7)
 dest=O/rel;dest.mkdir(parents=True,exist_ok=True);(dest/'public-pack.json').write_text(json.dumps(actual,ensure_ascii=False,indent=2)+'\n');same=actual==expected
 saved=json.loads((f.parent/'after_opacity_only-baseline-no-adoption-serialization-recovery.json').read_text());composed=copy.deepcopy(saved['composition']);assert composed['prompt_en']==core['baseline_prompt_en'];audit=auditor.audit_composed_prompt(actual,composed);(dest/'audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n')
 result={'case':str(rel),'matches_qualified_after_values':same,'pack_id':actual['pack_id'],'expected_pack_id':expected['pack_id'],'audit_failure_checks':[x.get('check')for x in audit.get('failures',[])],'baseline_unchanged':actual['authorial_core']['baseline_prompt_en']==core['baseline_prompt_en']};results.append(result);print(result,flush=True);(O/'results.json').write_text(json.dumps(results,indent=2)+'\n')
assert len(results)==11;assert all(x['matches_qualified_after_values']and not x['audit_failure_checks']and x['baseline_unchanged']for x in results)
print('Installed-source public build and retention audit:11/11 match/pass; no mocked source or index.')
