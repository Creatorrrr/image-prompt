from pathlib import Path
import json,sys,hashlib,datetime,subprocess,copy,shutil
P=Path(__file__).resolve().parents[2];R=P.parent/'image-prompt';A=R/'skills/photo-prompt-image-generator/assets';O=P/'material-effect-audit/production-integration';O.mkdir(exist_ok=True)
assert not subprocess.check_output(['git','status','--short'],cwd=R,text=True).strip(),'Require clean integration baseline'
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
sys.path.insert(0,str(A.parent/'scripts'));import prompt_generator as pg;import photo_candidate_semantics as cs;import build_semantic_index as si;import build_visual_profile_index as vi

def forbidden(*a,**kw):raise AssertionError('No provider calls allowed in this metadata-only integration')
pg.embed_texts_with_gemini=si.embed_texts_with_gemini=vi.embed_texts_with_gemini=forbidden
olddata=pg.load_runtime_data();oldvp=olddata[pg.VISUAL_PROFILE_INDEX_DATA_KEY];oldsi=pg.load_semantic_index_payload(A/'photo_prompt_semantic_index.json')
names=['photo_prompt_textile_surface_extension.json','photo_prompt_visual_obligations_textile_surface.json'];ext,vis=[json.loads((A/n).read_text())for n in names];oldext,oldvis=copy.deepcopy(ext),copy.deepcopy(vis)
for n in names:(O/('before-'+n)).write_bytes((A/n).read_bytes())
ops=json.loads((P/'material-effect-audit/fresh-control-evaluation/opacity-only-proposal.json').read_text())
# The integration is explicitly four source records, independent of the draft serialization shape.
ids=['clt_ct091_v1','clt_ct091_v2'];effect={'dimension':'appearance','target':'main_subject','property':'wardrobe.surface.sheer_opacity'}
for cid in ids:
 row=next(x for x in ext['slots']['surface_material']if x['id']==cid)
 assert row['affected_properties']==[{'dimension':'appearance','target':'main_subject','property':'wardrobe.surface.chiffon_organza_taffeta'}]
 row['affected_properties'].append(copy.deepcopy(effect))
 pid=cid.replace('clt_','clothing_',1);profile=next(x for x in vis['profiles']if x['id']==pid)
 assert profile['concept_candidate']['affected_properties']==oldext['slots']['surface_material'][ext['slots']['surface_material'].index(row)]['affected_properties']
 profile['concept_candidate']['affected_properties'].append(copy.deepcopy(effect))
# No semantic/alias/gate or unrelated record changes are permitted.
check=copy.deepcopy(ext)
for cid in ids:next(x for x in check['slots']['surface_material']if x['id']==cid)['affected_properties'].remove(effect)
assert check==oldext
check=copy.deepcopy(vis)
for cid in ids:next(x for x in check['profiles']if x['id']==cid.replace('clt_','clothing_',1))['concept_candidate']['affected_properties'].remove(effect)
assert check==oldvis
prior=copy.deepcopy(ext['maintenance_ref']);without=copy.deepcopy(ext);without.pop('maintenance_ref')
record={'contract_version':'photo-extension-maintenance-record/v1','record_id':'48h-textile-opacity-effect-scope-20261003','maintenance_only':True,'previous_reference':prior,'source_without_reference_sha256':cs.digest(without),'change_kind':'source_supported_property_effect_union','changed_candidate_ids':ids,'changed_profile_ids':[x.replace('clt_','clothing_',1)for x in ids],'added_property':effect,'original_effects_preserved':True,'visual_text_aliases_and_gates_unchanged':True,'new_provider_calls':0,'limits':['Canonical opacity path only; alternative authored paths are not aliases.','Same-owner/layer hierarchy can conservatively reject compatible lining-only changes.','Fresh independent requests have no natural target exposure; source-guided product counterexamples establish the guard correction.','No rendered-quality or general opacity-protection claim.']}
recordpath=R/'docs/research-evidence/photo-prompt/extension-maintenance'/f"{record['record_id']}.json";assert not recordpath.exists();ext['maintenance_ref']={'contract_version':'photo-extension-maintenance-ref/v1','record_id':record['record_id'],'sha256':cs.digest(record)}
recordpath.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
for name,value in zip(names,[ext,vis]):(A/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
reg=pg.load_visual_obligation_registry(A/'photo_prompt_visual_obligations.json');vectors=vi.reusable_vectors([A/'photo_prompt_visual_profile_index.json'],reg,provider=pg.SEMANTIC_PROVIDER,model=pg.SEMANTIC_MODEL_ID,dimensions=pg.DEFAULT_SEMANTIC_DIMENSIONS);assert len(vectors)==len(reg['profiles'])==1622
vp=pg.build_visual_profile_index_payload(reg,vectors=vectors)
for key in ('entries','exact_lookup','bm25f'):assert vp[key]==oldvp[key],key
vi.write_payload(A/'photo_prompt_visual_profile_index.json',vp)
data=pg.load_json(A/'photo_prompt_tags.json');data[pg.QUALITY_LAYERS_DATA_KEY]=pg.load_quality_layers(A/pg.QUALITY_LAYERS_FILENAME)
sp=si.build_resumable_index_payload(data,A/'photo_prompt_semantic_index.json',O/'empty-checkpoint.json',pg.SEMANTIC_PROVIDER,pg.SEMANTIC_MODEL_ID,pg.DEFAULT_SEMANTIC_DIMENSIONS,64,0,0,0,cache_indexes=[A/'photo_prompt_semantic_index.json'])
for key in ('entries','bm25f'):assert sp[key]==oldsi[key],key
assert len(sp['entries'])==9876;si.write_sharded_payload(A/'photo_prompt_semantic_index.json',sp,keep_stale_generations=True)
shutil.copyfile(Path(__file__).parent/'test_photo_textile_opacity_effect_scope.py',R/'tests/test_photo_textile_opacity_effect_scope.py')
newdata=pg.load_runtime_data();assert newdata[pg.SEMANTIC_INDEX_DATA_KEY]['entries']==oldsi['entries'];assert newdata[pg.VISUAL_PROFILE_INDEX_DATA_KEY]['entries']==oldvp['entries'];assert pg.dictionary_hash(newdata)==sp['dictionary_hash']
result={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'baseline_commit':head,'changed_ordinary_records':2,'changed_visual_records':2,'concepts':2,'provider_calls':0,'visual_entry_count':1622,'general_entry_count':9876,'all_vectors_texts_bm25f_exact_lookup_unchanged':True,'registry_before':oldvp['registry_sha256'],'registry_after':vp['registry_sha256'],'dictionary_before':oldsi['dictionary_hash'],'dictionary_after':sp['dictionary_hash'],'source_fields_only':'four additive effect entries plus current immutable maintenance linkage','maintenance_record':str(recordpath.relative_to(R))};(O/'application.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
