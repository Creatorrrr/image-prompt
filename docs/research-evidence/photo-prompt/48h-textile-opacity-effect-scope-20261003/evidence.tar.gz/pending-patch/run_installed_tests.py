from pathlib import Path
import subprocess,json,time,os
P=Path(__file__).resolve().parents[2];R=P.parent/'image-prompt';O=P/'material-effect-audit/production-integration/tests';O.mkdir(parents=True,exist_ok=True);results=[]
E={k:v for k,v in os.environ.items()if not any(t in k.upper()for t in ['TOKEN','API_KEY','CREDENTIAL'])};E['PYTHONDONTWRITEBYTECODE']='1'
names=['test_photo_textile_opacity_effect_scope.py','test_photo_texture_data_cleanup.py','test_photo_clothing_terminology_semantics.py','test_photo_candidate_semantics.py','test_photo_core_retrieval.py','test_photo_visual_profile_retrieval.py','test_photo_composer_view.py','test_photo_semantic_index.py','test_photo_nape_effect_scope.py']
for name in names:
 t=time.monotonic();r=subprocess.run([str(R/'.venv/bin/python'),'-m','unittest','discover','-s','tests','-p',name],cwd=R,env=E,capture_output=True,text=True,timeout=600);(O/(name+'.log')).write_text(r.stdout+r.stderr);results.append({'file':name,'returncode':r.returncode,'seconds':round(time.monotonic()-t,3)});(O/'results.json').write_text(json.dumps(results,indent=2)+'\n');print(name,r.returncode,flush=True)
r=subprocess.run([str(R/'.venv/bin/python'),'skills/photo-prompt-image-generator/scripts/validate_photo_prompt_dictionary.py'],cwd=R,env=E,capture_output=True,text=True,timeout=180);(O/'dictionary-validation.log').write_text(r.stdout+r.stderr);results.append({'file':'dictionary-validation','returncode':r.returncode});(O/'results.json').write_text(json.dumps(results,indent=2)+'\n');print('dictionary-validation',r.returncode,flush=True)
