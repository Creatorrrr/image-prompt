# Independent review: capture-physics DATA repairs

## Decision

Approve the physical direction, but **do not adopt the submitted proposal unchanged**. Adopt the exact reviewed proposal for subsequent full-CLI and composed-prompt verification. No repository files were edited by this review.

Reviewed against original Git source `57e29730f0b5c2df336fd1e9dd58374b2025ee03`, whose registry bytes exactly match the frozen snapshot. Deliverables:
- `reviewed-profiles.json`: complete recommended source profiles
- `reviewed-field-proposal.json`: exact old/new changes relative to original Git source
- `review-validation.json`: measured old/new compatibility, real token counts, exclusions and missing-component controls
- `review.py`: reproducible read-only source review, writing only these review artifacts

## Blocking finding in submitted proposal: lost valid subtypes

The original full component phrases in both English and Korean return `component_semantics` under the real original consumer and `None` under the proposed consumer, for **both** profiles. This is a real lexical compatibility regression, not a physical objection to the new alternatives.

Literal evidence also loses these previously valid anchors:
1. `normally vertical repeated structures lean or bend consistently in one direction`
2. `the fast-moving subject shears across its height or width instead of remaining rigid`
3. `two separated sharp zones with a softer intervening band`

Replacing the last phrase with a longer phrase ending in `or restrained optical transition` does not preserve the original phrase as an accepted anchor. The consumer requires the complete declared anchor as a literal substring of the evidence. An old band-only binding cannot contain the longer new anchor. The static test of newly authored component phrases did not test this backward direction.

Recommended repair: retain the original phrases as additional `any_terms` / `match_terms` / evidence alternatives, while keeping the repaired general instructions and gates. The old rolling language remains a valid combined-motion subtype, not a universal obligation. Old split middle-band language remains a valid band-only subtype. The reviewed proposal restores all original evidence anchors and full old EN/KO component matching without lowering any threshold.

## Physical meaning and ownership

Rolling repair is justified. Basler explicitly distinguishes simultaneous global exposure followed by row-by-row readout from temporally offset row exposures; it attributes rolling distortion to fast object or camera motion. Thus staggered row exposure is the relevant cause, not serial readout alone. A fixed camera does not impart image motion to stationary scenery; this last statement is geometric inference from the timing model, not a vendor quote. Different objects may have different relative image velocities and opposite shear signs despite sharing the same sensor timing axis.

Primary source read during review: https://docs.baslerweb.com/electronic-shutter-types#rolling-shutter

The proposed general `scene structures` requirement risks retaining a second scenery object merely to keep five groups. The reviewed wording instead addresses **present scene geometry**, and makes stationary background structures conditional on their presence. It does not require inserting posts, a building, or any separate background object. Five groups can remain because they describe distinct requirements: progressive row-time displacement, correct ownership of deformation, recognizable visible shear, locally crisp detail, and substitute rejection. Group count is not a physical premise. Keeping the same IDs is compatibility bookkeeping, not evidence of five independent physical effects.

The subject shear group now permits a stationary structure displaced in the image by camera motion. The fixed-camera moving object, camera-sweep static scene, and valid combined-motion subtype are coherent under the same general gate. The old unconditional rejection of one bent object was correctly narrowed to arbitrary bending lacking motion-related shear. Nothing here expands the profile into banding, segmented propellers, or every rolling-shutter artifact.

Split repair is justified by the profile's existing definition and evidence terms. An optical transition is an image-space boundary and does not require an object at intermediate scene depth. Schneider's fact sheet describes foreground through the semicircular diopter and background through the uncovered area, yielding two focus areas; it does not assert that every valid split-diopter image must reveal a softened middle-depth band.

Primary source read during review: https://schneiderkreuznach.com/application/files/5717/0142/0920/Fact_Sheet_Diopter_Split_GEN2_Schneider-Kreuznach.pdf

The reviewed proposal retains this intentionally narrow visible signature: very-near and distant sharp anchors, either a soft intervening band or soft optical transition, continuous scene cues, and no substitute composite. A completely hidden seam with no soft transition remains outside this repair. The process/equipment claim limit stays unchanged.

## Gate and evidence alignment

The general rolling geometry anchor, instruction, concept term, and gate agree on each form's relative image motion. The two restored old evidence alternatives describe legitimate narrower cases. The unchanged boundary's shared readout direction means the common timing axis; it must not be interpreted as identical displacement direction or magnitude across all objects.

The split middle component already has the band-or-transition match/evidence alternative. Repairing its instruction and render gate plus the boundary component makes those same alternatives consistent. Retaining the old band-only boundary avoids the lexical regression.

The matcher is lexical; it does not prove that a clause containing `stable or shear` chooses the correct branch. Real authored bindings should append scene-specific ownership and the actual visible effect. The current DATA repair can support that without pretending the lexical matcher computes physics.

## Exact token-floor findings

Counts are **distinct ASCII content tokens** from the actual `authorial_evidence_tokens`, not whitespace counts; repeated tokens and stopwords do not help. EN evidence is required even though semantic component matching also supports Korean.

Rolling revised anchors, count/minimum:
- readout: 8/9, needs at least 1 additional distinct concrete token
- new geometry: 12/10
- old structure alternative: 9/10, needs at least 1 additional distinct concrete token
- new subject/camera form: 13/12
- old subject alternative: 10/12, needs at least 2 additional distinct concrete tokens
- crisp detail: 11/12, needs at least 1 additional distinct concrete token
- boundary: 14/17, needs at least 3 additional distinct concrete tokens

Split anchors, count/minimum: near 7/5 and 5/5; far 9/6 and 7/6; middle 9/6 and 6/6; continuity 10/6 and 7/6; boundary 15/6, 10/6, and restored old 7/6. All clear their floors.

Do not lower rolling floors or pad with meaningless filler. Concrete scene nouns and properties can supply the existing shortfall; test the actual complete binding. This review tested the real token function and anchor predicate, **not** a complete composed-prompt audit result.

## Verified and remaining

Verified independently:
- original Git/snapshot registry byte identity
- submitted proposal's old EN/KO component regression reproduced
- reviewed proposal accepts old and new full EN/KO component texts
- removal of each new component blocks component matching
- affirmative activation exclusions still block
- all original evidence anchors accepted by reviewed contracts
- activation, labels, required fields, gate IDs/scales and evidence floors unchanged
- no new self-exclusion in complete new EN/KO component controls

The supplied six normal-CLI BEFORE cases and clean snapshot are the appropriate baseline. This review did not rerun those six or produce a full-index AFTER. Next: apply selected reviewed DATA, regenerate the actual index through the standard project path, replay all 24 immutable input files, compare whole packs and unaffected candidate identities/order/counts, and audit complete scene-specific literal bindings through the full composed-prompt consumer. Include a single moving form without extra scenery and combined camera/object motion with distinct or opposite relative velocities as ownership controls where feasible.

## Runtime boundary

No runtime code is needed merely to express these alternatives consistently in DATA. Runtime work is required if the acceptance criterion is automatic branch classification, branch-specific gate removal, verification of camera versus subject motion, calculation of shear sign/magnitude, or rejection of physically inconsistent geometry based only on the lexical evidence. Do not claim the static tests establish those capabilities. The reviewed DATA still relies on authored scene specificity and semantic/pixel review for causal correctness.
