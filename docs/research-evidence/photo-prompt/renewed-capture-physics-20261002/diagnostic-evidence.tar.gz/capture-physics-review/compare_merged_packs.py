import json,hashlib
from pathlib import Path
O=Path(__file__).resolve().parent;D=O/'binding-controls';B=O/'binding-controls-before-merged';A=O.parent/'capture-physics-audit/public-cli'
def diff(a,b,p=''):
 if type(a)!=type(b):return [{'path':p,'before':a,'after':b}]
 if isinstance(a,dict):
  out=[]
  for k in sorted(set(a)|set(b)):
   if k not in a or k not in b:out.append({'path':p+'/'+k,'before':a.get(k),'after':b.get(k)})
   else:out+=diff(a[k],b[k],p+'/'+k)
  return out
 if isinstance(a,list):
  if len(a)!=len(b):return [{'path':p,'before':a,'after':b}]
  return sum((diff(x,y,p+'/'+str(i)) for i,(x,y) in enumerate(zip(a,b))),[])
 return [] if a==b else [{'path':p,'before':a,'after':b}]
def all_ids(x,path=''):
 if isinstance(x,dict):
  out=[(path+'/id',x['id'])] if 'id' in x else []
  return out+sum((all_ids(v,path+'/'+k) for k,v in x.items()),[])
 if isinstance(x,list):return sum((all_ids(v,path+'/'+str(i)) for i,v in enumerate(x)),[])
 return []
rows=[]
for case in ['fixed-camera','camera-sweep','single-object','combined-opposite-velocities','rolling-combined-control','split-middle-control','split-optical-transition']:
 extra=case in ['single-object','combined-opposite-velocities'];before=(B/'packs' if extra else A/'after-final')/(case+'-pack.json');after=(D/'packs' if extra else A/'after-merged')/(case+'-pack.json')
 if not after.exists():print('WAIT',case);continue
 old=json.loads(before.read_text())[0];new=json.loads(after.read_text())[0];changes=diff(old,new)
 inputs_unchanged=None
 if extra:inputs_unchanged=all(f.read_bytes()==(B/'inputs'/case/f.name).read_bytes() for f in (D/'inputs'/case).glob('*.json'));assert inputs_unchanged
 row={'case':case,'before_path':str(before),'after_path':str(after),'before_sha256':hashlib.sha256(before.read_bytes()).hexdigest(),'after_sha256':hashlib.sha256(after.read_bytes()).hexdigest(),'before_pack_id':old['pack_id'],'after_pack_id':new['pack_id'],'extra_frozen_input_bytes_unchanged':inputs_unchanged,'all_id_values_and_paths_identical':all_ids(old)==all_ids(new),'change_count':len(changes),'changes':changes};rows.append(row)
 print(case,len(changes),'all ids same',row['all_id_values_and_paths_identical'])
(D/'merged-pack-comparison.json').write_text(json.dumps(rows,indent=2)+'\n')
