import copy,hashlib,json,subprocess,sys
from pathlib import Path
O=Path(__file__).resolve().parent;D=O/'binding-controls';R=O.parent.parent/'image-prompt';S=R/'skills/photo-prompt-image-generator/scripts'
sys.dont_write_bytecode=True;sys.path.insert(0,str(S));import audit_composed_prompt as ac
sha=lambda s:hashlib.sha256(s.encode()).hexdigest()
profiles={p['id']:p for p in json.loads((O/'reviewed-profiles.json').read_text())}
from visual_profile_contracts import compile_visual_profile
profiles={k:compile_visual_profile(v) for k,v in profiles.items()}
def load(path):
 x=json.loads(path.read_text());return x[0] if isinstance(x,list) else x
rolling={
'fixed-camera':[
 'Across the model car silhouette, {anchor}',
 '{anchor}; here only the car changes image position while the fixed camera leaves the stationary fence upright',
 '{anchor}; here the moving car carries the visible distortion while the posts stay upright',
 'On the painted vehicle lettering, {anchor}',
 'Across the blue car silhouette, {anchor}'],
'camera-sweep':[
 'Along the lamppost shafts, {anchor}',
 '{anchor}; here the camera pan displaces stationary architecture and the posts shear without any independently moving actor',
 '{anchor}; here that form is a stationary lamppost displaced in the image by the camera sweep',
 'On the narrow painted lamppost rims, {anchor}',
 'Across the stationary street architecture, {anchor}'],
'single-object':[
 'Across the isolated blue plate, {anchor}',
 '{anchor}; here the isolated plate alone carries image displacement and no additional scenery is introduced',
 '{anchor}; here the rigid blue plate is the sole visible moving object',
 'Inside the painted numerals, {anchor}',
 'Across the isolated rectangular plate silhouette, {anchor}'],
'combined-opposite-velocities':[
 'Across both car and fence, {anchor}',
 '{anchor}; here the rightward car and leftward projected fence have opposite image velocities and opposite shear signs',
 '{anchor}; the faster rightward car leans opposite the stationary fence as the camera pans right more slowly',
 'Inside the painted model lettering, {anchor}',
 'Across the opposite vehicle and fence shears, {anchor}'],
'rolling-combined-control':[
 'Across both car and fence, {anchor}',
 'Within the camera sweep, {anchor}; the stationary posts move in the image because the camera turns',
 'On the racing model car, {anchor}; its own motion and camera motion jointly determine its image displacement',
 'Inside the painted model lettering, {anchor}',
 'Across the model car and fence geometry, {anchor}']}
split={
'split-middle-control':[
 'At the brass key, {anchor}',
 'At the wall clock, {anchor}',
 'Across the wooden shelf, {anchor}',
 'From the foreground ledge to the distant clock, {anchor}',
 'The key and clock define {anchor}; the intervening shelf remains less resolved'],
'split-optical-transition':[
 'At the brass key, {anchor}',
 'At the wall clock, {anchor}',
 '{anchor}; here the softer feature is an image-space optical division, with no middle-depth prop',
 'Across the workshop ledge and distant wall, {anchor}',
 '{anchor}; here the key and clock frame only the softened optical division, not an intervening shelf']}
results=[]
for case,templates in {**rolling,**split}.items():
 path=(D/'packs' if case in ['single-object','combined-opposite-velocities'] else O.parent/'capture-physics-audit/public-cli/after-merged')/(case+'-pack.json')
 if not path.exists():print('WAIT',case);continue
 pack=load(path);pid='rolling_shutter_readout_skew' if case in rolling else 'split_diopter_dual_focus_planes'
 obligations=pack['visual_obligations']['obligations'];assert [p['id'] for p in obligations]==[pid]
 ob=obligations[0];expected=profiles[pid];assert ob['evidence_requirements']==expected['evidence_requirements'];assert ob['render_gates']==expected['render_gates']
 evidence={}
 for i,(field,spec) in enumerate(ob['evidence_requirements'].items()):
  idx=0
  if case=='rolling-combined-control' and i in [1,2]:idx=-1
  if case=='split-middle-control' and i in [2,4]:idx=-1
  evidence[field]=templates[i].format(anchor=spec['must_mention_any'][idx])
 core=pack['authorial_core'];lock=core['intent_lock'];prompt=core['baseline_prompt_en']+' '+'. '.join(evidence.values())+'.'
 composed={
 'core_retrieval_sha256':pack['core_retrieval']['canonical_sha256'],'pack_id':pack['pack_id'],'prompt_en':prompt,'negative_en':pack['negative_en'],'chosen_candidate_ids':[],'chosen_visual_concept_ids':[],'composer':'agent','candidate_interpretations':[],
 'embodiment_review':{'source_contract_sha256':pack['embodiment_preflight']['canonical_sha256'],'review':{'contract_version':'photo-embodiment-review/v1','provenance':'agent_postcomposition','prompt_sha256':sha(prompt),'scope':'not_applicable','summary':'The complete authored prompt depicts only unmanned model vehicles, a rigid plate, stationary architecture, or workshop objects. It contains no person or animal body action. Text-only applicability review; no rendered pixels inspected.','checks':{}}},
 'authorial_core_binding':{'source_authorial_core_sha256':core['canonical_sha256'],'source_intent_lock_sha256':lock['canonical_sha256'],'preserved_anchor_ids':[x['anchor_id'] for x in lock['semantic_anchors']],'preserved_evidence':[],'authorial_decisions':[]},
 'semantic_clarification_decisions':[{'clarification_id':x['id'],'decision':'applied' if x.get('required_in_final_prompt') else 'rejected','rationale':'The complete baseline and concrete capture evidence preserve the requested physical scene.','prompt_evidence':lock['semantic_anchors'][0]['prompt_evidence']} for x in pack['semantic_clarification']['candidates']],
 'creative_augmentation_brief':{'decisions':[{'candidate_id':x['id'],'decision':'rejected','rationale':'Preserve the requested capture relation and complete source-known physical scene.'} for x in pack['creative_augmentation']['candidates']]},
 'visual_obligation_evidence':{pid:evidence}}
 out=D/'audit'/case;out.mkdir(parents=True,exist_ok=True)
 (out/'composed.json').write_text(json.dumps(composed,indent=2)+'\n')
 focused=ac.audit_visual_obligations(pack,composed,prompt)
 full=ac.audit_composed_prompt(pack,composed)
 (out/'full-audit.json').write_text(json.dumps(full,indent=2)+'\n')
 controls=[]
 for field in evidence:
  bad=copy.deepcopy(composed);del bad['visual_obligation_evidence'][pid][field];f=ac.audit_visual_obligations(pack,bad,prompt);assert f;controls.append({'removed_field':field,'failures':f})
  bad=copy.deepcopy(composed);bad['prompt_en']=prompt.replace(evidence[field],'');f=ac.audit_visual_obligations(pack,bad,bad['prompt_en']);assert f;controls.append({'removed_literal':field,'failures':f})
 # Contradictory prose appended to genuine bindings demonstrates lexical audit limits.
 contradiction=' The camera is fixed and the stationary fence posts lean because of their image motion despite remaining motionless relative to that camera.' if case=='fixed-camera' else (' The intermediate shelf must remain critically sharp at the same time as being visibly softer than both anchors.' if case=='split-middle-control' else None)
 if contradiction:
  bad=copy.deepcopy(composed);bad['prompt_en']+=contradiction
  f=ac.audit_visual_obligations(pack,bad,bad['prompt_en']);controls.append({'physical_contradiction':contradiction,'focused_failures':f,'interpretation':'Acceptance would show absence of physical contradiction classification, not correct physics.'})
 (out/'focused-audit.json').write_text(json.dumps({'failures':focused,'negative_controls':controls},indent=2)+'\n')
 row={'case':case,'pack_path':str(path),'pack_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'pack_id':pack['pack_id'],'focused_pass':not focused,'full_status':full['status'],'full_failures':full.get('failures'),'prompt_words':ac.english_prompt_word_count(prompt),'token_counts':{k:len(ac.authorial_evidence_tokens(v)) for k,v in evidence.items()}}
 results.append(row);print(case,'focused',not focused,'full',full['status'],[x['check'] for x in full.get('failures',[])],flush=True)
(D/'audit-results.json').write_text(json.dumps(results,indent=2)+'\n')
