import copy,json,sys,subprocess,hashlib
from pathlib import Path
O=Path(__file__).resolve().parent; A=O.parent/'capture-physics-audit'; R=O.parents[1]/'image-prompt'
sys.path.insert(0,str(A/'baseline-snapshot/skills/photo-prompt-image-generator/scripts'))
from visual_profile_contracts import compile_visual_profile
from audit_composed_prompt import authorial_evidence_tokens,text_contains_term
import prompt_generator as pg
rawbytes=subprocess.check_output(['git','show','57e29730:skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations.json'],cwd=R)
assert rawbytes==(A/'baseline-snapshot/skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations.json').read_bytes()
old={p['id']:p for p in json.loads(rawbytes)['profiles']}; proposed=json.loads((A/'proposed-profiles.json').read_text()); recommended=copy.deepcopy(proposed)
r,s=recommended
# Ownership is an invariant on present geometry, not a demand to insert scenery.
en="scene geometry remains stable or shears consistently according to each form's motion relative to the camera"
ko='장면의 기하 형태가 각 형태의 카메라에 대한 상대 움직임에 따라 안정적으로 유지되거나 일관되게 전단됨'
r['semantics']['component_semantics']['groups'][1]['any_terms']=[en,ko]
r['evidence_requirements']['rolling_structure_phrase']['must_mention_any']=[en]
r['concept_candidate']['concept_terms'][1]='scene geometry consistent with each form\'s motion relative to the camera'
r['render_gates'][1]['description']="Visible scene geometry is consistent with each form's motion relative to the camera. Stationary background structures, when present with a fixed camera, remain stable; a separate background structure is not required."
r['composition_instruction']=r['composition_instruction'].replace('Keep stationary background structures stable with a fixed camera;', 'Keep any stationary background structures stable with a fixed camera;')
# Restore physically valid old combined-motion and middle-band lexical subtypes as alternatives.
for i,field in [(1,'rolling_structure_phrase'),(2,'rolling_subject_phrase')]:
 r['semantics']['component_semantics']['groups'][i]['any_terms'] += old[r['id']]['semantics']['component_semantics']['groups'][i]['any_terms']
 r['evidence_requirements'][field]['must_mention_any'] += old[r['id']]['evidence_requirements'][field]['must_mention_any']
c=s['authored_components']['components'][4]; oc=old[s['id']]['authored_components']['components'][4]
c['match_terms']+=oc['match_terms']
c['evidence_terms'] += [x for x in oc['evidence_terms'] if x not in c['evidence_terms']]

def diff(a,b,path=''):
 if type(a)!=type(b): return [{'path':path,'old':a,'new':b}]
 if isinstance(a,dict): return sum((diff(a[k],b[k],path+'/'+k) for k in a),[])
 if isinstance(a,list):
  if len(a)!=len(b):return [{'path':path,'old':a,'new':b}]
  return sum((diff(x,y,path+'/'+str(i)) for i,(x,y) in enumerate(zip(a,b))),[])
 return [] if a==b else [{'path':path,'old':a,'new':b}]
result={'baseline_commit':'57e29730f0b5c2df336fd1e9dd58374b2025ee03','status':'reviewed_proposal_only_no_repo_edits','source_sha256':hashlib.sha256(rawbytes).hexdigest(),'profiles':[]}
for original,new in zip(proposed,recommended):
 b=compile_visual_profile(old[new['id']]);p=compile_visual_profile(original);n=compile_visual_profile(new)
 row={'id':new['id'],'old_component_compatibility':[],'new_component_controls':[],'evidence':[]}
 for lang in [0,1]:
  text='; '.join(g['any_terms'][lang] for g in b['semantics']['component_semantics']['groups'])
  v=[pg.candidate_pack_visual_component_match(x,text) for x in [b,p,n]]
  assert v[0] and v[2];assert not v[1]
  row['old_component_compatibility'].append({'lang':lang,'baseline_proposed_recommended':v})
  groups=n['semantics']['component_semantics']['groups'];txt='; '.join(g['any_terms'][lang] for g in groups)
  assert pg.candidate_pack_visual_component_match(n,txt)
  missing=[bool(pg.candidate_pack_visual_component_match(n,'; '.join(g['any_terms'][lang] for j,g in enumerate(groups) if i!=j))) for i in range(5)]
  exclusions=[bool(pg.candidate_pack_visual_component_match(n,txt+'; '+x)) for x in n['activation']['exclude_if_any_terms']]
  assert not any(missing+exclusions)
  row['new_component_controls'].append({'lang':lang,'positive':True,'missing':missing,'excluded':exclusions})
 for field,req in n['evidence_requirements'].items():
  assert req['min_content_words']==b['evidence_requirements'][field]['min_content_words']
  anchors=[]
  for text in req['must_mention_any']:
   count=len(authorial_evidence_tokens(text));anchors.append({'text':text,'distinct_content_tokens':count,'minimum':req['min_content_words'],'additional_distinct_tokens_needed':max(0,req['min_content_words']-count)})
  for text in b['evidence_requirements'][field]['must_mention_any']:
   assert any(text_contains_term(text,a) for a in req['must_mention_any'])
  row['evidence'].append({'field':field,'anchors':anchors,'all_old_anchors_preserved':True})
 for key in ['activation','required_evidence_fields','runtime_expression']:assert b[key]==n[key]
 assert [(g['id'],g['review_scale']) for g in b['render_gates']]==[(g['id'],g['review_scale']) for g in n['render_gates']]
 result['profiles'].append(row)
(O/'reviewed-profiles.json').write_text(json.dumps(recommended,ensure_ascii=False,indent=2)+'\n')
(O/'reviewed-field-proposal.json').write_text(json.dumps({'baseline_commit':result['baseline_commit'],'profiles':{p['id']:diff(old[p['id']],p) for p in recommended}},ensure_ascii=False,indent=2)+'\n')
(O/'review-validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print('Verified original source bytes, old EN/KO compatibility restored, new EN/KO full/missing/exclusion controls pass, real token minima recorded, all old evidence anchors preserved.')
