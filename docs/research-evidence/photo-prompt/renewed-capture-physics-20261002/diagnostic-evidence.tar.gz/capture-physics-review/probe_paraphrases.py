import json,sys,subprocess
from pathlib import Path
O=Path(__file__).resolve().parent;R=O.parent.parent/'image-prompt';sys.dont_write_bytecode=True;sys.path.insert(0,str(R/'skills/photo-prompt-image-generator/scripts'))
import prompt_generator as pg
from visual_profile_contracts import compile_visual_profile
old={p['id']:compile_visual_profile(p) for p in json.loads(subprocess.check_output(['git','show','57e29730:skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations.json'],cwd=R))['profiles']}['rolling_shutter_readout_skew']
reg=pg.load_visual_obligation_registry(R/'skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations.json');new=next(p for p in reg['profiles'] if p['id']==old['id']);idx=json.loads((R/'skills/photo-prompt-image-generator/assets/photo_prompt_visual_profile_index.json').read_text())
rows=[]
for origin,p in [('old',old),('new',new)]:
 for i,t in enumerate(p['semantics']['paraphrase_examples']):
  matched=[g['id'] for g in new['semantics']['component_semantics']['groups'] if any(pg.intent_alias_matches(t,x) for x in g['any_terms'])]
  res=pg.resolve_visual_profile_hits(reg,[{'source':'concept_lock','text':t,'polarity':'required','priority':'critical','mandatory':True}],visual_profile_index=idx,adult_context=True)
  rows.append({'origin':origin,'index':i,'text':t,'original_match':pg.candidate_pack_visual_component_match(old,t),'reviewed_match':pg.candidate_pack_visual_component_match(new,t),'reviewed_literal_groups':matched,'exact_only_current_resolver_target_hits':[h for h in res['hits'] if h['profile_id']==old['id']]})
t=new['semantics']['paraphrase_examples'][0]
optional=pg.candidate_pack_auto_visual_concept_matches(reg,[{'source':'concept_lock','text':t,'polarity':'required','priority':'critical','mandatory':True}])
output={'cases':rows,'new_fixed_camera_optional_concept_result':optional.get(old['id']),'limits':'Resolver calls use the actual full current index without query fields or fabricated embedding vectors: exact routing only. The separate real optional-concept matcher is run for the new fixed-camera phrase.'}
(O/'paraphrase-probe.json').write_text(json.dumps(output,ensure_ascii=False,indent=2)+'\n');print(json.dumps(output,ensure_ascii=False,indent=2))
