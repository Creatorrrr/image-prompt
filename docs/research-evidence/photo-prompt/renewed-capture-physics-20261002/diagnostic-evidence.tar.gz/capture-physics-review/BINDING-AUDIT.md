# Complete scene-specific composed-prompt controls

Seven complete compositions passed the production `audit_composed_prompt` function, including every unrelated v6 composition check. No pack fields, gates, hashes or obligations were replaced. Packs came from the normal public `generate_photo_prompt.py` CLI using the actual refreshed full index. No fabricated embeddings or paid API calls were used by this review.

Cases: fixed-camera moving car; camera sweep/static street; isolated moving plate without extra scenery; combined camera/object motion with opposite image velocities; original combined-motion wording; original split middle-band wording; split optical transition without a middle-depth prop.

Artifacts:
- `binding-controls/audit-results.json`: source pack paths/hashes, full status and measured evidence token counts
- `binding-controls/audit/<case>/composed.json`: complete authored compositions and bindings
- `binding-controls/audit/<case>/full-audit.json`: all seven full PASS results
- `binding-controls/audit/<case>/focused-audit.json`: focused results plus negative controls
- `binding-controls/inputs/`: two additional genuine four-contract input sets for isolated plate and opposite-velocity scenes
- `binding-controls/packs/`: actual normal CLI packs/stdout/stderr for those two cases; both exited 0
- `prepare_binding_controls.py`, `run_binding_audits.py`: reproducible construction and execution

Every required field has a distinct scene-specific literal evidence phrase that meets the real content-token floor. Five missing-field and five missing-literal variants fail for each case. The two compatibility cases explicitly use the restored old rolling structure/subject anchors and restored old split band-only boundary anchor.

The focused auditor accepts a deliberately appended physical contradiction in the fixed-camera case: stationary posts are asserted to lean from image motion despite no motion relative to the fixed camera. It also accepts a split shelf being simultaneously critically sharp and softer than both sharp anchors. These controls deliberately retain genuine complete bindings. Their acceptance demonstrates that lexical evidence compliance does not classify physical consistency. No pixel-quality or automatic physics-validation claim is warranted. Runtime was not patched.

The full controls preserve the complete prepack baseline, reject all advisory embellishments, bind actual pack and core hashes, provide all required clarification decisions, and include a newly authored hash-bound postcomposition applicability review. These scenes depict no body actions, so embodiment applicability is correctly not applicable rather than a synthetic anatomy pass.

# Partial-paraphrase follow-up

`paraphrase-probe.json` records the actual six old/current phrases. Each previous phrase matches the previous profile but no longer the reviewed profile; each new phrase was unmatched before and now matches as `semantic_paraphrase_example`. All have zero literal matches to required component groups. The current fixed-camera phrase also gains optional eligibility through the production `candidate_pack_auto_visual_concept_matches`, confirming a real optional shortcut rather than just a helper label. Exact routing with the actual full current index yields no target hard hits for any of the six phrases. No embedding query vector was supplied or fabricated.

This does not weaken selected normal gates: optional opt-in still installs the full five-part obligation. However, the semantic-discovery component guard delegates to a matcher that accepts paraphrase examples without all five groups. Incomplete new examples therefore broaden advisory discovery beyond their demonstrated invariants. Existing partial old examples had the same architectural weakness; adding more exceptions does not resolve it.

Recommended minimal DATA follow-on: `complete-paraphrase-proposal.json` completes only new examples 0 and 1 with actual staggered exposure, ownership, progressive shear, crisp detail and substitute distinction. Each prior incomplete phrase stops matching while each complete phrase remains discoverable. All activation, evidence, gates and composition instructions are unchanged. The new camera-sweep example 2 already conveys row-timed geometry, camera-owned shear of static scenery, crisp detail and distinction from ordinary blur, so it need not be expanded merely to meet a literal component count. Five literal group matches are not the aim of authored paraphrases; complete physical meaning is.

Applying this follow-on changes indexed source text and therefore requires the established real index refresh plus normal replay. The already measured seven full passes refer to the reviewed profiles before this proposed two-leaf follow-on. Their obligation fields remain unchanged, but this report does not falsely claim an unrun full-index AFTER for the follow-on.

## Final completed-paraphrase replay

The two-leaf completion was subsequently applied by the parent and the actual rolling index entry refreshed. All seven complete composed-prompt audits were rerun against final normal CLI packs and passed again. Both extra CLI packs exited 0 from byte-identical four-contract inputs. Every final pack is recursively identical to its pre-completion counterpart: zero changed paths, unchanged pack IDs, candidate identities, ordering and counts. Prior compositions/packs/audits are preserved at `binding-controls-before-final`; final source hashes and summary are in `binding-controls/final-verification.json`, exact comparisons in `binding-controls/final-pack-comparison.json`, and seven final audit results in `binding-controls/audit-results.json`. No further prose changes are recommended. The physical-contradiction classification limitation still applies.

## Upstream 840d integration replay

All seven complete composed-prompt audits pass against the merged source and actual full index. Authored prompt text and visual evidence are byte-identical to the prior final controls. Only genuine pack/retrieval hashes required rebinding, plus updated rejected advisory clarification decisions for camera-sweep. Both extra merged CLI runs and both corresponding clean-upstream840d CLI runs exited 0 from unchanged inputs. Prior final artifacts are preserved in `binding-controls-before-merged`.

Keep causal comparisons separate: old-final versus merged has upstream-associated advisory changes in fixed-camera platform candidates, camera-sweep optional concepts/clarifications, and opposite-velocity lighting/bundles (5 to 4 bundles). Clean upstream840d versus merged isolates our DATA: exactly 12 paths for each rolling case and 6 paths for each split case, confined to target optical contracts/clarifications and pack ID. All candidate identities/order/counts are unchanged in that controlled comparison. Exact old-to-merged changes are in `binding-controls/merged-pack-comparison.json`; patch-isolating differences are in `binding-controls/merged-vs-upstream-only-comparison.json`; unchanged authored text and metadata adjustments are recorded in `binding-controls/merged-composition-comparison.json`. Current source hashes and completion summary are in `binding-controls/merged-verification.json`.
