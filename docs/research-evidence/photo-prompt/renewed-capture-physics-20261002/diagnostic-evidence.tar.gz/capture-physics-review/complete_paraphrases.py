import copy,json,sys
from pathlib import Path
O=Path(__file__).resolve().parent;R=O.parent.parent/'image-prompt';sys.dont_write_bytecode=True;sys.path.insert(0,str(R/'skills/photo-prompt-image-generator/scripts'));import prompt_generator as pg
from visual_profile_contracts import compile_visual_profile
p=next(x for x in json.loads((O/'reviewed-profiles.json').read_text()) if x['id']=='rolling_shutter_readout_skew');n=copy.deepcopy(p)
n['semantics']['paraphrase_examples'][0]='a fast lateral vehicle shears across its height against upright stationary posts when the camera is fixed; staggered row exposure progressively displaces only the vehicle image while painted lettering stays crisp, distinguishing motion-owned shear from tilted framing, perspective convergence, lens warp and uniform blur'
n['semantics']['paraphrase_examples'][1]='고정된 카메라 앞에서 빠르게 옆으로 이동하는 차량만 시차를 둔 센서 행 노출에 따라 높이 방향으로 점진적으로 전단되고 정지한 기둥은 곧게 유지되며, 차량의 글자는 국소적으로 선명하여 기울어진 구도나 원근 수렴, 렌즈 왜곡 또는 균일한 번짐과 구별됨'
# Korean explicit boundary contains 렌즈 왜곡, but activation excludes English lens distortion only.
compiled=compile_visual_profile(n);old=compile_visual_profile(p)
checks=[]
for i in [0,1]:
 partial=p['semantics']['paraphrase_examples'][i];complete=n['semantics']['paraphrase_examples'][i]
 checks.append({'index':i,'partial_before':pg.candidate_pack_visual_component_match(old,partial),'partial_after':pg.candidate_pack_visual_component_match(compiled,partial),'complete_after':pg.candidate_pack_visual_component_match(compiled,complete)})
 assert checks[-1]['partial_after'] is None and checks[-1]['complete_after']=='semantic_paraphrase_example'
for k in ['activation','required_evidence_fields','evidence_requirements','render_gates','composition_instruction']:
 assert compiled[k]==old[k]
patch=[{'path':'/semantics/paraphrase_examples/'+str(i),'old':p['semantics']['paraphrase_examples'][i],'new':n['semantics']['paraphrase_examples'][i]} for i in [0,1]]
(O/'complete-paraphrase-proposal.json').write_text(json.dumps({'profile_id':p['id'],'changes':patch,'checks':checks,'status':'proposal_only_no_repo_edits'},ensure_ascii=False,indent=2)+'\n')
print(json.dumps(checks,ensure_ascii=False))
