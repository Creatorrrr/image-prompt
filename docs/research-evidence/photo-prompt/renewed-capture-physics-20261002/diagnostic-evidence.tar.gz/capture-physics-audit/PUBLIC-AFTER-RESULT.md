# Reviewed repair: actual public consumer result

Baseline commit: 904b5893c94e2d59d646e977c8400e270635a568. Original 57e29730 baseline and all frozen raw inputs remain unchanged.

The exact independent-reviewed proposal, not the initial proposal, was applied: 20 source spans in the main visual-obligation registry, with both resulting profiles equal to capture-physics-review/reviewed-profiles.json. No other profile changed structurally in this application. Existing valid component/evidence phrases were retained as alternatives by the independent review. Parent subsequently refreshed the two real embedding entries and derived index. This worker made no API call and did not fabricate, replace or reuse stale vectors as fresh.

## Normal CLI requalification

Six normal current-repository BEFORE runs succeeded on 904b5893, using actual current full runtime data and real index. Recursive whole-pack comparison against the original57 BEFORE finds **zero changed paths for every case**. This establishes that the intervening remaining-boundary repair did not alter these six diagnostic outputs.

After the real index refresh, all six normal public CLI AFTER runs succeeded. The exact same 24 raw input files were supplied; run_current.py checked every frozen SHA-256 before every execution. Actual source/index/script SHA-256s and complete command lines are recorded in public-cli/after-reviewed/run-manifest.json.

## Whole-pack differences

- fixed-camera: 12 paths
- camera-sweep: 12 paths
- rolling-combined-control: 12 paths
- split-optical-transition: 6 paths
- split-middle-control: 6 paths
- generic-motion-control: zero paths

Each rolling case changes only pack_id, three fields of its rolling semantic clarification, and eight rolling obligation fields: two component alternative arrays, composition instruction, two literal evidence alternative arrays, one substitute rejection, and two gate descriptions.

Each split case changes only pack_id, one split clarification component, and four split obligation fields: boundary component alternatives, composition instruction, boundary evidence alternatives, and the soft-transition gate description.

No candidate identity/order/count, selected slot, core, controls, embodiment review, unrelated obligation, or other field changed in these cases. Arrays that increased in length are only the intended accepted component/evidence alternatives. This is a measured property of these six source-known inputs, not a claim of global retrieval equivalence.

Full values and paths: public-cli/after-reviewed/comparison-vs-before-904b.json. Readable path list: comparison-paths.txt. Original-to-current baseline comparison: public-cli/before-904b/comparison-vs-before.json.

## Index necessity and limits

The real loader requires matching registry fingerprint, lexical/BM25F payload and semantic text/hash metadata. A two-profile source edit therefore needs a derived-index refresh. An attempted pre-refresh diagnostic reached the loader after the parent had already refreshed; it succeeded, so no observed stale-index failure is claimed. That incidental successful fixed-camera CLI output is preserved separately as incidental-refreshed-fixed-camera.stdout/stderr and is not substituted for the formal six-run evidence.

The independent reviewer received the actual full-index AFTER packs for scene-specific composed-prompt evidence verification. These packs are retrieval contracts, not composed prompts or rendered images. No pixel improvement, automatic camera-motion inference, or full composed-prompt audit pass is inferred from them.

Replay: python run_current.py after-reviewed, from this evidence directory or any cwd. This script uses the repository's real current public CLI and index; run only with reviewed source and refreshed index installed. It never reconstructs inputs. compare_public.py before-904b after-reviewed performs the recursive comparison. apply_reviewed.py is an already-used one-time source edit script, not an input replay step.

## Regression handoff

This worker reran 8 capture semantic tests and 21 semantic-correction tests: all 29 passed, and git diff --check was clean. Parent separately reports 54 regression tests passing, dictionary validation passing, and exactly two real vectors changed with 1,417 preserved. Those broader results are parent-owned evidence, not additional test runs claimed by this worker. Initial proposal findings remain as history, explicitly superseded by the reviewer’s exact token-floor and backward-compatibility analysis. Complete scene-specific composed bindings and partial-paraphrase activation remain with the independent reviewer; no complete composed-audit pass is claimed here.

## Final requalification after complete-paraphrase correction

Parent subsequently applied the reviewer’s two complete-paraphrase leaves to the rolling profile and refreshed its actual vector. The original after-reviewed artifacts above remain preserved. Six new normal public CLI runs wrote separate `public-cli/after-final` artifacts; every run exited 0. All 24 frozen raw input files were hash-verified before execution and independently rechecked afterward (`after-final/immutable-input-verification.json`). Final source/index/script hashes and command lines are in `after-final/run-manifest.json`.

Recursive whole-pack comparison against after-reviewed finds zero changed paths in all six cases, including pack IDs. Thus no candidate identity, order, count or other public field changed on these six inputs after the complete-paraphrase correction. Against before-904b, final changes remain 12 paths for each of fixed-camera, camera-sweep and rolling-combined-control; 6 paths for each of split-optical-transition and split-middle-control; and zero for generic-motion-control.

Final comparisons: `after-final/comparison-vs-after-reviewed.json` and `after-final/comparison-vs-before-904b.json`. This verifies the existing six scenes, not every possible paraphrase query; the reviewer’s distinct partial/complete-paraphrase checks are separate evidence. No repository mutation, test edit or publication was performed by this final replay.

## Integration requalification against upstream840d

Upstream-only control is now commit 840d4b8f0dbcb977b3d02b5dbcce38894bcd0ec4, with its unmodified 1,496-profile real index. After the parent combined the nonconflicting source leaves and refreshed the real merged index, six normal CLI runs wrote `public-cli/after-merged`, all exit 0. All frozen input hashes were checked before every run and rechecked afterward. Recorded source/index/script hashes were also verified unchanged at the end of the replay. The merged working-tree hashes, rather than HEAD alone, identify the tested state.

Strict comparison to the correct upstream-only `before-840d` baseline:
- fixed-camera: 12 changed paths
- camera-sweep: 12
- rolling-combined-control: 12
- split-optical-transition: 6
- split-middle-control: 6
- generic-motion-control: 0

These changes remain confined to pack ID and the same target profile's clarification/obligation fields described above. No candidate identity/order/count changes or unrelated output changes occurred versus upstream840d for these six inputs.

Separate comparison to pre-upstream `after-final` deliberately records upstream drift: fixed-camera 27 paths, camera-sweep 49, split-optical-transition 6, rolling-combined-control 6, split-middle-control 6, generic-motion-control 17. Do not attribute those older-baseline differences to the capture repair or hide candidate differences present in that comparison. Full old/new values, including any advisory candidate arrays and order differences, are preserved in `after-merged/comparison-vs-after-final.json`. Strict repair comparison is `after-merged/comparison-vs-before-840d.json`.

All prior before/after artifacts remain intact. This integration replay made no repository edit, API call, index mutation, test edit or publication. The independent reviewer has received all genuine merged packs and the upstream snapshot path for its additional controls.
