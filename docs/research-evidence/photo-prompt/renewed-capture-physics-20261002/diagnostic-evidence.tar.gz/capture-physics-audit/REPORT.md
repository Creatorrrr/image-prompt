> Historical pre-review artifact. Initial proposed profiles and their evidence-floor/compatibility claims are superseded by capture-physics-review/REVIEW.md and its exact token counts. The initial proposal lost valid old component/evidence alternatives and was not applied. See PUBLIC-AFTER-RESULT.md for the exact reviewed repair and actual public-CLI results.

# Capture physics audit, 2026-10-02

## Result

At HEAD `57e29730f0b5c2df336fd1e9dd58374b2025ee03`, recommend **correct rolling-shutter motion ownership**, **align split-diopter's already-supported transition alternative across its compiled contract**, **keep telephoto/shallow-focus/highlight-rolloff**, and **defer broader focus-stack scope changes**. No repository files changed. No images generated, paid calls, or image-quality claims.

## Verified consumer behavior

`probe.py` calls the real `load_visual_obligation_registry`, `build_visual_profile_index_payload`, `resolve_visual_profile_hits`, and `candidate_pack_visual_profile_obligation` with request and context text. `materialized-consumer-probe.json` stores both routing results and fully materialized hard obligations. This is a six-profile sliced registry/index, not a full end-to-end generation run. Its exact routing and materializer are production functions.

- Locked tripod + fast lateral car + explicitly upright stationary posts: exact rolling alias is hard eligible; materializer still requires repeated vertical structures to lean.
- Rapid sweep of an empty stationary street + no independently moving subject: exact rolling alias is hard eligible; materializer still requires a fast-moving subject to shear.
- Macro stack with deliberately soft remote backdrop: exact multi-plane alias is hard eligible and requires sharp remote background.
- Split diopter with a hidden transition/no visible mid-depth object: exact alias is hard eligible and requires a visible soft middle-depth band.
- Shallow falloff with no foreground object: exact relation alias is hard eligible and requires a foreground transition. This last mismatch alone is **not** grounds to broaden an explicitly narrow relation.
- Generic existing slot labels `macro focus-stacked sharp detail`, `a split-diopter lens plane`, `shallow depth of field with strong background blur`, `subtle smartphone rolling-shutter motion`, `gradual bright tonal transition into highlights`, and `a 200mm telephoto lens` did **not** hard-activate any audited profile in this sliced resolver. Do not claim these broad slots automatically inherit the narrow contracts.
- Existing capture semantic suite: `python -m unittest discover -s tests -p 'test_photo_capture_elements_visual_semantics.py' -q` → **8 tests passed**. Existing tests verify narrow routing/schema, not these causal counterexamples.

## Profile decisions

### 1. rolling_shutter_readout_skew — CORRECT, high confidence

Source: `photo_prompt_visual_obligations.json:22263` onward. The definition and instruction explicitly permit fast lateral object motion **or** rapid camera movement. However `rolling_structure_lean` and `rolling_moving_form_skew` are both mandatory, with matching evidence fields and render gates. `single_bent_object` is rejected. The Korean paraphrase also implies structures and moving objects lean in the same direction.

Concrete contradiction: a stationary camera observes a moving car. The car changes image position between row exposure times; stationary fence posts do not. Requiring those posts to lean adds camera/environment motion that the selected scene explicitly forbids. Conversely a camera sweep across static architecture does not need an independently moving subject. With object and camera motion together, their relative image velocities may differ in magnitude or sign; one shared readout axis does not impose identical lean direction on all objects.

Primary evidence: Basler's documentation distinguishes sequential **exposure timing** from merely serial data readout: even its global-shutter explanation reads data row by row after simultaneous exposure. It says fast object **or** camera movement may cause rolling distortion. The stationary-background conclusion is an explicit geometric inference from those exposure times, not a vendor quote.
https://docs.baslerweb.com/electronic-shutter-types (sections Global Shutter, Rolling Shutter, Possible Image Distortion)

Minimal DATA change direction:
- Definition: say temporally staggered row exposure/recording; scope deformation to the relative image motion of each visible owner.
- Preserve progressive cross-readout displacement and crisp local detail.
- Replace mandatory background lean with owner-consistent scene structure: fixed camera/static background remains stable; a sweep can shear static structures.
- Replace independently moving subject requirement with a sheared visible moving-image form, allowing scene structures displaced by camera motion.
- Remove unconditional `single_bent_object` rejection; retain arbitrary unexplained bent geometry as the negative boundary. One coherently sheared moving object against a stable background is valid.
- Update all EN/KO component phrases, literal evidence, concept terms, composition instructions, gate descriptions, and paraphrases together. Existing IDs can be retained if the compatibility policy requires it, but don't leave descriptions implying obsolete ownership.

This is not widening to every rolling-shutter phenomenon (banding, propeller segmentation, wobble, etc.). It only repairs the two motion branches this exact profile already promises.

Verification: real resolver + materializer fixtures for tripod/car/upright posts, sweep/static street/no moving actor, and both camera/object motion with distinct image velocities. Check generated obligation prose never invents forbidden motion owners. Maintain negative Dutch-angle, lens-distortion, and uniform-blur cases. In component matching, exercise each physical branch in both languages, then literal-evidence audit with a minimally complete binding. Rebuild derived index using existing repo procedure and run validator/capture regressions before any image test.

### 2. split_diopter_dual_focus_planes — CORRECT internal alternative; DEFER hidden-boundary broadening

Source: `photo_prompt_visual_obligations.json:21876`, authored `diopter_soft_middle_band` around 21980. Definition and first match/evidence term allow an intervening depth band **or optical transition** to be softer. But the authored instruction/render gate require an intervening **middle-depth band**, and the final boundary component likewise only accepts a band. A softened split-field optical transition is an image-region transition; it need not be a visible object at an intermediate scene distance.

Minimal change: keep the current narrow visible-signature scope, but consistently preserve its already-written alternative: a softer intervening depth band **or a restrained optical transition**. Update instruction, render-gate description, boundary match/evidence terms and concept term. Do not simply remove the third component. This repair is supported by the data's own definition; the vendor source only establishes two optical focus regions and does not establish a universal visible middle band.

Primary source: Schneider-Kreuznach explains foreground through the semicircular diopter and background through the uncovered half, creating two focus areas.
https://schneiderkreuznach.com/application/files/5717/0142/0920/Fact_Sheet_Diopter_Split_GEN2_Schneider-Kreuznach.pdf

The hidden-seam fixture is an edge case, not a recommended immediate broadening: no visibly softer transition may be outside this deliberately narrow signature. Existing generic split-diopter slot is not an exact hard route. Preserve the recently added visual/process claim limit.

Verification: compile the authored components via the real registry loader, materialize the obligation for a request with near/far sharp anchors and a visible softened optical division but no intermediate-depth object. Verify instruction, evidence and gates accept that **same** alternative. Separate hidden-seam case as out-of-scope/deferred, and preserve uniform deep-focus/split-screen negatives.

### 3. telephoto_distance_compression_relation — KEEP

The alias names a distant-viewpoint/plane-scale relation; the definition now correctly says narrow field of view. It explicitly requires distant viewpoint rather than claiming focal length alone proves compression. Large background scale, crowded planes, reduced convergence and readable layers are a deliberate narrow depiction, not a universal equipment fact. Generic 135/200/400/600mm slots do not activate this exact relation in the probe. No causal contradiction established.

Primary context: Canon's perspective demonstration varies subject distance with focal length; it supports the depicted relative foreground/background scale family, not a claim that cropping alone changes viewpoint.
https://www.usa.canon.com/pro/rf-lens-world/features/perspective

Optional future wording precision could distinguish distance-owned perspective from field-of-view/framing, but do not churn this DATA without a failed consumer case. A same-viewpoint crop can retain the same perspective; current text rejects cropping **alone as proof**, not all cropped images.

### 4. shallow_depth_focus_falloff_relation — KEEP

Narrow aliases include Korean `선명면 전후 초점 이탈 구도` (before-and-after focus departure). Both recognizable foreground and background falloff are intentionally part of that scene relation. The broad `shallow_depth` and editing `pe_shallow_falloff` slots allow less restrictive focus depictions and do not hard-activate this profile in the probe. No forced broad-slot propagation was established. Keep optical, depth-driven falloff and edge continuity; do not misread this as a demand that foreground/background bokeh have identical shape.

Primary context: ZEISS documents foreground/background bokeh asymmetry and dependence on optics.
https://lenspire.zeiss.com/photo/app/uploads/2022/02/technical-article-depth-of-field-and-bokeh.pdf

The no-foreground exact-alias probe shows a user can name this narrower relation while contradicting it; that alone does not justify changing its scope. A future explicit-definition override test is more appropriate than broadening every shallow-focus gate.

### 5. focus_stacked_extended_depth_composite — DEFER scope change; retain current depiction

The current profile intentionally requires near/middle/far sharp anchors. Its Korean alias explicitly describes foreground-background composition. Broad `macro_focus_stack` slot says macro focus-stacked sharp detail and did not hard-route in the probe. The editing extension's related bundle is candidate-only and says profiles require separate activation. A macro subject-only stack is physically valid, but the current hard alias may intentionally name an extended foreground-background depiction; do not infer a migration from the generic technique alone.

Concern to retain: English `multi-plane focus-stack composite` is broad enough to match a shallow macro stack with a blurred distant background, and the exact probe confirms a hard contradiction. Decide whether that alias should be narrowed/removed or whether the relation should support subject-bounded depth before implementation. A minimal alias narrowing is safer than globally requiring all macro backgrounds to become sharp.

Second concern: definition/composition text implies clean blending distinguishes a focus stack from a single small-aperture exposure. Those pixels cannot prove exposure count. A future claim-limit-only correction could clarify visible extended sharpness versus actual production history without weakening the three-depth gates, analogous to the split-diopter limit already present. This is an inference about evidentiary limits, not a vendor statement proving indistinguishability for every scene.

Primary technique source: Adobe describes aligning and blending different focus points, with Stack Images distinct from Panorama.
https://helpx.adobe.com/photoshop/desktop/create-masks/blend-images/create-a-composite-with-extended-depth-of-field.html

Verification before deciding: full actual candidate-pack route from selected `macro_focus_stack` and editing bundle (not only lexical resolver), user-definition override behavior for a subject-only macro stack, and a three-depth positive. If narrowing aliases, keep generic technique labels advisory; do not manufacture a distant structure in a macro scene.

### 6. highlight_rolloff_tone_response — KEEP

Definition/required phrase/gate say clipping **may** happen or **any** clipped white stays confined. This does not mandate a clipped center. Near-white anchors and gradual tonal shoulder own the effect; spatial bloom/HDR halo is not sufficient evidence. The related editing slots preserve the tonal-vs-spatial distinction and candidate-only bundles require separate activation. Existing capture-boundary correction keeps the positive English boundary phrase from self-excluding. No new physical contradiction found.

ARRI's primary whitepaper discusses non-linear/local tone mapping for scene contrast; it supports tonal processing context, not a requirement to infer sensor model or capture history from rolloff.
https://www.arri.com/resource/blob/295460/e10ff8a5b3abf26c33f8754379b57442/2022-09-28-arri-dynamic-range-whitepaper-data.pdf

Keep unclipped near-white positive, small-core clipping positive, and abrupt featureless clipping negative in future consumer coverage. The gate's casual `reaches white` versus definition's `approaches white` could be made consistent in an unrelated cleanup, but there is no demonstrated rejection warranting this audit's priority.

## Limits

These are source/contract/routing findings, not image evaluation. No generated/rendered image inspected. No repo edits. The audit does not establish that a generic slot automatically activates a hard profile; measured generic probes show the opposite. Physical branch corrections must survive literal evidence and materialized gate consumers, not just a definition string test.
