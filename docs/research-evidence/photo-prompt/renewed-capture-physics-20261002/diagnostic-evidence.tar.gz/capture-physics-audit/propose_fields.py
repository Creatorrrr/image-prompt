import json,copy,subprocess
from pathlib import Path
R=Path('REPOSITORY_ROOT');O=Path(__file__).parent
old=json.loads(subprocess.check_output(['git','show','57e29730:skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations.json'],cwd=R,text=True));profiles={p['id']:p for p in old['profiles']};new={k:copy.deepcopy(profiles[k]) for k in ['rolling_shutter_readout_skew','split_diopter_dual_focus_planes']}
p=new['rolling_shutter_readout_skew']
p['semantics']['definition']='Temporally staggered sensor-row exposures record different image positions at different instants, so fast lateral subject motion or rapid camera movement produces coherent readout-axis shear according to each form\'s motion relative to the camera. Moving image forms lean or shear while stationary forms relative to a fixed camera retain stable geometry, and some local detail can remain crisp. A Dutch angle, wide-angle convergence, arbitrary warp, or ordinary motion blur cannot substitute.'
p['semantics']['paraphrase_examples']=['a fast lateral vehicle shears across its height against upright stationary posts when the camera is fixed','빠른 피사체 움직임이나 카메라 이동에 따른 상대 영상 운동이 판독 축을 따라 일관된 전단을 만듦','a rapid camera sweep shears stationary scene structures while crisp local detail separates row-timed geometry from ordinary blur']
groups=p['semantics']['component_semantics']['groups']
updates={
'rolling_structure_lean':(['scene structures remain stable or shear consistently according to their motion relative to the camera','장면 구조물이 카메라에 대한 상대 움직임에 따라 안정적으로 유지되거나 일관되게 전단됨'],'rolling_structure_phrase'),
'rolling_moving_form_skew':(['a recognizable form displaced by subject motion or camera movement shears progressively across the sensor readout axis','피사체 움직임이나 카메라 이동으로 영상 위치가 바뀌는 형태가 센서 판독 축을 가로질러 전단됨'],'rolling_subject_phrase')}
for g in groups:
 if g['id'] in updates:
  terms,field=updates[g['id']];g['any_terms']=terms;p['evidence_requirements'][field]['must_mention_any']=[terms[0]]
p['concept_candidate']['concept_terms'][1]='scene-structure geometry consistent with relative camera motion'
p['concept_candidate']['concept_terms'][2]='subject-motion or camera-motion shear across the readout axis'
p['composition_instruction']='Use fast lateral subject motion or a rapid camera sweep. Make geometric displacement vary progressively along one sensor-readout axis according to each form\'s relative image motion. Keep stationary background structures stable with a fixed camera; a camera sweep can shear stationary scene structures without an independently moving subject. Preserve some crisp local edges so the result reads as row-timed geometry rather than a tilted frame or generic blur.'
p['render_gates'][1]['description']='Scene structures remain stable or shear consistently with their motion relative to the camera; a fixed camera leaves stationary background structures stable.'
p['render_gates'][2]['description']='A form displaced in the image by subject motion or camera movement visibly shears across the sensor readout axis.'
p['semantics']['contrast_examples'][-1]='an arbitrarily bent object with no coherent motion-related shear'
p['reject_substitutes'][-1]='arbitrary_bending_without_motion_related_shear'
p=new['split_diopter_dual_focus_planes']
p['concept_candidate']['concept_terms'][2]='softer intervening depth band or restrained optical transition'
cs=p['authored_components']['components'];c=next(c for c in cs if c['id']=='diopter_soft_middle_band')
c['instruction']='An intervening middle-depth band or restrained optical transition remains visibly softer than both anchors.';c['render_gate']['description']=c['instruction']
c=next(c for c in cs if c['id']=='diopter_not_stack_or_split_screen')
c['match_terms']=['two separated sharp zones with a softer intervening band or restrained optical transition','분리된 두 선명 구역 사이에 더 부드러운 깊이 띠나 절제된 광학 전환이 남음']
c['evidence_terms'][1]=c['match_terms'][0]
# Keep band-only old alternatives on the band component, all gates, IDs, exclusions and thresholds.
def diff(a,b,path=''):
 if type(a)!=type(b):return [{'path':path,'old':a,'new':b}]
 if isinstance(a,dict):return sum([diff(a[k],b[k],path+'/'+k) for k in a],[])
 if isinstance(a,list):
  if len(a)!=len(b):return [{'path':path,'old':a,'new':b}]
  return sum([diff(x,y,path+'/'+str(i)) for i,(x,y) in enumerate(zip(a,b))],[])
 return [] if a==b else [{'path':path,'old':a,'new':b}]
proposal={'baseline_commit':'57e29730f0b5c2df336fd1e9dd58374b2025ee03','status':'proposal_only_no_repo_edits','profiles':{k:diff(profiles[k],v) for k,v in new.items()}}
(O/'minimal-field-proposal.json').write_text(json.dumps(proposal,ensure_ascii=False,indent=2)+'\n');(O/'proposed-profiles.json').write_text(json.dumps(list(new.values()),ensure_ascii=False,indent=2)+'\n')
print({k:len(v) for k,v in proposal['profiles'].items()})
