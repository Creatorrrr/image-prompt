from pathlib import Path
import json,sys
O=Path(__file__).parent/'public-cli';left,right=sys.argv[1:3];manifest=json.loads((O/'frozen-input-manifest.json').read_text())
def diff(a,b,p=''):
 if type(a)!=type(b):return [{'path':p,'before':a,'after':b}]
 if isinstance(a,dict):
  out=[]
  for k in sorted(set(a)|set(b)):
   if k not in a or k not in b:out.append({'path':p+'/'+k,'before':a.get(k),'after':b.get(k)})
   else:out+=diff(a[k],b[k],p+'/'+k)
  return out
 if isinstance(a,list):
  if len(a)!=len(b):return [{'path':p,'before':a,'after':b,'array_lengths':[len(a),len(b)]}]
  return sum([diff(x,y,p+'/'+str(i)) for i,(x,y) in enumerate(zip(a,b))],[])
 return [] if a==b else [{'path':p,'before':a,'after':b}]
rows=[]
for c in manifest:
 name=c['case'];a=json.loads((O/left/(name+'-pack.json')).read_text())[0];b=json.loads((O/right/(name+'-pack.json')).read_text())[0];changes=diff(a,b)
 rows.append({'case':name,'change_count':len(changes),'changes':changes});print(name,len(changes));print('\n'.join(x['path'] for x in changes))
(O/right/('comparison-vs-'+left+'.json')).write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
