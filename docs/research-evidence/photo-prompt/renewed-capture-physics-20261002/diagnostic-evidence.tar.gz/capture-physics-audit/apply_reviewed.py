import json,re,hashlib,subprocess
from pathlib import Path
R=Path('REPOSITORY_ROOT');O=Path(__file__).parent;V=O.parent/'capture-physics-review';f=R/'skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations.json'
s=f.read_text();doc=json.loads(s);proposal=json.loads((V/'reviewed-field-proposal.json').read_text());expected={p['id']:p for p in json.loads((V/'reviewed-profiles.json').read_text())}
assert not subprocess.check_output(['git','status','--short'],cwd=R,text=True)
assert all(c['exit_code']==0 for c in json.loads((O/'public-cli/before-904b/run-manifest.json').read_text())['cases'])
dec=json.JSONDecoder();spans={}
def ws(i):
 while s[i].isspace():i+=1
 return i
def scan(i,path):
 i=ws(i);start=i
 if s[i]=='{':
  i=ws(i+1)
  if s[i]!='}':
   while True:
    k,j=dec.raw_decode(s,i);i=scan(ws(j)+1,path+(k,));i=ws(i)
    if s[i]=='}':break
    i=ws(i+1)
  i+=1
 elif s[i]=='[':
  i=ws(i+1);n=0
  if s[i]!=']':
   while True:
    i=scan(i,path+(str(n),));i=ws(i);n+=1
    if s[i]==']':break
    i=ws(i+1)
  i+=1
 else:_,i=dec.raw_decode(s,i)
 spans[path]=(start,i);return i
scan(0,());edits=[]
for pid,changes in proposal['profiles'].items():
 n=next(i for i,p in enumerate(doc['profiles']) if p['id']==pid)
 for ch in changes:
  path=('profiles',str(n))+tuple(ch['path'].strip('/').split('/'));a,b=spans[path];assert json.loads(s[a:b])==ch['old'],path
  edits.append((a,b,json.dumps(ch['new'],ensure_ascii=False)))
for a,b,t in sorted(edits,reverse=True):s=s[:a]+t+s[b:]
updated=json.loads(s)
for p in updated['profiles']:
 if p['id'] in expected:assert p==expected[p['id']]
 else:assert p==next(q for q in doc['profiles'] if q['id']==p['id'])
(O/'registry-before-904b.json').write_bytes(f.read_bytes());f.write_text(s)
(O/'apply-manifest.json').write_text(json.dumps({'baseline':'904b5893c94e2d59d646e977c8400e270635a568','source_file':str(f.relative_to(R)),'reviewed_changes':len(edits),'changed_profiles':list(expected),'source_sha256':hashlib.sha256(f.read_bytes()).hexdigest()},indent=2)+'\n')
print('Applied only',len(edits),'reviewed source spans; non-target profiles structurally identical.')
