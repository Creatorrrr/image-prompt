# Upstream-only840d control

Exact source commit: 840d4b8f0dbcb977b3d02b5dbcce38894bcd0ec4. A git archive of the complete skill was extracted outside the repository. Unmodified upstream public CLI and original real index were used; no synthetic or stale-vector payload, repository mutation, or paid call. Real registry/index validation passed with 1,496 profiles and entries.

All six source-known cases completed with exit 0 into public-cli/before-840d. All 24 immutable raw input hashes were verified before execution and rechecked afterward. Earlier results remain untouched. The run manifest records exact commands and source/index/script hashes; upstream-840d-source-manifest.json records every archived source file hash.

Use this upstream-only control for the eventual merged comparison. Comparison with older904b is retained only as an upstream drift diagnostic, not evidence of a regression caused by our repairs. Changed path counts versus904b: fixed-camera=27, camera-sweep=49, split-optical-transition=6, rolling-combined-control=6, split-middle-control=6, generic-motion-control=17. Full values are in public-cli/before-840d/comparison-vs-before-904b.json. No merged AFTER result is claimed yet.
