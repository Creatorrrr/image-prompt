import json,sys,pathlib
ROOT=pathlib.Path('REPOSITORY_ROOT')
OUT=pathlib.Path(__file__).parent
sys.path.insert(0,str(ROOT/'skills/photo-prompt-image-generator/scripts'))
import prompt_generator as pg
ids=['telephoto_distance_compression_relation','shallow_depth_focus_falloff_relation','focus_stacked_extended_depth_composite','split_diopter_dual_focus_planes','rolling_shutter_readout_skew','highlight_rolloff_tone_response']
reg=pg.load_visual_obligation_registry(ROOT/'skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations.json')
reg={**reg,'profiles':[p for p in reg['profiles'] if p['id'] in ids]}
idx=pg.build_visual_profile_index_payload(reg)
cases=json.loads((OUT/'consumer-probe.json').read_text())
cases.extend({'case':'generic_slot_'+str(i),'text':t} for i,t in enumerate(['macro focus-stacked sharp detail','a split-diopter lens plane','shallow depth of field with strong background blur','subtle smartphone rolling-shutter motion','gradual bright tonal transition into highlights','a 200mm telephoto lens']))
for c in cases:
 res=pg.resolve_visual_profile_hits(reg,[{'source':'concept_lock','text':c['text'],'polarity':'required','priority':'critical','mandatory':True}],visual_profile_index=idx,adult_context=True)
 c['hits']=[{k:h.get(k) for k in ['profile_id','hard_eligible','match_basis','applicability_status']} for h in res['hits']]
 c['hard_obligations']=[pg.candidate_pack_visual_profile_obligation(next(p for p in reg['profiles'] if p['id']==h['profile_id']),reg,activation_source='request_only',source_intent_ids=['probe'],context_text=c['text'],request_text=c['text']) for h in res['hits'] if h.get('hard_eligible')]
(OUT/'materialized-consumer-probe.json').write_text(json.dumps(cases,ensure_ascii=False,indent=2))
for c in cases:print(c['case'],[(h['profile_id'],h['hard_eligible']) for h in c['hits']],len(c['hard_obligations']))
