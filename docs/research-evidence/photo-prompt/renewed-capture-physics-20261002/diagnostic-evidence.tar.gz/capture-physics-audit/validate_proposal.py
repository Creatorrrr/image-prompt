import json,sys
from pathlib import Path
O=Path(__file__).parent;sys.path.insert(0,str(O/'baseline-snapshot/skills/photo-prompt-image-generator/scripts'))
from visual_profile_contracts import compile_visual_profile
from audit_composed_prompt import authorial_evidence_tokens
import prompt_generator as pg
old=json.loads((O/'baseline-snapshot/skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations.json').read_text());olds={p['id']:compile_visual_profile(p) for p in old['profiles']};out=[]
for raw in json.loads((O/'proposed-profiles.json').read_text()):
 p=compile_visual_profile(raw);b=olds[p['id']];groups=p['semantics']['component_semantics']['groups'];r={'profile':p['id'],'preserved':{},'evidence_minima':[],'components':[]}
 for key in ['activation','required_evidence_fields','runtime_expression']:
  r['preserved'][key]=p[key]==b[key];assert r['preserved'][key]
 for key in ['minimum_component_groups','required_group_ids']:
  r['preserved'][key]=p['semantics']['component_semantics'][key]==b['semantics']['component_semantics'][key];assert r['preserved'][key]
 assert [(g['id'],g['review_scale']) for g in p['render_gates']]==[(g['id'],g['review_scale']) for g in b['render_gates']]
 for field,x in p['evidence_requirements'].items():
  assert x['min_content_words']==b['evidence_requirements'][field]['min_content_words']
  counts=[len(authorial_evidence_tokens(t)) for t in x['must_mention_any']];changed=x!=b['evidence_requirements'][field]
  r['evidence_minima'].append({'field':field,'minimum':x['min_content_words'],'anchor_content_counts':counts,'changed':changed})
  if changed:assert max(counts)>=x['min_content_words']
 for lang in [0,1]:
  txt='; '.join(g['any_terms'][lang] for g in groups);positive=bool(pg.candidate_pack_visual_component_match(p,txt));assert positive
  missing=[bool(pg.candidate_pack_visual_component_match(p,'; '.join(g['any_terms'][lang] for j,g in enumerate(groups) if i!=j))) for i in range(len(groups))];assert not any(missing)
  exclusions=[bool(pg.candidate_pack_visual_component_match(p,txt+'; '+t)) for t in p['activation']['exclude_if_any_terms']];assert not any(exclusions)
  r['components'].append({'language':lang,'positive':positive,'missing_group_matches':missing,'affirmative_exclusion_matches':exclusions})
 out.append(r)
(O/'proposal-static-validation.json').write_text(json.dumps(out,indent=2)+'\n');print('Preserved activation, IDs, gates/scales and thresholds; positive EN/KO, missing-component, exclusion controls passed. Changed evidence anchors meet minima.')
