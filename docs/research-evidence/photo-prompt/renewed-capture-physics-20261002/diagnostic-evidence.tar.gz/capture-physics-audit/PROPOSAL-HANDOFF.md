> Historical pre-review artifact. Initial proposed profiles and their evidence-floor/compatibility claims are superseded by capture-physics-review/REVIEW.md and its exact token counts. The initial proposal lost valid old component/evidence alternatives and was not applied. See PUBLIC-AFTER-RESULT.md for the exact reviewed repair and actual public-CLI results.

# Two-candidate DATA proposal and frozen public-CLI BEFORE

## Ready for review

- `minimal-field-proposal.json`: exact old/new JSON-pointer leaves, relative to each source profile. Rolling shutter: 17 changed leaves. Split diopter: 6 changed leaves.
- `proposed-profiles.json`: complete proposed source profiles. This is a proposal outside the repository, not applied DATA.
- `propose_fields.py`: reproducible derivation from published `57e29730`; never reads a possibly modified working-tree registry for the proposal.
- `public-cli/frozen-input-manifest.json`: six source-known diagnostic cases, with four raw contracts each and byte hashes.
- `public-cli/before/`: complete normal CLI packs, stdout, stderr and run manifest. All six exited 0.
- `run_before.py`: replays frozen input bytes through the unmodified public CLI in `baseline-snapshot`. It verifies original registry/index/script bytes against Git commit 57e29730 first.
- `proposal-static-validation.json` / `validate_proposal.py`: real compiler and component consumer checks, not a mocked matching function.

## Why a snapshot was used

The shared working tree acquired unrelated remaining-boundary registry/index changes before the first CLI execution. The clean-tip assertion stopped that attempt. A `git archive 57e29730 skills/photo-prompt-image-generator` snapshot was created outside the repository. Its actual full published index and source/scripts are unmodified. The normal `generate_photo_prompt.py` CLI loaded runtime data normally from that snapshot. No sliced or synthetic index was used for these BEFORE runs. Earlier sliced probes in this folder are supplementary and are not the baseline evidence.

The initial input-construction attempt was rejected before any CLI execution for a missing concept lock; the second for insufficient style evidence. Both were corrected before freezing the complete four-contract files and producing any BEFORE pack. The final input manifest is authoritative. Do not rerun `freeze_before.py` to modify those inputs. It retains a shared-tree clean-tip guard and is an input-construction record; use `run_before.py` for replay.

## Measured BEFORE results

1. `fixed-camera`: rolling profile hard obligation. Background-lean gate conflicts with fixed camera and upright stationary posts.
2. `camera-sweep`: rolling profile hard obligation. Fast-moving-subject gate conflicts with an entirely stationary scene whose image motion comes from the camera.
3. `split-optical-transition`: split-diopter hard obligation. Materialized middle-depth-band instruction/gate conflicts with the selected optical-transition-only alternative already allowed by the definition and evidence phrase.
4. `rolling-combined-control`: rolling profile hard obligation. Both scene structures and the unmanned car have relative image motion; original intended simultaneous depiction remains possible.
5. `split-middle-control`: split-diopter hard obligation. Original softer middle-depth band stays valid.
6. `generic-motion-control`: no hard obligations. Ordinary exposure-time motion blur is not newly made into a rolling-shutter profile.

Baseline prose is positive and scene-specific, approximately 120–150 words per case. Bodies are not depicted: model cars are explicitly unmanned, and the other cases are empty architecture or still-life objects. Embodiment applicability is therefore explicitly reviewed as not applicable, with explanation and hash bound to the exact baseline. This is an authored text review, not pixel evidence.

## Minimal semantic migration

Rolling: retain five simultaneous required groups, but their structural/form groups describe geometry consistent with relative camera motion rather than require two independent physical motion owners. Staggered **row exposures**, rather than serial readout alone, own the geometry. Static objects seen by a fixed camera remain stable; a camera sweep can shear a static scene. A visible moving-image form still must shear, and crisp detail, progressive readout-axis displacement and existing substitute boundaries remain required. The old `single_bent_object` negative is replaced only with arbitrary bending lacking coherent motion-related shear, because a genuinely moving isolated form is physically valid. This does not expand into rolling banding, propeller segmentation or arbitrary wobble.

Split: retain the already-present band-or-optical-transition alternative consistently in concept, instruction, render gate and boundary evidence. The near/far critical anchors and continuous scene are unchanged. No hidden-seam/no-visible-transition regime is added. Existing band-only alternatives remain valid; the definition already allowed the newly consistent alternative.

## Preserved and checked

Activation aliases/exclusions/adult/discovery guards; runtime labels; five group IDs and minimum required count; required evidence fields and word thresholds; gate IDs and scales are identical. EN/KO full components pass; removal of each group fails; affirmative exclusions block. Changed rolling evidence anchors meet their current content-word minima. Some unchanged old rolling anchors are shorter than their field minimum on their own: those bindings already require additional concrete scene words. Their thresholds were not weakened and this proposal does not claim anchor-only evidence is a valid complete binding.

## Runtime boundary

No new runtime logic is required for this DATA proposal: the existing compiler/materializer copies these instructions and evidence alternatives, and pixel/prompt review interprets the described causal relationships. This proposal does not implement an algorithm that classifies camera motion or computes optical flow from prose/images. If the desired behavior instead demands automatic branch-specific gate removal, background ownership inference, or direction/sign calculation, that requires runtime work and is outside this minimal change. We deliberately keep all five gates with physically conditional ownership language rather than claim such automatic selection exists.

## Remaining verification before adoption

Apply only after review, refresh the actual derived index under the project's established process, then replay these immutable 24 raw input files with the actual published CLI and compare entire packs. Confirm target obligation fields change as proposed, generic-motion stays unactivated, combined-motion and middle-band positives remain usable, and all other candidate IDs/order/counts are measured for drift. Run composed-prompt literal-evidence audit with source-specific complete bindings and dictionary/schema/capture regressions. No full-index AFTER result or pixel-quality improvement is claimed here. No paid API or image calls were made.
