import json,subprocess,sys,hashlib
from pathlib import Path
R=Path('REPOSITORY_ROOT');P=Path(__file__).resolve().parent;sys.path.insert(0,str(R/'skills/photo-prompt-image-generator/scripts'));import prompt_generator as pg
f='skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations.json';i=str(Path(f).with_name('photo_prompt_visual_profile_index.json'));up='840d4b8f0dbcb977b3d02b5dbcce38894bcd0ec4';base='904b5893c94e2d59d646e977c8400e270635a568';ours='5167491e';
def load(ref,path):return json.loads(subprocess.check_output(['git','show',ref+':'+path],cwd=R))
def merge(b,o,t,path=''):
 if o==b:return t
 if t==b or o==t:return o
 if isinstance(b,dict) and isinstance(o,dict) and isinstance(t,dict) and b.keys()==o.keys()==t.keys():return {k:merge(b[k],o[k],t[k],path+'/'+k) for k in b}
 if isinstance(b,list) and isinstance(o,list) and isinstance(t,list) and len(b)==len(o)==len(t):return [merge(v,o[j],t[j],path+'/'+str(j)) for j,v in enumerate(b)]
 raise AssertionError('Overlapping conflict: '+path)
b,o,t=load(base,f),load(ours,f),load(up,f);assert [p['id'] for p in b['profiles']]==[p['id'] for p in t['profiles']];n=json.loads((R/f).read_text());assert n==merge(b,o,t)
ids={'rolling_shutter_readout_skew','split_diopter_dual_focus_planes'};assert {p['id']:p for p in t['profiles'] if p['id'] not in ids}=={p['id']:p for p in n['profiles'] if p['id'] not in ids}
reg=pg.load_visual_obligation_registry(R/f);idx=pg.load_visual_profile_index(R/i,reg);old=load(up,i);assert old['entries'].keys()==idx['entries'].keys();changed=[k for k in old['entries'] if old['entries'][k]!=idx['entries'][k]];assert set(changed)==ids
changed_paths=subprocess.check_output(['git','diff','--name-only',up],cwd=R,text=True).splitlines();assert set(changed_paths)=={f,i,'tests/test_photo_capture_physics_alternatives.py'}
result={'upstream_parent':up,'local_data_parent':subprocess.check_output(['git','rev-parse',ours],cwd=R,text=True).strip(),'common_base':base,'exact_structural_three_way_merge':True,'all_upstream_non_target_profiles_preserved':True,'all_other_upstream_blobs_preserved':True,'changed_paths_before_report':changed_paths,'visual_profiles':len(reg['profiles']),'changed_entries_vs_upstream':changed,'unchanged_upstream_entries':len(old['entries'])-2,'rolling_vector_reused_from_legitimate_local_cache':True,'combined_split_vector_refreshed':True,'registry_sha256':idx['registry_sha256']}
(P/'capture-physics-audit/merged-validation/merge-proof.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
