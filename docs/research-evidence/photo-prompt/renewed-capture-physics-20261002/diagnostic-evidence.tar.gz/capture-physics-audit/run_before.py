from pathlib import Path
import json,hashlib,subprocess,sys,os
O=Path(__file__).parent;R=O/'baseline-snapshot';P=O/'public-cli';D=P/'before';D.mkdir(exist_ok=True)
manifest=json.loads((P/'frozen-input-manifest.json').read_text());repo=Path('REPOSITORY_ROOT')
files=['skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations.json','skills/photo-prompt-image-generator/assets/photo_prompt_visual_profile_index.json','skills/photo-prompt-image-generator/scripts/generate_photo_prompt.py','skills/photo-prompt-image-generator/scripts/prompt_generator.py']
meta={'baseline_commit':'57e29730f0b5c2df336fd1e9dd58374b2025ee03','execution':'unmodified normal public CLI in clean git-archive snapshot; original full real index, no mocks','hashes':{},'cases':[]}
for f in files:
 b=(R/f).read_bytes();assert b==subprocess.check_output(['git','show','57e29730:'+f],cwd=repo);meta['hashes'][f]=hashlib.sha256(b).hexdigest()
for c in manifest:
 case=c['case'];I=P/'inputs'/case
 for n,h in c['inputs'].items():assert hashlib.sha256((I/n).read_bytes()).hexdigest()==h
 cmd=[sys.executable,str(R/'skills/photo-prompt-image-generator/scripts/generate_photo_prompt.py'),'--seed',str(c['seed'])]
 for a in ['request-envelope','authorial-core','creative-controls','embodiment-review']:cmd+=['--'+a+'-json',str(I/(a+'.json'))]
 cmd+=['--output-file',str(D/(case+'-pack.json'))];p=subprocess.run(cmd,cwd=R,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},capture_output=True,text=True,timeout=240)
 (D/(case+'.stdout')).write_text(p.stdout);(D/(case+'.stderr')).write_text(p.stderr)
 row={'case':case,'command':cmd,'exit_code':p.returncode}
 if p.returncode==0:
  pack=json.loads((D/(case+'-pack.json')).read_text())[0];obs=pack.get('visual_obligations',{}).get('obligations',[])
  row['obligation_ids']=[o['id'] for o in obs];row['target_obligation']=next((o for o in obs if o['id']==c['target_profile']),None)
 meta['cases'].append(row);(D/'run-manifest.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n');print(case,p.returncode,flush=True)
 if p.returncode:print(p.stderr,flush=True)
assert all(c['exit_code']==0 for c in meta['cases'])
