"""In-memory counterfactuals only; never writes catalog sources."""
import copy,json,sys
from pathlib import Path
ROOT=Path('REPOSITORY_ROOT'); S=ROOT/'skills/photo-prompt-image-generator';sys.path.insert(0,str(S/'scripts'))
import prompt_generator as pg
r=pg.load_visual_obligation_registry(S/'assets/photo_prompt_visual_obligations.json');idx=pg.build_visual_profile_index_payload(r)
U='inverted_triangle_upper_body_dominant_relation'; L='triangle_lower_body_dominant_relation'
ps={p['id']:p for p in r['profiles']}; cases={
 'triangle':'adult triangle body shape', 'pear':'adult pear body shape', 'pear_shaped':'adult pear-shaped figure',
 'inverted_body':'adult inverted triangle body shape', 'inverted_figure':'adult inverted triangle figure',
 'upper_label':'adult upper-body dominant triangle figure', 'korean':'성인 역삼각형 체형',
 'natural_upper':'An adult viewed from the front, with shoulders and rib cage broader than the hips, tapering toward a narrower pelvis.',
 'natural_lower':'An adult viewed from the front, with hips and upper thighs broader than the shoulders and rib cage.',
 'natural_ambiguous':'An adult viewed from the front, with balanced shoulders and hips and a gently defined waist.',
 'mixed_labels':'adult inverted triangle figure and triangle body shape',
 'mixed_pear':'adult inverted triangle figure and pear body shape',
 'mixed_explicit_lower':'adult inverted triangle figure and lower-body dominant triangle figure',
 'either':'adult inverted triangle figure or triangle body shape',
 'contradictory_lower':'adult inverted triangle figure, with hips much wider than shoulders and rib cage',
 'two_people':'One adult has an inverted triangle body shape; another adult has a triangle body shape.',
 'geometry':'adult inverted triangle figure and inverted triangle geometry',
 'logo':'adult inverted triangle figure and inverted triangle logo',
}
for name,pid in [('component_upper',U),('component_lower',L)]:
 cases[name]='; '.join(g['any_terms'][0] for g in ps[pid]['semantics']['component_semantics']['groups'])
cases['upper_components_triangle']=cases['component_upper']+'; triangle body shape'
cases['upper_components_pear']=cases['component_upper']+'; pear body shape'
cases['mixed_components']=cases['component_upper']+'; '+cases['component_lower']
variants={'current':r}
for name,replacement in [('narrow_explicit_lower','lower-body dominant triangle figure'),('remove_control',None)]:
 v=copy.deepcopy(r);p=next(x for x in v['profiles'] if x['id']==U);g=p['activation']['exclude_if_any_terms'];g[g.index('triangle body shape'):g.index('triangle body shape')+1]=[replacement] if replacement else [];variants[name]=v
out={'flags':{pid:ps[pid]['activation'] for pid in [U,L]},'cases':cases,'variants':{}}
for vn,reg in variants.items():
 pp={p['id']:p for p in reg['profiles']}; rows=[]
 for name,text in cases.items():
  resolution=pg.resolve_visual_profile_hits(reg,[{'source':'user_requirement','text':text}],visual_profile_index=idx,adult_context=True,query_fields={'active_request':text})
  rows.append({'case':name,'hits':[{k:h.get(k) for k in ['profile_id','match_basis','applicability_status','applicability_reason','hard_eligible','optional_eligible']} for h in resolution['hits'] if h['profile_id'] in [U,L]],'components':{pid:pg.candidate_pack_visual_component_match(pp[pid],text) for pid in [U,L]},'applicability':{pid:{'without_core':pg.visual_profile_context_applicability(pp[pid],text,has_authorial_core_context=False),'with_core':pg.visual_profile_context_applicability(pp[pid],text,has_authorial_core_context=True)} for pid in [U,L]},'bm25f_evaluated':resolution['bm25f_evaluated'],'embedding_evaluated':resolution['embedding_evaluated']})
 out['variants'][vn]=rows
print(json.dumps(out,ensure_ascii=False,indent=2))
