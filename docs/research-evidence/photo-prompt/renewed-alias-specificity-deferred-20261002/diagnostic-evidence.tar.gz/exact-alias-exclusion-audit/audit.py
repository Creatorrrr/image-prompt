"""Read-only exact-term/own-exclusion audit; no provider or vector calls."""
import json
import sys
from pathlib import Path
ROOT = Path('REPOSITORY_ROOT')
SKILL = ROOT / 'skills/photo-prompt-image-generator'
sys.path.insert(0, str(SKILL / 'scripts'))
import prompt_generator as pg
registry = pg.load_visual_obligation_registry(SKILL / 'assets/photo_prompt_visual_obligations.json')
index = pg.build_visual_profile_index_payload(registry)
collisions = []
alias_count = 0
for profile in registry['profiles']:
    activation = profile.get('activation', {})
    disambiguation = activation.get('context_disambiguation', {})
    for alias in activation.get('exact_terms', []):
        alias_count += 1
        for lane, guards in [('activation', activation.get('exclude_if_any_terms', [])), ('context_disambiguation', disambiguation.get('exclude_if_any_terms', []))]:
            for guard in guards:
                if pg.intent_alias_matches(alias, guard):
                    collisions.append({'profile_id': profile['id'], 'alias': alias, 'guard': guard, 'lane': lane, 'context_required': disambiguation.get('required_with_authorial_core'), 'applicability_with_core': pg.visual_profile_context_applicability(profile, alias, has_authorial_core_context=True)})
proof = []
target = 'inverted_triangle_upper_body_dominant_relation'
for text in ['inverted triangle body shape', 'adult inverted triangle body shape', 'adult inverted triangle figure', 'adult triangle body shape']:
    result = pg.resolve_visual_profile_hits(registry, [{'source': 'user_requirement', 'text': text}], visual_profile_index=index, adult_context=True)
    proof.append({'text': text, 'adult_context': True, 'target_hits': [h for h in result['hits'] if h['profile_id'] == target]})
print(json.dumps({'profile_count': len(registry['profiles']), 'exact_alias_count': alias_count, 'collisions': collisions, 'resolver_proof': proof}, ensure_ascii=False, indent=2))
