# Separate DATA-option diagnosis

## Recommendation

Defer this alias contradiction from a narrow DATA-only fix. The overlapping exclusion is not redundant under the current consumers. Restoring the valid exact alias while preserving exclusion of an independently mentioned opposite label requires occurrence/span-aware matching or precedence work in the runtime. Do not drop the valid alias or automatically delete its opposite-label guard.

A robust runtime design would distinguish the occurrence of `triangle body shape` nested inside the positive `inverted triangle body shape` from a separate occurrence of `triangle body shape` elsewhere in the request. Global longest-string preference alone would be insufficient if it also suppressed a separate contradictory label. Entity-scoped mixed requests are another concern; the current applicability check pools context globally.

## Current positive evidence gates

Both upper/inverted and lower/triangle profiles have `requires_adult_character: true`. Neither has `hard_activation`, `context_disambiguation`, or `semantic_discovery_requires_component_evidence`.

Both declare four required component groups with minimum four, but these govern `candidate_pack_visual_component_match`, not exact eligibility. The exact lane calls `hard_activation_is_supported`, which returns true if its policy is absent. Semantic applicability only requires component matching when the explicit semantic flag is true. Consequently neither lane is currently protected by positive geometric proof. Supplying authorial-core context changes nothing for these profiles because no disambiguation policy is declared.

## In-memory experiments

`options_probe.py` compares the untouched registry, replacement of the one guard with the existing opposite profile's exact alias `lower-body dominant triangle figure`, and removal as an experimental control. The control is not a recommendation. No source files are mutated. All other guards remain intact.

Production consumers used: `resolve_visual_profile_hits`, actual BM25F query field `active_request`, `visual_profile_context_applicability` with and without core context, and `candidate_pack_visual_component_match`. Adult context is explicitly true. A production-built full index is reused because positive index content and exact aliases are unchanged by the counterfactual guard edits. No vectors/provider calls; embedding_evaluated is false throughout. Results are in `options-evidence.json`, 23 cases per variant.

Key actual eligibility outcomes:

- Standalone `adult triangle body shape`: current lower profile is hard-eligible and inverted profile is absent; narrowing/removal preserves the lower hit but adds inverted as BM25F optional-eligible. Thus the guard is not redundant even for a standalone opposite label.
- Standalone `adult pear body shape`: lower only, both before and after, because the independent pear exclusion is preserved.
- `adult inverted triangle body shape`: current inverted exact hit is request_exclusion; narrowing/removal makes it required/hard-eligible. The lower profile remains excluded by its `inverted triangle` guard.
- `adult inverted triangle figure`: required/hard-eligible throughout, despite no component match. The existing sibling alias demonstrates the current label-only contract.
- `adult inverted triangle figure and triangle body shape`, and the same with `or`: currently both exact matches are excluded; narrowing/removal makes inverted hard-eligible. No positive gate protects these mixed/ambiguous requests.
- Two explicitly different adults, one inverted and one triangle: current global exclusions block both; narrowing/removal makes inverted hard-eligible while lower remains blocked. Narrowing does not supply subject ownership or principled disambiguation.
- `adult inverted triangle figure and pear body shape`: both remain excluded, demonstrating retained pear-guard behavior.
- `adult inverted triangle figure and lower-body dominant triangle figure`: narrowing newly excludes inverted; current/removal makes inverted hard-eligible. The replacement trades which contradictory wording is caught rather than preserving scope.
- Natural upper-body prose (shoulders/rib cage broader than hips, tapering to narrower pelvis): BM25F optionally retrieves both profiles in all variants; neither component matcher qualifies. Natural lower-body prose retrieves lower only. Balanced/ambiguous prose retrieves neither. No exact hard obligations arise from those natural prose examples.
- Complete catalog-authored upper components: upper component match succeeds, lower fails, but BM25F optionally retrieves both. Complete lower components: lower component match succeeds, upper fails, yet BM25F still optionally retrieves both. These are existing behaviors, not regressions introduced by the counterfactual.
- Complete upper components plus `triangle body shape`: current upper component matching is blocked by the guard; narrowing/removal restores its component match and optional BM25F hit while the lower label remains hard-eligible. This also shows why component matches alone cannot arbitrate conflicting labels.
- Mixed complete upper and lower component statements: both match components and both are optional-eligible, all variants. Positive presence cannot establish absence of a contradictory relation.
- Geometry/logo exclusions continue to reject the upper exact label in all variants.

A Korean positive-label case also currently activates both profiles, because `삼각형 체형` is nested in `역삼각형 체형` and the lower profile's English inverse guard does not match that Korean context. This is a separate overlap symptom discovered incidentally, not an additional own-exclusion finding or a DATA repair proposal.

## Why the other DATA switches do not preserve the present contract

- Adding `semantic_discovery_requires_component_evidence` could suppress unsupported optional opposite-label retrieval, but it cannot change exact-lane mixed-label hard eligibility. It would also change discovery behavior and needs its own independent coverage.
- Adding a hard-activation component policy could require positive upper geometry, but bare valid aliases would stop being hard-eligible; additionally a request can contain both positive upper geometry and contradictory lower geometry. This is a material contract change, not an equivalent repair.
- Context disambiguation is conditional on authorial-core context; without core it cannot repair the exact-only path. Positive any-term lists cannot distinguish a nested negative occurrence from an independent one.
- Appending more confound phrases substitutes an expanding lexical exception list for occurrence-aware semantics and still misses mixed uses of the original bare label.

Original defect proof remains in README.md/evidence.json; these option findings supersede its tentative 'remove or replace' direction. No catalog repair is endorsed by this diagnosis.
