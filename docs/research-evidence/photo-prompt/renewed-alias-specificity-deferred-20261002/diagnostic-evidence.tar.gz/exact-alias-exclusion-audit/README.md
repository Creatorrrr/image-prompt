# Exact-alias exclusion audit

Read-only audit of main 99ebda65 plus existing pending positive-source corrections, 2026-10-02. No repository source mutations, provider calls, embeddings, or fabricated vectors. The complete compiled registry contains 1,496 profiles and 3,609 activation exact terms.

## Confirmed finding (one)

Profile: `inverted_triangle_upper_body_dominant_relation`.

The declared positive exact alias `inverted triangle body shape` contains and boundary-matches its own negative guard `triangle body shape`. The actual `intent_alias_matches` consumer returns true. The shared applicability consumer rejects it as `request_exclusion`; the actual resolver emits an exact hit with `context_mismatch`, `hard_eligible: false`, and `optional_eligible: false`.

This remains true for `adult inverted triangle body shape` with `adult_context=True`; it is not an adult-context failure or missing-positive-context issue. The alternative declared alias `adult inverted triangle figure` resolves as required and hard eligible, establishing that this is an alias-specific contradiction rather than an unreachable profile generally.

Provenance:
- `skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations.json:8790`: profile ID
- Same source, line 8794: positive exact alias
- Same source, line 8803: overlapping exclusion guard
- `scripts/prompt_generator.py:2702`: boundary/negation-aware literal matching
- Same script, line 6195: shared context applicability; exclusion wins before other checks
- Same script, line 6315: resolver, whose exact lane applies that shared context check

Fix direction: remove or replace the overbroad bare `triangle body shape` guard with an explicitly lower-body-dominant confound phrase. Retain negative checks for triangle geometry/logo and pear body shape. Verify the target alias becomes eligible while genuine lower-body-dominant confounds remain excluded. No fix was applied in this audit.

## Coverage and limits

Every compiled activation exact term was tested against the profile's own activation exclusions and context-disambiguation exclusions using the production matcher (not substring heuristics). Exactly one overlap was found. Context-disambiguation restrictions were inspected with authorial-core context enabled; there were no hits in that lane. Project-glossary aliases, component/paraphrase positives, generic ambiguity, missing positive context, and age guards are outside this audit's defect scope. The three pending component/paraphrase repairs were not duplicated.

`audit.py` is the reproducible read-only scan and resolver proof; `evidence.json` contains its compact output. Rerunning after edits will naturally report the changed registry rather than this snapshot's result.
