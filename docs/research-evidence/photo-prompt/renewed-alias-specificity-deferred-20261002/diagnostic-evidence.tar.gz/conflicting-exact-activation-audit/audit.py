import sys,json,re,collections,pathlib
root=pathlib.Path('REPOSITORY_ROOT')
sys.path.insert(0,str(root/'skills/photo-prompt-image-generator/scripts'))
import prompt_generator as p
reg=p.load_visual_obligation_registry(root/'skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations.json')
rows=p.visual_profile_exact_term_rows(reg)
def norm(t):return p.clean_spaces(re.sub(r'[-\u2013\u2014/]+',' ',t.lower().replace('_',' ')))
normalized=[(r,norm(r['term'])) for r in rows]
index={'exact_lookup':rows,'entries':{},'retrieval_policy':{}}
found=[]
for term in sorted(set(r['term'] for r in rows)):
 n=norm(term)
 matches=[r for r,a in normalized if a in n and p.intent_alias_matches(term,r['term'])]
 if len(set(r['profile_id'] for r in matches))<2:continue
 result=p.resolve_visual_profile_hits(reg,[{'source':'user_requirement','text':term}],visual_profile_index=index,adult_context=True)
 if not found: print('RESULT_KEYS',list(result))
 hits=[h for h in result.get('hits',[]) if h.get('hard_eligible')]
 if len(hits)<2:continue
 obligations=[]
 for h in hits:
  profile=p.visual_obligation_profile_by_id(reg,h['profile_id'])
  ob=p.candidate_pack_visual_profile_obligation(profile,reg,activation_source='exact',source_intent_ids=h['source_intent_ids'],context_text=term,request_text=term)
  obligations.append(ob)
 found.append({'term':term,'matching_terms':matches,'hard_profile_ids':[h['profile_id'] for h in hits],'projected_contracts':[{'id':o['id'],'composition_instruction':o['composition_instruction'],'render_gates':o['render_gates']} for o in obligations]})
 print(term,'=>',','.join(h['profile_id'] for h in hits))
out=pathlib.Path('EVIDENCE_ROOT/conflicting-exact-activation-audit')
(out/'overlaps.json').write_text(json.dumps(found,ensure_ascii=False,indent=2))
print('PROFILES',len(reg['profiles']),'ROWS',len(rows),'OVERLAPS',len(found))
