exec(open('EVIDENCE_ROOT/conflicting-exact-activation-audit/audit.py').read().split('found=[]')[0])
terms=['몸판에서 긴 두 바짓가랑이로 이어지는 원피스형 의복','long square face shape','살아있는 갑옷','과거 선박 연속성이 갈라지는 유령선','유령 환등 공연']
res=[]
for term in terms:
 r=p.resolve_visual_profile_hits(reg,[{'source':'user_requirement','text':term},{'source':'authorial_core_appearance','text':term}],visual_profile_index=index,adult_context=True)
 row={'term':term,'hits':r['hits']};res.append(row);print(json.dumps(row,ensure_ascii=False),flush=True)
pathlib.Path('EVIDENCE_ROOT/conflicting-exact-activation-audit/context-probes.json').write_text(json.dumps(res,ensure_ascii=False,indent=2))
