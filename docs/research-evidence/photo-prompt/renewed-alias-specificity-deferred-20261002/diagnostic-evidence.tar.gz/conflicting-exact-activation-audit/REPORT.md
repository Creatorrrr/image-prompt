# Conflicting exact activation audit

Result: **no safe data-only patch recommended** at commit `b85dcbca`.

## Method and boundaries

Loaded the complete registry through `load_visual_obligation_registry`: 1,496 profiles and 3,624 exact/glossary lookup rows. Checked duplicate phrases including the runtime matcher's lowercasing, whitespace, dash/slash and underscore normalization. There were **zero cross-profile duplicated strings**. Checked nested exact matches with `intent_alias_matches`, then called the real `resolve_visual_profile_hits` with request-scoped input, adult context, and a provider-free exact-only lookup index. No embeddings, fake vectors or BM25F hits were used. Projected every co-hard result with `candidate_pack_visual_profile_obligation`; retained concise instructions and gates in `overlaps.json`.

The nested scan found 26 possible profile-pair relationships and 30 phrases with multiple mandatory profiles in exact-only diagnostics. This is not 30 contradictions: related garment structures, double peace signs, and toe squats are compatible. For example, grounded squat requires both feet to supply the base, not flat heels, so toe-squat clearance is compatible. Loose historical qipao and qipao closure construction are also compatible.

## Candidates rejected after context checks

`context-probes.json` repeats five potentially conflicting phrases with a same-owner authorial-core appearance row, triggering the production context-disambiguation mechanism.

- Korean long-trouser one-piece phrase (`clothing_ct019_v1`) versus `one_piece_dress_construction`: the dress becomes `context_disambiguation_mismatch`; only the trouser-branch profile is mandatory. The Korean phrase is authored in clothing extension entry `clt_ct019_v1`, and its exact/hard/component terms agree. Replacing its phrase to evade substring matching is not justified as a collision repair.
- `살아있는 갑옷`: hollow articulated living armor remains mandatory; wearable armor is context-mismatched. Do not delete the common armor alias.
- Ghost-ship phrases and projected spectral performance: the human-ghost contract is context-mismatched; the intended nonhuman/profile owner remains mandatory.

## Runtime-only residual, not a data patch proposal

`long square face shape` (also Korean `직사각형 얼굴형` and Chinese `长方形脸`) matches both rectangular and square face profiles. Even with authorial-core context, both are mandatory. Actual gates disagree on the same face:

- `vo_face_square_vertical_relation`: length remains close to width rather than distinctly elongated
- `vo_face_rectangular_vertical_relation`: clearly longer than wide rather than compact-square

Each authored meaning is coherent; the nested matching semantics combine them. Dropping popular square aliases or deleting multilingual rectangle labels would hide the issue. A growing phrase-specific exclusion list would repeat the already-deferred inverted-triangle failure mode. This belongs with owner-aware nested-specificity/runtime resolution, followed by same-owner and separate-owner controls. No source edit is recommended here.

The already known inverted-triangle nested issue was not proposed as new work. No deliberately authored multi-axis combination was treated as a defect.

## Files and reproducibility

- `audit.py`: complete exact-lane nested scan and actual obligation projection
- `overlaps.json`: compact co-hard evidence, not a registry snapshot
- `context_probe.py`: five real resolver context checks
- `context-probes.json`: full status outputs for those checks

Source references: `scripts/prompt_generator.py` (`visual_profile_exact_term_rows`, `intent_alias_matches`, `visual_profile_context_applicability`, `resolve_visual_profile_hits`, `candidate_pack_visual_profile_obligation`); `assets/photo_prompt_visual_obligations.json`; `assets/photo_prompt_visual_obligations_clothing_structure.json`; `assets/photo_prompt_clothing_structure_extension.json`. Paths are relative to `skills/photo-prompt-image-generator/` inside the repository. No source files changed, no providers called, no index regeneration.
