"""Mechanical comparison and lossless preparation only; no semantic classification or approval."""
import json,gzip,hashlib
from pathlib import Path
R=Path(__file__).resolve().parents[1];A=R/'authored';W=R/'worker-notes'
canon=lambda x:hashlib.sha256(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
raw=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
P=A/'native_08250_06250_07250.prepared.json';old=json.loads(P.read_text())
C=R/'native-inputs/root-diagnostic6-kind-source-plan-23/CURRENT-PROPOSAL.json.gz';cur=json.loads(gzip.decompress(C.read_bytes()))
assert canon(cur).startswith('39ab970e')
cat=R/'CATALOG-FINAL-149-V6.json';catalog=json.loads(cat.read_text());assert canon(catalog)=='d9f4db418e1b63cd100b4c7a9fbff4c8401e00dffeffd22e299a0b5087a82b15'
rows=[]
for o in [6801,6807,6825,6851,6862,6867]:
 s=old['records'][o-6250];cid=s['candidate_id'];dpath=A/f'native_08250_06250_07250.{o//5*5:05}_{o//5*5+5:05}.checkpoint.json';prior=json.loads(dpath.read_text());dr=next(x for x in prior['records'] if x['ordinal']==o)
 own={bid:v for bid,v in cur['slot_bindings'].items() if v['candidate_id']==cid}
 cref={k:cur['candidates'][k] for k in s['complete_reference_records']};bref={k:cur['slot_bindings'][k] for k in s['complete_reference_bindings']}
 loc=s['compiled_review_locator'];f=Path(loc['file']);j=json.loads(f.read_text());row=j
 for k in loc['json_pointer'][1:].split('/'):row=row[int(k)] if isinstance(row,list) else row[k]
 rows.append({'ordinal':o,'candidate_id':cid,'original_prepared_whole_record':s,'old_frozen_draft':{'file':str(dpath),'raw_sha256':raw(dpath),'record_sha256':canon(dr),'whole_record':dr},'latest_current_whole_record':cur['candidates'][cid],'latest_current_own_bindings':own,'latest_complete_reference_records':cref,'latest_complete_reference_bindings':bref,'current_compiled_review':{'locator':loc,'file_raw_sha256':raw(f),'row_sha256':canon(row),'row':row},'exact_equality_checks':{'current_equals_old_exact5Bafter':cur['candidates'][cid]==s['exact_5B_after'],'own_bindings_equal':own==s['all_own_source_bindings'],'all_reference_bodies_equal':cref==s['complete_reference_records'],'all_reference_bindings_equal':bref==s['complete_reference_bindings'],'compiled_review_row_equal':row==s['compiled_5B_review'],'old_draft_source_before_equal':dr['source_before']==s['original_record'],'old_draft_exact5Bafter_equal':dr['exact_5B_after']==s['exact_5B_after']}})
out={'schema':'manual149-small-batch-preparation/v1','task':'/root/review_08250_09250','model':'gpt-6.1-sol','effort':'high','prepared_count':6,'new_unique_source_read_count':0,'formal_input':False,'proof_count':0,'approval_count':0,'source':{'file':str(C),'raw_sha256':raw(C),'canonical_sha256':canon(cur)},'catalog':{'file':str(cat),'raw_sha256':raw(cat),'canonical_sha256':canon(catalog)},'prior_prepared':{'file':str(P),'raw_sha256':raw(P)},'records':rows,'boundary':'Exact equality permits reuse of prior actual whole reads only; no automatic source qualification, role approval, full fact/unit correctness or proof re-sign.'}
p=A/'native_08250_close149_six.prepared-01.json';assert not p.exists();p.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(str(p),raw(p));print(json.dumps([{k:x[k] for k in ['ordinal','candidate_id','exact_equality_checks']} for x in rows],ensure_ascii=False,indent=2))
