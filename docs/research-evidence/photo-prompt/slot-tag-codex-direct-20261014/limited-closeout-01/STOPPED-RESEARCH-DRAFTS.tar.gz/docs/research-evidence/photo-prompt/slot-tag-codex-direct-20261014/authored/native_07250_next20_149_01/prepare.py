"""Root-delegated sparse bookkeeping, actual root read0; no proof or semantic conversion."""
import sys,importlib.abc,json,gzip,pathlib,hashlib
sys.dont_write_bytecode=True
class Block(importlib.abc.MetaPathFinder):
 def find_spec(self,fullname,path=None,target=None):
  if fullname.split('.')[0] in {'photo_local_embedding','torch','transformers','sentence_transformers','tensorflow','jax','mlx'}:raise RuntimeError(fullname)
sys.meta_path.insert(0,Block())
ROOT=pathlib.Path.cwd();R=ROOT/'docs/research-evidence/photo-prompt/slot-tag-codex-direct-20261014';O=R/'authored/native_07250_next20_149_01';G=pathlib.Path('/Users/chasoik/.cache/image-prompt/photo-shared-runtime/generations/fe5b593c819806a31803e40c620e6f2b28c3b54103f451dd6f38920f2d537258');sys.path[:0]=[str(G/'scripts'),str(G/'precore')]
import photo_candidate_corpus as c,photo_semantic_evidence as n
sys.path.insert(0,str(R));import prepare_simple5_and_diagnostic7_root_01 as sparse
# Existing sparse helper's historic default sys.path is not used as an authority.
sys.path[:0]=[str(G/'scripts'),str(G/'precore')]
assert pathlib.Path(c.__file__).is_relative_to(G) and pathlib.Path(n.__file__).is_relative_to(G) and sparse.n is n and sparse.c is c and sparse.nr.native is n
read=lambda p:json.loads(gzip.decompress(p.read_bytes()) if p.suffix=='.gz' else p.read_bytes())
H=lambda b:hashlib.sha256(b).hexdigest()
ref=lambda p:dict(file=str(p.relative_to(ROOT)),file_sha256=H(p.read_bytes()),sha256=c.digest(read(p)))
manifest=read(O/'MANIFEST.json');old=read(R/'SOURCE.json.gz');SFILE=R/'native-inputs/root-handoff-envelope-source-plan-27/CURRENT-PROPOSAL.json.gz';current=read(SFILE)
assert c.digest(current)==manifest['current_source_canonical_sha256'] and c.digest(current['slot_catalog'])==manifest['catalog_canonical_sha256']
base=read(R/'native-inputs/prepared/review05250-simple5-149-01/INPUT.json');assert base['catalog_review']['after']==current['slot_catalog']
out=sparse.prepare_sparse('review07250-next20-149-01',manifest['rows'],old,current,ref(SFILE),base['order'],base['catalog_review'],ref(O/'MANIFEST.json'),task_name='/root/review_07250_08250')
P=ROOT/out/'PREPARATION.json';receipt=read(P);receipt.update(actor='/root',actor_role='orchestration only',root_actual_read_count=0,delegated_preparer=manifest['delegated_preparer'],task_name='/root/review_07250_08250');P.write_bytes(c.canonical_bytes(receipt)+b'\n')
D=dict(schema='photo-native-delegated-preparation-pins/v1',generation=str(G),modules={k:dict(file=m.__file__,raw_sha256=H(pathlib.Path(m.__file__).read_bytes())) for k,m in [('native',n),('corpus',c),('reviews',sparse.nr),('sparse_helper',sparse)]},prepared_path=out,prepared_count=16,actual_read_count=0,actor='/root',actor_role='orchestration only',delegated_preparer=manifest['delegated_preparer'],source27_canonical_sha256=c.digest(current),source1299_unqualified='role_evidence' not in current['candidates']['cand_2e72784a26885ceaa1d645d25bd9a468']['content'],native_proofs_created=0,operating_changes=0)
(O/'PREPARATION-PINS.json').write_text(json.dumps(D,ensure_ascii=False,indent=2)+'\n');print(out);print(json.dumps(D,ensure_ascii=False))
