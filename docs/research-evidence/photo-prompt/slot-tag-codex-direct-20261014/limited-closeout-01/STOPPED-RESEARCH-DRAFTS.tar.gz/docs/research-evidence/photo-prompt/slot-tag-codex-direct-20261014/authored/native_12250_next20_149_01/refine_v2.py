"""Literal complete E anchors/values for the same un-signed20 plans; no native proof or source edits."""
import copy,json,hashlib,gzip,datetime
from pathlib import Path
R=Path(__file__).resolve().parents[2];O=Path(__file__).resolve().parent
def h(x):return hashlib.sha256(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
a=json.loads((O/'PROPOSAL-v1.json').read_text());S=json.loads(gzip.decompress((R/'native-inputs/root-handoff-envelope-source-plan-27/CURRENT-PROPOSAL.json.gz').read_bytes()))
V={
9612:('paraphrases/0',{'ruffle':'narrow_gathered_trim_joins_same_sleeve_border_and_spreads_into_waved_free_edge'}),
9614:('en',{'panel':'same_leggings_front_center_panel_continuous_with_visible_joining_seams_at_sides_instead_of_center'}),
9628:('en',{'blue':'light_clear_blue_only_within_same_selected_shirt_fabric_boundary'}),
9647:('en',{'join':'same_garment_sleeve_and_bodice_meet_along_that_seam','route':'same_sleeve_seam_diagonal_underarm_to_neckline'}),
9663:('en',{'edge':'same_jacket_lower_front_edges_curve_apart_below_fastening_point'}),
9672:('paraphrases/0',{'quilt':'physical_stitched_courses_surround_individual_softly_raised_quilted_areas_on_same_textile'}),
9705:('paraphrases/0',{'slit':'same_free_skirt_bottom_opens_upward_along_side_edge_into_two_separate_finished_margins'}),
9710:('en',{'pleat':'same_jacket_opened_back_pleat_reveals_extra_fabric_beside_shoulder_blade'}),
9718:('en',{'pile_a':'same_velvet_like_panel_dense_short_physical_pile','pile_m':'same_velvet_like_panel_dense_short_physical_pile','optical_a':'same_panel_direction_dependent_light_and_dark_surface_response','optical_m':'same_panel_direction_dependent_light_and_dark_surface_response'}),
9725:('en',{'position':'separate_fringe_strands_hang_from_same_garment_hem','attach':'upper_fringe_ends_attach_along_same_finished_edge','fringe':'separate_attached_fringe_strands_hang_from_same_garment_hem','old':'same_attached_hanging_fringe_strands_not_tassel_or_braid_branch'}),
9751:('en',{'yellow':'pale_warm_yellow_only_local_to_same_selected_cardigan_fabric'}),
9800:('en',{'pattern':'shallow_patterned_recess_field_interrupts_same_metal_surface','relief':'physical_shallow_patterned_recesses_in_same_metal_surface'}),
9831:('en',{'pattern':'dark_narrow_filled_grooves_form_visual_pattern_contrasting_with_same_bright_metal','inlay':'physical_dark_filled_grooves_in_same_bright_metal'}),
9845:('en',{'direction':'several_physical_fabric_pleat_ridges_fold_in_same_direction','attach':'each_same_fabric_pleat_ridge_continues_from_attached_top_toward_free_hem'}),
9850:('en',{'motif':'bright_metallic_line_motif_on_same_dark_metal_flush_looking_and_bounded_to_same_surface','inlay':'bright_metallic_line_inlay_appearance_on_same_dark_metal_flush_looking_within_same_bounded_surface'}),
9856:('en',{'relief_a':'small_physical_pile_loops_project_from_same_terry_fabric_face','topology_a':'small_repeated_projecting_pile_loop_topology_of_same_fabric_face','relief_m':'small_physical_pile_loops_project_from_same_terry_fabric_face','topology_m':'physical_repeated_pile_loop_organization_on_same_fabric_face'}),
9858:('en',{'red':'saturated_red_same_existing_small_bag_surface_forming_localized_red_accent_within_outfit'}),
9866:('en',{'leaves':'deeply_lobed_leaf_shaped_ornamental_forms_project_from_same_declared_object_frame','relief':'same_object_frame_relief_leaf_tips_physically_curl_away_from_frame_surface'}),
9882:('en',{'color':'light_muted_beige_gray_only_on_same_selected_trouser_surface_as_local_lower_garment_color'}),
9888:('embedding_text',{'cells':'colored_recessed_cell_fields_within_same_broad_metal_ground_with_uncut_same_metal_separating_neighbors','enamel':'recessed_enamel_cells_within_same_broad_metal_ground'})}
b=copy.deepcopy(a);b['schema']='photo-worker-next20-source27-149-native-close-proposal/v2';b['prior_v1_sha256']=h(a);b['stop']=datetime.datetime.now(datetime.timezone.utc).isoformat()
for r in b['records']:
 ptr,vals=V[r['ordinal']];src=S['candidates'][r['candidate_id']];text=src['content']
 for k in ptr.split('/'):text=text[int(k)]if isinstance(text,list)else text[k]
 sketches=[];changes=[]
 for f in r.pop('original_E_fact_sketches_with_manual_complete_constraints'):
  constraint=f.pop('manual_complete_value_constraint');f.pop('historical_draft_E_value_retained_for_comparison');old=copy.deepcopy(f);f['pointer']='/content/'+ptr;f['quote']=text;f['value']['value']=vals[f['id']]
  assert {k:v for k,v in f.items() if k not in ['pointer','quote','value']}=={k:v for k,v in old.items()if k not in ['pointer','quote','value']}
  sketches.append(f);changes.append({'fact_id':f['id'],'previous_unqualified_draft_pointer':old['pointer'],'previous_unqualified_draft_quote':old['quote'],'previous_unqualified_draft_value':old['value'],'complete_direct_positive_unit_anchor':f['pointer'],'manually_stated_complete_E_constraint':constraint,'reason':'Fresh unsigned fact sketch uses a complete actual ordinary source unit and manually precise literal value. No canonical source property, actual mutation dimension/target/operation/Rx, source body or conditions are changed. Historical draft value is not an approved fact and is not silently resigned.'})
 r['proposed_actual_E_facts']=sketches;r['unqualified_draft_fact_refinements']=changes
 assert len(sketches)==len(src['effects']['properties'])
 for f in r['proposed_actual_E_facts']+r['proposed_preservation_facts']+r['proposed_prerequisites']:
  value=src
  for part in f['pointer'][1:].split('/'):value=value[int(part)]if isinstance(value,list)else value[part]
  assert f['quote'] in value
 r['positive_unit_closing_plan']='Every complete original EN/KO/embedding/concept/paraphrase/relation and any phrase field stays unchanged. The full ordinary source unit of each actual E/P/PR directly anchors its own fact; remaining exact whole units retain manually judged partial restatement, selected-output-constraint or actual same-owner references. A weaker short clause cannot become full aggregate proof. No final proof or unit signature is written before fresh INPUT.'
b['fact_sketch_boundary']='These final-shaped literal facts are a manual proposal only. No meaning/native contract signature, proof, batch, source selection or acceptance has been generated. Conditions and all actual E addresses/Rx stay source27 exact; fresh INPUT must bind the exact final values and independently check all positive-unit/owner/role scopes.'
p=O/'PROPOSAL-v2.json'
with p.open('x')as f:json.dump(b,f,ensure_ascii=False,sort_keys=True,indent=2);f.write('\n')
print(json.dumps({'canonical':h(b),'raw':hashlib.sha256(p.read_bytes()).hexdigest(),'selected':len(b['records']),'source_changes':0,'proof_signatures':0}))
for r in b['records']:print(json.dumps({'ordinal':r['ordinal'],'actual_owner':r['source_positive_carrier_selection_rationale'],'E':r['proposed_actual_E_facts'],'PR':r['proposed_preservation_facts'],'P':r['proposed_prerequisites'],'roles':r['role_plan']},ensure_ascii=False))
