"""Delegated exact sparse bookkeeping; root orchestration has zero read credit."""
from pathlib import Path
import sys,json,gzip,hashlib,importlib.abc
sys.dont_write_bytecode=True
class Deny(importlib.abc.MetaPathFinder):
 def find_spec(self,fullname,path=None,target=None):
  if fullname.split('.')[0] in {'torch','transformers','sentence_transformers','mlx','mlx_lm','google','openai','anthropic','requests','httpx','urllib3','photo_local_embedding','photo_embedding_provider','photo_model_assets','photo_search_assets'}:
   raise ImportError('provider/model/network import denied: '+fullname)
sys.meta_path.insert(0,Deny())
G=Path('/Users/chasoik/.cache/image-prompt/photo-shared-runtime/generations/fe5b593c819806a31803e40c620e6f2b28c3b54103f451dd6f38920f2d537258')
sys.path[:0]=[str(G/'scripts'),str(G/'precore')]
import photo_candidate_corpus as c,photo_semantic_evidence as n
R=Path('docs/research-evidence/photo-prompt/slot-tag-codex-direct-20261014');D=R/'authored/native_extra_next20_149_01'
sys.path.insert(0,str(R));import prepare_simple5_and_diagnostic7_root_01 as helper
sys.path[:]=[x for x in sys.path if '/photo-shared-runtime/generations/' not in x]
sys.path[:0]=[str(G/'scripts'),str(G/'precore')]
assert helper.c is c and helper.n is n
assert all(Path(m.__file__).resolve().is_relative_to(G) for m in [c,n])
def read(p):
 b=p.read_bytes();return json.loads(gzip.decompress(b) if b[:2]==b'\x1f\x8b' else b)
def ref(p):return {'file':str(p),'file_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'sha256':c.digest(read(p))}
m=read(D/'SELECTION-MANIFEST-v1.json');S=Path(m['source']['file']);current=read(S);original=read(R/'SOURCE.json.gz');assert ref(S)==m['source']
previous_input=read(R/'native-inputs/prepared/review09250-next20-149-01/INPUT.json');assert previous_input['catalog_review']['after']==current['slot_catalog']
rows=[{'ordinal':x['ordinal'],'candidate_id':x['candidate_id'],'locator':x['original_compiled_locator'],'packet':x['original_packet']} for x in m['rows']]
before=c.digest(current)
out=helper.prepare_sparse('reviewnative-next20-149-01',rows,original,current,ref(S),m['order'],previous_input['catalog_review'],ref(D/'SELECTION-MANIFEST-v1.json'),task_name='/root/native_evidence')
assert before==c.digest(current)
modules={name:{'file':str(Path(mod.__file__).resolve()),'file_sha256':hashlib.sha256(Path(mod.__file__).read_bytes()).hexdigest()} for name,mod in sys.modules.copy().items() if name.startswith('photo_') and getattr(mod,'__file__',None)}
assert all(Path(v['file']).is_relative_to(G) for v in modules.values()),modules
v={'schema':'photo-native-delegated-sparse-preparation-attestation/v1','actor':'/root','actor_role':'orchestration','root_actual_read_count':0,'delegated_preparer_task':'/root/native_evidence','task_name':'/root/native_evidence','model':'gpt-6.1-sol','reasoning_effort':'high','authorization':'Exact parent next20/source27 task delegated sparse preparation; source remains byte-identical.','prepared_directory':out,'prepared_count':20,'actual_read_count_from_preparation':0,'proofs_created':0,'source_changes':0,'engine_changes':0,'network_calls':0,'provider_calls':0,'model_calls':0,'Gemini_calls':0,'helper':{'file':helper.__file__,'file_sha256':hashlib.sha256(Path(helper.__file__).read_bytes()).hexdigest()},'actual_modules':modules,'source':ref(S),'manifest':ref(D/'SELECTION-MANIFEST-v1.json')}
with (D/'PREPARER-ATTESTATION-v1.json').open('x') as f:f.write(json.dumps(v,ensure_ascii=False,sort_keys=True,indent=2)+'\n')
print(json.dumps({'prepared_directory':out,'prepared_count':20,'preparation_read_credit':0,'source_sha256':before,'modules':modules},ensure_ascii=False))
