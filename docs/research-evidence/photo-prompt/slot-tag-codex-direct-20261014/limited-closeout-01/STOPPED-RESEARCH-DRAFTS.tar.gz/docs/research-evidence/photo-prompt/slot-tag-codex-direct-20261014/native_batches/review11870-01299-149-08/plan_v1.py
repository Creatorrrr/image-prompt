"""Every actual E/protected-anchor semantic decision authored explicitly below."""
from common_v1 import *
packet=load('SELECTED-B1-REVIEW-PACKET-v1.json');view=packet['resolved_view'];inv=load('PRE-DISCOVERY-REQUEST-v1.json')['inventory']
# This finite request expressly leaves framing and activity/event/concept open.
# Each protected whole preserves actual existing entity truth, not its image crop.
DECISIONS={
 'macroApp':{
  'subject':'Macro changes selected image coverage, not existence of U,V,H1,H2,H3,R1,R2,X. The request explicitly permits nonhand panel omission while preserving these same entities; the full source also preserves topology and introduces no entity.',
  'identity':'Changing coverage does not change any rig/hand/item identity; the source prohibits creating or merging carriers and the complete union includes both rigs and every declared part.',
  'count':'Actual existing entity count is preserved. Macro does not duplicate/delete an entity or select a participant count; the request distinguishes mutable image inclusion from actual entities.',
  'age':'No age, maturity or age-dependent identity state is selected by macro; none is inferred from hand-shaped parts.',
  'subject.visibility':'A macro choice can otherwise crop an item; this selected full source expressly retains X visible in I. This finite plan retains X and all three hands as framing subjects and excludes only mutable nonhand panels. Exact literal X visibility is independently frozen and final typed X/I visibility must be rechecked.',
  'framing.visible_in':'The operation owner remains I. The source same-item/same-image guard and final typed relation retain X→I; neither an image replacement nor X→I2 is selected.'},
 'coverageApp':{
  'subject':'Hands-only participant anatomy excludes the independently mutable R1/R2 panels from image I, while the actual hand-bearing rigs and all parts still exist. No fixed human/person count, new body or entity deletion is introduced.',
  'identity':'The selected crop preserves independently declared entities and every part/carrier link. Hands remain H1/H2/H3 and X remains the same item; excluding a panel is not an identity merge.',
  'count':'The source changes participant-anatomy visibility, not actual entity counts or the complete participating hand scope. The request explicitly leaves this inclusion mutable; no participant is created or deleted.',
  'age':'Hands-only anatomy coverage selects no age or maturity attribute of the existing rigs/parts or item.',
  'subject.visibility':'Coverage explicitly says only hands are visible as participant anatomy AND the existing item remains visible. Item is not participant anatomy. Complete frame union preserves X while permitting only the enumerated nonhand panels to be excluded; preserve literal visible PR and verify typed result.',
  'framing.visible_in':'Only participant-anatomy coverage of the existing I is changed. X retains the independently declared exact I relation, not another image; same-image guard and typed final relation remain conjunctive.'},
 'exchangeApp':{
  'subject':'Perform physical handoff with independently present H1,H2,H3 on the existing X. All are input endpoints; activity neither creates an entity nor changes its type or carrier. Complete source refuses new endpoints.',
  'identity':'Physical handoff in progress is not completed legal ownership or object identity replacement. The exact same X and hand endpoints remain; no hand/carrier merge or subtype is added.',
  'count':'Performing the handoff with the exact full existing H1/H2/H3 receiver scope does not add another hand or item, nor replace the variable source scope with a fixed anatomical count.',
  'age':'Performed handoff supplies no age/maturity property of any existing endpoint.',
  'subject.visibility':'This source requires visible X both before and after. It does not select concealment, item coordinate, contact occlusion or a trajectory that would override visibility. In this open finite request a performed handoff retains X visible in I; final typed preservation separately required.',
  'framing.visible_in':'No image transition or different visible-in relationship is selected by physical handoff. X remains in the independently selected I, and same-image guard plus typed final relation remain mandatory.'}}
fx={f['fact_id']:f for node in view['nodes']for f in node['expanded_facts']if f['mode']=='effect'}
assert set(fx)==set(DECISIONS) and len(fx)==3
rows=[]
for fid in ['macroApp','coverageApp','exchangeApp']:
 f=fx[fid];ek=c.digest({k:f[k]for k in ['candidate_id','realization_id','fact_id','expansion_index','target']})
 for anchor in inv['anchors']:
  key=anchor['dimension']if anchor['kind']=='whole_dimension'else anchor['property']
  reason=DECISIONS[fid][key]
  rows.append({'effect_key':ek,'anchor_key':c.digest(anchor),'impact':'disjoint','reason':reason,
   'input_ids':['request'],'span_ids':['request_1'],'preservation_ref':'itemVisiblePreservation'if key=='subject.visibility'else None})
assessment={'schema':'research-source-anchor-impact-review/v1','inventory_sha256':c.digest(inv),'resolved_view_sha256':c.digest(view),
 'source_bindings_sha256':c.digest(packet['source_bindings']),'reviewer':'/root/review_11870_12250 actual whole-source/finite-request manual reviewer','anchors':rows,'joint':[]}
within={'schema':'photo-manual-within-source-E-compatibility/v1','candidate_id':CID,'actual_E_refs':['macroApp','coverageApp','exchangeApp'],
 'pairs':[{'refs':['macroApp','coverageApp'],'judgement':'compatible','reason':'Macro extent and only-hands participant anatomy are jointly selected image properties. The finite request supplies three hands and an existing item; inclusion of all hands and visible X with panel exclusion has no size/distance/output geometry constraint making it contradictory. No lens/focus or exact scale coordinate is added.'},
 {'refs':['macroApp','exchangeApp'],'judgement':'compatible','reason':'Perform the physical handoff on the exact item with all existing hands and select a macro view of those same endpoints. No trajectory/location/contact detail or frozen event limits this open activity selection.'},
 {'refs':['coverageApp','exchangeApp'],'judgement':'compatible','reason':'A handoff uses the visible actual participating hands and X. Only nonhand panels are excluded as participant anatomy; source keeps item visible and does not require new bodies or precise contact geometry.'}],
 'engine_joint_count':0,'reason':'The engine joint array covers different-source E pairs only; one selected CID means no cross-source pair. These three within-source meanings were nevertheless directly reviewed. Unknown/affects variants of the actual anchor plan must be rejected.'}
if __name__=='__main__':
 save('MANUAL-IMPACT-ASSESSMENT-v1.json',assessment);save('WITHIN-SOURCE-JOINT-REVIEW-v1.json',within)
 core,inventory,cap,authority=frozen_inputs();es=entries(core)
 plan=pe.freeze_permission_plan(authority,core,[es[0]],inventory=cap,assessment=assessment,contracts=contracts(),reviewer='/root/review_11870_12250 direct finite-request/source impact review')
 print(json.dumps(save('FROZEN-PLAN-PAYLOAD-v1.json',pe._payload(plan,'permission plan'))))
 with pe.trusted_permission_session(authority,plan):
  for e in es:
   result=n.admission(e,core);print('admission',result['allowed'],result.get('reason'));assert result['allowed'],result
   assert eligible(e,core)
 print('actual source fullcompact admission/consumer PASS')
