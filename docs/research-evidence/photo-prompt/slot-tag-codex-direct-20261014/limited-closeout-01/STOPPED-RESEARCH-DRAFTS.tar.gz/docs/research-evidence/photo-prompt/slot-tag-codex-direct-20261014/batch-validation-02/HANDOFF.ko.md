# source27 증분 준비 — root acceptance 대기

현재 source27 `d1039bd6a55f6c767a0049704457ed48aa109c273f557d7e407673455bb72ba3` /149V6를 source102와 전수 대조했다. 전체18,250개 ID·catalog·binding12,089개·정책은 유지한다. 실제 변경은 **고유23 CID = kind14 + soil3 + expression5 +1299 하나**이며 중복0, 나머지18,227개는 동일하다. [정확한 변경 CID·원문 delta](SOURCE27-DELTA.json)를 참조한다.

초기 시점의 기존7 positive 배치와 diagnostic70 배치를 원래 verifier/root acceptance로 재검증했다. **positive77 + diagnostic-only38 =115개 proof**는 source27의 전체 after/catalog/명시적 참조 closure·binding과 같으며 stale0이다. 115개의 foreign CID/실제로 소비하는 binding closure는 모두 빈 집합이다. own binding은 별도 [대조 대장](OWN-BINDING-SUPPLEMENT.json)에 보존했다. [초기115개 proof 목록](PROPOSED-EXACT-PROOF-REUSE.json)은 그 시점의 증거로 유지한다. 38개 diagnostic을 positive 역할/검색 투표로 바꾸지 않고, 같은70행 배치의 나머지32개 pending은 재사용하지 않는다.

그 뒤 루트가 soil3 수용·커밋을 알렸으므로, 그3개 배치/root acceptance도 재검증하여 **source25 전체 after/catalog/closure/binding이 source27과 정확히 같은3건**을 [별도 증분](SOIL3-EXACT-REUSE-SUPPLEMENT.json)으로 보존했다. 초기115개 파일은 바꾸지 않았다. 현재 제안은 **positive80 + diagnostic-only38 =118개**, 나머지18,132개다. [결합 선택자 목록](PROPOSED-COMBINED-REUSE-118.json)은 각 원 증거의 정확한 JSON pointer/hash만 선택한다. 모두 **새 source27 재사용에 대한 root acceptance 대기**이며 실제로 붙인 proof는0개다. expression5와 actual1299는 아직 root acceptance 대기이고 결합 목록에서 제외한다.

벡터는 source102의 이미 검증된 local metadata와 ID·full text·recipe·space·execution을 대조했다. soil3/expression5의 실제 변경은 `content.application_contract`만이고,1299는 여기에 `content.permission_envelope`를 더한 변경이다. 이 필드는 검색 projection을 바꾸지 않으므로 **기존18,198개 벡터 전부 재사용 계획 + 새 positive14개만 local 입력 계획 =18,212개**다. [전체 ID별 벡터 계획](VECTOR-REUSE-PLAN.json.gz)과 [원바이트 압축 대조](VECTOR-ARCHIVE.json)를 남겼다. 실제 벡터 payload를 다시 읽거나 새 inference를 실행하지 않았으며, 향후 기존 API에서 실제 벡터 bytes/실행증거/공간을 다시 검증해야 한다. Gemini 결과를 local 증거로 바꿔 부르지 않는다.

## 실행 의존성

1. 루트가 초기115개와 새 soil3 증분의 **118개 재사용 제안**을 별도로 수용해야 한다. 이는 새 의미 승인이나 전체 latest18250/pending0 통과가 아니다.
2. **actual1299의 정확한 source27 전체 proof/세 실제 E·모든 receiver·원 조건/owner·permission authority·완전 inventory/impact plan·독립 typed after-state 보존 검증이 완결될 때까지 source27 qualified container/index/generation/adoption을 실행하지 않는다.** 벡터가 그대로라는 사실은 native 자격을 주지 않는다. 현재 strict code는 별도로 고정된 `fe5b593c…`이고, 이 배치의 historical proof verifier는 원 판정에 사용한 `50fd92af…`다. source27 실행 전에는 실제1299를 지원하는 정확한 strict 구현을 루트가 고정·검증해야 한다.
3. expression5/복원32개/actual1299 또는 그 밖의 새 proof는 정확한 새 native 심사와 root acceptance 없이 이118개 제안에 추가하지 않는다. source가 다시 바뀌면 이 source27 계획을 새 hash로 고쳐 쓰지 않고 CID·closure·projection을 다시 대조한다.
4. 위 의존성이 완료된 뒤 새 비활성 연구 배치에서만 exact proof를 연결하고, local14개를 추론하며 전체18,212개의 DF/field lengths/포스팅·guard·payload/reference closure를 재구축·검증한다. 같은 core/catalog/controls/language/recipe/space/execution인 기존149질의는 표준 `validate_set` 후 재사용할 수 있지만, 검색 ranks/public pack/issued receipt는 새 source로 실제 실행해야 한다.1299의 새로운 실제 core/inventory/typed after-state는 먼저 작성·직접 검토한다.
5. 최종 운영 채택 gate는 **전체18,250개의 현재 판정과 pending0** 그대로다. `expected_count=77` 또는115로 줄이지 않는다. source102의 generation·실제 receipt·6220 구성 증빙은 source102 체크포인트로 그대로 둔다.

## 최소 쓰기 allowlist

현재는 **`R/batch-validation-02/`의 증분 delta·초기115/증분3 proof locator/closure·결합118 선택자·벡터 계획·검증/해시/이 handoff만** 썼다. 원문·production 코드·운영 데이터/catalog/binding·CURRENT·기존 batch01·G·Git은 쓰지 않았다. model/numeric/provider import 시도0, inference/network/Gemini/build/query/receipt 호출0이다.

후속 실행 승인을 받더라도 쓰기 범위는 별도 새 `R/batch-validation-03/` 연구 source/container·derived assets/cache·전용 store/generation/query/pack/receipt/compose 증빙으로 한정한다. 운영 store/pointer·원문·기존 proof·기존 generation/receipt를 고치지 않는다. 새 permanent binding 조건·weight는 별도 정확한 의미 수용이 필요하다. 중앙 CURRENT와 source 선택은 루트가 관리한다.

재실행 명령(새 output 폴더에서 exact 입력을 고정하여 사용):

```bash
R=docs/research-evidence/photo-prompt/slot-tag-codex-direct-20261014
env -i HOME=/Users/chasoik PATH=/opt/homebrew/bin:/usr/bin:/bin \
  PYTHONDONTWRITEBYTECODE=1 \
  /usr/bin/sandbox-exec -f "$R/batch-validation-02/deny-network.sb" \
  /opt/homebrew/opt/python@3.14/bin/python3.14 "$R/batch-validation-02/plan.py"
```

이 산출물은 실행 준비와 재사용 무결성 대조다. 새 source의 의미 정확도·완전성·native 자격·운영 채택·픽셀 또는5~8단계 완료를 인증하지 않는다.
