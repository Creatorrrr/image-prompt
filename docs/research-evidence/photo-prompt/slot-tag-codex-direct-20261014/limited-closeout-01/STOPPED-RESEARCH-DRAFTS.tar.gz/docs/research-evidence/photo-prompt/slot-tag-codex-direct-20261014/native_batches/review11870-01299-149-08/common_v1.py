"""Exact frozen research inputs, mechanical bindings; no semantic decision inferred."""
from author_v1 import *
import fixture_v2 as fi
import photo_native_permission as pe,photo_permission_comparison as pc,photo_search_layout as layout
import prompt_generator as g,audit_composed_prompt as audit

def save(name,value):
 p=O/name;assert not p.exists(),p;p.write_text(json.dumps(value,ensure_ascii=False,sort_keys=True,indent=2)+'\n');return {'file':str(p),'file_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'sha256':c.digest(value)}
def load(name):return json.loads((O/name).read_text())
def owner_choices(core,*,image='I',hand='H1',item='X'):
 fr=n.frozen_witnesses(core);sc={s['scope_id']:s for s in fr['member_scopes']}
 selected=[{'target':t,'selection':{'kind':'existing_owner','owner_id':owner}}for t,owner in [('image',image),('initiating_hand',hand),('exchange_item',item)]]
 selected +=[{'target':t,'selection':{'kind':'existing_member_scope','scope_id':sid,'scope_sha256':c.digest(sc[sid])}}for t,sid in [('other_hands','other_hands'),('framing_affected_owners','framing_affected')]]
 return {'schema':n.MEMBER_SELECTION_SCHEMA,'core_sha256':core['canonical_sha256'],'owner_graph_sha256':c.digest(fr['graph']),
  'member_scopes_sha256':c.digest(fr['member_scopes']),'entries':[{'candidate_id':CID,'realization_id':'base','meaning_sha256':proof['meaning_sha256'],
  'qualification_sha256':c.digest(proof),'bindings':selected}]}
def entries(core,*,binding=False,**kwargs):
 choices=owner_choices(core,**kwargs);bid='bind_2e72784a26885ceaa1d645d25bd9a468'if binding else None
 full=c.entry(S,CID,bid,realization_id='base',owner_selections=choices)
 compactdata={**S,'candidates':{**S['candidates'],CID:layout.guard_record(S['candidates'][CID],S)}}
 compact=c.entry(compactdata,CID,bid,realization_id='base',owner_selections=choices)
 return full,compact

def frozen_inputs():
 saved=load('PRE-DISCOVERY-REQUEST-v1.json');core,inv,cap=fi.freeze_input()
 assert core==saved['core'] and inv==saved['inventory']
 pin=load('QUALIFIED-SOURCE-PIN-v1.json');assert c.digest(S)==pin['qualified_full_source_sha256']
 authority=pe.freeze_source_authority(S,expected_snapshot_sha256=pin['qualified_full_source_sha256'],reviewer='/root/review_11870_12250 exact root input plus manually authored fresh08 proof')
 return core,inv,cap,authority

def contracts():return {CID:copy.deepcopy(after['content']['permission_envelope']['realizations']['base'])}
def eligible(entry,core):return g.core_entry_eligible(S,core,{'subject_category':'object','domains':[],'intent_constraints':{'subject_categories':['object'],'domains':[]}},{'subject':{'kind':['object'],'tags':['object']}},'',entry)
def modules():
 out={}
 for name,m in sorted(sys.modules.items()):
  p=getattr(m,'__file__',None)
  if p and (name.startswith('photo_')or name in {'prompt_generator','audit_composed_prompt'}):
   p=Path(p).resolve();assert p.is_relative_to(G),(name,p);out[name]={'file':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
 return out
if __name__=='__main__':
 pin={'schema':'photo-explicit-reviewed-source-freeze-pin/v1','root_input':I['current_snapshot'],'assignment_sha256':c.digest(A),
  'qualified_full_source_sha256':c.digest(S),'manual_proof_sha256':c.digest(proof),'exact_root_source_record_sha256':c.digest(after),
  'meaning_sha256':n.meaning_sha256(after),'reason':'Full exact root snapshot d1039 plus only own manually authored proof. All non-own source/conditions/catalog/bindings/policies are root-authorized input bytes; no claim to personally reread 18250 records. This independent caller pin is stored before issuing a source handle; candidate/selfhash alone is not authority.'}
 save('QUALIFIED-SOURCE-PIN-v1.json',pin)
 core,inv,cap,authority=frozen_inputs();es=entries(core)
 packet=pe.prepare_permission_review(authority,cap,core,[es[0]],contracts=contracts())
 assert len(packet['resolved_view']['effect_assignments'])==3
 print(json.dumps(save('SELECTED-B1-REVIEW-PACKET-v1.json',packet)))
 print(json.dumps({'effects':packet['resolved_view']['effect_assignments'],'permission_scope':packet['resolved_view']['permission_scope']['literal_properties']},ensure_ascii=False))
