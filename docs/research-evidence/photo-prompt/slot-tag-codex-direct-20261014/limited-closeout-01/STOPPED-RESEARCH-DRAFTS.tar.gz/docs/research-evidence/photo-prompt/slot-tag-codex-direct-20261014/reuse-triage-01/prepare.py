"""Read-only bookkeeping for the current per-CID reuse classification.

This verifies existing original review evidence and source equality. It makes
no semantic classification, source edit, native proof, or approval.
"""
import gzip
import hashlib
import importlib.abc
import json
import sys
from collections import Counter
from pathlib import Path

ROOT = Path.cwd()
R = ROOT / 'docs/research-evidence/photo-prompt/slot-tag-codex-direct-20261014'
D = R / 'reuse-triage-01'
G = Path('/Users/chasoik/.cache/image-prompt/photo-shared-runtime/generations/fe5b593c819806a31803e40c620e6f2b28c3b54103f451dd6f38920f2d537258')


class Deny(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        if fullname.split('.')[0] in {'torch', 'transformers', 'sentence_transformers', 'tensorflow', 'jax', 'mlx', 'google', 'openai', 'anthropic', 'requests', 'httpx'}:
            raise AssertionError(fullname)


sys.meta_path.insert(0, Deny())
sys.dont_write_bytecode = True
sys.path[:0] = [str(G / 'scripts'), str(G / 'precore')]
import photo_candidate_corpus as c
import photo_candidate_realizations as realization
import photo_semantic_evidence as n
sys.path.insert(0, str(R))
import direct_review as dr
sys.path[:0] = [str(G / 'scripts'), str(G / 'precore')]
assert n.__file__ == str(G / 'scripts/photo_semantic_evidence.py')


def read(path):
    raw = path.read_bytes()
    return json.loads(gzip.decompress(raw) if raw[:2] == b'\x1f\x8b' else raw)


def ref(path):
    return dict(file=str(path.relative_to(ROOT)), file_sha256=hashlib.sha256(path.read_bytes()).hexdigest(), sha256=c.digest(read(path)))


def save(name, value):
    path = D / name
    with path.open('xb') as handle:
        handle.write(c.canonical_bytes(value) + b'\n')


source_path = R / 'native-inputs/root-carrier4-source-plan-28/CURRENT-PROPOSAL.json.gz'
source = read(source_path)
assert c.digest(source) == 'e1c88b27e881ac11a179e09a9a41f4b2e69832679d4bf9c23b2b5e7099e6b696'
original = read(R / 'SOURCE.json.gz')
order = read(R / 'ORDER.json')
assert len(order) == len(set(order)) == len(source['candidates']) == 18250
assert set(order) == set(original['candidates']) == set(source['candidates'])
prior_source = read(R / 'native-inputs/root-expression5-source-plan-26/CURRENT-PROPOSAL.json.gz')
inventory = read(R / 'ROOT-CURRENT149-APPROVAL-INVENTORY-04.json')
positive = {row['candidate_id'] for row in inventory['records']}
diagnostic = set(read(R / 'ROOT-SOIL3-149-INTEGRATION-01.json')['diagnostic_ids'])
accepted = positive | diagnostic
assert len(positive) == 85 and len(diagnostic) == 38 and len(accepted) == 123
assert all(source[key] == prior_source[key] for key in ('slot_catalog', 'slot_bindings', 'policies'))
for cid in accepted:
    assert source['candidates'][cid] == prior_source['candidates'][cid]
    old_refs = n.referenced_records(prior_source['candidates'][cid], prior_source)
    new_refs = n.referenced_records(source['candidates'][cid], source)
    assert old_refs == new_refs
    for key in old_refs:
        field = 'slot_bindings' if c.BINDING_ID.fullmatch(key) else 'candidates'
        assert source[field][key] == prior_source[field][key]

old_catalog, new_catalog = original['slot_catalog'], source['slot_catalog']
changes = {}
for tag in sorted(set(old_catalog) | set(new_catalog)):
    before, after = old_catalog.get(tag), new_catalog.get(tag)
    if before != after:
        changes[tag] = dict(before=before, after=after, fields=[key for key in sorted(set(before or {}) | set(after or {})) if (before or {}).get(key) != (after or {}).get(key)])
save('ROLE-CHANGES.json', dict(schema='photo-reuse-role-definition-comparison/v1', original_catalog_sha256=c.digest(old_catalog), current_catalog_sha256=c.digest(new_catalog), added=[tag for tag in changes if tag not in old_catalog], removed=[tag for tag in changes if tag not in new_catalog], changed_existing=[tag for tag in changes if tag in old_catalog and tag in new_catalog], changes=changes, semantic_classifications_created=0))

packets = {}
for path in sorted((R / 'packets').glob('*.json')):
    packet = read(path)
    key = c.digest(packet)
    assert key not in packets
    packets[key] = (packet, ref(path))
compiled, authored, file_pins = {}, {}, {}
provenance_cache, binding_cache = {}, {}
for path in sorted((R / 'decisions').glob('*.json')):
    document = read(path)
    pin = ref(path)
    file_pins[pin['file']] = pin
    for number, row in enumerate(document['decisions'], 1):
        cid = row['candidate_id']
        assert cid not in compiled
        dr.validate_decision(row, original, provenance_cache=provenance_cache, binding_cache=binding_cache)
        location = row['authored_decision']
        ap = ROOT / location['file']
        if ap not in authored:
            authored[ap] = read(ap)
        item = dr.authored_item(authored[ap], location['item'])
        assert c.digest(item) == location['sha256'] and all(row[key] == value for key, value in item.items())
        packet, packet_ref = packets[row['packet_sha256']]
        assert packet['records'][cid] == original['candidates'][cid]
        assert packet['references'][cid] == dr.closure(original, cid)
        compiled[cid] = (row, dict(file=pin['file'], file_sha256=pin['file_sha256'], item=number, row_sha256=c.digest(row)), packet_ref)
assert set(compiled) == set(order)

def own_bindings(data):
    result = {}
    for bid, binding in data['slot_bindings'].items():
        result.setdefault(binding['candidate_id'], {})[bid] = binding
    return result

old_bindings, new_bindings = own_bindings(original), own_bindings(source)
index = []
for ordinal, cid in enumerate(order):
    row, locator, packet_ref = compiled[cid]
    before, current = original['candidates'][cid], source['candidates'][cid]
    corrected = dr.corrected_record(before, row['corrections'])
    old_refs, new_refs = n.referenced_records(before, original), n.referenced_records(current, source)
    index.append(dict(candidate_id=cid, ordinal=ordinal, already_final_native_valid=cid in accepted,
        original_compiled=locator, original_packet=packet_ref, original_authored=row['authored_decision'],
        original_review_status=row['status'], original_read_method=row['review_method'],
        original_record_sha256=c.digest(before), current_record_sha256=c.digest(current),
        old_corrected_fields_record_sha256=c.digest(corrected), current_equals_original=before == current,
        current_equals_old_corrected_fields=corrected == current, old_recommended_kind=row['recommended_kind'],
        current_kind_matches_old_recommendation=current['record_kind'] == row['recommended_kind'],
        original_conditions_sha256=c.digest(before['conditions']), current_conditions_sha256=c.digest(current['conditions']),
        original_effects_sha256=c.digest(before['effects']), current_effects_sha256=c.digest(current['effects']),
        original_realization_ids=realization.ids(before), current_realization_ids=realization.ids(current),
        original_reference_hashes=old_refs, current_reference_hashes=new_refs, reference_closure_equal=old_refs == new_refs,
        original_own_bindings_sha256=c.digest(old_bindings.get(cid, {})), current_own_bindings_sha256=c.digest(new_bindings.get(cid, {})),
        original_role_ids=[role['slot_id'] for role in row['roles']],
        original_uncertainties=row['uncertainties'], original_correction_count=len(row['corrections']),
        mechanical_original_review_trace_verified=True, new_semantic_classification=None))
with (D / 'ORIGINAL-INDEX.jsonl.gz').open('xb') as handle:
    handle.write(gzip.compress(b''.join(c.canonical_bytes(row) + b'\n' for row in index), mtime=0))
save('ORIGINAL-FILE-PINS.json', dict(compiled_files=file_pins, semantic_classifications_created=0))

partitions = {
    'batch_pipeline': [(0, 1250)],
    'review_11870_12250': [(1250, 3250)],
    'review_06250_07250': [(3250, 6250)],
    'review_08250_09250': [(6250, 7250), (13250, 15250)],
    'review_07250_08250': [(7250, 9250)],
    'review_12250_13000': [(9250, 10250), (15250, 17250)],
    'native_evidence': [(10250, 11250), (17250, 18250)],
    'review_09250_10500': [(11250, 13250)],
}
assigned = []
for task, ranges in partitions.items():
    rows = [row for start, stop in ranges for row in index[start:stop] if not row['already_final_native_valid']]
    ids = [row['candidate_id'] for row in rows]
    assigned.extend(ids)
    save(task + '.ASSIGNMENT.json', dict(schema='photo-codex-reuse-triage-assignment/v1', actor='/root', task_name='/root/' + task, model='gpt-6.1-sol', reasoning_effort='high', ranges=ranges, ids=ids, ordinals=[row['ordinal'] for row in rows], count=len(ids), baseline_accepted_excluded=123, source=ref(source_path), catalog_sha256=c.digest(new_catalog), actual_read_count_from_preparation=0, semantic_classifications_created=0))
assert len(assigned) == len(set(assigned)) == 18127 and set(assigned) == set(order) - accepted
save('BASELINE.json', dict(schema='photo-root-current-reuse-triage-baseline/v1', actor='/root', source=ref(source_path), original_source=ref(R / 'SOURCE.json.gz'), order=ref(R / 'ORDER.json'), catalog_sha256=c.digest(new_catalog), inventory_count=18250, already_valid_positive_count=85, already_valid_diagnostic_count=38, already_valid_count=123, already_valid_ids=sorted(accepted), classification_count=18127, classification_ids=assigned, partitions={task: {'ranges': ranges, 'count': sum(cid in set(assigned) for start, stop in ranges for cid in order[start:stop])} for task, ranges in partitions.items()}, original_compiled_review_trace_verified=18250, original_status_counts=dict(Counter(row['original_review_status'] for row in index)), mechanical_comparison_only=True, automatic_classifications=0, new_approvals=0, production_changes=0, Gemini_calls=0))
print(json.dumps(dict(already_valid=123, classification_target=18127, trace_verified=18250, duplicate=0, omitted=0, per_task={task: read(D / (task + '.ASSIGNMENT.json'))['count'] for task in partitions})))
