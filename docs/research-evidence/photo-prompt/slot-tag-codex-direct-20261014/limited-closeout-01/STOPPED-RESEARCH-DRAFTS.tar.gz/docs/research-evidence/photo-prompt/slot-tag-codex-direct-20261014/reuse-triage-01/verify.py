"""Verify the exact CID partition of authored reuse judgments, without approving them."""
import gzip
import hashlib
import json
import sys
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path.cwd()
R = ROOT / 'docs/research-evidence/photo-prompt/slot-tag-codex-direct-20261014'
D = R / 'reuse-triage-01'
G = Path('/Users/chasoik/.cache/image-prompt/photo-shared-runtime/generations/fe5b593c819806a31803e40c620e6f2b28c3b54103f451dd6f38920f2d537258')
sys.dont_write_bytecode = True
sys.path[:0] = [str(G / 'scripts'), str(G / 'precore')]
import photo_candidate_corpus as c


def read(path):
    return json.loads(path.read_bytes())


def pin(path):
    return dict(file=str(path.relative_to(ROOT)), file_sha256=hashlib.sha256(path.read_bytes()).hexdigest(), sha256=c.digest(read(path)))


def save(name, value):
    with (D / name).open('xb') as handle:
        handle.write(c.canonical_bytes(value) + b'\n')


baseline = read(D / 'BASELINE.json')
original = [json.loads(line) for line in gzip.decompress((D / 'ORIGINAL-INDEX.jsonl.gz').read_bytes()).splitlines()]
assert len(original) == 18250
combined, files, per_worker, reasons = {}, {}, {}, defaultdict(set)
required = {'candidate_id', 'ordinal', 'classification', 'subtype', 'comparison_ordinal', 'existing_evidence', 'reusable_scope', 'review_again', 'role_impact', 'reason_codes', 'rationale', 'native_work_remaining', 'final_native_approval_valid'}
for assignment_path in sorted(D.glob('*.ASSIGNMENT.json')):
    task = assignment_path.name.removesuffix('.ASSIGNMENT.json')
    assignment = read(assignment_path)
    path = D / (task + '.CLASSIFICATION.json')
    document = read(path)
    assert document['schema'] == 'photo-codex-per-cid-reuse-classification/v1'
    assert document['task_name'] == assignment['task_name']
    assert document['model'] == 'gpt-6.1-sol' and document['reasoning_effort'] == 'high'
    assert document['assignment_sha256'] == c.digest(assignment)
    assert document['source_sha256'] == baseline['source']['sha256']
    assert document['catalog_sha256'] == baseline['catalog_sha256']
    assert document['new_native_approvals'] == document['operating_changes'] == document['Gemini_calls'] == 0
    assert document['reading_boundary'] and document['summary']
    ids, counts = set(), Counter()
    for row in document['records']:
        assert required <= set(row), (task, row.get('ordinal'), required - set(row))
        cid, ordinal, category = row['candidate_id'], row['ordinal'], row['classification']
        assert cid not in ids and cid not in combined
        assert category in {'reuse', 'partial', 'full'}
        assert row['comparison_ordinal'] == ordinal
        assert original[ordinal]['candidate_id'] == cid
        assert original[ordinal]['already_final_native_valid'] is False
        assert row['final_native_approval_valid'] is False
        assert all(row[key] for key in ('subtype', 'existing_evidence', 'reusable_scope', 'role_impact', 'reason_codes', 'rationale', 'native_work_remaining'))
        assert isinstance(row['review_again'], list)
        assert (not row['review_again']) if category == 'reuse' else bool(row['review_again'])
        assert isinstance(row['reason_codes'], list) and all(isinstance(reason, str) and reason.strip() for reason in row['reason_codes'])
        ids.add(cid)
        counts[category] += 1
        combined[cid] = dict(row, classification_artifact=task + '.CLASSIFICATION.json', reviewer=document['task_name'])
        for reason in set(row['reason_codes']):
            reasons[reason].add(cid)
    assert ids == set(assignment['ids']) and len(ids) == assignment['count']
    files[task] = pin(path)
    per_worker[task] = dict(count=len(ids), counts=dict(counts))
assert len(combined) == len(set(combined)) == baseline['classification_count'] == 18127
assert set(combined) == set(baseline['classification_ids'])
assert set(combined).isdisjoint(baseline['already_valid_ids'])
assert len(set(combined) | set(baseline['already_valid_ids'])) == 18250
ordered = sorted(combined.values(), key=lambda row: row['ordinal'])
counts = Counter(row['classification'] for row in ordered)
for category in ('reuse', 'partial', 'full'):
    save(category.upper() + '-IDS.json', [row['candidate_id'] for row in ordered if row['classification'] == category])
with (D / 'PER-CID-CLASSIFICATION.jsonl.gz').open('xb') as handle:
    handle.write(gzip.compress(b''.join(c.canonical_bytes(row) + b'\n' for row in ordered), mtime=0))
summary = dict(schema='photo-root-reuse-classification-verification/v1', actor='/root', baseline=pin(D / 'BASELINE.json'), catalog_sha256=baseline['catalog_sha256'], source=baseline['source'], total=18250, existing_final_valid=123, classification_target=18127, counts={key: counts[key] for key in ('reuse', 'partial', 'full')}, duplicate=0, omitted=0, unclassified=0, reuse_final_native_approval_valid_in_target=0, reuse_evidence_native_work_pending=counts['reuse'], actual_meaning_partial_or_full_recheck=counts['partial'] + counts['full'], per_worker=per_worker, reason_unique_counts={key: len(ids) for key, ids in sorted(reasons.items())}, reason_counts_are_nonexclusive=True, worker_files=files, new_native_approvals=0, stage05_complete=False, stages06_to08_complete=False, production_activated=False, operating_native_qualified=0, Gemini_calls=0, boundary='Exact partition validation of explicit authored classification judgments. Existing reading reuse is not final149 approval. Partial means the recorded limited role/owner/effect/condition/reference work, not a demand to reread every whole body. Full applies only to documented whole-source/required-reference trust gaps. Root semantic integration and subsequent native evidence/consumer checks remain separate.')
save('ROOT-VERIFICATION.json', summary)
print(json.dumps({key: summary[key] for key in ('existing_final_valid', 'classification_target', 'counts', 'duplicate', 'omitted', 'unclassified', 'reuse_evidence_native_work_pending', 'actual_meaning_partial_or_full_recheck', 'new_native_approvals')}))
