"""Append exact reuse proposal for newly root-accepted soil3; preserve115."""
import copy,hashlib,importlib.abc,json,sys
from pathlib import Path
O=Path(__file__).resolve().parent;R=O.parent;ROOT=R.parents[3]
G=Path('/Users/chasoik/.cache/image-prompt/photo-shared-runtime/generations/50fd92afd9400f2272e12fcd6494cafdeea407b841f8a862d066c48f447e6839')
attempts=[]
class Deny(importlib.abc.MetaPathFinder):
    def find_spec(self,fullname,path=None,target=None):
        if fullname.split('.')[0] in {'photo_local_embedding','torch','transformers','sentence_transformers','tensorflow','jax','mlx','numpy','google','openai','anthropic','requests','httpx'}:
            attempts.append(fullname);raise RuntimeError('No model/provider in reuse supplement: '+fullname)
sys.meta_path.insert(0,Deny());sys.dont_write_bytecode=True
sys.path[:0]=[str(G/'scripts'),str(G/'precore'),str(R)]
import photo_candidate_corpus as c,photo_semantic_evidence as native
import direct_review
sys.path[:0]=[str(G/'scripts'),str(G/'precore')]
import native_reviews as nr
def ref(path,value=None):
    path=Path(path);value=nr.read_json(path)if value is None else value
    return {'file':str(path.relative_to(ROOT)),'file_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'sha256':c.digest(value)}
old=O/'PROPOSED-EXACT-PROOF-REUSE.json';oldhash=hashlib.sha256(old.read_bytes()).hexdigest();previous=nr.read_json(old)
current=nr.read_json(R/'native-inputs/root-handoff-envelope-source-plan-27/CURRENT-PROPOSAL.json.gz')
assert c.digest(current)==previous['current_source_sha256']=='d1039bd6a55f6c767a0049704457ed48aa109c273f557d7e407673455bb72ba3'
D=R/'native_batches/review09250-soil3-149-01';assignment=R/'native-inputs/prepared/review09250-soil3-149-01/ASSIGNMENT.json'
checked=nr.verify_batch(str(assignment),str(D/'BATCH.json'),str(D/'NOTE.json'),root=ROOT,here=R)
acceptance=ref(D/'ROOT-ACCEPTANCE.json');nr.verify_acceptance(ROOT,acceptance,checked)
assert checked['statuses']=={'approved':3,'pending':0,'diagnostic_reviewed':0}
entries=[]
for cid,row in checked['records'].items():
    assert cid not in {r['candidate_id']for r in previous['records']}
    assert row['source_after']==current['candidates'][cid] and row['proof']['catalog_sha256']==c.digest(current['slot_catalog'])
    closure=native.referenced_records(current['candidates'][cid],current)
    refs={key:current['candidates'][key]for key in closure if c.ID.fullmatch(key)}
    bindings={key:current['slot_bindings'][key]for key in closure if c.BINDING_ID.fullmatch(key)}
    assert set(row['dependency_records'])==set(refs) and row['reference_bindings']==bindings and row['proof']['reference_sha256']==closure
    for child,record in row['dependency_records'].items():
        plain=copy.deepcopy(record);plain['content'].pop('role_evidence',None);assert plain==refs[child]
    own={bid:c.digest(b)for bid,b in current['slot_bindings'].items()if b['candidate_id']==cid}
    entries.append({'candidate_id':cid,'ordinal':row['ordinal'],'historically_accepted_status':'approved',
        'whole_source_sha256':c.digest(current['candidates'][cid]),'review_sha256':c.digest(row),'proof_sha256':c.digest(row['proof']),
        'batch':ref(D/'BATCH.json'),'historical_root_acceptance':acceptance,'note':ref(D/'NOTE.json'),
        'candidate_reference_closure':{k:c.digest(v)for k,v in refs.items()},'binding_reference_closure':{k:c.digest(v)for k,v in bindings.items()},'own_binding_sha256':own,
        'role_ids':sorted(row['proof']['roles']),'new_source27_reuse_root_accepted':False})
assert not attempts and hashlib.sha256(old.read_bytes()).hexdigest()==oldhash
value={'schema':'photo-source27-soil3-proof-reuse-supplement/v1','initial115_proposal_preserved':ref(old,previous),
    'root_reported_soil3_commit':'d6ec27eec','Git_was_not_called_to_reverify_commit':True,
    'current_source_sha256':c.digest(current),'catalog_sha256':c.digest(current['slot_catalog']),
    'source25_batch_reverified':{k:checked[k]for k in ('assignment_sha256','input_sha256','batch_sha256','note_sha256','statuses')},
    'root_acceptance_pending_for_source27_reuse':True,'additional_reuse_eligible_records':entries,
    'combined_positive_proofs':80,'combined_diagnostic_only_proofs':38,'combined_total_proofs':118,
    'remaining_without_reusable_current_judgment':18132,'stale_or_changed_soil3':[],
    'expression5_and_actual1299_acceptance':'pending; excluded','source27_qualified_container_or_build_or_query_or_receipt_execution':0,
    'native_proofs_attached':0,'new_native_approvals_created':0,'operating_native_qualified_count':0,'model_import_attempts':attempts,'model_network_Gemini_Git_execution':0}
with(O/'SOIL3-EXACT-REUSE-SUPPLEMENT.json').open('xb')as stream:stream.write(c.canonical_bytes(value)+b'\n')
print(json.dumps({'additional_exact_proofs':3,'combined_proposed_reuse':118,'root_acceptance_pending':True,'execution':0}),flush=True)
