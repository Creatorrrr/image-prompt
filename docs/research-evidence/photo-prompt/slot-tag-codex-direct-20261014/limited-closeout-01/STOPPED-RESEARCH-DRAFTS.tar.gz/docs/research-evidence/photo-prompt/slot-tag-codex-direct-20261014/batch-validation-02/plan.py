"""Read-only source102→source27 incremental plan; no corpus/proof application.

Only outputs inside this batch are written. No model/numeric/network/provider
execution, index build, qualification container, generation, query or receipt.
The115 exact historical judgments remain pending a separate root reuse decision.
"""
import copy,gzip,hashlib,importlib.abc,json,sys
from collections import Counter
from pathlib import Path

O=Path(__file__).resolve().parent;R=O.parent;ROOT=R.parents[3]
G=Path('/Users/chasoik/.cache/image-prompt/photo-shared-runtime/generations/50fd92afd9400f2272e12fcd6494cafdeea407b841f8a862d066c48f447e6839')
STRICT=Path('/Users/chasoik/.cache/image-prompt/photo-shared-runtime/generations/fe5b593c819806a31803e40c620e6f2b28c3b54103f451dd6f38920f2d537258')
attempts=[]
class DenyModels(importlib.abc.MetaPathFinder):
    def find_spec(self,fullname,path=None,target=None):
        if fullname.split('.')[0] in {'photo_local_embedding','torch','transformers','sentence_transformers','tensorflow','jax','mlx','numpy','google','openai','anthropic','requests','httpx'}:
            attempts.append(fullname);raise RuntimeError('Planning forbids model/provider imports: '+fullname)
sys.meta_path.insert(0,DenyModels());sys.dont_write_bytecode=True
sys.path[:0]=[str(G/'scripts'),str(G/'precore'),str(R)]
import photo_candidate_corpus as c,photo_semantic_evidence as native,photo_global_index as docs
import direct_review as dr
sys.path[:0]=[str(G/'scripts'),str(G/'precore')]
import native_reviews as nr

def ref(path,value=None):
    path=Path(path);raw=path.read_bytes();value=nr.read_json(path) if value is None else value
    return {'file':str(path.relative_to(ROOT)),'file_sha256':hashlib.sha256(raw).hexdigest(),'sha256':c.digest(value)}
def save(name,value):
    with (O/name).open('xb') as stream:stream.write(c.canonical_bytes(value)+b'\n')
def changed(before,after,path=''):
    if before==after:return []
    if isinstance(before,dict) and isinstance(after,dict):
        rows=[]
        for key in sorted(set(before)|set(after)):
            p=path+'/'+str(key).replace('~','~0').replace('/','~1')
            if key in before and key in after:rows+=changed(before[key],after[key],p)
            else:rows.append({'pointer':p,'before_exists':key in before,'before':before.get(key),'after_exists':key in after,'after':after.get(key)})
        return rows
    return [{'pointer':path,'before_exists':True,'before':before,'after_exists':True,'after':after}]

names=['root-diagnostic6-kind-source-plan-23','root-diagnostic14-kind-source-plan-24','root-soil3-source-plan-25','root-expression5-source-plan-26','root-handoff-envelope-source-plan-27']
snapshots=[nr.read_json(R/'native-inputs'/name/'CURRENT-PROPOSAL.json.gz') for name in names]
before,current=snapshots[0],snapshots[-1]
assert c.digest(before)=='39ab970ec8a42550f6afb41163ae6e2e76c1403f60f76cb9e5a962e3197dd65c'
assert c.digest(current)=='d1039bd6a55f6c767a0049704457ed48aa109c273f557d7e407673455bb72ba3'
assert len(current['candidates'])==18250 and len(current['slot_catalog'])==149
assert c.digest(current['slot_catalog'])=='d9f4db418e1b63cd100b4c7a9fbff4c8401e00dffeffd22e299a0b5087a82b15'
order=nr.read_json(R/'ORDER.json');ordinal={cid:i for i,cid in enumerate(order)}
assert set(order)==set(before['candidates'])==set(current['candidates']) and len(order)==18250
for snapshot in snapshots[1:]:
    assert all(snapshot[key]==before[key] for key in ('schema','slot_catalog','slot_bindings','policies'))
groups=[]
for label,previous,next_source,expected in zip(['kind14','soil3','expression5','actual1299_permission_envelope'],snapshots,snapshots[1:],[14,3,5,1],strict=False):
    rows=[]
    for cid,record in next_source['candidates'].items():
        if record!=previous['candidates'][cid]:
            delta=changed(previous['candidates'][cid],record)
            if label=='kind14':assert len(delta)==1 and delta[0]['pointer']=='/record_kind' and delta[0]['before']=='diagnostic' and delta[0]['after']=='visual_option'
            rows.append({'candidate_id':cid,'ordinal':ordinal[cid],'before_sha256':c.digest(previous['candidates'][cid]),'after_sha256':c.digest(record),'delta':delta})
    assert len(rows)==expected
    groups.append({'group':label,'source_before_sha256':c.digest(previous),'source_after_sha256':c.digest(next_source),'records':rows})
union={row['candidate_id'] for group in groups for row in group['records']}
assert len(union)==23 and {cid for cid in order if before['candidates'][cid]!=current['candidates'][cid]}==union
save('SOURCE27-DELTA.json',{'schema':'photo-source102-source27-exact-delta/v1','source102':ref(R/'native-inputs'/names[0]/'CURRENT-PROPOSAL.json.gz',before),'source27':ref(R/'native-inputs'/names[-1]/'CURRENT-PROPOSAL.json.gz',current),'catalog_sha256':c.digest(current['slot_catalog']),'candidate_count':18250,'unique_changed_candidates':23,'unchanged_candidates':18227,'groups':groups,'catalog_bindings_policies_unchanged':True,'native_proofs_applied':0})

inventory_path=R/'ROOT-CURRENT149-APPROVAL-INVENTORY-02.json';inventory=nr.read_json(inventory_path)
selected={r['candidate_id']:r for r in inventory['records']};assert len(selected)==77
verified={};history=[]
for entry in inventory['accepted_history']:
    for key in ('assignment','batch','acceptance'):nr.artifact(ROOT,entry[key])
    note=(ROOT/entry['batch']['file']).parent/'NOTE.json'
    result=nr.verify_batch(entry['assignment']['file'],entry['batch']['file'],str(note),root=ROOT,here=R)
    nr.verify_acceptance(ROOT,entry['acceptance'],result)
    history.append({k:result[k] for k in ('assignment_sha256','input_sha256','batch_sha256','note_sha256','statuses')})
    for cid,row in result['records'].items():
        if cid in selected and selected[cid]['batch']==entry['batch']:
            assert row['status']=='approved' and c.digest(row['proof'])==selected[cid]['proof_sha256']
            verified[cid]=(row,entry['batch'],entry['acceptance'],ref(note))
D=R/'native_batches/root-diagnostic70-149-01';assignment=R/'native-inputs/prepared/root-diagnostic70-149-01/ASSIGNMENT.json'
diag=nr.verify_batch(str(assignment),str(D/'BATCH.json'),str(D/'NOTE.json'),root=ROOT,here=R)
nr.verify_acceptance(ROOT,ref(D/'ROOT-ACCEPTANCE.json'),diag)
assert diag['statuses']=={'approved':0,'pending':32,'diagnostic_reviewed':38}
pending32=[]
for cid,row in diag['records'].items():
    if row['status']=='diagnostic_reviewed':
        assert cid not in verified;verified[cid]=(row,ref(D/'BATCH.json'),ref(D/'ROOT-ACCEPTANCE.json'),ref(D/'NOTE.json'))
    else:pending32.append({'candidate_id':cid,'ordinal':ordinal[cid],'status':'pending','proof_reuse_eligible':False})
assert len(verified)==115
reusable=[];stale=[]
for cid,(row,batch,acceptance,note) in sorted(verified.items(),key=lambda x:ordinal[x[0]]):
    mismatches=[]
    if row['source_after']!=current['candidates'][cid]:mismatches.append('whole_source_after')
    if row['proof']['catalog_sha256']!=c.digest(current['slot_catalog']):mismatches.append('catalog')
    closure=native.referenced_records(current['candidates'][cid],current)
    candidate_refs={key:current['candidates'][key] for key in closure if c.ID.fullmatch(key)}
    binding_refs={key:current['slot_bindings'][key] for key in closure if c.BINDING_ID.fullmatch(key)}
    if set(row['dependency_records'])!=set(candidate_refs):mismatches.append('dependency_ids')
    if row['reference_bindings']!=binding_refs:mismatches.append('reference_bindings')
    for child,record in row['dependency_records'].items():
        plain=copy.deepcopy(record);proof=plain['content'].pop('role_evidence',None)
        if child not in candidate_refs or plain!=candidate_refs[child]:mismatches.append('dependency_source:'+child)
        if child not in verified or proof!=verified[child][0]['proof']:mismatches.append('accepted_dependency_proof:'+child)
    assert row['proof']['reference_sha256']==closure
    value={'candidate_id':cid,'ordinal':ordinal[cid],'historically_accepted_status':row['status'],
        'whole_source_sha256':c.digest(current['candidates'][cid]),'review_sha256':c.digest(row),'proof_sha256':c.digest(row['proof']),
        'batch':batch,'historical_root_acceptance':acceptance,'note':note,
        'candidate_reference_closure':{key:c.digest(value) for key,value in candidate_refs.items()},
        'binding_reference_closure':{key:c.digest(value) for key,value in binding_refs.items()},
        'proof_binding_reference_sha256':closure,'role_ids':sorted(row['proof']['roles']),
        'new_source27_reuse_root_accepted':False,'proposed_action':'attach exact existing proof only after separate root acceptance; no source/conditions/effects/roles/bindings changes'}
    if mismatches:stale.append({**value,'mismatches':mismatches})
    else:reusable.append(value)
assert len(reusable)==115 and not stale and not set(verified)&union
save('PROPOSED-EXACT-PROOF-REUSE.json',{'schema':'photo-source27-existing-proof-reuse-proposal/v1','actor':'/root/batch_pipeline','root_acceptance_pending':True,'current_source_sha256':c.digest(current),'catalog_sha256':c.digest(current['slot_catalog']),
    'historical_positive_inventory':ref(inventory_path),'verified_positive_batch_history':history,'verified_diagnostic_batch':{k:diag[k] for k in ('assignment_sha256','input_sha256','batch_sha256','note_sha256','statuses')},
    'proposed_positive_proofs':77,'proposed_diagnostic_only_proofs':38,'proposed_total_proofs':115,'stale_or_changed':stale,'records':reusable,'excluded_pending32':pending32,
    'meaning_rereviews_created':0,'native_proofs_attached':0,'new_source27_root_acceptance_created':False,'whole_source_native_qualification_or_adoption_complete':False,'production_expected_count':18250,'production_pending0_gate_unchanged':True})

# Plan from source102's already qualified LOCAL metadata; no vector payload,
# model installation, numerical library or embedding provider is loaded.
assets=R/'batch-validation-01/assets';manifest=nr.read_json(assets/'photo_candidate_search.json')
assert manifest['layout_id']=='6d65405e211465d9bad45af24a98ff2046a764e7dda2d41f701353c0e4234fd2'
assert manifest['space']['provider']=='embeddinggemma2-local' and manifest['space']['dimensions']==768
meta_path=assets/manifest['metadata']['path'];raw=meta_path.read_bytes();assert hashlib.sha256(raw).hexdigest()==manifest['metadata']['sha256'];meta=nr.read_json(meta_path)
assert len(meta['positive_ids'])==18198 and len(meta['positive_ids'])==len(set(meta['positive_ids']))
assert (G/'scripts/photo_global_index.py').read_bytes()==(STRICT/'scripts/photo_global_index.py').read_bytes()
old_positive=set(meta['positive_ids']);new_positive={cid for cid,r in current['candidates'].items() if r['record_kind'] in docs.POSITIVE_KINDS}
reused=[];inference=[]
for cid in sorted(new_positive):
    recipe,text=docs.text(current['candidates'][cid]);text_sha=hashlib.sha256(text.encode()).hexdigest();old=meta['vector_recipes'].get(cid)
    if old and old['recipe']==recipe and old['text_sha256']==text_sha:
        execution=old['embedding_execution'];assert execution['space']==manifest['space'] and execution['kind']=='document' and execution['provider_executed'] is True
        reused.append({'candidate_id':cid,'recipe':recipe,'text_sha256':text_sha,'local_execution_sha256':c.digest(execution),'vector_sha256':execution['vector_sha256']})
    else:inference.append({'candidate_id':cid,'ordinal':ordinal[cid],'reason':'new_positive_document' if old is None else 'changed_full_projection_or_recipe','recipe':recipe,'text_sha256':text_sha,'previous_recipe':old.get('recipe') if old else None,'previous_text_sha256':old.get('text_sha256') if old else None})
handoff='cand_2e72784a26885ceaa1d645d25bd9a468';assert any(r['candidate_id']==handoff for r in reused)
assert len(new_positive)==18212 and len(reused)+len(inference)==18212
save('VECTOR-REUSE-PLAN.json',{'schema':'photo-source27-local-vector-reuse-plan/v1','root_acceptance_pending':True,'source102_layout':ref(assets/'photo_candidate_search.json',manifest),'source102_metadata':{'file':str(meta_path.relative_to(ROOT)),'file_sha256':manifest['metadata']['sha256']},
    'local_space':manifest['space'],'local_space_sha256':c.digest(manifest['space']),'new_positive_documents':len(new_positive),'existing_positive_documents':len(old_positive),'reuse_eligible_count':len(reused),'planned_local_document_inputs':len(inference),'planned_new_positive_documents':len(new_positive-old_positive),'planned_refreshed_existing_documents':sum(r['reason']=='changed_full_projection_or_recipe' for r in inference),'reusable_vectors':reused,'planned_inference':inference,
    'actual1299_vector_reuse_eligible':True,'actual1299_native_proof_qualified':False,'old_vector_payloads_read_or_rematerialized':False,'new_embeddings_or_models_loaded':0,'Gemini_calls':0,'execution_gate':'No source27 index/build/qualification/generation/query/receipt until root accepts exact proof reuse and actual1299 review plus required permission/after-state contract is complete. Future reuse must revalidate actual vector bytes/execution/space with existing APIs.'})
assert not attempts
pins={}
for name,module in sorted(sys.modules.items()):
    path=getattr(module,'__file__',None)
    if path and (name.startswith('photo_')or name in {'direct_review','native_reviews'}):
        p=Path(path).resolve();assert p.is_relative_to(G) or p.is_relative_to(R)
        pins[name]={'file':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
save('PLAN-VERIFICATION.json',{'schema':'photo-source27-incremental-preparation-verification/v1','source102_sha256':c.digest(before),'source27_sha256':c.digest(current),'catalog_sha256':c.digest(current['slot_catalog']),'unique_changed_candidates':23,'proposed_proof_reuse':115,'positive_proofs':77,'diagnostic_only_proofs':38,'stale_proofs':0,'root_acceptance_pending':True,
    'source27_proofs_applied':0,'qualified_source27_containers_created':0,'new_native_approvals_created':0,'production_expected_count':18250,'production_pending0_gate_unchanged':True,
    'remaining_without_reusable_current_judgment':18250-115,'planned_positive_documents':len(new_positive),'planned_vector_reuse':len(reused),'planned_local_document_inputs':len(inference),
    'runtime_index_generation_query_receipt_calls':0,'model_import_attempts':attempts,'model_numeric_provider_network_execution':0,'Gemini_calls':0,'Git_calls':0,'operating_source_catalog_binding_policy_changes':0,'consumer_and_verifier_pins':pins})
print(json.dumps({'changed_CIDs':23,'proofs_pending_root_reuse_acceptance':len(reusable),'vector_reuse_planned':len(reused),'local_inputs_planned':len(inference),'execution':0}),flush=True)
