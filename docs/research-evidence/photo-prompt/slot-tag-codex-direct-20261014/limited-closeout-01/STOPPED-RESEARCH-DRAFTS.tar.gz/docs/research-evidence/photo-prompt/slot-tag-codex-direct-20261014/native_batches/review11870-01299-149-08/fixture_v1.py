"""Manually authored controlled input, frozen before this run's B1 selection.
The reviewer already knew source1299. This is not a real/blind user request.
No selected source action or framing result is asserted as a baseline fact.
"""
from pathlib import Path
import sys,json,hashlib,copy
G=Path('/Users/chasoik/.cache/image-prompt/photo-shared-runtime/generations/fe5b593c819806a31803e40c620e6f2b28c3b54103f451dd6f38920f2d537258')
sys.path[:0]=[str(G/'scripts'),str(G/'precore')]
import photo_candidate_corpus as c,photo_semantic_evidence as n,photo_native_permission as pe,photo_permission_comparison as pc
O=Path(__file__).parent;CID='cand_2e72784a26885ceaa1d645d25bd9a468';W=n.witnesses
# Literal independent input design, not a semantic extraction from a source.
TEXT=('Controlled finite tabletop study. Existing image I and separate image I2 are distinct images. '
 'Existing rig U has exactly the independently addressable parts H1 and R1; existing rig V has exactly H2, H3 and R2. '
 'H1, H2 and H3 are hand-shaped articulated hand entities, each with the exact entity.type/v1 value hand. '
 'R1 and R2 are the nonhand opaque panels of their rigs, not faces or newly assumed human bodies. '
 'Existing generic physical item X has exact entity.kind/v1 value physical_item. Every named image, rig, part and item independently exists. '
 'H1, H2, H3 and X are mutually distinct; X is not a rig or panel. I and I2 are not the rigs, hands or item. '
 'X is literally visible in I now, with separate framing.visible_in entity.owner_id/v1 value I; X has no visible-in relation to I2. '
 'The hands and panels R1/R2 are currently included in I. '
 'No current shot scale, final participant crop, performed activity, physical contact geometry, item location or transfer completion is fixed. '
 'Framing, participant inclusion/visibility and performed activity may be selected later, including omission of the nonhand panels from I, '
 'while preserving the same X visibly in the same I and retaining all independent entities, identities, topology and their actual entity counts. '
 'Activity/event/concept additions are open; existing entity identity, existence, actual entity count and age are protected. '
 'The initiating target available to this controlled request is H1. The complete other-hands input scope is exactly H2 and H3. '
 'The complete framing-affected input scope is exactly H1,H2,H3,X,U,V,R1,R2. '
 'This includes every affected hand/item, both carrier rigs and every independently declared nonhand part. '
 'I is the framing operation owner and I2 is an unaffected separate image, not a participant or receiver. '
 'All actual parts of U and V are enumerated above; no hidden body, other participant, background object, reference image or additional source input exists in this finite controlled study. '
 'No human category, body count or additional anatomical part is implied by the hand-shaped entities. '
 'These exact scopes, entity distinctions and topology are input declarations independent of a retrieved candidate.')
OWNERS=['I','I2','U','V','H1','H2','H3','R1','R2','X'];FRAME=['H1','H2','H3','X','U','V','R1','R2'];OTHER=['H2','H3']

def a(aid,kind,dim='subject',**axes):
 return {'assertion_id':aid,'dimension':dim,'polarity':'required','source_span_ids':['request_1'],'affected_dimensions':[dim],
  'axes':{'native_schema':W.SCHEMA,'kind':kind,**axes},'evidence':{'meaning':'Controlled finite tabletop study.'}}
def reseal(core):core.pop('canonical_sha256',None);core['canonical_sha256']=c.digest(core);return core

def make_core():
 h=hashlib.sha256(TEXT.encode()).hexdigest();rb={'request_sha256':h,'request_envelope_sha256':c.digest({'request_text':TEXT}),
 'input_inventory':{'schema':W.INPUT_SCHEMA,'complete':True,'items':[{'id':'request','kind':'request_text','sha256':h}]},
 'active_spans':[{'span_id':'request_1','source_span_id':'request_1','input_id':'request','text':TEXT}]}
 rows=[]
 for owner in OWNERS:
  rows.append(a('owner_'+owner,'owner',owner=owner,owner_kind='entity'))
  rows.append(a('present_'+owner,'fact',owner=owner,property='entity.presence',value_type='entity.presence/v1',value='present'))
 rows.append(a('image_role','role',owner='I',role='image'))
 for hand in ['H1','H2','H3']:rows.append(a('type_'+hand,'fact',owner=hand,property='entity.type',value_type='entity.type/v1',value='hand'))
 rows.append(a('kind_X','fact',owner='X',property='entity.kind',value_type='entity.kind/v1',value='physical_item'))
 rows.append(a('item_visible','fact','framing',owner='X',property='subject.visibility',value_type='subject.visibility/v1',value='visible'))
 rows.append(a('item_image','fact','framing',owner='X',property='framing.visible_in',value_type='entity.owner_id/v1',value='I'))
 for part in ['H1','H2','H3','R1','R2']:
  rows.append(a('visible_'+part,'fact','framing',owner=part,property='subject.visibility',value_type='subject.visibility/v1',value='visible'))
 for left,right in [('H1','U'),('R1','U'),('H2','V'),('H3','V'),('R2','V')]:rows.append(a('part_'+left,'part_of',left=left,right=right))
 for left,right in [('H1','H2'),('H1','H3'),('H2','H3'),('X','H1'),('X','H2'),('X','H3'),('U','V'),('I','I2')]:rows.append(a('separate_'+left+'_'+right,'disjoint',left=left,right=right))
 for sid,members in [('other_hands',OTHER),('framing_affected',FRAME)]:
  inv={'schema':W.MEMBER_SCOPE_SCHEMA,'complete':True,'state':'known_present','input_binding':W.input_binding(rb),'reviewed_input_ids':['request'],
    'members':[{'owner_id':owner,'source_span_ids':['request_1'],'source_input_ids':['request']}for owner in members]}
  rows.append(a(sid,'existing_member_scope',scope_id=sid,inventory=W.canonical(inv)))
 core={'contract_version':'photo-authorial-core/v3','subject':'Existing finite tabletop hand-bearing rigs and item','source_request':TEXT,'baseline_prompt_en':TEXT,
  'request_binding':rb,'semantic_assertions':rows,'intent_lock':{'contract_version':'photo-intent-lock/v2',
  'locked_dimensions':['subject','identity','count','age'],'open_dimensions':['framing','action','event','concept'],
  'semantic_anchors':[{'dimension':'framing','target':'X','property':'subject.visibility'},{'dimension':'framing','target':'X','property':'framing.visible_in'}]}}
 return reseal(core)

def inventory(core):
 f=n.frozen_witnesses(core)
 return {'schema':'research-independent-permission-inventory/v1','phase':'before_discovery','core_sha256':core['canonical_sha256'],
  'core_payload_sha256':c.digest(core),'input_binding':pc.core_input_binding(core),'topology_sha256':c.digest(f['graph']),
  'owners':OWNERS,'scope_members':{'other_hands':OTHER,'framing_affected':FRAME},'anchors':pc.anchors_from_core(core),
  'reviewed_input_ids':['request'],'reviewed_span_ids':['request_1'],'complete':True,'state':'known',
  'reviewer':'/root/review_11870_12250 controlled input author','reason':
   'Directly authored and reviewed full single input. U consists exactly of H1,R1 and V of H2,H3,R2; therefore every actual participant part/carrier and item appears in the explicit eight-member affected union. I is operation owner, I2 distinct unaffected image. No hidden parts/people/unread input; this finite synthetic completeness is declared, not inferred by a selector/hash. All four protected whole dimensions and two exact scalar/relation anchors are inventoried. Framing and performed activity remain open and no desired source E value exists in the baseline. Candidate locator in the visibility mapping only identifies the known research workload, never establishes the actual X/I witness truth.',
  'witnesses':[{'candidate_id':CID,'source_fact_ref':'itemVisiblePreservation','target':'X','image':'I','dimension':'framing','property':'subject.visibility',
   'value':{'type':'subject.visibility/v1','value':'visible'},'assertion_id':'item_visible','input_ids':['request'],'span_ids':['request_1'],'frozen':True}]}

def freeze_input():
 core=make_core();inv=inventory(core)
 handle=pe.freeze_permission_inventory(core,inv,expected_inventory_sha256=c.digest(inv),reviewer='/root/review_11870_12250 independent controlled request review')
 return core,inv,handle
if __name__=='__main__':
 core,inv,handle=freeze_input()
 out={'schema':'photo-controlled-request-before-selected-B1/v1','request_text':TEXT,'core':core,'inventory':inv,
  'core_sha256':c.digest(core),'inventory_sha256':c.digest(inv),'freeze_payload':pe._payload(handle,'permission inventory'),
  'chronology':'This synthetic input is authored/frozen before this run exposes selected B1 or drafts its proof. Reviewer already knew source1299; this is neither a blind historical request nor real user/pixel evidence. The trusted completeness/chronology assertions are explicit manual fixture-author acts.',
  'native_proof':None,'root_acceptance':0,'operating':0}
 p=O/'PRE-DISCOVERY-REQUEST-v1.json';assert not p.exists();p.write_text(json.dumps(out,ensure_ascii=False,sort_keys=True,indent=2)+'\n');print(c.digest(out))
