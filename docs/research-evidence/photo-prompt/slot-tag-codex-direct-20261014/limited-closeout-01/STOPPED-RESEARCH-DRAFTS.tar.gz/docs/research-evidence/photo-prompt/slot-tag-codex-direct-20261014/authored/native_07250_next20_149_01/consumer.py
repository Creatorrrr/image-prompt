"""Explicit isolated fixture on two actual source copies. No generator/model/runtime activation."""
import sys,importlib.abc,json,pathlib,copy,hashlib,gzip
sys.dont_write_bytecode=True
class Block(importlib.abc.MetaPathFinder):
 def find_spec(self,fullname,path=None,target=None):
  if fullname.split('.')[0] in {'photo_local_embedding','torch','transformers','sentence_transformers','tensorflow','jax','mlx'}:raise RuntimeError(fullname)
sys.meta_path.insert(0,Block())
ROOT=pathlib.Path.cwd();R=ROOT/'docs/research-evidence/photo-prompt/slot-tag-codex-direct-20261014';O=R/'authored/native_07250_next20_149_01';G=pathlib.Path('/Users/chasoik/.cache/image-prompt/photo-shared-runtime/generations/fe5b593c819806a31803e40c620e6f2b28c3b54103f451dd6f38920f2d537258');sys.path[:0]=[str(G/'scripts'),str(G/'precore')]
import photo_candidate_corpus as c,photo_semantic_evidence as n,photo_slot_semantics as s,photo_search_layout as layout,prompt_generator as g
B=json.loads((O/'BATCH.json').read_text());S=json.loads(gzip.decompress((R/'native-inputs/root-handoff-envelope-source-plan-27/CURRENT-PROPOSAL.json.gz').read_bytes()));selected=[r for r in B['records'] if r['proof'] is not None]
D={**S,'candidates':{},'slot_bindings':{k:v for k,v in S['slot_bindings'].items() if v['candidate_id'] in {r['candidate_id'] for r in selected}}}
for r in selected:
 a=copy.deepcopy(r['source_after']);a['content']['role_evidence']=r['proof'];D['candidates'][r['candidate_id']]=a
# Explicit isolated-fixture trust act only: never claim this2CID set is the root source27 full corpus.
AUTH=n.permission_envelope.freeze_source_authority(D,expected_snapshot_sha256=c.digest(D),reviewer='/root/review_07250_08250 controlled two-source fixture, not root acceptance')
def assertion(aid,kind,dim='subject',**axes):
 return {'assertion_id':aid,'dimension':dim,'polarity':'required','source_span_ids':['fixture_span'],'axes':{'native_schema':n.witnesses.SCHEMA,'kind':kind,**axes},'evidence':{'meaning':'Independently authored existing photograph and stated existing readability/coherence; optional image treatment is not pre-frozen.'},'affected_dimensions':[dim]}
def core(row,actual='fixture_image_A'):
 pr=next(f for f in row['proof']['facts'] if f['mode']=='preservation');text='An independently existing photograph. '+pr['quote']+'. Its independently declared image owner is '+actual+'. Only the optional style treatment may change; identity and existing readability/coherence stay.'
 vals=[assertion('existing_image','owner',owner=actual,owner_kind='entity'),assertion('image_role','role',role='image',owner=actual),assertion('keep_literal','fact',dim=pr['dimension'],owner=actual,property=pr['property'],value_type=pr['value']['type'],value=pr['value']['value'])]
 for declaration in vals:declaration['evidence']={'meaning':text}
 return {'contract_version':'photo-authorial-core/v3','subject':text,'event':'No physical object movement or new subject.','setting':'An independently declared photograph, no physical environment added.','baseline_prompt_en':text,'request_binding':{'active_spans':[{'source_span_id':'fixture_span','text':text}]},'semantic_assertions':vals,'user_exclusions':[],'intent_lock':{'contract_version':'photo-intent-lock/v2','locked_dimensions':['concept','subject','identity','count','age','event'],'open_dimensions':['style'],'semantic_anchors':[{'dimension':pr['dimension'],'target':actual,'property':pr['property'],'text':pr['quote']}]}}
contract={'subject_category':'generic','domains':[],'intent_constraints':{'subject_categories':[],'domains':[]},'adult_allowed':False,'no_people':True}
picked={'subject':{'en':'An existing photograph','kind':[],'tags':[]},'location':{'en':'No setting selected','tags':[]},'action':{'en':'No action selected','tags':[]}}
results=[];fixtures=[]
for row in selected:
 cid=row['candidate_id'];bid=next(k for k,v in D['slot_bindings'].items() if v['candidate_id']==cid);rec=D['candidates'][cid];n.validate(rec,D['slot_catalog'],corpus=D)
 guarded=copy.deepcopy(D);guarded['candidates']={k:layout.guard_record(v,D) for k,v in D['candidates'].items()}
 a=core(row);fixtures.append({'ordinal':row['ordinal'],'positive_core':a,'actual_binding':D['slot_bindings'][bid]})
 tests=[('positive',a,True),('different_actual_image_UUID',core(row,'fixture_image_B'),True)]
 missing=copy.deepcopy(a);missing['semantic_assertions']=[x for x in missing['semantic_assertions'] if x['assertion_id']!='keep_literal'];tests.append(('missing_preservation',missing,False))
 wrong=copy.deepcopy(a);wrong['semantic_assertions'][-1]['axes']['value']='contradictory';tests.append(('wrong_preservation',wrong,False))
 absent=copy.deepcopy(a);absent['semantic_assertions']=[x for x in absent['semantic_assertions'] if x['axes']['kind']!='owner'];tests.append(('missing_existing_actual_owner',absent,False))
 role=copy.deepcopy(a);role['semantic_assertions']=[x for x in role['semantic_assertions'] if x['axes']['kind']!='role'];tests.append(('missing_independent_image_role',role,False))
 closed=copy.deepcopy(a);closed['intent_lock']['open_dimensions']=[];closed['intent_lock']['locked_dimensions'].append('style');tests.append(('whole_style_dimension_lock',closed,False))
 lock=copy.deepcopy(a);lock['intent_lock']['semantic_anchors']+=[{'dimension':'style','target':'fixture_image_A','property':'image.detail','text':'Do not change this actual image detail property.'}];tests.append(('exact_original_image_detail_lock',lock,False))
 parent=copy.deepcopy(a);parent['intent_lock']['semantic_anchors']+=[{'dimension':'style','target':'fixture_image_A','property':'image','text':'Do not change this actual image or any image property.'}];tests.append(('original_parent_image_property_lock',parent,False))
 child=copy.deepcopy(a);child['intent_lock']['semantic_anchors']+=[{'dimension':'style','target':'fixture_image_A','property':'image.detail.local_part','text':'Do not change this image detail part.'}];tests.append(('partial_child_of_original_image_detail_lock',child,False))
 for form,data in [('full',D),('compact',guarded)]:
  entry=c.entry(data,cid,bid,realization_id='base');fit=s.fit(D['slot_catalog']['image_detail'],data['candidates'][cid],'',realization_id='base',source_data=D)
  for name,co,expected in tests:
   admission=n.admission(entry,co,source_data=D);eligible=g.core_entry_eligible(D,co,contract,picked,'image_detail',entry)
   results.append({'ordinal':row['ordinal'],'form':form,'case':name,'expected_final_eligible':expected,'actual_final_eligible':eligible,'admission':admission,'fit':fit,'pass':eligible==expected and fit['status']=='eligible'})
 (O/f"FIXTURE-SOURCE-{row['ordinal']}.json").write_text(json.dumps({'record':rec,'core':a,'actual_binding':D['slot_bindings'][bid]},ensure_ascii=False,indent=2)+'\n')
# Additional role has no persistent binding; prove fit only, never redirect original ID.
cid=next(r['candidate_id'] for r in selected if r['ordinal']==7443);extra=s.fit(D['slot_catalog']['color_grading'],D['candidates'][cid],'',realization_id='base',source_data=D)
report={'schema':'photo-native-isolated-exact-consumer-check/v1','actual_source_cid_count':2,'source27_full_authority_claim':False,'fixture_snapshot_sha256':c.digest(D),'authority_boundary':'Explicit isolated reviewer trust for actual2source copies and proofs; not root acceptance, production source27, activation, user-request or pixel evidence.','modules':{k:{'file':m.__file__,'raw_sha256':hashlib.sha256(pathlib.Path(m.__file__).read_bytes()).hexdigest()} for k,m in [('native',n),('corpus',c),('semantics',s),('layout',layout),('consumer',g)]},'checks':results,'extra_unbound_color_grading_role_fit':extra,'extra_role_binding_boundary':'New optional/direct .72 binding would need reviewed deny_domains product,jewelry,food,wildlife; no current binding redirected or changed.','total':len(results),'passed':sum(x['pass'] for x in results),'fixtures':fixtures,'operating_qualified_count':0,'model_calls':0,'network_calls':0}
(O/'CONSUMER-RESULTS.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print('passed',report['passed'],'/',len(results),'extra',extra['status']);print([(x['ordinal'],x['form'],x['case'],x['actual_final_eligible'],x['admission']['reason']) for x in results if not x['pass']])
