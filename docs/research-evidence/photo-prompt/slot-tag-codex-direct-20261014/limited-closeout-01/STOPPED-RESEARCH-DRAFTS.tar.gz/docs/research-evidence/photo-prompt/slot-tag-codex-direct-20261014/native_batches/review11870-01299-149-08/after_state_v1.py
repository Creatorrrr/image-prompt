"""Independent typed controlled result input; no real image/pixel observation."""
from common_v1 import *
AFTER_TEXT=('Controlled typed result. Existing images I/I2, rigs U/V, hand entities H1/H2/H3, panels R1/R2 and physical item X remain the same independently present entities. '
 'U still consists of H1/R1; V still consists of H2/H3/R2. All original distinctness and topology remain. '
 'In result image I the selected shot.scale is macro and framing.coverage is hands_only_participant_anatomy. '
 'The physical_handoff_in_progress action.interaction.exchange is on X with H1/H2/H3 as actual participating hands. '
 'H1/H2/H3 are visible as participant anatomy and panels R1/R2 are hidden by this participant crop, while the rigs still exist. '
 'X is literally visible in the same I, with exact framing.visible_in entity.owner_id/v1 value I; not I2. '
 'This is a manually authored typed finite-fixture result report, not a photograph, actual user request, inferred prompt substring or model-generated verification.')

def after_core(core):
 z=copy.deepcopy(core);z['source_request']=AFTER_TEXT;z['baseline_prompt_en']=AFTER_TEXT
 h=hashlib.sha256(AFTER_TEXT.encode()).hexdigest()
 rb={'request_sha256':h,'request_envelope_sha256':c.digest({'typed_result_text':AFTER_TEXT}),
  'input_inventory':{'schema':n.witnesses.INPUT_SCHEMA,'complete':True,'items':[{'id':'result','kind':'request_text','sha256':h}]},
  'active_spans':[{'span_id':'result_1','source_span_id':'result_1','input_id':'result','text':AFTER_TEXT}]}
 z['request_binding']=rb
 for assertion in z['semantic_assertions']:
  assertion['source_span_ids']=['result_1'];assertion['evidence']={'meaning':'Controlled typed result.'}
  if assertion['axes']['kind']=='existing_member_scope':
   inv=json.loads(assertion['axes']['inventory']);inv['input_binding']=n.witnesses.input_binding(rb);inv['reviewed_input_ids']=['result']
   for member in inv['members']:member['source_span_ids']=['result_1'];member['source_input_ids']=['result']
   assertion['axes']['inventory']=n.witnesses.canonical(inv)
 def result_fact(fid,dim,owner,prop,val):
  return {'assertion_id':fid,'dimension':dim,'polarity':'required','source_span_ids':['result_1'],'affected_dimensions':[dim],
   'axes':{'native_schema':n.witnesses.SCHEMA,'kind':'fact','owner':owner,'property':prop,'value_type':prop+'/v1','value':val},'evidence':{'meaning':'Controlled typed result.'}}
 z['semantic_assertions'] +=[result_fact('result_macro','framing','I','shot.scale','macro'),
  result_fact('result_coverage','framing','I','framing.coverage','hands_only_participant_anatomy'),
  result_fact('result_handoff','action','X','action.interaction.exchange','physical_handoff_in_progress')]
 z['semantic_assertions'] +=[result_fact('result_visibility_'+owner,'framing',owner,'subject.visibility',state)
  for owner,state in [('H1','visible'),('H2','visible'),('H3','visible'),('R1','hidden'),('R2','hidden')]]
 z['intent_lock']['locked_dimensions']+=['framing','action'];z['intent_lock']['open_dimensions']=['event','concept']
 return fi.reseal(z)

def evidence(plan):
 obligation=pe._payload(plan,'permission plan')['obligations'][0]
 return [{'candidate_id':CID,'realization_id':'base','fact_ref':'itemVisiblePreservation',
  'original_assertion_sha256':obligation['core_assertion_sha256'],'original_relation_sha256':obligation['relation_assertion_sha256'],
  'scalar_assertion_id':'item_visible','relation_assertion_id':'item_image'}]
if __name__=='__main__':
 core,inv,cap,authority=frozen_inputs();es=entries(core)
 plan=pe.freeze_permission_plan(authority,core,[es[0]],inventory=cap,assessment=load('MANUAL-IMPACT-ASSESSMENT-v1.json'),contracts=contracts(),reviewer='/root/review_11870_12250 directly authored impact plan')
 result=after_core(core);expected=c.digest(result)
 handle=pe.freeze_after_state(plan,result,expected_after_sha256=expected,evidence=evidence(plan),reviewer='/root/review_11870_12250 manually authored independent typed finite-result input')
 print(json.dumps(save('TYPED-AFTER-STATE-v1.json',{'schema':'photo-controlled-typed-result-review/v1','after_core':result,'after_core_sha256':expected,'original_evidence':evidence(plan),
  'receipt':pe._payload(handle,'after state'),'real_user_or_pixels':False,'root_acceptance':0,'operating':0})))
 with pe.trusted_permission_session(authority,plan,after_state=handle):
  for entry in es:assert n.audit_final_scalar_preservation([entry],core)['receipts']
 print('source-bound same X/I final typedPR PASS fullcompact')
