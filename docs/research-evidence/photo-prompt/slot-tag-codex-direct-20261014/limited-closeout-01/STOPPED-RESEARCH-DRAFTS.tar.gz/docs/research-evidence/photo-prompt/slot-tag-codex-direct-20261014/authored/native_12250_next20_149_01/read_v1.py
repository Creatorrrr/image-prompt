"""Lossless selected-source reader; inventory preparation is not semantic approval."""
import json,gzip,hashlib,sys
from pathlib import Path
R=Path(__file__).resolve().parents[2]
def h(x):return hashlib.sha256(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
rows={}
for path in sorted((R/'authored').glob('native_12250_09250_10250.*.json')):
 a=json.loads(path.read_text())
 for r in a.get('records',[]):
  if 9250<=r['ordinal']<9925 and 'facts'in r:rows[r['ordinal']]=(path,a,r)
S=json.loads(gzip.decompress((R/'native-inputs/root-handoff-envelope-source-plan-27/CURRENT-PROPOSAL.json.gz').read_bytes()))
for o in map(int,sys.argv[1:]):
 path,a,r=rows[o];cid=r['candidate_id'];current=S['candidates'][cid]
 print(json.dumps({'ordinal':o,'CID':cid,'frozen_draft_file':str(path),'draft_canonical':h(a),'draft_row_sha256':h(r),'wholecurrent':current,'same_current_as_whole_read_draftbefore':current==r['source_before'],'same_current_as_whole_read_draftafter':current==r['source_after'],'ownbinding_exact':{k:v for k,v in S['slot_bindings'].items()if v['candidate_id']==cid}==r['original_own_bindings'],'original_ownbindings':r['original_own_bindings'],'reference_records':r['reference_records'],'reference_bindings':r['reference_bindings'],'draftfacts':r['facts'],'draftroles':r['role_proposals'],'original5Blocator':{k:v for k,v in r['original5B'].items()if k!='row'}},ensure_ascii=False,separators=(',',':')))
print('SOURCE27',h(S),'CAT',h(S['slot_catalog']))
