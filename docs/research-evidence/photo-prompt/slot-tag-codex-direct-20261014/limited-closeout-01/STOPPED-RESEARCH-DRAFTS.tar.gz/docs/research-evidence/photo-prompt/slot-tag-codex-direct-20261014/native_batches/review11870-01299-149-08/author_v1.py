"""Literal fresh08 source/fact/owner/role authoring. No old approval conversion."""
from pathlib import Path
import sys,json,gzip,copy,hashlib
G=Path('/Users/chasoik/.cache/image-prompt/photo-shared-runtime/generations/fe5b593c819806a31803e40c620e6f2b28c3b54103f451dd6f38920f2d537258');sys.path[:0]=[str(G/'scripts'),str(G/'precore')]
import photo_candidate_corpus as c,photo_semantic_evidence as n,photo_candidate_realizations as real
R=Path('docs/research-evidence/photo-prompt/slot-tag-codex-direct-20261014');O=Path(__file__).parent;D=R/'native-inputs/prepared/review11870-01299-149-08'
A=json.loads((D/'ASSIGNMENT.json').read_text());I=json.loads((D/'INPUT.json').read_text());P=json.loads((D/'PREPARED-PACKET.json').read_text());CID=A['ids'][0]
S=json.loads(gzip.decompress(Path(I['current_snapshot']['file']).read_bytes()));CAT=I['catalog_review']['after'];before=P['original_records'][CID];after=P['current_records'][CID];old=P['historical_compiled_rows'][CID]
assert c.digest(I)=='5bca1028e4bda235a0140a19812977a950df92070dcad4c9d917c065d752b480';assert c.digest(S)=='d1039bd6a55f6c767a0049704457ed48aa109c273f557d7e407673455bb72ba3';assert S['slot_catalog']==CAT and after==S['candidates'][CID] and real.ids(after)==['base'];assert P['references'][CID]==P['reference_bindings'][CID]=={}
# Actual input/whole source read completed; no tags, old effects or metadata are positive anchors.
def F(fid,mode,target,prop,val,quote,dim='subject',requires=(),receivers=()):
 assert quote in after['content']['application_contract']
 f={'id':fid,'realization_id':'base','mode':mode,'dimension':dim,'target':target,'property':prop,'value':{'type':prop+'/v1','value':val},
  'requires':list(requires),'pointer':'/content/application_contract','quote':quote}
 if mode=='effect':f.update(operation='set_value',receivers=list(receivers))
 return f
facts=[
 F('initiatingPresence','prerequisite','initiating_hand','entity.presence','present','Each hand must have independently declared entity presence'),
 F('otherPresence','prerequisite','other_hands','entity.presence','present','Each hand must have independently declared entity presence'),
 F('initiatingType','prerequisite','initiating_hand','entity.type','hand','the exact entity.type/v1 value hand'),
 F('otherType','prerequisite','other_hands','entity.type','hand','the exact entity.type/v1 value hand'),
 F('itemPresence','prerequisite','exchange_item','entity.presence','present','The item must have independent entity presence'),
 F('itemKind','prerequisite','exchange_item','entity.kind','physical_item','the exact entity.kind/v1 value physical_item'),
 F('framePresence','prerequisite','framing_affected_owners','entity.presence','present','with exact existing presence for every member'),
 F('imagePresence','prerequisite','image','entity.presence','present','same actual image selected as the image target'),
 F('itemVisiblePreservation','preservation','exchange_item','subject.visibility','visible',
   'the separate literal framing/subject.visibility/subject.visibility/v1 value visible on the same item',dim='framing',requires=['itemPresence','imagePresence'])]
requirements=['initiatingPresence','otherPresence','initiatingType','otherType','itemPresence','itemKind','framePresence','imagePresence','itemVisiblePreservation']
frame_rx=['initiating_hand','other_hands','exchange_item','framing_affected_owners']
facts +=[
 F('macroApp','effect','image','shot.scale','macro','Select macro shot scale',dim='framing',requires=requirements,receivers=frame_rx),
 F('coverageApp','effect','image','framing.coverage','hands_only_participant_anatomy',
  'Select macro shot scale and hands-only participant framing. Only the participating hands are visible as participant anatomy; the existing item remains visible, and this does not require deletion of unrelated background.',dim='framing',requires=requirements,receivers=frame_rx),
 F('exchangeApp','effect','exchange_item','action.interaction.exchange','physical_handoff_in_progress',
  'Perform the physical handoff in progress on the selected item with every selected hand as an actual receiver.',dim='action',requires=requirements,receivers=['initiating_hand','other_hands'])]
roles={tag:{'spec_sha256':c.digest(CAT[tag]),'scope':'whole_record','realization_ids':['base'],'fact_refs':refs,'support_modes':['effect']} for tag,refs in [
 ('shot_scale',['macroApp']),('subject_framing',['coverageApp']),('action',['exchangeApp']),('relational_action',['exchangeApp'])]}
units=[{'realization_id':'base','pointer':'/content/application_contract','quote':after['content']['application_contract'],'disposition':'semantic','fact_refs':[f['id']for f in facts]}]
for lang in ['en','ko']:
 units.append({'realization_id':'base','pointer':'/content/'+lang,'quote':after['content'][lang],'disposition':'semantic_reference','fact_refs':['macroApp','coverageApp','exchangeApp'],
  'reference_relation':'partial_restatement','retained_constraint_rationale':
  ('The complete English field explicitly retains existing hands physically handing off one existing item, macro framing and only their hands visible as participant anatomy.' if lang=='en' else
   'The complete Korean field explicitly retains 기존 물체 하나를 실제로 주고받는 여러 기존 손, 매크로 구도 and 참여자의 신체 부위는 그 손들만 보인다.')+
  ' It is a partial restatement of exactly these three own canonical application effects. Preserve existing targets, the performed action, image scale, participant-anatomy exclusion, original complete selected hand/item/framing inventory receiver union and all independently consumed application guards/P/PR; do not infer a human body, a common/different carrier, precise contact, item type, location, ownership completion, lens or focus. Only full App supplies the complete selection/permission/final-preservation contract; the short field is not independently quoted as proving that complete obligation or stronger owner scope. No extra E duplicate is authored.'})
ownerbindings=[]
for target in ['image','initiating_hand','exchange_item']:
 ownerbindings.append({'target':target,'origin':'existing','introduced_by':None,'selector':{'kind':'selected_existing_owner'}})
for target in ['other_hands','framing_affected_owners']:
 ownerbindings.append({'target':target,'origin':'existing','introduced_by':None,'selector':{'kind':'selected_existing_member_scope',
  'scope_schema':n.witnesses.MEMBER_SCOPE_SCHEMA,'target_semantics':'each_member','receiver_semantics':'all_members'}})
basis=('Fresh08 direct whole original/current EN/KO/application, all six guards, canonical original E3 addresses, selected complete variable receiver scopes, current exact old5B, original optional/direct composition binding weight .8 with empty subject applicability and empty CID/binding closure reviewed. Full149 shot_scale/subject_framing/action/relational_action and actual neighboring composition/contact/pose/count/prop/framing specs read. Root deliberately selected bounded physical item handoff, then same-item/same-image preservation and mandatory eligibility; this is not the sole meaning of former exchange label. Exactly three App E facts select macro, hands-only participant anatomy and performed physical handoff; all actual Rx, union overlaps, individual typed P and itemVisiblePreservation stay separate. EN/KO whole short fields partially restate own App through one-hop references rather than falsely proving complete scope/guard duties or adding six duplicate E facts. Item visible is literal preservation consumed independently plus same actual image relation guard. Existing image/hands/item/all frame members are exact P; every hand is explicit hand type, item exact generic physical_item. Action remains E, never baseline P/context/no-op. Actual identity/topology, per-hand disjointness, complete before-discovery request scopes and every lock remain necessary. No fixed person/body count, legal ownership, trajectory, contact geometry, extra entity, subtype, lens or focus is supplied. Four roles reflect scale, participant coverage, concrete activity and explicit item+allhands interaction; no invented static hand pose, support/contact or independent composition layout. Source-only mandatory duties additionally require trusted full source authority, independent finite controlled request/inventory, exhaustive protected-anchor impact plan and source-bound typed same-item/same-image after-state; shape/freeze/hashes do not prove request/pixel semantic truth. Controlled experiments are synthetic, with reviewer prior source knowledge disclosed; no actual user/pixel or root/operating approval.')
proof={'schema':n.SCHEMA,'meaning_sha256':n.meaning_sha256(after),'catalog_sha256':c.digest(CAT),'complete':True,'facts':facts,'roles':roles,
 'owner_maps':{'base':{'schema':n.MEMBER_OWNER_SCHEMA,'bindings':ownerbindings}},'source_units':units,'effect_sets':{'base':n.effect_set(after,'base')},
 'dependencies':{'base':[]},'reference_sha256':{},'guard_sets':{'base':n.source_guard_set(after,'base',S)},'profile_contracts':{'base':None},
 'permission_envelopes':copy.deepcopy(after['content']['permission_envelope']),
 'review':{'basis':basis,'whole_source_reviewed':True,'source_correction':{'before_sha256':n.meaning_sha256(before),'after_sha256':n.meaning_sha256(after),
 'rationale':'Exact root-selected bounded physical-handoff, same-image and mandatory execution source retained; no worker source change. '+basis},
 'original_review':{'candidate_id':CID,'source_record_sha256':old['source_record_sha256'],'catalog_sha256':old['catalog_sha256'],
 'decision_sha256':I['original_decisions'][CID]['row_sha256'],'artifact':I['original_decisions'][CID]['file']+'#item='+str(I['original_decisions'][CID]['item'])},
 'native_review':{'reviewer':A['task_name'],'method':'codex_subagent_direct_source_read','native_contract_sha256':''}}}
proof['review']['native_review']['native_contract_sha256']=n.native_contract_sha256(proof)
record=copy.deepcopy(after);record['content']['role_evidence']=proof;S['candidates'][CID]=record;n.validate(record,CAT,corpus=S)
rev=I['required_revisions'][CID]
row={'candidate_id':CID,'ordinal':1299,'status':'approved','rationale':basis,'source_before':before,'source_after':after,
 'delta':[{'pointer':'/'+k,'before_exists':True,'before':before[k],'after_exists':True,'after':after[k],
 'reason':'Exact root-selected bounded source correction, unchanged by worker08. '+basis}for k in ['content','conditions','effects']if before[k]!=after[k]],
 'original_compiled':I['original_decisions'][CID],'proof':proof,'dependency_records':{},'reference_bindings':{},'source_reread_complete':True,
 'reference_reread_complete':True,'revision':{'prior_review':rev['prior_review'],'memo_artifacts':rev['memo_artifacts'],'rationale':'Fresh08 source and permission/final-Preservation review; previous pending06 and prepared07 remain immutable. '+basis}}
batch={'schema':'photo-codex-native-review-batch/v1','task_name':A['task_name'],'model':A['model'],'reasoning_effort':A['reasoning_effort'],
 'assignment_sha256':c.digest(A),'input_sha256':c.digest(I),'prepared_count':1,'actual_read_count':1,'records':[row]}
note={k:batch[k]for k in ['task_name','model','reasoning_effort','assignment_sha256','input_sha256','prepared_count','actual_read_count']};note.update(schema='photo-codex-native-review-note/v1',batch_sha256=c.digest(batch),whole_source_read_ids=[CID],whole_dependency_read_ids=[CID])
if '--draft'in sys.argv:
 p=O/'LITERAL-DRAFT-v1.json';assert not p.exists();p.write_text(json.dumps({'batch':batch,'note':note,'boundary':'Fresh manually authored whole source proof; actual controlled consumer/permission/final checks not yet run. Draft status not a final delivery or root approval.'},ensure_ascii=False,sort_keys=True,indent=2)+'\n');print('draft_shape_pass',c.digest(proof))
