"""Exact source28 carrier4 full/compact consumer controls. No source/code writes."""
import copy,hashlib,importlib.abc,json,sys
from pathlib import Path
ROOT=Path.cwd();R=ROOT/'docs/research-evidence/photo-prompt/slot-tag-codex-direct-20261014';D=R/'native-inputs/prepared/review08250-carrier4-149-01';O=R/'native_batches/review08250-carrier4-149-01';W=R/'worker-notes/native_08250_carrier4_149_01';G=Path('/Users/chasoik/.cache/image-prompt/photo-shared-runtime/generations/fe5b593c819806a31803e40c620e6f2b28c3b54103f451dd6f38920f2d537258');forbidden=[]
class Deny(importlib.abc.MetaPathFinder):
 def find_spec(self,fullname,path=None,target=None):
  if fullname.split('.')[0] in {'torch','transformers','sentence_transformers','tensorflow','jax','mlx','google','openai','anthropic','requests','httpx'}:forbidden.append(fullname);raise AssertionError(fullname)
sys.meta_path.insert(0,Deny());sys.dont_write_bytecode=True;sys.path[:0]=[str(G/'scripts'),str(G/'precore')]
import photo_semantic_evidence as n
import photo_candidate_corpus as c
import photo_search_layout as layout
import prompt_generator as g
# Load research verifier only after frozen consumers. It imports direct_review which
# prepends the working scripts path; restore frozen precedence before any execution.
sys.path.insert(0,str(R));import native_reviews as nr
sys.path[:]=[str(G/'scripts'),str(G/'precore')]+[p for p in sys.path if p not in {str(ROOT/'skills/photo-prompt-image-generator/scripts'),str(G/'scripts'),str(G/'precore')}]
H=c.digest;raw=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_text())
assert nr.native is n and raw(n.__file__)=='722a4be059b95c6a875cffa00d106ba63d7288c16ea8b155f13eb0e4f183104a'
A=read(D/'ASSIGNMENT.json');I=nr.artifact(ROOT,A['input']);S=nr.artifact(ROOT,I['current_snapshot']);OR=nr.artifact(ROOT,I['original_snapshot']);B=read(O/'BATCH.json');CAT=S['slot_catalog'];assert H(S)=='e1c88b27e881ac11a179e09a9a41f4b2e69832679d4bf9c23b2b5e7099e6b696'
V=nr.verify_batch(str((D/'ASSIGNMENT.json').relative_to(ROOT)),str((O/'BATCH.json').relative_to(ROOT)),str((O/'NOTE.json').relative_to(ROOT)));assert V['statuses']=={'approved':4,'pending':0,'diagnostic_reviewed':0} and not V['root_accepted']
# Independent synthetic requests. Literal actual owners/requirements below do not
# copy any desired E value, and never claim actual human requester or image truth.
REQ={6801:[('actor_exists','actor_A','subject','entity.presence','entity.presence/v1','present'),('face_exists','face_A','subject','entity.presence','entity.presence/v1','present'),('eyes_exist','eyes_A','subject','entity.presence','entity.presence/v1','present'),('actor_face','actor_A','subject','anatomy.face.presence','anatomy.face.presence/v1','present'),('face_eyes','face_A','subject','anatomy.eyes.presence','anatomy.eyes.presence/v1','present'),('allowed_group','actor_A','subject','entity.category_group','entity.category_group/v1','human_or_animal')],6807:[('image_exists','image_A','subject','entity.presence','entity.presence/v1','present'),('actor_exists','actor_A','subject','entity.presence','entity.presence/v1','present'),('actor_head','actor_A','subject','anatomy.head.presence','anatomy.head.presence/v1','present'),('human_category','actor_A','subject','entity.category','entity.category/v1','human'),('portrait_link','image_A','composition','image.portrait_subject','entity.owner_id/v1','actor_A')],6825:[('garment_exists','garment_A','subject','entity.presence','entity.presence/v1','present'),('swimsuit','garment_A','appearance','wardrobe.garment_type','wardrobe.garment_type/v1','swimsuit'),('back_opening','garment_A','appearance','wardrobe.back_opening.presence','wardrobe.back_opening.presence/v1','present')],6867:[('garment_exists','garment_A','subject','entity.presence','entity.presence/v1','present'),('swim_bottom','garment_A','appearance','wardrobe.garment_type','wardrobe.garment_type/v1','swim_bottom'),('waistband','garment_A','appearance','wardrobe.waistband.presence','wardrobe.waistband.presence/v1','present')]}
SELECTIONS={6801:{'actor':'actor_A','face':'face_A','eyes':'eyes_A'},6807:{'actor':'actor_A'},6825:{'garment':'garment_A'},6867:{'garment':'garment_A'}}
COUNTS={6801:6,6807:4,6825:3,6867:3}

def fixture(o,defect=None,anchor=None,whole=None,alias=None,parent=None,unknown=False,animal=False):
 if o==6801:
  owners={'actor_A':'animal' if animal else 'human','face_A':'biological_face','eyes_A':'biological_eye_region','actor_B':'human','face_B':'biological_face','eyes_B':'biological_eye_region','other_A':'unrelated_owner'};part=[['face_A','actor_A'],['eyes_A','face_A'],['face_B','actor_B'],['eyes_B','face_B']];disjoint=[['actor_A','actor_B'],['actor_A','other_A'],['actor_B','other_A']];roles={}
  if defect=='missing_face_part':part.remove(['face_A','actor_A'])
  if defect=='wrong_face_part':part.remove(['face_A','actor_A']);part.append(['face_A','actor_B']);disjoint=[['actor_A','other_A'],['actor_B','other_A']]
  if defect=='missing_eyes_part':part.remove(['eyes_A','face_A'])
  if defect=='wrong_eyes_part':part.remove(['eyes_A','face_A']);part.append(['eyes_A','face_B']);disjoint=[['actor_A','other_A'],['actor_B','other_A']]
 elif o==6807:
  owners={'image_A':'portrait_image','image_B':'portrait_image','actor_A':'human','actor_B':'human','other_A':'unrelated_owner'};part=[];disjoint=[['image_A','image_B'],['actor_A','actor_B'],['image_A','actor_A'],['image_A','actor_B'],['image_A','other_A'],['actor_A','other_A']];roles={'image':'image_A'}
 else:
  owners={'garment_A':'garment','garment_B':'garment','human_A':'human','other_A':'unrelated_owner'};part=[];disjoint=[['garment_A','garment_B'],['garment_A','human_A'],['garment_A','other_A'],['garment_B','human_A'],['garment_B','other_A']];roles={}
 if unknown:disjoint=[]
 equivalent=[]
 if alias:
  original,alias_id=alias;owners[alias_id]=owners[original];equivalent=[[alias_id,original]]
 if parent:
  child,parent_id=parent;owners[parent_id]='containing_owner';part.append([child,parent_id])
 declared=[]
 for aid,owner,dim,prop,vt,val in REQ[o]:
  if defect=='missing_'+aid:continue
  actual_owner='other_A' if defect=='other_'+aid else owner
  actual_value=('actor_B' if aid=='portrait_link' else 'wrong_declared_value') if defect=='wrong_'+aid else val
  actual_type='different.namespace/v1' if defect=='type_'+aid else vt
  if defect=='literal_human_only' and aid=='allowed_group':prop='entity.category';actual_type='entity.category/v1';actual_value='human'
  if defect=='literal_animal_only' and aid=='allowed_group':prop='entity.category';actual_type='entity.category/v1';actual_value='animal'
  declared.append((aid,actual_owner,dim,prop,actual_type,actual_value))
 text='Independent synthetic controlled caller request. Actual owners are explicitly declared: '+json.dumps(owners,sort_keys=True)+'. Explicit part ownership is '+json.dumps(part)+'. Explicit independently separate ownership is '+json.dumps(disjoint)+'. Actual common roles are '+json.dumps(roles)+'. Exact frozen requirements are '+json.dumps(declared)+'. These values are independently required before any optional retrieval; they do not freeze the desired glance, skeptical expression, top-margin placement, V geometry or outward fold. For group membership this caller explicitly declares human_or_animal inclusion on the selected actor; this is an application-specific typed assertion, not a standard OR inference. The garments are standalone existing owned garments in a human scene; no wearing relation is specified.'
 if alias:text+=' Explicit alias equivalence '+json.dumps(equivalent)+'.'
 if anchor:text+=' The caller locks exact property '+json.dumps(anchor)+'.'
 if whole:text+=' The caller locks the entire '+whole+' dimension.'
 rows=[]
 def stmt(aid,kind,dim='subject',**axes):rows.append({'assertion_id':aid,'dimension':dim,'polarity':'required','source_span_ids':['controlled_request'],'affected_dimensions':[dim],'axes':{'native_schema':n.witnesses.SCHEMA,'kind':kind,**axes},'evidence':{'controlled_request':text}})
 for who,kind in owners.items():stmt('owner_'+who,'owner',owner=who,owner_kind=kind)
 for role,who in roles.items():stmt('role_'+role,'role',role=role,owner=who)
 for ix,(left,right) in enumerate(part):stmt('part_'+str(ix),'part_of',left=left,right=right)
 for ix,(left,right) in enumerate(disjoint):stmt('disjoint_'+str(ix),'disjoint',left=left,right=right)
 for ix,(left,right) in enumerate(equivalent):stmt('alias_'+str(ix),'equivalent',left=left,right=right)
 anchors=[]
 for aid,owner,dim,prop,vt,val in declared:
  stmt('fact_'+aid,'fact',dim,owner=owner,property=prop,value_type=vt,value=val)
  if dim!='subject':anchors.append({'dimension':dim,'target':owner,'property':prop})
 if anchor:anchors.append({'dimension':anchor[0],'target':anchor[1],'property':anchor[2]})
 edim='expression' if o==6801 else 'composition' if o==6807 else 'appearance';lock=['subject']+([whole] if whole and whole!='subject' else []);op=[edim] if edim not in lock else []
 core={'contract_version':'photo-authorial-core/v3','subject':text,'baseline_prompt_en':text,'request_binding':{'active_spans':[{'source_span_id':'controlled_request','text':text}]},'semantic_assertions':rows,'user_exclusions':[],'intent_lock':{'contract_version':'photo-intent-lock/v2','locked_dimensions':lock,'open_dimensions':op,'semantic_anchors':anchors}};core['canonical_sha256']=H(core);core['core_id']=core['canonical_sha256'][:16];return core

def selection(rec,core,o,choices=None):
 proof=rec['content']['role_evidence'];return {'schema':n.OWNER_SELECTION_SCHEMA,'core_sha256':core['canonical_sha256'],'owner_graph_sha256':H(n.frozen_witnesses(core)['graph']),'entries':[{'candidate_id':rec['id'],'realization_id':'base','meaning_sha256':proof['meaning_sha256'],'qualification_sha256':H(proof),'bindings':[{'target':target,'owner_id':owner} for target,owner in (choices or SELECTIONS[o]).items()]}]}
def ent(view,rec,core,o,bid=None,choices=None,choose=True):return c.entry(view,rec['id'],bid,realization_id='base',**({'owner_selections':selection(rec,core,o,choices)} if choose else {}))
def contract(category='human',domains=[]):return {'subject_category':category,'adult_allowed':False,'domains':domains,'intent_constraints':{'domains':domains,'subject_categories':[]}}
def picked(category='human'):return {'subject':{'en':'Independent controlled '+category+' scene','tags':[category]},'action':{},'location':{}}
checks=0;results=[];cores=[]
def check(cond,label,*detail):
 global checks
 checks+=1
 if not cond:raise AssertionError((label,*detail))
def consumer(data,core,rec,o,entry,category='human',domains=[]):
 vals={slot:g.core_entry_eligible(data,core,contract(category,domains),picked(category),slot,entry) for slot in rec['content']['role_evidence']['roles']};return vals
for row in B['records']:
 o=row['ordinal'];cid=row['candidate_id'];rec=copy.deepcopy(row['source_after']);rec['content']['role_evidence']=row['proof'];data={**S,'candidates':{**S['candidates'],cid:rec}};n.validate(rec,CAT,corpus=data)
 own=[b for b in S['slot_bindings'].values() if b['candidate_id']==cid];check(len(own)==1,'one actual ownbinding',o);check(own==[b for b in OR['slot_bindings'].values() if b['candidate_id']==cid],'all original bindings preserved',o)
 base=fixture(o);cores.append({'ordinal':o,'core':base});eprops={(f['target'],f['property']) for f in row['proof']['facts'] if f['mode']=='effect'}
 check(not any((f['axes'].get('owner'),f['axes'].get('property')) in eprops for f in base['semantic_assertions']),'desiredE not baseline',o)
 matrix=[]
 for label,view in [('full',data),('compact',{**data,'candidates':{**data['candidates'],cid:layout.guard_record(rec,data)}})]:
  for bid in [None,own[0]['id']]:
   core=fixture(o);entry=ent(view,rec,core,o,bid);ad=n.admission(entry,core,source_data=data);check(ad['allowed'] and not ad.get('search_only'),'positive native admission',o,label,bid,ad)
   check(len(ad['resolved_frozen_facts'])==COUNTS[o],'all exact scalarP',o,ad)
   vals=consumer(data,core,rec,o,entry);check(all(vals.values()),'positive all consumer roles',o,label,bid,vals)
   for role in row['proof']['roles']:
    q=n.qualification(CAT[role],view['candidates'][cid],source_data=data);check(q['status']=='eligible' and q['native_qualification']=='qualified','actual fullcompact qualification',o,label,role,q)
   dims,props,_=n.permission_scope(entry,core);check(n.property_scope_allowed(core,dims,props,record=entry),'positive effect permission',o,label,bid,dims,props)
   check(n.audit_final_scalar_preservation([entry],core) is None,'final preserved scalar audit',o,label,bid)
   # Every P, including sourceguard image relation, absent/wrong-value/wrong-owner/type.
   failures=[]
   for aid,*_ in REQ[o]:
    for kind in ['missing','wrong','other','type']:
     defect=kind+'_'+aid;badcore=fixture(o,defect=defect);bad=ent(view,rec,badcore,o,bid);receipt=n.admission(bad,badcore,source_data=data);check(not receipt['allowed'],'exact P or guard negative',o,label,bid,defect,receipt);check(not any(consumer(data,badcore,rec,o,bad).values()),'all roles reject whole-cue P negative',o,defect)
     failures.append({'defect':defect,'reason':receipt['reason']})
   for defect in (['missing_face_part','wrong_face_part','missing_eyes_part','wrong_eyes_part','literal_human_only','literal_animal_only'] if o==6801 else []):
    bc=fixture(o,defect=defect);be=ent(view,rec,bc,o,bid);receipt=n.admission(be,bc,source_data=data);check(not receipt['allowed'],'actual relation/group exact rejection',o,defect,receipt);check(not any(consumer(data,bc,rec,o,be).values()),'relation/group all consumer rejection',o,defect);failures.append({'defect':defect,'reason':receipt['reason']})
   no=ent(view,rec,core,o,bid,choose=False);check(not n.admission(no,core)['allowed'],'no arbitrary first owner',o);check(not any(consumer(data,core,rec,o,no).values()),'consumer missing selection rejects',o)
   nc=n.admission(no,core,allow_unselected=True);check(nc.get('search_only') is True,'unselected is search-only',o,nc)
   choices={**SELECTIONS[o],next(iter(SELECTIONS[o])):'other_A'};wrong=ent(view,rec,core,o,bid,choices);check(not n.admission(wrong,core)['allowed'],'wrong selected owner',o)
   st=selection(rec,core,o);st['core_sha256']='0'*64;stale=c.entry(view,cid,bid,realization_id='base',owner_selections=st);check(not n.admission(stale,core)['allowed'],'stale selection',o)
   # Full actual canonical E footprint includes target AND every receiver. Locks
   # here are independent negative caller anchors, never P rewrites or aliases.
   lockrows=[];mapped={**SELECTIONS[o],**({'image':'image_A'} if o==6807 else {})}
   for f in row['proof']['facts']:
    if f['mode']!='effect':continue
    for target in [f['target']]+f['receivers']:
     owner=mapped[target];prop=f['property'];dim=f['dimension']
     for name,lockdim,lockprop in [('exact',dim,prop),('ancestor',dim,prop.rsplit('.',1)[0]),('cross_dimension_same_property','appearance' if dim!='appearance' else 'composition',prop)]:
      lc=fixture(o,anchor=(lockdim,owner,lockprop));le=ent(view,rec,lc,o,bid);ld,lp,_=n.permission_scope(le,lc);check(not n.property_scope_allowed(lc,ld,lp,record=le),'target/Rx original property lock',o,label,bid,f['id'],target,name);check(not any(consumer(data,lc,rec,o,le).values()),'all-role actual property lock',o,f['id'],target,name);lockrows.append({'fact':f['id'],'position_owner':target,'actual_owner':owner,'property':lockprop,'dimension':lockdim,'case':name,'allowed':False})
    target=f['target'];owner=mapped[target];alias=owner+'_alias';lc=fixture(o,anchor=(f['dimension'],alias,f['property']),alias=(owner,alias));le=ent(view,rec,lc,o,bid);ld,lp,_=n.permission_scope(le,lc);check(not n.property_scope_allowed(lc,ld,lp,record=le),'alias lock',o,f['id']);check(not any(consumer(data,lc,rec,o,le).values()),'alias consumer lock',o)
    par=owner+'_container';lc=fixture(o,anchor=(f['dimension'],par,f['property']),parent=(owner,par));le=ent(view,rec,lc,o,bid);ld,lp,_=n.permission_scope(le,lc);check(not n.property_scope_allowed(lc,ld,lp,record=le),'parent owner scope lock',o,f['id'])
    lc=fixture(o,anchor=(f['dimension'],'other_A',f['property']),unknown=True);le=ent(view,rec,lc,o,bid);ld,lp,_=n.permission_scope(le,lc);check(not n.property_scope_allowed(lc,ld,lp,record=le),'unknown owner overlap lock',o,f['id'])
    lc=fixture(o,anchor=(f['dimension'],'other_A',f['property']));le=ent(view,rec,lc,o,bid);ld,lp,_=n.permission_scope(le,lc);check(n.property_scope_allowed(lc,ld,lp,record=le),'explicit disjoint property lock irrelevant',o,f['id']);check(all(consumer(data,lc,rec,o,le).values()),'disjoint control positive',o)
   for dim in dims:
    lc=fixture(o,whole=dim);le=ent(view,rec,lc,o,bid);check(not any(consumer(data,lc,rec,o,le).values()),'whole effect dimension lock all roles',o,dim)
   # Isolate source-common and actual ownbinding policy; neither replaces the other.
   policy=[]
   if o in {6807,6825,6867}:
    for cat in ['animal','environment','product']:
     vals=consumer(data,core,rec,o,entry,cat);check(not any(vals.values()),'original human restriction AND',o,cat,vals);policy.append({'subject_category':cat,'allowed':False})
   if o in {6825,6867}:
    for domain in ['product','jewelry','food','wildlife']:
     vals=consumer(data,core,rec,o,entry,'human',[domain]);check(not any(vals.values()),'exact old domain deny AND',o,domain,vals);policy.append({'domain':domain,'allowed':False})
   if o==6801:
    ac=fixture(o,animal=True);ae=ent(view,rec,ac,o,bid);check(n.admission(ae,ac)['allowed'],'explicit animal owner with exact group predicate',o);check(all(consumer(data,ac,rec,o,ae,'animal').values()),'animal category positive retains original OR',o)
    check(not any(consumer(data,core,rec,o,entry,'product').values()),'global product not biological application',o)
   matrix.append({'view':label,'binding_id':bid,'admission':ad,'permission_dimensions':dims,'permission_properties':props,'all_roles_consumer':vals if False else list(row['proof']['roles']),'P_guard_negatives':failures,'locks':lockrows,'policy_negatives':policy,'final_scalar_preservation':'pass_no_violation','positive_no_desired_E_frozen':True})
 # Tighten only isolated binding copy to ensure presentation constraints AND even
 # after role re-expression. This never edits actual original bindings.
 guarded=copy.deepcopy(data);guarded['slot_bindings'][own[0]['id']]['conditions']={**own[0]['conditions'],'subject_applicability':{**own[0]['conditions'].get('subject_applicability',{}),'deny_domains':['controlled_forbidden']}}
 cc=fixture(o);ee=ent(guarded,rec,cc,o,own[0]['id']);check(n.admission(ee,cc)['allowed'],'binding policy separate from factual prerequisite',o);check(not any(consumer(guarded,cc,rec,o,ee,domains=['controlled_forbidden']).values()),'tightened binding AND actual consumer',o)
 rejected=[]
 for defect in ['missing_App_unit','missing_KO_unit','canonical_E_as_P','canonical_property_rename','metadata_anchor','unsigned_value_change']+(['guard_support_without_direct_unit','missing_anatomy_role_guard_ref'] if o==6801 else [])+(['missing_samefact_view','facet_outside_canonical_quote'] if o in {6807,6867} else []):
  bad=copy.deepcopy(rec);p=bad['content']['role_evidence'];ef=next(f for f in p['facts'] if f['mode']=='effect')
  if defect=='missing_App_unit':p['source_units']=[u for u in p['source_units'] if u['pointer']!='/content/application_contract']
  elif defect=='missing_KO_unit':p['source_units']=[u for u in p['source_units'] if u['pointer']!='/content/ko']
  elif defect=='canonical_E_as_P':ef['mode']='prerequisite';ef.pop('operation');ef.pop('receivers')
  elif defect=='canonical_property_rename':ef['property']='prefix.workaround'
  elif defect=='metadata_anchor':ef.update(pointer='/content/aliases/0',quote=bad['content']['aliases'][0])
  elif defect=='unsigned_value_change':ef['value']['value']='unsigned_changed_value'
  elif defect=='guard_support_without_direct_unit':p['source_units'][1].pop('guard_refs')
  elif defect=='missing_anatomy_role_guard_ref':p['roles']['anatomical_connection']['guard_refs']=[]
  elif defect=='missing_samefact_view':p.pop('manual_role_views');next(v for v in p['roles'].values() if v.get('view_refs')).pop('view_refs')
  else:p['manual_role_views'][0]['normal_anchors'][0]['facet_quote']='not a canonical source substring'
  if defect!='unsigned_value_change':p['review']['native_review']['native_contract_sha256']=n.native_contract_sha256(p)
  try:n.validate(bad,CAT,corpus={**data,'candidates':{**data['candidates'],cid:bad}})
  except (ValueError,KeyError) as err:check(True,'invalid sourceproof rejection');rejected.append({'case':defect,'error':str(err)})
  else:raise AssertionError((o,defect,'invalid proof accepted'))
 results.append({'ordinal':o,'candidate_id':cid,'actual_ownbinding':own[0],'matrix':matrix,'stricter_binding_AND':True,'invalid_proofs_rejected':rejected})
modules={}
for name,m in sorted(sys.modules.items()):
 if (name.startswith('photo_') or name=='prompt_generator') and getattr(m,'__file__',None):
  pp=Path(m.__file__).resolve();check(pp.is_relative_to(G),'all actual frozen module paths',name,str(pp));modules[name]={'file':str(pp),'raw_sha256':raw(pp)}
check(not forbidden,'no provider/model import',forbidden)
def save(p,v):
 assert not p.exists(),str(p);p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n');print(p.name,raw(p),H(v));return {'file':str(p.relative_to(ROOT)),'file_sha256':raw(p),'sha256':H(v)}
coresref=save(W/'CONTROLLED-CORES-v1.json',{'schema':'photo-carrier4-independent-synthetic-core/v1','independent_manual_requirements':REQ,'source':'Synthetic independently authored caller requirements, not actual user evidence and no desired E value frozen.','cores':cores})
veref=save(W/'BATCH-VERIFICATION-v1.json',{k:v for k,v in V.items() if k!='records'})
save(W/'ACTUAL-CHECKS-v1.json',{'schema':'photo-carrier4-source28-actual-consumer-controls/v1','task_name':A['task_name'],'model':A['model'],'reasoning_effort':A['reasoning_effort'],'input_sha256':H(I),'source_sha256':H(S),'catalog_sha256':H(CAT),'batch_raw_sha256':raw(O/'BATCH.json'),'batch_sha256':H(B),'generation':str(G),'module_pins':modules,'actual_assertions':checks,'full_compact_with_without_original_binding_baselines':16,'per_role_qualification_baselines':32,'per_role_consumer_baselines':32,'results':results,'controlled_cores':coresref,'batch_verification':veref,'failure_history':[{'stage':'author-v1 after writing BATCH/NOTE','error':'Module inventory assertion failed: native_reviews/direct_review prepended working scripts and lazy contract imports were not all pinned. No root acceptance or operating writes.','resolution':'Preserve author-v1 and BATCH/NOTE; actual checker preloads frozen consumers and restores frozen precedence immediately after research verifier import. All actual production modules assert immutable generation path and actual SHA, and all source/full/compact/consumers execute freshly. No source/proof meaning changed.'}],'limits':'Actual exact source28 full/compact/role/view/guard/admission/oldbinding/P/receiver property+dimension controls executed on synthetic independent core requests only. Shape and exact consumer guards do not prove natural-language entailment, actual user requirements, generated pixels or root acceptance. No final composed prompt/delivery run; final scalar audit called on each full/compact selected single entry.','root_acceptance':0,'operating_qualification':0,'source_code_git_writes':0,'model_Gemini_network_calls':0,'forbidden_import_attempts':forbidden})
print('PASS actual checks',checks)
