"""Explicit actual carrier type obligations; still unsigned proposal, never inferred at runtime."""
import copy,datetime,hashlib,json
from pathlib import Path
O=Path(__file__).resolve().parent
def h(x):return hashlib.sha256(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
a=json.loads((O/'PROPOSAL-v2.json').read_text());b=copy.deepcopy(a)
T={9612:'garment',9614:'leggings',9628:'shirt',9647:'garment',9663:'jacket',9672:'fabric',9705:'skirt',9710:'jacket',9718:'panel',9725:'garment',9751:'cardigan',9800:'artifact',9831:'jewelry',9845:'fabric',9850:'artifact',9856:'fabric',9866:'object_frame',9882:'trousers',9888:'artifact'}
for r in b['records']:
 if r['ordinal']==9858:
  assert any(p['property']=='props.type' and p['value']['value']=='small_bag' for p in r['proposed_prerequisites']);r['exact_carrier_type_plan']='The existing props.type/v1 small_bag P already pins the explicitly existing small-bag carrier; global human does not substitute for it.';continue
 kind=T[r['ordinal']];anchor=r['proposed_prerequisites'][0];f={'id':'carrier_kind','realization_id':'base','pointer':anchor['pointer'],'quote':anchor['quote'],'dimension':'subject','target':anchor['target'],'property':'entity.type','mode':'prerequisite','value':{'type':'entity.type/v1','value':kind},'requires':[]};r['proposed_prerequisites'].append(f)
 for e in r['proposed_actual_E_facts']:e['requires'].append('carrier_kind')
 r['exact_carrier_type_plan']='Same actual '+kind+' carrier must be independently frozen at the original source target with exact subject/entity.type and entity.type/v1 '+kind+'. The quote names this actual carrier/its owned construction; no kind is inferred by the engine from a role, source property, binding label or global human/domain/primary tag. A different owner with that kind cannot lend it. This is a literal prerequisite of the specified carrier, not a new source choice, body or creation approval.'
b.update(schema='photo-worker-next20-source27-149-native-close-proposal/v3',prior_v2_sha256=h(a),stop=datetime.datetime.now(datetime.timezone.utc).isoformat(),exact_carrier_type_prerequisite_additions=19,actual_E_count=36,prerequisite_count=47,preservation_count=5,role_proposal_count=37)
p=O/'PROPOSAL-v3.json'
with p.open('x')as f:json.dump(b,f,ensure_ascii=False,sort_keys=True,indent=2);f.write('\n')
print(json.dumps({'canonical':h(b),'raw':hashlib.sha256(p.read_bytes()).hexdigest(),'records':len(b['records']),'P':sum(len(r['proposed_prerequisites'])for r in b['records'])}))
for r in b['records']:print(r['ordinal'],json.dumps({'type_P':next(f for f in r['proposed_prerequisites']if f['property']in ['entity.type','props.type']),'E_requires':{e['id']:e['requires']for e in r['proposed_actual_E_facts']}},ensure_ascii=False))
