"""Keep rendered structural guards within actual selected E, without manufacturing frozen-before state."""
import copy,datetime,hashlib,json
from pathlib import Path
O=Path(__file__).resolve().parent
def h(x):return hashlib.sha256(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
a=json.loads((O/'PROPOSAL-v3.json').read_text());b=copy.deepcopy(a)
CHANGES={
9663:{'edge':'same_jacket_lower_front_edges_curve_apart_below_fastening_point_with_opening_distinct_from_own_lapel_folds'},
9710:{'pleat':'same_jacket_opened_back_pleat_reveals_extra_fabric_beside_shoulder_blade_while_both_sides_stay_joined_to_own_back_panel'},
9800:{'pattern':'shallow_patterned_recess_field_on_same_metal_surface_bounded_by_own_unrecessed_metal','relief':'physical_shallow_recesses_in_same_metal_with_recess_field_bounded_by_own_unrecessed_metal'},
9831:{'pattern':'dark_narrow_filled_groove_pattern_on_same_bright_metal_with_adjacent_metal_fields_distinct','inlay':'physical_dark_filled_grooves_in_same_bright_metal_with_adjacent_metal_fields_distinct'},
9856:{'relief_a':'small_physical_pile_loops_project_from_same_fabric_face_with_repeated_loop_texture_visible_in_light','topology_a':'same_fabric_repeated_projecting_pile_loop_topology_visible_in_light','relief_m':'same_fabric_physical_projecting_pile_loop_relief_with_repeated_loop_texture_visible_in_light','topology_m':'same_fabric_physical_repeated_pile_loop_organization_visible_in_light'}}
for r in b['records']:
 if r['ordinal'] in [9800,9850,9888]:
  f=next(f for f in r['proposed_prerequisites']if f['id']=='carrier_kind');f['pointer']='/content/relations/0/subject';f['quote']='artifact'
 if r['ordinal'] in CHANGES:
  prior=copy.deepcopy(r['proposed_preservation_facts']);ids={x['id']for x in prior}
  for e in r['proposed_actual_E_facts']:
   e['requires']=[i for i in e['requires']if i not in ids];e['value']['value']=CHANGES[r['ordinal']][e['id']]
  for role in r['role_plan'].values():
   role['fact_refs']=[i for i in role['fact_refs']if i not in ids];role['support_modes']=['effect'] if role['fact_refs'] and all(i in {e['id']for e in r['proposed_actual_E_facts']}for i in role['fact_refs'])else role['support_modes']
  r['proposed_preservation_facts']=[]
  r['source_guard_mode_reassessment']={'prior_unsigned_PR_sketches':prior,'final_mode':'selected_E_output_constraint_same_original_footprint','reason':'The actual whole source states the selected opening/panel/recess/field/loop configuration and its simultaneous coherence or visibility. It does not expressly require a separately frozen prior input configuration. Remains/stays does not by itself license a new independent before-state restriction. Keep every literal connection/boundary/distinction/legibility as a conjunct of the complete actual E result on the same owner, with no new E or permission and no source deletion. If a future real input independently locks any of these properties, that original lock still constrains adoption; this plan cannot waive it.'}
 r['no_extra_state_restriction']='All positive output coherence guards remain literal constraints of the actual selected E. No independent PR is imposed merely from remains/stays, source-scope wording or a noun; no actual pre-existing request-state claim is made.'
b.update(schema='photo-worker-next20-source27-149-native-close-proposal/v4',prior_v3_sha256=h(a),stop=datetime.datetime.now(datetime.timezone.utc).isoformat(),preservation_count=0,output_coherence_guard_constraints_retained_in_original_E_count=5)
p=O/'PROPOSAL-v4.json'
with p.open('x')as f:json.dump(b,f,ensure_ascii=False,sort_keys=True,indent=2);f.write('\n')
print(json.dumps({'canonical':h(b),'raw':hashlib.sha256(p.read_bytes()).hexdigest(),'E':sum(len(r['proposed_actual_E_facts'])for r in b['records']),'P':sum(len(r['proposed_prerequisites'])for r in b['records']),'PR':sum(len(r['proposed_preservation_facts'])for r in b['records']),'source_edits':0,'proof_signatures':0}))
for r in b['records']:
 print(r['ordinal'],json.dumps({'E':[{k:e[k]for k in ['id','pointer','quote','dimension','target','property','mode','operation','receivers','value','requires']}for e in r['proposed_actual_E_facts']],'roles':r['role_plan'],'PR':r['proposed_preservation_facts']},ensure_ascii=False))
