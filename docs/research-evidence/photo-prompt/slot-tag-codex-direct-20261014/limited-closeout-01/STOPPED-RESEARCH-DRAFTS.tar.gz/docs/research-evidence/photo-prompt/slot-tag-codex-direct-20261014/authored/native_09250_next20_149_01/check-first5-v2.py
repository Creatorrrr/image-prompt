"""Actual controls on fixed envelope-aware generation, manually authored independent fixture facts."""
import copy,json,gzip,sys,hashlib,importlib.abc
from pathlib import Path
ROOT=Path.cwd();R=ROOT/'docs/research-evidence/photo-prompt/slot-tag-codex-direct-20261014';D=R/'native-inputs/prepared/review09250-next20-149-01';O=R/'authored/native_09250_next20_149_01';G=Path('/Users/chasoik/.cache/image-prompt/photo-shared-runtime/generations/fe5b593c819806a31803e40c620e6f2b28c3b54103f451dd6f38920f2d537258');sys.dont_write_bytecode=True
forbidden=[]
class Deny(importlib.abc.MetaPathFinder):
 def find_spec(self,fullname,path=None,target=None):
  if fullname.split('.')[0] in {'torch','transformers','sentence_transformers','tensorflow','jax','mlx','google','openai','anthropic','requests','httpx'}:forbidden.append(fullname);raise AssertionError(fullname)
sys.meta_path.insert(0,Deny());sys.path[:0]=[str(G/'scripts'),str(G/'precore')]
import photo_semantic_evidence as n
import photo_candidate_corpus as c
import photo_search_layout as layout
import prompt_generator as g
H=c.digest
read=lambda p:json.loads(Path(p).read_text())
I=read(D/'INPUT.json');S=json.loads(gzip.decompress(Path(ROOT/I['current_snapshot']['file']).read_bytes()));B=read(O/'FIRST5-PROOFS-v1.json');assert H(S)==B['source_sha256']
# Independent controlled caller declarations, never desired style/openness/contrast prerequisites.
PRESENT=('owner_present','subject','entity.presence','entity.presence/v1','present')
FACE=('face_present','subject','anatomy.face.presence','anatomy.face.presence/v1','present')
HAIR=('hair_present','subject','anatomy.hair.presence','anatomy.hair.presence/v1','present')
SCALP=('scalp_present','subject','anatomy.scalp.presence','anatomy.scalp.presence/v1','present')
BASELINES={
11251:[PRESENT,FACE,('lips_present','subject','anatomy.lips.presence','anatomy.lips.presence/v1','present'),('skin_present','subject','anatomy.facial_skin.presence','anatomy.facial_skin.presence/v1','present')],
11308:[PRESENT,FACE,('eyes_present','subject','anatomy.eyes.presence','anatomy.eyes.presence/v1','present'),('irises_present','subject','anatomy.irises.presence','anatomy.irises.presence/v1','present'),('lids_present','subject','anatomy.upper_eyelids.presence','anatomy.upper_eyelids.presence/v1','present'),('lid_continuity','body_geometry','anatomy.connection.upper_lids_eye_apertures','anatomy.connection.upper_lids_eye_apertures/v1','upper eyelids remain attached to their same owned eye apertures')],
11321:[PRESENT,HAIR,SCALP,('root_ownership','body_geometry','anatomy.connection.hair_scalp','anatomy.connection.hair_scalp/v1','the declared short locks originate in the same owned scalp hair region')],
11373:[PRESENT,HAIR,SCALP,('root_ownership','body_geometry','anatomy.connection.front_locks_hairline','anatomy.connection.front_locks_hairline/v1','the same front locks originate at the owned forehead hairline and remain on that same scalp')],
11386:[PRESENT,HAIR,('section_continuity','appearance','hair.topology.section_continuity','hair.topology.section_continuity/v1','successive bends belong to the same continuous owned hair sections')]
}
def fixture(o,*,defect=None,anchor=None,whole=False,alias=False,parent=False,disjoint=True,second=False):
 declared=[]
 for fid,dim,prop,vt,val in BASELINES[o]:
  if defect==('missing',fid):continue
  who='other_A' if defect==('other_owner',fid) else 'actor_A';actual='independently_different_value' if defect==('wrong',fid) else val
  declared.append((fid,who,dim,prop,vt,actual))
 if second:declared += [('second_'+fid,'actor_B',dim,prop,vt,val) for fid,dim,prop,vt,val in BASELINES[o]]
 text='Independent synthetic controlled caller request; not a real user. actor_A is an independently existing declared human carrier. It is explicitly identified before discovery, without any neutral main/foreground role. Each named local region/connection below is independently declared as actual input truth with exact stated scope and correspondence; merely repeating a label or passing a hash is insufficient in real use. No desired lip contrast, eyelid lowering, short-tip direction, rearward arrangement or broad S wave is frozen here. Caller declares: '+ ' ; '.join(who+' '+dim+'/'+prop+' '+vt+' = '+str(val) for fid,who,dim,prop,vt,val in declared)+'.'
 if disjoint:text+=' actor_A and other_A are explicitly disjoint actual owners.'
 if alias:text+=' alias_A is exactly the same actual human owner as actor_A.'
 if parent:text+=' actor_A is explicitly a part of parent_A in this synthetic owner graph.'
 if second:text+=' actor_B is a second independently existing qualified human carrier, explicitly disjoint from actor_A and other_A.'
 rows=[]
 def stmt(aid,kind,dim='subject',**axes):rows.append({'assertion_id':aid,'dimension':dim,'polarity':'required','source_span_ids':['controlled_input'],'axes':{'native_schema':n.witnesses.SCHEMA,'kind':kind,**axes},'evidence':{'controlled_input':text},'affected_dimensions':[dim]})
 stmt('actor_owner','owner',owner='actor_A',owner_kind='human');stmt('other_owner','owner',owner='other_A',owner_kind='human')
 if disjoint:stmt('separate','disjoint',left='actor_A',right='other_A')
 if alias:stmt('alias_owner','owner',owner='alias_A',owner_kind='human');stmt('alias_same','equivalent',left='alias_A',right='actor_A')
 if parent:stmt('parent_owner','owner',owner='parent_A',owner_kind='controlled_whole');stmt('actual_part','part_of',left='actor_A',right='parent_A')
 if second:
  stmt('second_owner','owner',owner='actor_B',owner_kind='human');stmt('second_disjoint','disjoint',left='actor_B',right='actor_A');stmt('second_other_disjoint','disjoint',left='actor_B',right='other_A')
 anchors=[]
 for fid,who,dim,prop,vt,val in declared:
  stmt('fact_'+fid,'fact',dim,owner=who,property=prop,value_type=vt,value=val)
  if dim!='subject':anchors.append({'dimension':dim,'target':who,'property':prop})
 if anchor:anchors.append({'dimension':anchor[0],'target':anchor[1],'property':anchor[2]})
 core={'contract_version':'photo-authorial-core/v3','subject':text,'baseline_prompt_en':text,'request_binding':{'active_spans':[{'source_span_id':'controlled_input','text':text}]},'semantic_assertions':rows,'user_exclusions':[],'intent_lock':{'contract_version':'photo-intent-lock/v2','locked_dimensions':['subject','body_geometry']+(['appearance','expression'] if whole else []),'open_dimensions':[] if whole else ['appearance','expression'],'semantic_anchors':anchors}}
 core['canonical_sha256']=H(core);core['core_id']=core['canonical_sha256'][:16];return core

def selection(rec,core,owner='actor_A'):
 p=rec['content']['role_evidence'];return {'schema':n.OWNER_SELECTION_SCHEMA,'core_sha256':core['canonical_sha256'],'owner_graph_sha256':H(n.frozen_witnesses(core)['graph']),'entries':[{'candidate_id':rec['id'],'realization_id':'base','meaning_sha256':p['meaning_sha256'],'qualification_sha256':H(p),'bindings':[{'target':'main_subject','owner_id':owner}]}]}
def entry(view,rec,core,bid=None,owner='actor_A',choose=True):return c.entry(view,rec['id'],bid,realization_id='base',**({'owner_selections':selection(rec,core,owner)} if choose else {}))
def contract(category='human',domains=None):return {'subject_category':category,'adult_allowed':False,'domains':domains or [],'intent_constraints':{'subject_categories':[category],'domains':domains or []}}
def picked(category='human'):return {'subject':{'en':'Independently declared existing '+category+' carrier','tags':[category]},'action':{},'location':{}}
count=0;results=[];cores=[]
def check(v,label,*more):
 global count
 count+=1
 if not v:raise AssertionError((label,*more))
for row in B['records']:
 o=row['ordinal'];cid=row['candidate_id'];rec=copy.deepcopy(row['source_after']);rec['content']['role_evidence']=copy.deepcopy(row['proof']);data={**S,'candidates':{cid:rec},'slot_bindings':{k:v for k,v in S['slot_bindings'].items() if v['candidate_id']==cid}};n.validate(rec,S['slot_catalog'],corpus=data);assert H(row['source_after'])==H(S['candidates'][cid]);assert hashlib.sha256((O/'FIRST5-PROOFS-v1.json').read_bytes()).hexdigest()=='0282d63c8ce04480ab77d1498968bd99f8db9b142507f8ef24719b34775b5495';controlled_transport=n.permission_envelope.freeze_source_authority(data,expected_snapshot_sha256=H(data),reviewer='Direct worker source27 exact selected CID plus freshly authored proof; controlled sparse-view transport only, not root acceptance or whole18250 authority');roles=list(row['proof']['roles']);own=[v for v in S['slot_bindings'].values() if v['candidate_id']==cid];check(len(own)==1,'exact own binding count',o)
 effectfacts=[f for f in row['proof']['facts'] if f['mode']=='effect'];originaleffects=row['source_after']['effects']['properties'];check([{k:f[k] for k in ['dimension','target','property']} for f in effectfacts]==originaleffects,'all original E addresses retained',o)
 core=fixture(o);cores.append({'ordinal':o,'core':core});matrix=[]
 for label,view in [('full',data),('compact',{**data,'candidates':{**data['candidates'],cid:layout.guard_record(rec,data)}})]:
  for bid in [None,own[0]['id']]:
   core=fixture(o);e=entry(view,rec,core,bid);ad=n.admission(e,core);check(ad['allowed'] and not ad.get('search_only'),'baseline actual admission',o,label,bid,ad)
   check(len(ad['resolved_frozen_facts'])==len(BASELINES[o]),'complete PPR count',o,label,bid,ad);check({x['owner'] for x in ad['resolved_frozen_facts']}=={'actor_A'},'same actual owner PPR',o)
   dims,props,_=n.permission_scope(e,core);expected=[{**p,'target':'actor_A'} for p in originaleffects];check(props==expected,'exact original canonical scope',o,props,expected)
   for role in roles:
    q=n.qualification(S['slot_catalog'][role],view['candidates'][cid],source_data=data);check(q['status']=='eligible' and q['native_qualification']=='qualified','actual role fullcompact',o,role,q)
    check(g.core_entry_eligible(view,core,contract(),picked(),role,e),'actual consumer baseline',o,label,bid,role)
   nc=entry(view,rec,core,bid,choose=False);check(not n.admission(nc,core)['allowed'],'no implicit owner',o);check(n.admission(nc,core,allow_unselected=True).get('search_only') is True,'only search before explicit owner choice',o)
   for role in roles:check(not g.core_entry_eligible(view,core,contract(),picked(),role,nc),'consumer no implicit owner',o,role)
   defects=[]
   for fid,*_ in BASELINES[o]:
    for k in ['missing','wrong','other_owner']:
     badcore=fixture(o,defect=(k,fid));be=entry(view,rec,badcore,bid);bad=n.admission(be,badcore);check(not bad['allowed'],'actual PPR defect denied',o,k,fid,bad)
     for role in roles:check(not g.core_entry_eligible(view,badcore,contract(),picked(),role,be),'consumer PPR denied',o,k,fid,role)
     defects.append({'kind':k,'fact':fid,'reason':bad['reason']})
   locks=[]
   for prop in originaleffects:
    root=prop['property'];ancestor=root.rsplit('.',1)[0] if '.' in root else '*'
    tests=[('same_property','actor_A',root,False,False,True,prop['dimension']),('same_property_other_dimension','actor_A',root,False,False,True,'material'),('property_ancestor','actor_A',ancestor,False,False,True,prop['dimension']),('explicit_alias','alias_A',root,True,False,True,prop['dimension']),('actual_owner_parent','parent_A',root,False,True,True,prop['dimension']),('unknown_other_owner_overlap','other_A',root,False,False,False,prop['dimension'])]
    for name,who,property_,alias,parent,disjoint,dim in tests:
     lc=fixture(o,anchor=(dim,who,property_),alias=alias,parent=parent,disjoint=disjoint);le=entry(view,rec,lc,bid);ld,lp,_=n.permission_scope(le,lc);check(not n.property_scope_allowed(lc,ld,lp,record=le),'source E original/ancestor/alias/owner lock',o,name,root)
     for role in roles:check(not g.core_entry_eligible(view,lc,contract(),picked(),role,le),'consumer property lock',o,name,role)
     locks.append({'case':name,'property':property_,'target':who,'denied':True})
    dc=fixture(o,anchor=(prop['dimension'],'other_A',root));de=entry(view,rec,dc,bid)
    for role in roles:check(g.core_entry_eligible(view,dc,contract(),picked(),role,de),'explicit disjoint same property positive',o,role)
   wc=fixture(o,whole=True);we=entry(view,rec,wc,bid)
   for role in roles:check(not g.core_entry_eligible(view,wc,contract(),picked(),role,we),'whole dimension lock',o,role)
   for name,pc,owner in [('alias_selection',fixture(o,alias=True),'alias_A'),('second_qualified_selection',fixture(o,second=True),'actor_B'),('unrelated_property',fixture(o,anchor=('appearance','actor_A','unrelated.sibling')),'actor_A')]:
    pe=entry(view,rec,pc,bid,owner)
    for role in roles:check(g.core_entry_eligible(view,pc,contract(),picked(),role,pe),'positive explicit owner/property control',o,name,role)
   # All these sources have intrinsic human restriction; catalog149 broadening cannot waive it.
   for role in roles:check(not g.core_entry_eligible(view,core,contract('object'),picked('object'),role,e),'original source human condition AND',o,role)
   matrix.append({'view':label,'binding_id':bid,'baseline_admission':ad,'roles':roles,'resolved_effects':props,'PPR_defects':defects,'locks':locks,'whole_dimension_denied':True,'disjoint_alias_secondowner_unrelated_controls_allowed':True,'source_human_condition_retained':True})
 # Original own binding remains unchanged and can independently deny a catalog-broadened native role.
 if o in [11251,11321,11373,11386]:
  bc=fixture(o);be=entry(data,rec,bc,own[0]['id'])
  for role in roles:check(not g.core_entry_eligible(data,bc,contract(domains=['product']),picked(),role,be),'existing deny-domain binding remains AND',o,role)
 negative=[]
 for defect in ['missing_KO_unit','missing_relation_endpoint','canonical_property_rename','E_to_P','unsigned_value']:
  bad=copy.deepcopy(rec);proof=bad['content']['role_evidence'];f=next(f for f in proof['facts'] if f['mode']=='effect')
  if defect=='missing_KO_unit':proof['source_units']=[u for u in proof['source_units'] if u['pointer']!='/content/ko']
  elif defect=='missing_relation_endpoint':proof['source_units']=[u for u in proof['source_units'] if u['pointer']!='/content/relations/0/object']
  elif defect=='canonical_property_rename':f['property']='new_role_prefix'
  elif defect=='E_to_P':f['mode']='prerequisite';f.pop('operation');f.pop('receivers')
  else:f['value']['value']='unsigned_wrong_value'
  if defect!='unsigned_value':proof['review']['native_review']['native_contract_sha256']=n.native_contract_sha256(proof)
  try:n.validate(bad,S['slot_catalog'],corpus={**data,'candidates':{**data['candidates'],cid:bad}})
  except ValueError as err:count+=1;negative.append({'case':defect,'reason':str(err)})
  else:raise AssertionError((o,defect,'tamper accepted'))
 results.append({'ordinal':o,'candidate_id':cid,'full_compact_binding_matrix':matrix,'original_binding':own[0],'tampered_proofs_denied':negative,'worker_controls_pass':True})
modules={}
for name,m in sorted(sys.modules.items()):
 if (name.startswith('photo_') or name=='prompt_generator') and getattr(m,'__file__',None):
  p=Path(m.__file__).resolve();check(p.is_relative_to(G),'fixed module path',name,str(p));modules[name]={'file':str(p),'file_sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
check(not forbidden,'provider/localmodel import guard',forbidden)
for name,value in [('FIRST5-CONTROLLED-CORES-v2.json',{'schema':'photo-native-next20-first5-independent-controlled-input/v1','cores':cores,'boundary':'Independent synthetic caller truth only, no real request/source authority inferred from this fixture.'}),('FIRST5-ACTUAL-CHECKS-v2.json',{'schema':'photo-native-next20-first5-fixed-actual-controls/v1','task_name':'/root/review_09250_10500','source_sha256':H(S),'input_sha256':H(I),'proof_file_sha256':hashlib.sha256((O/'FIRST5-PROOFS-v1.json').read_bytes()).hexdigest(),'actual_assertions':count,'results':results,'actual_modules':modules,'root_acceptance':0,'operating_qualified':0,'provider_localmodel_network_calls':0,'forbidden_import_attempts':forbidden,'boundary':'Actual source qualification, full/compact explicit-owner admission and per-role consumers on independently authored synthetic frozen input fixtures only. No final multi-candidate union, real-request authority, provider/pixel/runtime activation or root acceptance.'})]:
 p=O/name
 with p.open('x') as f:f.write(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
 print(name,hashlib.sha256(p.read_bytes()).hexdigest())
print('PASS',count)
