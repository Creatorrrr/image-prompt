"""Actual source1299 B1 union plus independently declared exact owner alias."""
from common_v1 import *
from photo_contracts import property_effects_allowed
core,inv,cap,authority=frozen_inputs();z=copy.deepcopy(core)
suffix=' H1_alias is another exact input name for H1, the same existing hand and not a second entity.'
text=fi.TEXT+suffix;rb=z['request_binding'];h=hashlib.sha256(text.encode()).hexdigest()
z['source_request']=text;z['baseline_prompt_en']=text;rb['request_sha256']=h;rb['request_envelope_sha256']=c.digest({'request_text':text})
rb['input_inventory']['items'][0]['sha256']=h;rb['active_spans'][0]['text']=text
for row in z['semantic_assertions']:
 if row['axes']['kind']=='existing_member_scope':
  scope=json.loads(row['axes']['inventory']);scope['input_binding']=n.witnesses.input_binding(rb);row['axes']['inventory']=n.witnesses.canonical(scope)
z['semantic_assertions'] +=[fi.a('owner_H1_alias','owner',owner='H1_alias',owner_kind='entity'),fi.a('equivalent_H1_alias','equivalent',left='H1_alias',right='H1')]
fi.reseal(z);e=entries(z)[0];context=n._resolve_selected_native_contracts([e],z);scope=context['view']['permission_scope'];graph=scope['owner_graph']
assert property_effects_allowed(z['intent_lock'],scope['dimensions'],scope['literal_properties'],owner_graph=graph)
checks=[]
for prop,dimension in [('shot.scale','framing'),('framing.coverage','framing'),('action.interaction.exchange','action')]:
 lock=copy.deepcopy(z['intent_lock']);lock['semantic_anchors'].append({'dimension':dimension,'target':'H1_alias','property':prop})
 allowed=property_effects_allowed(lock,scope['dimensions'],scope['literal_properties'],owner_graph=graph);assert not allowed
 checks.append({'alias_anchor':{'dimension':dimension,'target':'H1_alias','property':prop},'allowed':allowed,'rejected':not allowed})
print(json.dumps(save('ALIAS-LOCK-CHECKS-v1.json',{'schema':'photo-actual1299-declared-alias-lock-checks/v1','core':z,'actual_B1_view':context['view'],'checks':checks,
 'module_paths_sha256':modules(),'root_acceptance':0,'operating':0,'boundary':'Grounded owner equivalence declaration in an explicitly extended independent typed fixture. Same actual source proof and actual B1 full receiver union. Tests the original pinned property primitive on all three E properties through the alternate hand name; no substring alias, new source E, production source or trust waiver.'})))
