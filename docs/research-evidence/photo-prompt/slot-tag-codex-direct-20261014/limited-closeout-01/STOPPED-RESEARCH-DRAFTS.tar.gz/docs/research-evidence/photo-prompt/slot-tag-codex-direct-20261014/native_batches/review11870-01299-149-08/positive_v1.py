"""Actual full/compact source-selected permission and final-PR consumers."""
from common_v1 import *
from after_state_v1 import after_core,evidence
from unittest import mock
core,inv,cap,authority=frozen_inputs();es=entries(core);assessment=load('MANUAL-IMPACT-ASSESSMENT-v1.json')
plan=pe.freeze_permission_plan(authority,core,[es[0]],inventory=cap,assessment=assessment,contracts=contracts(),reviewer='/root/review_11870_12250 direct selected finite-request plan')
result=after_core(core);typed=pe.freeze_after_state(plan,result,expected_after_sha256=c.digest(result),evidence=evidence(plan),reviewer='/root/review_11870_12250 typed result input reviewer')
rows=[]
with pe.trusted_permission_session(authority,plan,after_state=typed):
 for kind,binding in [('full',False),('compact',False),('full-ownbinding',True),('compact-ownbinding',True)]:
  e=entries(core,binding=binding)[1 if kind.startswith('compact')else 0]
  receipt=n.admission(e,core);dims,props,graph=n.permission_scope(e,core)
  value={'case':kind,'admission':receipt,'consumer':eligible(e,core),'scope':{'dimensions':dims,'properties':props,'graph':graph},
   'property_scope_allowed':n.property_scope_allowed(core,dims,props,record=e),'final_receipt':n.audit_final_scalar_preservation([e],core)}
  rows.append(value)
 for tag in ['shot_scale','subject_framing','action','relational_action']:
  q=n.qualification(CAT[tag],record,source_data=S)
  rows.append({'case':'actual-role-'+tag,'qualification':q,'consumer':g.core_entry_eligible(S,core,
   {'subject_category':'object','domains':[],'intent_constraints':{'subject_categories':['object'],'domains':[]}},{'subject':{'kind':['object'],'tags':['object']}},tag,es[0])})
 pack={'authorial_core':core,'creative_controls':{}}
 prompt='Macro framing in image I of existing hands H1,H2,H3 physically handing off the same existing item X. Only these hands are visible as participant anatomy; nonhand panels R1/R2 are outside the participant crop. X remains literally visible in the same I; rigs U/V and all original entities and part relationships remain.'
 composed={'chosen_candidate_ids':[CID],'candidate_interpretations':[{'candidate_id':CID,'realization_id':'base'}],
  'owner_selections':es[0]['_native_owner_selections'],'prompt_en':prompt}
 # The controlled input is not an actual frozen production pack. Isolate only
 # its unrelated categorical pre-core setup; all selected-source reconstruction,
 # own B1, actual admission/consumer/property/joint/final PR code is real.
 controls=({'subject_category':'object','domains':[],'intent_constraints':{'subject_categories':['object'],'domains':[]}},{'subject':{'kind':['object'],'tags':['object']}})
 with mock.patch.object(g,'frozen_core_context',return_value=controls):
  output={};failures=audit.audit_native_adoptions(pack,composed,S,resolution_out=output)
 rows.append({'case':'actual-selected-native-final-audit','failures':failures,'resolution':output,
  'categorical_precore_setup_only_isolated':True,'native_internal_checks_mocked':False})
out={'schema':'photo-actual-source1299-controlled-positive-checks/v1','task_name':A['task_name'],'assignment_sha256':c.digest(A),'input_sha256':c.digest(I),
 'source_record_sha256':c.digest(after),'proof_sha256':c.digest(proof),'prepared_root_snapshot':I['current_snapshot'],
 'actual_qualified_source_sha256':c.digest(S),'actual_same_B1_sha256':load('SELECTED-B1-REVIEW-PACKET-v1.json')['resolved_view']['canonical_sha256'],
 'checks':rows,'module_paths_sha256':modules(),'root_acceptance':0,'operating':0,'real_user_or_pixel':False,
 'boundary':'Fresh actual source1299 native contract + independently authored finite typed request/result only. No production fullpack/freezeworkflow or pixels; native final auditor categorical setup alone isolated, native selected source/P/guard/3E/Rx/permission/finalPR real.'}
print(json.dumps(save('POSITIVE-CHECKS-v1.json',out)))
print(json.dumps([{'case':x['case'],'admission':x.get('admission',{}).get('allowed'),'consumer':x.get('consumer'),'qualification':x.get('qualification',{}).get('status'),'failures':x.get('failures')}for x in rows]))
assert all(x.get('consumer',True) and x.get('admission',{}).get('allowed',True) and x.get('qualification',{}).get('status','eligible')=='eligible' and not x.get('failures',[])for x in rows)
