"""Fresh permission/core plans cannot waive actual scoped type/disjointness guards."""
from common_v1 import *
core,inv,cap,authority=frozen_inputs();base=load('MANUAL-IMPACT-ASSESSMENT-v1.json');checks=[]
for defect in ['wrong-last-hand-kind','missing-last-hand-disjoint']:
 k=copy.deepcopy(core)
 if defect=='wrong-last-hand-kind':next(x for x in k['semantic_assertions']if x['assertion_id']=='type_H3')['axes']['value']='fin'
 else:k['semantic_assertions']=[x for x in k['semantic_assertions']if x['assertion_id']!='separate_H1_H3']
 fi.reseal(k);inventory=fi.inventory(k)
 capability=pe.freeze_permission_inventory(k,inventory,expected_inventory_sha256=c.digest(inventory),reviewer='explicit negative typed input authority')
 es=entries(k);packet=pe.prepare_permission_review(authority,capability,k,[es[0]],contracts=contracts())
 review=copy.deepcopy(base);review['inventory_sha256']=c.digest(inventory);review['resolved_view_sha256']=c.digest(packet['resolved_view']);review['source_bindings_sha256']=c.digest(packet['source_bindings'])
 plan=pe.freeze_permission_plan(authority,k,[es[0]],inventory=capability,assessment=review,contracts=contracts(),reviewer='permission-only plan for original source footprint; not a P/guard waiver')
 with pe.trusted_permission_session(authority,plan):
  for transport,entry in zip(['full','compact'],es):
   guard=n.evaluate_native_guards(entry,k);admission=n.admission(entry,k,source_data=S);consumer=eligible(entry,k)
   checks.append({'case':defect+'/'+transport,'fresh_inventory_sha256':c.digest(inventory),'fresh_plan_sha256':pe._payload(plan,'permission plan')['plan_sha256'],
     'native_guard_result':guard,'native_admission':admission,'consumer':consumer,'rejected':not guard['allowed'] and not admission['allowed'] and not consumer,'stale_plan_used':False})
print(json.dumps(save('FRESH-GUARD-CHECKS-v2.json',{'schema':'photo-actual1299-fresh-plan-guard-negative/v1','checks':checks,'count':len(checks),
 'module_paths_sha256':modules(),'root_acceptance':0,'operating':0,
 'boundary':'Fresh independently typed negative cores and current source-specific permission plans. Additional permission is not prerequisite/guard qualification. These failures are actual type/distinctness checks, not stale positive-plan rejection. Actual source and all3E/Rx unchanged.'})))

print(json.dumps(checks,ensure_ascii=False))
