"""Same-model focused research peer. No writer import, source mutation or authority from shape."""
from pathlib import Path
import sys,json,gzip,hashlib,copy,importlib.abc
class DenyModels(importlib.abc.MetaPathFinder):
 def find_spec(self,fullname,path=None,target=None):
  if fullname.split('.')[0] in {'google','google_genai','openai','anthropic','torch','transformers','sentence_transformers','ollama','mlx','httpx','requests'}:raise ImportError('offline peer prohibits model/network '+fullname)
sys.meta_path.insert(0,DenyModels())
G=Path('/Users/chasoik/.cache/image-prompt/photo-shared-runtime/generations/fe5b593c819806a31803e40c620e6f2b28c3b54103f451dd6f38920f2d537258');sys.path[:0]=[str(G/'scripts'),str(G/'precore')]
import photo_candidate_corpus as c,photo_semantic_evidence as n,photo_native_permission as pe,photo_permission_comparison as pc,photo_search_layout as layout,prompt_generator as g,audit_composed_prompt as audit
from photo_contracts import property_effects_allowed
from unittest import mock
R=Path('docs/research-evidence/photo-prompt/slot-tag-codex-direct-20261014');O=Path(__file__).parent;W=R/'native_batches/review11870-01299-149-08';D=R/'native-inputs/prepared/review11870-01299-149-08';CID='cand_2e72784a26885ceaa1d645d25bd9a468';REVIEWER='/root/review_06250_07250 same-model controlled-fixture peer'
def read(p):return json.loads(p.read_text())
def raw(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(name,x):
 p=O/name
 if p.exists():assert json.loads(p.read_text())==x;return
 p.write_text(json.dumps(x,ensure_ascii=False,sort_keys=True,indent=2)+'\n')
checks=[]
def yes(name,ok,detail=None):
 checks.append({'case':name,'pass':bool(ok),'detail':detail});assert ok,name

def denied(name,fn):
 try:
  r=fn();reject=r is False or isinstance(r,dict) and r.get('allowed') is False
  detail={'return':r}
 except ValueError as e:reject=True;detail={'error':str(e)}
 yes(name,reject,detail)
B=read(W/'BATCH.json');I=read(D/'INPUT.json');A=read(D/'ASSIGNMENT.json');P=read(D/'PREPARED-PACKET.json');row=B['records'][0];proof=row['proof']
yes('final-writer-BATCH-raw',raw(W/'BATCH.json')=='2817908552338cc301847ab5f0322661250c6fe133f58365481f73b9772c727b')
yes('final-writer-NOTE-raw',raw(W/'NOTE.json')=='367e3a962fff48f76c909b63545aa5d0d9026f34f9280bdde9489c1384af8ed8')
yes('final-exact-manually-read-literal-draft',B==read(W/'LITERAL-DRAFT-v1.json')['batch'])
yes('input-assignment-bindings',c.digest(I)==B['input_sha256'] and c.digest(A)==B['assignment_sha256'] and A['ids']==[CID])
p=Path(I['current_snapshot']['file']);S=json.loads(gzip.decompress(p.read_bytes()))
yes('root-full-source27-pin',raw(p)==I['current_snapshot']['file_sha256'] and c.digest(S)=='d1039bd6a55f6c767a0049704457ed48aa109c273f557d7e407673455bb72ba3')
yes('source-after-exact-root-packet',row['source_after']==P['current_records'][CID]==S['candidates'][CID])
yes('source-before-exact-original-packet',row['source_before']==P['original_records'][CID])
cat=read(R/'CATALOG-FINAL-149-V6.json');yes('exact149-catalog',c.digest(cat)=='d9f4db418e1b63cd100b4c7a9fbff4c8401e00dffeffd22e299a0b5087a82b15' and cat==S['slot_catalog'])
loc=I['original_decisions'][CID];oldfile=Path(loc['file']);old=read(oldfile)['decisions'][loc['item']-1]
yes('actual-compiled-file-row',raw(oldfile)==loc['file_sha256'] and c.digest(old)==loc['row_sha256'] and old==P['historical_compiled_rows'][CID])
yes('compiled-locator-preserved',proof['review']['original_review']['artifact']==loc['file']+'#item=50')
yes('empty-required-closure',row['dependency_records']==row['reference_bindings']==P['references'][CID]==P['reference_bindings'][CID]=={})
yes('ownbinding-exact', {k:v for k,v in S['slot_bindings'].items() if v['candidate_id']==CID}==read(W/'READ-NOTE-v1.json')['whole_ownbindings'])
record=copy.deepcopy(row['source_after']);record['content']['role_evidence']=proof;S['candidates'][CID]=record
qualified_expected='f26867869915e331f277b9cc8f1b6a186e20514c34303847e83d19cad9307765'
yes('reviewed-source-plus-only-exact-proof',c.digest(S)==qualified_expected)
core=read(W/'PRE-DISCOVERY-REQUEST-v1.json')['core'];inv=read(W/'PRE-DISCOVERY-REQUEST-v1.json')['inventory'];savedpacket=read(W/'SELECTED-B1-REVIEW-PACKET-v1.json');assessment=read(W/'MANUAL-IMPACT-ASSESSMENT-v1.json');after=read(W/'TYPED-AFTER-STATE-v1.json');contracts={CID:row['source_after']['content']['permission_envelope']['realizations']['base']}
def reseal(k):k.pop('canonical_sha256',None);k['canonical_sha256']=c.digest(k);return k

def choices(k):
 f=n.frozen_witnesses(k);sc={s['scope_id']:s for s in f['member_scopes']}
 bindings=[{'target':t,'selection':{'kind':'existing_owner','owner_id':v}} for t,v in [('image','I'),('initiating_hand','H1'),('exchange_item','X')]]
 bindings +=[{'target':t,'selection':{'kind':'existing_member_scope','scope_id':sid,'scope_sha256':c.digest(sc[sid])}}for t,sid in [('other_hands','other_hands'),('framing_affected_owners','framing_affected')]]
 return {'schema':n.MEMBER_SELECTION_SCHEMA,'core_sha256':k['canonical_sha256'],'owner_graph_sha256':c.digest(f['graph']),'member_scopes_sha256':c.digest(f['member_scopes']),'entries':[{'candidate_id':CID,'realization_id':'base','meaning_sha256':proof['meaning_sha256'],'qualification_sha256':c.digest(proof),'bindings':bindings}]}
compactdata={**S,'candidates':{**S['candidates'],CID:layout.guard_record(record,S)}}
def entry(k,compact=False,binding=False):
 e=c.entry(compactdata if compact else S,CID,'bind_2e72784a26885ceaa1d645d25bd9a468' if binding else None,realization_id='base',owner_selections=choices(k))
 if compact:e.pop('role_evidence',None)
 return e
controls=({'subject_category':'object','domains':[],'intent_constraints':{'subject_categories':['object'],'domains':[]}},{'subject':{'kind':['object'],'tags':['object']}})
def eligible(e,k,tag=''):return g.core_entry_eligible(S,k,controls[0],controls[1],tag,e)
e=entry(core);n.validate(record,cat,corpus=S)
denied('shape-validation-cannot-issue-source-or-plan-authority',lambda:n.admission(e,core,source_data=S))
# Exact selected source was directly reviewed; this explicit call is the separate trusted act.
save('REVIEWED-SOURCE-PIN.json',{'schema':'same-model-peer-explicit-source-authority-pin/v1','reviewer':REVIEWER,'expected_snapshot_sha256':qualified_expected,'root_snapshot':I['current_snapshot'],'BATCH_raw':raw(W/'BATCH.json'),'proof_sha256':c.digest(proof),'source27_personally_read_CIDs':[CID],'full18250_personally_read':False,'root_acceptance':0,'operating':0,'reason':'Root full input with only exact whole-reviewed1299 proof; all other records root input bytes, not peer reread or semantic approval. Prior source knowledge disclosed; controlled synthetic request/typed result only.'})
authority=pe.freeze_source_authority(S,expected_snapshot_sha256=qualified_expected,reviewer=REVIEWER)
cap=pe.freeze_permission_inventory(core,inv,expected_inventory_sha256='909e8715a6dcfc8ce094fbf185be728fd6976e7c763be39c71e742f874959a88',reviewer=REVIEWER+' whole finite request completeness review')
packet=pe.prepare_permission_review(authority,cap,core,[e],contracts=contracts)
yes('entire-B1-whole-source-reviewpacket-exact-writer',packet==savedpacket)
plan=pe.freeze_permission_plan(authority,core,[e],inventory=cap,assessment=assessment,contracts=contracts,reviewer=REVIEWER+' reviewed18impacts+within3pairs')
pp=pe._payload(plan,'permission plan');scope=packet['resolved_view']['permission_scope'];fx=packet['resolved_view']['effect_assignments']
yes('exact22literal-union-and-3canonical-effects',len(scope['literal_properties'])==22 and len(fx)==3)
for f in fx:
 expected=['H1','H2','H3'] if f['dimension']=='action' else ['H1','H2','H3','R1','R2','U','V','X']
 yes('exact-all-Rx:'+f['property'],f['receivers']==expected and f['operation']=='set_value')
yes('no-desired-effects-as-baseline-P',not any(a.get('axes',{}).get('property') in {'shot.scale','framing.coverage','action.interaction.exchange'}for a in core['semantic_assertions']))
# A receipt/dict or freshly self-hashed payload is not a live capability.
denied('serialized-source-authority-deny',lambda:pe.prepare_permission_review(pe._payload(authority,'source authority'),cap,core,[e],contracts=contracts))
denied('serialized-inventory-deny',lambda:pe.freeze_permission_plan(authority,core,[e],inventory=inv,assessment=assessment,contracts=contracts,reviewer=REVIEWER))
wrong=copy.deepcopy(inv);wrong['scope_members']['framing_affected'].remove('R2')
denied('independently-pinned-omitted-R2-inventory-deny',lambda:pe.freeze_permission_inventory(core,wrong,expected_inventory_sha256=c.digest(inv),reviewer=REVIEWER))
wrong=copy.deepcopy(assessment);wrong['anchors'][-1]['impact']='unknown'
denied('unknown-impact-deny',lambda:pe.freeze_permission_plan(authority,core,[e],inventory=cap,assessment=wrong,contracts=contracts,reviewer=REVIEWER))
wrong=copy.deepcopy(assessment);wrong['anchors'].pop()
denied('missing-18th-impact-deny',lambda:pe.freeze_permission_plan(authority,core,[e],inventory=cap,assessment=wrong,contracts=contracts,reviewer=REVIEWER))
for compact in [False,True]:
 ee=entry(core,compact)
 denied(('compact'if compact else'full')+':missing-session-deny',lambda ee=ee:n.admission(ee,core,source_data=S))
 with pe.trusted_permission_session(authority,plan):
  yes(('compact'if compact else'full')+':plan-admission-before-final',n.admission(ee,core,source_data=S)['allowed'])
  denied(('compact'if compact else'full')+':missing-typed-final-deny',lambda ee=ee:n.audit_final_scalar_preservation([ee],core))
# Independently reread typed result has exactly the same actual X, I, topology and native assertions.
typed=pe.freeze_after_state(plan,after['after_core'],expected_after_sha256=after['after_core_sha256'],evidence=after['original_evidence'],reviewer=REVIEWER+' direct typed after-state X/I review')
for defect in ['hidden','wrong-image','wrong-item','missing-scalar','missing-relation','wrong-original-hash','missing-evidence','stale-expectation']:
 k=copy.deepcopy(after['after_core']);ev=copy.deepcopy(after['original_evidence']);expect=None
 if defect=='hidden':next(a for a in k['semantic_assertions']if a['assertion_id']=='item_visible')['axes']['value']='hidden'
 elif defect=='wrong-image':next(a for a in k['semantic_assertions']if a['assertion_id']=='item_image')['axes']['value']='I2'
 elif defect=='wrong-item':next(a for a in k['semantic_assertions']if a['assertion_id']=='item_visible')['axes']['owner']='H1'
 elif defect.startswith('missing-')and defect!='missing-evidence':k['semantic_assertions']=[a for a in k['semantic_assertions']if a['assertion_id']!=('item_visible'if defect=='missing-scalar'else'item_image')]
 elif defect=='wrong-original-hash':ev[0]['original_assertion_sha256']='0'*64
 elif defect=='missing-evidence':ev=[]
 else:expect='0'*64
 reseal(k)
 denied('typed-final:'+defect,lambda k=k,ev=ev,expect=expect:pe.freeze_after_state(plan,k,expected_after_sha256=expect or c.digest(k),evidence=ev,reviewer=REVIEWER+' deliberately false negative-control; no semantic endorsement'))
# Every original canonical property and actual receiver retains independent lock enforcement.
for j,a in enumerate(scope['literal_properties']):
 lock=copy.deepcopy(core['intent_lock']);lock['semantic_anchors'].append(a)
 yes('canonical-all22-target-Rx-lock:'+str(j),not property_effects_allowed(lock,scope['dimensions'],scope['literal_properties'],owner_graph=scope['owner_graph']),a)
for a in [{'dimension':'framing','target':'I','property':'shot'},{'dimension':'framing','target':'U','property':'framing.*'},{'dimension':'action','target':'V','property':'action.interaction'}]:
 lock=copy.deepcopy(core['intent_lock']);lock['semantic_anchors'].append(a)
 yes('parent-wildcard-ancestor-lock:'+str(a),not property_effects_allowed(lock,scope['dimensions'],scope['literal_properties'],owner_graph=scope['owner_graph']))
with pe.trusted_permission_session(authority,plan,after_state=typed):
 for compact in [False,True]:
  for binding in [False,True]:
   ee=entry(core,compact,binding);label=('compact'if compact else'full')+('-ownbinding'if binding else'')
   yes(label+':actual-admission',n.admission(ee,core,source_data=S)['allowed'])
   yes(label+':actual-consumer',eligible(ee,core))
   dd,pr,gr=n.permission_scope(ee,core,source_data=S)
   yes(label+':unchanged-permission-scope',dd==scope['dimensions'] and pr==scope['literal_properties'])
   final=n.audit_final_scalar_preservation([ee],core)
   rr=final['receipts'][0]
   yes(label+':final-same-X-I-original-assertions',rr['obligation']['target']=='X' and rr['obligation']['image']=='I' and rr['scalar_assertion']['assertion_id']=='item_visible' and rr['relation_assertion']['axes']['value']=='I')
  for role in ['shot_scale','subject_framing','action','relational_action']:
   yes(('compact'if compact else'full')+':actual-role:'+role,eligible(entry(core,compact),core,role))
 composed={'chosen_candidate_ids':[CID],'candidate_interpretations':[{'candidate_id':CID,'realization_id':'base'}],'owner_selections':e['_native_owner_selections'],'prompt_en':'Macro framing in image I of hands H1,H2,H3 physically handing off existing item X. Only hands are visible as participant anatomy, panels R1/R2 are outside the crop. Same X remains visible in same I; all entities/topology remain.'}
 with mock.patch.object(g,'frozen_core_context',return_value=controls):
  out={};fails=audit.audit_native_adoptions({'authorial_core':core,'creative_controls':{}},composed,S,resolution_out=out)
 yes('actual-final-native-auditor',not fails,{'failures':fails,'categorical_precore_setup_only_isolated':True,'native_internal_checks_mocked':False})
# Do not replay whole writer negative suite; precise original guards fresh-check on current B1.
for aid in ['type_H3','separate_H1_H3','present_R2','item_image']:
 k=copy.deepcopy(core);k['semantic_assertions']=[a for a in k['semantic_assertions']if a['assertion_id']!=aid];reseal(k)
 for comp in [False,True]:
  with pe.trusted_permission_session(authority,plan):denied('required-original-guard/P:'+aid+':'+str(comp),lambda k=k,comp=comp:n.admission(entry(k,comp),k,source_data=S))
modules={}
for name,m in sorted(sys.modules.items()):
 p=getattr(m,'__file__',None)
 if p and (name.startswith('photo_')or name in {'prompt_generator','audit_composed_prompt'}):
  p=Path(p).resolve();assert p.is_relative_to(G),(name,p);modules[name]={'file':str(p),'raw_sha256':raw(p)}
save('CONTROLS.json',{'schema':'1299-same-model-peer-focused-actual-controls/v1','task_name':'/root/review_06250_07250','model':'gpt-6.1-sol','reasoning_effort':'high','checks':checks,'assertions':len(checks),'all_pass':all(x['pass']for x in checks),'module_paths_sha256':modules,'root_acceptance':0,'operating':0,'real_user_blind_or_pixels':False,'boundary':'Controlled source-known finite request/typed result; writer data reused as exact manually peer-read fixture, no writer helper imported. Authority explicitly issued only after whole source/manual review. Full final audit isolates categorical precore only; native/source/permission/finalPR real. No full production pack or pixels.'})
print(json.dumps({'assertions':len(checks),'all_pass':True,'modules':len(modules)}))
