"""Fresh-plan guard isolation and grounded alias controls; exact same source1299."""
from pathlib import Path
# Reuse only our explicitly bounded initialization/functions, not prior tests or any writer helper.
p=Path(__file__).with_name('peer.py');prefix=p.read_text().split("e=entry(core);n.validate(record,cat,corpus=S)")[0]
exec(compile(prefix,str(p),'exec'),globals());checks=[]
authority=pe.freeze_source_authority(S,expected_snapshot_sha256=qualified_expected,reviewer=REVIEWER+' extra guard controls')
for defect in ['wrong-last-hand-kind','missing-all-grounded-last-hand-disjoint','remove-direct-but-parent-separation-remains']:
 k=copy.deepcopy(core)
 if defect=='wrong-last-hand-kind':next(a for a in k['semantic_assertions']if a['assertion_id']=='type_H3')['axes']['value']='fin'
 else:
  missing={'separate_H1_H3','separate_U_V'}if defect=='missing-all-grounded-last-hand-disjoint'else{'separate_H1_H3'}
  k['semantic_assertions']=[a for a in k['semantic_assertions']if a['assertion_id']not in missing]
 reseal(k);fr=n.frozen_witnesses(k);iv=copy.deepcopy(inv);iv.update(core_sha256=k['canonical_sha256'],core_payload_sha256=c.digest(k),topology_sha256=c.digest(fr['graph']))
 cap=pe.freeze_permission_inventory(k,iv,expected_inventory_sha256=c.digest(iv),reviewer=REVIEWER+' exact declared controlled perturbation, no semantic approval')
 ee=entry(k);packet=pe.prepare_permission_review(authority,cap,k,[ee],contracts=contracts)
 ar=copy.deepcopy(assessment);ar.update(inventory_sha256=c.digest(iv),resolved_view_sha256=c.digest(packet['resolved_view']),source_bindings_sha256=c.digest(packet['source_bindings']))
 plan=pe.freeze_permission_plan(authority,k,[ee],inventory=cap,assessment=ar,contracts=contracts,reviewer=REVIEWER+' permission-only control retains18 unchanged impact judgements; no P/guard waiver')
 expected=defect=='remove-direct-but-parent-separation-remains'
 with pe.trusted_permission_session(authority,plan):
  for comp in [False,True]:
   e=entry(k,comp);guard=n.evaluate_native_guards(e,k);ad=n.admission(e,k,source_data=S);consumer=eligible(e,k)
   yes('fresh-plan:'+defect+':'+str(comp),guard['allowed']==expected and ad['allowed']==expected and consumer==expected,{'guard':guard,'admission':ad,'consumer':consumer,'stale_positive_plan_used':False,'expected_allowed':expected})
# Actual declared alias fixture was directly read as exact original core plus explicit suffix,
# unchanged source definitions. It is not inferred by string similarity.
alias=read(W/'ALIAS-LOCK-CHECKS-v1.json')['core'];original=read(W/'PRE-DISCOVERY-REQUEST-v1.json')['core']
suffix=' H1_alias is another exact input name for H1, the same existing hand and not a second entity.'
yes('alias-fixture-exact-literal-extension',alias['source_request']==original['source_request']+suffix)
ctx=n._resolve_selected_native_contracts([entry(alias)],alias);scope=ctx['view']['permission_scope']
for dim,prop in [('framing','shot.scale'),('framing','framing.coverage'),('action','action.interaction.exchange')]:
 lock=copy.deepcopy(alias['intent_lock']);lock['semantic_anchors'].append({'dimension':dim,'target':'H1_alias','property':prop})
 yes('grounded-alias-original-lock:'+prop,not property_effects_allowed(lock,scope['dimensions'],scope['literal_properties'],owner_graph=scope['owner_graph']))
save('FOCUSED-FOLLOWUP-CONTROLS.json',{'schema':'same-model-peer-fresh-plan-and-alias-controls/v1','task_name':'/root/review_06250_07250','checks':checks,'assertions':len(checks),'all_pass':all(x['pass']for x in checks),'root_acceptance':0,'operating':0,'boundary':'New fresh current core/plan prevents stale-plan denial from masquerading as an isolated guard check. Removing direct H1-H3 alone remains valid via actual U/V separation and owned parts. Both grounded paths must be removed for a disjointness negative. Initial CONTROLS97 last8 are only retained positive-plan/core-staleness tests, not all isolated semantic guard tests. Alias consumes explicit equivalence; no source aliases or metadata.'})
print({'assertions':len(checks),'all_pass':True})
