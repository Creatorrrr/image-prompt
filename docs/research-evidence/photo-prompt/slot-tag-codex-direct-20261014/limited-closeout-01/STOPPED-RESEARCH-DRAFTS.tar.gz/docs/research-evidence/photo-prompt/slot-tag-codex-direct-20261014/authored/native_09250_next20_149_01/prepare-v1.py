"""Explicit root-delegated sparse bookkeeping only; semantic read/proof credit zero."""
from pathlib import Path
import sys,json,gzip,hashlib
sys.dont_write_bytecode=True
G=Path('/Users/chasoik/.cache/image-prompt/photo-shared-runtime/generations/fe5b593c819806a31803e40c620e6f2b28c3b54103f451dd6f38920f2d537258')
sys.path[:0]=[str(G/'scripts'),str(G/'precore')]
import photo_candidate_corpus as c
import photo_semantic_evidence as n
R=Path('docs/research-evidence/photo-prompt/slot-tag-codex-direct-20261014');D=R/'authored/native_09250_next20_149_01'
sys.path.insert(0,str(R));import prepare_simple5_and_diagnostic7_root_01 as helper
sys.path[:0]=[str(G/'scripts'),str(G/'precore')]
assert helper.c is c and helper.n is n
assert all(Path(m.__file__).resolve().is_relative_to(G) for m in [c,n])
def read(p):
 b=p.read_bytes();return json.loads(gzip.decompress(b) if b[:2]==b'\x1f\x8b' else b)
def ref(p):return {'file':str(p),'file_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'sha256':c.digest(read(p))}
manifest=read(D/'SELECTION-MANIFEST-v1.json');original=read(R/'SOURCE.json.gz');S=Path(manifest['source']['file']);current=read(S);assert ref(S)==manifest['source']
oldinput=read(R/'native-inputs/prepared/review09250-soil3-149-01/INPUT.json');rows=[]
for row in manifest['rows']:
 loc=dict(row['original_compiled_locator']);loc['file_sha256']=loc.pop('file_raw_sha256');o=row['ordinal'];p=R/'packets'/('11250-250.json' if o<11500 else '11500-250.json')
 assert c.digest(current['candidates'][row['candidate_id']])==row['current_whole_sha256']
 rows.append({'candidate_id':row['candidate_id'],'ordinal':o,'locator':loc,'packet':ref(p)})
before=c.digest(current)
out=helper.prepare_sparse('review09250-next20-149-01',rows,original,current,ref(S),oldinput['order'],oldinput['catalog_review'],ref(D/'SELECTION-MANIFEST-v1.json'),task_name='/root/review_09250_10500')
assert before==c.digest(current)
receipt={'schema':'photo-native-delegated-sparse-preparation-attestation/v1','actor':'/root','actor_role':'orchestration','delegated_preparer_task':'/root/review_09250_10500','task_name':'/root/review_09250_10500','model':'gpt-6.1-sol','reasoning_effort':'high','authorization':'Root explicit next20 assignment delegated existing prepare_sparse for source27 unchanged selected currents.','prepared_directory':out,'prepared_count':20,'actual_read_count':0,'native_proofs_created':0,'source_changes':0,'engine_changes':0,'network_calls':0,'model_calls':0,'Gemini_calls':0,'helper':{'file':helper.__file__,'file_sha256':hashlib.sha256(Path(helper.__file__).read_bytes()).hexdigest()},'actual_modules':{m.__name__:{'file':m.__file__,'file_sha256':hashlib.sha256(Path(m.__file__).read_bytes()).hexdigest()} for m in [c,n]},'source':ref(S),'manifest':ref(D/'SELECTION-MANIFEST-v1.json')}
p=D/'PREPARER-ATTESTATION-v1.json'
with p.open('x') as f:f.write(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(receipt))
