"""Bounded actual1299 mandatory-permission/typed-P/PR/scope adversarial runs."""
from common_v1 import *
from after_state_v1 import after_core,evidence
from photo_contracts import property_effects_allowed
import time
start=time.monotonic();core,inv,cap,authority=frozen_inputs();es=entries(core);base=load('MANUAL-IMPACT-ASSESSMENT-v1.json')
plan=pe.freeze_permission_plan(authority,core,[es[0]],inventory=cap,assessment=base,contracts=contracts(),reviewer='/root/review_11870_12250 reviewed positive control')
checks=[]
def deny(name,fn):
 try:
  result=fn();rejected=(result is False or isinstance(result,dict)and result.get('allowed')is False)
  error=None
 except (ValueError,KeyError,TypeError) as exc:result=None;rejected=True;error=type(exc).__name__+': '+str(exc)
 checks.append({'case':name,'expected':'deny','rejected':rejected,'error':error,'actual_result':result})
 if not rejected:raise AssertionError('unexpected permission: '+name)
def scoped_plan(k,inventory,assessment):
 selected=entries(k)[0]
 capability=pe.freeze_permission_inventory(k,inventory,expected_inventory_sha256=c.digest(inventory),reviewer='explicit adversarial fixture inventory review')
 return pe.freeze_permission_plan(authority,k,[selected],inventory=capability,assessment=assessment,contracts=contracts(),reviewer='explicit adversarial fixture plan')
try:
 for transport,e in zip(['full','compact'],es):
  deny(transport+':missing-session/admission',lambda e=e:n.admission(e,core,source_data=S))
  deny(transport+':missing-session/consumer',lambda e=e:eligible(e,core))
  deny(transport+':missing-session/permission',lambda e=e:n.permission_scope(e,core,source_data=S))
  deny(transport+':missing-session/final',lambda e=e:n.audit_final_scalar_preservation([e],core))
  injected=copy.deepcopy(e);injected['permission_plan']=pe._payload(plan,'permission plan')
  deny(transport+':self-injected-plan',lambda:n.admission(injected,core,source_data=S))
 # A JSON/selfhash cannot supply any trusted capability.
 for label,call in [
  ('self-rehashed-authority',lambda:pe.prepare_permission_review(pe._payload(authority,'source authority'),cap,core,[es[0]],contracts=contracts())),
  ('self-rehashed-inventory',lambda:pe.freeze_permission_plan(authority,core,[es[0]],inventory=pe._payload(cap,'permission inventory'),assessment=base,contracts=contracts(),reviewer='test')),
  ('self-rehashed-plan',lambda:pe._payload(pe._payload(plan,'permission plan'),'permission plan'))]:deny(label,call)
 # Full authoritative source is an explicit independent deny input in every standalone strict route.
 # Inside the active session the same CID also remains source-required even if payload opt-in is stripped.
 with pe.trusted_permission_session(authority,plan):
  for transport,e in zip(['full','compact'],es):
   for defect in ['strip-optin','strip-all-proof','change-E','remove-frame-Rx','remove-guard']:
    bad=copy.deepcopy(e);p=bad['_semantic_evidence_guard']
    if defect=='strip-optin':
     bad.pop('permission_envelope',None);p.pop('permission_envelopes',None)
     if isinstance(bad.get('role_evidence'),dict):bad['role_evidence'].pop('permission_envelopes',None)
    elif defect=='strip-all-proof':bad.pop('_semantic_evidence_guard');bad.pop('role_evidence',None);bad.pop('permission_envelope',None)
    elif defect=='change-E':next(f for f in p['facts']if f['id']=='macroApp')['value']['value']='wide'
    elif defect=='remove-frame-Rx':next(f for f in p['facts']if f['id']=='coverageApp')['receivers'].remove('framing_affected_owners')
    else:p['guard_sets']['base']['source_conditions'][0]['native_guards']['rules'].pop()
    if '_semantic_evidence_guard'in bad:p['compact_sha256']=c.digest({k:v for k,v in p.items()if k!='compact_sha256'})
    for route,fn in [('admission',lambda bad=bad:n.admission(bad,core,source_data=S)),('consumer',lambda bad=bad:eligible(bad,core)),
       ('permission',lambda bad=bad:n.permission_scope(bad,core,source_data=S)),
       ('property-utility',lambda bad=bad:n.property_scope_allowed(core,bad['affected_dimensions'],bad['affected_properties'],record=bad))]:deny(transport+':'+defect+'/'+route,fn)
 # Actual full-record qualification cannot replace the root-selected mandatory source.
 forged=copy.deepcopy(record);forged['content'].pop('permission_envelope');p=forged['content']['role_evidence'];p.pop('permission_envelopes')
 p['meaning_sha256']=n.meaning_sha256(forged);p['review']['native_review']['native_contract_sha256']=n.native_contract_sha256(p)
 deny('actual-full-source-qualification/stripped-rehashed',lambda:n.validate(forged,CAT,corpus=S))
 for defect in ['incomplete','unknown','unreviewed-input','unreviewed-span','missing-owner','stale-topology','stale-input','scope-mismatch','wrong-witness-image','witness-unreviewed-span']:
  wrong=copy.deepcopy(inv)
  if defect=='incomplete':wrong['complete']=False
  elif defect=='unknown':wrong['state']='unknown'
  elif defect=='unreviewed-input':wrong['reviewed_input_ids']=[]
  elif defect=='unreviewed-span':wrong['reviewed_span_ids']=[]
  elif defect=='missing-owner':wrong['owners'].remove('R2')
  elif defect=='stale-topology':wrong['topology_sha256']='0'*64
  elif defect=='stale-input':wrong['input_binding']['request_sha256']='0'*64
  elif defect=='scope-mismatch':wrong['scope_members']['other_hands']=['H2']
  elif defect=='wrong-witness-image':wrong['witnesses'][0]['image']='I2'
  else:wrong['witnesses'][0]['span_ids']=['unread-span']
  wrongassessment=copy.deepcopy(base);wrongassessment['inventory_sha256']=c.digest(wrong)
  deny('inventory:'+defect,lambda w=wrong,a=wrongassessment:scoped_plan(core,w,a))
 # Even rehashed data cannot replace an independently retained expected inventory pin.
 wrong=copy.deepcopy(inv);wrong['scope_members']['framing_affected'].remove('R2')
 deny('rehashed-omitted-scope/independent-pin',lambda:pe.freeze_permission_inventory(core,wrong,expected_inventory_sha256=c.digest(inv),reviewer='reviewer'))
 for defect in ['unknown','affects','missing-pair','stale-view','stale-source']:
  wrong=copy.deepcopy(base)
  if defect in ['unknown','affects']:wrong['anchors'][0]['impact']=defect
  elif defect=='missing-pair':wrong['anchors'].pop()
  elif defect=='stale-view':wrong['resolved_view_sha256']='0'*64
  else:wrong['source_bindings_sha256']='0'*64
  deny('assessment:'+defect,lambda w=wrong:pe.freeze_permission_plan(authority,core,[es[0]],inventory=cap,assessment=w,contracts=contracts(),reviewer='adversarial test'))
 # Exact P/PR and all six original guards, including the last scoped hand/member.
 for defect in ['wrong-last-hand-kind','missing-last-hand-disjoint','missing-frame-member-presence','hidden-item','wrong-image']:
  k=copy.deepcopy(core)
  if defect=='wrong-last-hand-kind':next(x for x in k['semantic_assertions']if x['assertion_id']=='type_H3')['axes']['value']='fin'
  elif defect=='missing-last-hand-disjoint':k['semantic_assertions']=[x for x in k['semantic_assertions']if x['assertion_id']!='separate_H1_H3']
  elif defect=='missing-frame-member-presence':k['semantic_assertions']=[x for x in k['semantic_assertions']if x['assertion_id']!='present_R2']
  elif defect=='hidden-item':next(x for x in k['semantic_assertions']if x['assertion_id']=='item_visible')['axes']['value']='hidden'
  fi.reseal(k)
  for transport,which in [('full',0),('compact',1)]:
   def call(k=k,which=which,defect=defect):
    selected=entries(k,image='I2'if defect=='wrong-image'else'I')[which]
    # These negatives retain a valid source authority but cannot satisfy either
    # exact actual-source obligations or the unchanged positive plan/core pin.
    with pe.trusted_permission_session(authority,plan):return n.admission(selected,k,source_data=S)
   deny('actual-guard/P:'+defect+'/'+transport,call)
 # Actual property primitive checks every one of the unchanged 22 target/Rx tuples.
 view=load('SELECTED-B1-REVIEW-PACKET-v1.json')['resolved_view'];scope=view['permission_scope'];graph=scope['owner_graph']
 assert len(scope['literal_properties'])==22 and property_effects_allowed(core['intent_lock'],scope['dimensions'],scope['literal_properties'],owner_graph=graph)
 for j,anchor in enumerate(scope['literal_properties']):
  lock=copy.deepcopy(core['intent_lock']);lock['semantic_anchors'].append(anchor)
  deny('original-E-all-target-Rx-lock:'+str(j)+':'+anchor['target']+'/'+anchor['property'],lambda lock=lock:property_effects_allowed(lock,scope['dimensions'],scope['literal_properties'],owner_graph=graph))
 for anchor in [{'dimension':'framing','target':'I','property':'shot'}, {'dimension':'framing','target':'U','property':'framing.*'},
  {'dimension':'action','target':'U','property':'action.interaction'}, {'dimension':'action','target':'V','property':'action.*'}]:
  lock=copy.deepcopy(core['intent_lock']);lock['semantic_anchors'].append(anchor)
  deny('original-parent-wildcard-ancestor:'+anchor['target']+'/'+anchor['property'],lambda lock=lock:property_effects_allowed(lock,scope['dimensions'],scope['literal_properties'],owner_graph=graph))
 for dimension in ['framing','action']:
  # Whole-dimension permission is a separate original conjunction, not an
  # undocumented obligation of the partial-property primitive itself.
  k=copy.deepcopy(core);k['intent_lock']['locked_dimensions'].append(dimension);k['intent_lock']['open_dimensions'].remove(dimension);fi.reseal(k)
  inventory=fi.inventory(k);capability=pe.freeze_permission_inventory(k,inventory,expected_inventory_sha256=c.digest(inventory),reviewer='explicit whole-dimension protected negative')
  selected=entries(k)[0];packet=pe.prepare_permission_review(authority,capability,k,[selected],contracts=contracts());v=packet['resolved_view']
  assessment=copy.deepcopy(base);assessment['inventory_sha256']=c.digest(inventory);assessment['resolved_view_sha256']=c.digest(v);assessment['source_bindings_sha256']=c.digest(packet['source_bindings'])
  anchor=next(a for a in inventory['anchors']if a['kind']=='whole_dimension'and a['dimension']==dimension)
  for f in v['nodes'][0]['expanded_facts']:
   if f['mode']!='effect':continue
   ek=c.digest({key:f[key]for key in ['candidate_id','realization_id','fact_id','expansion_index','target']})
   assessment['anchors'].append({'effect_key':ek,'anchor_key':c.digest(anchor),'impact':'disjoint',
    'reason':'Deliberately false adversarial manual disjoint row cannot waive an original whole-dimension lock.',
    'input_ids':['request'],'span_ids':['request_1'],'preservation_ref':None})
  deny('original-whole-dimension-plan:'+dimension,lambda:pe.freeze_permission_plan(authority,k,[selected],inventory=capability,assessment=assessment,contracts=contracts(),reviewer='adversarial disjoint claim'))
 # The exact old 1299 gap: a different real property path is NOT an alias.
 # Original primitive may allow it, while the reviewed whole-source impact must deny.
 semantic=[]
 for anchor,impact in [({'dimension':'framing','target':'R1','property':'subject.visibility'},'affects'),
  ({'dimension':'framing','target':'R2','property':'body.framing'},'affects'),
  ({'dimension':'framing','target':'U','property':'framing.inclusion'},'affects'),
  ({'dimension':'framing','target':'R2','property':'custom.unreviewed_visibility'},'unknown')]:
  k=copy.deepcopy(core);k['intent_lock']['semantic_anchors'].append(anchor);fi.reseal(k);inventory=fi.inventory(k)
  selected=entries(k)[0];capability=pe.freeze_permission_inventory(k,inventory,expected_inventory_sha256=c.digest(inventory),reviewer='independent added-protected-property negative')
  packet=pe.prepare_permission_review(authority,capability,k,[selected],contracts=contracts());v=packet['resolved_view'];assessment=copy.deepcopy(base)
  assessment['inventory_sha256']=c.digest(inventory);assessment['resolved_view_sha256']=c.digest(v);assessment['source_bindings_sha256']=c.digest(packet['source_bindings'])
  for f in v['nodes'][0]['expanded_facts']:
   if f['mode']!='effect':continue
   ek=c.digest({key:f[key]for key in ['candidate_id','realization_id','fact_id','expansion_index','target']})
   assessment['anchors'].append({'effect_key':ek,'anchor_key':c.digest(anchor),'impact':impact if f['fact_id']=='coverageApp'else'disjoint',
    'reason':'Direct whole source hands-only coverage excludes the independently included nonhand panel/carrier region; the new real protected inclusion/visibility therefore conflicts. No property alias is invented.'if impact=='affects'else'No semantic definition for this custom protected visibility meaning is provided; the actual crop influence is unknown and must fail closed.',
    'input_ids':['request'],'span_ids':['request_1'],'preservation_ref':None})
  primitive_allowed=property_effects_allowed(k['intent_lock'],scope['dimensions'],scope['literal_properties'],owner_graph=graph)
  assert primitive_allowed
  semantic.append({'anchor':anchor,'original_property_primitive_allowed':primitive_allowed,'manual_coverage_impact':impact})
  deny('whole-source-semantic-impact:'+anchor['target']+'/'+anchor['property'],lambda:pe.freeze_permission_plan(authority,k,[selected],inventory=capability,assessment=assessment,contracts=contracts(),reviewer='actual independently read semantic conflict'))
 # Final PR requires its separate result capability and exact original source IDs/spans.
 with pe.trusted_permission_session(authority,plan):
  for transport,e in zip(['full','compact'],es):deny('missing-typed-result:'+transport,lambda e=e:n.audit_final_scalar_preservation([e],core))
 result=after_core(core);ev=evidence(plan)
 for defect in ['hidden','wrong-image','wrong-item','missing-scalar','unread-span','stale-pin','wrong-original-scalar','wrong-original-relation','missing-evidence','incomplete-input']:
  wrong=copy.deepcopy(result);evidence_row=copy.deepcopy(ev);expected=None
  if defect=='hidden':next(x for x in wrong['semantic_assertions']if x['assertion_id']=='item_visible')['axes']['value']='hidden'
  elif defect=='wrong-image':next(x for x in wrong['semantic_assertions']if x['assertion_id']=='item_image')['axes']['value']='I2'
  elif defect=='wrong-item':next(x for x in wrong['semantic_assertions']if x['assertion_id']=='item_visible')['axes']['owner']='H1'
  elif defect=='missing-scalar':wrong['semantic_assertions']=[x for x in wrong['semantic_assertions']if x['assertion_id']!='item_visible']
  elif defect=='unread-span':next(x for x in wrong['semantic_assertions']if x['assertion_id']=='item_visible')['source_span_ids']=['unread']
  elif defect=='stale-pin':expected='0'*64
  elif defect=='wrong-original-scalar':evidence_row[0]['original_assertion_sha256']='0'*64
  elif defect=='wrong-original-relation':evidence_row[0]['original_relation_sha256']='0'*64
  elif defect=='missing-evidence':evidence_row=[]
  else:wrong['request_binding']['input_inventory']['complete']=False
  fi.reseal(wrong)
  deny('typed-after:'+defect,lambda w=wrong,e=evidence_row,h=expected:pe.freeze_after_state(plan,w,expected_after_sha256=h or c.digest(w),evidence=e,reviewer='independent typed negative'))
 deny('self-rehashed-after-state',lambda:pe._payload(load('TYPED-AFTER-STATE-v1.json')['receipt'],'after state'))
finally:
 out={'schema':'photo-source1299-actual-mandatory-negative-checks/v1','assignment_sha256':c.digest(A),'input_sha256':c.digest(I),'proof_sha256':c.digest(proof),
  'checks':checks,'count':len(checks),'all_rejected':all(x['rejected']for x in checks),'actual_original_permission_triples':22,
  'semantic_other_property_cases':locals().get('semantic',[]),'module_paths_sha256':modules(),'elapsed_seconds':round(time.monotonic()-start,3),
  'root_acceptance':0,'operating':0,'real_user_or_pixel':False,
  'boundary':'Exact frozen actual source1299 proof with synthetic typed controlled inputs. Strict stripped routes explicitly use actual full source and/or active trusted source session; standalone record=None legacy property primitives supply no source authority. All 22 old E/Rx locks, parent/wildcard/ancestor/whole checks use the actual immutable B1 property union and frozen primitive. Semantic nonmatching-property impacts use fresh actual plan negatives. Trusted manual input completeness remains a human truth boundary: a newly trusted false complete scope cannot be detected from a self-consistent hash alone; no such false scope is granted trust here.'}
 print(json.dumps(save('NEGATIVE-CHECKS-v2.json',out)))
 print('negative count',len(checks),'all rejected',out['all_rejected'])
