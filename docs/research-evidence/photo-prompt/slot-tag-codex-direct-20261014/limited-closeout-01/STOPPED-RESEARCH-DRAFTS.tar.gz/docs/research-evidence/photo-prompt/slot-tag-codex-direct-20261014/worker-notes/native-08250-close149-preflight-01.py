"""Offline shape-only preflight. No formal input, signing, qualification, registration or source write."""
import json,gzip,hashlib,sys,copy
from pathlib import Path
R=Path(__file__).resolve().parents[1];A=R/'authored';W=R/'worker-notes';P=A/'native_08250_close149_five.proposal-03.json';j=json.loads(P.read_text());G=Path(j['frozen_validator']['generation']);sys.path[:0]=[str(G/'scripts'),str(G/'precore')]
import photo_semantic_evidence as n
import photo_candidate_corpus as c
import photo_candidate_realizations as rr
h=lambda v:hashlib.sha256(json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
pins={}
for name,m in [('native',n),('corpus',c),('realizations',rr),('witnesses',n.witnesses),('role_views',n.manual_views),('owner_resolver',n.owner_resolver)]:
 p=Path(m.__file__).resolve();assert p.is_relative_to(G),(name,p);pins[name]={'file':str(p),'raw_sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
assert pins['native']['raw_sha256']=='f74a5ef91bc07048c8bf312b66680c5b92b3b7b388f31f1890f31c8578609dee'
current=json.loads(gzip.decompress(Path(j['source_input']['file']).read_bytes()));assert h(current)==j['source_input']['canonical_sha256'];proposed=copy.deepcopy(current);results=[]
for x in j['records']:
 s=x['source_after_proposal'];assert h(s)==x['source_after_proposal_sha256'];proposed['candidates'][s['id']]=s
 assert rr.ids(s)==['base']
 fs=x['facts_unsigned_design'];ids={f['id'] for f in fs};assert len(ids)==len(fs)
 for f in fs:
  n._fact_valid(f);assert f['pointer'] in n.primary_paths(s,'base');assert f['quote'] in n.positive_string(s,f['pointer'],realization_id='base');assert set(f['requires'])<=ids
  assert all(next(v for v in fs if v['id']==ref)['mode'] in {'prerequisite','preservation'} for ref in f['requires'])
 n._validate_owner_map(x['owner_map_unsigned_design'],fs)
 if x['guard_rules_exact_source']:n.validate_source_guards(s['conditions']['native_guards'])
 unitp={u['pointer'] for u in x['source_units_unsigned_design']};assert unitp==n.primary_paths(s,'base')
 for u in x['source_units_unsigned_design']:
  assert u['quote']==n.positive_string(s,u['pointer'],realization_id='base')
  for ref in u['fact_refs']:
   f=next(f for f in fs if f['id']==ref)
   if u['disposition']=='semantic':assert f['pointer']==u['pointer'] and f['quote'] in u['quote']
   elif u['disposition']=='semantic_reference':
    assert f['pointer']!=u['pointer'];assert any(v['disposition']=='semantic' and v['pointer']==f['pointer'] and ref in v['fact_refs'] for v in x['source_units_unsigned_design'])
 es=[f for f in fs if f['mode']=='effect'];effects=x['effect_sets_unsigned_design']['base'];assert {tuple(f[k] for k in ['dimension','target','property']) for f in es}=={tuple(f[k] for k in ['dimension','target','property']) for f in effects['properties']}
 groups={}
 for f in es:
  key=tuple(f[k] for k in ['realization_id','dimension','target','property']);v=(h(f['value']),f['operation'],tuple(f['receivers']));assert key not in groups or groups[key]==v;groups[key]=v
 results.append({'ordinal':x['ordinal'],'source_after_sha256':h(s),'base_only':True,'facts':len(fs),'P':sum(f['mode']=='prerequisite' for f in fs),'E':len(es),'PR':0,'units':len(x['source_units_unsigned_design']),'whole_positive_field_count':len(unitp),'ordinary_units':sum(u['disposition']=='semantic' for u in x['source_units_unsigned_design']),'semantic_reference_units':sum(u['disposition']=='semantic_reference' for u in x['source_units_unsigned_design']),'source_guard_count':len(x['guard_rules_exact_source']),'canonical_effect_conflicts':0,'shape_preflight':'pass'})
c.validate(proposed)
out={'schema':'manual149-proposal-shape-preflight/v1','task':'/root/review_08250_09250','model':'gpt-6.1-sol','reasoning_effort':'high','proposal':str(P),'proposal_raw_sha256':hashlib.sha256(P.read_bytes()).hexdigest(),'source_input':j['source_input'],'module_pins':pins,'results':results,'full_proposed_corpus_container_shape':'pass18250_only_in_memory','network':'sandbox deny network; provider keys unset','formal_input':False,'full_native_validate':'not_run_no_root_selected_INPUT','compact_validate':'not_run','admission':'not_run','source_semantic_approval':0,'proofs_created':0,'operating_qualification':0,'source_writes':0,'failure_history':[{'stage':'initial shape runner','error':'AttributeError: realization_ids absent in pinned realization module','resolution':'Use actual frozen rr.ids API; no source or production mutation.'},{'stage':'author-proposal01 before JSON output','error':'invalid property ownership/effect: source properties allowed only dimension/target/property','resolution':'Source effect triples separated from explicit native E fact operation/receivers; no schema or production code changed.'}],'limits':'Literal hash, pointer, full-field inventory, one-hop canonical support, typed fact/owner/effect shape and corpus structure checks only. Manual entailment and root source selection remain independent. No source-qualified/selfhash claim.'}
p=W/'native-08250-close149-preflight-01.json';assert not p.exists();p.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(str(p),hashlib.sha256(p.read_bytes()).hexdigest());print(json.dumps(results,ensure_ascii=False,indent=2))
