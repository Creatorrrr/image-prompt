"""Mechanical freeze of actually authored/read/checked source08, exact verifier."""
import sys,importlib.abc
class DenyModels(importlib.abc.MetaPathFinder):
 def find_spec(self,fullname,path=None,target=None):
  if fullname.split('.')[0]in {'photo_local_embedding','torch','transformers','sentence_transformers','tensorflow','jax','mlx','openai','google','anthropic'}:
   raise AssertionError('model/provider import forbidden: '+fullname)
sys.meta_path.insert(0,DenyModels())
from common_v1 import *
import photo_embedding_provider as provider
blocked=[]
def deny_model(*a,**k):blocked.append('embedding');raise AssertionError('embedding forbidden')
provider.embed=deny_model;provider.embed_many=deny_model
from after_state_v1 import after_core,evidence
# Every decision already has literal manual authoring and actual experiment output.
positive=load('POSITIVE-CHECKS-v1.json');negative=load('NEGATIVE-CHECKS-v2.json');guards=load('FRESH-GUARD-CHECKS-v3.json');aliases=load('ALIAS-LOCK-CHECKS-v1.json')
assert negative['count']==125 and negative['all_rejected'];assert all(x['rejected']for x in guards['checks']) and len(guards['checks'])==4
assert all(x['rejected']for x in aliases['checks']) and len(aliases['checks'])==3
assert all(x.get('consumer',True)and x.get('admission',{}).get('allowed',True)and not x.get('failures',[])for x in positive['checks'])
draft=load('LITERAL-DRAFT-v1.json');assert draft['batch']==batch and draft['note']==note
assert proof['permission_envelopes']['realizations']['base']['canonical_effect_refs']==['macroApp','coverageApp','exchangeApp']
assert {f['id']for f in facts if f['mode']=='effect'}=={'macroApp','coverageApp','exchangeApp'}
core,inv,cap,authority=frozen_inputs();es=entries(core)
context=n._resolve_selected_native_contracts([es[0]],core);assignments=context['view']['effect_assignments']
actual={(x['dimension'],x['target'],x['property'],x['value']['value'],x['operation'],tuple(x['receivers']))for x in assignments}
expected={('action','X','action.interaction.exchange','physical_handoff_in_progress','set_value',('H1','H2','H3')),
 ('framing','I','shot.scale','macro','set_value',('H1','H2','H3','R1','R2','U','V','X')),
 ('framing','I','framing.coverage','hands_only_participant_anatomy','set_value',('H1','H2','H3','R1','R2','U','V','X'))}
assert actual==expected and len(assignments)==3 and len(context['view']['permission_scope']['literal_properties'])==22
plan=pe.freeze_permission_plan(authority,core,[es[0]],inventory=cap,assessment=load('MANUAL-IMPACT-ASSESSMENT-v1.json'),contracts=contracts(),reviewer='/root/review_11870_12250 final exact controlled proof check')
result=after_core(core);typed=pe.freeze_after_state(plan,result,expected_after_sha256=c.digest(result),evidence=evidence(plan),reviewer='/root/review_11870_12250 final exact independent typed result check')
with pe.trusted_permission_session(authority,plan,after_state=typed):
 for e in es:assert n.admission(e,core)['allowed']and eligible(e,core)and n.audit_final_scalar_preservation([e],core)['receipts']
for name,val in [('BATCH.json',batch),('NOTE.json',note)]:save(name,val)
# The research verifier imports direct_review then resets skill sys.path. The
# actual native engine was loaded from the exact frozen generation beforehand.
sys.path.insert(0,str(R));import native_reviews as nr
sys.path[:]=[p for p in sys.path if p not in {str(Path.cwd()/'skills/photo-prompt-image-generator/scripts'),str(Path.cwd()/'skills/photo-prompt-image-generator/precore')}]
sys.path[:0]=[str(G/'scripts'),str(G/'precore')]
assert Path(nr.native.__file__).resolve().is_relative_to(G)
verified=nr.verify_batch(str(D/'ASSIGNMENT.json'),str(O/'BATCH.json'),str(O/'NOTE.json'))
assert verified['shape_valid']and verified['actual_read_count']==1 and verified['statuses']['approved']==1 and not verified['root_accepted']
print(json.dumps(save('VERIFICATION-v1.json',verified)))
enginepins=modules();assert not blocked
mods=[m for m in sys.modules if m.split('.')[0]in {'photo_local_embedding','torch','transformers','sentence_transformers','tensorflow','jax','mlx','openai','google','anthropic'}];assert not mods
out={'schema':'photo-source1299-frozen-engine-proof-verification/v1','frozen_generation':str(G),'module_paths_sha256':enginepins,
 'research_helper_pins':{str(Path(m.__file__)):hashlib.sha256(Path(m.__file__).read_bytes()).hexdigest()for m in [nr,nr.dr]},
 'whole_source_direct_read_count':1,'prepared_count':1,'actual_selected_canonical_E_count':3,'actual_original_target_Rx_permission_triples':22,
 'manual_E_anchor_decisions':18,'manual_within_source_pairs':3,'engine_cross_source_joint_pairs':0,
 'positive_scenarios':len(positive['checks']),'negative_cases':125,'additional_fresh_guard_denials':4,'additional_alias_primitive_denials':3,
 'fresh_guard_v2_valid_ancestor_disjoint_positive_controls':2,
 'guarded_final_source_scope_assertions_and_fullcompact_admission_consumer_finalPR':True,
 'model_imports_loaded':mods,'blocked_embedding_attempts':blocked,'all_engine_code_under_frozen_generation':True,
 'worker_status':'approved','root_acceptance':0,'operating':0,'real_user_or_pixel':False,
 'boundary':'Worker approves this freshly read native source proof only. Root semantic acceptance remains0. Exact synthetic finite request/typed result and manual inventory/impact are trusted reviewed inputs, not observed user or pixels. Source unchanged from exact root input. No production code/source/operating runtime/Git/model/network changes.'}
print(json.dumps(save('ENGINE-CHECKS-v1.json',out)))
print(json.dumps({'BATCH':c.digest(batch),'NOTE':c.digest(note),'verification':c.digest(verified),'status':verified['statuses'],'proof':c.digest(proof)}))
