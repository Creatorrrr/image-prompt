# 재사용 분류 체크포인트

범위는 최종149개 역할과 source28 전체18,250 CID다. 이미 루트 수용된123개는 그대로 보존하며 이번 분류에서 제외한다. 나머지18,127개를 각 담당자의 ASSIGNMENT에 따라 중복 없이 분류한다. 준비 도구는 기존 compiled/원문 packet/작성자 판정 추적과 기계적 비교만 수행한다. 입력의 `new_semantic_classification: null`은 판정이 아니다. 기존139 승인18,231개와 native 초안9,685개도149 최종 승인이 아니다.

## 우선순위와 읽기 범위

새 원문 대량 재독, 새 소수 native 배치, proof 서명, source 수정, 엔진·캐시·검토 플랫폼 확장은 시작하지 않는다. 기존 직접 독해·판정·native 초안·역할 경계·재사용 분류 기록을 먼저 찾는다. 기존 동일 원문 독해는 재사용할 수 있으며 새 독해 수로 세지 않는다. 정말 필요한 의미 판단만 바뀐 부분/관련 역할 명세 범위에서 수행한다. 부족한 근거는 아래 부분/전체 분류의 구체적 미완결 사유로 기록하여 분류를 닫는다. 후보 제외, 진단 전용 변경, 자동 승인으로 해소하지 않는다.

`ROLE-CHANGES.json`의 새 명세와 바뀐 명세를 읽는다. 선택했던 role의 hash만 비교하지 않는다. 선택하지 않았던 새 역할·바뀐 이웃 역할의 적합성/누락 가능성도 기존 의미·조건·효과·소유자·분기·필수 참조 근거와 비교한다. 반대로 전체 catalog/snapshot/runtime hash만 달라졌다는 이유로 전체 재독을 요구하지 않는다. `ORIGINAL-INDEX.jsonl.gz`는 기계적 비교 보조이며 읽음/의미 판단을 새로 부여하지 않는다.

## 세 분류

- `reuse`: 현재 전체 의미·조건·효과/소유자·실현 분기·필수 참조와 관련 역할 의미의 기존 직접 근거를 재사용할 수 있고, 최종149의 추가/변경/미선택 역할 영향도 직접 판정되어 추가 원문 의미 재검토가 필요 없다. native 증거 작성·실행 검증·루트 수용만 남아도 해당 세부 상태를 명시한다. 단지 옛 본문을 읽었다는 기록만 있고149 누락/소유자 의미가 미판정이면 이 분류가 아니다.
- `partial`: 기존 전체 독해 중 재사용할 부분은 신뢰할 수 있으나, 바뀐 필드·역할/이웃 경계·조건·소유자·효과/모드·분기·참조 또는 기존 미판정 쟁점을 제한된 범위에서 직접 확인해야 한다. 어떤 근거를 재사용하며 정확히 무엇을 다시 볼지 기록한다. 현149 영향 검토 자료가 부족한 것도 그 범위를 명시하여 이 분류로 닫는다.
- `full`: 기존 전체 의미나 필수 참조 독해의 신뢰를 확보할 수 없거나 의미 전체에 걸친 모순 때문에 전체 원문과 필수 참조를 다시 읽어야 한다. 단순 missing native proof/새 global hash는 이유가 아니다. 정확한 신뢰 공백을 적는다.

정보가 부족한 CID를 미분류로 남기지 않는다. 부족한 범위가 한정되면 partial, 전체 독해/필수 참조 신뢰가 없으면 full이다. 이는 분류 완료이며 후보 자체의 의미 검토 완료/승인이 아니다. 반복된 공통 사유는 명시적 ID 목록을 가진 수동 판단 그룹으로 묶을 수 있다. 태그·단어·hash 규칙으로 의미를 추정해 자동 판정하거나 읽지 않은 목록에 일괄 reuse를 부여하지 않는다.

## 출력

각 담당자는 이 디렉터리의 `<task>.CLASSIFICATION.json`과 필요하면 동명 작은 노트만 작성한다. 다른 담당자의 파일·source·proof·CURRENT·계획·Git·운영·모델은 수정하지 않는다. Gemini/API/CLI 모델 호출과 네트워크는 금지다. 실제 코드는 고정 Gfe5b593c에서 읽기 전용으로만 사용한다.

최상위 필드: `schema`=`photo-codex-per-cid-reuse-classification/v1`, `task_name`, `model`=`gpt-6.1-sol`, `reasoning_effort`=`high`, `assignment_sha256`(canonical), `source_sha256`, `catalog_sha256`, `records`, `summary`, `reading_boundary`, `new_native_approvals`=0, `operating_changes`=0, `Gemini_calls`=0.

각 record의 필수 필드:

- `candidate_id`, `ordinal`, `classification`(reuse/partial/full), `subtype`.
- `comparison_ordinal`: ORIGINAL-INDEX의 같은 ordinal. 이 파일에 기존 compiled/packet/원문/조건/효과/분기/참조/ownbinding 정확 hash가 결합되어 있다.
- `existing_evidence`: 사용한 기존 직접 판정/독해/초안/분류 artifact의 실제 경로와 CID/item/pointer 등 위치. 기계 index의 original compiled locator를 재사용 근거로 직접 참조할 수 있다. 추가 native/149 분류 근거를 쓴다면 정확한 artifact와 해당 CID 위치를 적는다.
- `reusable_scope`: 신뢰할 수 있어 다시 읽지 않을 기존 범위. reuse에는 실제 의미/149 역할 근거를 포함하고, partial/full에서는 검증된 부분만 적는다.
- `review_again`: 직접 다시 확인할 구체적 field/role/owner/E/RID/참조 목록. reuse에는 빈 목록과 남은 native 작업을 별도 명시한다.
- `role_impact`: 새 역할/변경 역할/이웃·미선택 역할을 어떤 직접 근거로 고려했으며, 왜 무영향/부분 영향/미해결인지. 전역 ROLE-CHANGES pin과 실제 해당 CID 판단을 함께 사용한다.
- `reason_codes`, `rationale`, `native_work_remaining`(증거 작성·실행·루트 통합 등의 목록), `final_native_approval_valid`=false. 이미 수용된123개가 발견되면 새로 포함하지 말고 루트에 알린다.

`summary`에는 고유 CID 전체/각 세 분류 수/중복0·누락0·미분류0, reuse 중 최종 승인 유효 수와 독해·근거 재사용/native 작업 잔여 수, 실제 의미 재검토 필요 수(partial+full), 주요 사유별 고유 수를 기록한다. 독해 재사용 수를 최종 승인 수로 표시하지 않는다. `reading_boundary`는 기존 읽음 재사용/이번에 새로 읽은 명세·한정된 의미 근거/새 whole-source 독해 수를 정확히 구별한다.
