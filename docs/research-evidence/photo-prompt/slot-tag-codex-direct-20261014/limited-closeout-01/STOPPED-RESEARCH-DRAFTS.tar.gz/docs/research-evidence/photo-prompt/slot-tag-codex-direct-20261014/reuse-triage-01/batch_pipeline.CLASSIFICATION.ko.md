# batch_pipeline 재사용 분류

source28/final149 고정, 배정1230 CID를 reuse41 / partial1189 / full0으로 분류했다. 겹침·누락·미분류0, 기존완료123 포함0, 새 native 승인·운영 변경0이다.

reuse는 읽고 대조한 기존 직접 의미요약·사실·배제 경계가 장르 또는 이미지 출력형식으로 완결되고, final149의 추가10·변경35·미선택 이웃 역할도 직접 무영향으로 닫은 명시적41 ID만이다. 장르31개는 실제 인물/물체/촬영 이력/장소/행사/물리 속성을 만들지 않는 기존 경계를 유지한다. 출력형식10개는 실제 물리 물체 구조·물성·무늬·입자·광학 장치가 아닌 이미지 비율/레이아웃만 유지한다. native 증거 작성·정확한 footprint/조건/표시 관계 검증·루트 수용은 여전히 필요하며, 기존 draft의 source/binding 수정안은 자동 수용하지 않는다.

partial에는1000개 기존 native checkpoint의494 draft/506 구체 pending을 활용했다. 특히 출신의 E↔P·기록 카메라와 장면 소품·빛의 기준축/수광자·whole-image grading과 실제 고유색·미반영 EN/KO 문구·기존 개별 미해결 질문과 final149 누락 역할을 한정해 다시 확인한다.259/807/924/1236은 source28의 새 소품 생성·presence/type/count3E와 기존 인간/소유자 조건의 변경 범위를 별도로 적었다.6개 옛 diagnostic은 frozen/접근 world/서사 crack/먼지-흠집/소독약 공기/divine glitch 각각의 제한된 의미 대안을 다시 확인하며, 진단 플래그나 빈 E를 뜻 없음의 근거로 삼지 않는다.

원본1230개 complete-source/packet/작성자 trace와 참조 일치는 신뢰할 수 있으므로 단지 전역 catalog/runtime hash나 native proof가 없다는 이유로 full 재독을 요구하지 않는다. partial1189는 기존 전체 독해를 버리는 수가 아니라, 구체적 의미·역할 경계 재확인이 남은 수다. 각 record에는 원compiled/packet의 정확한 위치, 가능한 경우 exact 선택된 native checkpoint row, 원래 pending 질문·source_edits 필드와 현재149 role agenda를 결합했다. role 인접 그래프는 재검토 목록을 찾는 보조이며 의미 적합성이나 미선택 역할의 부재를 자동 판정하지 않는다.

새 source28 whole-record/필수 참조 재독0. 현재 바뀐4개 App/effects 필드만 한정해서 직접 보았고, 기존 compiled summary/facts와 rejected boundaries를 별도로 검토한 정확한 ordinal 목록·수는 JSON reading_boundary에 있다. 예시 native draft847 안에서 옛 source_before 전체가 우연히 함께 보인1건은 명시했으며 새 corpus 독해 실적으로 더하지 않는다. 이전1000개 읽음/494 draft/506 pending은 기존 기록의 재사용이며 이번 새 읽음·최종149 승인 수가 아니다.

근거가 부족한 나머지를 reuse로 승인하지 않았고, 누락 상태로 남기지도 않았다. output은 이 CLASSIFICATION.json과 이 노트뿐이다. source/proof/CURRENT/engine/build/embedding/query/receipt/Git/Gemini/network 실행·수정0이다.
