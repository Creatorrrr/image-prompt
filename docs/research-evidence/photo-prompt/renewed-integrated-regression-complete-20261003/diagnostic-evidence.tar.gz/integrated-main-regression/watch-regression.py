import json,pathlib,time,datetime
p=pathlib.Path(__file__).resolve().parent
old=json.loads((p.parent/'current-full-regression/historical-comparison.json').read_text())
known=set(old['retained_failure_labels'])
seen=set();report=p/'watch-events.jsonl';last_progress=0
while True:
    path=p/'module-suite-progress.json'
    try:m=json.loads(path.read_text())
    except (FileNotFoundError,json.JSONDecodeError):time.sleep(5);continue
    for r in m['results']:
        if r['test_file'] in seen:continue
        seen.add(r['test_file'])
        unexpected=[x for x in r['failure_error_labels'] if x not in known]
        if unexpected or (r['exit_code'] and not r['failure_error_labels']) or r['reported_tests'] is None:
            event={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'event':'unexpected_result','result':r}
            with report.open('a') as f:f.write(json.dumps(event)+'\n')
            print(json.dumps(event),flush=True)
            raise SystemExit(42)
        if r['failure_error_labels']:
            event={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'event':'historical_failure_labels_only','module':r['test_file'],'labels':r['failure_error_labels']}
            with report.open('a') as f:f.write(json.dumps(event)+'\n')
            print(json.dumps(event),flush=True)
    if time.monotonic()-last_progress>300:
        event={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'event':'progress','completed_modules':len(m['results']),'discovered_modules':len(m['test_files']),'completed_tests':sum(r['reported_tests'] or 0 for r in m['results'])}
        with report.open('a') as f:f.write(json.dumps(event)+'\n')
        print(json.dumps(event),flush=True);last_progress=time.monotonic()
    if (p/'module-suite-results.json').exists():
        print('Regression complete; all observed failures historical',flush=True);raise SystemExit(0)
    if (p/'launcher.exit').exists():
        print('Launcher ended without module-suite-results.json',flush=True);raise SystemExit(43)
    time.sleep(5)
