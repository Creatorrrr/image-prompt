"""Finalize the complete frozen regression without changing repository files."""
import collections, datetime, hashlib, json, pathlib, re, subprocess
P=pathlib.Path(__file__).resolve().parent
ROOT=P/'snapshot'
PIN='7d1bb2a5104198804512b2b93082f9a100ee7238'
PREV=P.parent/'current-full-regression'

def sha(data): return hashlib.sha256(data).hexdigest()
def write(name,value): (P/name).write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n')
def normalize(text):
    text=text.replace('<WORKSPACE>','<WORKSPACE>')
    text=text.replace('<PYTHON_RUNTIME>','<PYTHON_RUNTIME>')
    text=re.sub(r'/Users/[^/\s]+/Downloads/[^\n\"\']+', '<EXTERNAL_REFERENCE_DOWNLOAD>', text)
    return text

def parse_log(text):
    ids=re.findall(r'^test\S+ \(([^)]+)\) \.\.\.',text,re.M)
    terminals=list(re.finditer(r'^Ran (\d+) tests? in ([0-9.]+)s\s*\n\s*\n(OK(?: \([^\n]*\))?|FAILED \([^\n]+\))\s*$',text,re.M))
    if len(terminals)!=1:
        raise ValueError(f'Expected one unittest aggregate, observed {len(terminals)}')
    terminal=terminals[0]
    counts={'tests':int(terminal[1]),'failures':0,'errors':0,'skipped':0,'expected_failures':0,'unexpected_successes':0}
    for name,label in [('failures','failures'),('errors','errors'),('skipped','skipped'),('expected_failures','expected failures'),('unexpected_successes','unexpected successes')]:
        found=re.search(re.escape(label)+r'=(\d+)',terminal[3])
        if found:counts[name]=int(found[1])
    labels=re.findall(r'^(FAIL|ERROR): (.+)$',text,re.M)
    return ids,counts,labels

m=json.loads((P/'module-suite-results.json').read_text())
assert m['commit']==PIN
expected=json.loads((P/'discovered-test-ids.json').read_text())
files=m['test_files']
assert len(set(files))==len(files)
assert collections.Counter(x['test_file'] for x in m['results'])==collections.Counter(files)
executed=[]; totals=collections.Counter(); entries=[]; current_labels=[]
for result in m['results']:
    log=P/result['log']; data=log.read_bytes(); text=data.decode()
    assert sha(data)==result['log_sha256'], result['log']
    assert sha((ROOT/result['test_file']).read_bytes())==result['sha256'], result['test_file']
    ids,counts,labels=parse_log(text)
    expected_module=[x for x in expected if x.split('.')[0]==pathlib.Path(result['test_file']).stem]
    counts_equal=collections.Counter(ids)==collections.Counter(expected_module)
    exit_consistent=result['exit_code']==(1 if counts['failures'] or counts['errors'] or counts['unexpected_successes'] else 0)
    entry={**result,'totals':counts,'discovered_id_count':len(expected_module),'executed_id_count':len(ids),'id_multiset_matches':counts_equal,'exit_consistent':exit_consistent,'missing_ids':list((collections.Counter(expected_module)-collections.Counter(ids)).elements()),'unexpected_ids':list((collections.Counter(ids)-collections.Counter(expected_module)).elements()),'selected':True}
    entries.append(entry); executed.extend(ids); totals.update(counts)
    current_labels.extend({'kind':kind,'label':label,'log':result['log']} for kind,label in labels)
    assert counts_equal and counts['tests']==len(ids),entry
    assert exit_consistent,entry
write('module-reconciliation.json',entries)
write('executed-test-ids.json',executed)
missing=list((collections.Counter(expected)-collections.Counter(executed)).elements())
extra=list((collections.Counter(executed)-collections.Counter(expected)).elements())
assert not missing and not extra
assert len(executed)==totals['tests']
# Preserve the prior selected failure logs as local comparison evidence.
prior_summary=json.loads((PREV/'summary.json').read_text())
prior_evidence=P/'prior-selected-failure-logs';prior_evidence.mkdir(exist_ok=True)
prior_labels=[]; prior_manifest=[]
for relative in prior_summary['selected_logs']:
    source=PREV/relative; raw=source.read_bytes(); text=raw.decode()
    _,_,labels=parse_log(text)
    if not labels: continue
    target=prior_evidence/source.name; target.write_bytes(raw)
    prior_manifest.append({'original_relative_path':relative,'copied_to':str(target.relative_to(P)),'raw_sha256':sha(raw)})
    prior_labels.extend({'kind':kind,'label':label,'log':str(target.relative_to(P))} for kind,label in labels)
write('prior-evidence-manifest.json',{'commit':prior_summary['commit'],'files':prior_manifest})
old=collections.Counter((x['kind'],x['label']) for x in prior_labels)
new=collections.Counter((x['kind'],x['label']) for x in current_labels)
comparison={'prior_commit':prior_summary['commit'],'current_commit':PIN,'retained_failure_labels':[{'kind':kind,'label':label} for kind,label in (old&new).elements()],'new_failure_labels':[{'kind':kind,'label':label} for kind,label in (new-old).elements()],'resolved_old_labels':[{'kind':kind,'label':label} for kind,label in (old-new).elements()],'current_failures':current_labels,'prior_failures':prior_labels}
# Compare entire failure trace sections after replacing each frozen root and timing footer.
def failure_traces(text):
    marker='======================================================================\n'
    if marker not in text:return ''
    trace=text.split(marker,1)[1]
    trace=re.sub(r'\n----------------------------------------------------------------------\nRan \d+ tests? in [0-9.]+s\n.*','',trace,flags=re.S)
    for base in (str(ROOT),str(PREV/'snapshot')):trace=trace.replace(base,'<SNAPSHOT>')
    return trace
comparison['trace_comparisons']=[]
for x in prior_manifest:
    name=pathlib.Path(x['copied_to']).name
    current=P/'module-logs'/name
    if current.exists():
        before=failure_traces((P/x['copied_to']).read_text()); after=failure_traces(current.read_text())
        comparison['trace_comparisons'].append({'module':name,'prior_trace_sha256':sha(before.encode()),'current_trace_sha256':sha(after.encode()),'identical_after_snapshot_root_normalization':before==after})
write('historical-comparison.json',comparison)
assert m['tracked_diff_exit_code']==0
venv=ROOT/'.venv'; cleanup={'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'action':'Remove only the temporary snapshot .venv symlink, leaving its existing target unchanged','symlink_target':str(venv.resolve()) if venv.is_symlink() else None}
if venv.is_symlink():venv.unlink();cleanup['removed']=True
else:cleanup['removed']=False
cleanup['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();write('cleanup.json',cleanup)
status=subprocess.check_output(['git','status','--porcelain=v1'],cwd=ROOT,text=True)
(P/'snapshot-status-final.txt').write_text(status)
assert not status,status
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip();assert head==PIN
summary={'commit':PIN,'strategy':'Complete sequential module-isolated regression; each original discovered module ran in one fresh subprocess. No monolithic attempt and no test reruns.','totals':dict(totals),'module_count':len(entries),'passed_modules':sum(x['exit_code']==0 for x in entries),'failed_modules':sum(x['exit_code']!=0 for x in entries),'discovered_id_count':len(expected),'executed_id_count':len(executed),'exact_id_multiset_match':not missing and not extra,'missing_ids':missing,'unexpected_ids':extra,'duplicate_ids':[{ 'id':k,'count':v} for k,v in collections.Counter(executed).items() if v>1],'selected_logs':[x['log'] for x in entries],'module_process_wall_time_sum_seconds':sum(x['seconds'] for x in entries),'started_utc':m['started_utc'],'finished_utc':m['finished_utc'],'new_failure_label_count':len(comparison['new_failure_labels']),'retained_failure_label_count':len(comparison['retained_failure_labels']),'all_historical_failure_traces_identical':all(x['identical_after_snapshot_root_normalization'] for x in comparison['trace_comparisons']),'discovery_loader_errors':len(json.loads((P/'discovery-details.json').read_text())['loader_errors']),'test_environment_failures':[],'test_recovery_attempts':[],'snapshot_final_status_clean':not status,'snapshot_head_unchanged':head==PIN}
write('summary.json',summary)
known=not comparison['new_failure_labels'] and summary['all_historical_failure_traces_identical']
report=f'''# Integrated DATA snapshot full-regression evidence

Pinned commit: {PIN}. Later main/upstream changes are outside this frozen run.

## Terminal result

All {summary['module_count']} discovered modules completed in fresh sequential subprocesses. Aggregate: **{totals['tests']} tests, {totals['failures']} assertion/subtest failures, {totals['errors']} error, {totals['skipped']} skips**. {summary['passed_modules']} modules passed; {summary['failed_modules']} modules retained failure/error results. Exact discovered-ID multiset reconciliation passed: {len(expected)} discovered and {len(executed)} executed IDs, with no missing, unexpected, or duplicate IDs. No module failed to import or execute, and no environment-repair test rerun was needed.

Historical classification: {'all 11 failure/error labels and their full trace sections match the prior selected 3c3b3a64 results after snapshot-root normalization; there are no unexpected failing identities or changed failure traces' if known else 'see historical-comparison.json; new or changed failures require review'}.

This is complete module-isolated coverage, not a monolithic unittest pass. The suite is still red at the historical missing assets. Nothing was skipped, synthesized, or rewritten to obtain this outcome.

## Retained missing-asset failures

- Korean emotional: three subtest failures on reference.is_file(), absent external JPEG
- Makeup reference: one failure (zero frozen cores instead of five), one FileNotFoundError for source_observation.json
- Poverty: three subtest failures on result_path.is_file(), absent result PNGs
- Rare photo: three subtest failures on artifact.is_file(), absent request-envelope JSONs

Those are historical missing-asset failures, not new environment/setup errors. Prior baseline reproduction scope remains exactly as documented in current-full-regression/REPORT.md: Korean/makeup/rare have prior original-baseline reproductions; poverty matches the historical traceback without a new original-baseline reproduction.

## Coverage and method

Fresh discovery found {len(expected)} IDs across {len(entries)} modules, rather than assuming the earlier 1221/136 totals. Compared with 3c3b3a64, this pin adds 20 IDs in three modules: acting-expression (12), liminal maintained-alternative (4), nonhuman source-alternatives (4). No prior discovered IDs were removed. discovery-delta.json contains the exact additions. The three new modules all completed successfully.

The detached worktree was created at the exact pin. Its .venv was temporarily linked to the already-existing main environment before discovery or testing so test-internal .venv/bin/python commands worked. No packages were installed. Provider/auth API-key, token, secret, credential, password, and private-key environment names were removed from test subprocesses, with four primary provider key names explicitly absent; bytecode was disabled. No provider calls were performed. Every exact subprocess command, cwd, start/end timestamp, duration, exit, test-file SHA-256, and log SHA-256 is in module-suite-results.json. Every raw test log is retained under module-logs/.

Start: {m['started_utc']}. Finish: {m['finished_utc']}. Sum of module subprocess wall times: {summary['module_process_wall_time_sum_seconds']:.3f} seconds. Discovery has its own command, timing, exit and log. There were no test recovery attempts. diagnostic-attempts.json preserves a separate path-resolution error in an evidence-comparison utility; it never affected test execution.

No source, tests, assertions, goldens, or missing assets were edited or fabricated. After completion, only the temporary .venv symlink was removed. The snapshot HEAD remains {PIN}; tracked/untracked status is clean. No commits, pushes, or publication were performed.

## Evidence and export

- summary.json: aggregate and exact coverage result
- module-reconciliation.json: selected module runs, per-module counts and exact-ID comparison
- discovered-test-ids.json and executed-test-ids.json: full multisets
- module-suite-results.json and module-logs/: every executed test command and result
- historical-comparison.json and prior-selected-failure-logs/: direct historical identity/trace comparison
- discovery-delta.json: all 20 additional IDs
- setup.log, run.sh, run-module-suite.py, launcher files, cleanup.json: reproduction and lifecycle
- export/: sanitized copies with workspace/runtime and personal Downloads reference paths replaced, preserving outcomes
- export-manifest.json: paired SHA-256 of raw and sanitized files

Raw evidence is local. Export normalization changes paths only, and every export is verified against the normalization function. No exported file grants evidence beyond this pin.
'''
(P/'REPORT.md').write_text(report)
export=P/'export';export.mkdir(exist_ok=True)
files=[x for x in P.iterdir() if x.is_file() and x.name not in ('export-manifest.json','finalize.log','export-verification.json') and not x.name.endswith('.tmp')]
files+=list((P/'module-logs').glob('*.log'))+list(prior_evidence.glob('*.log'))
manifest=[]
for source in sorted(files):
    raw=source.read_bytes(); clean=normalize(raw.decode()).encode(); target=export/source.relative_to(P)
    target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(clean)
    assert target.read_bytes()==normalize(source.read_text()).encode()
    manifest.append({'file':str(source.relative_to(P)),'raw_bytes':len(raw),'export_bytes':len(clean),'raw_sha256':sha(raw),'export_sha256':sha(clean)})
write('export-manifest.json',manifest);(export/'export-manifest.json').write_bytes((P/'export-manifest.json').read_bytes())
checks={'file_count':len(manifest),'all_raw_hashes_match':all(sha((P/x['file']).read_bytes())==x['raw_sha256'] for x in manifest),'all_export_hashes_match':all(sha((export/x['file']).read_bytes())==x['export_sha256'] for x in manifest),'all_exports_exact_path_normalizations':all((export/x['file']).read_text()==normalize((P/x['file']).read_text()) for x in manifest),'workspace_path_residues':[x['file'] for x in manifest if '<WORKSPACE>' in (export/x['file']).read_text()],'runtime_path_residues':[x['file'] for x in manifest if '<PYTHON_RUNTIME>' in (export/x['file']).read_text()],'personal_download_path_residues':[x['file'] for x in manifest if re.search(r'/Users/[^/\s]+/Downloads/',(export/x['file']).read_text())]}
write('export-verification.json',checks);(export/'export-verification.json').write_bytes((P/'export-verification.json').read_bytes())
assert all(checks[k] for k in ('all_raw_hashes_match','all_export_hashes_match','all_exports_exact_path_normalizations'))
assert not checks['workspace_path_residues'] and not checks['runtime_path_residues'] and not checks['personal_download_path_residues']
print(json.dumps({k:v for k,v in summary.items() if k!='selected_logs'},indent=2))
print(json.dumps(checks,indent=2))
