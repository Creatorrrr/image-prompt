"""Export completed evidence with path-only normalization and paired hashes."""
import hashlib,json,pathlib,re,tarfile
P=pathlib.Path(__file__).resolve().parent
EXPORT=P/'export'
def sha(raw):return hashlib.sha256(raw).hexdigest()
def normalize(text):
    text=text.replace('<WORKSPACE>','<WORKSPACE>')
    text=text.replace('<PYTHON_RUNTIME>','<PYTHON_RUNTIME>')
    return re.sub(r'/Users/[^/\s]+/Downloads/[^\n\"\']+','<EXTERNAL_REFERENCE_DOWNLOAD>',text)
excluded={'export-manifest.json','export-verification.json','export-package.json','export-evidence.log'}
files=[x for x in P.iterdir() if x.is_file() and x.name not in excluded and not x.name.endswith(('.tar.gz','.tmp'))]
files+=list((P/'module-logs').glob('*.log'))+list((P/'prior-selected-failure-logs').glob('*.log'))
manifest=[]
for source in sorted(files):
    raw=source.read_bytes();clean=normalize(raw.decode()).encode(); target=EXPORT/source.relative_to(P)
    target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(clean)
    manifest.append({'file':str(source.relative_to(P)),'raw_bytes':len(raw),'export_bytes':len(clean),'raw_sha256':sha(raw),'export_sha256':sha(clean)})
data=(json.dumps(manifest,indent=2)+'\n').encode();(P/'export-manifest.json').write_bytes(data);(EXPORT/'export-manifest.json').write_bytes(data)
raw_hashes=all(sha((P/x['file']).read_bytes())==x['raw_sha256'] for x in manifest)
export_hashes=all(sha((EXPORT/x['file']).read_bytes())==x['export_sha256'] for x in manifest)
normalizations=all((EXPORT/x['file']).read_bytes()==normalize((P/x['file']).read_bytes().decode()).encode() for x in manifest)
residues=[]
for x in manifest:
    text=(EXPORT/x['file']).read_bytes().decode()
    if '<WORKSPACE>' in text or '<PYTHON_RUNTIME>' in text or re.search(r'/Users/[^/\s]+/Downloads/',text):residues.append(x['file'])
# Exact outcome-bearing lines remain byte-identical after path-only normalization.
pattern=r'^(?:test\S+ \([^\n]+|  test\S+ \([^\n]+|FAIL: [^\n]+|ERROR: [^\n]+|Ran \d+ tests? in [^\n]+|FAILED \([^\n]+\)|OK(?: \([^\n]+\))?)$'
outcome_checks=[]
for x in manifest:
    if x['file'].startswith('module-logs/'):
        raw=(P/x['file']).read_bytes().decode();export=(EXPORT/x['file']).read_bytes().decode()
        outcome_checks.append(re.findall(pattern,raw,re.M)==re.findall(pattern,export,re.M))
verification={'file_count':len(manifest),'all_raw_hashes_match':raw_hashes,'all_export_hashes_match':export_hashes,'all_exports_exact_path_normalizations':normalizations,'local_private_path_residues':residues,'test_log_outcomes_identical':all(outcome_checks),'test_logs_checked':len(outcome_checks),'snapshot_source_mutations':False,'publication_performed':False}
assert raw_hashes and export_hashes and normalizations and not residues and all(outcome_checks)
verification_bytes=(json.dumps(verification,indent=2)+'\n').encode();(P/'export-verification.json').write_bytes(verification_bytes);(EXPORT/'export-verification.json').write_bytes(verification_bytes)
archive=P/'integrated-main-regression-export.tar.gz'
with tarfile.open(archive,'w:gz') as tar:tar.add(EXPORT,arcname='integrated-main-regression')
package={'archive':archive.name,'archive_sha256':sha(archive.read_bytes()),'archive_bytes':archive.stat().st_size,'manifest_sha256':sha(data),'verification_sha256':sha(verification_bytes),'source_commit':json.loads((P/'summary.json').read_text())['commit'],'export_files':len(manifest)+2}
(P/'export-package.json').write_text(json.dumps(package,indent=2)+'\n')
print(json.dumps(verification,indent=2));print(json.dumps(package,indent=2))
