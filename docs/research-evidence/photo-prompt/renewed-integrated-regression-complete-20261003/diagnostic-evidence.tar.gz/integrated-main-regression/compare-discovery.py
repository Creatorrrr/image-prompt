import collections,json,pathlib,subprocess
p=pathlib.Path(__file__).resolve().parent; prev=p.parent/'current-full-regression'
a=json.loads((prev/'discovered-test-ids.json').read_text()); b=json.loads((p/'discovered-test-ids.json').read_text())
summary={'prior_commit':'3c3b3a649afc04a5b39abc23a0e57084ba34fec2','current_commit':(p/'commit.txt').read_text().strip(),'prior_count':len(a),'current_count':len(b),'added_ids':list((collections.Counter(b)-collections.Counter(a)).elements()),'removed_ids':list((collections.Counter(a)-collections.Counter(b)).elements())}
(p/'discovery-delta.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
cmd=['git','diff','--stat',summary['prior_commit'],summary['current_commit']]; proc=subprocess.run(cmd,cwd=p/'snapshot',text=True,capture_output=True);(p/'prior-pin-diff-stat.log').write_text('Command: '+repr(cmd)+'\n'+proc.stdout+proc.stderr+'\nExit: '+str(proc.returncode)+'\n')
