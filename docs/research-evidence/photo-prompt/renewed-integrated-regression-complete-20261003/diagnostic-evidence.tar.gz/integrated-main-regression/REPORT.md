# Integrated DATA snapshot full-regression evidence

Pinned commit: 7d1bb2a5104198804512b2b93082f9a100ee7238. Later main/upstream changes are outside this frozen run.

## Terminal result

All 139 discovered modules completed in fresh sequential subprocesses. Aggregate: **1241 tests, 10 assertion/subtest failures, 1 error, 0 skips**. 135 modules passed; 4 modules retained failure/error results. Exact discovered-ID multiset reconciliation passed: 1241 discovered and 1241 executed IDs, with no missing, unexpected, or duplicate IDs. No module failed to import or execute, and no environment-repair test rerun was needed.

Historical classification: all 11 failure/error labels and their full trace sections match the prior selected 3c3b3a64 results after snapshot-root normalization; there are no unexpected failing identities or changed failure traces.

This is complete module-isolated coverage, not a monolithic unittest pass. The suite is still red at the historical missing assets. Nothing was skipped, synthesized, or rewritten to obtain this outcome.

## Retained missing-asset failures

- Korean emotional: three subtest failures on reference.is_file(), absent external JPEG
- Makeup reference: one failure (zero frozen cores instead of five), one FileNotFoundError for source_observation.json
- Poverty: three subtest failures on result_path.is_file(), absent result PNGs
- Rare photo: three subtest failures on artifact.is_file(), absent request-envelope JSONs

Those are historical missing-asset failures, not new environment/setup errors. Prior baseline reproduction scope remains exactly as documented in current-full-regression/REPORT.md: Korean/makeup/rare have prior original-baseline reproductions; poverty matches the historical traceback without a new original-baseline reproduction.

## Coverage and method

Fresh discovery found 1241 IDs across 139 modules, rather than assuming the earlier 1221/136 totals. Compared with 3c3b3a64, this pin adds 20 IDs in three modules: acting-expression (12), liminal maintained-alternative (4), nonhuman source-alternatives (4). No prior discovered IDs were removed. discovery-delta.json contains the exact additions. The three new modules all completed successfully.

The detached worktree was created at the exact pin. Its .venv was temporarily linked to the already-existing main environment before discovery or testing so test-internal .venv/bin/python commands worked. No packages were installed. Provider/auth API-key, token, secret, credential, password, and private-key environment names were removed from test subprocesses, with four primary provider key names explicitly absent; bytecode was disabled. No provider calls were performed. Every exact subprocess command, cwd, start/end timestamp, duration, exit, test-file SHA-256, and log SHA-256 is in module-suite-results.json. Every raw test log is retained under module-logs/.

Start: 2026-10-03T04:14:23.427857+00:00. Finish: 2026-10-03T05:20:47.985947+00:00. Sum of module subprocess wall times: 3983.171 seconds. Discovery has its own command, timing, exit and log. There were no test recovery attempts. diagnostic-attempts.json preserves a path-resolution error in a comparison utility and an initial export-verifier newline-handling assertion; neither affected test execution. Both utility issues were corrected without changing any raw test result.

No source, tests, assertions, goldens, or missing assets were edited or fabricated. After completion, only the temporary .venv symlink was removed. The snapshot HEAD remains 7d1bb2a5104198804512b2b93082f9a100ee7238; tracked/untracked status is clean. No commits, pushes, or publication were performed.

## Evidence and export

- summary.json: aggregate and exact coverage result
- module-reconciliation.json: selected module runs, per-module counts and exact-ID comparison
- discovered-test-ids.json and executed-test-ids.json: full multisets
- module-suite-results.json and module-logs/: every executed test command and result
- historical-comparison.json and prior-selected-failure-logs/: direct historical identity/trace comparison
- discovery-delta.json: all 20 additional IDs
- setup.log, run.sh, run-module-suite.py, launcher files, cleanup.json: reproduction and lifecycle
- export/: sanitized copies with workspace/runtime and personal Downloads reference paths replaced, preserving outcomes
- export-manifest.json: paired SHA-256 of raw and sanitized files

Raw evidence is local. Export normalization changes paths only, and every export is verified against the normalization function. No exported file grants evidence beyond this pin.
