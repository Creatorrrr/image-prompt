from pathlib import Path
import sys,json,hashlib
P=Path(__file__).resolve().parent;D=P/'undercut-trial-v2';S=D/'after/skills/photo-prompt-image-generator';A=S/'assets';B=D/'before/skills/photo-prompt-image-generator/assets'
sys.path.insert(0,str(S/'scripts'));import prompt_generator as pg;import build_semantic_index as si;import build_visual_profile_index as vi

def forbidden(*a,**kw):raise AssertionError('Provider call forbidden in metadata-only trial')
pg.embed_texts_with_gemini=si.embed_texts_with_gemini=vi.embed_texts_with_gemini=forbidden
reg=pg.load_visual_obligation_registry(A/'photo_prompt_visual_obligations.json');oldreg=pg.load_visual_obligation_registry(B/'photo_prompt_visual_obligations.json')
vectors=vi.reusable_vectors([B/'photo_prompt_visual_profile_index.json'],reg,provider=pg.SEMANTIC_PROVIDER,model=pg.SEMANTIC_MODEL_ID,dimensions=pg.DEFAULT_SEMANTIC_DIMENSIONS)
assert len(vectors)==len(reg['profiles'])==1622
vp=pg.build_visual_profile_index_payload(reg,vectors=vectors);oldvp=pg.load_visual_profile_index(B/'photo_prompt_visual_profile_index.json',oldreg)
assert vp['entries']==oldvp['entries'];assert vp['exact_lookup']==oldvp['exact_lookup'];assert vp['bm25f']==oldvp['bm25f']
vi.write_payload(A/'photo_prompt_visual_profile_index.json',vp)
data=pg.load_json(A/'photo_prompt_tags.json');data[pg.QUALITY_LAYERS_DATA_KEY]=pg.load_quality_layers(A/pg.QUALITY_LAYERS_FILENAME)
oldsi=pg.load_semantic_index_payload(B/'photo_prompt_semantic_index.json')
payload=si.build_resumable_index_payload(data,A/'photo_prompt_semantic_index.json',D/'empty-checkpoint.json',pg.SEMANTIC_PROVIDER,pg.SEMANTIC_MODEL_ID,pg.DEFAULT_SEMANTIC_DIMENSIONS,64,0,0,0,cache_indexes=[B/'photo_prompt_semantic_index.json'])
assert payload['entries']==oldsi['entries'];assert payload['bm25f']==oldsi['bm25f'];assert len(payload['entries'])==9876
si.write_sharded_payload(A/'photo_prompt_semantic_index.json',payload,keep_stale_generations=True)
loaded=pg.load_runtime_data(A/'photo_prompt_tags.json')
report={'profile_count':1622,'semantic_entry_count':9876,'all_profile_entries_vectors_texts_bm25f_unchanged':True,'all_general_entries_vectors_texts_bm25f_unchanged':True,'exact_lookup_unchanged':True,'provider_calls':0,'registry_hash_before':oldvp['registry_sha256'],'registry_hash_after':vp['registry_sha256'],'dictionary_hash_before':oldsi['dictionary_hash'],'dictionary_hash_after':payload['dictionary_hash'],'runtime_load_after':'pass'}
(D/'index-verification.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
