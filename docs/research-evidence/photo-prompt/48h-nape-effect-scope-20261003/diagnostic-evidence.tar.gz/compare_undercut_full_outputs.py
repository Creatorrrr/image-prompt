from pathlib import Path
import json
P=Path(__file__).resolve().parent;D=P/'undercut-trial-v2'
def differences(a,b,path=''):
 out=[]
 if isinstance(a,dict) and isinstance(b,dict):
  for k in sorted(a.keys()|b.keys()):
   q=path+'/'+k
   if k not in a:out.append({'path':q,'before_missing':True,'after':b[k]})
   elif k not in b:out.append({'path':q,'before':a[k],'after_missing':True})
   else:out.extend(differences(a[k],b[k],q))
 elif isinstance(a,list) and isinstance(b,list):
  if a!=b:out.append({'path':path,'before':a,'after':b})
 elif a!=b:out.append({'path':path,'before':a,'after':b})
 return out
rows=[]
for f in sorted((D/'before-output').glob('*.pack.json')):
 b=json.loads(f.read_text())[0];a=json.loads((D/'after-output'/f.name).read_text())[0]
 row={'case':f.stem,'changes':differences(b,a),'augmentation_ids_before':[r['id']for r in b['creative_augmentation']['candidates']],'augmentation_ids_after':[r['id']for r in a['creative_augmentation']['candidates']]};rows.append(row)
(D/'complete-output-comparison.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
print([(r['case'],len(r['changes']),r['augmentation_ids_before']==r['augmentation_ids_after'])for r in rows])
