from pathlib import Path
import json,hashlib,os,subprocess,time
P=Path(__file__).resolve().parent;F=P/'undercut-effect-audit/cli-fixtures';D=P/'undercut-trial-v2';M=json.loads((F/'MANIFEST.json').read_text());E={k:v for k,v in os.environ.items()if not any(t in k.upper()for t in ['TOKEN','API_KEY','CREDENTIAL'])};results=[]
for arm in ['before','after']:
 S=D/arm/'skills/photo-prompt-image-generator';O=D/(arm+'-output');O.mkdir(exist_ok=True)
 for case in M['cases']:
  C=F/case['id']
  for n,h in case['file_sha256'].items():assert hashlib.sha256((C/n).read_bytes()).hexdigest()==h
  cmd=['python',str(S/'scripts/generate_photo_prompt.py'),'--request-envelope-json',str(C/'request-envelope.json'),'--authorial-core-json',str(C/'authorial-core.json'),'--creative-controls-json',str(C/'creative-controls.json'),'--embodiment-review-json',str(C/'embodiment-review.json'),'--seed','1003','--output-file',str(O/(case['id']+'.pack.json'))]
  t=time.monotonic();r=subprocess.run(cmd,env=E,capture_output=True,text=True,timeout=180);(O/(case['id']+'.stdout.txt')).write_text(r.stdout);(O/(case['id']+'.stderr.txt')).write_text(r.stderr)
  results.append({'arm':arm,'case':case['id'],'returncode':r.returncode,'seconds':round(time.monotonic()-t,3),'stderr':r.stderr[-1000:]});print(arm,case['id'],r.returncode,flush=True)
  (D/'cli-results.json').write_text(json.dumps(results,indent=2)+'\n')
  for n,h in case['file_sha256'].items():assert hashlib.sha256((C/n).read_bytes()).hexdigest()==h
