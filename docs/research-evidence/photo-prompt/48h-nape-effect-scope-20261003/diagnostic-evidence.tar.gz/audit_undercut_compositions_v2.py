from pathlib import Path
import sys,json,copy
P=Path(__file__).resolve().parent;D=P/'undercut-trial-v2'
ARM=sys.argv[1]
assert ARM in ['before','after']
sys.path.insert(0,str(D/ARM/'skills/photo-prompt-image-generator/scripts'))
import audit_composed_prompt as audit
def baseline_composition(pack):
    core, lock = pack["authorial_core"], pack["authorial_core"]["intent_lock"]
    review = copy.deepcopy(pack["embodiment_preflight"]["baseline_review"])
    review["provenance"] = "agent_postcomposition"
    composed = {
        "core_retrieval_sha256": pack["core_retrieval"]["canonical_sha256"], "pack_id": pack["pack_id"],
        "prompt_en": core["baseline_prompt_en"], "negative_en": pack["negative_en"],
        "chosen_candidate_ids": [], "chosen_visual_concept_ids": [], "composer": "agent",
        "embodiment_review": {"source_contract_sha256": pack["embodiment_preflight"]["canonical_sha256"], "review": review},
        "candidate_interpretations": [],
        "authorial_core_binding": {"source_authorial_core_sha256": core["canonical_sha256"],
            "source_intent_lock_sha256": lock["canonical_sha256"],
            "preserved_anchor_ids": [x["anchor_id"] for x in lock["semantic_anchors"]],
            "preserved_evidence": [], "authorial_decisions": []},
        "semantic_clarification_decisions": [{"clarification_id": x["id"],
            "decision": "applied" if x.get("required_in_final_prompt") else "rejected",
            "rationale": "Retain the exact frozen requester-owned scene and reject unrelated optional reinterpretations",
            "prompt_evidence": lock["semantic_anchors"][0]["prompt_evidence"]}
            for x in pack["semantic_clarification"]["candidates"]],
        "creative_augmentation_brief": {"decisions": [{"candidate_id": x["id"], "decision": "rejected",
            "rationale": "Retain the exact frozen requester-owned physical event"}
            for x in pack["creative_augmentation"]["candidates"]]},
    }
    contract = pack.get("semantic_assertion_obligations")
    if contract:
        composed["semantic_assertion_evidence"] = {"source_contract_sha256": contract["canonical_sha256"],
            "evidence": {x["assertion_id"]: x["frozen_evidence"] for x in contract["obligations"]}}
    return composed

results=[]
for arm in [ARM]:
 for f in sorted((D/(arm+'-output')).glob('*.pack.json')):
  pack=json.loads(f.read_text())[0];composed=baseline_composition(pack);result=audit.audit_composed_prompt(pack,composed)
  target=D/(arm+'-output')/(f.stem+'.composed.json');target.write_text(json.dumps(composed,ensure_ascii=False,indent=2)+'\n')
  target.with_suffix('.audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
  results.append({'arm':arm,'case':f.stem,'status':result['status'],'failures':result['failures'],'warnings':result.get('warnings',[]),'prompt_unchanged':composed['prompt_en']==pack['authorial_core']['baseline_prompt_en']})
(D/(ARM+'-composition-audit-results.json')).write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n')
print([(r['arm'],r['case'],r['status'])for r in results])
