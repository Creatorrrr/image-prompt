# Undercut effect metadata audit

## Recommendation

**Qualify the two-record metadata correction for a DATA-only trial.** Add one nape effect alongside the existing side effect for `sca_h16` in both the ordinary candidate and optional visual profile. The unchanged consumer then protects nape-property locks that the current side-only declaration misses. This is an applicability/lock-safety correction, not new visual coverage, semantic retrieval improvement, or image-quality evidence.

The union has a real conservative cost: a safe side-only realization under a nape lock is excluded because the single source entry still offers side **or** nape. Do not hide that regression, special-case runtime routing, or narrow source wording solely to retain the candidate. The user can still receive their explicitly requested side-only portrait from the frozen baseline; losing this optional candidate does not invalidate the request. Variant-specific optional candidates would be a separate larger design.

## Exact records and source authority

Requested source pin: `8a0fb5b8dd30d70bc9dbae7f63fbce38daa3bbfc`.

Runtime checkout during audit: `6fb8768287ab37878f1257960fc6b799d4b38fac`; its only differences from the requested pin were two documentation/evidence additions. Both inspected production JSON files were byte-verified against `git show` at the requested pin. Detached before/proposal copies were saved outside the repository.

1. `skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations_subculture_appearance.json`
   - `/profiles/12` (`id = sca_h16`)
   - edit only `/profiles/12/concept_candidate/affected_properties`
2. `skills/photo-prompt-image-generator/assets/photo_prompt_subculture_appearance_extension.json`
   - `/slots/hair_style/11` (`id = sca_h16`)
   - edit only `/slots/hair_style/11/affected_properties`

Both define a substantially shorter **side or nape** region next to retained longer upper hair. Both currently declare only:

- dimension: `appearance`
- target: `main_subject`
- property: `hair.style.side.undercut_length`

Append the parallel authored effect:

- dimension: `appearance`
- target: `main_subject`
- property: `hair.style.nape.undercut_length`

Do not change labels, aliases, positive definitions, components, alternatives, carrier guards, affected dimension, exact activation, render gates or evidence fields.

Source records corroborate the missing location:

- `docs/research-evidence/photo-prompt/subculture-appearance-20261003/term-specs.psv`, H16, line 17: the described short region is side **or nape**; its older research property column is `subject.hair.side.length_distribution`
- `docs/research-evidence/photo-prompt/subculture-appearance-integration-20261003/NEW-RELATION-ALTERNATIVES.psv`, H16, line 14: English and Korean alternatives both include nape; its intermediate property column is `hair.side.undercut_length`
- The integration script, `build_integration.py` around lines 105–121, prepends `hair.style.` for hair-style rows and initially creates a one-element effect list. This explains how the old single-side research field became the runtime path even though the visual meaning retained the alternative region

Those are historical evidence/build records. Do not silently rewrite them to pretend they already declared the union. A correction record and focused test should document the new complete effect scope. Updating a historical build script is not necessary for production loading and is outside this minimal metadata-only proposal.

## Canonical-path finding

**There is no discovered finite canonical property vocabulary.** The core validator enforces lower-case dot-path syntax and an open parent dimension; the shared property consumer enforces target/path equality, ancestors, descendants and `*`. It does not look up anatomical synonyms or infer overlap from source prose.

`hair.style.nape.undercut_length` is therefore a **newly declared conventional sibling** of the existing `hair.style.side.undercut_length`, not an already registered canonical leaf. It follows the integration's established `hair.style` namespace. Neither old `subject.hair...` research paths nor `hair.side...` intermediate paths should be copied into runtime.

An adjacent existing H15 effect, `hair.style.layers.crown_nape_length`, describes layered crown/nape distribution. It is not an alias for a nape-specific undercut and must not be substituted merely because its string contains `nape`.

This fix protects locks expressed using the shared `hair.style.nape` ancestor, the parallel leaf, or broader `hair.style`. It does not claim synonym normalization across arbitrary alternative paths such as another research namespace. That remaining ontology limitation is unchanged.

## Detached tests through unchanged consumer functions

`audit.py` uses frozen source JSON copies and imports production functions unchanged:

- `photo_contracts.property_effects_allowed`
- `prompt_generator.candidate_pack_visual_concept_candidates`
- `prompt_generator.candidate_pack_assertion_discovery(..., include_visual_priorities=True)` for ordinary candidate discovery

The property locks and visual observations are in normalized v3 cores that remain unchanged before/after. The visual projection receives a controlled optional hit to isolate applicability rather than conflate it with ranking. The ordinary path ranks the isolated actual candidate through production BM25F and observation-discovery functions. These are source-guided consumer tests, not independent semantic evaluation, a complete public-CLI pack trial, composition audit or rendered-image qualification.

Results agree across all three consumers for all nine cases:

| Case | Before | Proposal |
| --- | --- | --- |
| Fully open | eligible | eligible |
| Side ancestor locked | blocked | blocked |
| Nape ancestor locked | eligible | blocked |
| Exact parallel nape leaf locked | eligible | blocked |
| Unrelated hair color locked | eligible | eligible |
| Unrelated iris-color distribution locked | eligible | eligible |
| Explicit side-only undercut with nape lock | eligible | blocked |
| Another subject's nape locked | eligible | eligible |
| Broad hair.style locked | blocked | blocked |

Thus the proposal corrects two directly tested nape omissions and preserves side/broad-parent/owner/unrelated-property behavior. The side-only case documents conservative loss. A union effect is a union of everything this unspecialized candidate may affect; it is not a claim that every realization changes both locations simultaneously. The current generic gate cannot narrow the effect union by reading a side-only sentence.

An ordinary candidate can still appear in a larger lexical inventory and be marked ineligible rather than disappear completely. Public-CLI acceptance must check actual applicability and adoption authority, not require disappearance as the sole correct UI representation.

## Four complete public-CLI fixture bundles

Prepared at `cli-fixtures/`:

1. `nape_preserved`: requested nape length preserved, side styling open
2. `side_preserved`: requested side length preserved, nape styling open
3. `fully_open`: haircut arrangement open
4. `unrelated_iris_preserved`: both irises remain brown, haircut arrangement open

Each includes exact request envelope, raw v3 authorial core, resolved creative-control snapshot, synthetic contract-test embodiment review, normalized core, and command. All four passed the same request/core/control/embodiment input loaders used by `generate_photo_prompt.py`. The review is explicitly synthetic regression evidence and makes no physical/pixel claim.

`cli-fixtures/MANIFEST.json` freezes every input SHA, request SHA and canonical core SHA. Reuse these same files and seed `90716` in the detached baseline and cached-index proposal checkouts. No per-arm rewriting is allowed. Commands use only the existing public CLI arguments; the CLI has no data-root override, so execute in each correctly prepared checkout. These fixtures were deliberately source-guided and must not be labeled blind.

Expected proposal outcomes: nape-preserved and side-preserved reject optional adoption of this unspecialized union; fully-open and unrelated-iris preserve eligibility. Baseline differs only for nape-preserved. No exact full-profile term is intentionally inserted into the requester text to manufacture hard activation. Actual retrieval presence/rank remains for the coordinator's public trial; it was not assumed from the microchecks.

## Vector and generated-index implications

Direct comparisons passed:

- ordinary `semantic_text_for_entry` unchanged
- ordinary BM25F fields and isolated derived BM25F payload unchanged
- profile semantic text and BM25F fields unchanged
- profile exact activation, evidence requirements and render gates unchanged
- ordinary source digest and dictionary hash changed
- visual registry hash changed

Therefore **zero new embedding texts and zero new vectors are expected**. All existing vectors are reusable byte-for-byte under the same provider/model/dimensions. Both generated indexes still need normal source-identity refresh and validation:

- general semantic index: updated dictionary hash and any derived source metadata; vector/shard contents should remain unchanged if the builder's cache is complete
- visual profile index: updated registry hash; unchanged exact lookup, semantic/BM25F content and vectors

Do not preserve stale headers, overwrite hashes by hand, make fake vectors, or run uncached provider calls. Use existing builders with complete matching caches; stop if any pending embedding appears unexpectedly. Candidate/public semantic surfaces, corpus hashes and pack IDs will legitimately reflect the new effect metadata, so before/after packs need not be byte-identical even though their frozen inputs and visible prose are unchanged.

## Limits and handoff

No production files were mutated; no providers or image tools were called. Detached proposal files, `RESULTS.json`, `run.log`, `REPORT.md`, and complete CLI fixtures are in this directory. Initial probe-layout/fixture-validation errors are preserved in `PROBE-SETUP-FAILURE.txt`; ordinary validators were retained rather than weakened.

Recommendation is conditional on the cached-index public-CLI trial and affected regression checks. This is a small source-correct metadata repair with a measured conservative loss, not a universal fix for property ontologies, stronger safety policy, or artistic improvement.
