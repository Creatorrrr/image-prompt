"""Read-only independent review of coordinator's detached v2 evidence."""
from pathlib import Path
import copy,hashlib,json,subprocess,sys
P=Path(__file__).resolve().parent.parent;D=P/'undercut-trial-v2';R=P.parent/'image-prompt';F=P/'undercut-effect-audit/cli-fixtures';O=P/'undercut-effect-audit/public-v2-review';O.mkdir(exist_ok=True)
report={};sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((D/'runtime-source-manifest.json').read_text())
for rel,h in manifest.items():
 for arm in ['before','after']:
  assert sha(D/arm/'skills/photo-prompt-image-generator'/rel)==h
 assert sha(R/'skills/photo-prompt-image-generator'/rel)==h
 assert hashlib.sha256(subprocess.check_output(['git','show','8a0fb5b8:skills/photo-prompt-image-generator/'+rel],cwd=R)).hexdigest()==h
report['runtime_files_byte_identical_to_pin8']=len(manifest)
fixtures=json.loads((F/'MANIFEST.json').read_text())
for case in fixtures['cases']:
 for n,h in case['file_sha256'].items():assert sha(F/case['id']/n)==h
report['original_fixture_hashes_verified']=sum(len(c['file_sha256'])for c in fixtures['cases'])
A=D/'before/skills/photo-prompt-image-generator/assets';B=D/'after/skills/photo-prompt-image-generator/assets'
def changes(a,b,p=''):
 if type(a)!=type(b):return [p]
 if isinstance(a,dict):return sum((changes(a.get(k),b.get(k),p+'/'+k)for k in sorted(a.keys()|b.keys())),[])
 if isinstance(a,list):
  if len(a)!=len(b):return [p]
  return sum((changes(x,y,p+'/'+str(i))for i,(x,y)in enumerate(zip(a,b))),[])
 return []if a==b else[p]
source_changes={}
for n in ['photo_prompt_subculture_appearance_extension.json','photo_prompt_visual_obligations_subculture_appearance.json']:
 assert sha(A/n)==sha(R/'skills/photo-prompt-image-generator/assets'/n)
 assert sha(B/n)==sha(P/'undercut-effect-audit/proposal-v2'/n)
 source_changes[n]=changes(json.loads((A/n).read_text()),json.loads((B/n).read_text()))
report['source_changes']=source_changes
v1=json.loads((A/'photo_prompt_visual_profile_index.json').read_text());v2=json.loads((B/'photo_prompt_visual_profile_index.json').read_text())
assert changes(v1,v2)==['/registry_sha256'];report['profile_index_only_changed_field']='registry_sha256';report['profile_entries_unchanged']=len(v1['entries'])
s1=json.loads((A/'photo_prompt_semantic_index.json').read_text());s2=json.loads((B/'photo_prompt_semantic_index.json').read_text());sdiff=changes(s1,s2)
assert sdiff==['/created_at','/dictionary_hash']+['/shards/'+str(i)+'/path'for i in range(len(s1['shards']))]
for a,b in zip(s1['shards'],s2['shards']):assert sha(A/a['path'])==a['sha256']==sha(B/b['path'])==b['sha256']
report['general_shards_byte_identical_and_hash_valid']=len(s1['shards']);report['general_entries_unchanged']=s1['entry_count'];report['general_manifest_changed_fields']=sdiff
report['pack_checks']=[]
for c in [x['id']for x in fixtures['cases']]:
 b=json.loads((D/'before-output'/f'{c}.pack.json').read_text())[0];a=json.loads((D/'after-output'/f'{c}.pack.json').read_text())[0]
 for k in ['authorial_core','negative_en','embodiment_preflight']:assert a[k]==b[k]
 def ids(p):return {k:[(x['id'],x.get('applicability'))for x in v['candidates']]for k,v in p['slots'].items()}
 bi,ai=ids(b),ids(a);delta={k:{'before':bi.get(k),'after':ai.get(k)}for k in bi.keys()|ai.keys()if bi.get(k)!=ai.get(k)}
 visual_ids=lambda p:[(x['id'],x.get('applicability'))for x in (p.get('visual_concept_candidates')or{}).get('candidates',[])]
 aug_ids=lambda p:[(x['id'],x.get('applicability'))for x in (p.get('creative_augmentation')or{}).get('candidates',[])]
 assert visual_ids(a)==visual_ids(b)
 if c!='nape_preserved':assert aug_ids(a)==aug_ids(b)
 if c!='nape_preserved':assert not delta
 else:
  assert set(delta)=={'hair_style','makeup_wear_state'}
  assert [x['entry_id']for x in a['slots']['hair_style']['candidates']]==['sca_h08']
 for arm in ['before','after']:
  comp=json.loads((D/(arm+'-output')/f'{c}.pack.composed.json').read_text());audit=json.loads((D/(arm+'-output')/f'{c}.pack.composed.audit.json').read_text())
  assert audit['status']=='pass'and not audit['failures']and audit['quality_status']=='warn'
  assert comp['chosen_candidate_ids']==comp['chosen_visual_concept_ids']==[]
  assert comp['prompt_en']==a['authorial_core']['baseline_prompt_en']
 report['pack_checks'].append({'case':c,'slot_id_applicability_delta':delta,'visual_ids_applicability_unchanged':True,'augmentation_ids_applicability_unchanged':aug_ids(a)==aug_ids(b),'augmentation_before':aug_ids(b),'augmentation_after':aug_ids(a),'augmentation_pool_count_before':b['creative_augmentation']['hard_eligible_candidate_count'],'augmentation_pool_count_after':a['creative_augmentation']['hard_eligible_candidate_count'],'core_negative_embodiment_unchanged':True,'composition_scope':'unchanged baseline, reject all optional candidates; pass with existing uncovered-intent warnings'})
sys.path.insert(0,str(D/'after/skills/photo-prompt-image-generator/scripts'));import audit_composed_prompt as auditor
p=json.loads((D/'after-output/nape_preserved.pack.json').read_text())[0];c=json.loads((D/'after-output/nape_preserved.pack.composed.json').read_text())
target='slot:makeup_wear_state:faded_lip_center_wear';c['chosen_candidate_ids']=[target]
a=auditor.audit_composed_prompt(p,c);rows=[f for f in a['failures']if f.get('check')=='candidate_applicability'];assert rows and any(x['id']==target for r in rows for x in r['candidates'])
report['extra_ineligible_row_attempted_selection']={'status':a['status'],'applicability_failures':rows,'all_failure_checks':[f.get('check')for f in a['failures']],'scope':'In-memory counterfactual selection, no production artifact/input mutation. Other missing interpretation failures do not substitute for the explicit applicability rejection.'}
report['actual_cli_seed']=1003;report['fixture_command_template_seed']=90716;report['actual_seed_same_in_v1_v2_all_arms']=True
report['production_git_status']=subprocess.check_output(['git','status','--short'],cwd=R,text=True);assert not report['production_git_status']
report['recommendation']='APPLY bounded H15/H16 metadata correction with normal cached source-identity index refresh; no category-wide nape safety claim'
(O/'independent-verification.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items()if k not in ['pack_checks','general_manifest_changed_fields']},indent=2))
