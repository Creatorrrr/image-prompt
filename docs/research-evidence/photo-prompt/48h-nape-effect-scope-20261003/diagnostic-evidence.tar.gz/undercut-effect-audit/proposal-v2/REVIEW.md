# H15 replacement review and v2 recommendation

## Decision

Proceed only to the coordinator's fresh cached-index v2 trial. The H16-only change is not sufficient evidence for nape protection because its freed candidate position admitted H15, whose authored meaning also constrains nape hair. Preserve H16-only source copies, results and full CLI outputs as development history; they have not been overwritten.

The minimum revised delta covers four effect arrays in the same two source files:

- H15 ordinary candidate `/slots/hair_style/10/affected_properties`
- H16 ordinary candidate `/slots/hair_style/11/affected_properties`
- H15 visual profile `/profiles/11/concept_candidate/affected_properties`
- H16 visual profile `/profiles/12/concept_candidate/affected_properties`

Append `appearance / main_subject / hair.style.nape.layer_length` to H15. Keep its original `hair.style.layers.crown_nape_length` effect intact.

Append the already-proposed `appearance / main_subject / hair.style.nape.undercut_length` to H16. Keep its original side effect intact.

Both nape leaves are newly declared conventional paths, not members of a discovered finite canonical vocabulary. The compiler accepts dot-path syntax; the consumer compares hierarchy, not English anatomical meaning. H15's combined existing leaf is under `hair.style.layers` and therefore cannot match the `hair.style.nape` ancestor. Retaining it preserves existing whole-layer and exact combined-property locks while the additional nape leaf protects region-scoped locks.

## Source evidence and actual replacement

H15 is explicit in every relevant source:

- `term-specs.psv` H15, line 16: shorter crown/face-frame layers and longer layers at the nape
- `NEW-RELATION-ALTERNATIVES.psv` H15, line 13: longer sections continue at the back of the neck
- Both production H15 records: the second positive visual component is longer layered sections remaining at the nape

This is therefore an independently justified correction of the source effect declaration, not a candidate-ID suppression invented after a ranking failure.

The coordinator's `undercut-trial/before-after-candidate-comparison.json` and nape-preserved public packs establish:

- Before: eligible H16 and H08
- H16-only after: eligible H15 and H08
- The nape property anchor, core, negative output and embodiment bytes stayed identical

The replacement does not itself prove that the rendered nape changed: H15's longer-nape wording might be realizable without altering already-long hair. It does prove that the unspecialized candidate's complete nape constraint remains unrepresented in its effect declaration and is admitted under a region-level lock. The normal conservative property contract has no value-equivalence solver to certify a particular realization.

H08 describes bun/tail gathering topology. It has no explicit nape location or nape-length component, so the observed H08 survivor does not justify adding a speculative nape effect to it.

## Detached v2 checks

`audit_v2.py` exercises the unchanged property gate, visual optional projection and ordinary frozen-observation discovery for both IDs. All 36 baseline/proposal state checks pass their stated expectations across nine cases per profile. These are source-guided lock tests with a controlled observation to isolate applicability; they are not full CLI retrieval or independent semantic evaluation.

- Open, unrelated hair color, unrelated iris color and another subject's nape stay eligible
- Nape ancestor and each profile's exact new nape leaf change eligible → blocked
- Broad `hair.style` remains blocked
- H16 side lock remains blocked
- H15 side lock remains eligible: this bounded nape metadata repair does not fix its crown/face-side regional ontology
- Side-only realization under a nape lock becomes blocked by the unspecialized union/effect declaration, including otherwise potentially compatible cases
- Each original effect remains in place and still blocks under its existing exact-property lock

Both schemas validate. Both IDs retain identical positive semantic text, BM25F content, activation and gates. Only four affected-properties arrays change. Zero new embedding texts are expected; refresh source identity using unchanged cached vectors.

## Important scope limits

Do not call this category-wide nape protection. A focused positive-source scan also found the legacy `two_block_disconnected_cut` profile with back/nape wording but no scoped effect metadata. It is outside this proposed delta and would require separate assessment. Anatomical hairline, feather, tattoo and neck-garment candidates are different semantic owners, so a shared word `nape` is not sufficient reason to assign them this hairstyle effect.

The unchanged side-preserved public fixture already admits H15, whose alternative mentions face-side layers. Identical side-case IDs are therefore not evidence that every side-related option is safe. The current proposal establishes only the intended nape overlap for the two corrected records; it does not certify all crown/face/side effects or normalize alternative property names.

## Next acceptance check

Replay the exact same four frozen public-CLI fixture bundles, with their existing hashes and seed, in a fresh v2 cached-index arm. Do not tune their inputs. Inspect the entire new hair-style candidate set and any visual-profile replacements, not just disappearance of H15/H16.

Accept only the bounded claim if both corrected entries are unavailable for optional adoption under `hair.style.nape`, open/unrelated behavior remains consistent, existing property guards survive, cached indexes validate, and no new unexplained nape-constraining replacement is presented as a passing outcome. If replacement exposes another relevant omission, report it and bound any further work explicitly; do not add broad hair blacklists or claim closure from candidate absence alone.

No production edits, provider calls or image generation were performed.
