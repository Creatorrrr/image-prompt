"""H15 + H16 detached metadata qualification; preserves all v1 artifacts."""
from pathlib import Path
import sys,json,copy,hashlib,subprocess
R=Path('REPOSITORY_ROOT');O=Path(__file__).resolve().parent;D=O/'proposal-v2';D.mkdir(exist_ok=True)
sys.path.insert(0,str(R/'skills/photo-prompt-image-generator/scripts'));sys.path.insert(0,str(R))
import prompt_generator as pg
import photo_contracts as pc
import photo_candidate_semantics as ps
import validate_photo_prompt_dictionary as vd
from visual_profile_contracts import compile_visual_profile
BASE='photo_prompt_subculture_appearance_extension.json';VIS='photo_prompt_visual_obligations_subculture_appearance.json'
ADD={'sca_h15':'hair.style.nape.layer_length','sca_h16':'hair.style.nape.undercut_length'}
originals={name:json.loads((O/'baseline'/name).read_text()) for name in [BASE,VIS]}
for name,payload in originals.items():
 after=copy.deepcopy(payload)
 for rid,prop in ADD.items():
  row=next(r for r in (after['profiles'] if name==VIS else after['slots']['hair_style']) if r['id']==rid)
  effects=row['concept_candidate']['affected_properties'] if name==VIS else row['affected_properties']
  effects.append({'dimension':'appearance','target':'main_subject','property':prop})
 (D/name).write_text(json.dumps(after,ensure_ascii=False,indent=2)+'\n')
proposed={name:json.loads((D/name).read_text()) for name in [BASE,VIS]}
registry=json.loads(subprocess.check_output(['git','show','8a0fb5b8:skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations.json'],cwd=R))
validation=D/'validation';validation.mkdir(exist_ok=True)
errors=[]
full=copy.deepcopy(registry);full['profiles']+=proposed[VIS]['profiles'];(validation/'registry.json').write_text(json.dumps(full,ensure_ascii=False,indent=2)+'\n');vd.validate_visual_obligation_registry(validation/'registry.json',errors);assert not errors,errors
ps.validate_candidate_entries(proposed[BASE],pg.AUTHORIAL_CORE_V3_INTENT_LOCK_DIMENSIONS)
records=[];invariants={};policy={'candidate_semantic_policy':{'core_assertion_discovery':{'maximum_candidates':24,'maximum_per_assertion':4,'minimum_shared_content_words':3}}}
for rid,nape_leaf in ADD.items():
 entries={};profiles={};registries={};indexes={}
 for state,sources in [('baseline',originals),('proposal_v2',proposed)]:
  entries[state]=next(e for e in sources[BASE]['slots']['hair_style'] if e['id']==rid)
  profiles[state]=compile_visual_profile(next(p for p in sources[VIS]['profiles'] if p['id']==rid))
  rr=copy.deepcopy(registry);rr['profiles'].append(profiles[state]);registries[state]=rr
  indexes[state]=pg.build_semantic_bm25f_payload({'slots':{'hair_style':[entries[state]]}})
 for case in ['open','side_locked','nape_locked','nape_leaf_locked','unrelated_locked','unrelated_iris_locked','side_only_under_nape_lock','other_subject_nape_locked','whole_hair_style_locked']:
  core=json.loads((O/('core-'+case+'.json')).read_text())
  # The exact-leaf microcase uses each proposed effect's own conventional leaf.
  # Freeze once before the pair; no state-specific core editing occurs.
  if case=='nape_leaf_locked':
   for a in core['intent_lock']['semantic_anchors']:
    if a.get('property'):a['property']=nape_leaf
  # A controlled advisory observation isolates property safety from rank recall.
  # It does not constitute a new independent semantic test.
  observed=copy.deepcopy(core);observed['visual_priorities']=profiles['baseline']['semantics']['visual_components']
  result={'profile_id':rid,'case':case,'lock_paths':[a.get('property') for a in core['intent_lock']['semantic_anchors'] if a.get('property')], 'states':{}}
  for state in entries:
   e=entries[state];p=profiles[state];lock=core['intent_lock']
   expected=case not in {'whole_hair_style_locked'} and not (case=='side_locked' and rid=='sca_h16') and not (state=='proposal_v2' and case in {'nape_locked','nape_leaf_locked','side_only_under_nape_lock'})
   guard=pc.property_effects_allowed(lock,e['affected_dimensions'],e['affected_properties'])
   public=pg.candidate_pack_visual_concept_candidates({pg.VISUAL_OBLIGATIONS_DATA_KEY:registries[state]},{'provenance':{'authorial_core':core}},{},None,None,{'hits':[{'profile_id':rid,'optional_eligible':True,'hard_eligible':False,'match_basis':'bm25f'}]})
   visible=bool(public and any(r['id']=='visual-concept:'+rid for r in public['candidates']))
   found=pg.candidate_pack_assertion_discovery(policy,observed,{'slot:hair_style:'+rid:e},indexes[state],include_visual_priorities=True)
   discovered=('slot:hair_style:'+rid) in found
   result['states'][state]={'property_guard':guard,'visual_optional':visible,'ordinary_observation_discovery':discovered,'expected':expected,'passed':guard==visible==discovered==expected}
  records.append(result)
 be,ae=entries['baseline'],entries['proposal_v2'];bp,ap=profiles['baseline'],profiles['proposal_v2']
 orig=be['affected_properties'][0]['property'];original_lock={'contract_version':'photo-intent-lock/v2','semantic_anchors':[{'dimension':'appearance','target':'main_subject','property':orig}]}
 invariants[rid]={'ordinary_text_equal':pg.semantic_text_for_entry(be,'hair_style')==pg.semantic_text_for_entry(ae,'hair_style'),'ordinary_bm25f_equal':indexes['baseline']==indexes['proposal_v2'],'profile_text_equal':pg.visual_profile_semantic_text(bp)==pg.visual_profile_semantic_text(ap),'profile_bm25f_fields_equal':pg.visual_profile_bm25f_fields(bp)==pg.visual_profile_bm25f_fields(ap),'activation_equal':bp['activation']==ap['activation'],'gates_equal':bp['render_gates']==ap['render_gates'],'original_effects_preserved':ae['affected_properties'][:-1]==be['affected_properties'],'original_property_lock_still_blocks':not pc.property_effects_allowed(original_lock,ae['affected_dimensions'],ae['affected_properties']),'proposed_effect':nape_leaf}
# Exact difference paths across complete detached source copies.
def diff(a,b,path=''):
 if type(a)!=type(b):return [path]
 if isinstance(a,dict):return sum((diff(a.get(k),b.get(k),path+'/'+k) for k in sorted(set(a)|set(b))),[])
 if isinstance(a,list):
  if len(a)!=len(b):return [path]
  return sum((diff(x,y,path+'/'+str(i)) for i,(x,y) in enumerate(zip(a,b))),[])
 return [] if a==b else [path]
diffs={name:diff(originals[name],proposed[name]) for name in [BASE,VIS]}
report={'source_pin':'8a0fb5b8dd30d70bc9dbae7f63fbce38daa3bbfc','scope':'Source-guided property/application consumer tests; not full CLI, not independent semantic evaluation. Same lock per baseline/proposal pair. Controlled observation words used only to separate ranking from lock safety. Existing frozen public CLI fixtures are unchanged.','schema_errors':errors,'cases':records,'invariants':invariants,'changed_paths':diffs,'remaining_scoped_limit':'H15 still does not overlap hair.style.side; this nape-only addition does not certify side, crown or all category-level property coverage. Legacy two_block_disconnected_cut is outside this delta.','provider_calls':0,'production_mutations':0}
(D/'RESULTS.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'schema_errors':errors,'passed_state_checks':sum(v['passed'] for r in records for v in r['states'].values()),'state_checks':len(records)*2,'invariants':invariants,'changed_paths':diffs},indent=2))
