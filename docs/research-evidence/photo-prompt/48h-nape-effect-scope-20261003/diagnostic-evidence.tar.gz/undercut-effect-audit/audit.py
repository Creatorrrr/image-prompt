from pathlib import Path
import sys,json,copy,subprocess,hashlib
R=Path('REPOSITORY_ROOT');O=Path(__file__).resolve().parent;PIN='8a0fb5b8dd30d70bc9dbae7f63fbce38daa3bbfc'
sys.path.insert(0,str(R/'skills/photo-prompt-image-generator/scripts'));sys.path.insert(0,str(R))
import prompt_generator as pg
import photo_contracts as pc
import photo_candidate_semantics as ps
import validate_photo_prompt_dictionary as vd
from visual_profile_contracts import compile_visual_profile
from tests import photo_prompt_fixtures as f
FILES=['skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations_subculture_appearance.json','skills/photo-prompt-image-generator/assets/photo_prompt_subculture_appearance_extension.json']
for version in ['baseline','proposal']:(O/version).mkdir(exist_ok=True)
payloads={}
for file in FILES:
 raw=subprocess.check_output(['git','show',PIN+':'+file],cwd=R)
 assert raw==(R/file).read_bytes(),'Production source differs from requested pin'
 d=json.loads(raw);payloads[Path(file).name]=d
 (O/'baseline'/Path(file).name).write_bytes(raw)
 proposed=copy.deepcopy(d)
 if 'profiles' in proposed: row=next(x for x in proposed['profiles'] if x['id']=='sca_h16')['concept_candidate']
 else:row=next(x for x in proposed['slots']['hair_style'] if x['id']=='sca_h16')
 row['affected_properties'].append({'dimension':'appearance','target':'main_subject','property':'hair.style.nape.undercut_length'})
 (O/'proposal'/Path(file).name).write_text(json.dumps(proposed,ensure_ascii=False,indent=2)+'\n')
BASE='photo_prompt_subculture_appearance_extension.json'; VIS='photo_prompt_visual_obligations_subculture_appearance.json'
ordinary={};profile={};registries={};bm25={}
base_registry=json.loads(subprocess.check_output(['git','show',PIN+':skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations.json'],cwd=R))
for version in ['baseline','proposal']:
 d=json.loads((O/version/BASE).read_text()); ordinary[version]=next(x for x in d['slots']['hair_style'] if x['id']=='sca_h16')
 p=json.loads((O/version/VIS).read_text());profile[version]=compile_visual_profile(next(x for x in p['profiles'] if x['id']=='sca_h16'))
 registry=copy.deepcopy(base_registry);registry['profiles'].append(profile[version]);registries[version]=registry
 (O/version/'validation').mkdir(exist_ok=True)
 (O/version/'validation/registry.json').write_text(json.dumps(registry,ensure_ascii=False,indent=2)+'\n')
 errors=[];vd.validate_visual_obligation_registry(O/version/'validation/registry.json',errors);assert not errors,errors
 ps.validate_candidate_entries({'slots':{'hair_style':[ordinary[version]]}},pg.AUTHORIAL_CORE_V3_INTENT_LOCK_DIMENSIONS)
 thin={'slots':{'hair_style':[ordinary[version]]}}
 bm25[version]=pg.build_semantic_bm25f_payload(thin)
cases=[
 ('open',None,'main_subject',True,True),
 ('side_locked','hair.style.side','main_subject',False,False),
 ('nape_locked','hair.style.nape','main_subject',True,False),
 ('nape_leaf_locked','hair.style.nape.undercut_length','main_subject',True,False),
 ('unrelated_locked','hair.color','main_subject',True,True),
 ('unrelated_iris_locked','face.eyes.iris_color_distribution','main_subject',True,True),
 ('side_only_under_nape_lock','hair.style.nape','main_subject',True,False),
 ('other_subject_nape_locked','hair.style.nape','background_subject',True,True),
 ('whole_hair_style_locked','hair.style','main_subject',False,False),
]
records=[]
policy={'candidate_semantic_policy':{'core_assertion_discovery':{'maximum_candidates':24,'maximum_per_assertion':4,'minimum_shared_content_words':3}}}
for case,path,target,expected_before,expected_after in cases:
 specific=case=='side_only_under_nape_lock'
 request=('Photograph an adult person with a side-only undercut and retained upper hair. Preserve all nape hair at its existing length.' if specific else 'Photograph an adult person with an undercut length contrast and retained upper hair.')
 if path and not specific:request+=' Preserve the selected protected hair property unchanged.'
 scene=('One adult person holds a still pose in a neutral photographic studio. The visible haircut has a side-only short patch and longer upper hair; the nape hair remains at its existing length.' if specific else 'One adult person holds a still pose in a neutral photographic studio. A side or nape region has markedly shorter hair; the adjacent upper hair mass remains longer. The protected hair detail remains unchanged.')
 baseline=scene+' Soft lighting reveals the chosen hair lengths, and a calm background keeps the haircut legible. The framing preserves a coherent portrait with natural proportions and readable hair contours.'
 core=f.core(request,interpreted_intent='A photographic haircut relation with unchanged protected hair details',subject='One adult person',setting='a neutral photographic studio',event='holds a still pose',visual_priorities=(('a short side-only hair patch beside longer retained upper hair','unchanged nape hair length') if specific else ('a side or nape region has markedly shorter hair','the adjacent upper hair mass remains longer')),baseline_prompt_en=baseline,open_dimensions=('appearance','lighting','framing','composition'),anchor_evidence=('One adult person','holds a still pose','a neutral photographic studio'))
 if path:core['intent_lock']['semantic_anchors'].append({'anchor_id':'protected_hair','source_text':request,'dimension':'appearance','target':target,'property':path,'prompt_evidence':'the nape hair remains at its existing length' if specific else 'The protected hair detail remains unchanged'})
 core=pg.normalize_authorial_core(core,request_envelope=pg.normalize_request_envelope(f.envelope(request)))
 # Frozen visual priorities provide optional observation discovery; the normalized core is unchanged.
 row={'case':case,'lock':path,'target':target,'side_only_requested':specific,'versions':{}}
 for version,expected in [('baseline',expected_before),('proposal',expected_after)]:
  e=ordinary[version];p=profile[version];lock=core['intent_lock']
  guard=pc.property_effects_allowed(lock,e['affected_dimensions'],e['affected_properties'])
  result={'provenance':{'authorial_core':core}}
  public=pg.candidate_pack_visual_concept_candidates({pg.VISUAL_OBLIGATIONS_DATA_KEY:registries[version]},result,{},None,None,{'hits':[{'profile_id':'sca_h16','optional_eligible':True,'hard_eligible':False,'match_basis':'bm25f'}]})
  visible=bool(public and public['candidates'])
  found=pg.candidate_pack_assertion_discovery(policy,core,{'slot:hair_style:sca_h16':e},bm25[version],include_visual_priorities=True)
  discovery='slot:hair_style:sca_h16' in found
  row['versions'][version]={'property_guard_allowed':guard,'visual_optional_visible':visible,'ordinary_assertion_discovered':discovery,'expected':expected,'pass':guard==visible==discovery==expected,'effects':e['affected_properties']}
 records.append(row)
 (O/('core-'+case+'.json')).write_text(json.dumps(core,ensure_ascii=False,indent=2)+'\n')
# Content projections and source identity; no vectors are created.
be,pe=ordinary['baseline'],ordinary['proposal'];bp,pp=profile['baseline'],profile['proposal']
invariants={
 'ordinary_semantic_text_equal':pg.semantic_text_for_entry(be,'hair_style')==pg.semantic_text_for_entry(pe,'hair_style'),
 'ordinary_bm25f_fields_equal':pg.semantic_bm25f_fields_for_entry(be,'hair_style')==pg.semantic_bm25f_fields_for_entry(pe,'hair_style'),
 'ordinary_bm25f_payload_equal':bm25['baseline']==bm25['proposal'],
 'profile_semantic_text_equal':pg.visual_profile_semantic_text(bp)==pg.visual_profile_semantic_text(pp),
 'profile_bm25f_fields_equal':pg.visual_profile_bm25f_fields(bp)==pg.visual_profile_bm25f_fields(pp),
 'profile_exact_terms_equal':bp['activation']==pp['activation'],
 'profile_evidence_equal':bp['evidence_requirements']==pp['evidence_requirements'],
 'profile_render_gates_equal':bp['render_gates']==pp['render_gates'],
 'ordinary_source_hash_changed':ps.digest(be)!=ps.digest(pe),
 'dictionary_hash_changed':pg.dictionary_hash({'slots':{'hair_style':[be]}})!=pg.dictionary_hash({'slots':{'hair_style':[pe]}}),
 'visual_registry_hash_changed':pg.visual_profile_registry_sha256(registries['baseline'])!=pg.visual_profile_registry_sha256(registries['proposal']),
}
# Exact only data-diff proof over complete copied source assets.
diffs=[]
def diff(a,b,path=''):
 if type(a)!=type(b):return [path]
 if isinstance(a,dict):return sum((diff(a.get(k),b.get(k),path+'/'+k) for k in sorted(set(a)|set(b))),[])
 if isinstance(a,list):
  if len(a)!=len(b):return [path]
  return sum((diff(x,y,path+'/'+str(i)) for i,(x,y) in enumerate(zip(a,b))),[])
 return [] if a==b else [path]
for name in [BASE,VIS]:diffs.append({'file':name,'changed_paths':diff(json.loads((O/'baseline'/name).read_text()),json.loads((O/'proposal'/name).read_text()))})
report={'source_pin':PIN,'runtime_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'scope':'Detached record copies; unchanged production property gate, visual optional projection, ordinary frozen-observation discovery. Not full pack or image qualification. Normalized v3 cores, including property locks and visual priorities, remain unchanged during consumer calls.','schema_valid':True,'cases':records,'projection_invariants':invariants,'asset_diffs':diffs,'provider_calls':0,'images':0,'conservative_loss':'The side-or-nape union candidate is blocked under a nape lock even when a side-only realization is explicitly requested. No runtime branch narrows effects based on prose.'}
(O/'RESULTS.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'cases':[{ 'id':r['case'],**{v:r['versions'][v]['pass'] for v in ['baseline','proposal']},'before_visible':r['versions']['baseline']['visual_optional_visible'],'after_visible':r['versions']['proposal']['visual_optional_visible']} for r in records],'invariants':invariants,'diffs':diffs},indent=2))
