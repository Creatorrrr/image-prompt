from pathlib import Path
import json,sys,hashlib,copy
R=Path('REPOSITORY_ROOT');O=Path(__file__).resolve().parent/'cli-fixtures';O.mkdir(exist_ok=True)
sys.path.insert(0,str(R));sys.path.insert(0,str(R/'skills/photo-prompt-image-generator/scripts'))
from tests import photo_prompt_fixtures as f
import prompt_generator as pg
cases=[
 ('nape_preserved','Keep all nape hair at its existing long length. You may vary the side haircut.', 'hair.style.nape','the nape hair retains its existing long length','a close-cut side patch sits below longer upper hair',False),
 ('side_preserved','Keep the side hair at its existing long length. You may vary the nape haircut.', 'hair.style.side','the side hair retains its existing long length','a close-cut nape patch sits below longer upper hair',False),
 ('fully_open','Choose the visible short-versus-long hair arrangement freely.',None,None,'a close-cut side or nape patch has a short visible hair length',True),
 ('unrelated_iris_preserved','Keep both irises brown. Choose the visible short-versus-long hair arrangement freely.','face.eyes.iris_color_distribution','both irises remain brown','a close-cut side or nape patch has a short visible hair length',True),
]
manifest={'classification':'source-guided regression fixtures, not blind evaluation or image generation','purpose':'Before/after property-lock semantics with byte-identical core inputs','cases':[]}
for key,condition,prop,lock_evidence,hair,proposal_eligible in cases:
 request='Create a still studio portrait of one adult person, using a clear undercut hair-length contrast. '+condition
 subject='one adult person with naturally resting facial features';setting='a quiet gray photographic studio';event='the subject holds a relaxed stationary portrait pose'
 baseline=('A photographic portrait shows '+subject+' in '+setting+'. '+event+'. '+hair+'; the neighboring upper hair retains a longer length. '+((lock_evidence+'. ') if lock_evidence else '')+'Gentle side light separates the short patch from the fuller upper mass, while a calm backdrop supports a clear hair silhouette. The image is a considered portrait with tactile strand detail and balanced framing, leaving the selected hair arrangement visible.')
 priorities=[hair,'the neighboring upper hair retains a longer length','readable separation between the short patch and fuller upper mass']
 raw=f.core(request,interpreted_intent='A calm studio portrait showing an undercut length contrast while preserving the requested existing properties',subject=subject,setting=setting,event=event,visual_priorities=tuple(priorities),baseline_prompt_en=baseline,locked_dimensions=('concept','subject','event'),open_dimensions=('appearance','framing','composition','camera','lighting','color','atmosphere'),anchor_evidence=('A photographic portrait',subject,event))
 if prop:raw['intent_lock']['semantic_anchors'].append({'anchor_id':'protected_property','source_text':condition,'dimension':'appearance','target':'main_subject','property':prop,'prompt_evidence':lock_evidence})
 env=f.envelope(request)
 controls=pg.creative_controls.resolve(request,overrides={'sensual':0,'fetish':0,'creativity':1,'surreal':0},context={'subject_category':'human','no_people':False,'explicit_nonsexual':False},seed=7)
 raw['creative_controls_sha256']=controls['canonical_sha256']
 bound=pg.normalize_authorial_core(raw,request_envelope=pg.normalize_request_envelope(env),creative_control_snapshot=controls)
 review=f.review(bound['baseline_prompt_en'])
 # Exercise the same pre-data input loaders as the public CLI; no corpus or provider needed.
 folder=O/key;folder.mkdir(exist_ok=True)
 values={'request-envelope.json':env,'authorial-core.json':raw,'creative-controls.json':controls,'embodiment-review.json':review,'normalized-core.json':bound}
 hashes={}
 for name,value in values.items():
  path=folder/name;path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n');hashes[name]=hashlib.sha256(path.read_bytes()).hexdigest()
 loaded_env=pg.load_request_envelope_arg(str(folder/'request-envelope.json'))
 loaded_core=pg.load_authorial_core_arg(str(folder/'authorial-core.json'),request_envelope=loaded_env,creative_control_snapshot=controls)
 pg.photo_embodiment.build_policy(loaded_core,review)
 assert loaded_core['canonical_sha256']==bound['canonical_sha256']
 entry={'id':key,'file_sha256':hashes,'source_request_sha256':env['request_sha256'],'core_sha256':bound['canonical_sha256'],'protected_property':prop,'target_candidate_ids':['visual-concept:sca_h16','slot:hair_style:sca_h16'],'expected_baseline_eligible':key!='side_preserved','expected_proposal_eligible':proposal_eligible,'input_validation':'passes public CLI request/core/control/embodiment input loaders','public_cli_execution':'not run; coordinator will supply detached cached-index baseline/proposal'}
 manifest['cases'].append(entry)
 command=f'''# Run unchanged in each separately prepared baseline/proposal checkout.\n# Use the same absolute fixture files; only --output-file may differ.\npython skills/photo-prompt-image-generator/scripts/generate_photo_prompt.py \\\n  --request-envelope-json {folder}/request-envelope.json \\\n  --authorial-core-json {folder}/authorial-core.json \\\n  --creative-controls-json {folder}/creative-controls.json \\\n  --embodiment-review-json {folder}/embodiment-review.json \\\n  --seed 90716 \\\n  --output-file candidate-pack-{key}.json\n'''
 (folder/'COMMAND.txt').write_text(command)
(O/'MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'fixtures':len(cases),'public_input_validation':'4/4 passed','provider_calls':0,'corpus_loaded':False},indent=2))
