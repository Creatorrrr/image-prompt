from pathlib import Path
import json,shutil,hashlib
P=Path(__file__).resolve().parent;R=P.parent/'image-prompt';S=R/'skills/photo-prompt-image-generator';D=P/'undercut-trial-v2';D.mkdir(exist_ok=True)
for arm in ['before','after']:
 t=D/arm/'skills/photo-prompt-image-generator';t.mkdir(parents=True,exist_ok=True)
 for n in ['scripts','precore']:
  shutil.copytree(S/n,t/n,dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__'))
 a=t/'assets';a.mkdir(exist_ok=True)
 for f in (S/'assets').glob('*.json'):shutil.copy2(f,a/f.name)
 manifest=json.loads((a/'photo_prompt_semantic_index.json').read_text())
 for row in manifest['shards']:
  dest=a/row['path'];dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(S/'assets'/row['path'],dest)
 if arm=='after':
  for n in ['photo_prompt_subculture_appearance_extension.json','photo_prompt_visual_obligations_subculture_appearance.json']:shutil.copy2(P/'undercut-effect-audit/proposal-v2'/n,a/n)
files={}
for f in S.glob('scripts/*.py'):files[str(f.relative_to(S))]=hashlib.sha256(f.read_bytes()).hexdigest()
(D/'runtime-source-manifest.json').write_text(json.dumps(files,indent=2)+'\n')
print('Snapshots prepared; production checkout not modified')
