from pathlib import Path
import json,hashlib,sys,shutil,datetime,subprocess,copy
P=Path(__file__).resolve().parent;R=P.parent/'image-prompt';A=R/'skills/photo-prompt-image-generator/assets';B=P/'undercut-trial-v2/before/skills/photo-prompt-image-generator/assets';N=P/'undercut-trial-v2/after/skills/photo-prompt-image-generator/assets'
assert not subprocess.check_output(['git','status','--short'],cwd=R,text=True).strip()
sys.path.insert(0,str(A.parent/'scripts'));import prompt_generator as pg;import photo_candidate_semantics as cs
names=['photo_prompt_subculture_appearance_extension.json','photo_prompt_visual_obligations_subculture_appearance.json','photo_prompt_visual_profile_index.json','photo_prompt_semantic_index.json']
for name in names:assert (A/name).read_bytes()==(B/name).read_bytes(),name
olddata=pg.load_runtime_data();oldprofile=olddata[pg.VISUAL_OBLIGATIONS_DATA_KEY];oldindex=olddata[pg.SEMANTIC_INDEX_DATA_KEY]
ext=json.loads((N/names[0]).read_text());prior=copy.deepcopy(ext['maintenance_ref']);without=copy.deepcopy(ext);without.pop('maintenance_ref')
record={'contract_version':'photo-extension-maintenance-record/v1','record_id':'48h-nape-effect-scope-20261003','maintenance_only':True,'previous_reference':prior,'source_without_reference_sha256':cs.digest(without),'change_kind':'source_supported_property_effect_union','changed_candidate_ids':['sca_h15','sca_h16'],'changed_profile_ids':['sca_h15','sca_h16'],'added_properties':{'sca_h15':'hair.style.nape.layer_length','sca_h16':'hair.style.nape.undercut_length'},'original_effects_preserved':True,'visual_text_and_gates_unchanged':True,'new_provider_calls':0,'limits':['Conventional declared dot paths, not a finite canonical vocabulary.','The two union candidates conservatively lose side-only or crown-only optional use under a nape lock.','No category-wide region protection or pixel-quality claim.']}
ext['maintenance_ref']={'contract_version':'photo-extension-maintenance-ref/v1','record_id':record['record_id'],'sha256':cs.digest(record)}
recordpath=R/'docs/research-evidence/photo-prompt/extension-maintenance'/f"{record['record_id']}.json";assert not recordpath.exists()
manifest=json.loads((N/names[3]).read_text());manifest['created_at']=datetime.datetime.now(datetime.timezone.utc).isoformat()
# Only generated index metadata and current-generation shards are copied. All cached entry bytes were verified unchanged.
for row in manifest['shards']:
 src=N/row['path'];assert hashlib.sha256(src.read_bytes()).hexdigest()==row['sha256'];dst=A/row['path'];dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
(A/names[0]).write_text(json.dumps(ext,ensure_ascii=False,indent=2)+'\n');shutil.copy2(N/names[1],A/names[1]);shutil.copy2(N/names[2],A/names[2]);(A/names[3]).write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n');recordpath.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
shutil.copy2(P/'planned_test_photo_nape_effect_scope.py',R/'tests/test_photo_nape_effect_scope.py')
newdata=pg.load_runtime_data();assert newdata[pg.SEMANTIC_INDEX_DATA_KEY]['entries']==oldindex['entries'];assert newdata[pg.VISUAL_PROFILE_INDEX_DATA_KEY]['entries']==olddata[pg.VISUAL_PROFILE_INDEX_DATA_KEY]['entries']
assert pg.dictionary_hash(newdata)==manifest['dictionary_hash'];assert cs.digest(record)==ext['maintenance_ref']['sha256'];assert cs.digest(without)==record['source_without_reference_sha256']
report={'applied_utc':manifest['created_at'],'changed_candidate_records':2,'changed_visual_profile_records':2,'new_provider_calls':0,'general_entries_unchanged':len(oldindex['entries']),'visual_entries_unchanged':len(olddata[pg.VISUAL_PROFILE_INDEX_DATA_KEY]['entries']),'maintenance_record':str(recordpath.relative_to(R)),'new_registry_sha256':pg.visual_profile_registry_sha256(newdata[pg.VISUAL_OBLIGATIONS_DATA_KEY]),'new_dictionary_hash':pg.dictionary_hash(newdata),'index_created_at':'new cached-index build timestamp; no new embeddings'}
(P/'undercut-trial-v2/production-application.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
