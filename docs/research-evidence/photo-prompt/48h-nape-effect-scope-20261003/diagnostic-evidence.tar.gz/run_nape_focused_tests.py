from pathlib import Path
import subprocess,json,time
P=Path(__file__).resolve().parent;R=P.parent/'image-prompt';O=P/'undercut-trial-v2/final-focused-tests';O.mkdir(exist_ok=True);out=[]
names=['test_photo_nape_effect_scope.py','test_photo_subculture_appearance_alternatives.py','test_photo_subculture_appearance_boundary_history.py','test_photo_core_retrieval.py','test_photo_visual_profile_retrieval.py','test_photo_composer_view.py','test_photo_candidate_semantics.py','test_photo_semantic_index.py']
for n in names:
 t=time.monotonic();p=subprocess.run(['python','-m','unittest','discover','-s','tests','-p',n],cwd=R,capture_output=True,text=True,timeout=600);(O/(n+'.log')).write_text(p.stdout+p.stderr);out.append({'test_file':n,'returncode':p.returncode,'seconds':round(time.monotonic()-t,3)});print(n,p.returncode,flush=True);(O/'results.json').write_text(json.dumps(out,indent=2)+'\n')
