import os,sys
from pathlib import Path
sys.dont_write_bytecode=True
def guard(event,args):
    reason=None
    if event.startswith("socket."): reason="Network socket blocked in offline V12 validation"
    if event=="open" and isinstance(args[0],(str,bytes,os.PathLike)) and Path(os.fsdecode(args[0])).name==".env": reason="Credential file read blocked"
    if reason:
        with open(os.environ["V12_GUARD_LOG"],"a") as log: log.write(event+": "+reason+"\n")
        raise RuntimeError(reason)
sys.addaudithook(guard)
