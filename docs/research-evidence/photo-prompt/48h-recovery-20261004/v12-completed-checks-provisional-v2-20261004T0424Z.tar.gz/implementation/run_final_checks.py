"""Offline final checks with explicit command and source-identity receipts."""
import argparse,hashlib,json,os,subprocess,sys,time
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('stage',choices=['focused','affected','full']);a=p.parse_args()
O=Path(__file__).parent;R=Path('/workspace/scratch/ce8f20680f5a/image-prompt-v12-work');D=R/'docs/research-evidence/photo-prompt/architecture-zero-delta-20261004'
sha=lambda b:hashlib.sha256(b).hexdigest()
env={k:v for k,v in os.environ.items() if not any(x in k.upper() for x in ['TOKEN','API_KEY','SECRET','CREDENTIAL'])};env.update(GEMINI_API_KEY='',GOOGLE_API_KEY='',PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=str(O/'guard'),V12_GUARD_LOG=str(O/'guard-attempts.log'))
if a.stage=='focused':cmd=[sys.executable,'-m','unittest','tests.test_photo_current_boundary_snapshot','tests.test_photo_nape_metadata_boundary_history','tests.test_photo_latest_metadata_boundary_history','tests.test_photo_architecture_zero_delta_boundary','tests.test_subculture_illustration_photo_boundary','tests.test_subculture_illustration_universal_scene_v3.UniversalSceneCurrentOracleV2Tests','-v']
elif a.stage=='affected':cmd=[sys.executable,'-m','unittest','tests.test_subculture_illustration_photo_boundary','tests.test_subculture_illustration_universal_scene_v3','tests.test_photo_visual_profile_retrieval','-v']
else:cmd=[sys.executable,'-m','unittest','discover','-s','tests','-v']
receipt={'command':cmd,'cwd':str(R),'data_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'proof_sha256':sha((D/'V12-zero-delta-proof.json').read_bytes()),'validator_sha256':sha((R/'skills/subculture-illustration-image-generator/scripts/validate_illustration_assets.py').read_bytes()),'started_unix':time.time(),'network_and_credential_file_guard_sha256':sha((O/'guard/sitecustomize.py').read_bytes())}
(O/(a.stage+'-final.start.json')).write_text(json.dumps(receipt,indent=2)+'\n')
with (O/(a.stage+'-final.log')).open('w') as out:cp=subprocess.run(cmd,cwd=R,env=env,stdout=out,stderr=subprocess.STDOUT)
receipt.update(returncode=cp.returncode,elapsed_seconds=round(time.time()-receipt['started_unix'],3),log_sha256=sha((O/(a.stage+'-final.log')).read_bytes()),proof_unchanged=receipt['proof_sha256']==sha((D/'V12-zero-delta-proof.json').read_bytes()),validator_unchanged=receipt['validator_sha256']==sha((R/'skills/subculture-illustration-image-generator/scripts/validate_illustration_assets.py').read_bytes()))
(O/(a.stage+'-final.result.json')).write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2),flush=True);sys.exit(cp.returncode)
