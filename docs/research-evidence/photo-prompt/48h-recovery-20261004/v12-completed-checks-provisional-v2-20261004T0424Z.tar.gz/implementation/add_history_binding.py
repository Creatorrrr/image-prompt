from pathlib import Path
p=Path('/workspace/scratch/ce8f20680f5a/image-prompt-v12-work/skills/subculture-illustration-image-generator/scripts/validate_illustration_assets.py');s=p.read_text();needle='    transition = baseline.get("zero_pack_delta_transition")';s=s.replace(needle,'''    _require(all(_sha256(repo_root / path) == digest
                 for path, digest in proof["immutable_history"].items()),
             "photo V12 immutable historical artifact drift")
    old_descriptor_path = evidence_dir / "universal_scene_baseline_v2.before.json"
    _require(_sha256(old_descriptor_path) == proof["universal_v2_before_sha256"],
             "photo V12 universal descriptor archive drift")
    old_descriptor = old_descriptor_path.read_bytes()
    old_validator_sha = proof["previous_validator_sha256"].encode("ascii")
    _require(old_descriptor.count(old_validator_sha) == 1
             and (asset_dir / "universal_scene_baseline_v2.json").read_bytes()
             == old_descriptor.replace(old_validator_sha, _sha256(Path(__file__)).encode("ascii"), 1),
             "photo V12 universal descriptor changed beyond validator hash")
'''+needle);p.write_text(s)
