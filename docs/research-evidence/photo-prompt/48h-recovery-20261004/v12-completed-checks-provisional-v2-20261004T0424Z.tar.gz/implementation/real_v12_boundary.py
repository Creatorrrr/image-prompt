import hashlib,json,sys,time
from pathlib import Path
R=Path('/workspace/scratch/ce8f20680f5a/image-prompt-v12-work');O=Path(__file__).parent;S=R/'skills/subculture-illustration-image-generator/scripts';sys.path.insert(0,str(S))
import validate_illustration_assets as v
A=S.parent/'assets';start=time.time();result={'mocking':False,'default_dispatch':v.validate_photo_regression_baseline(A),'validator_sha256':hashlib.sha256(Path(v.__file__).read_bytes()).hexdigest(),'proof_sha256':v.PHOTO_V12_ZERO_DELTA_PROOF_SHA256}
try:v.validate_photo_regression_baseline(A,baseline_version=11)
except v.ValidationFailure as e:
 assert str(e)=='photo metadata successor DATA source bytes drift';result['explicit_v11_after_source']={'status':'rejected','reason':str(e)}
else:raise AssertionError('V11 accepted new DATA')
result['elapsed_seconds']=round(time.time()-start,3);(O/'real-final-boundary.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2),flush=True)
