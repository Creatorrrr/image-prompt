import hashlib,json,shutil,subprocess
from pathlib import Path
R=Path('/workspace/scratch/ce8f20680f5a/image-prompt-v12-work');O=Path(__file__).parent;Q=O.parent/'new-architecture-qualification';B=Q/'runs/integrated-0efc2dfde7de-001/boundary';A=R/'skills/subculture-illustration-image-generator/assets';S=R/'skills/subculture-illustration-image-generator/scripts/validate_illustration_assets.py';D=R/'docs/research-evidence/photo-prompt/architecture-zero-delta-20261004';D.mkdir(exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
write=lambda p,x:p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
proposal=json.loads((Q/'proposal.json').read_bytes());previous=json.loads((A/'photo_regression_baseline_v11.json').read_bytes())
pack=(B/'before/frozen-v11-pack.json').read_bytes();assert sha(pack)==previous['sha256'];assert pack==(B/'after/frozen-v11-pack.json').read_bytes();(A/'photo_regression_baseline_v11_pack.json').write_bytes(pack)
for old,new in [(O/'palace-before.json',D/'palace-before.json'),(A/'universal_scene_baseline_v2.json',D/'universal_scene_baseline_v2.before.json'),(Q/'proposal.json',D/'two-alias-proposal.json'),(O/'local-index-receipt.json',D/'production-index-verification.json'),(B/'frozen-pack-comparison.json',D/'production-boundary-comparison.json')]:shutil.copyfile(old,new)
# Inventory all top-level authored JSON DATA and index manifests. Active vector
# shards remain transitively bound by the unchanged semantic-index manifest.
source_assets=R/Path(previous['command'][1]).parent.parent/'assets'
after={p.name:sha(p.read_bytes()) for p in sorted(source_assets.glob('*.json'))}
before=dict(after);before['photo_prompt_visual_obligations_palace_fortification.json']=proposal['source_file_sha256'];before['photo_prompt_visual_profile_index.json']=previous['metadata_only_transition']['source_files'][str(source_assets.relative_to(R)/'photo_prompt_visual_profile_index.json')]
write(O/'source-inventory.json',{'before':before,'after':after})
write(O/'immutable-history-before.json',{str(p.relative_to(R)):sha(p.read_bytes()) for p in sorted(A.glob('*')) if p.is_file() and (p.name.startswith('photo_regression_baseline_') and p.name!='photo_regression_baseline_v11_pack.json' or p.name.startswith('universal_scene_') and p.name!='universal_scene_baseline_v2.json')})
print('Prepared immutable source/history archives',len(after),'source files')
