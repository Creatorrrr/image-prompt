"""Independent negative-only probes; all mutations live in reviewer-owned temp copies."""
import copy,hashlib,json,sys
from pathlib import Path
ROOT=Path('/workspace/scratch/ce8f20680f5a/image-prompt-v12-work');OUT=Path('/workspace/scratch/ce8f20680f5a/data-progress-48h-recovery-20261004/qualification-independent-review/v12-review');sys.path.insert(0,str(ROOT))
from tests import test_photo_architecture_zero_delta_boundary as fixture
v=fixture.v;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();rows=[]
for attack in ['changed_approved_alias_material','changed_index_retrieval_policy']:
 c=fixture.ArchitectureZeroDeltaBoundaryTests('test_same_two_alias_scope_cannot_self_authorize_different_wording');c.setUp()
 try:
  repo,source=c.sandbox_sources();c.direct(repo=repo)
  proof=copy.deepcopy(c.proof);evidence=repo/fixture.EVIDENCE
  if attack=='changed_approved_alias_material':
   edit=proof['alias_edits'][0];before=edit['new_value'];assert '돌 리브' in before;edit['new_value']=before.replace('돌 리브','나무 리브',1)
   f=repo/source/'photo_prompt_visual_obligations_palace_fortification.json';raw=f.read_bytes();old=json.dumps(before,ensure_ascii=False).encode();new=json.dumps(edit['new_value'],ensure_ascii=False).encode();assert raw.count(old)==1;f.write_bytes(raw.replace(old,new,1));proof['source_inventory_after'][f.name]=sha(f)
   prop=evidence/'two-alias-proposal.json';p=json.loads(prop.read_text());p['edits']=proof['alias_edits'];prop.write_text(json.dumps(p,ensure_ascii=False));proof['qualification_artifacts'][prop.name]=sha(prop)
  else:
   f=repo/source/'photo_prompt_visual_profile_index.json';idx=json.loads(f.read_text());before=idx['retrieval_policy']['candidate_limit'];idx['retrieval_policy']['candidate_limit']=before+1;f.write_text(json.dumps(idx,ensure_ascii=False,indent=2)+'\n');proof['source_inventory_after'][f.name]=sha(f);proof['after_source_files'][str(source/f.name)]=sha(f)
   receipt=evidence/'production-index-verification.json';p=json.loads(receipt.read_text());p['index_sha256']=sha(f);receipt.write_text(json.dumps(p));proof['qualification_artifacts'][receipt.name]=sha(receipt)
  pp=evidence/'V12-zero-delta-proof.json';pp.write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n');c.baseline['zero_pack_delta_transition']['source_files']=copy.deepcopy(proof['after_source_files']);c.baseline['zero_pack_delta_transition']['evidence_sha256']=sha(pp);c.path.write_text(json.dumps(c.baseline))
  row={'attack':attack,'unmutated_control_passed':True,'changed_source_file':str(source/f.name),'actual_mutated_source_hash':sha(f),'declared_mutated_source_hash':proof['source_inventory_after'][f.name],'untrusted_manifest_rehash_matches_actual_mutated_proof':c.baseline['zero_pack_delta_transition']['evidence_sha256']==sha(pp),'unchanged_trusted_registered_proof_hash':v.PHOTO_V12_ZERO_DELTA_PROOF_SHA256,'tampered_proof_hash':sha(pp),'same_two_profile_ids_and_field_paths':[(e['profile_id'],e['field']) for e in proof['alias_edits']]==[(e['profile_id'],e['field']) for e in c.proof['alias_edits']]}
  try:c.direct(repo=repo);row.update(rejected=False,error=None)
  except v.ValidationFailure as exc:row.update(rejected=True,error=str(exc))
  row['expected_registered_identity_rejection']=row['rejected'] and row['error']=='photo V12 immutable proof drift';rows.append(row)
 finally:c.doCleanups()
r={'purpose':'Independently test attacker-controlled source/proof/manifest rehashes against unchanged registered trusted scope','source_edits':False,'negative_only_temp_copies':True,'provider_calls':0,'rows':rows,'all_negatives_rejected_by_trusted_identity':all(r['expected_registered_identity_rejection'] for r in rows)};(OUT/'adversarial-scope-probe.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');print(json.dumps(r,ensure_ascii=False,indent=2));assert r['all_negatives_rejected_by_trusted_identity']
