"""Finalize only completed integrated DATA evidence; do not mix future V12 work."""
import hashlib,json,re,subprocess
from pathlib import Path
O=Path(__file__).resolve().parent.parent;Q=O/'runs/integrated-0efc2dfde7de-001';P=O/'runs/prerelease-001';R=Path('/workspace/scratch/ce8f20680f5a/image-prompt')
load=lambda p:json.loads(Path(p).read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,v):Path(p).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
s=load(Q/'SUMMARY.json');results=load(Q/'results.json')['rows'];mutations=load(Q/'mutation-results.json')['cases'];boundary=load(Q/'boundary/CAUSAL-RESULT.json');tr=load(Q/'test-receipt.json')['arms']
assert s['qualification_criteria_met'] and len(results)==36 and len({(x['case'],x['arm']) for x in results})==36
assert len(tr)==2 and all(t['unittest_exit']==0 and t['dictionary_exit']==0 for t in tr)
assert boundary['default_current_validator']['before']['status']=='pass' and boundary['default_current_validator']['after']['error']=='photo metadata successor DATA source bytes drift'
assert boundary['pack_comparison']['raw_bytes_equal'] and boundary['pack_comparison']['changed_json_leaf_paths']==[]
parity=[]
for row in results:
 d=Q/'outputs'/row['arm']/row['case'];old=P/'outputs'/row['arm']/row['case']
 hashes={}
 for name in ['candidate-pack.json','composed.json','audit.json']:
  assert (d/name).read_bytes()==(old/name).read_bytes();hashes[name]=sha(d/name)
 parity.append({'case':row['case'],'arm':row['arm'],'same_arm_prerelease_bytes_equal':True,'files_sha256':hashes})
write(Q/'INTEGRATED-PRERELEASE-PARITY.json',{'runtime_sha':s['runtime_sha'],'observed_current_executions':36,'all_108_pack_composition_audit_files_equal':True,'rows':parity,'past_results_not_substituted_for_current_execution':True})
counts=[]
for cohort in ['source_guided','independent_synthetic_theme_targeted']:
 for arm in ['before','after']:
  rows=[r for r in results if r['cohort']==cohort and r['arm']==arm]
  counts.append({'cohort':cohort,'arm':arm,'inputs':len(rows),'admission_passes':sum(r['admission']=='pass' for r in rows),'composition_passes':sum(r['audit_status']=='pass' for r in rows)})
focused=[]
for arm in ['before','after']:
 paths=list((Q/'commands').glob('*-'+arm+'-existing-focused-tests.stderr.txt'));assert len(paths)==1
 txt=paths[0].read_text();assert 'Ran 95 tests' in txt and re.search(r'\nOK\s*$',txt)
 focused.append({'arm':arm,'modules':7,'methods':95,'first_run_exit':0,'dictionary_exit':0,'log_sha256':sha(paths[0]),'fixture_staged_before_run':True,'corrective_reruns':0})
afterlog=(Q/'boundary/after/current-and-historical-boundary-tests.stderr.txt').read_text();beforelog=(Q/'boundary/before/current-and-historical-boundary-tests.stderr.txt').read_text()
assert 'Ran 20 tests' in beforelog and re.search(r'\nOK\s*$',beforelog)
assert 'Ran 20 tests' in afterlog and 'FAILED (failures=9, errors=1)' in afterlog
headers=re.findall(r'^(FAIL|ERROR): (\w+) \(([^)]+)\)',afterlog,re.M)
fail_methods={qualified for typ,name,qualified in headers if typ=='FAIL'};error_methods={qualified for typ,name,qualified in headers if typ=='ERROR'}
assert len(fail_methods)==4 and len(error_methods)==1
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==s['runtime_sha']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True).strip()
assert sha(O/'backups/architecture-provisional-final-20261004.tar.gz')=='14d010cbb830ba611af61c317ce443e36dcbb24f02b99327b9992a3e0480adce'
assessment={'status':'integrated_DATA_qualification_complete__production_promotion_blocked_by_existing_V11_source_pin','runtime_sha':s['runtime_sha'],'verified_actual_main_receipt_sha256':sha(Q/'verified-integration-receipt.json'),'actual_integrated_rerun_completed':True,'source_worktree_clean_at_completion':True,'source_installation':False,'publication_by_this_worker':False,'production_promotion_allowed':False,'combined_compatibility_gate_pass':False,'scoped_architecture_summary_pass':s['qualification_criteria_met'],'raw_scoped_summary_sha256':sha(Q/'SUMMARY.json'),'raw_driver_metadata_notice':'SUMMARY.json inherited literal integrated_rerun_required:true is retained unchanged; this actual integrated run completed on the verified merged SHA. It is not a new observation or a promotion grant.','frozen_effective_input_count':18,'current_input_repairs':0,'all_raw_and_normalized_inputs_equal_reviewed_effective_versions':True,'main_CLI_admissions':36,'main_composed_audits':36,'paired_inputs':18,'counts':counts,'main_artifacts_byte_equal_same_arm_prerelease':True,'all_generic_core_ownership_baseline_negative_slot_bundle_invariants_met':True,'new_unique_profile_coverage':0,'real_full_visual_indexes':{'profile_count':1622,'texts_and_vectors_unchanged':True,'pending_embedding_inputs':0,'before_raw_sha256':load(Q/'before-index-receipt.json')['index_sha256'],'after_raw_sha256':load(Q/'after-index-receipt.json')['index_sha256']},'actual_main_selection_modes':['core_bm25f'],'embedding_query_behavior_qualified':False,'valid_old_Korean_recall_tradeoff':{'controls':2,'automatic_target_gates_lost':6,'unchanged_baselines_still_pass':True,'generic_literal_anchors_do_not_restore_pixel_gates':True},'optional_exposure_deltas':[d for d in s['paired_deltas'] if d['optional_added'] or d['optional_removed']],'optional_adoptions':0,'mutations':{'actual_replacement_or_owner_substitutions':8,'expected_literal_anchor_rejections':8,'retained_anchor_contradiction_append_probes':2,'append_probes_passed':2,'general_semantic_contradiction_detection_demonstrated':False},'focused_tests':focused,'boundary':{'actual_frozen_recipe_CLI_runs':2,'additional_real_nested_CLI_runs_in_default_validator':2,'input_repairs':0,'raw_before_sha256':boundary['pack_comparison']['before_raw_sha256'],'raw_after_sha256':boundary['pack_comparison']['after_raw_sha256'],'all_json_leaf_deltas':[],'all_64_candidate_objects_and_order_identical':True,'unchanged_default_current_validator_before':'pass / photo_regression_baseline/v11','unchanged_default_current_validator_after':'fail / photo metadata successor DATA source bytes drift','only_mismatched_v11_pinned_source':'skills/photo-prompt-image-generator/assets/photo_prompt_visual_profile_index.json','existing_exactly_four_binding_change_workflow_does_not_authorize_zero_pack_delta_transition':True,'production_or_snapshot_validator_baseline_changes':0,'boundary_regression_methods_each_arm':20,'before_methods_passed':20,'after_fully_passing_methods':15,'after_failing_methods':4,'after_failure_records_including_subtests':9,'after_error_methods':1,'same_V11_source_pin_causes_all_after_failures':True,'future_V12_implementation_or_tests_included':False},'preserved_environment_failure':{'attempts':1,'stage':'Relocated existing Python initialization before generator code','repair':'Versioned driver supplies original installed PYTHONHOME; exact copied binary, frozen argv and source inputs retained','generation_calls_in_failed_attempt':0},'provider_network_guard_attempts':0,'rendered_images':0,'full_project_suite_run':False,'prerelease_archive_preserved_sha256':'14d010cbb830ba611af61c317ce443e36dcbb24f02b99327b9992a3e0480adce','next_boundary':'Separate reviewed immutable-boundary handling and its tests; preserve current V11 failure and do not treat the scoped DATA pass as overall compatibility.'}
write(Q/'INTEGRATED-ASSESSMENT.json',assessment)
write(Q/'COMPLETION-RECEIPT.json',{'status':assessment['status'],'runtime_sha':s['runtime_sha'],'source_main_clean':True,'data_gate_pass':True,'promotion_gate_pass':False,'assessment_sha256':sha(Q/'INTEGRATED-ASSESSMENT.json'),'scoped_summary_sha256':sha(Q/'SUMMARY.json'),'main_results_sha256':sha(Q/'results.json'),'mutation_results_sha256':sha(Q/'mutation-results.json'),'focused_test_receipt_sha256':sha(Q/'test-receipt.json'),'boundary_causal_result_sha256':sha(Q/'boundary/CAUSAL-RESULT.json'),'boundary_regression_receipt_sha256':sha(Q/'boundary/regression-receipt.json'),'current_vs_prerelease_artifact_parity_sha256':sha(Q/'INTEGRATED-PRERELEASE-PARITY.json'),'all_results_terminal':True})
print(json.dumps(load(Q/'COMPLETION-RECEIPT.json'),indent=2))
