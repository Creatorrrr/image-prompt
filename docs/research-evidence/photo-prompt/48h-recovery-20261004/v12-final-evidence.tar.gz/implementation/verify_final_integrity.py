"""Final receipt over the full frozen source and all terminal test artifacts."""
import argparse,hashlib,json,subprocess
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--output',default='FINAL-INTEGRITY-RECEIPT.json');p.add_argument('--allow-running',action='store_true');a=p.parse_args()
O=Path(__file__).parent;R=Path('/workspace/scratch/ce8f20680f5a/image-prompt-v12-work');D=R/'docs/research-evidence/photo-prompt/architecture-zero-delta-20261004';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_bytes());freeze=load(O/'FINAL-SOURCE-FREEZE.json');proof=load(D/'V12-zero-delta-proof.json');baseline=load(R/'skills/subculture-illustration-image-generator/assets/photo_regression_baseline_v12.json')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();status=subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True)
changed={name:{'expected':digest,'actual':sha(R/name)} for name,digest in freeze['files'].items() if sha(R/name)!=digest}
source=R/Path(baseline['command'][1]).parent.parent/'assets';inventory={p.name:sha(p) for p in source.glob('*.json')};history_changes={name:{'expected':digest,'actual':sha(R/name)} for name,digest in proof['immutable_history'].items() if sha(R/name)!=digest}
assert head==freeze['head'] and status=='' and not changed and inventory==proof['source_inventory_after'] and not history_changes
artifacts={p.name:sha(p) for p in sorted(O.iterdir()) if p.is_file() and (p.name.startswith(('focused-final.','affected-final.','full-final.','real-final-boundary.')) or p.name in ('FINAL-SOURCE-FREEZE.json','runner-receipt-field-clarification.json','compact-palace-regressions.log','local-index-receipt.json','production-index-build.log'))}
for path in sorted(O.iterdir()):
 if path.is_file() and (path.name.startswith(('current-observed-failures-diagnostic.','synthetic-env-diagnostic','synthetic-env-allowed','historical-after-fetch.','historical-object-retrieval.')) or path.name=='guard-attempts.log'):artifacts[path.name]=sha(path)
for relative in ['guard/sitecustomize.py','fixture-only-guard/sitecustomize.py']:
 artifacts[relative]=sha(O/relative)
review_root=O.parent/'qualification-independent-review/v12-review'
for path in sorted(review_root.iterdir()):
 if path.is_file() and path.suffix in ('.json','.txt','.log'):
  artifacts['independent-review/'+path.name]=sha(path)
terminal={name:load(O/(name+'-final.result.json')) if (O/(name+'-final.result.json')).exists() else None for name in ('focused','affected','full')}
continuation=load(O/'continuation/CONTINUATION-SUMMARY.json') if (O/'continuation/CONTINUATION-SUMMARY.json').exists() else None
for path in sorted((O/'continuation').glob('*')):
 if path.is_file() and path.suffix in ('.json','.log'):artifacts[str(path.relative_to(O))]=sha(path)
if not a.allow_running:assert continuation and continuation['all_continuation_modules_terminal'] and not continuation['missing_ids'],'Discovery continuation is incomplete'

if not a.allow_running:assert all(terminal.values()),'Final check batch still running'
receipt={'checkout_head':head,'data_commit':proof['data_commit'],'data_parent':proof['data_parent_commit'],'git_status_clean':True,'frozen_changed_file_count':len(freeze['files']),'all_frozen_changed_file_hashes_match':not changed,'source_json_inventory_count':len(inventory),'source_inventory_exact':inventory==proof['source_inventory_after'],'immutable_history_count':len(proof['immutable_history']),'all_immutable_history_hashes_match':not history_changes,'freeze_sha256':sha(O/'FINAL-SOURCE-FREEZE.json'),'proof_sha256':sha(D/'V12-zero-delta-proof.json'),'final_batch_terminal':bool(all(terminal.values()) and continuation and continuation['all_continuation_modules_terminal']),'discovery_coverage':continuation,'terminal_test_receipts':terminal,'artifact_sha256':artifacts,'guard_attempts':(O/'guard-attempts.log').read_text() if (O/'guard-attempts.log').exists() else '', 'classification':'Integrity receipt only. Test failures/skips must be interpreted from terminal logs and comparison evidence.'}
(O/a.output).write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({k:v for k,v in receipt.items() if k not in ('terminal_test_receipts','artifact_sha256')},indent=2))
