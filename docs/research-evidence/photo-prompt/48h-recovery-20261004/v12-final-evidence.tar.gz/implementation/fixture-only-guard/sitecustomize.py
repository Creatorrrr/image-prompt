"""Two unchanged dummy-.env unit tests only; all sockets/real .env stay blocked."""
import json
import os
import sys
from pathlib import Path
sys.dont_write_bytecode = True
# Capture before the reviewed test deliberately clears its own environment.
ALLOW_ROOT = Path(os.environ['V12_DUMMY_ENV_ROOT']).resolve(strict=True)
ALLOWED_LOG = Path(os.environ['V12_DUMMY_ALLOWED_LOG']).resolve()
BLOCKED_LOG = Path(os.environ['V12_DUMMY_BLOCKED_LOG']).resolve()

def record(path, event, detail):
    with path.open('a', encoding='utf-8') as stream:
        stream.write(json.dumps({'event': event, **detail}) + '\n')

def guard(event, args):
    if event.startswith('socket.'):
        record(BLOCKED_LOG, event, {'reason': 'all network sockets remain prohibited'})
        raise RuntimeError('Network socket blocked in offline V12 fixture validation')
    if event == 'open' and isinstance(args[0], (str, bytes, os.PathLike)):
        path = Path(os.fsdecode(args[0]))
        if path.name == '.env':
            resolved = path.resolve()
            if not resolved.is_relative_to(ALLOW_ROOT):
                record(BLOCKED_LOG, event, {'reason': '.env outside fresh dummy-fixture tree', 'path': str(resolved)})
                raise RuntimeError('Credential-file access outside synthetic fixture tree blocked')
            record(ALLOWED_LOG, event, {'reason': 'reviewed synthetic dummy .env fixture only', 'relative_path': str(resolved.relative_to(ALLOW_ROOT)), 'mode': str(args[1])})
sys.addaudithook(guard)
