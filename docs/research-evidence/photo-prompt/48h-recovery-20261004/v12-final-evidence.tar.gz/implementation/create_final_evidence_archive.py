"""Read-back-verified final evidence package; no live logs or DATA payloads."""
import hashlib,io,json,tarfile
from pathlib import Path
O=Path(__file__).parent;V=O.parent/'qualification-independent-review/v12-review';B=O/'backups';files={}
exclude={'palace-before.json','final-maintenance.patch','v12-maintenance.bundle'}
for p in O.iterdir():
 if p.is_file() and p.name not in exclude and p.suffix in ('.json','.jsonl','.log','.md','.py'):files['implementation/'+p.name]=p
for directory in ('continuation','guard','fixture-only-guard'):
 for p in (O/directory).glob('*'):
  if p.is_file() and p.suffix in ('.json','.jsonl','.log','.py'):files['implementation/'+str(p.relative_to(O))]=p
for p in V.iterdir():
 if p.is_file() and p.suffix in ('.json','.jsonl','.log','.md','.txt','.py'):files['independent-review/'+p.name]=p
sha=lambda b:hashlib.sha256(b).hexdigest();contents={name:p.read_bytes() for name,p in files.items()};manifest={'schema':'v12-final-implementation-evidence-archive/v1','source_head':'62b0ba99960fb580c0f1bc07a17b0e3041a08fc2','data_commit':'cd52f366f0b27ca16a20edef2b64cfea8de07c3a','scope':'Completed implementation validation and independent review evidence. Publication is a separate action. All interrupted attempts, baseline failures and diagnostic corrections remain explicit.','excludes':['runtime copies','DATA/index payloads','temporary fixture directories','existing redundant backups','separately available exact-code Git bundle'],'files':{name:{'sha256':sha(raw),'bytes':len(raw)} for name,raw in contents.items()}};mp=B/'v12-final-evidence.manifest.json';mp.write_text(json.dumps(manifest,indent=2)+'\n');contents['MANIFEST.json']=mp.read_bytes();archive=B/'v12-final-evidence.tar.gz';assert not archive.exists(),'Preserve existing archive; choose a new name for a revision'
with tarfile.open(archive,'w:gz') as t:
 for name,raw in sorted(contents.items()):
  i=tarfile.TarInfo(name);i.size=len(raw);i.mode=0o644;t.addfile(i,io.BytesIO(raw))
with tarfile.open(archive) as t:
 assert set(t.getnames())==set(contents)
 for name,raw in contents.items():assert t.extractfile(name).read()==raw
assert all(p.read_bytes()==contents[name] for name,p in files.items()),'Evidence changed while snapshotting'
receipt={'archive':str(archive),'archive_sha256':sha(archive.read_bytes()),'archive_bytes':archive.stat().st_size,'manifest_sha256':sha(mp.read_bytes()),'member_count':len(contents),'read_back_verified':True,'all_source_evidence_bytes_stable':True,'source_head':manifest['source_head']};(B/'v12-final-evidence.receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
