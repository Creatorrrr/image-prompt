import hashlib,json,re,sys,unittest
from pathlib import Path
R=Path('/workspace/scratch/ce8f20680f5a/image-prompt-v12-work');O=Path('/workspace/scratch/ce8f20680f5a/data-progress-48h-recovery-20261004');D=O/'qualification-independent-review/v12-review';P=O/'v12-implementation';sys.path.insert(0,str(R))
suite=unittest.TestLoader().discover(str(R/'tests'))
def ids(s):
 for x in s:
  if isinstance(x,unittest.TestSuite):yield from ids(x)
  else:yield x.id()
actual=list(ids(suite));saved=json.loads((P/'continuation/DISCOVERY-INVENTORY.json').read_text());original=(P/'full-final.log').read_text();started=re.findall(r'^test\w* \(([^)]+)\) \.\.\.',original,re.M);completed=started[:-1]
checks={'unique_discovered_ids':len(actual)==len(set(actual))==1447,'independent_inventory_matches':actual==saved['inventory_ids'],'original_started_exact_prefix':started==actual[:len(started)],'original_last_method_interrupted':started[-1]==saved['interrupted_method'] and not original.rstrip().endswith(('ok','FAIL','ERROR')),'original_completed_prefix_excludes_last':completed==saved['original_completed_ids'] and len(completed)==1011,'pending_exact_tail':actual[len(completed):]==saved['pending_ids'] and len(saved['pending_ids'])==436,'original_log_hash_matches':hashlib.sha256((P/'full-final.log').read_bytes()).hexdigest()==saved['original_log_sha256']}
r={'scope':'Independent unittest collection only; no tests run in this script','checks':checks,'all_checks_passed':all(checks.values()),'inventory_count':len(actual),'original_methods_started':len(started),'original_methods_completed':len(completed),'pending_count':len(actual)-len(completed),'inventory_ids':actual};(D/'discovery-inventory-verification.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items() if k!='inventory_ids'},indent=2));assert r['all_checks_passed']
