# Reproduce the isolated comparison

The frozen design is `PROTOCOL.md`; `SCOPE-ADDENDUM-20261004.md` authorizes the separate provisional prerelease run. `cases.json` and `mutations.json` are immutable. The original failed adapter/runner versions and all normalized-input attempts are retained as evidence, not hidden by the reusable replay path.

## Files and their roles

- `proposal.json`: exactly two intended alias replacements and original profile/source hashes
- `source-profiles.json`: the two inspected authored profiles
- `freeze_cases.py`, `cases.json`, `mutations.json`: new source-guided requests, honest English baselines, their source-owned facts, and fixed mutations
- `adapter.py`: initial mechanical core/composition/mutation adapter, intentionally preserved unchanged
- `repair_inputs_v2.py`, `repair_inputs_v3.py`: exact first-run repair scripts and failure history
- `repair_schema_for_replay.py`: reusable consolidation of the independently reviewed, existing-fact minimum-content repairs; static equivalence is recorded in `REPLAY-REPAIR-EQUIVALENCE.json`
- `runner.py`: original runner used for first preparation and initial input normalization
- `runner_v2.py`: reviewed index/CLI/audit/test/summary driver with complete-denominator and both-snapshot guards
- `sitecustomize.py`: original offline guard, preserved
- `guards-v2/sitecustomize.py`: offline guard with a narrow logged exception for the existing unit tests' same-snapshot generator subprocess; no socket access is permitted
- `index_receipt.py`: full merged-registry cache preflight and post-build equality verification; the real index builder CLI is a separate recorded command
- `FRESH-EXPECTATIONS.json`: independent synthetic-control expectations fixed before either runtime arm was inspected
- `SOURCE-INSPECTION.json`: historical public scaffolds inspected but never executed, and current source entry points

## Requirements and scope

Use a clean, available source worktree, an existing Python environment capable of running the repository, and roughly 4 GB free for two complete photo-skill/test snapshots plus output headroom. No dependency installation, network operation, credentials, external API, or rendering is part of this procedure. Both snapshots use ordinary independent files, with no link back to source. The source worktree and the user's main checkout are never edited.

The first run used source SHA `776ce8dfa1791c2ec9d13ba21490a7651c2cf2ad` in `/workspace/scratch/ce8f20680f5a/image-prompt-pr5-source`, run ID `prerelease-001`, and mode `prerelease`. Do not reuse an existing run ID for a fresh experiment or overwrite failed attempts. To reproduce the same provisional experiment, choose a new run ID and run from this directory:

```sh
SOURCE=/path/to/clean/pr5-source
SHA=776ce8dfa1791c2ec9d13ba21490a7651c2cf2ad
RUN=prerelease-replay-001
FRESH=/path/to/fresh-architecture-authoring
COMMON="--source $SOURCE --runtime-sha $SHA --run-id $RUN --mode prerelease --fresh-source $FRESH"
PYTHONDONTWRITEBYTECODE=1 python runner.py $COMMON --phase prepare
PYTHONDONTWRITEBYTECODE=1 python runner.py $COMMON --phase inputs
```

The historical current-schema adapter produces preserved minimum-content validation failures in the source-guided inputs. The two fresh cores were accepted without modification. An `inputs` exit status 2 is a retained input failure, not a qualified main result. Inspect it before running the reviewed repair:

```sh
PYTHONDONTWRITEBYTECODE=1 python repair_schema_for_replay.py --run-directory runs/$RUN
PYTHONDONTWRITEBYTECODE=1 python runner_v2.py $COMMON --phase indexes
PYTHONDONTWRITEBYTECODE=1 python runner_v2.py $COMMON --phase runs
PYTHONDONTWRITEBYTECODE=1 python runner_v2.py $COMMON --phase mutations
PYTHONDONTWRITEBYTECODE=1 python runner_v2.py $COMMON --phase tests
PYTHONDONTWRITEBYTECODE=1 python runner_v2.py $COMMON --phase report
```

Use `runner.py` only for `prepare` and initial `inputs`; use `runner_v2.py` for the remaining phases. The reusable repair accepts only the specific reviewed source-guided changes. It stops on a fresh-control or unknown failure. If a newer runtime no longer produces those failures, or produces different ones, preserve the outcome and review a new adapter version rather than forcing old repairs or changing case meaning. The original first-run V2/V3 repair scripts are evidence tied to `prerelease-001`; do not repoint or overwrite them.

The supported repairs are real field changes, not byte no-ops: chapel `subject` and its subject-anchor `prompt_evidence` expand “ribs” to the already-requested “stone ribs” or “timber ribs”; arcade `event` expands to its already-frozen complete first relation. No request bytes, baseline prose, source fact, assertion meaning, camera/light authorship or exclusions change. Each old input and error remains available.

## Actual integrated runtime

The prerelease result never establishes merged-runtime compatibility. For the actual integrated rerun, use a new clean source SHA and run ID with `--mode integrated --integrated-receipt /path/to/verified-receipt.json` on both driver commands. The receipt must contain `pr5_merged: true`, `runtime_sha`, `pr5_merge_sha`, `pr_url`, and `review_complete: true`, based on separately verified merge/review evidence. The runner checks Git ancestry and exact source HEAD; it does not invent a merge receipt or establish GitHub merge status itself. Rebuild both experimental arms on that one SHA.

## Reading the evidence

`SUMMARY.json` requires exactly 36 unique source/fresh arm rows and 18 complete pairs. It distinguishes preserved initial adapter failures from unresolved input failures. Its qualification flag also requires full-index receipts, permitted-only source differences, unchanged code/test trees, generic-duty/slot/bundle parity, all ten mutation runs, actual prompt-content rejection for the eight replacements, and both-arm focused tests plus dictionary validation. The two contradiction-append probes are diagnostic; their outcomes are not a guarantee of arbitrary semantic contradiction detection.

Raw commands retain stdout, stderr, exit status, runtime and script hashes. Main evidence comes from actual generator and composed-audit subprocesses. Existing unit tests may contain their own test doubles; they are reported only as contract regressions, never as the real-cache experiment or semantic-quality evidence. The public CLI's actual retrieval mode must be reported; a genuine cached vector index does not prove that embedding query retrieval ran.

Do not call a pass-count increase photographic quality or natural-query accuracy. Report the two complete old-Korean controls' loss of automatic hard-profile render gates even when their baseline audits pass. All optional candidates remain unselected. There are zero new unique profiles, no rendered images, and no source installation in this task.
