"""Mechanical minimum-content schema repair; retain first input attempts forever."""
import copy,hashlib,json,os,shutil,subprocess,sys
from pathlib import Path
O=Path(__file__).resolve().parent;Q=O/'runs/prerelease-001'
load=lambda p:json.loads(Path(p).read_text())
sha=lambda b:hashlib.sha256(b).hexdigest()
def write(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
original=load(Q/'input-manifest.json');frozen={c['id']:c for c in load(O/'cases.json')['cases']}
out=Q/'input-repairs-v2';out.mkdir(exist_ok=False)
records=list(original['cases']);changes=[];failures=[]
for row in original['initial_failures']:
    name=row['case'];src=Q/'inputs'/name;dest=out/name;shutil.copytree(src,dest)
    core=load(dest/'authorial-core.json');before=copy.deepcopy(core)
    facts=frozen[name]['request_facts']
    if frozen[name]['profile_id']=='pf_rib_vault_chapel':core['subject']=facts[0].split(' intersect')[0]
    else:core['event']=facts[0]
    allowed={'subject'} if frozen[name]['profile_id']=='pf_rib_vault_chapel' else {'event'}
    actual={k for k in core if core[k]!=before[k]};assert actual==allowed
    assert core['source_request']==before['source_request'] and core['baseline_prompt_en']==before['baseline_prompt_en']
    assert core['intent_lock']==before['intent_lock'] and core['semantic_assertions']==before['semantic_assertions']
    write(dest/'authorial-core.json',core)
    env={k:os.environ[k] for k in ('PATH','HOME','LANG') if k in os.environ}
    env.update(PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=str(Q/'runner-source'),ARCH_DENY_ASSETS='1',ARCH_GUARD_LOG=str(out/'guard-attempts.jsonl'))
    cmd=[sys.executable,str(Q/'runner-source/adapter.py'),'normalize','--root',str(Q/'before'),'--input',str(dest)]
    cp=subprocess.run(cmd,env=env,capture_output=True,text=True)
    (dest/'v2-normalize.stdout.txt').write_text(cp.stdout);(dest/'v2-normalize.stderr.txt').write_text(cp.stderr)
    changes.append({'case':name,'fields':{k:{'old':before[k],'new':core[k]} for k in actual},'argv':cmd,'returncode':cp.returncode,'original_core_sha256':sha((src/'authorial-core.json').read_bytes()),'repaired_core_sha256':sha((dest/'authorial-core.json').read_bytes()),'request_baseline_anchors_assertions_unchanged':True})
    if cp.returncode:failures.append({'case':name,'error':cp.stderr});continue
    assert not (out/'guard-attempts.jsonl').exists()
    records.append({**frozen[name],'input_dir':str(dest),'files_sha256':{str(f.relative_to(dest)):sha(f.read_bytes()) for f in dest.rglob('*') if f.is_file()},'input_status':'pass','adapter_version':'mechanical-schema-v2','initial_failure_retained':True})
write(out/'ADAPTER-CHANGES.json',{'kind':'minimum-concrete-content schema repair only','source_file_sha256':sha(Path(__file__).read_bytes()),'changes':changes,'failed_repairs':failures,'candidate_runs_before_this_repair':0})
write(Q/'input-manifest.v2.json',{'cases':records,'initial_failures':original['initial_failures'],'unresolved_input_failures':failures,'frozen_before_candidates':True,'original_manifest_sha256':sha((Q/'input-manifest.json').read_bytes()),'mechanical_repairs':str(out/'ADAPTER-CHANGES.json')})
assert len(records)+len(failures)==18
print('v2 normalized',len(records),'unresolved',len(failures),'first failures retained',len(original['initial_failures']))
if failures:raise SystemExit(2)
