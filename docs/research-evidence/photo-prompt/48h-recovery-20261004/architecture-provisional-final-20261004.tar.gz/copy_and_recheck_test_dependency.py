"""Restore one omitted immutable test dependency, then rerun the exact method.

This repairs snapshot packaging, not production data, runtime, tests or fixtures.
Requires both initial 95-method focused arms to have finished and saved results.
"""
import argparse,hashlib,json,os,re,shutil,subprocess,sys
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--run-directory',required=True);p.add_argument('--source',required=True);a=p.parse_args()
O=Path(__file__).resolve().parent;Q=Path(a.run_directory).resolve();R=Path(a.source).resolve();Q.relative_to(O/'runs')
sha=lambda b:hashlib.sha256(b).hexdigest();load=lambda p:json.loads(Path(p).read_text())
def write(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
receipt=load(Q/'test-receipt.json');assert {x['arm'] for x in receipt['arms']}=={'before','after'} and len(receipt['arms'])==2
rel=Path('docs/research-evidence/photo-prompt/extension-maintenance/photo_prompt_palace_fortification_extension.json')
source=R/rel;original_bytes=source.read_bytes();sha_source=sha(original_bytes)
pin=load(Q/'run-status.json')['runtime_sha'];assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==pin
assert subprocess.check_output(['git','show',pin+':'+str(rel)],cwd=R)==original_bytes
method='tests.test_photo_palace_fortification_semantics.PalaceFortificationSemanticsTests.test_provenance_does_not_enter_runtime_candidate_fields'
# Determine the declared class name from source, never guess a silently empty test.
import ast
module=ast.parse((R/'tests/test_photo_palace_fortification_semantics.py').read_text())
classes=[n.name for n in module.body if isinstance(n,ast.ClassDef) and any(isinstance(m,ast.FunctionDef) and m.name=='test_provenance_does_not_enter_runtime_candidate_fields' for m in n.body)]
assert len(classes)==1;method='tests.test_photo_palace_fortification_semantics.'+classes[0]+'.test_provenance_does_not_enter_runtime_candidate_fields'
out=Q/'test-fixture-repair';out.mkdir(exist_ok=False);rows=[]
for arm in ['before','after']:
    root=Q/arm;target=root/rel;assert not target.exists(),'Preserve unexpected fixture state rather than replacing it'
    target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(original_bytes);assert sha(target.read_bytes())==sha_source
    log_candidates=list((Q/'commands').glob('*-'+arm+'-existing-focused-tests.stderr.txt'));assert len(log_candidates)==1
    initial=log_candidates[0].read_text();assert 'Ran 95 tests' in initial and 'FAILED (errors=1)' in initial and 'FileNotFoundError' in initial and str(rel) in initial
    assert initial.count('ERROR: ')==1 and 'FAIL: ' not in initial and 'test_provenance_does_not_enter_runtime_candidate_fields' in initial
    cmd=[sys.executable,'-m','unittest',method,'-v']
    env={k:os.environ[k] for k in ('PATH','HOME','LANG') if k in os.environ};env.update(PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=str(O/'guards-v2'),ARCH_GUARD_LOG=str(out/'guard-attempts.jsonl'))
    cp=subprocess.run(cmd,cwd=root,env=env,capture_output=True,text=True,timeout=300)
    (out/(arm+'.stdout.txt')).write_text(cp.stdout);(out/(arm+'.stderr.txt')).write_text(cp.stderr)
    rows.append({'arm':arm,'argv':cmd,'returncode':cp.returncode,'actual_one_test_ran':'Ran 1 test' in cp.stderr,'initial_full_module_count':95,'initial_passed_methods':94,'initial_error_methods':1,'initial_error_kind':'missing immutable snapshot test dependency','initial_log_sha256':sha(log_candidates[0].read_bytes()),'corrected_dependency_sha256':sha_source})
    write(out/'SUPPLEMENTAL-TEST-RESULT.json',{'method':method,'dependency':str(rel),'dependency_source_sha256':sha_source,'runtime_sha':pin,'cases':rows,'runtime_test_data_changes':0,'snapshot_packaging_repair':True,'first_suite_results_preserved':True,'pristine_full_suite_pass_claim':False,'all_95_methods_covered_per_arm_after_targeted_repair':len(rows)==2 and all(x['returncode']==0 and x['actual_one_test_ran'] for x in rows)})
    assert cp.returncode==0 and 'Ran 1 test' in cp.stderr
assert not (out/'guard-attempts.jsonl').exists()
print('Both affected provenance methods passed after verified fixture copy; initial 94/95 records remain unchanged')
