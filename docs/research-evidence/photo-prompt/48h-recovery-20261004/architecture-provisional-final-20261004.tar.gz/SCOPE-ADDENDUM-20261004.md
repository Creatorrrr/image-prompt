# Prerelease execution addendum, 2026-10-04

The original design, cases and proposal remain byte-for-byte frozen. A later authorized scope permits an isolated provisional same-runtime comparison on published PR5 commit `776ce8dfa1791c2ec9d13ba21490a7651c2cf2ad`, with the original main checkout still held at `b7578916eca10c00fb421a8d6bd73ae0e2d52684`. Use the detached read-only PR5 source worktree only as a copy source. No source installation, main edit or publication is authorized by this addendum.

Both experimental arms must use the same PR5 code. Copy only the complete photo skill and tests into separate ordinary writable snapshot files under this qualification directory; no hardlinks or symlinks back to source and no large historical documentation copy are needed. Apply only the proposed two-alias changes in the after snapshot and build its complete real cached index using the unmodified CLI. All original protocol criteria remain in force.

Any result on this SHA is PROVISIONAL PRERELEASE evidence. An eventual actual merged/integrated SHA requires a new full same-runtime before/after run and compatibility review. This addendum does not establish that PR5 is merged. The first execution stores its runner/adapter source versions and all failures. Mechanical schema changes, if needed, get separate archived versions without changing frozen case meanings or prose.

Fresh raw controls were disclosed only after design and source-guided case freeze. Their separate expectations are in FRESH-EXPECTATIONS.json, fixed before runtime-arm inspection. They are independent synthetic, theme-targeted initial authoring, not natural traffic or target positive-recall samples.
