"""Extend existing subject evidence to two words, preserving all owned facts."""
import copy,hashlib,json,os,shutil,subprocess,sys
from pathlib import Path
O=Path(__file__).resolve().parent;Q=O/'runs/prerelease-001';load=lambda p:json.loads(Path(p).read_text());sha=lambda b:hashlib.sha256(b).hexdigest()
def write(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
previous=load(Q/'input-manifest.v2.json');frozen={c['id']:c for c in load(O/'cases.json')['cases']}
out=Q/'input-repairs-v3';out.mkdir(exist_ok=False);records=list(previous['cases']);changes=[];failures=[]
for row in previous['unresolved_input_failures']:
    name=row['case'];src=Q/'input-repairs-v2'/name;dest=out/name;shutil.copytree(src,dest)
    core=load(dest/'authorial-core.json');before=copy.deepcopy(core)
    anchor=next(a for a in core['intent_lock']['semantic_anchors'] if a['anchor_id']=='subject');assert anchor['prompt_evidence']=='ribs'
    anchor['prompt_evidence']=core['subject'];assert anchor['prompt_evidence'] in core['baseline_prompt_en']
    assert core['source_request']==before['source_request'] and core['baseline_prompt_en']==before['baseline_prompt_en'] and core['semantic_assertions']==before['semantic_assertions']
    write(dest/'authorial-core.json',core)
    env={k:os.environ[k] for k in ('PATH','HOME','LANG') if k in os.environ};env.update(PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=str(Q/'runner-source'),ARCH_DENY_ASSETS='1',ARCH_GUARD_LOG=str(out/'guard-attempts.jsonl'))
    cmd=[sys.executable,str(Q/'runner-source/adapter.py'),'normalize','--root',str(Q/'before'),'--input',str(dest)]
    cp=subprocess.run(cmd,env=env,capture_output=True,text=True)
    (dest/'v3-normalize.stdout.txt').write_text(cp.stdout);(dest/'v3-normalize.stderr.txt').write_text(cp.stderr)
    changes.append({'case':name,'field':'intent_lock.semantic_anchors[anchor_id=subject].prompt_evidence','old':'ribs','new':anchor['prompt_evidence'],'argv':cmd,'returncode':cp.returncode,'request_baseline_assertions_owned_meaning_unchanged':True})
    if cp.returncode:failures.append({'case':name,'error':cp.stderr});continue
    assert not (out/'guard-attempts.jsonl').exists()
    records.append({**frozen[name],'input_dir':str(dest),'files_sha256':{str(f.relative_to(dest)):sha(f.read_bytes()) for f in dest.rglob('*') if f.is_file()},'input_status':'pass','adapter_version':'mechanical-schema-v3','initial_failure_retained':True})
write(out/'ADAPTER-CHANGES.json',{'kind':'minimum-two-content-word subject anchor repair','source_file_sha256':sha(Path(__file__).read_bytes()),'changes':changes,'failed_repairs':failures,'candidate_runs_before_this_repair':0})
write(Q/'input-manifest.v3.json',{'cases':records,'initial_failures':previous['initial_failures'],'v2_failures':previous['unresolved_input_failures'],'unresolved_input_failures':failures,'frozen_before_candidates':True,'previous_manifest_sha256':sha((Q/'input-manifest.v2.json').read_bytes()),'mechanical_repairs':str(out/'ADAPTER-CHANGES.json')})
print('v3 normalized',len(records),'unresolved',len(failures))
if failures:raise SystemExit(2)
