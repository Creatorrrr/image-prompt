from pathlib import Path
import hashlib,json

root=Path('.')
def sha(b): return hashlib.sha256(b).hexdigest()
def write_json(p,o): p.write_text(json.dumps(o,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def anchor(i,source,dimension,evidence,target=None,prop=None):
 a={'anchor_id':i,'source_text':source,'dimension':dimension,'prompt_evidence':evidence}
 if target: a.update(target=target,property=prop)
 return a

prompts={
'stone_reading_hall': "A realistic architectural photograph of a reading hall, with intersecting stone ribs overhead and a quiet seating area at the far end. The architecture holds the frame's attention: slender pale ribs rise from the side piers, cross above the central aisle, and repeat toward the distant wall. From just inside one side of the entrance, the view follows this rhythm into depth. Natural light enters through tall side windows, grazing the limestone surfaces and settling into broad, soft pools across the floor. At the far end, two low oak chairs and a small table occupy a shallow recess beside the last window. A pair of reading tables and a low book ledge establish the hall's everyday use while remaining subordinate to its structure. Fine stone joints, softened chair edges, and gently shaded vaults give the room a tangible scale. The small seating destination and generous intervals of floor create a calm, welcoming interior. Photograph it with measured verticals, natural color, and clear detail from the nearest rib to the far recess.",
'coastal_arcaded_guesthouse': "A realistic architectural photograph looking through a two-level arcaded guesthouse toward an open courtyard in a small coastal town. A deep ground-floor arch frames the near edge of the view. Across the courtyard, limestone arches form two stacked arcades, and simple timber railings run along the upper gallery. Pale apricot plaster surrounds the stonework, its subdued color carrying gently into the shaded passage. The courtyard lies open between the arcaded wings. Morning sunlight reaches its paving while reflected light keeps the lower gallery legible; the upper arches retain a clear rhythm against the sky. A cane chair drawn slightly away from a small table, a folded cloth, and a pot of rosemary give the space a relaxed everyday feel. Tiled roofs and a thin blue glimpse of sea appear through a side opening. Use a slightly off-center standing viewpoint that separates the foreground arch, open court, and two visible levels. Preserve natural material texture and soft tonal transitions, letting the layered architecture remain the first impression."
}

specs={
'stone_reading_hall':{
 'intent':"The synthetic requester wants a calm, welcoming reading hall led by its stone-rib structure and a quiet destination at the far end. My direction connects the large structural rhythm to a small seating recess through soft window light. The off-center view, pale limestone, oak chairs, furniture count, and detailed window placement are editable authorial choices, not requester locks.",
 'subject':'A reading hall with intersecting stone ribs overhead',
 'setting':'A naturally lit reading-hall interior with a quiet seating area at its far end',
 'event':'The hall extends beneath intersecting ribs to a quiet seating area at its far end',
 'priorities':['Intersecting overhead ribs establish the hall\'s primary structural rhythm.','Repeated bays lead into depth toward a small seating destination.','Natural window light makes the stone volume readable and welcoming.','Reading furniture remains subordinate to the architecture.'],
 'resolution':'A reading hall is an interior for reading; intersecting stone ribs are crossing overhead structural members. The quiet seating area must remain at the far end, and natural illumination, calm welcome, and architecture-led attention govern the image. The request does not exclude people or prescribe camera height, furniture count, exact stone type, or a historical period.',
 'anchors':[
 anchor('core_concept','realistic architectural photograph','concept','A realistic architectural photograph'),
 anchor('core_subject','reading hall','subject','a reading hall'),
 anchor('core_event','a quiet seating area at the far end','event','a quiet seating area at the far end'),
 anchor('ribs_geometry','intersecting stone ribs overhead','appearance','intersecting stone ribs overhead','hall','vault.ribs.geometry'),
 anchor('ribs_material','stone ribs','material','stone ribs','hall','vault.ribs.material'),
 anchor('light_source','natural light','lighting','Natural light','hall','illumination.source'),
 anchor('room_mood','calm and welcoming','atmosphere','a calm, welcoming interior','hall','mood'),
 anchor('architectural_priority','architecture as the main subject','composition',"The architecture holds the frame's attention",'image','hierarchy.primary'),
 anchor('photographic_style','realistic architectural photograph','style','A realistic architectural photograph','image','representation')
 ],
 'features':[
 ('feature.location','explicit_request','reading hall',None,'The reading-hall function gives the stone interior a legible everyday purpose.','a reading hall'),
 ('feature.primary_object','explicit_request','intersecting stone ribs overhead',None,'The crossing ribs are the principal visible architectural form.','intersecting stone ribs overhead'),
 ('feature.spatial_depth','explicit_request','a quiet seating area at the far end',None,'The destination must read as distant within the same interior.','a quiet seating area at the far end'),
 ('feature.mood','explicit_request','calm and welcoming',None,'The requested emotional register is carried by an inviting destination and generous space.','a calm, welcoming interior'),
 ('feature.lighting_source','explicit_request','natural light',None,'Daylight reveals the ribs and volume while preserving the requested illumination.','Natural light enters through tall side windows'),
 ('feature.environmental_details','agent_visual_choice',None,None,'Sparse traces of use make the room tangible without competing with its structure.','Fine stone joints, softened chair edges, and gently shaded vaults'),
 ('feature.visual_hierarchy','explicit_request','architecture as the main subject',None,'Architecture must be the first impression rather than its supporting furniture.',"The architecture holds the frame's attention")
 ],
 'style':['architectural photography','quiet spatial editorial',['measured verticals','natural color','clear detail from the nearest rib to the far recess']]
},
'coastal_arcaded_guesthouse':{
 'intent':'The synthetic requester wants a photographic through-building view of a two-level arcaded coastal guesthouse and an open court, with specified materials and an everyday atmosphere. My direction places a shaded arch close to the viewer and lets the opposite two stacked arcades resolve in luminous depth. The morning light, exact standing height, chair, cloth, plant, roof and sea glimpse are editable authorial choices; people remain optional.',
 'subject':'A two-level arcaded guesthouse with pale apricot plaster, limestone arches, and simple timber railings',
 'setting':'An open courtyard within a guesthouse in a small coastal town',
 'event':'A through-building view reveals an open courtyard and both arcaded levels',
 'priorities':['A foreground opening leads the eye through the building into the courtyard.','Both stacked arcades remain visible and spatially coherent.','Apricot plaster, limestone arches, and timber rails retain distinct material identities.','Small traces of everyday use soften the building\'s ordered geometry.'],
 'resolution':'The request calls for a view through the guesthouse toward its courtyard, with arcades on a two-level building, a small coastal-town setting, specified plaster, arch and railing materials, and a relaxed everyday mood. People are permitted but neither required nor excluded. Exact camera height, time of day, furniture, geography, and the individual arch profile are not prescribed.',
 'anchors':[
 anchor('core_concept','realistic architectural photograph','concept','A realistic architectural photograph'),
 anchor('core_subject','two-level arcaded guesthouse','subject','a two-level arcaded guesthouse'),
 anchor('core_event','open courtyard','event','The courtyard lies open between the arcaded wings'),
 anchor('through_view','looking through a two-level arcaded guesthouse toward an open courtyard','camera','looking through a two-level arcaded guesthouse toward an open courtyard','image','viewpoint.direction'),
 anchor('coastal_setting','in a small coastal town','setting','in a small coastal town','guesthouse','location.context'),
 anchor('stacked_arcades','two-level arcaded guesthouse','appearance','two stacked arcades','guesthouse','arcades.levels'),
 anchor('plaster_color','pale apricot plaster','color','Pale apricot plaster','guesthouse','plaster.color'),
 anchor('arch_material','limestone arches','material','limestone arches','guesthouse','arches.material'),
 anchor('railing_material','timber railings','material','timber railings','guesthouse','railings.material'),
 anchor('railing_design','simple timber railings','appearance','simple timber railings','guesthouse','railings.design'),
 anchor('everyday_mood','relaxed everyday feel','atmosphere','a relaxed everyday feel','courtyard','mood'),
 anchor('photographic_style','realistic architectural photograph','style','A realistic architectural photograph','image','representation')
 ],
 'features':[
 ('feature.location','explicit_request','in a small coastal town',None,'The coastal town situates the guesthouse beyond generic architecture.','in a small coastal town'),
 ('feature.primary_object','explicit_request','two-level arcaded guesthouse',None,'Both arcaded levels need a readable structural form.','a two-level arcaded guesthouse'),
 ('feature.spatial_depth','explicit_request','looking through a two-level arcaded guesthouse toward an open courtyard',None,'A through-view gives the requested courtyard its spatial relationship to the building.','looking through a two-level arcaded guesthouse toward an open courtyard'),
 ('feature.mood','explicit_request','relaxed everyday feel',None,'The guesthouse should feel lived in and easygoing.','a relaxed everyday feel'),
 ('feature.environmental_details','agent_visual_choice',None,None,'A few ordinary objects soften the ordered architecture while remaining replaceable.','A cane chair drawn slightly away from a small table, a folded cloth, and a pot of rosemary'),
 ('feature.color','explicit_request','pale apricot plaster',None,'The requested plaster color creates a restrained material identity.','Pale apricot plaster'),
 ('feature.light_quality','agent_visual_choice',None,None,'Reflected daylight connects the shaded passage to the brighter court without obscuring a level.','reflected light keeps the lower gallery legible')
 ],
 'style':['architectural photography','observational courtyard editorial',['natural material texture','soft tonal transitions','layered architecture']]
}}

catalog_sha=sha((root/'visual_feature_catalog.frozen.json').read_bytes())
for key,raw_prompt in prompts.items():
 d=root/key;s=specs[key];prompt=' '.join(raw_prompt.split())
 request=(d/'request.txt').read_text();env=json.loads((d/'request_envelope.json').read_text());controls=json.loads((d/'creative_controls.json').read_text())
 core={
 'contract_version':'photo-authorial-core/v3','provenance':'agent_prepack','source_request':request,
 'creative_controls_sha256':controls['canonical_sha256'],'interpreted_intent':s['intent'],
 'subject':s['subject'],'setting':s['setting'],'event':s['event'],'visual_priorities':s['priorities'],
 'baseline_prompt_en':prompt,'user_definitions':[],
 'interpretation_provenance':[{'term':'architectural request in context','source_text':request,'basis':'request_context','resolution':s['resolution'],'sources':[]}],
 'unresolved_ambiguities':[],'user_exclusions':[],'runtime_forbidden_labels':[],
 'intent_lock':{'contract_version':'photo-intent-lock/v2','priority':'requesting_user','semantic_anchors':s['anchors'],'locked_dimensions':['concept','subject','event'],
 'open_dimensions':['identity','count','appearance','setting','relationship','style','format','framing','composition','lighting','camera','color','material','timing','atmosphere']},
 'semantic_assertions':[{'assertion_id':'primary_environment','dimension':'subject','polarity':'required','source_span_ids':['topic'],'affected_dimensions':['subject'],'axes':{'subject_category':'environment'},'evidence':{'subject_phrase':'a reading hall' if key=='stone_reading_hall' else 'a two-level arcaded guesthouse'}}],
 'request_lineage':None,'style':{'domain':s['style'][0],'family':s['style'][1],'evidence':s['style'][2]},'variation_key':'synthetic_initial_'+key
 }
 for a in s['anchors']:
  assert a['source_text'] in request,(key,a)
  assert a['prompt_evidence'] in prompt,(key,a)
 assert 48 <=len(prompt.split())<=360
 (d/'baseline_prompt_en.txt').write_bytes(prompt.encode())
 write_json(d/'authorial_core.raw.json',core)
 selected=[]
 for cat,basis,source,derivation,reason,evidence in s['features']:
  assert evidence in prompt
  if source: assert source in request
  selected.append({'category_id':cat,'basis':basis,'source_span_ids':['topic'] if basis!='agent_visual_choice' else [],'source_text':source,'derivation':derivation,'reason':reason,'baseline_evidence':evidence})
 write_json(d/'precore_feature_selection.json',{'contract_version':'photo-precore-feature-selection/v1','request_id':env['request_id'],'active_span_ids':['topic'],'catalog_path':'skills/photo-prompt-image-generator/precore/visual_feature_catalog.json','catalog_schema_version':'photo-precore-feature-catalog/v1','catalog_sha256':catalog_sha,'request_sha256':env['request_sha256'],'baseline_prompt_sha256':sha(prompt.encode()),'selected':selected})
 write_json(d/'embodiment_review.json',{'contract_version':'photo-embodiment-review/v1','provenance':'agent_prepack','prompt_sha256':sha(prompt.encode()),'scope':'not_applicable','summary':'An architectural environment is the primary subject. This authored baseline prescribes no human or animal bodily action, consequential contact, hidden appendage, or articulated body mechanism. Supporting people remain an open option under the synthetic requests, not a prohibition.','checks':{}})
 write_json(d/'initial_authorial_rationale.json',{'synthetic':True,'chosen_direction':s['intent'],'controls_applied':{'creativity':1,'surreal':0,'sensual_effective':0,'fetish_effective':0,'adult_emphasis':'inactive','explanation':'Saved defaults were resolved once before baseline authorship. The primary subject is nonhuman architecture; the resolver makes both adult axes effectively zero. Explicit no_people and explicit_nonsexual are both false.'},'prompt_word_count':len(prompt.split()),'request_owned_vs_authorial':'Only exact request-grounded dimensions/properties are anchored. Furniture, geometry refinements, additional visible setting cues, photographic mechanics, and supporting details are editable unless a specific source phrase anchors that property. Mandatory concept/subject/event fields use the minimal requested visible state.','uncertainty':'The neutral JSON follows only the schema information printed in SKILL.md. No private schema, candidate, test, or audit script was inspected or executed, so downstream implementation compatibility is unverified. Optional human presence is not locked. No image or user-preference validation exists.'})
 print(key,'words',len(prompt.split()),'prompt_sha256',sha(prompt.encode()),'core_bytes_sha256',sha((d/'authorial_core.raw.json').read_bytes()))
