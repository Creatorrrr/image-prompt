"""External fail-closed execution guard. Never copied into production source."""
import json,os,sys
from pathlib import Path
sys.dont_write_bytecode=True

def hook(event,args):
    reason=None
    if event.startswith('socket.'):
        reason='All socket operations are prohibited in this offline qualification'
    if event=='subprocess.Popen':
        reason='Nested subprocesses require a separately reviewed runner command'
    if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
        p=Path(os.fsdecode(args[0])).absolute()
        if p.name=='.env':reason='Credential file access is prohibited'
        if os.environ.get('ARCH_DENY_ASSETS')=='1' and 'photo-prompt-image-generator/assets/' in str(p):
            reason='Candidate DATA is unavailable during mechanical input normalization'
    if reason:
        path=os.environ.get('ARCH_GUARD_LOG')
        if path:
            with open(path,'a',encoding='utf-8') as f:f.write(json.dumps({'event':event,'reason':reason})+'\n')
        raise RuntimeError(reason)
sys.addaudithook(hook)
