# Two Korean architecture aliases: new provisional revalidation

## Result and release boundary

The two proposed strings are retained unchanged. A new, frozen same-runtime comparison on PR5 prerelease SHA `776ce8dfa1791c2ec9d13ba21490a7651c2cf2ad` supports the intended conservative exact-trigger correction in the bounded cases below. This is **provisional evidence, not permission to install or publish the change**. Main remains clean at `b7578916eca10c00fb421a8d6bd73ae0e2d52684`; the read-only PR5 source is also clean. A new same-runtime before/after run is still required on the actual integrated SHA.

Both targets were previously inspected in the older all34 audit. This work adds **zero new unique-profile coverage**. Lost experiments were not recovered, repeated from memory, or treated as verified. Historical public archive members were inspected only as schema/scaffolding references; their scripts and results were not imported into this experiment.

## Why these two fields

Only `activation.exact_terms[1]` changes for `pf_rib_vault_chapel` and `pf_venetian_arcade` in `photo_prompt_visual_obligations_palace_fortification.json`.

- Chapel: the old Korean phrase did not require stone ribs, explicit chapel identity, or pointed openings beside the connected supports. The unchanged English definition/components require those facts. The new Korean string supplies them while retaining wall-side continuity and the distinct worship end
- Arcade: the old Korean phrase omitted the water-facing lower arcade, finer openwork upper gallery, and broad upper wall mass. The new phrase supplies those selected facts and retains the distinct opening rhythm and actual support relationship

English aliases, definitions, component duties, gates, ordinary candidates, runtime and tests remain unchanged. No historical building/era, identity, religion, nationality or ownership inference is added. The exact strings and source hashes are in `proposal.json`; the independent comparison and acceptance criteria were frozen in `PROTOCOL.md` before fresh-control disclosure.

## Actual public CLI results

The same frozen inputs, seed and code were used on both sides. Every row used the unmodified generator CLI followed by the unmodified composed-audit CLI. All optional candidates were declined, and every composed baseline remained unchanged.

| Cohort | Inputs | Before admission | After admission | Before composition | After composition |
|---|---:|---:|---:|---:|---:|
| Source-guided synthetic maintenance cases | 16 | 16/16 | 16/16 | 11/16 | 16/16 |
| Independent synthetic, theme-targeted controls | 2 | 2/2 | 2/2 | 2/2 | 2/2 |

There are exactly **36 unique arm rows and 18 complete pairs**. The five improved cases are old-Korean requests that explicitly specify timber ribs, round-headed openings, a dry inland plaza, a solid enclosed upper gallery, or a narrow low parapet. Those scenes are compatible with the old alias but conflict with one unchanged selected component. Before, the wrong hard duty makes truthful baseline composition fail; after, the unchanged requested scene passes without that duty. Their English counterexamples remain non-hard and pass in both arms.

The two new canonical Korean requests become hard and pass after. The two unchanged exact English positives stay hard and pass in both arms. The independent reading-hall and coastal-guesthouse controls remain non-hard for both targets and retain their original raw cores and baselines. They are separate negative/transfer controls, not representative natural traffic or target-positive recall coverage.

All 18 pairs preserve the normalized core, request ownership, baseline, negative prompt, generic intent/assertion duties, control and embodiment bindings, ordinary retrieval inventory, slot objects and bundles.

## Explicit recall cost

The two complete, valid old-Korean positive controls continue to pass baseline composition, but lose their automatic target hard profile and **three render gates each, six total**. Optional target exposure and literal requester anchors do not restore those pixel-review duties. This result is not a recall improvement and must not be reported as “no regression.” Natural-query recall loss is not estimated by these two constructed controls.

## Real cache/index evidence and retrieval scope

The actual production builder/check CLIs rebuilt each complete 1,622-profile index. Provider/model/dimensions/entry identity and full embedding input text matched the genuine source cache for every profile; all entry texts and vector values remain unchanged. The before rebuild is byte-identical to the original cache. The stale original index is rejected against the after registry.

- Before index SHA-256: `9a279002707290f79ad3b4de646644dfe4146bf4948dd07977e3d16a458482c6`
- After index SHA-256: `eb2b1b5359132de1f0dc62dca074dc71d42d11c17840e35f4cf58c6c879b42f0`

Only the registry hash, two exact lookup rows and generated BM25F change; the two target BM25F documents change, with consequent corpus-statistic/lexicon updates. There is no alias collision. Ordinary data/index bytes remain unchanged. Pending embedding inputs: zero. Observed provider/network guard attempts: zero. No fake vectors were used in the main real-cache CLI experiment; the unchanged unit tests retain their labelled test doubles. Actual public generation reports `core_bm25f`; the real cached vector index does **not** establish embedding-query retrieval coverage.

## Optional collateral is present

Six inputs change optional exposure. In the two arcade cases, only the target changes status: the new canonical Korean target leaves optional exposure for hard status, and the complete old-Korean target returns from hard status to optional exposure. Four chapel inputs additionally change an unrelated, unselected suggestion:

- New canonical Korean: chapel moves from optional to hard; `upper_lip_philtral_contour` enters the optional set
- Complete old Korean: chapel returns to optional; `upper_lip_philtral_contour` leaves it
- Timber Korean: chapel enters optional; `pc_pc16_owner_relation` leaves it
- Round-openings Korean: chapel enters optional; `pc_pc21_owner_relation` leaves it

A separate, read-only helper diagnosis reconstructs these sets from the real full registry/index and confirms displacement at the eight-hit lexical retrieval cap as hard chapel is excluded from or returned to that lane. The first reduced-policy diagnostic and its corrected version are preserved independently. This helper is not an additional public CLI case or embedding experiment. None of these alternatives is adopted; ordinary slots and bundles are identical. No aesthetic gain is inferred from exposure changes.

## Actual prompt mutations and the semantic limit

Six fact replacements and two owner-transfer replacements modify actual final prose, refresh truthful mutable evidence and the final non-body review hash, and preserve the immutable pack/core/bindings. All eight fail on the expected `intent_lock_prompt_evidence` anchors. Other metadata/frozen-evidence failures are recorded separately and are not counted as semantic protection.

Both additional probes that **append a contradictory sentence while retaining the original literal evidence pass**. This directly shows the audit's limit. The result does not establish general semantic contradiction detection, restored pixel-gate coverage, or rendered-image fidelity.

## Preserved harness repairs and test results

Before any candidate arm, the first adapter produced 14 source-guided minimum-content failures. A second attempt left seven one-word subject-anchor failures. All initial files/errors remain preserved; no case meaning or baseline was tuned after outcomes.

The reviewed repairs are real field changes: chapel `subject` and subject-anchor `prompt_evidence` expand “ribs” to the already-requested “stone ribs” or “timber ribs”; arcade `event` expands to the complete already-frozen first relation. The source-owned material already appears in relation 1, so the evidence expansion creates no new fact or ownership. Request/baseline bytes and typed assertion meaning stay unchanged. Both independent raw cores normalized without repair.

Each original focused run executed 95 methods across seven modules: **94 passed, one errored** because the isolated snapshot omitted the unchanged maintenance JSON needed by the palace provenance test. Both dictionary validators passed. This is harness packaging, not a PR5 regression. After copying only that exact pinned Git-byte record into both snapshots, the affected method passes in both targeted reruns. Thus all 95 distinct methods have successful aggregate coverage per arm, with two original errors preserved; there is no claim of a pristine full-suite pass or complete-project discovery. The preserved supplemental field named `initial_full_module_count: 95` means methods, not modules.

The original strict `SUMMARY.json` deliberately retains `focused_checks_pass_both_arms: false` and `qualification_criteria_met: false` because those first suite exits were 1. `FINAL-ASSESSMENT.json` separately records the resolved packaging error and complete aggregate coverage; it does not rewrite the initial result or declare production promotion ready. `TEST-DEPENDENCY-NOTE.md` and `stage_test_dependency.py` prevent the packaging omission in a new replay.

## Deliverables and next gate

- Frozen protocol, two-field proposal and source profiles: `PROTOCOL.md`, `proposal.json`, `source-profiles.json`
- Frozen case/mutation meaning and independent-control expectations: `cases.json`, `mutations.json`, `FRESH-EXPECTATIONS.json`
- Reproducible runners and reviewed repairs: `REPRODUCE-v2.md`, `runner.py`, `runner_v2.py`, `adapter.py`, the versioned repair scripts and offline guards
- Full new evidence: `runs/prerelease-001/`, including all initial failures, exact commands, cached-index receipts, public outputs, mutation audits, original focused-suite logs and supplemental method receipts
- Concise machine-readable conclusion: `FINAL-ASSESSMENT.json`

No source installation, fixture tuning, runtime patch, provider call or image generation occurred. These are bounded synthetic maintenance results. The next release gate is a fresh, source-complete same-runtime comparison on the actual integrated runtime, preserving these fixed meanings and explicitly reevaluating the recall tradeoff and unselected collateral.
