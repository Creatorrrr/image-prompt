# Test snapshot dependency correction

The first prerelease runner copied the complete photo skill and test tree, but omitted one immutable research-evidence JSON required by `test_provenance_does_not_enter_runtime_candidate_fields`. This is a packaging defect in the new harness, not a product regression. Its original failed suite logs remain part of the evidence.

For a NEW replay, run the following after `runner.py --phase prepare` and before the focused test phase, using the same `SOURCE` and `RUN` as `REPRODUCE.md`:

```sh
PYTHONDONTWRITEBYTECODE=1 python stage_test_dependency.py --run-directory runs/$RUN --source "$SOURCE"
```

The script copies only `docs/research-evidence/photo-prompt/extension-maintenance/photo_prompt_palace_fortification_extension.json` into each isolated snapshot. It verifies the exact bytes against the pinned source Git object and records hashes. It does not alter the source worktree, test code, runtime, data, case meaning or expected outcome. No historical evidence archive or large docs tree is copied.

For the already-running `prerelease-001`, wait for both initial suites to finish and use `copy_and_recheck_test_dependency.py` instead. That script preserves and verifies the 94 passing methods plus one missing-file error per arm, then runs the exact affected method in both arms. The report must distinguish this aggregate corrected coverage from a pristine full-suite first pass. A complete-project unittest discovery run was not requested or claimed by this scoped qualification.
