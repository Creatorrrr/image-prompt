"""Offline actual-CLI same-runtime experiment. Source checkout is read-only.

Example prerelease execution:
  python runner.py --source /path/to/read-only-pr5 --runtime-sha 776ce8d... \
      --run-id prerelease-001 --mode prerelease --phase prepare
Then inputs, indexes, runs, mutations, tests, report. Every subprocess retains
argv/stdout/stderr/return code. Failures never overwrite source inputs.
"""
import argparse,copy,hashlib,json,os,shutil,subprocess,sys,time
from pathlib import Path
O=Path(__file__).resolve().parent
PARSER=argparse.ArgumentParser();PARSER.add_argument('--source',required=True);PARSER.add_argument('--runtime-sha',required=True)
PARSER.add_argument('--run-id',required=True);PARSER.add_argument('--mode',choices=['prerelease','integrated'],required=True)
PARSER.add_argument('--phase',choices=['prepare','inputs','indexes','runs','mutations','tests','report'],required=True)
PARSER.add_argument('--integrated-receipt');PARSER.add_argument('--fresh-source',default=str(O.parent/'fresh-architecture-authoring'))
A=PARSER.parse_args();R=Path(A.source).resolve();Q=O/'runs'/A.run_id
assert A.run_id and '/' not in A.run_id and '..' not in A.run_id
sha=lambda b:hashlib.sha256(b).hexdigest()
def load(p):return json.loads(Path(p).read_text())
def write(p,x):p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def tree(p):return {str(f.relative_to(p)):sha(f.read_bytes()) for f in sorted(p.rglob('*')) if f.is_file()}
def git(*args):return subprocess.check_output(['git',*args],cwd=R,text=True).strip()
assert git('rev-parse','HEAD')==A.runtime_sha and not git('status','--porcelain'), 'Read-only source must be clean and exactly pinned'
if A.mode=='prerelease':assert A.runtime_sha=='776ce8dfa1791c2ec9d13ba21490a7651c2cf2ad', 'Only the dated prerelease addendum authorizes this SHA'
else:
    receipt=load(A.integrated_receipt)
    assert receipt['pr5_merged'] is True and receipt['runtime_sha']==A.runtime_sha and receipt['review_complete'] is True
    assert receipt.get('pr_url') and receipt.get('pr5_merge_sha')
    subprocess.run(['git','merge-base','--is-ancestor',receipt['pr5_merge_sha'],A.runtime_sha],cwd=R,check=True)
base=Q/'before';after=Q/'after';skill='skills/photo-prompt-image-generator';s=lambda root:root/skill

def run(cmd,label,cwd=None,assets=False,allowed=(0,),timeout=600):
    logs=Q/'commands';logs.mkdir(parents=True,exist_ok=True)
    # Never replace a previous command or failed attempt record.
    n=len(list(logs.glob('*.command.json')))+1;stem=logs/(f'{n:04d}-'+label)
    env={k:os.environ[k] for k in ('PATH','HOME','LANG','LC_ALL','TZ','TMPDIR') if k in os.environ}
    env.update(PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=str(Q/'runner-source'),ARCH_GUARD_LOG=str(Q/'network-or-isolation-attempts.jsonl'))
    if assets:env['ARCH_DENY_ASSETS']='1'
    start=time.time()
    write(str(stem)+'.command.json',{'argv':list(map(str,cmd)),'cwd':str(cwd or Q),'runtime_sha':A.runtime_sha,'mode':A.mode,'network':'denied','credential_environment':'omitted','runner_source_sha256':sha((Q/'runner-source/runner.py').read_bytes())})
    cp=subprocess.run(list(map(str,cmd)),cwd=cwd or Q,env=env,capture_output=True,text=True,timeout=timeout)
    Path(str(stem)+'.stdout.txt').write_text(cp.stdout);Path(str(stem)+'.stderr.txt').write_text(cp.stderr)
    write(str(stem)+'.exit.json',{'returncode':cp.returncode,'seconds':round(time.time()-start,3)})
    if (Q/'network-or-isolation-attempts.jsonl').exists():raise RuntimeError('An isolation operation was attempted; inspect and stop')
    if cp.returncode not in allowed:raise RuntimeError('Command failed: '+str(stem))
    return cp

if A.phase=='prepare':
    Q.mkdir(parents=True,exist_ok=False)
    (Q/'runner-source').mkdir()
    for f in O.glob('*.py'):shutil.copy2(f,Q/'runner-source'/f.name)
    frozen=['PROTOCOL.md','proposal.json','source-profiles.json','DESIGN-FREEZE.json','cases.json','mutations.json','freeze_cases.py','SCOPE-ADDENDUM-20261004.md','FRESH-EXPECTATIONS.json']
    write(Q/'frozen-design-hashes.json',{name:sha((O/name).read_bytes()) for name in frozen})
    initial=tree(s(R));write(Q/'source-photo-skill-hashes.json',initial)
    for dest in [base,after]:
        (dest/'skills').mkdir(parents=True)
        shutil.copytree(s(R),s(dest),symlinks=False,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
        shutil.copytree(R/'tests',dest/'tests',symlinks=False,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
        assert not any(p.is_symlink() for p in dest.rglob('*'))
        assert tree(s(dest))==initial
    file=after/load(O/'proposal.json')['source_file'];source=load(file)
    for edit in load(O/'proposal.json')['edits']:
        profile=next(p for p in source['profiles'] if p['id']==edit['profile_id'])
        assert profile['activation']['exact_terms'][1]==edit['old_value']
        assert sha(json.dumps(profile,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())==edit['source_profile_sha256']
        profile['activation']['exact_terms'][1]=edit['new_value']
    write(file,source)
    write(Q/'run-status.json',{'state':'prepared_only','mode':A.mode,'runtime_sha':A.runtime_sha,'source_checkout':str(R),'provisional':A.mode=='prerelease','requires_integrated_revalidation':True,'source_installation':False})
    print('Snapshots prepared; no indexes or candidate packs generated')
else:
    assert Q.exists()
    for name,h in load(Q/'frozen-design-hashes.json').items():assert sha((O/name).read_bytes())==h,name
    for file in (Q/'runner-source').glob('*.py'):
        assert file.read_bytes()==(O/file.name).read_bytes(), 'Runner source changed: archive a new run/adapter version before proceeding'
    if A.phase=='inputs':
        cases=load(O/'cases.json')['cases'];prepared=[];failures=[]
        for c in cases:
            idir=Q/'inputs'/c['id'];cf=Q/'case-records'/(c['id']+'.json');write(cf,c)
            try:
                run([sys.executable,Q/'runner-source/adapter.py','prepare','--case',cf,'--output',idir],c['id']+'-prepare',assets=True)
                run([sys.executable,s(base)/'precore/creative_controls.py','--request-envelope-json',idir/'request-envelope.json','--context-json',idir/'creative-context.json','--seed','20261004','--output',idir/'creative-controls.json'],c['id']+'-controls',cwd=base,assets=True)
                run([sys.executable,Q/'runner-source/adapter.py','bind','--input',idir],c['id']+'-bind',assets=True)
                run([sys.executable,Q/'runner-source/adapter.py','normalize','--root',base,'--input',idir],c['id']+'-normalize',assets=True)
                prepared.append({**c,'input_dir':str(idir),'files_sha256':tree(idir),'input_status':'pass'})
            except Exception as e:failures.append({'case':c['id'],'error':str(e),'files':tree(idir) if idir.exists() else {}})
        # Preserve the independent raw files byte-for-byte before any adaptation.
        F=Path(A.fresh_source);fm=load(F/'FREEZE_MANIFEST.json')
        assert sha((F/'FREEZE_MANIFEST.json').read_bytes())==load(O/'FRESH-EXPECTATIONS.json')['source_manifest_sha256']
        for name,h in fm['files_sha256'].items():assert sha((F/name).read_bytes())==h
        raw=Q/'fresh-raw';shutil.copytree(F,raw)
        for name in ['stone_reading_hall','coastal_arcaded_guesthouse']:
            src=raw/name;idir=Q/'inputs'/name;idir.mkdir(parents=True)
            mapping={'request_envelope.json':'request-envelope.json','authorial_core.raw.json':'authorial-core.json','creative_controls.json':'creative-controls.json','embodiment_review.json':'embodiment-review.json','baseline_prompt_en.txt':'baseline.txt','request.txt':'request.txt'}
            for old,new in mapping.items():shutil.copy2(src/old,idir/new)
            c={'id':name,'cohort':'independent_synthetic_theme_targeted','profile_id':None,'role':'fresh_negative','request':(idir/'request.txt').read_text(),'baseline_prompt_en':(idir/'baseline.txt').read_text(),'expected':{'before_hard':False,'after_hard':False,'before_audit':'pass','after_audit':'pass'}}
            write(Q/'case-records'/(name+'.json'),c)
            try:
                run([sys.executable,Q/'runner-source/adapter.py','normalize','--root',base,'--input',idir],name+'-initial-normalize',assets=True)
                prepared.append({**c,'input_dir':str(idir),'files_sha256':tree(idir),'input_status':'pass'})
            except Exception as e:failures.append({'case':name,'cohort':c['cohort'],'error':str(e),'raw_preserved':True,'files':tree(idir)})
        write(Q/'input-manifest.json',{'cases':prepared,'initial_failures':failures,'frozen_before_candidates':True})
        print('Inputs normalized:',len(prepared),'failures:',len(failures))
        if failures:raise SystemExit(2)
    elif A.phase=='indexes':
        cache=s(base)/'assets/photo_prompt_visual_profile_index.json'
        for arm,root in [('before',base),('after',after)]:
            extra=['--expect-stale'] if arm=='after' else []
            run([sys.executable,Q/'runner-source/index_receipt.py','preflight','--root',root,'--cache',cache,'--output',Q/(arm+'-cache-preflight.json'),*extra],arm+'-cache-preflight')
            run([sys.executable,s(root)/'scripts/build_visual_profile_index.py','--cache-index',cache,'--batch-size','1'],arm+'-actual-full-index-build',cwd=root,timeout=1200)
            run([sys.executable,s(root)/'scripts/build_visual_profile_index.py','--check'],arm+'-actual-index-check',cwd=root)
            run([sys.executable,Q/'runner-source/index_receipt.py','verify','--root',root,'--cache',cache,'--output',Q/(arm+'-index-receipt.json'),*extra],arm+'-rebuilt-index-verify')
        print('Actual full index CLIs finished; consult saved receipts')
    elif A.phase=='runs':
        im=load(Q/'input-manifest.json');rows=[]
        # All untouched input failures remain explicit. Do not erase them from a
        # claimed full denominator by running only the successfully adapted rows.
        for c in im['cases']:
            idir=Path(c['input_dir'])
            for name,h in c['files_sha256'].items():assert sha((idir/name).read_bytes())==h
            for arm,root in [('before',base),('after',after)]:
                dest=Q/'outputs'/arm/c['id'];dest.mkdir(parents=True,exist_ok=False)
                record={'case':c['id'],'cohort':c['cohort'],'arm':arm,'runtime_sha':A.runtime_sha,'mode':A.mode}
                try:
                    run([sys.executable,s(root)/'scripts/generate_photo_prompt.py','--request-envelope-json',idir/'request-envelope.json','--authorial-core-json',idir/'authorial-core.json','--creative-controls-json',idir/'creative-controls.json','--embodiment-review-json',idir/'embodiment-review.json','--seed','20261004','--output-file',dest/'candidate-pack.json'],c['id']+'-'+arm+'-actual-cli',cwd=root)
                    record['admission']='pass';pack=load(dest/'candidate-pack.json')[0]
                    run([sys.executable,Q/'runner-source/adapter.py','compose','--pack',dest/'candidate-pack.json','--case',Q/'case-records'/(c['id']+'.json'),'--output',dest/'composed.json'],c['id']+'-'+arm+'-compose')
                    cp=run([sys.executable,s(root)/'scripts/audit_composed_prompt.py','--pack',dest/'candidate-pack.json','--composed',dest/'composed.json'],c['id']+'-'+arm+'-actual-audit',cwd=root,allowed=(0,1))
                    audit=json.loads(cp.stdout);write(dest/'audit.json',audit)
                    hard=(pack.get('visual_obligations')or{}).get('obligations',[])
                    record.update(audit_status=audit['status'],failures=audit['failures'],warnings=audit['warnings'],hard_ids=[x['id'] for x in hard],hard_gate_ids=[g['id'] for ob in hard for g in ob.get('render_gates',[])],optional_visual_ids=[x['id'] for x in (pack.get('visual_concept_candidates')or{}).get('candidates',[])],artifact_hashes=tree(dest))
                except Exception as e:record.update(error=str(e),admission=record.get('admission','fail'))
                rows.append(record);write(Q/'results.json',{'rows':rows,'initial_input_failures':im['initial_failures']})
                print(c['id'],arm,record.get('admission'),record.get('audit_status'),record.get('error',''),flush=True)
                if record.get('error'):raise SystemExit(2)
    elif A.phase=='mutations':
        rows=[]
        for d in load(O/'mutations.json')['cases']:
            source=Q/'outputs/after'/d['source_case_id'];assert load(source/'audit.json')['status']=='pass'
            dest=Q/'mutations'/d['id'];dest.mkdir(parents=True,exist_ok=False);write(dest/'definition.json',d)
            run([sys.executable,Q/'runner-source/adapter.py','mutate','--case',dest/'definition.json','--input',source/'composed.json','--output',dest/'composed.json'],d['id']+'-mutate')
            cp=run([sys.executable,s(after)/'scripts/audit_composed_prompt.py','--pack',source/'candidate-pack.json','--composed',dest/'composed.json'],d['id']+'-actual-audit',cwd=after,allowed=(0,1))
            audit=json.loads(cp.stdout);write(dest/'audit.json',audit)
            content=[f for f in audit['failures'] if f['check']=='intent_lock_prompt_evidence']
            affected={f.get('anchor_id') for f in content};expected=set(d['affected_anchor_ids'])
            rows.append({'id':d['id'],'kind':d['kind'],'status':audit['status'],'content_failures':content,'other_failures':[f for f in audit['failures'] if f['check']!='intent_lock_prompt_evidence'],'expected_content_rejections_observed':expected<=affected if d['expected_content_failure'] else None,'definition':d})
        write(Q/'mutation-results.json',{'cases':rows,'rendered_images':0,'semantic_contradiction_detector_claim':False})
    elif A.phase=='tests':
        # Existing unit tests may use their own test doubles. They are contract
        # regression evidence, never the real-index/CLI experiment evidence.
        modules=['tests.test_photo_palace_fortification_semantics','tests.test_photo_palace_korean_relation_alignment','tests.test_photo_visual_profile_retrieval','tests.test_photo_visual_obligations','tests.test_photo_authorial_core_v6','tests.test_photo_core_retrieval','tests.test_photo_embodiment_preflight','tests.test_photo_negative_intent_guard']
        selected=[];missing=[]
        for m in modules:
            if (after/(m.replace('.','/')+'.py')).exists():selected.append(m)
            else:missing.append(m)
        cp=run([sys.executable,'-m','unittest',*selected,'-v'],'existing-focused-tests',cwd=after,allowed=(0,1),timeout=1800)
        vp=run([sys.executable,s(after)/'scripts/validate_photo_prompt_dictionary.py'],'dictionary-validator',cwd=after,allowed=(0,1),timeout=1200)
        write(Q/'test-receipt.json',{'modules':selected,'missing_modules':missing,'unittest_exit':cp.returncode,'dictionary_exit':vp.returncode,'full_suite_run':False})
    elif A.phase=='report':
        results=load(Q/'results.json');cases={x['id']:x for x in load(Q/'input-manifest.json')['cases']};checks=[];deltas=[]
        for r in results['rows']:
            c=cases[r['case']];expected=c['expected'];targets=[c['profile_id']] if c.get('profile_id') else ['pf_rib_vault_chapel','pf_venetian_arcade']
            observed=any(t in r.get('hard_ids',[]) for t in targets);eh=expected[r['arm']+'_hard']
            checks.append({'case':r['case'],'arm':r['arm'],'admission_ok':r['admission']=='pass','audit_expected':expected[r['arm']+'_audit'],'audit_observed':r.get('audit_status'),'audit_ok':r.get('audit_status')==expected[r['arm']+'_audit'],'hard_expected':eh,'hard_observed':observed,'hard_ok':eh is None or observed==eh})
        for name in cases:
            paths=[Q/'outputs'/arm/name/'candidate-pack.json' for arm in ['before','after']]
            if not all(p.exists() for p in paths):continue
            b,a=[load(p)[0] for p in paths]
            fields=['authorial_core','intent_lock','negative_en','semantic_assertion_obligations','slots','candidate_bundles']
            eq={f:b.get(f)==a.get(f) for f in fields}
            def hard(x):return {o['id']:[g['id'] for g in o.get('render_gates',[])] for o in (x.get('visual_obligations')or{}).get('obligations',[])}
            def opt(x):return {v['id'] for v in (x.get('visual_concept_candidates')or{}).get('candidates',[])}
            deltas.append({'case':name,'paired_invariants':eq,'hard_before':hard(b),'hard_after':hard(a),'optional_added':sorted(opt(a)-opt(b)),'optional_removed':sorted(opt(b)-opt(a))})
        source_now=tree(s(R));assert source_now==load(Q/'source-photo-skill-hashes.json')
        before_now=tree(s(base));after_now=tree(s(after));allowed={load(O/'proposal.json')['source_file'].split(skill+'/')[1],'assets/photo_prompt_visual_profile_index.json'}
        changed=[k for k in sorted(set(before_now)|set(after_now)) if before_now.get(k)!=after_now.get(k)]
        report={'mode':A.mode,'runtime_sha':A.runtime_sha,'provisional':A.mode=='prerelease','initial_input_failures':results['initial_input_failures'],'checks':checks,'paired_deltas':deltas,'snapshot_source_diff':changed,'source_diff_within_two_alias_and_index_scope':set(changed)<=allowed,'source_checkout_unchanged':True,'new_unique_profile_coverage':0,'provider_network_guard_attempts':(Q/'network-or-isolation-attempts.jsonl').exists(),'images':0,'source_installation':False,'integrated_rerun_required':True}
        report['main_matrix_expected_outcomes_met']=all(c['admission_ok'] and c['audit_ok'] and c['hard_ok'] for c in checks) and not results['initial_input_failures']
        report['paired_invariants_met']=all(all(d['paired_invariants'].values()) for d in deltas)
        write(Q/'SUMMARY.json',report);print(json.dumps({k:v for k,v in report.items() if k not in ['checks','paired_deltas']},indent=2))
assert git('rev-parse','HEAD')==A.runtime_sha and not git('status','--porcelain')
