"""Current-schema mechanical adapter. No profile-derived meaning or fixtures.

Run only against a recorded post-PR5 snapshot. All input failures are retained by
runner.py. This file has NOT been behaviorally qualified when first delivered.
"""
import argparse,copy,hashlib,json,sys
from pathlib import Path

def sha(b):return hashlib.sha256(b).hexdigest()
def load(p):return json.loads(Path(p).read_text())
def write(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')

def prepare(case,output):
    p=Path(output);p.mkdir(parents=True,exist_ok=False)
    raw=case['request'];baseline=case['baseline_prompt_en'];facts=case['request_facts']
    assert sha(raw.encode())==case['request_sha256']
    assert sha(baseline.encode())==case['baseline_sha256']
    (p/'request.txt').write_bytes(raw.encode());(p/'baseline.txt').write_bytes(baseline.encode())
    envelope={'contract_version':'photo-request-envelope/v1','provenance':'requesting_user',
              'request_id':'synthetic-architecture-revalidation-'+case['id'],'request_text':raw,
              'request_sha256':sha(raw.encode()),'active_spans':[{'span_id':'scene','start':0,'end':len(raw),'text':raw}]}
    write(p/'request-envelope.json',envelope)
    write(p/'creative-context.json',{'subject_category':'nonhuman','no_people':False,'explicit_nonsexual':False})
    write(p/'embodiment-review.json',{'contract_version':'photo-embodiment-review/v1','provenance':'agent_prepack',
          'prompt_sha256':sha(baseline.encode()),'scope':'not_applicable','summary':'The entire authored scene consists of stationary architectural structures; no living body or bodily action appears.','checks':{}})
    write(p/'case.json',case)

def bind_core(p):
    p=Path(p);case=load(p/'case.json');raw=case['request'];facts=case['request_facts'];b=case['baseline_prompt_en']
    anchors=[{'anchor_id':'architecture','source_text':raw,'dimension':'concept','prompt_evidence':'An architectural photograph'}]
    anchors += [{'anchor_id':'relation_'+str(i+1),'source_text':raw,'dimension':'setting','prompt_evidence':f} for i,f in enumerate(facts)]
    # Subject and event evidence remain distinct literal phrases, both supported
    # by fact one. They are not camera, mood, or other agent-owned choices.
    if case['profile_id']=='pf_rib_vault_chapel':subject='ribs';event=facts[0][facts[0].index('intersect'):]
    else:subject='an open lower arcade';event=facts[0][facts[0].index('faces'):]
    anchors += [{'anchor_id':'subject','source_text':raw,'dimension':'subject','prompt_evidence':subject},
                {'anchor_id':'structural_state','source_text':raw,'dimension':'event','prompt_evidence':event}]
    core={'contract_version':'photo-authorial-core/v3','provenance':'agent_prepack','source_request':raw,
      'creative_controls_sha256':load(p/'creative-controls.json')['canonical_sha256'],
      'interpreted_intent':'Preserve the architecture and every expressly requested material, opening shape, spatial owner and connection. A measured oblique view and soft daylight are the agent-owned photographic treatment.',
      'subject':subject,'setting':'; '.join(facts),'event':event,'visual_priorities':facts[:3],
      'baseline_prompt_en':b,'user_definitions':[],
      'interpretation_provenance':[{'term':'architectural arrangement','source_text':raw,'basis':'request_context','resolution':'; '.join(facts),'sources':[]}],
      'unresolved_ambiguities':[],'user_exclusions':[],'runtime_forbidden_labels':[],
      'intent_lock':{'contract_version':'photo-intent-lock/v2','priority':'requesting_user','semantic_anchors':anchors,
                     'locked_dimensions':['concept','subject','setting','event'],
                     'open_dimensions':['composition','framing','lighting','camera','color','atmosphere']},
      'semantic_assertions':[{'assertion_id':'primary_subject_category','dimension':'subject','polarity':'required','source_span_ids':['scene'],'affected_dimensions':['subject'],'axes':{'subject_category':'object'},'evidence':{'subject_phrase':facts[0]}},
         {'assertion_id':'architectural_relations','dimension':'setting','polarity':'required','source_span_ids':['scene'],'affected_dimensions':['setting'],
          'axes':{'structural_arrangement':'expressly_requested_relations'},'evidence':{'relation_'+str(i+1)+'_phrase':f for i,f in enumerate(facts)}}],
      'request_lineage':None,'variation_key':case['id']}
    assert all(a['prompt_evidence'] in b for a in anchors)
    write(p/'authorial-core.json',core)

def normalize(root,p):
    p=Path(p);sys.path.insert(0,str(Path(root)/'skills/photo-prompt-image-generator/scripts'))
    import prompt_generator as g
    e=g.load_request_envelope_arg(str(p/'request-envelope.json'))
    c=g.load_authorial_core_arg(str(p/'authorial-core.json'),request_envelope=e,creative_control_snapshot=load(p/'creative-controls.json'))
    review=g.photo_embodiment.build_policy(c,load(p/'embodiment-review.json'))
    assert c['baseline_prompt_en'].encode()==(p/'baseline.txt').read_bytes()
    write(p/'normalized-authorial-core.json',c);write(p/'normalized-envelope.json',e);write(p/'embodiment-policy.json',review)

def compose(pack,case):
    core=pack['authorial_core'];lock=core['intent_lock'];b=core['baseline_prompt_en']
    hard=(pack.get('visual_obligations')or{}).get('obligations',[])
    review=copy.deepcopy(pack['embodiment_preflight']['baseline_review']);review['provenance']='agent_postcomposition'
    incompatible=set();evidence={}
    for ob in hard:
        evidence[ob['id']]={}
        for name,req in ob['evidence_requirements'].items():
            matches=[v for v in req.get('must_mention_any',[]) if v in b]
            if matches:evidence[ob['id']][name]=matches[0];continue
            # Use the actual requested relation for the BEFORE conflicting
            # profile. Never invent the selected variant's absent phrase.
            if ob['id']==case.get('profile_id') and name.startswith('component_') and name.endswith('_phrase'):
                ix=int(name.split('_')[1])-1
                phrase=case['request_facts'][ix]
                assert phrase in b
                evidence[ob['id']][name]=phrase;incompatible.add(ob['id'])
            else:raise ValueError('Unknown required duty lacks honest literal baseline evidence: '+ob['id']+'/'+name)
    c={'core_retrieval_sha256':pack['core_retrieval']['canonical_sha256'],'pack_id':pack['pack_id'],'prompt_en':b,
       'negative_en':pack['negative_en'],'chosen_candidate_ids':[],'chosen_visual_concept_ids':[],'composer':'agent',
       'embodiment_review':{'source_contract_sha256':pack['embodiment_preflight']['canonical_sha256'],'review':review},
       'candidate_interpretations':[],
       'authorial_core_binding':{'source_authorial_core_sha256':core['canonical_sha256'],'source_intent_lock_sha256':lock['canonical_sha256'],
          'preserved_anchor_ids':[a['anchor_id'] for a in lock['semantic_anchors']],'preserved_evidence':[],'authorial_decisions':[]},
       'semantic_clarification_decisions':[],
       'creative_augmentation_brief':{'decisions':[{'candidate_id':v['id'],'decision':'rejected','rationale':'Retain the independently frozen architecture without adopting optional alternatives'} for v in (pack.get('creative_augmentation')or{}).get('candidates',[])]}}
    for row in pack['semantic_clarification']['candidates']:
        bad=row.get('profile_id') in incompatible
        c['semantic_clarification_decisions'].append({'clarification_id':row['id'],
           'decision':'applied' if row.get('required_in_final_prompt') and not bad else 'rejected',
           'rationale':'The selected duty conflicts with the literal requester scene; preserve the scene' if bad else 'Preserve requester meaning and decline optional reinterpretation',
           'prompt_evidence':case['request_facts'][0] if case.get('request_facts') else lock['semantic_anchors'][0]['prompt_evidence']})
    if hard:c['visual_obligation_evidence']=evidence
    contract=pack.get('semantic_assertion_obligations')
    if contract:c['semantic_assertion_evidence']={'source_contract_sha256':contract['canonical_sha256'],'evidence':{x['assertion_id']:x['frozen_evidence'] for x in contract['obligations']}}
    assert all(v in b for fields in evidence.values() for v in fields.values())
    return c

def mutate(base,definition):
    c=copy.deepcopy(base);old_prompt=base['prompt_en']
    if definition['kind']=='append_contradiction':prompt=old_prompt+' '+definition['append']
    else:
        assert definition['old'] in old_prompt
        prompt=old_prompt.replace(definition['old'],definition['new'])
    assert prompt!=old_prompt
    c['prompt_en']=prompt
    # Only mutable prose evidence is refreshed. Immutable hashes/anchor IDs stay.
    def replace(v):
        if isinstance(v,dict):return {k:replace(x) for k,x in v.items()}
        if isinstance(v,list):return [replace(x) for x in v]
        if isinstance(v,str) and definition['kind']=='replace_content':return v.replace(definition['old'],definition['new'])
        return v
    for key in ['semantic_clarification_decisions','visual_obligation_evidence']:
        if key in c:c[key]=replace(c[key])
    if 'semantic_assertion_evidence' in c:
        c['semantic_assertion_evidence']['evidence']=replace(c['semantic_assertion_evidence']['evidence'])
    c['embodiment_review']['review']['prompt_sha256']=sha(prompt.encode())
    c['embodiment_review']['review']['summary']='The full altered prose still depicts stationary architecture and no living-body mechanism. The changed structural meaning is intentionally tested against the original immutable requester contract.'
    for key in ['authorial_core_binding','core_retrieval_sha256','negative_en','pack_id']:
        assert c[key]==base[key]
    return c

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('operation',choices=['prepare','bind','normalize','compose','mutate']);p.add_argument('--root');p.add_argument('--case');p.add_argument('--input');p.add_argument('--pack');p.add_argument('--output');a=p.parse_args()
    if a.operation=='prepare':prepare(load(a.case),a.output)
    elif a.operation=='bind':bind_core(a.input)
    elif a.operation=='normalize':normalize(a.root,a.input)
    elif a.operation=='compose':write(a.output,compose(load(a.pack)[0],load(a.case)))
    elif a.operation=='mutate':write(a.output,mutate(load(a.input),load(a.case)))
