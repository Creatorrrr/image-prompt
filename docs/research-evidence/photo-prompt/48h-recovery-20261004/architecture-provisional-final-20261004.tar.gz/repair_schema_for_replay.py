"""Replay only the reviewed minimum-length repairs in a new run directory.

Preserves the first manifest/inputs and accepts no automatic semantic edits.
Usage: python repair_schema_for_replay.py --run-directory runs/integrated-001
The initial runner --phase inputs must already have saved its admission failures.
"""
import argparse,copy,hashlib,json,os,shutil,subprocess,sys
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--run-directory',required=True);a=p.parse_args()
O=Path(__file__).resolve().parent;Q=Path(a.run_directory).resolve();Q.relative_to(O/'runs')
load=lambda p:json.loads(Path(p).read_text());sha=lambda b:hashlib.sha256(b).hexdigest()
def write(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
assert not (Q/'outputs').exists(),'Repair must precede every candidate arm'
assert not (Q/'input-manifest.v3.json').exists(),'Never replace a saved repaired manifest'
original=load(Q/'input-manifest.json');frozen={c['id']:c for c in load(O/'cases.json')['cases']}
out=Q/'reviewed-schema-repairs';out.mkdir(exist_ok=False);records=list(original['cases']);changes=[];failures=[]
for row in original['initial_failures']:
    name=row['case']
    if name not in frozen:raise ValueError('Fresh or unknown schema failure needs independent review: '+name)
    src=Q/'inputs'/name;dest=out/name;shutil.copytree(src,dest)
    core=load(dest/'authorial-core.json');before=copy.deepcopy(core);facts=frozen[name]['request_facts']
    if frozen[name]['profile_id']=='pf_rib_vault_chapel':
        assert core['subject']=='ribs'
        core['subject']=facts[0].split(' intersect')[0]
        anchor=next(x for x in core['intent_lock']['semantic_anchors'] if x['anchor_id']=='subject')
        assert anchor['prompt_evidence']=='ribs';anchor['prompt_evidence']=core['subject']
        fields=['subject','intent_lock.semantic_anchors[subject].prompt_evidence']
    else:
        assert core['event']==facts[0][facts[0].index('faces'):]
        core['event']=facts[0];fields=['event']
    assert core['source_request']==before['source_request'] and core['baseline_prompt_en']==before['baseline_prompt_en'] and core['semantic_assertions']==before['semantic_assertions']
    write(dest/'authorial-core.json',core)
    env={k:os.environ[k] for k in ('PATH','HOME','LANG') if k in os.environ};env.update(PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=str(Q/'runner-source'),ARCH_DENY_ASSETS='1',ARCH_GUARD_LOG=str(out/'guard-attempts.jsonl'))
    cmd=[sys.executable,str(Q/'runner-source/adapter.py'),'normalize','--root',str(Q/'before'),'--input',str(dest)]
    cp=subprocess.run(cmd,env=env,capture_output=True,text=True)
    (dest/'normalize.stdout.txt').write_text(cp.stdout);(dest/'normalize.stderr.txt').write_text(cp.stderr)
    changes.append({'case':name,'fields':fields,'argv':cmd,'returncode':cp.returncode,'request_baseline_owned_facts_unchanged':True,'anchor_evidence_expanded':frozen[name]['profile_id']=='pf_rib_vault_chapel'})
    if cp.returncode:failures.append({'case':name,'error':cp.stderr});continue
    assert not (out/'guard-attempts.jsonl').exists()
    records.append({**frozen[name],'input_dir':str(dest),'files_sha256':{str(f.relative_to(dest)):sha(f.read_bytes()) for f in dest.rglob('*') if f.is_file()},'input_status':'pass','adapter_version':'reviewed-minimum-length-replay','initial_failure_retained':True})
write(out/'ADAPTER-CHANGES.json',{'review_basis':'Original prerelease-001 V2/V3 mechanical repairs, independently checked before behavioral results','source_file_sha256':sha(Path(__file__).read_bytes()),'changes':changes,'failed_repairs':failures})
write(Q/'input-manifest.v3.json',{'cases':records,'initial_failures':original['initial_failures'],'unresolved_input_failures':failures,'frozen_before_candidates':True,'original_manifest_sha256':sha((Q/'input-manifest.json').read_bytes()),'mechanical_repairs':str(out/'ADAPTER-CHANGES.json')})
print('Normalized',len(records),'unresolved',len(failures),'initial failures retained',len(original['initial_failures']))
if failures:raise SystemExit(2)
