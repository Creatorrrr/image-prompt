"""Full-registry real-cache preflight/verification; no fake vectors or embedding calls."""
import argparse,hashlib,json,sys
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('phase',choices=['preflight','verify']);p.add_argument('--root',required=True);p.add_argument('--cache',required=True);p.add_argument('--output',required=True);p.add_argument('--expect-stale',action='store_true');a=p.parse_args()
s=Path(a.root)/'skills/photo-prompt-image-generator';sys.path.insert(0,str(s/'scripts'))
import prompt_generator as g
import build_visual_profile_index as builder
registry=g.load_visual_obligation_registry(s/'assets/photo_prompt_visual_obligations.json')
cache=json.loads(Path(a.cache).read_text())
v=builder.reusable_vectors([Path(a.cache)],registry,provider=g.SEMANTIC_PROVIDER,model=g.SEMANTIC_MODEL_ID,dimensions=g.DEFAULT_SEMANTIC_DIMENSIONS)
ids={x['id'] for x in registry['profiles']}
assert set(v)==ids,'Missing compatible cached vector(s); stop before production builder'
assert all(cache['entries'][x['id']]['text']==g.visual_profile_semantic_text(x) for x in registry['profiles'])
assert all(cache['entries'][k]['vector']==v[k] for k in ids)
stale=None
try:g.validate_visual_profile_index_metadata(cache,registry)
except ValueError as exc:stale=str(exc)
if a.expect_stale:assert stale and 'registry_sha256' in stale
else:assert stale is None
sha=lambda b:hashlib.sha256(b).hexdigest()
canonical=lambda x:json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
r={'phase':a.phase,'profile_count':len(ids),'compatible_cached_vectors':len(v),'pending_embedding_inputs':0,
   'cache_sha256':sha(Path(a.cache).read_bytes()),'all_texts_equal':True,'all_vectors_equal':True,'stale_cache_rejection':stale,
   'registry_sha256':g.visual_profile_registry_sha256(registry),'claim_limit':'Helper preflight/verification only; actual index build is a separate recorded production CLI command'}
if a.phase=='verify':
    ix=g.load_visual_profile_index(s/'assets/photo_prompt_visual_profile_index.json',registry)
    assert ix['entries']==cache['entries']
    r.update(index_sha256=sha((s/'assets/photo_prompt_visual_profile_index.json').read_bytes()),
       logical_index_sha256=sha(canonical(ix)),entries_unchanged=True,exact_lookup_sha256=sha(canonical(ix['exact_lookup'])),bm25f_sha256=sha(canonical(ix['bm25f'])),equal_to_cached_index=ix==cache)
Path(a.output).write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
