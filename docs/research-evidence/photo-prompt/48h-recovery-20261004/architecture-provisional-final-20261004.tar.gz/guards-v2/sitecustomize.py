"""Version 2: offline guard with a reviewed same-snapshot test CLI exception."""
import json,os,sys
from pathlib import Path
sys.dont_write_bytecode=True

def record(name,payload):
    path=os.environ.get(name)
    if path:
        with open(path,'a',encoding='utf-8') as f:f.write(json.dumps(payload,ensure_ascii=False)+'\n')
def hook(event,args):
    reason=None
    if event.startswith('socket.'):reason='All socket operations are prohibited in offline qualification'
    if event=='subprocess.Popen':
        executable,argv,cwd,env=args
        permitted=os.environ.get('ARCH_ALLOWED_TEST_CLI')
        argv=list(argv) if isinstance(argv,(list,tuple)) else []
        inherited=env is None or (env.get('PYTHONPATH')==os.environ.get('PYTHONPATH') and env.get('ARCH_GUARD_LOG')==os.environ.get('ARCH_GUARD_LOG'))
        allowed=bool(permitted and len(argv)>=2 and Path(str(argv[0])).resolve()==Path(sys.executable).resolve() and Path(str(argv[1])).resolve()==Path(permitted).resolve() and inherited)
        if allowed:record('ARCH_ALLOWED_CHILD_LOG',{'event':event,'argv':argv,'cwd':str(cwd),'reviewed_exception':'Existing focused unit test invokes the same-snapshot unmodified generator CLI with the inherited offline guard'})
        else:reason='Nested subprocess is outside the reviewed same-snapshot generator CLI exception'
    if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
        p=Path(os.fsdecode(args[0])).absolute()
        if p.name=='.env':reason='Credential file access is prohibited'
        if os.environ.get('ARCH_DENY_ASSETS')=='1' and 'photo-prompt-image-generator/assets/' in str(p):reason='Candidate DATA is unavailable during mechanical input normalization'
    if reason:
        record('ARCH_GUARD_LOG',{'event':event,'reason':reason})
        raise RuntimeError(reason)
sys.addaudithook(hook)
