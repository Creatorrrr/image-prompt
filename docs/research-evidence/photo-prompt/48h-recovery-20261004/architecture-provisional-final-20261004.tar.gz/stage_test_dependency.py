"""For a fresh replay only: stage the one reviewed immutable test reference.

Call after prepare and before --phase tests. This avoids reproducing the first
run's known missing-file packaging error. Never edits runtime data or tests.
"""
import argparse,hashlib,json,subprocess
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--run-directory',required=True);p.add_argument('--source',required=True);a=p.parse_args()
O=Path(__file__).resolve().parent;Q=Path(a.run_directory).resolve();R=Path(a.source).resolve();Q.relative_to(O/'runs')
assert not list((Q/'commands').glob('*existing-focused-tests.command.json')), 'This preparatory staging must precede focused tests'
rel=Path('docs/research-evidence/photo-prompt/extension-maintenance/photo_prompt_palace_fortification_extension.json')
pin=json.loads((Q/'run-status.json').read_text())['runtime_sha'];b=(R/rel).read_bytes()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==pin
assert subprocess.check_output(['git','show',pin+':'+str(rel)],cwd=R)==b
h=hashlib.sha256(b).hexdigest();targets=[]
for arm in ['before','after']:
    target=Q/arm/rel;assert not target.exists();target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(b)
    assert hashlib.sha256(target.read_bytes()).hexdigest()==h;targets.append(str(target))
out=Q/'test-dependency-staging.json';assert not out.exists()
out.write_text(json.dumps({'dependency':str(rel),'runtime_sha':pin,'source_and_copy_sha256':h,'targets':targets,'runtime_test_fixture_meaning_changes':0,'reason':'Exact source maintenance record is a read dependency of the unchanged palace provenance test'},indent=2)+'\n')
print('Immutable test reference staged in both snapshots')
