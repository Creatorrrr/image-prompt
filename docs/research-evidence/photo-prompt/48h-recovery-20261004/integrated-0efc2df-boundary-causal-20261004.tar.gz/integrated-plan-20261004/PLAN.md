# Gated integrated-runtime rerun plan

Status: **plan only; hold active**. No new runtime snapshot, index, candidate run, test, source edit, network/provider call, image, installation or publication has been started for this integrated run. Explicit authorization to publish PR5 is not a verified remote main pin. Start only when the coordinator supplies the verified final main SHA and releases this execution hold.

## Immutable basis

Reuse the 18 effective inputs recorded in `runs/prerelease-001/input-manifest.v3.json`: 16 source-guided cases and the two untouched independent synthetic controls. Copy the same requester text, baseline, authorial core including the reviewed subject/event/anchor repairs, bound creative controls and embodiment review **byte-for-byte**. Do not invoke initial authoring, regenerate controls, recreate the old failures, change camera/light ownership, add definitions, tune expected results or substitute a fixture.

Preserve all prerelease artifacts, original and repaired adapter versions, reports, tarballs and hashes. The complete prerelease archive SHA-256 is `14d010cbb830ba611af61c317ce443e36dcbb24f02b99327b9992a3e0480adce`. The frozen meanings and criteria remain `PROTOCOL.md`, `proposal.json`, `cases.json`, `mutations.json` and `FRESH-EXPECTATIONS.json`.

Use the preserved `runner.py` for snapshot preparation and `runner_v2.py` for real index/CLI/mutation/test/report phases. The only additional orchestration needed after release is an input-copy-and-revalidation step; it is described below but is not executed or installed by this plan. Preserve its eventual version/hash before use. `adapter.py` is used only to normalize already-corrected raw inputs and construct the same retention compositions/mutations, not to bind newly authored cores.

## Required start receipt

The coordinator must provide:

1. Verified final remote main SHA, verification evidence and a clean local read-only source worktree at exactly that SHA
2. The actual PR5 integration/merge commit and PR URL, with the integration method stated accurately
3. Confirmation that review/integration is complete and this local isolated qualification may start
4. A receipt compatible with the preserved integrated gate: `runtime_sha`, `pr5_merge_sha`, `pr_url`, `review_complete: true`, `pr5_merged: true`, supported by the actual verified integration facts

The gate checks source HEAD/cleanliness and `git merge-base --is-ancestor` for the integration commit. Do not manufacture merge status or use authorization as proof of publication. If publication was by a route that does not truthfully satisfy the preserved receipt semantics, pause and agree a separately versioned metadata-only launch gate; do not spoof fields or relax behavioral criteria. If the SHA or source path is missing, continue holding. No fetch/pull or worktree creation in the shared source repository is part of this child task.

Reserve a new run name only after the actual SHA is known, for example `integrated-<first-12-sha>-001`. Never reuse `prerelease-001` or overwrite an existing run.

## Exact execution order after release

Let `SOURCE` be the verified clean source worktree, `SHA` the verified main commit, `RECEIPT` the verified start receipt, `RUN` the new unique run name and `Q=runs/$RUN` under this qualification directory. Use `PYTHONDONTWRITEBYTECODE=1`; set a per-run `TMPDIR` under this directory for any test temporaries. Strip credentials in the child environment and retain the reviewed offline socket/credential guard.

### 1. Read-only preflight and preparation

- Verify frozen protocol/proposal/case/mutation/fresh expectation and all 18 effective input file hashes against their saved manifests and prerelease archive receipts
- Verify source HEAD/cleanliness, integration ancestry and exact old target profile hashes/aliases
- Compare the current source runtime/control definitions with the prerelease source to identify any additional integrated changes; record them, never silently blend source versions
- Confirm adequate disk for two independent complete photo-skill/test snapshots and records
- Run:
  `python runner.py --source "$SOURCE" --runtime-sha "$SHA" --run-id "$RUN" --mode integrated --integrated-receipt "$RECEIPT" --phase prepare`
- This copies independent files, without links to shared source. Both arms use the same SHA. Only the two approved Korean aliases are replaced in the isolated after snapshot

### 2. Stage the known test dependency immediately

Before either test suite begins, run:
`python stage_test_dependency.py --run-directory "$Q" --source "$SOURCE"`

This copies only the pinned immutable palace maintenance record into both isolated snapshots and verifies its bytes against the source Git object. Its prerelease source SHA-256 was `954fed9368e36faa9bc6146f47992c78c60621f1757b59ff9726e064aec5cd79`; verify the actual integrated source rather than assuming that hash. A changed record must be reviewed against the corresponding unchanged test/data references, never edited to pass.

### 3. Reuse and revalidate the exact 18 effective inputs

The new input-transfer orchestration will:

- Read the existing effective manifest and verify every referenced file hash
- Copy immutable effective inputs and their origin manifest into a new `inherited-inputs/` evidence area; preserve the two independent original authoring records as well
- Populate a fresh operational input directory for each case with the identical request envelope, raw authorial core, creative controls, embodiment review, request bytes and baseline bytes; copy each original case record unchanged
- Invoke the preserved `adapter.py normalize` against the **integrated before snapshot** with runtime DATA reads and sockets prohibited; store new normalization outputs separately from copied old normalization records
- Require 18/18 successful current normalizations, and compare current normalized meaning/ownership/bindings to the frozen effective versions. If a schema or hash normalization changes unexpectedly, preserve the first rejection/delta and stop before retrieval for review; do not re-author or automatically repair meaning
- Freeze a new `input-manifest.v3.json` using the same case IDs, cohorts, expected outcomes, raw input bytes and seed, with fresh operational paths/hashes and `unresolved_input_failures: []`
- Keep current normalization failures separate from the historical 14 initial and seven second-attempt schema failures. Preserve historical repair lineage and exact archive hashes; do not relabel historical failures as new integrated failures or erase them

Do **not** run either driver's `inputs` phase for this reuse path: that phase would reconstruct the original short fields and deliberately reproduce obsolete adapter failures. Do not invoke `repair_schema_for_replay.py` unless a separate reviewed new normalization task actually calls for it.

### 4. Real full-index rebuilds

Run `runner_v2.py` with the same common integrated arguments and `--phase indexes`.

Require the complete merged registry, genuine immutable reference cache, provider/model/dimension/entry/full-text compatibility and zero pending embeddings before either production builder CLI. Both actual builder/check CLIs run. All cached texts/vectors remain genuine and unchanged; old index rejection against the after registry is demonstrated. Preserve exact lookup/BM25F/hash deltas and unchanged ordinary assets. No provider call, fabricated vector or helper-only replacement is allowed.

### 5. Actual public experiment

Run `--phase runs`, retaining all subprocess command/artifact/exit records.

Require exactly 18 inputs × both arms = 36 unique CLI admissions and 36 composed audits; no missing or duplicate row. Preserve all 18 baselines, requester ownership, generic duties, negatives, controls, embodiment bindings and ordinary slot/bundle inventories across arms. Maintain zero optional adoption. Reevaluate each frozen expectation; do not reuse prerelease outcomes as current evidence.

Run `--phase mutations` with the frozen ten definitions. Require actual prompt replacement in the eight replacement/ownership controls and the expected literal-anchor rejection; retain separate metadata failures. Record both append-contradiction outcomes as diagnostics, not a promise of arbitrary semantic contradiction detection.

### 6. Focused regression and dictionary checks

After fixture staging, run `--phase tests` on both snapshots. The preserved seven modules covered 95 methods per prerelease arm; record the actual integrated method count and all failures. Require both pristine current-suite exits and both dictionary validators to pass for the preserved strict integrated summary. The reviewed same-snapshot test subprocess exception remains narrowly scoped and logged, with the offline guard inherited.

If any new failure occurs, preserve it, compare both arms and source dependencies, and report the exact blocker. No runtime/test/fixture tuning is authorized. Do not silently substitute targeted reruns for pristine suite evidence or drop a failing method. A separately reviewed mechanical harness correction gets a new version and explicit accounting.

### 7. Strict report and independent review

Run `--phase report`. Require complete denominator, full source/snapshot integrity, real-index receipts, all mutation checks and both-arm test/dictionary gates. Record the actual selection mode, not inferred embedding-query coverage. Report any changed optional exposure, six valid old-Korean target gates lost if observed again, the frozen recall tradeoff, zero new unique profiles, and absent image/quality evidence.

The preserved driver hardcodes `integrated_rerun_required: true` (and an equivalent preparation metadata field) even in integrated mode. Keep that raw report intact. A separate, explicitly versioned integrated assessment must bind the actual verified main SHA and state whether this integrated run completed; it must identify the inherited metadata literal rather than silently rewriting the historical driver output. Do not reuse `write_final_assessment.py`, which is deliberately tied to the prerelease run and its initial test errors.

Request an independent review once complete artifacts are ready. Give the reviewer frozen sources, verified main receipt, all current command/pack/audit/index/test/mutation artifacts, historical hash receipts, and the exact proposed scope; ask for factual revalidation, input/source integrity, complete denominators, recall/collateral accounting and final claim consistency. The reviewer must be read-only on source and producer outputs and may write only its separate review deliverables.

### 8. Delivery and stopping boundary

Send useful outcomes/blockers to the coordinator immediately. Create a bounded, hash-manifested final evidence archive excluding duplicated production/index payloads; verify every archive member by reading it back. Preserve all failed attempts and report both integrated and prerelease evidence distinctly.

Completion here is local isolated qualification plus independent review and verified artifacts. It does not authorize source installation, data PR publication or another network operation. Any publication remains with the coordinator under the user's separate authorization. If main changes before qualification closes, do not relabel this run as the new head: retain its exact SHA and ask whether a further integrated rerun is needed.
