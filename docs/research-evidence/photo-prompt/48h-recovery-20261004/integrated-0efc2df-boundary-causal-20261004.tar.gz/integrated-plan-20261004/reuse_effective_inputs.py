"""Copy the 18 reviewed effective inputs verbatim and revalidate on integrated code."""
import argparse,copy,hashlib,json,os,shutil,subprocess,sys,time
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--run-directory',required=True);p.add_argument('--source-run',required=True);a=p.parse_args()
O=Path(__file__).resolve().parent.parent;Q=Path(a.run_directory).resolve();P=Path(a.source_run).resolve();Q.relative_to(O/'runs');P.relative_to(O/'runs')
assert Q!=P
sha=lambda b:hashlib.sha256(b).hexdigest()
def load(p):return json.loads(Path(p).read_text())
def write(p,v):Path(p).parent.mkdir(parents=True,exist_ok=True);Path(p).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def tree(p):return {str(f.relative_to(p)):sha(f.read_bytes()) for f in sorted(p.rglob('*')) if f.is_file()}
status=load(Q/'run-status.json');assert status['mode']=='integrated'
manifest=load(P/'input-manifest.v3.json');assert len(manifest['cases'])==18 and not manifest['unresolved_input_failures']
assert not (Q/'input-manifest.v3.json').exists() and not (Q/'outputs').exists()
write(Q/'input-transfer/origin-manifest.json',manifest)
shutil.copytree(P/'fresh-raw',Q/'fresh-raw')
assert tree(P/'fresh-raw')==tree(Q/'fresh-raw')
operational=['request-envelope.json','authorial-core.json','creative-controls.json','embodiment-review.json','request.txt','baseline.txt','creative-context.json','case.json']
records=[];failures=[];checks=[]
for case in manifest['cases']:
 name=case['id'];source=Path(case['input_dir']);inherited=Q/'inherited-inputs'/name;dest=Q/'inputs'/name
 for n,h in case['files_sha256'].items():assert sha((source/n).read_bytes())==h,(name,n)
 shutil.copytree(source,inherited);assert tree(source)==tree(inherited)
 dest.mkdir(parents=True,exist_ok=False)
 for n in operational:
  if (source/n).exists():shutil.copy2(source/n,dest/n);assert (source/n).read_bytes()==(dest/n).read_bytes()
 shutil.copy2(P/'case-records'/(name+'.json'),Q/'case-records'/ (name+'.json')) if (Q/'case-records').exists() else None
 (Q/'case-records').mkdir(exist_ok=True)
 if not (Q/'case-records'/(name+'.json')).exists():shutil.copy2(P/'case-records'/(name+'.json'),Q/'case-records'/(name+'.json'))
 env={k:os.environ[k] for k in ('PATH','HOME','LANG','LC_ALL','TZ','TMPDIR') if k in os.environ}
 env.update(PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=str(Q/'runner-source'),ARCH_DENY_ASSETS='1',ARCH_GUARD_LOG=str(Q/'input-transfer/guard-attempts.jsonl'))
 cmd=[sys.executable,str(Q/'runner-source/adapter.py'),'normalize','--root',str(Q/'before'),'--input',str(dest)]
 start=time.time();cp=subprocess.run(cmd,env=env,capture_output=True,text=True,timeout=180)
 stem=Q/'input-transfer'/name
 Path(str(stem)+'.stdout.txt').write_text(cp.stdout);Path(str(stem)+'.stderr.txt').write_text(cp.stderr)
 write(str(stem)+'.command.json',{'argv':cmd,'returncode':cp.returncode,'seconds':round(time.time()-start,3),'script_sha256':sha(Path(__file__).read_bytes()),'normalization_only':True,'runtime_assets_denied':True,'source_effective_input_sha256':case['files_sha256']})
 same={n:(dest/n).exists() and (dest/n).read_bytes()==(source/n).read_bytes() for n in ['normalized-authorial-core.json','normalized-envelope.json','embodiment-policy.json']}
 check={'case':name,'returncode':cp.returncode,'all_raw_inputs_byte_identical':all((dest/n).read_bytes()==(source/n).read_bytes() for n in operational if (source/n).exists()),'normalized_outputs_byte_identical':same};checks.append(check)
 if cp.returncode or not all(same.values()):failures.append(check)
 else:
  row=copy.deepcopy(case);row.update(input_dir=str(dest),files_sha256=tree(dest),input_status='pass',input_origin='byte-identical reused prerelease effective input',origin_input_dir=str(source),origin_files_sha256=case['files_sha256']);records.append(row)
 write(Q/'input-transfer/checks.json',{'checks':checks,'failures':failures,'runtime_sha':status['runtime_sha'],'source_manifest_sha256':sha((P/'input-manifest.v3.json').read_bytes()),'candidate_generation_calls':0})
 if (Q/'input-transfer/guard-attempts.jsonl').exists():raise SystemExit('Isolation attempt; stop')
 if failures:raise SystemExit('Integrated input validation drift; stop before retrieval')
write(Q/'input-manifest.v3.json',{'cases':records,'initial_failures':[],'unresolved_input_failures':[],'frozen_before_candidates':True,'source_effective_manifest_sha256':sha((P/'input-manifest.v3.json').read_bytes()),'source_effective_manifest':'input-transfer/origin-manifest.json','historical_repairs_preserved':True,'historical_prerelease_archive_sha256':'14d010cbb830ba611af61c317ce443e36dcbb24f02b99327b9992a3e0480adce','current_input_repairs':0})
assert len(records)==18
print('All 18 effective inputs copied byte-for-byte; current normalization outputs exactly equal prerelease')
