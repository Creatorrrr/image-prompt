"""Real frozen V11 pack replay and unmodified current boundary validation."""
import argparse,hashlib,json,os,shutil,subprocess,sys,time
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--source',required=True);p.add_argument('--run-directory',required=True);p.add_argument('--phase',choices=['prepare','proof','tests'],required=True);a=p.parse_args()
O=Path(__file__).resolve().parent.parent;Q=Path(a.run_directory).resolve();Q.relative_to(O/'runs');R=Path(a.source).resolve();B=Q/'boundary'
sha=lambda b:hashlib.sha256(b).hexdigest()
def load(p):return json.loads(Path(p).read_text())
def write(p,x):Path(p).parent.mkdir(parents=True,exist_ok=True);Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def tree(p):return {str(f.relative_to(p)):sha(f.read_bytes()) for f in sorted(p.rglob('*')) if f.is_file()}
pin=load(Q/'run-status.json')['runtime_sha'];assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==pin
assert not subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True).strip()
ill=Path('skills/subculture-illustration-image-generator');photo=Path('skills/photo-prompt-image-generator')
proofbase=Path('docs/research-evidence/photo-prompt/camera-evidence-structure-20261003')
docs=[proofbase/'IMMUTABLE_BOUNDARY_ADVANCE_WORKFLOW.md',proofbase/'independent-v9-boundary-diagnostics.tar.gz',proofbase/'independent-v9-boundary-verification.json',proofbase/'pr-review-followup/latest-qualified-boundary-pack.json',proofbase/'pr-review-followup/V11-four-leaf-proof.json',Path('docs/research-evidence/photo-prompt/retrieval-runtime-improvement-20261003/photo-boundary-after-pack.json')]
if a.phase=='prepare':
 B.mkdir(exist_ok=False);source_hashes=tree(R/ill);receipt={'runtime_sha':pin,'illustration_skill_source_hashes':source_hashes,'docs_source_sha256':{},'source_main_modified':False,'interpreter_copy':{}}
 for d in docs:
  data=(R/d).read_bytes();assert subprocess.check_output(['git','show',pin+':'+str(d)],cwd=R)==data
  receipt['docs_source_sha256'][str(d)]=sha(data)
 for arm in ['before','after']:
  root=Q/arm;shutil.copytree(R/ill,root/ill,symlinks=False,ignore=shutil.ignore_patterns('__pycache__','*.pyc'));assert tree(root/ill)==source_hashes
  for d in docs:(root/d).parent.mkdir(parents=True,exist_ok=True);shutil.copy2(R/d,root/d)
  # The frozen argv names .venv/bin/python. Reuse an exact independent copy of
  # the already-installed interpreter binary; no package installation or links.
  binary=Path(sys.executable).resolve();target=root/'.venv/bin/python';target.parent.mkdir(parents=True);shutil.copy2(binary,target)
  assert sha(binary.read_bytes())==sha(target.read_bytes()) and not target.is_symlink()
  receipt['interpreter_copy'][arm]={'installed_interpreter':str(binary),'snapshot_interpreter':str(target),'sha256':sha(target.read_bytes())}
 write(B/'source-dependency-receipt.json',receipt);print('Boundary source/proof fixtures copied byte-identically; no generation yet');raise SystemExit(0)
assert B.exists()
def run(arm,cmd,label,allowed=(0,),timeout=300):
 root=Q/arm;dest=B/arm;dest.mkdir(exist_ok=True);stem=dest/label
 assert not Path(str(stem)+'.command.json').exists()
 env={k:os.environ[k] for k in ('PATH','HOME','LANG','LC_ALL','TZ','TMPDIR') if k in os.environ}
 env.update(PYTHONHOME=sys.base_prefix,PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=str(O/'guards-v2'),ARCH_GUARD_LOG=str(B/'guard-attempts.jsonl'),ARCH_ALLOWED_TEST_CLI=str(root/photo/'scripts/generate_photo_prompt.py'),ARCH_ALLOWED_CHILD_LOG=str(B/'allowed-child-cli.jsonl'))
 write(str(stem)+'.command.json',{'argv':list(map(str,cmd)),'cwd':str(root),'runtime_sha':pin,'offline_guard_sha256':sha((O/'guards-v2/sitecustomize.py').read_bytes()),'script_sha256':sha(Path(__file__).read_bytes())})
 start=time.time();cp=subprocess.run(list(map(str,cmd)),cwd=root,env=env,capture_output=True,text=True,timeout=timeout)
 Path(str(stem)+'.stdout.txt').write_text(cp.stdout);Path(str(stem)+'.stderr.txt').write_text(cp.stderr);write(str(stem)+'.exit.json',{'returncode':cp.returncode,'seconds':round(time.time()-start,3)})
 assert not (B/'guard-attempts.jsonl').exists(),'Isolation attempt; stop'
 assert cp.returncode in allowed,(arm,label,cp.stderr)
 return cp
if a.phase=='proof':
 for arm in ['before','after']:
  root=Q/arm;manifest=load(root/ill/'assets/photo_regression_baseline_v11.json');dest=B/arm;dest.mkdir(exist_ok=True)
  for name,h in manifest['frozen_inputs'].items():assert sha((root/name).read_bytes())==h
  cmd=list(manifest['command']);cmd[cmd.index('--output-file')+1]=str(dest/'frozen-v11-pack.json')
  run(arm,cmd,'actual-frozen-v11-cli-v2')
 before=(B/'before/frozen-v11-pack.json').read_bytes();after=(B/'after/frozen-v11-pack.json').read_bytes();b=json.loads(before);c=json.loads(after)
 def diff(x,y,path=''):
  if type(x)!=type(y):return [path]
  if isinstance(x,dict):return [path+'/'+k for k in set(x)^set(y)]+sum((diff(x[k],y[k],path+'/'+k) for k in sorted(set(x)&set(y))),[])
  if isinstance(x,list):return ([path+'/length'] if len(x)!=len(y) else [])+sum((diff(v,w,path+'/'+str(i)) for i,(v,w) in enumerate(zip(x,y))),[])
  return [] if x==y else [path]
 expected=load(R/ill/'assets/photo_regression_baseline_v11.json')
 source_deltas=[]
 for rel,pinned in expected['metadata_only_transition']['source_files'].items():
  bh=sha((Q/'before'/rel).read_bytes());ah=sha((Q/'after'/rel).read_bytes())
  source_deltas.append({'path':rel,'v11_pin':pinned,'before':bh,'after':ah,'before_matches_pin':bh==pinned,'after_matches_pin':ah==pinned})
 receipt={'runtime_sha':pin,'source_inputs_repaired':False,'before_raw_sha256':sha(before),'after_raw_sha256':sha(after),'v11_expected_sha256':expected['sha256'],'before_matches_v11':sha(before)==expected['sha256'],'after_matches_v11':sha(after)==expected['sha256'],'raw_bytes_equal':before==after,'changed_json_leaf_paths':diff(b,c),'complete_candidate_objects_and_order_equal':b[0]['slots']==c[0]['slots'],'candidate_count':sum(len(slot.get('candidates',[])) for slot in b[0]['slots'].values()),'source_pin_comparison':source_deltas,'existing_workflow_requires_exactly_four_binding_changes':True,'zero_pack_delta_does_not_automatically_authorize_existing_four_leaf_successor_workflow':b==c}
 write(B/'frozen-pack-comparison.json',receipt);print(json.dumps(receipt,indent=2),flush=True)
 for arm in ['before','after']:
  root=Q/arm;run(arm,[root/'.venv/bin/python',O/'integrated-plan-20261004/boundary_current_validator.py','--snapshot',root,'--output',B/arm/'current-validator.json'],'unmodified-current-boundary-validator-v2',allowed=(0,1))
 results={arm:load(B/arm/'current-validator.json') for arm in ['before','after']}
 write(B/'CAUSAL-RESULT.json',{'runtime_sha':pin,'pack_comparison':receipt,'default_current_validator':results,'source_installation':False,'baseline_or_validator_edits':False,'promotion_blocked':any(v['status']!='pass' for v in results.values())})
 print('Default current boundary validator:',{k:v['status'] for k,v in results.items()},flush=True)
elif a.phase=='tests':
 rows=[]
 for arm in ['before','after']:
  root=Q/arm;mods=['tests.test_photo_current_boundary_snapshot','tests.test_photo_nape_metadata_boundary_history','tests.test_photo_latest_metadata_boundary_history']
  cp=run(arm,[root/'.venv/bin/python','-m','unittest',*mods,'-v'],'current-and-historical-boundary-tests',allowed=(0,1),timeout=600)
  rows.append({'arm':arm,'modules':mods,'returncode':cp.returncode})
 write(B/'regression-receipt.json',{'cases':rows,'classification':'Existing unchanged tests; inspect actual failures without updating baselines or expected outcomes'})
