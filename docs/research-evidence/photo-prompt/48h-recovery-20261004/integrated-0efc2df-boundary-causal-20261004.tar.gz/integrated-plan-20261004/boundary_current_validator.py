"""Record the unchanged boundary validator's default current dispatch; no mocks."""
import argparse,hashlib,json,sys,traceback
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--snapshot',required=True);p.add_argument('--output',required=True);a=p.parse_args()
root=Path(a.snapshot).resolve();script=root/'skills/subculture-illustration-image-generator/scripts/validate_illustration_assets.py'
sys.path.insert(0,str(script.parent));import validate_illustration_assets as validator
receipt={'consumer':'Unmodified validate_photo_regression_baseline, default current dispatch, real nested production CLI','baseline_version_override':None,'mocking':False,'validator_file_sha256':hashlib.sha256(script.read_bytes()).hexdigest(),'python_executable':sys.executable}
try:
 result=validator.validate_photo_regression_baseline(root/'skills/subculture-illustration-image-generator/assets')
 receipt.update(status='pass',result=result);rc=0
except Exception as exc:
 receipt.update(status='fail',error_type=type(exc).__name__,error=str(exc),traceback=traceback.format_exc());rc=1
Path(a.output).write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n');print(json.dumps(receipt,ensure_ascii=False,indent=2));raise SystemExit(rc)
