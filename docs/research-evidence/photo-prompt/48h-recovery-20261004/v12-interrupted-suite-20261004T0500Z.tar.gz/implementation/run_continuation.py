"""Finish the unexecuted discovery tail in two bounded module processes."""
import concurrent.futures,hashlib,json,os,re,subprocess,sys,time
from pathlib import Path
O=Path(__file__).parent;R=Path('/workspace/scratch/ce8f20680f5a/image-prompt-v12-work');C=O/'continuation';inventory=json.loads((C/'DISCOVERY-INVENTORY.json').read_bytes());freeze=json.loads((O/'FINAL-SOURCE-FREEZE.json').read_bytes());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==freeze['head']
assert subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True)==''
assert all(sha(R/name)==digest for name,digest in freeze['files'].items())
env={k:v for k,v in os.environ.items() if not any(x in k.upper() for x in ['TOKEN','API_KEY','SECRET','CREDENTIAL'])};env.update(GEMINI_API_KEY='',GOOGLE_API_KEY='',PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=str(O/'guard')+os.pathsep+str(R/'tests'),V12_GUARD_LOG=str(O/'guard-attempts.log'))
def run(module):
 cmd=[sys.executable,'-m','unittest',module,'-v'];start=time.time();receipt={'command':cmd,'cwd':str(R),'source_head':freeze['head'],'frozen_source_receipt_sha256':sha(O/'FINAL-SOURCE-FREEZE.json'),'pythonpath':env['PYTHONPATH'],'started_unix':start}
 (C/(module+'.start.json')).write_text(json.dumps(receipt,indent=2)+'\n')
 with (C/(module+'.log')).open('w') as out:cp=subprocess.run(cmd,cwd=R,env=env,stdout=out,stderr=subprocess.STDOUT)
 log=(C/(module+'.log')).read_text();ids=re.findall(r'^test\w* \(([^)]+)\) \.\.\.',log,re.M);expected=[i for i in inventory['inventory_ids'] if i.split('.')[0]==module];footer=re.search(r'^Ran (\d+) tests? in ([\d.]+)s$',log,re.M)
 receipt.update(returncode=cp.returncode,elapsed_seconds=round(time.time()-start,3),log_sha256=sha(C/(module+'.log')),footer_present=bool(footer),footer_count=int(footer[1]) if footer else None,expected_test_count=len(expected),observed_test_ids=ids,expected_inventory_exact=ids==expected,all_frozen_files_unchanged=all(sha(R/name)==digest for name,digest in freeze['files'].items()))
 (C/(module+'.result.json')).write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'module':module,'returncode':cp.returncode,'count':receipt['footer_count'],'inventory_exact':receipt['expected_inventory_exact'],'seconds':receipt['elapsed_seconds']}),flush=True);return receipt
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:results=list(pool.map(run,inventory['continuation_modules']))
covered=set(inventory['original_completed_ids']);new=[]
for r in results:
 if r['footer_present'] and r['footer_count']==r['expected_test_count'] and r['expected_inventory_exact'] and r['all_frozen_files_unchanged']:
  covered.update(r['observed_test_ids']);new+=r['observed_test_ids']
summary={'source_head':freeze['head'],'original_monolithic_completed':False,'original_returncode':-9,'inventory_count':inventory['inventory_count'],'original_completed_count':inventory['original_completed_count'],'continuation_invocations':len(results),'continuation_completed_test_invocations':len(new),'unique_methods_covered':len(covered),'missing_ids':sorted(set(inventory['inventory_ids'])-covered),'repeated_interrupted_module_count':len(set(inventory['original_completed_ids'])&set(new)),'all_continuation_modules_terminal':all(r['footer_present'] and r['footer_count']==r['expected_test_count'] and r['expected_inventory_exact'] for r in results),'all_frozen_files_unchanged':all(sha(R/name)==digest for name,digest in freeze['files'].items()),'module_receipts':{m+'.result.json':sha(C/(m+'.result.json')) for m in inventory['continuation_modules']},'scope_note':'Inventory coverage combines the explicitly incomplete monolithic attempt with bounded same-source module continuation. Failures and skips are separate; no single full-suite pass is asserted.'}
(C/'CONTINUATION-SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2),flush=True)
