"""Source-guided DATA experiment adapter. Architecture adapter used only for schema scaffolding."""
import argparse,copy,hashlib,json,sys
from pathlib import Path
sha=lambda b:hashlib.sha256(b).hexdigest()
def load(p):return json.loads(Path(p).read_text())
def write(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def prepare(c,p):
 p=Path(p);p.mkdir(parents=True,exist_ok=False);raw=c['request'];b=c['baseline_prompt_en']
 assert sha(raw.encode())==c['request_sha256'] and sha(b.encode())==c['baseline_sha256']
 (p/'request.txt').write_bytes(raw.encode());(p/'baseline.txt').write_bytes(b.encode())
 write(p/'case.json',c)
 write(p/'request-envelope.json',{'contract_version':'photo-request-envelope/v1','provenance':'requesting_user','request_id':'synthetic-source-guided-use-trace-'+c['id'],'request_text':raw,'request_sha256':sha(raw.encode()),'active_spans':[{'span_id':'scene','start':0,'end':len(raw),'text':raw}]})
 write(p/'creative-context.json',{'subject_category':'human' if c['human'] else 'nonhuman','no_people':not c['human'],'explicit_nonsexual':True})
 review={'contract_version':'photo-embodiment-review/v1','provenance':'agent_prepack','prompt_sha256':sha(b.encode()),'scope':'body_action' if c['human'] else 'not_applicable','summary':'Text-only assessment of the stationary seated adult and described object arrangement; no image is available or assessed.' if c['human'] else 'The authored scene contains only stationary objects and environmental surfaces, with no living body or bodily action.','checks':{}}
 if c['human']:
  facts=c['request_facts'];body=facts[-1]
  reasons={'body_ownership':'The seated adult owns both described hands and feet; no overlapping person is described.','joint_chain_and_reach':'Both hands rest separately on the nearby tabletop; the seated pose does not request an impossible joint chain.','support_and_balance':'The chair supports the seated adult and both feet meet the floor.','contact_and_space':'The hands touch separate tabletop locations while the mug rests separately; no impossible grip is requested.','visibility_and_projection':'The single oblique view explicitly retains the adult and the requested object relationships together.'}
  for name,reason in reasons.items():review['checks'][name]={'status':'supported','reason':reason,'prompt_evidence':[body]}
 write(p/'embodiment-review.json',review)
def bind(p):
 p=Path(p);c=load(p/'case.json');raw=c['request'];facts=c['request_facts'];b=c['baseline_prompt_en']
 anchors=[{'anchor_id':'environment','source_text':raw,'dimension':'concept','prompt_evidence':'An environmental photograph'}]+[{'anchor_id':'relation_'+str(i+1),'source_text':raw,'dimension':'setting','prompt_evidence':f} for i,f in enumerate(facts)]+[{'anchor_id':'subject','source_text':raw,'dimension':'subject','prompt_evidence':c['subject']},{'anchor_id':'event','source_text':raw,'dimension':'event','prompt_evidence':c['event']}]
 core={'contract_version':'photo-authorial-core/v3','provenance':'agent_prepack','source_request':raw,'creative_controls_sha256':load(p/'creative-controls.json')['canonical_sha256'],'interpreted_intent':'Preserve every explicitly requested object, visible state, owner and spatial relationship; depiction does not certify an actual historical event. View and soft lighting are agent-owned photographic treatment.','subject':c['subject'],'setting':'; '.join(facts),'event':c['event'],'visual_priorities':facts[:3],'baseline_prompt_en':b,'user_definitions':[],'interpretation_provenance':[{'term':'environmental arrangement','source_text':raw,'basis':'request_context','resolution':'; '.join(facts),'sources':[]}],'unresolved_ambiguities':[],'user_exclusions':[],'runtime_forbidden_labels':[],'intent_lock':{'contract_version':'photo-intent-lock/v2','priority':'requesting_user','semantic_anchors':anchors,'locked_dimensions':['concept','subject','setting','event'],'open_dimensions':['composition','framing','lighting','camera','color','atmosphere']},'semantic_assertions':[{'assertion_id':'primary_subject_category','dimension':'subject','polarity':'required','source_span_ids':['scene'],'affected_dimensions':['subject'],'axes':{'subject_category':'human' if c['human'] else 'object'},'evidence':{'subject_phrase':c['subject']}},{'assertion_id':'requested_scene_relations','dimension':'setting','polarity':'required','source_span_ids':['scene'],'affected_dimensions':['setting'],'axes':{'spatial_arrangement':'expressly_requested_relations'},'evidence':{'relation_'+str(i+1)+'_phrase':f for i,f in enumerate(facts)}}],'request_lineage':None,'variation_key':c['id']}
 assert all(a['prompt_evidence'] in b for a in anchors)
 write(p/'authorial-core.json',core)
def normalize(root,p):
 p=Path(p);sys.path.insert(0,str(Path(root)/'skills/photo-prompt-image-generator/scripts'));import prompt_generator as g
 e=g.load_request_envelope_arg(str(p/'request-envelope.json'));c=g.load_authorial_core_arg(str(p/'authorial-core.json'),request_envelope=e,creative_control_snapshot=load(p/'creative-controls.json'))
 policy=g.photo_embodiment.build_policy(c,load(p/'embodiment-review.json'))
 assert c['baseline_prompt_en'].encode()==(p/'baseline.txt').read_bytes()
 write(p/'normalized-core.json',c);write(p/'normalized-envelope.json',e);write(p/'embodiment-policy.json',policy)
def compose(pack,c):
 core=pack['authorial_core'];lock=core['intent_lock'];b=core['baseline_prompt_en'];review=copy.deepcopy(pack['embodiment_preflight']['baseline_review']);review['provenance']='agent_postcomposition';evidence={}
 for ob in (pack.get('visual_obligations')or{}).get('obligations',[]):
  evidence[ob['id']]={}
  for name,req in ob['evidence_requirements'].items():
   matches=[v for v in req.get('must_mention_any',[]) if v in b]
   if not matches:raise ValueError('No honest literal baseline evidence for '+ob['id']+'/'+name)
   evidence[ob['id']][name]=matches[0]
 r={'core_retrieval_sha256':pack['core_retrieval']['canonical_sha256'],'pack_id':pack['pack_id'],'prompt_en':b,'negative_en':pack['negative_en'],'chosen_candidate_ids':[],'chosen_visual_concept_ids':[],'composer':'agent','embodiment_review':{'source_contract_sha256':pack['embodiment_preflight']['canonical_sha256'],'review':review},'candidate_interpretations':[],'authorial_core_binding':{'source_authorial_core_sha256':core['canonical_sha256'],'source_intent_lock_sha256':lock['canonical_sha256'],'preserved_anchor_ids':[a['anchor_id'] for a in lock['semantic_anchors']],'preserved_evidence':[],'authorial_decisions':[]},'semantic_clarification_decisions':[{'clarification_id':row['id'],'decision':'applied' if row.get('required_in_final_prompt') else 'rejected','rationale':'Retain the exact frozen requester scene and decline optional reinterpretation','prompt_evidence':c['request_facts'][0]} for row in pack['semantic_clarification']['candidates']],'creative_augmentation_brief':{'decisions':[{'candidate_id':v['id'],'decision':'rejected','rationale':'Retain the frozen environmental scene without optional additions'} for v in (pack.get('creative_augmentation')or{}).get('candidates',[])]}}
 if evidence:r['visual_obligation_evidence']=evidence
 contract=pack.get('semantic_assertion_obligations')
 if contract:r['semantic_assertion_evidence']={'source_contract_sha256':contract['canonical_sha256'],'evidence':{x['assertion_id']:x['frozen_evidence'] for x in contract['obligations']}}
 return r
def mutate(base,d,variant):
 r=copy.deepcopy(base);old=base['prompt_en'];assert d['old'] in old;r['prompt_en']=old.replace(d['old'],d['new']);assert r['prompt_en']!=old
 if variant=='refreshed_evidence':
  def rep(v):
   if isinstance(v,str):return v.replace(d['old'],d['new'])
   if isinstance(v,dict):return {k:rep(x) for k,x in v.items()}
   if isinstance(v,list):return [rep(x) for x in v]
   return v
  for k in ['semantic_clarification_decisions','visual_obligation_evidence']:
   if k in r:r[k]=rep(r[k])
  r['semantic_assertion_evidence']['evidence']=rep(r['semantic_assertion_evidence']['evidence'])
 r['embodiment_review']['review']['prompt_sha256']=sha(r['prompt_en'].encode())
 r['embodiment_review']['review']['summary']='Text-only review: the seated adult and hand/foot contacts are unchanged. The mutated object relationship is intentionally tested against original immutable requester bounds, without claiming an image observation.'
 for k in ['authorial_core_binding','core_retrieval_sha256','negative_en','pack_id']:assert r[k]==base[k]
 assert r['semantic_assertion_evidence']['source_contract_sha256']==base['semantic_assertion_evidence']['source_contract_sha256']
 return r
if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('op');a.add_argument('--root');a.add_argument('--input');a.add_argument('--case');a.add_argument('--output');a.add_argument('--variant');x=a.parse_args()
 if x.op=='prepare':prepare(load(x.case),x.output)
 elif x.op=='bind':bind(x.input)
 elif x.op=='normalize':normalize(x.root,x.input)
 elif x.op=='compose':write(x.output,compose(load(x.input)[0],load(x.case)))
 elif x.op=='mutate':write(x.output,mutate(load(x.input),load(x.case),x.variant))
