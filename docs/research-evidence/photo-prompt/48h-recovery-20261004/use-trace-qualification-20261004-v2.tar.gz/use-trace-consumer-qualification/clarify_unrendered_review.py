"""Supplementary review-schema correction, never pixel evidence; preserve v1 failures."""
import sys,runpy,copy
from pathlib import Path
O=Path(__file__).resolve().parent;sys.argv=[str(O/'runner.py'),'noop'];n=runpy.run_path(str(O/'runner.py'));run=n['run'];Q=n['Q'];load=n['load'];write=n['write'];S=n['S'];rows=[]
for arm in ['before','after']:
 for case in ['selected_en','selected_ko']:
  d=Q/'outputs'/arm/case;r=load(d/'truthful-unrendered-review.json');r['user_judgment']={'baseline_available':False,'genuinely_moe':'pending','better_than_baseline':'not_applicable','source':'not_yet_received','evidence':'No image or requesting-user assessment was obtained.'};write(d/'truthful-unrendered-review-v2.json',r)
  cp=run([sys.executable,Q/arm/S/'scripts/audit_moe_render_review.py','--pack',d/'candidate-pack.json','--composed',d/'composed.json','--review',d/'truthful-unrendered-review-v2.json'],case+'-'+arm+'-actual-unrendered-review-v2-audit',cwd=Q/arm,allowed=(0,1,2));import json;a=json.loads(cp.stdout);write(d/'unrendered-review-v2-audit.json',a);rows.append({'case':case,'arm':arm,'technical_qualified':a['technical_qualified'],'schema_failures':a['schema_failures'],'failed_hard_gates':a['failed_hard_gates']})
write(Q/'unrendered-review-v2-note.json',{'first_records_retained':True,'first_defect':'v1 used user_judgment.status=pending instead of the actual source schema fields, creating extra judgment-schema failures.','correction':'v2 only fixes pending/not_applicable judgment metadata. No image, digest or pixel gate evidence is fabricated. All v2 records must still fail because image and gate observations are absent.','rows':rows})
print('Supplementary truthful review schema corrected; no image or pixel qualification')
