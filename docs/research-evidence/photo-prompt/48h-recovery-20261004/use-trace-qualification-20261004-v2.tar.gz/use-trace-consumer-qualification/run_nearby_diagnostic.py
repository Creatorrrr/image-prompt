"""Separately frozen post-outcome nearby-control core correction; original rows remain primary."""
import sys,runpy,json,copy,hashlib
from pathlib import Path
O=Path(__file__).resolve().parent;sys.argv=[str(O/'runner.py'),'noop'];ns=runpy.run_path(str(O/'runner.py'));run=ns['run'];write=ns['write'];load=ns['load'];tree=ns['tree'];Q=ns['Q'];S=ns['S'];D=Q/'nearby-core-diagnostic-v2';D.mkdir(exist_ok=False)
cases=[]
for original in load(O/'cases.json')['cases']:
 if original['role']=='nearby':
  c=copy.deepcopy(original);c['source_case_id']=c['id'];c['id']+='_core_v2';c['subject']='the adult user';c['post_outcome_diagnostic']=True;cases.append(c)
write(D/'CASES-FREEZE.json',{'cases':cases,'reason':'Correct the subject/event/category conflation found in original nearby core: existing visible adult owns the existing seated action; all mug relationships remain in setting and immutable anchors.','actual_changes':['subject field changes from a sealed retail mug to the adult user','dependent subject evidence/anchor/core digests update; request and baseline bytes unchanged'],'independent_holdout':False,'primary_evidence_replaced':False,'original_failures_and_expectation_mismatch_preserved':True})
for c in cases:
 p=D/'inputs'/c['id'];cf=D/'case-records'/(c['id']+'.json');write(cf,c)
 run([sys.executable,O/'adapter.py','prepare','--case',cf,'--output',p],c['id']+'-prepare',assets=True)
 run([sys.executable,Q/'before'/S/'precore/creative_controls.py','--request-envelope-json',p/'request-envelope.json','--context-json',p/'creative-context.json','--seed','20261004','--output',p/'creative-controls.json'],c['id']+'-controls',cwd=Q/'before',assets=True)
 run([sys.executable,O/'adapter.py','bind','--input',p],c['id']+'-bind',assets=True)
 run([sys.executable,O/'adapter.py','normalize','--root',Q/'before','--input',p],c['id']+'-normalize',assets=True)
write(D/'INPUT-FREEZE.json',{'files_sha256':tree(D/'inputs'),'candidate_packs_generated':0,'driver_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()})
rows=[]
for c in cases:
 for arm in ['before','after']:
  root=Q/arm;p=D/'inputs'/c['id'];d=D/'outputs'/arm/c['id'];d.mkdir(parents=True,exist_ok=False)
  run([sys.executable,root/S/'scripts/generate_photo_prompt.py','--request-envelope-json',p/'request-envelope.json','--authorial-core-json',p/'authorial-core.json','--creative-controls-json',p/'creative-controls.json','--embodiment-review-json',p/'embodiment-review.json','--seed','20261004','--output-file',d/'candidate-pack.json'],c['id']+'-'+arm+'-actual-generator',cwd=root)
  run([sys.executable,O/'adapter.py','compose','--input',d/'candidate-pack.json','--case',D/'case-records'/(c['id']+'.json'),'--output',d/'composed.json'],c['id']+'-'+arm+'-compose')
  cp=run([sys.executable,root/S/'scripts/audit_composed_prompt.py','--pack',d/'candidate-pack.json','--composed',d/'composed.json'],c['id']+'-'+arm+'-actual-audit',cwd=root,allowed=(0,1));a=json.loads(cp.stdout);write(d/'audit.json',a);pack=load(d/'candidate-pack.json')[0];rows.append({'case':c['id'],'arm':arm,'audit_status':a['status'],'failures':a['failures'],'hard_ids':[v['id'] for v in (pack.get('visual_obligations')or{}).get('obligations',[])]});write(D/'results.json',rows);print(c['id'],arm,a['status'],flush=True)
