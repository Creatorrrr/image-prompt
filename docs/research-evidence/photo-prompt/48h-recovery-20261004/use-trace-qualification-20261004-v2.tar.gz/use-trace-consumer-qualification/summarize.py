"""Evaluate observed evidence against the retained freeze; no rewritten expectations."""
import json,hashlib,subprocess
from pathlib import Path
O=Path(__file__).resolve().parent;Q=O/'run-001';R=O.parents[1]/'image-prompt-pr5-source';S='skills/photo-prompt-image-generator'
sha=lambda b:hashlib.sha256(b).hexdigest()
load=lambda p:json.loads(Path(p).read_text())
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def tree(p):return {str(f.relative_to(p)):sha(f.read_bytes()) for f in sorted(p.rglob('*')) if f.is_file() and '__pycache__' not in f.parts}
def diff(a,b,path=''):
 if type(a)!=type(b):return [{'path':path,'before':a,'after':b}]
 if isinstance(a,dict):return [r for k in sorted(set(a)|set(b)) for r in diff(a.get(k),b.get(k),path+'/'+k)]
 if isinstance(a,list):
  if len(a)!=len(b):return [{'path':path,'before':a,'after':b}]
  return [r for i,(x,y) in enumerate(zip(a,b)) for r in diff(x,y,path+'/'+str(i))]
 return [] if a==b else [{'path':path,'before':a,'after':b}]
cases=load(O/'cases.json')['cases'];rows=load(Q/'results.json');paired=[];expect=[]
for c in cases:
 bs=[Q/'outputs'/arm/c['id'] for arm in ['before','after']];packs=[load(p/'candidate-pack.json')[0] for p in bs];composed=[load(p/'composed.json') for p in bs]
 dp=diff(*packs);dc=diff(*composed);write(Q/(c['id']+'-pack-diff.json'),dp)
 pair={'case':c['id'],'cohort':'source_guided','baseline_unchanged_both':all(x['prompt_en'].encode()==c['baseline_prompt_en'].encode() for x in composed),'composed_equal':composed[0]==composed[1],'composed_diff':dc,'pack_diff_paths':[x['path'] for x in dp],'core_equal':packs[0]['authorial_core']==packs[1]['authorial_core'],'core_retrieval_equal':packs[0]['core_retrieval']==packs[1]['core_retrieval'],'embodiment_equal':packs[0]['embodiment_preflight']==packs[1]['embodiment_preflight'],'negative_equal':packs[0]['negative_en']==packs[1]['negative_en'],'optional_order_equal':[v['id'] for v in (packs[0].get('visual_concept_candidates')or{}).get('candidates',[])]==[v['id'] for v in (packs[1].get('visual_concept_candidates')or{}).get('candidates',[])]}
 
 keyed=[{v['id']:v for v in (pack.get('visual_concept_candidates')or{}).get('candidates',[])} for pack in packs]
 pair['optional_membership_equal']=set(keyed[0])==set(keyed[1]);pair['optional_content_diffs_keyed_by_id']=diff(*keyed);pair['optional_orders']=[list(x) for x in keyed];pair['composed_content_except_pack_id_equal']={k:v for k,v in composed[0].items() if k!='pack_id'}=={k:v for k,v in composed[1].items() if k!='pack_id'};pair['frozen_pair_invariance_met']=pair['optional_order_equal'] and pair['composed_content_except_pack_id_equal'] and all(r['path'].endswith('/render_gates/0/description') for r in pair['optional_content_diffs_keyed_by_id'])
 paired.append(pair)
 for arm in ['before','after']:
  r=next(r for r in rows if r['case']==c['id'] and r['arm']==arm);observed='rb_use_trace_affordance' in r['hard_ids'];expect.append({'case':c['id'],'arm':arm,'frozen_hard_expected':c['expected_use_trace_hard'],'hard_observed':observed,'frozen_expectation_met':observed==c['expected_use_trace_hard'],'audit_status':r['audit_status']})
mr=load(Q/'mutation-results.json');mut=[]
for row in mr:
 d=Q/'mutations'/row['arm']/row['id']/row['variant'];definition=load(d/'definition.json');base=load(Q/'outputs'/row['arm']/definition['source_case']/'composed.json');actual=load(d/'composed.json')
 mut.append({**row,'actual_prose_changed':actual['prompt_en']!=base['prompt_en'],'old_full_phrase_absent':definition['old'] not in actual['prompt_en'],'immutable_binding_preserved':all(actual[k]==base[k] for k in ['authorial_core_binding','core_retrieval_sha256','pack_id','negative_en']),'intent_lock_content_rejection':any(x['check']=='intent_lock_prompt_evidence' for x in row['failures']),'visual_evidence_rejections':[x for x in row['failures'] if 'visual' in x['check']]})
initial=load(Q/'source-skill-hashes.json');current=tree(R/S);bt=tree(Q/'before'/S);at=tree(Q/'after'/S);source_delta=[k for k in sorted(set(initial)|set(current)) if initial.get(k)!=current.get(k)];arm_delta=[k for k in sorted(set(bt)|set(at)) if bt.get(k)!=at.get(k)]
proposal=load(O/'scaffolding/narrow-alternative.json');profilediff=diff(load(Q/'before'/proposal['source_file']),load(Q/'after'/proposal['source_file']))
render=[]
for c in cases:
 for arm in ['before','after']:
  p=Q/'outputs'/arm/c['id'];r=load(p/'effective-render-contract.json');contract=r['effective_contract'];gates=[g for ob in (contract or {}).get('obligations',[]) for g in ob.get('render_gates',[])];tg=[g for g in gates if g['id'].startswith('vo_rb_use_trace_affordance')];render.append({'case':c['id'],'arm':arm,'selection_failures':r['selection_failures'],'effective_target_gates':tg,'unrendered_review_v2_audit':load(p/'unrendered-review-v2-audit.json') if (p/'unrendered-review-v2-audit.json').exists() else None,'unrendered_review_audit':load(p/'unrendered-review-audit.json') if (p/'unrendered-review-audit.json').exists() else None})
tests=load(Q/'test-results.json')
summary={'decision':'DEFER_SOURCE_PROMOTION_NO_OBJECTIVE_CONSUMER_QUALITY_GAIN_DEMONSTRATED','runtime_sha':'776ce8dfa1791c2ec9d13ba21490a7651c2cf2ad','prerelease_only':True,'source_guided_not_fresh':True,'original_case_count':len(cases),'original_cli_audits':len(rows),'original_composed_passes':sum(r['audit_status']=='pass' for r in rows),'paired':paired,'frozen_expectations':expect,'strict_qualification':False,'strict_failure_reasons':['Original selected_ko hard-activation expectation unmet in both arms; English-only exact activation retained','Original nearby controls conflate mug subject with adult action/category; supplementary correction does not repair primary evidence','Five optional public candidate-list permutations exceed literal frozen pair-invariance expectation; candidate membership and keyed content except target description remain unchanged'],'strict_all_frozen_expectations_met':all(r['frozen_expectation_met'] for r in expect),'render_propagation':render,'mutation_rows':mut,'mutation_count':len(mut),'actual_prose_content_rejections':sum(x['intent_lock_content_rejection'] for x in mut),'nearby_control_design_limit':'Original nearby subject/event/category conflation remains in initial rows; separately frozen post-outcome diagnostic is supplementary only.','nearby_diagnostic_results':load(Q/'nearby-core-diagnostic-v2/results.json'),'existing_tests':tests,'source_unchanged':not source_delta,'source_delta':source_delta,'arm_skill_diff_files':arm_delta,'profile_leaf_diff':profilediff,'both_scripts_unchanged':tree(R/S/'scripts')==tree(Q/'before'/S/'scripts')==tree(Q/'after'/S/'scripts'),'both_tests_unchanged':tree(R/'tests')==tree(Q/'before'/'tests')==tree(Q/'after'/'tests'),'input_freeze_preserved':tree(Q/'inputs')==load(Q/'INPUT-FREEZE.json')['files_sha256'],'all_1622_index_entries_texts_vectors_unchanged':all(load(Q/(a+'-index-receipt.json'))['entries_unchanged'] and load(Q/(a+'-index-receipt.json'))['profile_count']==1622 for a in ['before','after']),'guard_attempts':load(Q/'blocked-operations.jsonl') if (Q/'blocked-operations.jsonl').exists() else [],'images_generated':0,'pixel_reviews_performed':0,'provider_calls':0,'source_installation':False,'publication':False,'objective_consumer_quality_gain_demonstrated':False,'claim':'Explicit selected-depiction/history wording reaches an actual effective English hard gate; unchanged static audits and synthetic records do not establish human error reduction, narrative image quality, or retrieval improvement.'}
write(Q/'SUMMARY.json',summary)
print(json.dumps({k:v for k,v in summary.items() if k not in ['paired','frozen_expectations','render_propagation','mutation_rows','profile_leaf_diff']},ensure_ascii=False,indent=2))
