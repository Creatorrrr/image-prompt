import os,sys,json,hashlib,shutil,subprocess,time
from pathlib import Path
O=Path(__file__).resolve().parent;R=O.parents[1]/'image-prompt-pr5-source';Q=O/'run-001';S='skills/photo-prompt-image-generator';SHA='776ce8dfa1791c2ec9d13ba21490a7651c2cf2ad'
sha=lambda b:hashlib.sha256(b).hexdigest()
def load(p):return json.loads(Path(p).read_text())
def write(p,x):p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def tree(p):return {str(f.relative_to(p)):sha(f.read_bytes()) for f in sorted(p.rglob('*')) if f.is_file() and '__pycache__' not in f.parts}
def git(*a):return subprocess.check_output(['git',*a],cwd=R,text=True).strip()
def run(argv,label,cwd=None,allowed=(0,),assets=False,tests=False,timeout=900):
 logs=Q/'commands';logs.mkdir(parents=True,exist_ok=True);n=len(list(logs.glob('*.command.json')))+1;stem=logs/(str(n).zfill(4)+'-'+label)
 env={k:os.environ[k] for k in ('PATH','HOME','LANG','LC_ALL','TZ','TMPDIR') if k in os.environ};env.update(PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=str(O/'guards'),ARCH_GUARD_LOG=str(Q/'blocked-operations.jsonl'))
 if assets:env['ARCH_DENY_ASSETS']='1'
 if tests:env.update(ARCH_ALLOWED_TEST_CLI=str(Path(cwd)/S/'scripts/generate_photo_prompt.py'),ARCH_ALLOWED_CHILD_LOG=str(Q/'allowed-test-child-invocations.jsonl'))
 write(str(stem)+'.command.json',{'argv':list(map(str,argv)),'cwd':str(cwd or Q),'runtime_sha':SHA,'network':'denied by process audit guard; no credential environment','runner_sha256':sha(Path(__file__).read_bytes()),'guard_sha256':sha((O/'guards/sitecustomize.py').read_bytes())});start=time.time()
 cp=subprocess.run(list(map(str,argv)),cwd=cwd or Q,env=env,capture_output=True,text=True,timeout=timeout)
 Path(str(stem)+'.stdout.txt').write_text(cp.stdout);Path(str(stem)+'.stderr.txt').write_text(cp.stderr);write(str(stem)+'.exit.json',{'returncode':cp.returncode,'seconds':round(time.time()-start,3)})
 if (Q/'blocked-operations.jsonl').exists():raise RuntimeError('Isolation operation attempted; stop and inspect')
 if cp.returncode not in allowed:raise RuntimeError('Command failed; retained: '+str(stem))
 return cp
assert git('rev-parse','HEAD')==SHA and not git('status','--porcelain')
for n,h in load(O/'DESIGN-FREEZE.json')['files_sha256'].items():assert sha((O/n).read_bytes())==h,n
phase=sys.argv[1]
if phase=='prepare':
 Q.mkdir(exist_ok=False);write(Q/'source-skill-hashes.json',tree(R/S));write(Q/'source-test-hashes.json',tree(R/'tests'));write(Q/'execution-tool-hashes.json',{str(p.relative_to(O)):sha(p.read_bytes()) for p in [O/'adapter.py',O/'runner.py',O/'index_receipt.py',O/'guards/sitecustomize.py']})
 for arm in ['before','after']:
  d=Q/arm;(d/'skills').mkdir(parents=True);shutil.copytree(R/S,d/S,symlinks=False,ignore=shutil.ignore_patterns('__pycache__','*.pyc'));shutil.copytree(R/'tests',d/'tests',symlinks=False,ignore=shutil.ignore_patterns('__pycache__','*.pyc'));shutil.copytree(R/'docs',d/'docs',symlinks=False,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
  assert not any(p.is_symlink() or (p.is_file() and p.stat().st_nlink>1) for p in d.rglob('*'))
  assert tree(d/S)==load(Q/'source-skill-hashes.json')
 candidate=load(O/'scaffolding/narrow-alternative.json');f=Q/'after'/candidate['source_file'];assert sha(f.read_bytes())==candidate['source_sha256'];j=load(f);p=j['profiles'][1];assert p['id']==candidate['profile_id'];g=p['authored_components']['components'][0]['render_gate'];assert g['description']==candidate['old'];g['description']=candidate['proposed'];write(f,j)
 print('isolated source copies prepared')
elif phase=='inputs':
 for c in load(O/'cases.json')['cases']:
  p=Q/'inputs'/c['id'];cf=Q/'case-records'/(c['id']+'.json');write(cf,c)
  run([sys.executable,O/'adapter.py','prepare','--case',cf,'--output',p],c['id']+'-prepare',assets=True)
  run([sys.executable,Q/'before'/S/'precore/creative_controls.py','--request-envelope-json',p/'request-envelope.json','--context-json',p/'creative-context.json','--seed','20261004','--output',p/'creative-controls.json'],c['id']+'-controls',cwd=Q/'before',assets=True)
  run([sys.executable,O/'adapter.py','bind','--input',p],c['id']+'-bind',assets=True)
  run([sys.executable,O/'adapter.py','normalize','--root',Q/'before','--input',p],c['id']+'-normalize',assets=True)
 write(Q/'INPUT-FREEZE.json',{'files_sha256':tree(Q/'inputs'),'candidate_packs_generated':0,'input_failure_records':'All command exits retained; never overwritten'})
 print('all 8 inputs frozen before generator arm execution')
elif phase=='indexes':
 cache=Q/'reference-cache.json';assert not cache.exists();shutil.copy2(R/S/'assets/photo_prompt_visual_profile_index.json',cache)
 for arm in ['before','after']:
  root=Q/arm;extra=['--expect-stale'] if arm=='after' else []
  run([sys.executable,O/'index_receipt.py','preflight','--root',root,'--cache',cache,'--output',Q/(arm+'-cache-preflight.json'),*extra],arm+'-cache-preflight')
  run([sys.executable,root/S/'scripts/build_visual_profile_index.py','--cache-index',cache,'--batch-size','1'],arm+'-actual-full-registry-build',cwd=root)
  run([sys.executable,root/S/'scripts/build_visual_profile_index.py','--check'],arm+'-actual-index-check',cwd=root)
  run([sys.executable,O/'index_receipt.py','verify','--root',root,'--cache',cache,'--output',Q/(arm+'-index-receipt.json'),*extra],arm+'-index-verify')
 print('both full indexes rebuilt')
elif phase=='runs':
 assert tree(Q/'inputs')==load(Q/'INPUT-FREEZE.json')['files_sha256'];rows=[]
 for c in load(O/'cases.json')['cases']:
  for arm in ['before','after']:
   root=Q/arm;p=Q/'inputs'/c['id'];d=Q/'outputs'/arm/c['id'];d.mkdir(parents=True,exist_ok=False)
   run([sys.executable,root/S/'scripts/generate_photo_prompt.py','--request-envelope-json',p/'request-envelope.json','--authorial-core-json',p/'authorial-core.json','--creative-controls-json',p/'creative-controls.json','--embodiment-review-json',p/'embodiment-review.json','--seed','20261004','--output-file',d/'candidate-pack.json'],c['id']+'-'+arm+'-actual-generator',cwd=root)
   run([sys.executable,O/'adapter.py','compose','--input',d/'candidate-pack.json','--case',Q/'case-records'/(c['id']+'.json'),'--output',d/'composed.json'],c['id']+'-'+arm+'-compose')
   cp=run([sys.executable,root/S/'scripts/audit_composed_prompt.py','--pack',d/'candidate-pack.json','--composed',d/'composed.json'],c['id']+'-'+arm+'-actual-audit',cwd=root,allowed=(0,1));a=json.loads(cp.stdout);write(d/'audit.json',a);pack=load(d/'candidate-pack.json')[0]
   row={'case':c['id'],'arm':arm,'audit_status':a['status'],'failures':a['failures'],'warnings':a['warnings'],'hard_ids':[v['id'] for v in (pack.get('visual_obligations')or{}).get('obligations',[])],'optional_ids':[v['id'] for v in (pack.get('visual_concept_candidates')or{}).get('candidates',[])]};rows.append(row);write(Q/'results.json',rows);print(c['id'],arm,row['audit_status'],row['hard_ids'],flush=True)
elif phase=='mutations':
 rows=[]
 for de in load(O/'mutations.json')['cases']:
  for arm in ['before','after']:
   src=Q/'outputs'/arm/de['source_case'];assert load(src/'audit.json')['status']=='pass'
   for variant in ['stale_evidence','refreshed_evidence']:
    dest=Q/'mutations'/arm/de['id']/variant;dest.mkdir(parents=True,exist_ok=False);write(dest/'definition.json',de)
    run([sys.executable,O/'adapter.py','mutate','--input',src/'composed.json','--case',dest/'definition.json','--variant',variant,'--output',dest/'composed.json'],de['id']+'-'+arm+'-'+variant+'-mutate')
    cp=run([sys.executable,Q/arm/S/'scripts/audit_composed_prompt.py','--pack',src/'candidate-pack.json','--composed',dest/'composed.json'],de['id']+'-'+arm+'-'+variant+'-actual-audit',cwd=Q/arm,allowed=(0,1));a=json.loads(cp.stdout);write(dest/'audit.json',a);rows.append({'id':de['id'],'arm':arm,'variant':variant,'status':a['status'],'failures':a['failures']});write(Q/'mutation-results.json',rows)
 print('32 prose mutation audits recorded')
elif phase=='tests':
 rows=[]
 modules=['tests.test_photo_realistic_background_semantics','tests.test_photo_visual_profile_retrieval','tests.test_photo_visual_obligations','tests.test_photo_embodiment']
 for arm in ['before','after']:
  root=Q/arm
  cp=run([sys.executable,'-m','unittest',*modules,'-v'],arm+'-existing-focused-tests',cwd=root,allowed=(0,1),tests=True,timeout=1800)
  vp=run([sys.executable,root/S/'scripts/validate_photo_prompt_dictionary.py'],arm+'-dictionary-validator',cwd=root,allowed=(0,1),timeout=1200)
  rows.append({'arm':arm,'modules':modules,'unittest_exit':cp.returncode,'dictionary_exit':vp.returncode,'full_suite':False});write(Q/'test-results.json',rows)
 print(rows)
assert git('rev-parse','HEAD')==SHA and not git('status','--porcelain')
