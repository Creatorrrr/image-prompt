"""Additional read-only consumer inspection using the original frozen runner guard."""
import sys,runpy,json
from pathlib import Path
O=Path(__file__).resolve().parent;sys.argv=[str(O/'runner.py'),'noop'];ns=runpy.run_path(str(O/'runner.py'));run=ns['run'];write=ns['write'];load=ns['load'];Q=ns['Q'];S=ns['S']
rows=[]
for c in load(O/'cases.json')['cases']:
 for arm in ['before','after']:
  root=Q/arm;d=Q/'outputs'/arm/c['id'];f=d/'effective-render-contract.json'
  run([sys.executable,O/'inspect_propagation.py',root,d/'candidate-pack.json',d/'composed.json',f],c['id']+'-'+arm+'-production-render-contract',cwd=root)
  eff=load(f);rows.append({'case':c['id'],'arm':arm,'effective_contract':eff['effective_contract'],'selection_failures':eff['selection_failures']})
  if c['role']=='selected':
   pack=load(d/'candidate-pack.json')[0];review={'schema_version':'moe-render-review/v1','pack_id':pack['pack_id'],'contract_version':(eff['effective_contract'] or pack['embodiment_preflight'])['contract_version'],'reviewer':'source-guided-no-pixel-inspection-performed','result_image':'','result_sha256':'','hard_gates':{},'user_judgment':{'source':'not_yet_received','status':'pending'},'scope_note':'No image exists in this experiment. No observed pixel or hard-gate verdict is claimed.'};write(d/'truthful-unrendered-review.json',review)
   cp=run([sys.executable,root/S/'scripts/audit_moe_render_review.py','--pack',d/'candidate-pack.json','--composed',d/'composed.json','--review',d/'truthful-unrendered-review.json'],c['id']+'-'+arm+'-actual-unrendered-review-audit',cwd=root,allowed=(0,1,2));write(d/'unrendered-review-audit.json',json.loads(cp.stdout))
write(Q/'propagation-results.json',rows)
print('Actual effective render checklist inspected for all pairs; unrendered review remains unqualified')
