"""Production-derived render checklist only; no image or pixel review."""
import sys,json,hashlib
from pathlib import Path
root,packfile,composedfile,out=sys.argv[1:];sys.path.insert(0,str(Path(root)/'skills/photo-prompt-image-generator/scripts'));import audit_composed_prompt as audit
load=lambda p:json.loads(Path(p).read_text());pack=load(packfile)[0];composed=load(composedfile)
contract,failures=audit.derive_effective_visual_obligation_contract(pack,composed)
Path(out).write_text(json.dumps({'effective_contract':contract,'selection_failures':failures,'boundary':'The actual rendered-review consumer calls this production derivation; description propagation is inspected without rendering or scoring pixels.'},ensure_ascii=False,indent=2)+'\n')
