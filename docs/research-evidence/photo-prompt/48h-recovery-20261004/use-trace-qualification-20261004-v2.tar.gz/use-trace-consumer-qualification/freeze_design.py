import json,hashlib
from pathlib import Path
O=Path(__file__).resolve().parent;R=O.parents[1]/'image-prompt-pr5-source'
sha=lambda b:hashlib.sha256(b).hexdigest()
def write(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
rel=['a recently used object rests on a stable working surface',"the object is placed within the user's reach",'the adjacent walking route remains clear']
body='the adult user sits upright on a chair with both feet on the floor and both hands resting separately on the tabletop'
owner='the recently used object is a clean drinking mug beside a folded cloth on the table'
rows=[
('selected','en','Make an environmental photograph: '+'; '.join(rel+[owner,body])+'.',rel+[owner,body],True),
('selected','ko','환경 사진을 만들어 주세요. 방금 사용한 물건이 안정된 작업면 위에 놓여 있고, 그 물건은 사용자의 손이 닿는 위치에 있으며, 옆 통로는 비어 있습니다. 그 물건은 탁자 위 접은 천 옆의 깨끗한 음료 머그잔입니다. 성인 사용자는 의자에 상체를 세워 앉아 양발을 바닥에 대고 두 손을 각각 탁자에 얹고 있습니다.',rel+[owner,body],True),
('partial','en','Make an environmental photograph: '+rel[0]+'. The recently used object is a clean drinking mug on a table.',[rel[0],'the recently used object is a clean drinking mug on a table'],False),
('partial','ko','환경 사진을 만들어 주세요. 방금 사용한 물건이 안정된 작업면에 놓여 있습니다. 그 물건은 탁자 위의 깨끗한 음료 머그잔입니다.',[rel[0],'the recently used object is a clean drinking mug on a table'],False),
('nearby','en','Make an environmental photograph: a sealed retail mug stands on a stable tabletop; the mug is within the seated adult shopper\'s reach; the adjacent walking route remains clear; '+body+'.',['a sealed retail mug stands on a stable tabletop',"the mug is within the seated adult shopper's reach",rel[2],body],False),
('nearby','ko','환경 사진을 만들어 주세요. 밀봉된 판매용 머그잔이 안정된 탁자 위에 서 있고, 앉아 있는 성인 손님의 손이 닿는 위치에 있으며, 옆 통로는 비어 있습니다. 성인 손님은 의자에 상체를 세워 앉아 양발을 바닥에 대고 두 손을 각각 탁자에 얹고 있습니다.',['a sealed retail mug stands on a stable tabletop',"the mug is within the seated adult shopper's reach",rel[2],body],False),
('effect','en','Make an environmental photograph: a wet stone path reflects a nearby window; the dry wall remains matte; the stone surface stays readable.',['a wet stone path reflects a nearby window','the dry wall remains matte','the stone surface stays readable'],False),
('effect','ko','환경 사진을 만들어 주세요. 젖은 돌길이 가까운 창문을 반사하고, 마른 벽은 무광 상태를 유지하며, 돌 표면은 읽을 수 있게 보입니다.',['a wet stone path reflects a nearby window','the dry wall remains matte','the stone surface stays readable'],False)]
cases=[]
for role,lang,request,facts,human in rows:
 b='An environmental photograph shows this arrangement: '+'; '.join(facts)+'. A measured oblique view keeps the requested owners and spatial relationships visible together in one frame. Soft daylight describes the surfaces, while restrained tonal separation gives the principal objects visual priority. The surrounding detail remains subordinate to the requested scene.'
 subject=('the adult user' if role=='selected' else 'a sealed retail mug' if role=='nearby' else 'a clean drinking mug' if role=='partial' else 'a wet stone path')
 event=('sits upright on a chair' if human else 'rests on a stable working surface' if role=='partial' else 'reflects a nearby window')
 cases.append(dict(id=role+'_'+lang,role=role,language=lang,cohort='source_guided',source_exposed=True,independent_holdout=False,request=request,request_facts=facts,baseline_prompt_en=b,request_sha256=sha(request.encode()),baseline_sha256=sha(b.encode()),human=human,subject=subject,event=event,expected_use_trace_hard=(role=='selected'),expected_paired_behavior='identical outside revised description and derived binding metadata'))
write(O/'cases.json',{'cases':cases,'authoring_basis':'Original relation source and reviewed clarification, inspected before drafting. No independence or unexposed-input claim.'})
mutations=[]
for lang in ['en','ko']:
 for name,old,new in [('support',rel[0],'a recently used object floats above a working surface'),('reach',rel[1],"the object is placed beyond the user's reach"),('passage',rel[2],'the adjacent walking route is blocked by a crate'),('use_role',rel[0],'an unopened retail object rests on a stable working surface')]:
  mutations.append(dict(id=name+'_'+lang,source_case='selected_'+lang,old=old,new=new,kind='replace_actual_prose',expected='reject missing immutable literal scene evidence; do not infer semantic detector or pixel failure'))
write(O/'mutations.json',{'cases':mutations})
plan={'runtime_sha':'776ce8dfa1791c2ec9d13ba21490a7651c2cf2ad','source':str(R),'status':'FROZEN_BEFORE_ARM_RUNS','design':'Same-runtime paired unchanged baseline and one-leaf gate-description candidate; selected depiction versus historical certification clarification only.','cases':8,'arms':2,'source_guided':True,'fresh_independence':False,'candidate':json.loads((O/'scaffolding/narrow-alternative.json').read_text()),'rejected_first_proposal':'Preserved in scaffolding/rejected-first-proposal.json; never an accepted arm.','scope':['Local isolated full skill and test copies, regular independent files','Actual public full index builder using all and only genuine compatible cached vectors','Actual public generator and composed audit with exact frozen baseline unchanged across arms','Actual effective rendered-review contract derivation, inspect gate description propagation','Actual prose removal of support, reach, passage, use-role while preserving immutable bounds; stale and refreshed mutable evidence variants','Existing unit tests as structural regressions only','Truthful missing-image review record must not receive pixel qualification'],'no':['source/runtime/test edits','network','provider calls','images','uploads','main change','publication','generated pixel quality claims','numeric semantic improvement claims from schema passes'],'decision_rules':['Stop/DEFER if vectors missing or incompatible, requested semantics undefined, source differs, extra data/source change needed, renderer/preferences/runtime change needed','Improvement requires objective difference beyond clearer human-review wording; wording alone may be useful but is not consumer-quality qualification','Do not weaken visible selected use, support, reach, passage, owner coverage or immutable requester bounds'],'first_failure_policy':'Retain every command, input, exit and failed artifact. Any adapter correction gets a separately archived version and explanation before rerun.'}
write(O/'PLAN.json',plan)
files=['cases.json','mutations.json','PLAN.json']+[str(p.relative_to(O)) for p in sorted((O/'scaffolding').glob('*'))]
write(O/'DESIGN-FREEZE.json',{'files_sha256':{n:sha((O/n).read_bytes()) for n in files},'arms_executed':0,'created_utc':'2026-10-04T02:28Z'})
print('Frozen 8 source-guided inputs, 8 mutation definitions and plan before any arm run')
