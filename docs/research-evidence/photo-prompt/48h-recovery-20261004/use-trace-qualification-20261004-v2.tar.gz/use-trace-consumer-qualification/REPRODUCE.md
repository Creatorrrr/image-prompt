# Local reproduction and preservation

No production installation, network, provider request, image generation or upload is part of reproduction. Use the same locally available clean source at `776ce8dfa1791c2ec9d13ba21490a7651c2cf2ad`; abort if its manifest differs. This is prerelease-only evidence.

## Authoritative inputs

Use `cases.json`, `PLAN.json`, `DESIGN-FREEZE.json` and `run-001/INPUT-FREEZE.json`. Do not rerun the authoring script `freeze_design.py` as if it were a fresh holdout: its first authored design had the explicitly preserved nearby applicability issue. Original and corrected design versions remain archived. The freeze's minute-level created_utc value is an author-entered approximate label, not a trusted timestamp; recorded tool sequence and input hashes establish that freezing preceded generator arm execution.

## Reconstruct fresh isolated arms

1. Use a new sibling qualification directory; never overwrite this run. Copy the retained harness, guard, candidate and frozen input artifacts
2. Make regular independent copies of the source photo-prompt skill and tests. Copy only the real `docs/research-evidence/photo-prompt/extension-maintenance` dependency files used by the existing tests/validator. Do not copy historical nested qualification archives, which contain the initial dangling symlinks recorded in this run
3. Verify both initial skills against `source-skill-hashes.json`, tests against `source-test-hashes.json`, and absence of symlinks/hardlinks. Apply exactly the narrow candidate's one JSON description to the after copy, checking its old value and original source SHA first
4. Copy the genuine source visual-profile cache. Run the exact recorded preflight, public full-index builder, index check and verification commands with only local paths rebased. Require all 1,622 actual profiles and cached text/vector equality; stop if anything would need embedding
5. Execute the recorded actual generator and composed-auditor commands on frozen inputs, preserving the frozen English baseline unchanged. The guard suppresses bytecode writes, removes credential environment variables and denies network, credential-file access and unreviewed child processes
6. Execute the frozen actual-prose mutation definitions, preserving immutable pack/core bindings; run actual composed audits. Preserve both stale/refreshed mutable-evidence variants and all failures
7. Inspect the actual production effective-render contract. Use existing truthful unrendered original/v2 records only as missing-evidence diagnostics; never supply invented pixels or passing gates
8. Run the recorded existing four unittest modules and dictionary validator on each arm. A full suite is not implied

`run-001/commands/` records actual argv, cwd, stdout, stderr, exit, elapsed time and runtime/guard/runner identifiers. The original preparation failure was an outer compound-shell operation and has a separate retained tool-output receipt; it is not falsely presented as a fully instrumented standalone process.

`runner.py` is the exact initially executed runner and intentionally remains unchanged, including its over-broad original docs-copy preparation. Use the explicit clean staging sequence above for a fresh replay; do not repeat that known unnecessary copy failure. The original recovery helper is preserved as evidence of this run, not a mandate to fabricate the same first-failure transcript in a new run.

The corrected nearby-control diagnostic and corrected v2 unrendered records are supplementary, explicitly post-outcome work. Do not replace original rows, remove the Korean expectation mismatch, or convert strict qualification to true. The compact evidence archive excludes bulky unchanged source copies and cache/index binaries; their hashes and full local snapshots remain available in the working qualification directory.
