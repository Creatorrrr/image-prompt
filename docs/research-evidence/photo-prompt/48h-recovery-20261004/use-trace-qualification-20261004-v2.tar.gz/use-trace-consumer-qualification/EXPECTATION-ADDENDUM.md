# Preserved frozen expectation and coverage limit

The frozen plan's selected_ko.expected_use_trace_hard=true is not met: neither arm creates a hard use-trace obligation. The request is natural Korean, while this profile intentionally has one English exact activation phrase. The unchanged English translated baseline does not make the Korean request an exact activation source. The same optional profile can be discovered without becoming mandatory.

The original expectation is retained verbatim. This is a harness expectation mismatch and limits selected-hard-gate coverage to English; it is not evidence of a gate-only regression or lost requested meaning. Strict all-frozen-criteria qualification remains false. Actual prose and generic immutable requester bounds are evaluated separately, without adding an alias, changing the request, or forcing bilingual hard-profile parity.

The original nearby controls also bind the mug subject to the seated adult's event in the core representation, with human subject-category metadata. Their literal request/baseline remains intact, but those rows alone cannot count as clean core-semantic negative evidence. Preserve the first rows and disclose any later separately frozen correction rather than replacing their evidence.
