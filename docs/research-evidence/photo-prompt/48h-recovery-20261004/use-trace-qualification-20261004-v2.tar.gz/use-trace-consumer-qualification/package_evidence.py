"""Package local text/code/evidence only; no uploads or copied runtime snapshots."""
import json,hashlib,tarfile
from pathlib import Path
O=Path(__file__).resolve().parent;P=O.parent;V=P/'use-trace-consumer-review';B=O/'backups';B.mkdir(exist_ok=True);sha=lambda b:hashlib.sha256(b).hexdigest()
files=[]
for root in [O,V]:
 for f in sorted(root.rglob('*')):
  if not f.is_file():continue
  rel=f.relative_to(root)
  if root==O and (rel.parts[0]=='backups' or (rel.parts[0]=='run-001' and len(rel.parts)>1 and rel.parts[1] in {'before','after','reference-cache.json'})):continue
  assert not f.is_symlink() and f.stat().st_nlink==1
  files.append(f)
manifest={'kind':'local text/code/evidence archive; unchanged source copies and 31MB index/cache binaries excluded','source_runtime_sha':'776ce8dfa1791c2ec9d13ba21490a7651c2cf2ad','files_sha256':{str(f.relative_to(P)):sha(f.read_bytes()) for f in files},'file_count':len(files),'uncompressed_bytes':sum(f.stat().st_size for f in files),'no_upload_performed':True}
m=B/'use-trace-qualification-20261004.manifest.json';m.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n');out=B/'use-trace-qualification-20261004.tar.gz';assert not out.exists()
with tarfile.open(out,'w:gz') as t:
 for f in files:t.add(f,arcname=str(f.relative_to(P)),recursive=False)
 t.add(m,arcname='use-trace-consumer-qualification/backups/'+m.name,recursive=False)
with tarfile.open(out,'r:gz') as t:
 members=[x for x in t.getmembers() if x.isfile()]
 for x in members:
  expected=manifest['files_sha256'].get(x.name)
  if expected:assert sha(t.extractfile(x).read())==expected
 assert len(members)==len(files)+1
receipt={'archive':str(out),'archive_sha256':sha(out.read_bytes()),'archive_bytes':out.stat().st_size,'manifest':str(m),'manifest_sha256':sha(m.read_bytes()),'files_verified':len(files),'excluded':['before/after source snapshots','reference-cache.json'],'contents':'text, JSON, Python, Markdown and logs; no generated images','publication_or_upload':False}
(B/'ARCHIVE-RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
