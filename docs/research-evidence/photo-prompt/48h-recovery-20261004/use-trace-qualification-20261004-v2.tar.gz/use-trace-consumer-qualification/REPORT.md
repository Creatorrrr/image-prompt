# Use-trace render-gate consumer qualification

## Decision: DEFER production change

The narrower candidate is a defensible human-review wording clarification, but **no objective consumer-quality gain was demonstrated**. It explicitly separates a selected recent-use depiction from certification of an actual past event or elapsed time. The real consumer propagates that wording. Neither unchanged composed-audit outcomes nor synthetic review records show that people review images better, that pixels depict use better, or that retrieval improves.

Do not install this change, alter main, publish it, or start a new improvement cycle to force a passing result. Source remains unchanged. The first proposal that made visible use narrative optional stays rejected and was never used as an accepted arm.

## Frozen experiment and provenance

- Runtime: `776ce8dfa1791c2ec9d13ba21490a7651c2cf2ad`, same local PR5 prerelease in both arms
- Candidate: one JSON description at `/profiles/1/authored_components/components/0/render_gate/description` in the realistic-background profile file
- Source and original semantic review were read before authoring. These are **source-guided English/Korean cases**, not fresh independent holdouts
- Eight original cases, two arms: full selected relation; partial recent-use/support relation; nearby retail-mug scene; ordinary wet/dry reflection control
- Requests, English baseline prompts, original assertions and immutable bounds frozen before generator runs. `DESIGN-FREEZE.json`, the retained original design version, and `run-001/INPUT-FREEZE.json` preserve provenance
- Full independent regular-file copies; no writable symlink or hardlink path back to source. Runtime and test files unchanged
- Actual public full-index builder, generator, composed auditor and unrendered-review auditor were used. The production effective-render-contract function was invoked separately, exactly as used by the review consumer
- Architecture harness files were preserved as schema/guard scaffolding only; no architecture outcomes or fixture expectations were imported

## Observed consumer results

All 16 original public generator/composed-audit rows passed, with the exact frozen baseline prose preserved in both arms. The same is true of four separately frozen, corrected-control supplementary rows. These counts describe structural execution, not semantic quality gains.

Only the English selected case activates the three use-trace hard gates in each arm. Its actual effective render checklist contains the revised description in the after arm. Gate identity, both thumbnail/native scales, composition instructions, literal evidence requirements, recent-use narrative, stable support, reach and clear passage duties are otherwise unchanged.

The natural Korean selected request leaves this English-exact-triggered profile optional. Its final baseline still retains all requested relations and generic immutable anchors. This contradicts the frozen `expected_use_trace_hard=true` value in both arms, but is **not a demonstrated runtime regression or loss of meaning**. The expectation remains preserved and unmet; it limits positive-language hard-gate coverage. No alias was added and no bilingual parity was forced.

Five original optional lists reorder the use-trace candidate: selected Korean, both partial cases and both original nearby cases. Membership and all keyed candidate content except the target description are unchanged. Source `prompt_generator.py:9479–9486` hashes full candidate content for a non-preferential permutation. This is a public presentation-order delta, not evidence of changed retrieval quality or score ranking. It also exceeds the literal frozen expectation of equality outside description and binding metadata. Changed pack IDs bind changed pack content; composed prose and other composed fields remain identical after excluding that ID.

## Full real-cache index reconstruction

Each actual full registry contains 1,622 profiles. All 1,622 genuine compatible 768-dimensional cached vectors and their texts were reused; no vector was fabricated or re-embedded. Both production builders and index checks passed. Entries, exact lookup and BM25F structures are unchanged. Only the after index's registry digest changes. The stale after-cache metadata was detected before rebuilding, rather than bypassed.

Receipts: `run-001/before-index-receipt.json`, `after-index-receipt.json`, cache-preflight receipts, and retained actual CLI argv/stdout/stderr/exit records. Independent verification also covers every actual registry profile and tracked cache entry.

## Actual prose omission and bound-preservation probes

All 32 mutation audits rejected the actual altered prose, in both arms and both languages, with both stale and refreshed mutable evidence. Each keeps original pack/core-retrieval/authorial-core bindings, negative prose and source-contract hash. Every rejection includes an `intent_lock_prompt_evidence` failure for a missing frozen phrase; this is content-level evidence, not credit for a broken metadata hash alone.

- Support: replaces the resting-on-stable-surface clause with a floating-object clause
- Reach: replaces within-reach placement with beyond-reach placement
- Passage: replaces clear adjacent passage with a blocked route
- Use-role probe: replaces the first recent-use clause with an unopened-retail clause

The use-role probe retains a later clause calling the mug recently used. It therefore introduces a conflicting role and deletes a locked literal; it is **not** complete removal of recent-use meaning or proof of a general semantic contradiction detector. The support probe likewise removes the explicit stable-support clause; it does not establish physical feasibility from pixels. English probes additionally exercise active profile literal evidence. Korean probes establish generic immutable requester-bound retention, not a nonexistent Korean hard profile.

There is no after-versus-before rejection improvement. The gate wording does not create a new prose-semantic detector.

## Rendering and synthetic-review boundary

No image was generated, inspected or scored. No provider call or network attempt occurred. Actual production derivation confirms gate-description propagation; the rendered auditor validates supplied records and bindings, not the narrative truth of pixels.

Four truthful unrendered review records remain technically unqualified. Their initial version also had incorrect user-judgment schema fields; all first records and failure outputs remain. Four separately named v2 records correct only the pending/not-applicable judgment fields. They still fail specifically because an image path, image digest and observed gate evidence are absent. No passing gate verdict, image digest, image or user acceptance was fabricated. These expected failures and existing synthetic tests cannot establish actual pixel narrative quality.

## Preserved harness problems and recovery

1. Before any input/arm execution, nearby scenes were found to include an adult despite a false human-applicability flag. Initial cases/design hashes were archived, and applicability was corrected before the final input freeze; request and baseline bytes were unchanged
2. Initial preparation encountered dangling symlinks in unrelated historical documentation. The original tool-output traceback is retained, together with an explicitly reconstructed explanatory summary and tool session/chunk receipt. The compound shell later ran input preparation and returned zero; standalone preparation exit was not separately captured. Recovery used intact skill/test copies and ordinary maintenance dependency files; it did not change source or bypass the broken archive links
3. Original nearby controls still paired a mug subject with the seated adult's event and human subject-category metadata. Their four original rows remain invalid as clean core-semantic negative controls. A separately frozen, post-outcome two-case diagnostic makes the existing adult the subject while retaining all mug facts and request/baseline bytes. Its four passes are supplementary, not replacements or independent holdouts
4. The Korean hard-activation expectation remains unmet, with the source-grounded explanation above
5. Optional-list permutations remain disclosed as literal pair-invariance mismatches
6. A null visual-contract handling defect was corrected before executing the propagation helper using the actual embodiment-only fallback; the original unexecuted helper text is retained. No Korean visual duty was invented
7. Initial unrendered user-judgment schema errors remain retained beside the corrected v2 diagnostic

**Strict original qualification is false.** Corrected supplementary controls and reviews do not turn the original protocol into all-pass evidence.

## Existing regression checks

- run-001/commands/0045-before-existing-focused-tests.stderr.txt: 70 methods, OK (435.735 seconds)
- run-001/commands/0135-after-existing-focused-tests.stderr.txt: 70 methods, OK (430.654 seconds)
- before dictionary validator exit: 0
- after dictionary validator exit: 0

These are focused existing regression checks, not a full repository suite or actual rendered-image evaluation. No existing test or runtime file was edited.

## Completion and retained artifacts

- Machine summary: `run-001/SUMMARY.json`
- Original 16 rows: `run-001/results.json`; original artifacts under `run-001/outputs/`
- All 32 prose mutations: `run-001/mutation-results.json`, plus their exact composed inputs and audit outputs
- Corrected controls: `run-001/nearby-core-diagnostic-v2/` with separate case/input freezes
- Effective review contracts: `run-001/propagation-results.json`; truthful original/v2 reviews beside each selected case
- First-failure/preexecution notes remain in the root and run directory
- Independent review: sibling `use-trace-consumer-review/`

The meaningful result is a bounded clarification-propagation finding plus preservation evidence and disclosed limitations. No numeric semantic improvement, retrieval improvement, rendered-quality improvement, new profile coverage, production adoption or integrated-runtime qualification is claimed. Stop here and leave production unchanged.
