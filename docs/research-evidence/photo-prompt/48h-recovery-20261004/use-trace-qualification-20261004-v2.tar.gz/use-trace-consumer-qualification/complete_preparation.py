"""Complete copy preparation after a preserved dangling-link failure in unrelated archived docs."""
import json,hashlib,shutil
from pathlib import Path
O=Path(__file__).resolve().parent;Q=O/'run-001';R=O.parents[1]/'image-prompt-pr5-source';S='skills/photo-prompt-image-generator'
sha=lambda b:hashlib.sha256(b).hexdigest()
def write(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def tree(p):return {str(f.relative_to(p)):sha(f.read_bytes()) for f in sorted(p.rglob('*')) if f.is_file() and '__pycache__' not in f.parts}
write(Q/'PREPARATION-FIRST-FAILURE.json',{'phase':'prepare','outcome':'failed before after-arm exists or candidate applied','error':'shutil.Error: two archived docs photo-editing-effects-20261001 source-snapshot-v1/v2 semantic shard symlinks have absent targets','source_dangling_links':['docs/research-evidence/photo-prompt/photo-editing-effects-20261001/qualification/source-snapshot-v2/skills/photo-prompt-image-generator/assets/photo_prompt_semantic_index_shards','docs/research-evidence/photo-prompt/photo-editing-effects-20261001/qualification/source-snapshot-v1/assets/photo_prompt_semantic_index_shards'],'input_phase':'Ran after preparation failure because shell invocation lacked set -e; all 8 input CLI stages succeeded and inputs were frozen before any arm runs. Source and before skill pristine.','recovery':'Do not retry unrelated archived docs or dereference their links. Keep first partial copy and source hashes. Complete after skill/tests copy, plus only real ordinary files from extension-maintenance dependency used by existing tests and validator. No source/runtime/test/input edits.'})
assert tree(Q/'before'/S)==load if False else True
assert tree(Q/'before'/S)==json.loads((Q/'source-skill-hashes.json').read_text())
d=Q/'after';(d/'skills').mkdir(parents=True,exist_ok=False);shutil.copytree(R/S,d/S,symlinks=False,ignore=shutil.ignore_patterns('__pycache__','*.pyc'));shutil.copytree(R/'tests',d/'tests',symlinks=False,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
D='docs/research-evidence/photo-prompt/extension-maintenance';shutil.copytree(R/D,d/D,symlinks=False)
assert tree(d/S)==json.loads((Q/'source-skill-hashes.json').read_text())
c=json.loads((O/'scaffolding/narrow-alternative.json').read_text());f=d/c['source_file'];assert sha(f.read_bytes())==c['source_sha256'];j=json.loads(f.read_text());g=j['profiles'][1]['authored_components']['components'][0]['render_gate'];assert g['description']==c['old'];g['description']=c['proposed'];write(f,j)
for arm in ['before','after']:
 assert not any(p.is_symlink() or (p.is_file() and p.stat().st_nlink>1) for p in (Q/arm).rglob('*'))
 assert tree(Q/arm/'tests')==json.loads((Q/'source-test-hashes.json').read_text())
write(Q/'PREPARATION-RECOVERY.json',{'before_skill_pristine':True,'after_one_leaf_applied':True,'all_copy_files_regular_and_not_hardlinked':True,'scripts_and_tests_unchanged':True,'maintenance_dependencies_equal':tree(Q/'before'/D)==tree(Q/'after'/D)==tree(R/D),'images_generated':0,'driver_sha256':sha(Path(__file__).read_bytes())})
print('Preparation recovered; first failure retained; source unchanged')
