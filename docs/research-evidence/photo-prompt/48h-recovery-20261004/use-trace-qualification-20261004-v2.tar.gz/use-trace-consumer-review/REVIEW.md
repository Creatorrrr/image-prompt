# Independent review: use-trace DATA qualification

## Decision

**DEFER consumer-quality qualification and leave production unchanged.** The narrow wording is source-semantically defensible and is faithfully consumed by the local contract pipeline. Completed evidence establishes structural preservation and truthful refusal of nonexistent pixel evidence. It establishes no objective consumer-quality gain. This is source-guided bilingual request testing with an English baseline, not an independent holdout or generated-image study.

Review complete. The producer's final REPORT.md and SUMMARY.json agree with the independent evidence and explicitly leave strict qualification false. Both unchanged focused suites passed 70 methods, and both dictionary validators exited zero. These are structural regression checks, not the full repository suite. Final source/input/copy/index verification remained clean after all tests.

## Independently verified

- Source remains the clean `776ce8dfa1791c2ec9d13ba21490a7651c2cf2ad` checkout. Frozen design, all original inputs, execution tools, source skill files and tests match their recorded hashes. Snapshot files are regular independent files, without links/hardlinks. The baseline snapshot is byte-pristine. The candidate snapshot changes one gate-description JSON leaf and its necessary registry-bound index metadata only.
- Source-provenance cache has 1,622 actual entries, each with the expected 768-dimensional finite nonzero vector. Cache bytes exactly match the tracked source index. Every profile's current positive semantic text matches its cached text in both arms. All 1,622 compatible vectors are reusable, with zero missing vectors. This verifies reuse of genuine committed cache entries; it does not claim a new provider-origin attestation.
- Both recorded public full-registry builds and public index checks exit zero, report 1,622 profiles and 3,837 exact terms, and use unmodified runtime. The before index is byte-identical to cache; the after index changes only `registry_sha256`. All entries, vectors, exact lookup and BM25F content remain identical. Candidate metadata is freshly bound to the actual changed registry. No provider call is needed.
- All 16 original generator/composed audit records pass. Across eight original pairs, request text, final baseline prose, authorial core, immutable semantic assertion contract, and core retrieval are equal. Optional membership is equal. Keying optional rows by ID leaves only the intended description plus derived pack ID as differences; effect-only pairs have no difference.
- All 16 recorded effective-render contracts exactly match independent calls to the unchanged production derivation. English selected inputs retain the same three use-trace gates and the same reach/passage descriptions; only component 1 wording changes. The revised text reaches the actual contract consumed by the rendered-review auditor.
- All 32 actual prose mutation audits were independently rerun and exactly reproduce the recorded failures. Each replacement occurs in `prompt_en` exactly as frozen. Pack ID, authorial-core binding, core retrieval hash, negative prompt and immutable semantic-contract source hash remain fixed within each mutation. Stale and refreshed mutable-evidence variants are both rejected. Every mutation has immutable literal failure checks, not an inferred pixel-semantic verdict.
- All four corrected missing-image reviews were independently rerun. They remain `technical_qualified=false` and `representative_eligible=false`, with failures confined to missing image, image hash and gate evidence. English selected rows require eight gates (three use-trace plus five embodiment); Korean selected rows require five embodiment gates and have no effective use-trace hard contract.
- The four separate corrected nearby-control repeats preserve the exact original requests, baseline prose and mug-setting facts, repair only the subject/event association, pass composed audits and activate no use-trace hard duty. Their input freeze matches. They are explicitly post-outcome diagnostics and do not replace original primary evidence.

## Limitations and defects, retained rather than relabelled

1. **Frozen Korean hard-duty expectation is unmet.** `selected_ko.expected_use_trace_hard=true` fails in both arms. Natural Korean request text does not match this profile's intentionally English-only exact activation phrase; the translated English baseline is not equivalent to a raw-request exact match. This is a frozen expectation mismatch and positive-language hard-gate coverage limit, not evidence of a gate-only runtime regression or lost requested meaning. Korean immutable prose preservation is separately tested.
2. **Five optional lists reorder.** Selected Korean, both partial and both original nearby pairs move the use-trace candidate's public list position. `candidate_pack_shuffle` (`prompt_generator.py:9479`) hashes full candidate JSON, so changing a description changes a non-preferential permutation. Membership and keyed content are otherwise stable; there is no retrieval-score evidence of rank drift. Nevertheless, literal equality outside description and binding metadata was the frozen criterion, so these are collateral public-surface differences and must remain disclosed.
3. **Original nearby subject/event conflation.** Original controls choose the retail mug as subject but the seated adult action as event, with human subject-category metadata. Literal prose survives, but those originals alone are not clean negative core-semantic evidence. The minimal adult-subject repeat is a useful separately frozen diagnostic, not fresh or independently authored coverage.
4. **Use-role mutation is a conflicting-clause probe.** It substitutes an unopened retail role for the first use/support clause while retaining a later “recently used ... clean drinking mug” clause. It tests altered prose and locked literal deletion; it is not complete removal of use-role meaning or an isolated semantic-recency detector experiment.
5. **First unrendered records had an unrelated judgment-schema defect.** Their `status=pending` field did not populate the auditor's `genuinely_moe` and `better_than_baseline` fields. The first four records remain archived. The separate corrected v2 records eliminate this confound while honestly keeping all images and observed gate verdicts absent.
6. **Preparation failure retention is explicitly limited.** The initial full docs copy failed on pre-existing dangling archived links before candidate application. Inputs nevertheless ran because the compound shell lacked `set -e`. Original tool output and a reconstructed explanatory summary are retained, and standalone prepare exit was not separately captured; the compound shell exit was zero. Recovery completes ordinary local copies and only required maintenance docs without editing source, inputs, runtime or tests.
7. **A propagation helper null-contract defect was caught before execution.** Its first version assumed every selected request had a visual contract. The archived correction uses the production auditor's existing embodiment fallback for Korean input; it neither invents hard use-trace gates nor claims a failed execution occurred.

## Semantic judgment

The rejected first proposal's “may suggest use” and support-only failure boundary could let support geometry pass while abandoning the selected use narrative. Keeping that proposal rejected is justified.

The narrow alternative retains a required selected depiction, visible owners and fail-closed evidence while excluding proof of hidden actual use or elapsed time. It prescribes no residue, steam, stain, extra person, action or temporal cue. Definition, activation, evidence, composition, owner scope, gate IDs/scales, reach, passage and ordinary candidate remain unchanged. This is a defensible claim-limit clarification. The local deterministic experiment cannot establish how a human or image reviewer would interpret or apply it more accurately.

The composed prose is deliberately fixed and no optional concepts are selected. That isolates contract propagation but provides no generative or human-review treatment effect. Structural passes and symmetric literal rejections must not become numeric semantic improvement claims.

## Artifacts

- `current-verification.json`: final post-test independent source, frozen-input, copy, genuine-cache and full-index checks, including recorded production build commands
- `output-verification-current.json`: eight paired invariant checks, sixteen effective contracts, thirty-two independently rerun mutation audits and first missing-image reruns
- `output-verification-before-propagation.json`: retained intermediate receipt
- `supplement-verification.json`: corrected missing-image reruns and separately frozen nearby controls
- `verify_available.py`, `verify_outputs.py`, `verify_supplements.py`: read-only local verification scripts, writing only in this review directory

No source/runtime/test edits, network/provider calls, uploads, publication, generated-image judgments or consumer-quality certification were performed by this review.
