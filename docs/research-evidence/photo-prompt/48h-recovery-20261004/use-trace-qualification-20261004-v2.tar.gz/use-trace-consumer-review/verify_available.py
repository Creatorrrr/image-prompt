"""Independent read-only evidence verification; writes only to this review directory."""
import json, pathlib, hashlib, math, subprocess, sys, datetime
O=pathlib.Path(__file__).resolve().parent
Q=O.parent/'use-trace-consumer-qualification'
R=O.parents[1]/'image-prompt-pr5-source'
RUN=Q/'run-001'
S=pathlib.Path('skills/photo-prompt-image-generator')
load=lambda p:json.loads(pathlib.Path(p).read_text())
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()

def tree(p):
 return {str(f.relative_to(p)):sha(f) for f in sorted(p.rglob('*')) if f.is_file() and '__pycache__' not in f.parts}
def diff(a,b,path=''):
 if type(a)!=type(b):return [path]
 if isinstance(a,dict):
  out=[]
  for k in sorted(a.keys()|b.keys()):out += [path+'/'+k] if k not in a or k not in b else diff(a[k],b[k],path+'/'+k)
  return out
 if isinstance(a,list):
  if len(a)!=len(b):return [path+'/$length']
  return sum((diff(x,y,path+'/'+str(i)) for i,(x,y) in enumerate(zip(a,b))),[])
 return [] if a==b else [path]

out={'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'source_status':subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True),'claim_limit':'Independent current-file verification, not rerun of full pipeline or pixel/provider study.'}
assert out['source_commit']=='776ce8dfa1791c2ec9d13ba21490a7651c2cf2ad' and out['source_status']==''
out['design_hash_mismatches']=[f for f,h in load(Q/'DESIGN-FREEZE.json')['files_sha256'].items() if sha(Q/f)!=h]
out['input_hash_mismatches']=[f for f,h in load(RUN/'INPUT-FREEZE.json')['files_sha256'].items() if sha(RUN/'inputs'/f)!=h]
out['execution_tool_hash_mismatches']=[f for f,h in load(RUN/'execution-tool-hashes.json').items() if sha(Q/f)!=h]
source=tree(R/S)
out['source_skill_matches_preparation_manifest']=source==load(RUN/'source-skill-hashes.json')
out['source_tests_match_preparation_manifest']=tree(R/'tests')==load(RUN/'source-test-hashes.json')
out['arms']={}
for arm in ['before','after']:
 root=RUN/arm; a=tree(root/S)
 out['arms'][arm]={'changed_skill_files':[f for f in sorted(set(source)|set(a)) if source.get(f)!=a.get(f)],'tests_equal_source':tree(root/'tests')==tree(R/'tests'),'nonregular_or_linked_files':[str(f.relative_to(root)) for f in root.rglob('*') if f.is_symlink() or (f.is_file() and f.stat().st_nlink>1)]}
proposal=load(Q/'scaffolding/narrow-alternative.json')
before=load(RUN/'before'/proposal['source_file']); after=load(RUN/'after'/proposal['source_file'])
out['candidate_json_diff_paths']=diff(before,after)
assert out['candidate_json_diff_paths']==[proposal['json_pointer']]
assert before['profiles'][1]['authored_components']['components'][0]['render_gate']['description']==proposal['old']
assert after['profiles'][1]['authored_components']['components'][0]['render_gate']['description']==proposal['proposed']
cache=load(RUN/'reference-cache.json')
out['cache_equal_tracked_source_bytes']=sha(RUN/'reference-cache.json')==sha(R/S/'assets/photo_prompt_visual_profile_index.json')
out['cache_sha256']=sha(RUN/'reference-cache.json')
out['index_common']={'entries':len(cache['entries']),'exact_terms':len(cache['exact_lookup']),'provider':cache['provider'],'embedding_model':cache['embedding_model'],'dimensions':cache['embedding_dimensions'],'all_vectors_finite_dimensioned_nonzero':all(len(e['vector'])==cache['embedding_dimensions'] and all(math.isfinite(v) for v in e['vector']) and any(e['vector']) for e in cache['entries'].values())}
for arm in ['before','after']:
 ix=load(RUN/arm/S/'assets/photo_prompt_visual_profile_index.json')
 out['arms'][arm]['index_difference_paths_from_source_cache']=diff(cache,ix)
 out['arms'][arm]['all_1622_entries_equal_cache']=ix['entries']==cache['entries'] and len(ix['entries'])==1622
 out['arms'][arm]['index_sha256']=sha(RUN/arm/S/'assets/photo_prompt_visual_profile_index.json')
# No runtime or credential/network operations may occur in this import/derivation.
sys.dont_write_bytecode=True
blocked=[]
def guard(event,args):
 if event.startswith('socket.') or event=='subprocess.Popen':
  blocked.append(event);raise RuntimeError('Review forbids network and child processes during runtime imports')
 if event=='open' and isinstance(args[0],(str,bytes)) and pathlib.Path(args[0]).name=='.env':
  blocked.append('credential_open');raise RuntimeError('Review forbids credential reads')
sys.addaudithook(guard)
sys.path.insert(0,str(R/S/'scripts'))
import prompt_generator as g
import build_visual_profile_index as builder
for arm in ['before','after']:
 reg=g.load_visual_obligation_registry(RUN/arm/S/'assets/photo_prompt_visual_obligations.json')
 vectors=builder.reusable_vectors([RUN/'reference-cache.json'],reg,provider=g.SEMANTIC_PROVIDER,model=g.SEMANTIC_MODEL_ID,dimensions=g.DEFAULT_SEMANTIC_DIMENSIONS)
 ids={p['id'] for p in reg['profiles']}
 ix=load(RUN/arm/S/'assets/photo_prompt_visual_profile_index.json')
 g.validate_visual_profile_index_metadata(ix,reg)
 out['arms'][arm]['registry_profiles']=len(ids)
 out['arms'][arm]['compatible_cached_vectors']=len(vectors)
 out['arms'][arm]['missing_cached_vectors']=sorted(ids-set(vectors))
 out['arms'][arm]['every_registry_semantic_text_equals_cached_text']=all(cache['entries'][p['id']]['text']==g.visual_profile_semantic_text(p) for p in reg['profiles'])
 out['arms'][arm]['rebuilt_index_valid_for_actual_registry']=True
 out['arms'][arm]['registry_sha256']=g.visual_profile_registry_sha256(reg)
 assert len(ids)==len(vectors)==1622 and not ids-set(vectors)
out['review_blocked_operations']=blocked
out['commands']={}
for f in sorted((RUN/'commands').glob('*.command.json')):
 stem=str(f)[:-len('.command.json')]; exitfile=pathlib.Path(stem+'.exit.json')
 if any(x in f.name for x in ['actual-full-registry-build','actual-index-check']):
  out['commands'][f.name]={'command':load(f),'exit':load(exitfile) if exitfile.exists() else None,'stdout':pathlib.Path(stem+'.stdout.txt').read_text()}
rows=load(RUN/'results.json') if (RUN/'results.json').exists() else []
out['completed_original_arms']=[{k:v for k,v in row.items() if k in ['case','arm','audit_status','hard_ids','failures']} for row in rows]
out['producer_blocked_operations_log_exists']=(RUN/'blocked-operations.jsonl').exists()
(O/'current-verification.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k not in ['commands','completed_original_arms']},ensure_ascii=False,indent=2))
