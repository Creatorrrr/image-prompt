"""Independent consumer artifact inspection. No edits outside review directory."""
import json, pathlib, hashlib, copy, datetime, sys, collections
sys.dont_write_bytecode=True
O=pathlib.Path(__file__).resolve().parent; Q=O.parent/'use-trace-consumer-qualification'; RUN=Q/'run-001'; R=O.parents[1]/'image-prompt-pr5-source';S=pathlib.Path('skills/photo-prompt-image-generator')
load=lambda p:json.loads(pathlib.Path(p).read_text());sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def guard(event,args):
 if event.startswith('socket.') or event=='subprocess.Popen':raise RuntimeError('Forbidden network or subprocess during independent artifact review')
 if event=='open' and isinstance(args[0],(str,bytes)) and pathlib.Path(args[0]).name=='.env':raise RuntimeError('Credential read forbidden')
sys.addaudithook(guard);sys.path.insert(0,str(R/S/'scripts'));import audit_composed_prompt as audit;import audit_moe_render_review as render

def diff(a,b,p=''):
 if type(a)!=type(b):return [p]
 if isinstance(a,dict):return sum(([p+'/'+k] if k not in a or k not in b else diff(a[k],b[k],p+'/'+k) for k in sorted(a.keys()|b.keys())),[])
 if isinstance(a,list):
  if len(a)!=len(b):return [p+'/$length']
  return sum((diff(x,y,p+'/'+str(i)) for i,(x,y) in enumerate(zip(a,b))),[])
 return [] if a==b else [p]
def keyed_pack(p):
 p=copy.deepcopy(p)
 c=(p.get('visual_concept_candidates') or {}).get('candidates')
 if c is not None:p['visual_concept_candidates']['candidates']={x['id']:x for x in c}
 return p
out={'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'original_pairs':[],'propagation':[],'mutations':[],'truthful_unrendered_reviews':[],'claim_limit':'No pixel or semantic-quality observations. Runtime import/derivation is local, unchanged and offline.'}
for c in load(Q/'cases.json')['cases']:
 bases={arm:RUN/'outputs'/arm/c['id'] for arm in ['before','after']}
 if not all((p/'audit.json').exists() for p in bases.values()):continue
 packs={a:load(p/'candidate-pack.json')[0] for a,p in bases.items()}; comps={a:load(p/'composed.json') for a,p in bases.items()}
 before,after=packs['before'],packs['after']; bc,ac=comps['before'],comps['after']
 optional=lambda p:[x['id'] for x in (p.get('visual_concept_candidates')or{}).get('candidates',[])]
 row={'case':c['id'],'source_exposed':c['source_exposed'],'baseline_exact_and_equal_both_arms':bc['prompt_en']==ac['prompt_en']==c['baseline_prompt_en'],'request_frozen_same_both_arms':before['authorial_core']['source_request']==after['authorial_core']['source_request']==c['request'],'authorial_core_equal_both_arms':before['authorial_core']==after['authorial_core'],'semantic_assertion_contract_equal_both_arms':before.get('semantic_assertion_obligations')==after.get('semantic_assertion_obligations'),'core_retrieval_equal_both_arms':before['core_retrieval']==after['core_retrieval'],'ordered_optional_ids_equal':optional(before)==optional(after),'optional_membership_equal':set(optional(before))==set(optional(after)),'keyed_candidate_pack_difference_paths':diff(keyed_pack(before),keyed_pack(after)),'composed_difference_paths':diff(bc,ac),'recorded_audits':{a:load(p/'audit.json')['status'] for a,p in bases.items()}}
 out['original_pairs'].append(row)
 for arm,p in bases.items():
  effective,failures=audit.derive_effective_visual_obligation_contract(packs[arm],comps[arm]);f=p/'effective-render-contract.json'
  row={'case':c['id'],'arm':arm,'effective_use_trace_gates':[(g['id'],g['description']) for ob in (effective or {}).get('obligations',[]) if ob['id']=='rb_use_trace_affordance' for g in ob['render_gates']],'required_hard_gate_ids':(effective or {}).get('required_hard_gates',[]),'selection_failures':failures,'recorded_helper_exists':f.exists()}
  if f.exists():row['recorded_helper_matches_independent_derivation']=load(f)['effective_contract']==effective and load(f)['selection_failures']==failures
  out['propagation'].append(row)
  f=p/'truthful-unrendered-review.json';recorded=p/'unrendered-review-audit.json'
  if f.exists() and recorded.exists():
   review=load(f);result=render.audit_moe_render_review(packs[arm],review,composed=comps[arm],review_path=f)
   out['truthful_unrendered_reviews'].append({'case':c['id'],'arm':arm,'recorded_audit_matches_independent_rerun':load(recorded)==result,'review_has_no_image_or_hash':not review.get('result_image') and not review.get('result_sha256'),'review_has_no_observed_hard_gates':not review.get('hard_gates'),'independent_result':result})
if '--propagation-only' in sys.argv:
 prior=load(O/'output-verification-current.json');out['mutations']=prior['mutations'];out['mutation_audits_observed_utc']=prior.get('mutation_audits_observed_utc',prior['observed_utc'])
for de in ([] if '--propagation-only' in sys.argv else load(Q/'mutations.json')['cases']):
 for arm in ['before','after']:
  original=load(RUN/'outputs'/arm/de['source_case']/'composed.json');pack=load(RUN/'outputs'/arm/de['source_case']/'candidate-pack.json')[0]
  for variant in ['stale_evidence','refreshed_evidence']:
   p=RUN/'mutations'/arm/de['id']/variant
   if not (p/'audit.json').exists():continue
   changed=load(p/'composed.json');recorded=load(p/'audit.json')
   assert changed['prompt_en']==original['prompt_en'].replace(de['old'],de['new']) and changed['prompt_en']!=original['prompt_en']
   immutable=['authorial_core_binding','core_retrieval_sha256','negative_en','pack_id']
   assert all(changed[k]==original[k] for k in immutable)
   assert changed['semantic_assertion_evidence']['source_contract_sha256']==original['semantic_assertion_evidence']['source_contract_sha256']
   result=audit.audit_composed_prompt(pack,changed)
   out['mutations'].append({'id':de['id'],'arm':arm,'variant':variant,'status':recorded['status'],'actual_prose_changed_exactly_as_frozen':True,'old_literal_absent':de['old'] not in changed['prompt_en'],'new_literal_present':de['new'] in changed['prompt_en'],'immutable_bindings_equal_source_composed':True,'recorded_audit_matches_independent_rerun':recorded==result,'failure_checks':[f['check'] for f in result['failures']],'other_recent_use_clause_retained':'the recently used object is a clean drinking mug beside a folded cloth on the table' in changed['prompt_en'] if de['id'].startswith('use_role') else None})
out['counts']={'completed_original_pairs':len(out['original_pairs']),'completed_mutation_audits':len(out['mutations']),'completed_unrendered_audits':len(out['truthful_unrendered_reviews']),'helper_propagations_present':sum(x['recorded_helper_exists'] for x in out['propagation']),'optional_order_changed_pairs':sum(not x['ordered_optional_ids_equal'] for x in out['original_pairs'])}
(O/'output-verification-current.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(out['counts'],ensure_ascii=False,indent=2));print('keyed differences:');print(json.dumps({r['case']:r['keyed_candidate_pack_difference_paths'] for r in out['original_pairs']},ensure_ascii=False,indent=2))
