import json,pathlib,sys,hashlib,datetime
O=pathlib.Path(__file__).resolve().parent;Q=O.parent/'use-trace-consumer-qualification';RUN=Q/'run-001';R=O.parents[1]/'image-prompt-pr5-source';S=pathlib.Path('skills/photo-prompt-image-generator');load=lambda p:json.loads(pathlib.Path(p).read_text());sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
sys.dont_write_bytecode=True
sys.addaudithook(lambda event,args: (_ for _ in ()).throw(RuntimeError('offline read-only review')) if event.startswith('socket.') or event=='subprocess.Popen' else None)
sys.path.insert(0,str(R/S/'scripts'));import audit_moe_render_review as render
out={'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'corrected_unrendered':[],'corrected_nearby':[]}
for case in ['selected_en','selected_ko']:
 for arm in ['before','after']:
  p=RUN/'outputs'/arm/case;f=p/'truthful-unrendered-review-v2.json';ap=p/'unrendered-review-v2-audit.json'
  if not ap.exists():
   matches=list(p.glob('*v2*audit*.json'))+list(p.glob('*audit*v2*.json'));assert len(matches)==1,matches;ap=matches[0]
  review=load(f);res=render.audit_moe_render_review(load(p/'candidate-pack.json')[0],review,composed=load(p/'composed.json'),review_path=f)
  assert res==load(ap)
  assert not res['technical_qualified'] and not res['representative_eligible']
  assert {f['check'] for f in res['schema_failures']}=={'result_image','result_sha256','hard_gates'}
  assert not review.get('result_image') and not review.get('result_sha256') and not review.get('hard_gates')
  out['corrected_unrendered'].append({'case':case,'arm':arm,'independent_rerun_matches':True,'technical_qualified':False,'representative_eligible':False,'schema_failure_checks':[f['check'] for f in res['schema_failures']],'missing_gate_count':len(res['failed_hard_gates']),'review_sha256':sha(f),'audit_sha256':sha(ap)})
D=RUN/'nearby-core-diagnostic-v2'; originals={c['id']:c for c in load(Q/'cases.json')['cases']};casefreeze=load(D/'CASES-FREEZE.json')
for c in casefreeze['cases']:
 src=originals[c['source_case_id']];assert c['request']==src['request'] and c['baseline_prompt_en']==src['baseline_prompt_en'] and c['request_facts']==src['request_facts'];assert c['subject']=='the adult user' and c['event']==src['event'] and c['human']==src['human']
 for arm in ['before','after']:
  p=D/'outputs'/arm/c['id'];pack=load(p/'candidate-pack.json')[0];comp=load(p/'composed.json');res=load(p/'audit.json');assert comp['prompt_en']==src['baseline_prompt_en'];assert pack['authorial_core']['subject']=='the adult user';assert res['status']=='pass';assert not (pack.get('visual_obligations') or {}).get('obligations')
  out['corrected_nearby'].append({'case':c['id'],'arm':arm,'original_request_and_baseline_bytes_preserved':True,'minimal_subject_event_repair_confirmed':True,'recorded_composed_audit':'pass','use_trace_hard_activated':False,'post_outcome_diagnostic':True})
freeze=load(D/'INPUT-FREEZE.json');out['supplement_input_freeze_hash_mismatches']=[f for f,h in freeze['files_sha256'].items() if sha(D/'inputs'/f)!=h]
(O/'supplement-verification.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps(out,ensure_ascii=False,indent=2))
