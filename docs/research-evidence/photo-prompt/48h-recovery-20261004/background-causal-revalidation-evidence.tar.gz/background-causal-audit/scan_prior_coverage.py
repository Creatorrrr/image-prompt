import hashlib,json,tarfile,gzip,subprocess
from pathlib import Path
ROOT=Path('/workspace/scratch/ce8f20680f5a/image-prompt')
OUT=Path('/workspace/scratch/ce8f20680f5a/data-progress-48h-recovery-20261004/background-causal-audit')
ids=['rb_water_path_stain','rb_use_trace_affordance','rb_vegetation_site_relation','rb_coating_substrate_boundary']
needles=[x.encode() for x in ids]
rows=[]; containers=[]; selected=[]; scan_count=0

def examine(data,path,source_sha):
 global scan_count
 scan_count+=1
 hits=[ids[i] for i,n in enumerate(needles) if n in data]
 if not hits:return
 text=data.decode('utf-8',errors='replace')
 lines=text.splitlines(); contexts=[]
 for n,line in enumerate(lines):
  terms=[x for x in ids if x in line]
  if terms:contexts.append({'line':n+1,'ids':terms,'text':line[:1200]})
 row={'path':path,'sha256':hashlib.sha256(data).hexdigest(),'source_sha256':source_sha,'bytes':len(data),'ids':hits,'matching_line_count':len(contexts),'first_matches':contexts[:12]}
 rows.append(row)
 # Preserve human-authored reports in full; dump inventories kept only as matching-line excerpts.
 name=path.split('!')[-1].lower()
 if name.endswith(('.md','.txt')) or any(s in name for s in ['audit-result','review-result','findings','verdict']):
  selected.append({'path':path,'sha256':row['sha256'],'text':text})

paths=subprocess.check_output(['git','ls-files','docs/research-evidence','docs/analysis','artifacts'],cwd=ROOT,text=True).splitlines()
for rel in paths:
 p=ROOT/rel
 if not p.is_file():continue
 if p.suffix in ['.png','.jpg','.jpeg','.pdf','.webp','.mp4']:continue
 data=p.read_bytes(); sha=hashlib.sha256(data).hexdigest()
 if rel.endswith('.tar.gz'):
  members=0
  try:
   with tarfile.open(p,'r:gz') as tf:
    for m in tf:
     if not m.isfile():continue
     members+=1
     if Path(m.name).suffix.lower() in ['.png','.jpg','.jpeg','.pdf','.webp','.mp4']:continue
     f=tf.extractfile(m)
     if f:examine(f.read(),rel+'!'+m.name,sha)
   containers.append({'path':rel,'sha256':sha,'bytes':len(data),'member_count':members,'status':'read'})
  except Exception as e:containers.append({'path':rel,'sha256':sha,'status':'error','error':str(e)})
 elif rel.endswith('.gz'):
  try:examine(gzip.decompress(data),rel+'!decompressed',sha);containers.append({'path':rel,'sha256':sha,'bytes':len(data),'status':'read'})
  except Exception as e:containers.append({'path':rel,'sha256':sha,'status':'error','error':str(e)})
 else:examine(data,rel,sha)
(OUT/'prior-coverage-exact-id-hits.json').write_text(json.dumps({'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'search_scope':'git-tracked docs/research-evidence, docs/analysis, artifacts; regular textual files plus every textual gzip/tar member; no deleted or absent history','needles':ids,'objects_scanned':scan_count,'matching_objects':len(rows),'compressed_archives':containers,'matches':rows},ensure_ascii=False,indent=2))
(OUT/'prior-coverage-human-reports.json').write_text(json.dumps(selected,ensure_ascii=False,indent=2))
print(json.dumps({'scanned':scan_count,'matching_objects':len(rows),'archives':len(containers),'archive_errors':[x for x in containers if x['status']=='error'],'human_reports':[x['path'] for x in selected]},indent=2))
