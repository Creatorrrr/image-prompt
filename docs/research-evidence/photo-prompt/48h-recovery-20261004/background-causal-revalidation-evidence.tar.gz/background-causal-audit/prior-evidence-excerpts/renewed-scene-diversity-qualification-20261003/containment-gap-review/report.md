# Temporary containment DATA gap audit

## Decision

**KEEP. Do not add a candidate row from this audit. No frozen proposal is supplied.**

Family A offers useful independently authored scene mechanisms, but this audit did not establish a sufficiently distinct, low-overlap photographic DATA concept. The specific containment mechanisms are less directly represented than generic work/contact relations; that vocabulary difference is not, by itself, a reason to insert a scene recipe or call a scene-state change a framing refinement.

Once the author has established the actor, temporary barrier/catch, support/contact, material path, and affected boundary, existing candidates can jointly preserve their visibility. A new generic “containment relationship in one frame” row would substantially restate that coverage. A more specific intervention would change the action, prop/contact configuration and material distribution. It would need honest multi-dimension ownership and an independently justified open-scope use case, rather than a composition-only label.

This is a keep decision for the current DATA audit, not a claim that every possible containment operation is already named or that the existing retrieval reliably surfaces the best available rows.

## Scope and isolation

- Repository: `REPOSITORY_ROOT`
- Development input: `daylong-progress-20261002/scene-diversity-research/development-families.md`, Family A only for analysis and diagnostics
- Read the engineering skill, repository photo skill/maintenance instructions, current runtime source and merged runtime-reachable candidate data
- No repository `AGENTS.md` or files inside the repository `.agents` directory were present
- No original research containing holdouts, qualification input/output, separate proposal, competing result, or tests/fixtures were opened
- No source insertion, runtime modification, repository writes, paid/network call, external-agent communication or rendered-image evaluation occurred
- Audit output is outside the repository, in this report's directory
- `reachability-diagnostic.json` records source hashes, the repository HEAD, and all diagnostic results; `audit_reachability.py` reproduces the offline check

The merged runtime source contains 112 slots and 9,664 rows. `load_json()` reads the declared extension list; source files outside that runtime list do not establish reachable DATA coverage. The runtime no longer uses the removed preset/sampler scene recipes: `retrieve_core_slots()` retrieves from frozen fields, applies eligibility, ranks within each slot and observes bounded inventory limits.

## Existing combinations, evaluated as relationships

### A1: raised sagging tarp, supported elsewhere, stream entering the bucket

Existing combination:

1. `composition.crop_boundary_anchor_integrity` keeps the broom-to-tarp contact, connected sheet edge, stream continuation and bucket opening inside the crop
2. `composition.peak_action_event_phase` can organize the already-authored raising/draining moment as cause, direction and immediate consequence
3. `focus.subject_anchor_focus_plane_priority` can preserve joint readability of the operative contact and receiving destination
4. `composition.pr_environmental_portrait_subject_place_candidate` keeps enough of the stall/crates to explain the routine task

Relevant but conditional action/material coverage:

- `action.tool_contact_active_process_visible_result` and `action.using_tool_at_visible_change_boundary` express actual tool contact and a connected result
- `contact_point.load_bearing_contact_deformation` expresses the supporting contact and its local response
- `action.tactile_gather_contact_action` covers support-bound sagging and converging wrinkles, but gathering is not automatically equivalent to lifting one tarp corner with a broom
- `composition.tactile_contact_front_underside_composition` is usable only if the acting contact, deformation boundary, lifted edge and exposed underside really exist. A1 does not license inventing an exposed underside merely to use it

What these combinations do not author: a wet tarp, its tie points, a broom acting as a prop, a drain trajectory, or a correctly placed bucket. Those are the independent scene's substantive event and topology. A tarp noun or a bucket noun would not supply them either.

### A2: split sack pouring potting mix into a floor-contacting dustpan

Existing combination:

1. `crop_boundary_anchor_integrity` preserves the sack outlet, falling material, pan mouth and pan-floor contact rather than allowing a tight hand portrait to remove the destination
2. `peak_action_event_phase` relates the already-authored sack tilt, falling mix and accumulating result
3. `subject_anchor_focus_plane_priority` keeps the outlet/receiving edge/contact judgeable together
4. `pr_environmental_portrait_subject_place_candidate` can keep the trolley and intact sacks subordinate but task-explanatory

`working_same_target_from_two_sides` is a nearby cooperative relation, not a required replacement. The development scene specifies two workers but not that they stand on opposite sides. Its topology cannot be added as a supposedly neutral refinement. Likewise, generic tool-contact rows do not independently guarantee that one worker steadies the pan while the other controls the sack.

What is specific here is transfer into an improvised shallow catcher with floor support. Naming a dustpan or borrowing the unrelated food-portioning transfer family would not establish the split-sack/material-source/receiving-pan relationship. Once that relationship is authored, the crop/focus/cause-result combination already supplies the photographic preservation duty.

### A3: rolled towel wedged along a door bottom, localized wet front retained on one side

Existing combination:

1. `crop_boundary_anchor_integrity` keeps the pressing hand, towel-door/floor seam and the visible wet front connected in frame
2. `subject_anchor_focus_plane_priority` makes the decisive seam and wet/dry boundary readable
3. `pr_environmental_portrait_subject_place_candidate` retains the side entrance and ordinary maintenance context
4. `load_bearing_contact_deformation` is relevant to an already-authored compressed towel/contact, but is an action/contact/material interpretation, not permission to create a new barrier

`peak_action_event_phase` is not automatically useful for a stable wedged towel. The frame need not acquire a falling stream, motion blur, dramatic transition or flood. `rb_water_path_stain_candidate` is also not interchangeable: it describes an existing runoff stain descending from an outlet, not an active contained wet front.

The meaningful A3 distinction is a locally pressure-seated temporary barrier at the same contact line where the liquid stops. That is real action/environment authorship. A composition-only entry must not manufacture the hand pressure, compressed roll, remaining wet patch or dry far side. If those are already part of the core, the crop and focus primitives can preserve them without a new scene-specific instruction.

## Neighbors that must not be borrowed or widened

- `pov_trace_mitigate_defect_action` and `pov_leak_damp_draft_mitigation_prop` already describe temporary catches/absorbent cloth/seals, but require `occupied_housing_habitability_mitigation_relation`. Routine market, nursery and pool work does not establish that premise. Treating those scenes as equivalent paraphrases would change owner/context rather than extend a synonym
- `des_overflow_causal_line_composition` requires `excess_accumulation_overflow`. It depicts continued adding beyond full capacity and its spill/displacement consequence, which is not the same relationship as preventing or catching an incidental spill
- `character_creepy_cute_scene_action` plus its tarp prop requires a separate atomic creature/surveyor scene. The shared tarp word does not authorize importing the nonhuman helper or its rain-shielding event
- `tactile_gather_contact_action` has useful deformation language but an existing sheet/manipulation premise and effects across action, material and pose. It is not a generic method for inventing a tarp intervention in an otherwise ordinary scene

## Runtime reachability findings

The offline probe projects the exact A1–A3 development text into a maintenance-only core-shaped carrier. It resolves deterministic zero-added-treatment controls and calls the current `frozen_core_context()`, `core_slot_entry_eligible()` and `retrieve_core_slots()` functions. It does **not** claim to create a valid public authorial core or a complete candidate pack. Placeholder hashes are visibly marked `maintenance-diagnostic-only`; there is no attempt to pass public input validation.

For all three projections:

- The inferred subject category is human; no specialized domain is inferred
- Generic crop, cause/result framing, environmental-task framing, anchor focus, tool/contact and cooperative rows are source-eligible
- The housing-mitigation, excess-accumulation and creature/tarp neighbors are ineligible; their source context requirements fail
- None of the nominated generic coverage rows appears in the bounded returned inventory from the unchanged concrete development text
- The returned `composition` slot contains only `rb_foreground_occlusion_candidate` in these specific diagnostics. Several action/prop hits are semantically adjacent or unrelated, so retrieval presence must not be treated as correctness

This is a real limitation worth keeping visible: **eligible corpus coverage is not reliable discoverability**. It does not prove that another row will help; the probe uses terse development descriptions, no authored visual priorities, no public-core validation, and no full final-composition path. It is not a qualification or image-quality result. The lack of a useful hit must not be repaired by treating the development scenes themselves as new fixed presets.

A narrow follow-on, if separately wanted, would test existing equivalent contact/crop/focus language against independently authored frozen photographic cores. That is a retrieval/authoring distinction to establish before adding DATA, not authorization from this audit to change runtime or tune against these development cases.

## Scope and condition honesty

`affected_dimensions` denotes actual changes, not the name of the slot carrying an idea. For a proposed new pressure-seated containment action, the author would need to account for at least:

- action: the intervention itself
- pose and relationship: actor-to-barrier/support contact configuration
- material: local deformation or absorption when newly introduced
- setting/event as applicable: the position and extent of the liquid/material, the retained or redirected path, and the resulting local consequence

A framed view of already-authored relationships can instead be composition/camera/framing refinement. These categories must not be collapsed merely because they describe the same visible subject. Whole-dimension locks and property locks remain independent of lexical eligibility.

The runtime's standard slot public semantic projection preserves `concept_units`, `relations`, `affected_dimensions` and any `affected_properties`. A `contextual_usage.application_conditions` note is not an executable predicate. In this ordinary slot path it is also not copied by `semantic_source()` as such; the special contextual-appeal path has separate preserved context metadata. Therefore source prose alone cannot be advertised as an enforced or automatically preserved public guard. No new executable condition was inferred or fabricated from that prose here.

Because there is no adopted proposal, there are no new dimensions/properties, guard tags, contextual conditions or semantic-index inputs to freeze. `decision.json` explicitly records the absence of a proposed row.

## Source pointers

Paths below are relative to `image-prompt/`:

- `skills/photo-prompt-image-generator/scripts/prompt_generator.py:1284`: merged runtime loader
- `skills/photo-prompt-image-generator/scripts/prompt_generator.py:11250`: slot-focused frozen-field projection
- `skills/photo-prompt-image-generator/scripts/prompt_generator.py:11274`: frozen context, with no optional candidate allowed to establish a prerequisite
- `skills/photo-prompt-image-generator/scripts/prompt_generator.py:11311`: current source eligibility
- `skills/photo-prompt-image-generator/scripts/prompt_generator.py:11356`: bounded core retrieval
- `skills/photo-prompt-image-generator/scripts/photo_candidate_semantics.py:219`: ordinary public semantic source fields
- `skills/photo-prompt-image-generator/assets/photo_prompt_reactorprompt_visual_relations_extension.json:7,109,121,146`: crop, load contact, active tool process and anchor focus
- `skills/photo-prompt-image-generator/assets/photo_prompt_tags.json:66502`: cause/trajectory/consequence framing
- `skills/photo-prompt-image-generator/assets/photo_prompt_tactile_reality_extension.json:129,228`: supported sheet gathering and contact/deformation/underside framing
- `skills/photo-prompt-image-generator/assets/photo_prompt_research_extension.json:2883`: opposite-side shared-target work
- `skills/photo-prompt-image-generator/assets/photo_prompt_photorealism_elements_extension.json:6`: environmental task framing
- `skills/photo-prompt-image-generator/assets/photo_prompt_poverty_extension.json:438,967`: scoped temporary housing mitigation
- `skills/photo-prompt-image-generator/assets/photo_prompt_desire_extension.json:1275`: continued-accumulation overflow relation
- `skills/photo-prompt-image-generator/assets/photo_prompt_character_moe_extension.json:1078`: scoped creature/tarp scene
- `skills/photo-prompt-image-generator/assets/photo_prompt_realistic_background_extension.json:411`: runoff stain, not active containment

## Completion evidence

No test suite, paid call or image generation was run because this is a read-only corpus/eligibility audit. The offline diagnostic completed successfully. Repository status was clean before and after inspection. The source hashes in the diagnostic bind the exact inspected implementation and DATA; future repository changes would require rechecking the corresponding claims.
