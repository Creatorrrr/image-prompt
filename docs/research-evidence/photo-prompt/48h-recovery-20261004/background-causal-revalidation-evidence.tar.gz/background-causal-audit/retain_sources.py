import hashlib,json,subprocess,tarfile
from pathlib import Path
R=Path('/workspace/scratch/ce8f20680f5a/image-prompt');O=Path('/workspace/scratch/ce8f20680f5a/data-progress-48h-recovery-20261004/background-causal-audit')
ids=['rb_water_path_stain','rb_use_trace_affordance','rb_vegetation_site_relation','rb_coating_substrate_boundary']
rels=['skills/photo-prompt-image-generator/references/maintenance.md','skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations_realistic_background.json','skills/photo-prompt-image-generator/assets/photo_prompt_realistic_background_extension.json','skills/photo-prompt-image-generator/scripts/visual_profile_contracts.py','skills/photo-prompt-image-generator/scripts/photo_visual_retrieval.py','skills/photo-prompt-image-generator/scripts/photo_candidate_semantics.py','skills/photo-prompt-image-generator/scripts/prompt_generator.py','docs/research-evidence/photo-prompt/realistic-background-20260912/visual-proposals.json','docs/research-evidence/photo-prompt/realistic-background-20260912/evaluation-cases.jsonl','docs/research-evidence/photo-prompt/realistic-background-20260912/report.md','docs/research-evidence/photo-prompt/realistic-background-20260912/sources.json','docs/research-evidence/photo-prompt/realistic-background-implementation-20260912/report.md','docs/research-evidence/photo-prompt/realistic-background-implementation-20260912/source-coverage.json','docs/research-evidence/photo-prompt/48h-initial-data-qualification-20261003/README.md','docs/research-evidence/photo-prompt/everyday-scene-20260923/report.md']
manifest=[]
for rel in rels:
 d=(R/rel).read_bytes();dest=O/'source-snapshots'/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(d)
 manifest.append({'repo_path':rel,'sha256':hashlib.sha256(d).hexdigest(),'bytes':len(d),'snapshot_path':str(dest.relative_to(O))})
profile_path=rels[1];candidate_path=rels[2]
profiles=json.loads((R/profile_path).read_text())['profiles'];slots=json.loads((R/candidate_path).read_text())['slots'];records=[]
for id in ids:
 i,p=next((i,x) for i,x in enumerate(profiles) if x['id']==id)
 slot,j,c=next((s,i,c) for s,rows in slots.items() for i,c in enumerate(rows) if c['id']==id+'_candidate')
 records.append({'id':id,'profile_pointer':'/profiles/'+str(i),'profile_record_sha256':hashlib.sha256(json.dumps(p,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()).hexdigest(),'profile':p,'ordinary_candidate_pointer':'/slots/'+slot+'/'+str(j),'ordinary_candidate':c})
(O/'frozen-selected-records.json').write_text(json.dumps(records,ensure_ascii=False,indent=2))
archives={
'docs/research-evidence/photo-prompt/renewed-liminal-maintained-alternative-20261003/diagnostic-evidence.tar.gz':['architecture-visibility-audit/decisions.json','architecture-visibility-audit/source-continuity-proof.json'],
'docs/research-evidence/photo-prompt/48h-initial-data-qualification-20261003/diagnostic-evidence.tar.gz':['scene-contract-audit/profile-inventory.json','scene-contract-audit/component-binding-checks.json','scene-contract-audit/component-omission-checks.json','scene-contract-audit/materialization-checks.json'],
'docs/research-evidence/photo-prompt/renewed-oneiric-comparison-alternative-20261003/diagnostic-evidence.tar.gz':['component-evidence-coverage-audit/inventory.json'],
'docs/research-evidence/photo-prompt/renewed-scene-diversity-qualification-20261003/diagnostic-evidence.tar.gz':['containment-gap-review/report.md']}
archive_manifest=[]
for rel,names in archives.items():
 archive_sha=hashlib.sha256((R/rel).read_bytes()).hexdigest()
 with tarfile.open(R/rel) as tf:
  for name in names:
   b=tf.extractfile(name).read();dest=O/'prior-evidence-excerpts'/Path(rel).parent.name/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b)
   archive_manifest.append({'archive':rel,'archive_sha256':archive_sha,'member':name,'member_sha256':hashlib.sha256(b).hexdigest(),'retained_path':str(dest.relative_to(O))})
obj={'repository':'Creatorrrr/image-prompt','commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'head_is_shallow':subprocess.check_output(['git','rev-parse','--is-shallow-repository'],cwd=R,text=True).strip(),'repo_status_at_freeze':subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True),'source_files':manifest,'retained_archive_members':archive_manifest,'record_hash_recipe':'SHA256 of UTF-8 JSON ensure_ascii=False, sort_keys=True, separators=(comma,colon)'}
(O/'source-manifest.json').write_text(json.dumps(obj,ensure_ascii=False,indent=2));print(json.dumps(obj,ensure_ascii=False,indent=2))
