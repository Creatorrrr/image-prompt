# Four realistic-background relations: read-only DATA audit

## Decision

- **KEEP** `rb_water_path_stain`, `rb_vegetation_site_relation`, and `rb_coating_substrate_boundary` as the deliberately narrow manifestations they already define
- **DEFER** a one-leaf render-gate clarification for `rb_use_trace_affordance`: preserve the selected support/reach/passage relation and the author's intended recent-use narrative, but do not ask pixel review to establish actual recency
- **No production correction applied or qualified.** No new profile coverage is claimed. All four exact records were already researched and included in published structural audits

The concrete concern is an assessment-boundary mismatch, not a demonstrated retrieval failure or rendered defect: component 1 requires “a recently used object rests on a stable working surface,” and its current gate fails ambiguous evidence. Visible contact/support can be judged in a still frame; actual time of last use cannot. The existing source proposal explicitly marked unobservable properties `unscored_not_pass`.

## Scope and pin

Repository commit: `b7578916eca10c00fb421a8d6bd73ae0e2d52684`, clean at inspection and source freeze. Checkout is shallow; this audit searches the tracked published evidence present at this commit and makes no assertion about absent unpublished work or unavailable older commits.

Profile source SHA-256: `d014e3b3b692cb312e978ba79c50b1258a257715fcb5ed115f20389d90689520`

Ordinary candidate source SHA-256: `3fdec61f61cd251825fd8b945ea900ff56c0f5e260e0d351ca0a4668c2e1e532`

Relevant maintenance rules: research is not runtime meaning; selected variants remain optional; composition/history/material diagnosis are separate claims; index or contract checks are not rendered quality; changing a registry leaf requires its registry hash to be rebuilt even when positive retrieval text is unchanged. Source files and selected archive members are retained byte-for-byte under this audit directory and listed in `source-manifest.json`.

No production files, providers, images, publishing, or runtime changes were used. New operations were filesystem reads, textual/archive search, JSON extraction, source hashing, and writing this evidence directory. No generator, resolver, schema helper, or test suite was executed as part of this audit.

## Prior coverage before novelty

The exact-ID scan covered 23,288 text objects across tracked `docs/research-evidence`, `docs/analysis`, and `artifacts`, including textual members of all 79 gzip/tar archives. It found 1,140 matching objects, many of them repeated source snapshots or incidental candidate inventories. All archives were readable. Those counts are search inventory, not tests or independently reviewed cases. The complete searchable path/hash index is `prior-coverage-exact-id-hits.json`.

Substantive prior coverage:

1. `realistic-background-20260912/visual-proposals.json` contains all four selected relations, their owners, prerequisites, confusion boundaries and explicit limitations. `evaluation-cases.jsonl` has positive/near-miss specifications for each, marked `not_run`. Use trace and vegetation were explicitly design hypotheses without direct empirical sources; water and coating were source-informed designs, not generator validation
2. `realistic-background-implementation-20260912/source-coverage.json` maps each profile to its ordinary candidate. The implementation report distinguishes selected relations from broad realism, exact activation from candidate discovery, and pixel evidence from claimed history. Its three-arm images cover other selected relation groups; they do not qualify these four profiles merely because all were implemented together
3. `renewed-liminal-maintained-alternative-20261003/diagnostic-evidence.tar.gz`, member `architecture-visibility-audit/decisions.json`, already records **KEEP** for `rb_water_path_stain`: its full definition intentionally includes every named owner. The archive also proves its three component strings are propagated. This audit agrees with that KEEP rather than counting it as new coverage
4. `renewed-oneiric-comparison-alternative-20261003/diagnostic-evidence.tar.gz`, member `component-evidence-coverage-audit/inventory.json`, includes all four records and reports zero unreused component terms. That is literal binding inventory, not proof of visual observability
5. `48h-initial-data-qualification-20261003/diagnostic-evidence.tar.gz`, `scene-contract-audit/*`, already checks these exact four among 40 selected profiles: component binding, one-component omissions, and materializer projection. Those results are explicitly direct production-function checks, not full public CLI or pixel qualification
6. The everyday-scene research already treats use trace as an existing support/reach/passage relation; a containment-gap report explicitly distinguishes the water candidate's descending outlet stain from an active wet front held by a towel

The present contribution is a focused semantic revalidation plus an explicit recency counterexample and proposed gate clarification. No searched human report documented that exact counterexample or recommended this gate-only clarification. This is a bounded “not found in the inspected corpus,” not a claim of first-ever discovery. It adds zero new unique profiles and zero proven consumer-quality improvements.

## Activation and Korean/English sufficiency

All four records share the same intentional separation:

- `activation.exact_terms` contains one **complete English selected-definition string**, including all three relations
- Each authored component has one English match/evidence phrase. The compiler projects all three into required evidence, composition and gates
- Korean labels and short English relation names are `semantics.paraphrase_examples` / concept terms. They describe a broader topic and generally do not entail every component of the narrow variant
- `semantic_discovery_requires_component_evidence: false` permits advisory discovery without first proving the full relation. It is not a statement that any partial phrase satisfies a hard obligation
- Source reading of `resolve_visual_profile_hits` distinguishes exact hard eligibility from semantic optional eligibility; `candidate_pack_visual_component_match` labels paraphrase hits as indirect optional eligibility and documents that it cannot hard-activate a profile

Therefore the short Korean labels are insufficient as complete selected semantics, but that is **not itself a bad hard trigger**. They are not exact hard-activation terms. Adding those labels to exact activation, or making every broad realism request acquire a drain, clear walkway, plants, exposed metal, mug or cloth, would broaden meaning incorrectly.

A complete natural Korean description is not listed as a canonical exact term or full component alternative. That is a localization/retrieval coverage question, not a proven error in this selected contract. An independently authored Korean/English consumer pair should preserve requester meaning even if it never retrieves this profile; forced profile-ID parity is not the correct success condition. No Korean hard-alias addition is proposed.

## Per-record assessment

### `rb_water_path_stain` — KEEP, revalidation

Profile pointer `/profiles/5`; ordinary candidate `/slots/texture/2`.

The exact definition requires the drainage outlet, the narrow mark beginning immediately below that outlet, and the surrounding wall distinguished from the localized mark. All three authored components, instructions and native-scale gates retain those owners and relations. The candidate's English sentence is a compatible shortened depiction; its full concept units preserve the localized-surrounding-wall duty. Korean “물 경로에 연결된 변색” is a topic label, not proof of the complete selected relation.

`affected_dimensions: [material]` is coherent when applying this local surface state to an **already-established** outlet/wall. It does not authorize adding a new drain to a locked smooth wall. The owner relation is semantic data, not an executable proof that the owner exists. A downstream full-scope adoption check remains necessary.

Reject as this selected manifestation: a stripe below an unrelated window, a random vertical discoloration with no visible outlet, or a towel holding an active wet front. An outlet may be off-frame in a valid ordinary photograph, but that is outside this intentionally same-frame variant; it is not a reason to delete the outlet gate. The spatial connection does not diagnose leakage, establish when water flowed, or prove a stain's physical cause.

### `rb_vegetation_site_relation` — KEEP, revalidation

Profile pointer `/profiles/29`; ordinary candidate `/slots/composition/4`.

The selected variant is small plants emerging from soil at a paving edge, their stems joined to that ground area, and a clear maintained walking surface beside them. Definition, component/evidence strings and both-scale gates align. The ordinary candidate retains that pairing; `affected_dimensions: [composition, setting]` describes environment placement/arrangement.

Korean “식생과 바닥 조건의 접속” and the awkward but non-hard English label “vegetation site relation relation” do not specify the paved-edge/clear-route variant. That is insufficient justification to broaden this existing candidate. No cosmetic alias rewrite is proposed as a quality improvement.

Floating/clipped stem bases, a plant decal unconnected to soil, or plants spread across the entire designated path do not satisfy this variant. A coherent wild meadow with no path can still be a valid image outside it. Hidden underground roots, species identity, how long growth took, and actual maintenance history are not requested proofs; visible stem-to-soil connection and clear paving are the assessable relations.

### `rb_coating_substrate_boundary` — KEEP, revalidation

Profile pointer `/profiles/30`; ordinary candidate `/slots/texture/5`.

The selected small worn paint edge, contrasting exposed-metal highlight, and boundary following the part's solid shape are consistently expressed in the definition and all three component/evidence/gate strings. The ordinary candidate is the same small paint-to-metal manifestation; `affected_dimensions: [material]` covers local coating/substrate appearance without requiring a global lighting change.

Korean “도막과 금속 바탕의 경계” names the material boundary but omits the selected local-loss/highlight/shape requirements. It belongs in optional discovery, not as sufficient exact activation.

A bright printed line on intact paint, an isolated metal-colored patch with no coating boundary, or a global rust overlay does not satisfy the selected relation. A coating over wood is a legitimate separate material case, not a defect in this explicitly metal-backed variant. No alloy identification, age, corrosion diagnosis or wear cause follows from the still image.

### `rb_use_trace_affordance` — DEFER one gate clarification

Profile pointer `/profiles/1`; ordinary candidate `/slots/space_condition/0`.

The full selected relation contains a supported object, placement within the user's reach, and a clear adjacent passage. Definition/components/evidence/instructions/gates are textually consistent. The candidate's mug and folded cloth are a narrower allowed realization, not defaults for all lived-in spaces. `affected_dimensions: [setting]` is the declared ordinary scope; neither “used cup” nor that scope licenses changing a locked main subject, pose, user intent, or action.

There is no reason to remove reach, support, or passage requirements. A visible person or an explicit, visibly grounded use position can make reach plausible. An absent or ambiguous reference owner may legitimately fail this selected gate; this audit does not redefine reach or make an off-frame user automatically sufficient.

**Concrete assessment counterexample:** two otherwise identical still images show a mug with a small residue line on a stable work surface near a seated person's hand, a folded cloth nearby, and the same clear passage. In scenario A someone drank from the mug a minute before exposure. In scenario B the same visible residue was staged, or the mug has remained unchanged since the previous day. Support, distance and passage pixels are identical. They cannot establish the truth of “recently used.” Neither residue, steam nor arrangement alone certifies a past event or its timing.

This does not invalidate the intended fictional narrative or the visual suggestion of use. It shows why the gate's current unconditional treatment of ambiguous recency as failure overstates what a pixel reviewer can establish. No actual consumer/pixel false pass has been observed here.

The minimum proposal in `minimum-data-only-proposal.json` changes **only component 1's render-gate description**. It assesses visible object support, permits use-compatible appearance to suggest the narrative, and explicitly withholds certification of whether/when use occurred. The definition, exact activation, all match/evidence terms, composition instructions, component count, gate ID/scale, reach, clear passage, candidate and all other records stay unchanged. No mandatory residue, steam, damage, dirt, extra user, prop or temporal event is introduced.

This proposal remains **DEFER**, rather than an adopted improvement: an independent consumer reviewer should first confirm that it distinguishes intended narrative from scored visible support without silently dropping requester meaning. If that separation is not accepted, retain the current data and record recent-use verification as unresolved; do not expand the task into a new cue recipe.

## Ordinary-candidate effects and unproven risks

The four candidates expose concept units, owner relations and their authored dimensions; `semantic_source()` preserves those declarations and does not manufacture missing prerequisites. Profile association is not hard activation by itself. Their narrow names can remain useful even when a whole selected relation is unsuitable for an individual scene.

A material-only candidate must not create a missing outlet or replace locked wood with metal; a setting candidate must not manufacture a main actor or alter locked action; a composition/setting candidate must not add vegetation over a requester-locked bare path. These are concrete full-consumer controls, not findings that current runtime actually allowed those edits. No generic expansion of `affected_dimensions`, new guard tags, or runtime ID branch is justified by this read-only review.

## Qualification plan and stopping rule

`consumer-test-plan.json` defines fresh bilingual selected positives, partial/neighbor controls, and effect-scope controls. It separates semantic cases from their translations and from output artifacts. It is a **plan, not executed evidence**.

For the use-trace one-leaf proposal, first freeze the exact original request envelope, independently authored baseline, core, controls, embodiment review, query inputs and source hashes. Use the public generator with the current real indexes and the normal composer/view/audit path in isolated baseline/proposal snapshots. A query vector may be reused only when its exact input and vector-space identity already match; do not fabricate a cache or invoke a provider in this read-only authorization. If an actual run needs an unavailable vector or other permission, stop with the precise blocker.

Required comparisons: (a) same packs except the approved gate, source/pack hashes and directly bound projections; (b) identical required textual evidence and support/reach/path duties; (c) identical activation and candidate inventories for fixed inputs; (d) real composed-prompt and dry-run runtime audits, with one missing spatial component rejected; (e) no unauthorized owner insertion or locked material/action change through the ordinary candidate lane. Helper success alone cannot close these gates.

A gate-only registry edit is outside positive retrieval text, so every semantic text/vector should remain unchanged. Verify that from exact compiled inputs before rebuilding only metadata; do not assume it. Any unexpected retrieval/text change or need to alter core, expectation, existing data scope, or runtime stops the proposal. Preserve first failures rather than rewriting the fixtures to pass. No image quality or actual-history claim is available without separate authorized, appropriately limited visual assessment; no image generation is requested here.

## Artifacts

- `source-manifest.json` and `source-snapshots/`: exact source hashes and retained bytes
- `frozen-selected-records.json`: four profiles and four linked ordinary candidates with pointers
- `prior-coverage-exact-id-hits.json`: complete published exact-ID search results, with compressed-source hashes
- `prior-coverage-recency-report-hits.json`: supplementary human-report phrase search
- `prior-evidence-excerpts/`: relevant original archived audit members
- `minimum-data-only-proposal.json`: one uncommitted, unqualified gate leaf
- `consumer-test-plan.json`: 12 conceptual controls with bilingual request text, not 24 independent cases
- `verification.json` and `artifact-manifest.json`: source stability, clean status and output integrity
