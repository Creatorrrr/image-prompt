# Independent source-semantic review: use-trace render gate

## Decision

**DEFER implementation; reject the first proposed wording and keep the production source unchanged.** The intended distinction between depicted recent use and verified historical recency is sound. The exact proposed gate is not a semantics-preserving clarification: “may suggest use” and the final “support evidence” condition can allow a gate pass based only on support geometry, even when the visible scene fails the selected use narrative.

A narrower, one-leaf clarification is defensible, but it is not a qualified consumer improvement. The current source already limits capture-history claims. The audit establishes a possible reading ambiguity, not that the current contract necessarily demands historical proof, nor an observed bad assessment. No full consumer, provider, image, index, production-edit, or publication operation was performed in this review.

## What the sources actually require

Repository inspected: `b7578916eca10c00fb421a8d6bd73ae0e2d52684`; worktree clean at start and final verification. Profile source SHA-256: `d014e3b3b692cb312e978ba79c50b1258a257715fcb5ed115f20389d90689520`.

1. **Current selected meaning includes recent use.** In `skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations_realistic_background.json`, lines 120–192, the exact term, definition, component match/evidence terms, composition instruction and gate all retain “a recently used object rests on a stable working surface.” This is a selected depiction, not a broad realism default. The current claim limit at lines 146–149 already says a depiction is not capture-history evidence.
2. **The visible spatial duties are genuine.** The same profile, lines 195–226, independently requires placement within the user's reach and a clear adjacent walking route. They are not waived by uncertainty about the object's past. The proposed edit correctly leaves both intact.
3. **Original research does not prescribe a temporal cue.** `docs/research-evidence/photo-prompt/realistic-background-20260912/visual-proposals.json`, lines 52–92, names the selected working surface and used props as owner, presupposes a space in use with appropriate selected props, and requires stable support, reachable placement and retained passage. Its English candidate depicts a recently used mug beside a folded cloth. It provides no residue, steam, dirt, damage or time-proof requirement. The corresponding positive/near-miss specifications in `evaluation-cases.jsonl`, lines 3–4, are `not_run`.
4. **The research explicitly distinguishes depiction from diagnosis.** The original `report.md`, lines 34–36, separates actual causal diagnosis from depicting the chosen cause/effect relation. Lines 53–61 explain usable placement and lived-in appearance without equating them to dirt or poverty. The implementation `report.md`, lines 18–22, likewise separates selected visible components from certification of capture history. This supports fictional or staged representations without requiring their story to have occurred in reality.
5. **`unscored_not_pass` is not a recency-specific rule.** It appears in the original proposal's general evaluation block. It does not specifically identify recent use as an omitted component or authorize scoring only support. The research report at line 208 applies non-observation/partial-failure treatment to required visible regions. The current runtime reference, `references/image-runtime.md:19`, requires image-grounded pass/fail evidence for each hard gate. Neither fact supplies a hidden-history verification procedure.
6. **Keeping prose evidence does not preserve the scoring obligation by itself.** `scripts/visual_profile_contracts.py:146–155` separately projects evidence requirements, gates and composition instructions. A gate can be weakened while its prompt phrase remains unchanged. This is a source reading only; the compiler was not executed.

## Precise objection to the submitted proposal

The counterexample of pixel-identical mugs with different hidden histories is valid: the image cannot distinguish actual recent drinking, yesterday's unchanged scene and a deliberately staged scene. **All three can legitimately depict the same selected recent-use narrative.** The counterexample therefore defeats a historical-certification reading; it does not show that the intended narrative can be dropped from visible assessment.

The proposed gate changes two different things:

- Correctly excludes knowledge of whether/when actual use happened
- Changes a required selected depiction into an optional suggestion: “Its depicted state may suggest use,” followed by failure only for missing/ambiguous “support evidence”

A reviewer reading that text can mark component 1 satisfied by a supported object while ignoring a visible contradiction of its requested use role. That is a potential gate-to-instruction mismatch. The unchanged definition and prompt can continue to say “recently used” while the hard gate no longer checks its depiction. It is a source-level risk, not an observed runtime false pass.

The omission is also not repaired by adding a mandatory stain, steam plume, visible person, gesture or timestamp. Those are unrequested implementations. A spotless object may fit the selected use narrative through the scene's functional context; dirt is neither necessary nor sufficient. No extra fourth component is justified.

## Narrow one-leaf alternative

Keep the same JSON pointer, gate ID, scale and all other source fields. Proposed replacement description:

> A recently used object is depicted resting on a stable working surface. All named owners must be visible in this image. Missing, ambiguous, substituted or partly realized visible evidence for this selected depiction fails. Assess recent use as the requested narrative supported by the object's visible state and use context, not as proof of an actual past event or elapsed time. Uncertainty about actual use or its timing alone is not a failure and does not require an added cue.

This retains a required depiction and its fail-closed visible-evidence boundary, and limits the type of claim a pass makes. “Visible state and use context” is a reading of the existing selected object/working-surface relationship, not an additional mark, prop, pose or action. The alternative is saved as a review artifact, **not applied**.

If even this clarification cannot be interpreted without a new cue requirement, leave the source as it is and record the historical-certification reading as unsupported. Do not erase recent-use meaning or redesign the profile to force a determinate timestamp.

## Counterfactual semantic checks, not executed tests

- **Identical pixels, different hidden histories:** same visible verdict in both histories; no claim that either history was proved. Staging is not a reason to fail a fictional depiction
- **Clean object in a coherent use setting, no stain or steam:** absence of a prescribed trace is not a failure. Judge the selected object's visible role and existing scene context
- **Supported replacement contradicts an explicit requested use depiction:** support alone cannot clear component 1. For example, where the frozen request requires the drinking mug as just used in that scene, replacing it with visibly unopened retail inventory changes the depicted role. Do not infer a universal rule about all packaged objects' real histories
- **Ambiguous support or floating object:** component 1 still fails, even if its appearance suggests use
- **Object beyond the grounded user's reach:** component 2 still fails; no off-frame user assumption is created
- **Blocked adjacent passage:** component 3 still fails, regardless of support or narrative plausibility
- **Owner concealed, or only the prompt says the object is present:** missing visible evidence still cannot receive a pass

These checks are analytic expectations for later independent qualification, not new authored fixtures and not pixel observations. The proposed wording must not be used as its own proof of success.

## Qualification boundary

Source-semantic approval is limited to the narrower claim boundary above. Before adoption, the parent should separately decide whether to authorize isolated fixed-input public consumer comparisons, confirm unchanged activation/evidence/composition/candidate text and correctly refreshed registry metadata, and inspect the actual propagated gate. Neither unchanged vectors nor CLI audit success would establish that a generated image preserves the narrative. This review adds zero rendered-quality results and zero empirically proven improvements. DATA-only and main-held constraints remain intact.

## Retained evidence

- `rejected-first-proposal.json`: byte-for-byte copy of the submitted proposal, including its original status and wording; its original file is unchanged
- `source-evidence.json`: exact original research record and its two `not_run` cases, plus the current profile and ordinary candidate
- `narrow-alternative.json`: separately frozen one-leaf semantic alternative, not adopted or executed
- `verification.json`: source hashes, clean worktree check, reviewed files and artifact hashes

The original use-trace relation is exactly “소품이 안정된 지지면에 놓임”; “손이 닿는 위치에 사용 물건이 있음”; “통행 경로가 유지됨”. The owner is “선택한 작업면과 사용하는 소품”, and the prerequisite is “사용 중인 공간이며 적절한 소품 1–3개 선택”. The candidate narrative is exactly “A recently used mug rests within reach beside a folded cloth, with the walking route left clear.” These support a visible use-role reading without an invented trace recipe or historical proof obligation.
