# Color scope consumer qualification: plan only

## Decision and boundary

**KEEP all four meanings; DEFER metadata changes.** Broad `color` ownership is deliberately conservative under partial color locks. The current source shows where a declaration can block a compatible realization, and where an empty declaration provides no cross-carrier overlap evidence. Neither observation establishes a consumer defect or a DATA-only remedy.

Read-only source: `image-prompt` at `0efc2dfde7de9693799d3c84618705332e59920c`. This is a source-guided refinement of `../color-owner-audit`, whose baseline was `b7578916eca10c00fb421a8d6bd73ae0e2d52684`; all four complete profiles, ordinary rows, and linked source bundles remain unchanged. It is not a new consumer run. No production, runtime, DATA, index, or test edits; no test execution, prompt generation, provider/network calls, or images. **Zero new unique coverage.** Leave the concurrent V12 worktree and its tests alone. Future execution requires a separately authorized isolated snapshot, after the main implementation settles.

## What the actual contract says

1. `photo-intent-lock/v2` property anchors add only `target` and `property` to the ordinary anchor fields (`anchor_id`, `source_text`, `dimension`, `prompt_evidence`). They require an explicitly open dimension, lowercase dotted paths, requester-grounded source text, and literal baseline evidence. Fully specified dimensions remain locked. `concept`, `subject`, and `event` always remain locked. `normalize_intent_lock` validates path syntax and provenance, **not a color-owner ontology** [S2].
2. Candidate effects are `affected_dimensions` plus optional `affected_properties`, whose rows contain exactly `dimension`, `target`, and `property`. No `owner_scope`, `field_effects`, `subject_palette`, `background_palette`, owner inventory, or scope-membership graph is recognized here. Candidate `relations` is a separate `{id,type,subject,object}` evidence surface, not a lock-owner resolver [S3].
3. `property_effects_allowed` requires at least one declared effect for each affected dimension that also has a property lock. With an ordinary candidate's `affected_dimensions: ["color"]` and missing/empty effects, **any color property anchor blocks compatibility**, even on another owner. Parent/child paths and `*` overlap. Explicit target/property overlaps are checked across carrier dimensions [S1].
4. The empty-effects cross-carrier case differs: if the only color-meaning anchor is carried under `appearance` or `material`, a candidate declaring only `color` and no effects supplies no overlapping rows and has no same-dimension lock to trigger the missing-effects guard. This is a static consequence of the helper, **not permission to recolor the fixed owner and not proof of a reachable unsafe adoption**. Frozen evidence, candidate interpretation, and semantic review still apply [S1, S7].
5. Canonical paths are literal lexical identities. This contract has no mapping from a source's “one named owner,” “specified scope,” or “separate scene elements” to each request's owners. `main_subject / wardrobe.color`, `main_subject / wardrobe.garment_type`, and `main_subject / wardrobe.material` have source precedents; `cup / surface.material` appears in a helper fixture, not a production color-owner registry. Production color effect precedents are predominantly `* / *`; a narrow `main_subject / skin.color` exists for a different editing operation. Neither can be repurposed as these four relations' scope [S8].

Use only existing wire fields. A later core author may ground ordinary lowercase target/property values under the generic path contract, but must document which physical owner/property each means and use the identical values everywhere. Such run-local values are not new supported global labels. A candidate must not gain compatibility merely because its invented target string differs from the protected owner's string. Do not substitute `subject` for `main_subject`, or an arbitrary palette path for `wardrobe.color`, to make overlap disappear.

## Why the consumer path matters

The current public generator first validates the envelope, core, controls, and embodiment review, then loads DATA. Ordinary retrieval uses grounded whole-scene/focused BM25F and bounded slot allocation. Generic ordinary eligibility does not itself check property effects; pack construction subsequently marks incompatible candidates `ineligible` with source `authored_property_scope`. Public and joint bundle admission also check effects. Thus “not in the pack,” “present but ineligible,” and “eligible but not chosen” are different outcomes [S4–S5].

`compose_pack_view.py` carries applicability and both effect fields into the overview and returns exact selected detail records from the immutable pack [S6]. The composed auditor independently reloads source DATA, recomputes bundle admission, checks selected ordinary effects against source, checks interpretation effects, and preserves requester anchors. Declaring only a friendly final effect cannot repair missing source effects. Literal evidence retention does not prove absence of contradictory added prose [S7].

The four ordinary rows all retain both authored concept units but no property effects, directed relations, or `core_assertion_discovery` opt-in. Their linked optional bundles retain both components. Bundle adoption never automatically promotes the associated profile. A profile's hard activation or opt-in visual concept is a separate route and cannot stand in for ordinary-candidate use [S3, S9].

## Four proposed cases

These are **hypothetical evaluation requests**, not quotations of the user. `qualification-matrix.json` records the same four cases and negative controls. A fresh author must create full valid pre-core artifacts from each case's request alone, without candidate IDs, exact source sentences, or old pack prose. Freeze all variants before retrieval. Do not broaden a request after seeing an absent candidate.

### C1: Restricted subject, fixed garment and background

Proposed request: Photograph the same adult model wearing a cream cotton coat and an existing scarf before the same blue painted wall. Keep the coat's color and material, the person's identity, the scarf's existence, and the blue wall unchanged. The scarf's hue and other unprescribed photographic choices are open; a limited subject palette may be considered if compatible with those fixed details.

Target: `slot:color:cr_candidate_restricted_subject`. A useful adopted change would assign a concrete hue to the existing scarf within a compatible restricted subject palette, while preserving fixed garment/background facts. The baseline must not already lock that authorial hue or the complete optional relation. Protect garment color/type/material using source-established property meanings; retain the background's fixed color and owner through a grounded semantic anchor, without claiming the background has a built-in owner label.

This is also an important conservative control: a static effect that truthfully covers all subject coloration may overlap the fixed coat. Listing only the scarf would underdeclare this generic source meaning unless the source contract really supports request-scoped restriction. Do not call this a missing-metadata bug merely because the particular scarf realization is safe.

### C2: Restricted background, fixed subject color/material

Proposed request: Photograph the same adult model in a yellow cotton coat in front of three existing plaster backdrop panels. Preserve the model, coat color/material/type, and the panels' identities and materials. Background hue choices and unprescribed photographic choices remain open; a small background palette is welcome, independently of the coat.

Target: `slot:color:cr_candidate_restricted_background`. A useful adopted change would assign a concrete limited palette only to those panels. Freeze matched carrier variants for the fixed coat color: first a `color` anchor, then `appearance`, and optionally `material`, with the **same `main_subject / wardrobe.color` meaning, evidence, and owner**. Rebuild/hash each legitimate core; do not mutate a canonical core in place. A carrier contrast may also change retrieval queries, so record that separately from compatibility.

This is the strongest potential false-suppression witness, but it still cannot justify inventing a globally understood “background” target. A safe DATA-only declaration needs an existing consistently bound background scope across actual consumers, not merely syntactically accepted distinct strings.

### C3: Local achromatic accent, colored outside owner

Proposed request: Photograph an existing tabletop arrangement containing the same red porcelain cup and the same tray in front of a blue wall. Keep the cup red and porcelain, keep both objects and their placement, and preserve the blue wall. Within the tabletop arrangement only, the cup is the sole chromatic accent; other tabletop tones may be chosen achromatically, retaining shading. Other unprescribed photographic choices remain open.

Target: `slot:color:cr_candidate_achromatic_accent`. A useful changed final realization would assign/clarify previously open achromatic tray tones without desaturating the wall, recoloring the cup, or adding another accent. The complete requested accent relation belongs to requester meaning; merely repeating its existing baseline wording is not candidate improvement. If the baseline already completely realizes the proposed optional contribution, record **no visible prose benefit** and stop that adoption comparison.

Both the accent owner and the boundary are request-dependent. Freeze their real semantic evidence before retrieval; do not manufacture a serialized `scope_members` or `accent_owner` field. If current paths cannot faithfully represent the proposed source-level effects, DEFER to generic runtime design rather than hardcode cup/table/wall labels into a reusable relation.

### C4: Color repetition across existing separated owners

Proposed request: Photograph the same red porcelain cup and the same ceramic vase already separated by a visible gap on a shelf. Keep the cup red and porcelain, keep the vase ceramic, preserve both objects and their positions, and add no objects. The vase's hue is open and may echo the cup; other unprescribed photographic choices remain open.

Target: `slot:color:cr_candidate_color_repetition`. A useful adopted change would color the existing vase within the cup's hue family and explicitly preserve the existing gap. It cannot create a third owner, replace either object, or change geometry. Run a paired requester variant in which both objects' incompatible hues are fixed, and another with a fixed touching/occluded arrangement: decline rather than recolor a protected surface or move owners to rescue the relation.

The source does not prescribe a fixed owner count, owner names, or a fixed target list. A per-case two-object effect list in global DATA would be false precision; adding `subject` or `composition` effects merely to legitimize object creation/movement would change the meaning.

## Negative controls, without multiplying the claim

Within those four cases, use only controls that answer the contract question:

- Matched same-meaning carrier anchors (`color` versus `appearance`/`material`) with identical target/property identity; changed retrieval is a separate observation
- A whole `color` lock, and same-owner exact/ancestor overlap where applicable: no source edit may bypass them
- Wrong-owner recoloring, material substitution, owner replacement/addition, scope expansion, and (for C4) movement/merged owners; retain original fixed phrases elsewhere to expose the limits of literal-only checks
- Missing one ordinary concept unit or one selected bundle component; report ordinary semantic review separately from bundle component-field enforcement
- An unrelated feasible existing effect and the unchanged baseline as controls, without treating their pass as proof that a target candidate should pass
- Bare family labels and an unselected/profile-only result remain advisory/separate; never count them as an adopted ordinary contribution

No duplicate-source variant, carrier control, helper test, or altered final artifact adds a unique family to coverage.

## Future execution sequence, not authorized or run here

1. Pin and hash a clean isolated snapshot of the final integrated source. Preserve the original audit and this plan. Re-read any changed contract before executing. Use supported local public CLI inputs and source-bound indexes only; the current normal CLI has no invented `--offline`/`--lexical` switch. Its ordinary lane is grounded BM25F. Record the actual retrieval mode; never represent cached/synthetic vectors as live dense retrieval.
2. Independently freeze requester text/spans, controls, authorial core, minimal literal fixed evidence, feature-selection record, and embodiment review. Preserve actual owner/color/material/position facts while keeping unspecified choices genuinely open. Ground partial prescriptions at the narrowest meaningful existing path convention; required typed assertions must not force an entire open color dimension closed merely to make this test easy. If needed semantics cannot be represented truthfully, record the schema/design blocker and stop that case.
3. Generate one real public pack per pre-frozen arm with `generate_photo_prompt.py`. Save command/stdout/stderr, source and index hashes, pack/core/lock/retrieval hashes, ordinary source identity, and applicability. Read the compact view, then request the target's full detail **only if actually exposed**. Also record whether a bundle is public or joint-admitted and why. Source presence, helper-injected inventory, profile retrieval, or `applicability: eligible` alone is not reachability/adoption success.
4. If absent, diagnose the first supported boundary (ungrounded query, lexical/rank cap, context guard, partial lock, bundle admission) without rewriting the case, adding aliases/discovery opt-in, or injecting the target. Preserve honest non-exposure. A controlled helper witness can later isolate a boundary but must remain separately labeled and cannot upgrade the consumer result.
5. For a genuinely eligible useful candidate, author the baseline-retained control and one complete changed final composition through existing selection/interpretation fields. Record selected ordinary ID or selected public bundle plus its canonical ordinary member, source effect declarations, exact adopted final clauses, and baseline-to-final text diff. Require an actual new useful visible instruction; no ID-only adoption, `realization: baseline` escape, duplicated source wording, or unrelated nice detail. Preserve full meaning of both units. Keep profile activation independent; satisfy its components/gates only if that route actually imposes them.
6. Run the complete composed audit against the unmodified full pack and source snapshot. Separately review all fixed owner/color/material facts and the new final prose semantically, including contradictions after retained anchor phrases. For each negative mutant save precise mechanical failure or unexpected acceptance plus separate semantic judgment. A mechanical pass on a wrong-owner mutant is a documented audit boundary, not a safe result and not automatically a DATA defect.
7. When separately approved, build a runtime-request artifact without sending it to an image tool, retain complete final prose and all bindings, and run the runtime audit. Include append-only wrong-owner changes in this downstream artifact, because containing the valid composed prompt does not itself prove the surrounding runtime text is compatible. No provider, render, or pixel claim follows. Stop after the minimal qualified comparison or a demonstrated blocker; do not run heavy aggregate tests alongside V12.

## Evidence threshold for a DATA-only proposal

All of the following are needed:

- Same frozen request and valid independently authored core, actual consumer path, trustworthy source/index binding, and reproducible exact stage of exclusion or unsafe adoption
- A materially useful permissible final change, identified in prose and approved by semantic review, whose absence is attributable to these source effects rather than ranking, baseline completeness, missing authoring scope, or an unrelated runtime guard
- Proof that the proposed effect list covers **every possible changed semantic property and owner in the unchanged candidate meaning**, including inherited bundles/profile candidate surfaces where relevant; no omission of accent remainder, subject surfaces, or repeated owners
- Existing unambiguous target/property identity across core, source, overview, detail, selected interpretation, and audit; no request-specific owner enumeration baked into reusable DATA, no aliases used to escape overlap, no made-up ownership resolver
- A later authorized isolated DATA-only comparison that changes only truthful effect metadata (and mechanically required source-bound regeneration), preserves English/Korean meanings, both components/gates, independent activation, locked properties and materials, whole-dimension locks, and negative controls
- Changed final prose with a clearly described benefit and no protected changes. Helper acceptance, wider exposure, or more passes alone is insufficient

If a truthful broad scope necessarily intersects a protected property, **KEEP conservative blocking**. If owner binding, local-scope membership, path aliasing, or semantic contradiction detection requires generic runtime design, **DEFER** and describe that design question without patching DATA. If no eligible target is exposed, the source remains ambiguous, no genuine final difference is useful, or the existing baseline/direct independently justified choice already suffices, **DEFER/no demonstrated benefit**. Do not force a patch or relabel an adoption to manufacture success.

## Deliverable and accounting

This packet contains only a plan, four-case matrix, static source evidence/continuity, and artifact hashes. Execution, mutation outcomes, consumer quality, and render quality are all **not run / unknown**. Current KEEP meanings and DEFER effects remain unchanged; repeated-source revalidation adds zero new unique behavioral coverage.
