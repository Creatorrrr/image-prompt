# Color owner/scope DATA audit

## Decision

KEEP the four authored meanings and their four directly linked ordinary candidates. DEFER any scope-metadata edit until an actual ordinary-candidate consumer reproduction identifies a mismatch. This audit found no demonstrated data contradiction or consumer bug. No production files, indexes, tests or runtime code were changed; no provider/network calls or images were used.

Baseline: clean main `b7578916eca10c00fb421a8d6bd73ae0e2d52684`. Audit is static source comparison, not a full consumer qualification. Main remains held pending external PR5 integration. Camera metadata was not evaluated.

## Prior coverage checked first

- The September 10 implementation covers these authored families. `color-tests-v2.log` records the existing eight-test suite, including complete-relation activation, negation, subject/background opposition, component-to-gate compilation, and ordinary-bundle dimension checks. These historical results were read, not rerun or claimed as new passes.
- All four full profile rows and all four ordinary candidate rows are unchanged from the September 12 realistic-background baseline snapshots. See `revalidation-continuity.json`.
- All 64 local published `.tar.gz` archives were inventoried. Text members up to 8 MB were scanned for selected profile and candidate IDs, yielding 146 matching members; ten larger text members were explicitly skipped and listed. Many hits are source/rank inventory or collateral pack appearances, not owner-specific qualification.
- The preserved lighting/composition diagnostic contains advisory-only occurrences of all four profiles. Their `hard_eligible` values are false. Its appearances must not be counted as new hard activation or owner-preservation tests.
- The October 1 lighting-color owner cleanup changed five `pe_*` relations, not these four `cr_*` meanings. That adjacent cleanup does not prove a new defect here.
- September's rendered Color Echo scene did not select `cr_color_repetition`; the implementation report explicitly separates baseline-authored conditions from actual adopted data. It does not qualify this profile's ordinary candidate.

Unique new behavioral coverage claimed: zero. This packet adds a current source-alignment review and a proposed qualification matrix only.

## Selected meaning and ordinary-candidate alignment

1. `cr_restricted_subject`: the subject's selected principal hue families stop at the subject boundary; background colors remain independently assigned. English candidate prose, Korean optional label, both components, and both gate descriptions agree. The candidate cannot use this relation as authority to recolor the background.
2. `cr_restricted_background`: the reciprocal background restriction explicitly leaves subject colors independent. Its candidate and gate owners agree. Do not replace it with a global palette limit or allow subject/wardrobe/object recoloring merely to satisfy this candidate.
3. `cr_achromatic_accent`: one named owner retains a single principal chromatic accent; the remainder of the *specified scope* stays achromatic with shading. A tabletop scope does not imply a whole-image scope. The broad bilingual label remains optional. Preserve this valid narrow one-owner variant rather than converting every single-accent interpretation to it.
4. `cr_color_repetition`: one recognizable hue family recurs on distinct scene elements, with visible spatial gaps. Existing separated owners permit a color-only realization. The source does not require creating/replacing/moving owners; a locked incompatible arrangement should not be repaired by undeclared geometry changes.

For all four, exact definition equals the complete exact activation term, joined component evidence, candidate English prose, and bundle proposition. Candidate concept units equal component evidence, labels agree across the profile/candidate/bundle, and each gate retains its component owner/scope. All direct ordinary candidates declare only `color` as an affected dimension. Static checks and exact records are retained separately.

## Metadata questions, not demonstrated consumer bugs

The ordinary rows omit `affected_properties` and structured owner relations; profile candidate blocks also lack explicit effect metadata. This is coarse, but it does not establish unsafe adoption. `photo_contracts.property_effects_allowed` rejects missing effects when a property lock shares the declared affected dimension. It explicitly distinguishes recorded scope checks from semantic truth. Cross-carrier color anchors (for example wardrobe color under appearance or material), actual public exposure and final owner preservation still require the actual consumer path.

Do not add `subject`, `props` or `composition` effects speculatively: that could broaden a valid color-only candidate into permission to alter owners or arrangement. Request-scoped owners also cannot safely be replaced with a guessed fixed target path.

Two broad-family warnings look asymmetric in isolation: the background variant retains a generic warning about replacing a whole-image restriction with a subject-only one, and the accent variant warns against assuming every single hue means one object. Both are inherited from recorded broader families, while positive selected contracts explicitly preserve narrow meanings. They are not sufficient grounds for a semantic rewrite.

## Minimal next qualification

`consumer-qualification-plan.json` proposes four frozen owner cases: subject-only, background-only, local achromatic accent, and repetition across existing owners. Each must trace the real ordinary candidate from source through public pack, detail, adoption, composed/runtime audit and component/gate preservation. Paired mutations recolor the wrong owner, broaden the named scope, omit a component, or create/replace/move owners. Property-anchor carrier variants test the coarse-metadata concern directly.

The plan has not run. Existing source/index presence or helper-only checks cannot substitute for actual exposure and adoption. Any unavailable stage must remain deferred. No render or visual-quality claim is proposed. Re-check against integrated main before any later release decision.

## Evidence

- `source-manifest.json` and `source-snapshots/`: exact local sources, hashes, baseline and clean-status record
- `frozen-selected-records.json`: the four profiles, four ordinary candidates, four linked relation bundles, and family coverage
- `static-alignment-checks.json`: source alignment only, not runtime validation
- `prior-coverage-archives.json`, `historical-collateral-classification.json`, `revalidation-continuity.json`: prior overlap and conservative coverage accounting
- `decisions.json`: KEEP/DEFER decisions and precise limits
- `consumer-qualification-plan.json`: proposed future actual-consumer matrix
- `audit_sources.py`, `write_report.py`: local evidence-generation scripts; no production editing
