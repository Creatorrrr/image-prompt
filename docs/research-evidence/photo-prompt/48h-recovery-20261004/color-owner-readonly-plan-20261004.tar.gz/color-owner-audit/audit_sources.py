#!/usr/bin/env python3
"""Read-only color owner DATA audit; no runtime imports, provider calls or tests."""
import hashlib,json,subprocess,tarfile
from pathlib import Path
ROOT=Path('/workspace/scratch/ce8f20680f5a/image-prompt')
OUT=Path(__file__).resolve().parent
IDS=['cr_restricted_subject','cr_restricted_background','cr_achromatic_accent','cr_color_repetition']
CIDS=[p.replace('cr_','cr_candidate_',1) for p in IDS]
FILES=[
'skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations_color_relations.json',
'skills/photo-prompt-image-generator/assets/photo_prompt_color_relations_extension.json',
'skills/photo-prompt-image-generator/references/maintenance.md',
'skills/photo-prompt-image-generator/scripts/photo_contracts.py',
'skills/photo-prompt-image-generator/scripts/photo_candidate_semantics.py',
'skills/photo-prompt-image-generator/scripts/prompt_generator.py',
'skills/photo-prompt-image-generator/scripts/visual_profile_contracts.py',
'docs/research-evidence/photo-prompt/extension-maintenance/photo_prompt_color_relations_extension.json',
'docs/research-evidence/photo-prompt/color-combination-patterns-20260910/pattern-catalog.md',
'docs/research-evidence/photo-prompt/color-relations-implementation-20260910/report.md',
'docs/research-evidence/photo-prompt/color-relations-implementation-20260910/coverage.json',
'docs/research-evidence/photo-prompt/color-relations-implementation-20260910/color-tests-v2.log',
'docs/research-evidence/photo-prompt/lighting-color-owner-data-cleanup-20261001/REPORT.ko.md',
'docs/research-evidence/photo-prompt/lighting-color-owner-data-cleanup-20261001/changes.json',
'docs/research-evidence/photo-prompt/lighting-color-owner-data-cleanup-20261001/frozen-inventory-queries.json',
'tests/test_photo_color_relations.py',
'docs/research-evidence/photo-prompt/realistic-background-implementation-20260912/baseline/skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations_color_relations.json',
'docs/research-evidence/photo-prompt/realistic-background-implementation-20260912/baseline/skills/photo-prompt-image-generator/assets/photo_prompt_color_relations_extension.json',
]
def sha(b):return hashlib.sha256(b).hexdigest()
def dump(n,x):(OUT/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def load(p):return json.loads((ROOT/p).read_text())
manifest=[]
for p in FILES:
 b=(ROOT/p).read_bytes();dest=OUT/'source-snapshots'/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b)
 manifest.append({'source_path':p,'snapshot_path':str(dest.relative_to(OUT)),'bytes':len(b),'sha256':sha(b)})
start={'commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'status':subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,text=True).strip(),'scope':'four named profiles plus four directly linked ordinary color candidates and their relation bundles','mode':'static source comparison only; no production edits or runtime execution'}
dump('source-manifest.json',{'baseline':start,'files':manifest})
profiles={p['id']:p for p in load(FILES[0])['profiles'] if p['id'] in IDS}
ext=load(FILES[1]);candidates={e['id']:{'slot':s,'row':e} for s,es in ext['slots'].items() for e in es if e['id'] in CIDS}
variants={v['id']:v for v in ext['visual_semantics'] if set(v.get('hard_profile_ids',[]))&set(IDS)}
record=load(FILES[7]);family={k:v for k,v in record['maintenance_only']['family_coverage'].items() if set(v.get('profiles',[]))&set(IDS)}
dump('frozen-selected-records.json',{'profiles':profiles,'ordinary_candidates':candidates,'linked_variants':variants,'maintenance_family_coverage':family})
checks=[]
for pid in IDS:
 p=profiles[pid];c=candidates[pid.replace('cr_','cr_candidate_',1)];v=next(v for v in variants.values() if pid in v['hard_profile_ids']);comps=p['authored_components']['components'];parts=[co['evidence_terms'][0] for co in comps]
 checks.append({'profile_id':pid,'definition_equals_complete_exact_term':p['semantics']['definition']==p['activation']['exact_terms'][0],
 'definition_equals_joined_components':p['semantics']['definition']=='; '.join(parts),
 'candidate_en_equals_profile_definition':c['row']['en']==p['semantics']['definition'],
 'candidate_units_equal_component_evidence':c['row']['concept_units']==parts,
 'bundle_proposition_equal_profile_definition':v['primary_visual_proposition']==p['semantics']['definition'],
 'bundle_components_equal_component_evidence':[g['visible_evidence'][0] for g in v['component_groups']]==parts,
 'broad_labels_are_optional_not_exact':not set(p['semantics']['paraphrase_examples'])&set(p['activation']['exact_terms']),
 'labels_aligned_across_profile_candidate_bundle':p['semantics']['paraphrase_examples']==c['row']['aliases']==v['source_keywords'],
 'gate_descriptions_preserve_component_owner_scope':all(co['render_gate']['description'].startswith(co['evidence_terms'][0]+'. Judge the declared owners and scope') for co in comps),
 'ordinary_affected_dimensions':c['row']['affected_dimensions'],'ordinary_affected_properties':c['row'].get('affected_properties'),'explicit_owner_relations':c['row'].get('relations'),
 'profile_effect_dimensions':p.get('concept_candidate',{}).get('affected_dimensions'),'gate_ids':[co['render_gate']['id'] for co in comps]})
dump('static-alignment-checks.json',{'kind':'static source assertions, not consumer qualification','profiles':checks,'all_assertions_true':all(v is True for r in checks for k,v in r.items() if isinstance(v,bool))})
# Published local history: enumerate all archive members, scan text up to 8 MB and retain skipped inventory.
archive_results=[];archives=[];skipped=[];text_suffixes={'.json','.jsonl','.md','.py','.csv','.log','.txt'};terms=[x.encode() for x in IDS+CIDS]
for archive in sorted((ROOT/'docs/research-evidence/photo-prompt').rglob('*.tar.gz')):
 b=archive.read_bytes();archives.append({'path':str(archive.relative_to(ROOT)),'sha256':sha(b),'bytes':len(b)})
 with tarfile.open(archive) as tf:
  for m in tf:
   if not m.isfile() or Path(m.name).suffix not in text_suffixes:continue
   if m.size>8000000:skipped.append({'archive':str(archive.relative_to(ROOT)),'member':m.name,'reason':'text member above 8 MB; omitted generated snapshot inventory is not new behavior coverage'});continue
   data=tf.extractfile(m).read();found=[t.decode() for t in terms if t in data]
   if found:
    kind='archived candidate or profile occurrence; no owner-behavior qualification inferred'
    if any(k in m.name for k in ('source-snapshot','source_snapshot','snapshot/','rank','index')):kind='source/index/rank inventory overlap only'
    if m.name.endswith('.md'):kind='human-readable historical report occurrence; excerpt retained'
    row={'archive':str(archive.relative_to(ROOT)),'archive_sha256':sha(b),'member':m.name,'member_sha256':sha(data),'bytes':len(data),'ids':found,'coverage_kind':kind}
    if m.name.endswith('.md'):row['matching_lines']=[{'line':i,'text':l[:650]} for i,l in enumerate(data.decode(errors='replace').splitlines(),1) if any(t.decode() in l for t in terms)]
    archive_results.append(row)
dump('prior-coverage-archives.json',{'purpose':'deny novel-coverage claims for revalidation or collateral appearances; no exhaustive historical behavioral-coverage claim','archives_scanned':len(archives),'archives':archives,'matching_members':archive_results,'skipped_text_members':skipped})
# Preserve the all-four archived collateral resolver example separately, without treating it as a test here.
a='docs/research-evidence/photo-prompt/renewed-lighting-composition-boundaries-20261002/diagnostic-evidence.tar.gz';m='combined-full-resolver-diagnostic-enriched.json'
with tarfile.open(ROOT/a) as tf:d=json.load(tf.extractfile(m))
historical_hits=[]
def walk(o,path='$'):
 if isinstance(o,dict):
  if o.get('profile_id') in IDS:historical_hits.append({'json_path':path,'profile_id':o['profile_id'],'match_basis':o.get('match_basis'),'hard_eligible':o.get('hard_eligible'),'optional_eligible':o.get('optional_eligible')})
  for k,v in o.items():walk(v,path+'.'+k)
 elif isinstance(o,list):
  for i,v in enumerate(o):walk(v,path+f'[{i}]')
walk(d);dump('historical-collateral-classification.json',{'archive':a,'member':m,'interpretation':'All listed hits are archival advisory retrieval overlap, not proof of color-owner preservation or new hard activation. Scores intentionally omitted.','hits':historical_hits})
# One dated source snapshot establishes unchanged selected authored meaning, separate from behavior history.
oldbase='docs/research-evidence/photo-prompt/realistic-background-implementation-20260912/baseline/skills/photo-prompt-image-generator/assets/'
continuity=[]
for fn,key,ids in [('photo_prompt_visual_obligations_color_relations.json','profiles',IDS),('photo_prompt_color_relations_extension.json','slots',CIDS)]:
 p=ROOT/(oldbase+fn);old=json.loads(p.read_text());now=load('skills/photo-prompt-image-generator/assets/'+fn)
 if key=='profiles':oldrows={r['id']:r for r in old[key]};nowrows={r['id']:r for r in now[key]}
 else:oldrows={r['id']:r for es in old[key].values() for r in es};nowrows={r['id']:r for es in now[key].values() for r in es}
 for i in ids:continuity.append({'id':i,'historical_source':oldbase+fn,'historical_source_sha256':sha(p.read_bytes()),'row_unchanged':oldrows[i]==nowrows[i],'row_sha256':sha(json.dumps(nowrows[i],sort_keys=True,ensure_ascii=False,separators=(',',':')).encode())})
dump('revalidation-continuity.json',{'unique_new_coverage_claimed':0,'historical_source_comparison':continuity,'note':'Unchanged rows are historical meaning revalidation; old collateral/routing appearances are not full consumer or pixel qualification.'})
print(json.dumps({'profiles':len(profiles),'linked_candidates':len(candidates),'aligned':all(v is True for r in checks for k,v in r.items() if isinstance(v,bool)),'historical_rows_unchanged':sum(x['row_unchanged'] for x in continuity),'archive_count':len(archives),'archive_matching_members':len(archive_results),'skipped_text_members':len(skipped)},indent=2))
