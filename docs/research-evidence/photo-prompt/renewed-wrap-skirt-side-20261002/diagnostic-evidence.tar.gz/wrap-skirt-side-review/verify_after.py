import copy,hashlib,json,sys,subprocess
from pathlib import Path
sys.dont_write_bytecode=True
R=Path('REPOSITORY_ROOT');O=Path(__file__).parent;S=O.parent/'garment-closure-alternative-audit';A=R/'skills/photo-prompt-image-generator/assets';sys.path.insert(0,str(A.parent/'scripts'))
import prompt_generator as pg
import audit_composed_prompt as ac
D=S/'public-cli/after';E=O/'after-evidence';E.mkdir(exist_ok=True)
save=lambda p,x:p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n');load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
files=[*A.glob('*.json'),*(A.parent/'scripts').glob('*.py')];hashes={str(f):sha(f) for f in files}
reg=pg.load_visual_obligation_registry(A/'photo_prompt_visual_obligations.json');idx=pg.load_visual_profile_index(A/'photo_prompt_visual_profile_index.json',reg)
pid='wrap_skirt_overlap_closure';profile=pg.visual_obligation_profile_by_id(reg,pid);assert profile==load(O/'approved-profile.json')
oldidx=load(O.parent/'wrap-skirt-original-index.json');oldentries=oldidx['entries'];newentries=idx['entries'];assert oldentries.keys()==newentries.keys();changed=[k for k in oldentries if oldentries[k]!=newentries[k]];assert changed==[pid],changed
results=[]
for name,location in [('side-overlap','side'),('front-overlap-control','front')]:
 p=load(D/f'{name}-pack.json')[0];before=load(S/'public-cli/before'/f'{name}-pack.json')[0];core=p['authorial_core'];lock=core['intent_lock'];baseline=core['baseline_prompt_en'];ob=next(x for x in p['visual_obligations']['obligations'] if x['id']==pid)
 assert baseline==before['authorial_core']['baseline_prompt_en'];assert ob['evidence_requirements']==profile['evidence_requirements'];assert ob['component_semantics']==profile['semantics']['component_semantics'];assert ob['render_gates']==before['visual_obligations']['obligations'][0]['render_gates']
 evidence={
 'shared_waist_phrase':'On the adult’s wrap skirt, both skirt panels begin from one continuous waist construction, connected beneath the visible button.',
 'two_panel_edges_phrase':'Below that button, two separately traceable skirt panel edges remain visible with coherent thickness and gravity-led folds.',
 'diagonal_overlap_phrase':f'In the frozen three-quarter studio view, one panel crosses diagonally over the other across the skirt {location}, with continuous fabric boundaries clearly traceable.',
 'functional_fastening_phrase':'At this skirt waist, a visible waist tie button snap or buckle holds the overlap; here the actual fastening is the visible button joining both fabric panels.',
 'underpanel_confound_phrase':'Beneath the adult’s upper skirt-panel edge, the continuing under-panel proves a real wrap rather than a printed stripe or separate scarf, retaining its physical depth and connection to the same waist.'}
 for f,v in evidence.items():pg.validate_visual_intent_binding(obligation_index=0,field=f,phrase=v,requirement=profile['evidence_requirements'][f])
 prompt=baseline+' '+' '.join(evidence.values())
 c={'pack_id':p['pack_id'],'composer':'agent','prompt_en':prompt,'negative_en':p['negative_en'],'chosen_candidate_ids':[],'chosen_visual_concept_ids':[],'core_retrieval_sha256':p['core_retrieval']['canonical_sha256'],'visual_obligation_evidence':{pid:evidence},'authorial_core_binding':{'source_authorial_core_sha256':core['canonical_sha256'],'source_intent_lock_sha256':lock['canonical_sha256'],'preserved_anchor_ids':[a['anchor_id'] for a in lock['semantic_anchors']],'preserved_evidence':[a['prompt_evidence'] for a in lock['semantic_anchors']],'authorial_decisions':[]}}
 review=copy.deepcopy(p['embodiment_preflight']['baseline_review']);review['provenance']='agent_postcomposition';review['prompt_sha256']=hashlib.sha256(prompt.encode()).hexdigest();review['summary']='Text-only postcomposition review: the original single adult, planted feet, continuous relaxed arms and unobscured waist button remain unchanged. Added evidence describes the same frozen skirt-panel geometry and does not change pose, clothing, body ownership, reach, contact, support, or camera view. No pixel verification is claimed.'
 c['embodiment_review']={'source_contract_sha256':p['embodiment_preflight']['canonical_sha256'],'review':review}
 c['semantic_clarification_decisions']=[]
 for row in p['semantic_clarification']['candidates']:
  apply=row.get('required_in_final_prompt') is True or row.get('profile_id')==pid
  d={'clarification_id':row['id'],'decision':'applied' if apply else 'rejected','rationale':'Preserve the frozen adult, button fastening, continuous waist, actual skirt-panel overlap and three-quarter view.' if apply else 'This optional interpretation is unnecessary for the requested garment-construction scene and would add unrelated meaning.'}
  if apply:d['prompt_evidence']=baseline.split('. ')[0]+'.' if row.get('source')=='requester_meaning_bound_by_authorial_core' else evidence['diagonal_overlap_phrase']
  c['semantic_clarification_decisions'].append(d)
 c['creative_augmentation_brief']={'decisions':[{'candidate_id':row['id'],'decision':'rejected','rationale':'Retain the frozen adult, simple upper garment, button-fastened wrap skirt, original overlap location and three-quarter studio view without adding optional variations.'} for row in ac.creative_augmentation_candidates_from_pack(p)]}
 save(E/f'{name}-complete-composed.json',c)
 cmd=[sys.executable,str(A.parent/'scripts/audit_composed_prompt.py'),'--pack',str(D/f'{name}-pack.json'),'--composed',str(E/f'{name}-complete-composed.json')];run=subprocess.run(cmd,text=True,capture_output=True)
 (E/f'{name}-audit.stdout').write_text(run.stdout);(E/f'{name}-audit.stderr').write_text(run.stderr)
 result=json.loads(run.stdout);save(E/f'{name}-complete-audit.json',result)
 focused_before=ac.audit_visual_obligations(before,c,prompt);focused_after=ac.audit_visual_obligations(p,c,prompt)
 results.append({'case':name,'cli_command':cmd,'cli_exit':run.returncode,'status':result['status'],'failures':result['failures'],'warnings':result['warnings'],'before_visual_failures':focused_before,'after_visual_failures':focused_after,'baseline_preserved':prompt.startswith(baseline),'evidence_content_words':{k:len(ac.authorial_evidence_tokens(v)) for k,v in evidence.items()}})
 print(name,result['status'],result['failures'])
assert all(sha(Path(f))==h for f,h in hashes.items())
save(E/'full-composition-summary.json',results)
save(E/'source-verification.json',{'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'status':subprocess.check_output(['git','status','--short'],cwd=R,text=True),'reviewed_profile_equal_live':True,'index_validated_with_real_loader':True,'registry_sha256':pg.visual_profile_registry_sha256(reg),'index_registry_sha256':idx['registry_sha256'],'changed_index_entries':changed,'unchanged_index_entries':len(oldentries)-len(changed),'source_files_unchanged_during_review':len(hashes),'sha256':{str(x):sha(x) for x in [A/'photo_prompt_visual_obligations.json',A/'photo_prompt_visual_profile_index.json',*[D/f'{n}-pack.json' for n in ['side-overlap','front-overlap-control']]]}})
assert all(x['cli_exit']==0 and x['status']=='pass' for x in results),results
