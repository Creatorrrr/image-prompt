# Live integration and full composed-audit review

Approved integration verified. Both genuine normal public AFTER candidate packs pass the full production `audit_composed_prompt.py` CLI, exit 0, status pass, zero failures. This is a full composed audit, not only the focused visual-obligation helper. Logs, composed JSON, complete audit JSON, and measurements are in `after-evidence/`; the offline reproduction script is `verify_after.py`.

## Evidence and controls

The complete composed prompts retain each original baseline verbatim. The side case's overlap evidence says “across the skirt side”; the front control's evidence says “across the skirt front.” The five distinct scene-specific fields retain the frozen adult, visible button, shared waist, traceable fabric edges, under-panel, and three-quarter studio view. No new exposure, garment, pose, or camera requirement is introduced. The fastening field retains the exact existing anchor that lists all tie/button/snap/buckle options, then explicitly identifies the actual button already present in both frozen scenes.

The content-word counts in each case are 14 / 15 / 18 / 17 / 23, above the unchanged floors 9 / 8 / 10 / 10 / 12. The original review's four-closure acceptance and all-group omission controls still apply because the live profile is byte-equivalent in JSON values to the exact approved proposal. Both packs retain the full original render-gate array. The ten-word overlap floor is not reduced or bypassed.

Each full audit has three warnings explaining that original candidate-pack intents were preserved by free description/assertion. They are the adult, standing studio event, and scene-specific overlap anchor. There are no failures; no warnings have been hidden or labeled as absent.

The exact same complete evidence was additionally tested with the focused production visual-obligation audit against the genuine BEFORE packs: side fails solely for lacking the old front-only overlap anchor, front passes. Both pass against AFTER. These BEFORE comparisons are focused checks, not full BEFORE audit claims.

## Live source, index, and provider provenance

- Live profile equals `approved-profile.json` exactly
- Production registry/index loader validates the live source and index together
- Both report registry hash `9bf9bf63dedc8a88fb167b06d1ff17cf9ad8b9403e54bf8b946a8814945f190e`
- Only `wrap_skirt_overlap_closure` changes among 1,496 stored index entries; the remaining 1,495 entries are identical to the pre-refresh snapshot
- The successful provider ledger record matches the live semantic-text SHA-256; the corresponding cached actual vector equals the live index vector
- All 96 asset/script hashes remain stable during this review
- At review time, HEAD remains b85dcbca17156526e0a61b24e34a2c77829c06aa; the two expected source/index files are modified by the parent integration, and this reviewer made no repository edits or provider calls

The original Korean overlap component phrase was already location-neutral. The added Korean phrase explicitly locates the same diagonal physical overlap at the side; it does not change regional garment distinctions. The mandatory original English evidence was front-only, which is the demonstrated contract inconsistency.

The scout's public comparison establishes frozen-input equivalence and unchanged candidate collections. This independent review used those actual AFTER packs, separately verified exported profile evidence/components/gates against the live source, and ran full composition validation. No image was generated, so this establishes text/contract correctness, not rendered pixel quality.
