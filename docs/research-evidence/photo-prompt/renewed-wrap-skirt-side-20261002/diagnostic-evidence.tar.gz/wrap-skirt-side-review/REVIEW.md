# Independent review: approve exact two-array proposal

Decision: approve `approved-profile.json` without amendment. This is the exact proposed full profile, with exactly two append-only array changes recorded in `exact-approved-changes.json`. The review executed production consumers against in-memory copies only. Repository HEAD is b85dcbca17156526e0a61b24e34a2c77829c06aa and remains clean; 96 recorded source-file hashes match the public BEFORE snapshot. No repository edits, provider calls, generated vectors, images, or pixels were used.

## Construction and scope

The authoritative definition explicitly permits actual panels crossing over the skirt front **or side**. The added English and Korean alternatives retain one panel crossing diagonally over another. Korean 옆면 means the side surface; it does not introduce a slit, side exposure, pose, new garment, or a different fastening. The original Korean anchor is location-neutral, rather than explicitly front-only; because the matcher is literal, the new side-specific Korean sentence nevertheless needed its own alternative.

The complete original profile is preserved outside these appended alternatives. The stable `diagonal_front_overlap` ID stays unchanged. There are still five required component groups, a minimum of five matching groups, and five required evidence fields. Content-word floors remain 9 / 8 / 10 / 10 / 12. The original English front phrase and Korean neutral phrase remain unchanged. Tie, button, snap, and buckle all remain permitted. Waist continuity, two actual traceable panel edges, real diagonal crossing, functional fastening, continuing under-panel, print/slit/scarf controls, all five gate IDs, review scales, activation, runtime policy, and rejection substitutes remain unchanged.

The existing front-or-three-quarter viewing instruction and visibility duties remain intact. This adds no permission for a hidden side overlap. A visible lateral crossing in a three-quarter view is compatible with the existing instruction. The legacy concept candidate wording “diagonal front overlap” is not changed: the reviewed scope repairs accepted component and mandatory evidence alternatives, and does not promise equivalent semantic retrieval ranking.

No regional/traditional garment definitions, activations, or textile/closure requirements are edited. In particular, there is no broadening of qipao, kebaya/sarong, or tied-sarong profiles, nor any treatment of those garments as interchangeable. This is a generic wrap-skirt construction alternative already authorized by its definition.

## Measured consumer results

`review.py` is the reproducible offline review, and `measured-review.json` contains all 82 measured consumer rows.

- Four actual binding checks: front passes before and proposed; side fails before and passes proposed
- Sixteen actual composed visual-obligation audits: front passes before and proposed for each of tie/button/snap/buckle; side fails before only on its overlap anchor and passes proposed for each closure
- Eight full component-match checks: original English and Korean phrases retain eligibility; side-specific English/Korean constructions gain eligibility only with the proposal
- Forty component omission controls: omitting any of the five required groups yields no component match for either location/language under either profile
- Ten original confound controls: diagonal print, asymmetrical hem, isolated front slit, scarf over skirt, and hidden fastening each fail overlap binding and produce no component match before and proposed
- Two content-floor controls: the bare side anchor still fails the ten-content-word floor; adding an accepted anchor does not waive that floor
- Two composed negative controls: missing waist evidence and nonliteral side evidence still fail the actual audit

The composed-audit inputs explicitly choose no optional concepts, include the required safe “wrap skirt” label, and supply all five distinct evidence phrases literally in the prompt. They use the actual materializer with the full proposed profile, rather than bypassing the consumer or testing string counts alone. Closure controls preserve the pre-existing generic fastening anchor and identify each selected closure in additional descriptive text; they demonstrate retention of those alternatives, not new closure-specific lexical acceptance.

Confound controls establish rejection for isolated invalid constructions lacking the anchors. They do not claim that literal validators can infer visual truth or reject every adversarial contradiction appended to otherwise valid anchor text. Native render gates remain necessary.

## Genuine public BEFORE verification

Both frozen public CLI packs were inspected directly, checked against their recorded output hashes, and verified against all four input hashes and source hashes. Both are photo-candidate-pack/v6, exit 0 in the recorded normal public CLI runs, and contain only `wrap_skirt_overlap_closure` as the active obligation. Both export the old front-only English overlap evidence, even though the side case’s frozen request and baseline explicitly require side geometry. The original source and run manifests remain at `../garment-closure-alternative-audit/public-cli/`.

These are actual public BEFORE artifacts with frozen synthetic scene requests. This review did not rerun or label any in-memory proposed output as a public AFTER pack. They prove a text-contract inconsistency, not rendered-image performance.

## Integration requirements

Production semantic text and BM25F fields both change. Refresh the changed profile’s real positive vector through the established legitimate provider workflow and rebuild the normal derived index/provenance. Do not hand-edit vectors or fabricate embeddings. After integration, run the exact frozen public CLI inputs again, preserving their hashes, and check the emitted front-or-side evidence alternatives plus the original front controls. All image-quality or actual pixel claims remain untested.
