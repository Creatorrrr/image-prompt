import copy,hashlib,json,sys,subprocess
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path('/workspace/scratch/ce8f20680f5a'); R=ROOT/'image-prompt'; A=R/'skills/photo-prompt-image-generator/assets'; S=A.parent/'scripts'; O=Path(__file__).parent; I=O.parent/'garment-closure-alternative-audit'
sys.path.insert(0,str(S));import prompt_generator as pg;import audit_composed_prompt as ac
load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
save=lambda n,x:(O/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
before=load(I/'before-profile.json');after=load(I/'proposed-profile.json');reg=pg.load_visual_obligation_registry(A/'photo_prompt_visual_obligations.json');assert before==pg.visual_obligation_profile_by_id(reg,before['id'])
def diff(a,b,p=''):
 if a==b:return []
 if isinstance(a,dict) and isinstance(b,dict):
  assert a.keys()==b.keys();return sum([diff(a[k],b[k],p+'/'+k) for k in a],[])
 if isinstance(a,list) and isinstance(b,list) and len(a)==len(b):return sum([diff(x,y,p+'/'+str(i)) for i,(x,y) in enumerate(zip(a,b))],[])
 return [{'path':p,'before':a,'after':b}]
changes=diff(before,after);assert changes==load(I/'exact-changed-leaves.json');assert all(x['after'][:len(x['before'])]==x['before'] for x in changes)
source=load(I/'public-cli/before-source-manifest.json');assert all(sha(R/f)==h for f,h in source['sha256'].items())
packs={};public=[]
run=load(I/'public-cli/before/run-manifest.json')
for item in load(I/'public-cli/frozen-input-manifest.json'):
 case=item['case'];D=I/'public-cli/inputs'/case;assert all(sha(D/n)==h for n,h in item['inputs'].items());P=I/'public-cli/before'/f'{case}-pack.json';p=load(P)[0];packs[case]=p;row=next(x for x in run['cases'] if x['case']==case);assert sha(P)==row['output_sha256'];obs=p['visual_obligations']['obligations'];assert len(obs)==1
 assert obs[0]['evidence_requirements']==before['evidence_requirements'];assert obs[0]['component_semantics']==before['semantics']['component_semantics']
 public.append({'case':case,'pack_sha256':sha(P),'contract':p['contract_version'],'target':obs[0]['id'],'anchors':obs[0]['evidence_requirements']['diagonal_overlap_phrase']['must_mention_any'],'recorded_exit':row['exit_code'],'recorded_source_hashes_unchanged':row['source_hashes_unchanged'],'verified_input_hashes':True})
rows=[]
def binding(profile,field,phrase):
 try:pg.validate_visual_intent_binding(obligation_index=0,field=field,phrase=phrase,requirement=profile['evidence_requirements'][field]);return {'pass':True}
 except ValueError as e:return {'pass':False,'error':str(e)}
side='one panel crosses diagonally over the other across the skirt side';front=before['evidence_requirements']['diagonal_overlap_phrase']['must_mention_any'][0]
for name,profile in [('before',before),('proposed',after)]:
 for loc,anchor in [('front',front),('side',side)]:
  phrase=anchor+' with continuous fabric boundaries clearly traceable';result=binding(profile,'diagonal_overlap_phrase',phrase);assert result['pass']==(name=='proposed' or loc=='front');rows.append({'consumer':'binding','profile':name,'case':loc,**result})
  for closure in ['tie','button','snap','buckle']:
   evidence={f:req['must_mention_any'][0]+' maintaining coherent physical construction clearly observable' for f,req in profile['evidence_requirements'].items()};evidence['diagonal_overlap_phrase']=phrase;evidence['functional_fastening_phrase']+=f'; here the {closure} physically secures the waist'
   pack=copy.deepcopy(packs['side-overlap']);old=pack['visual_obligations']['obligations'][0];pack['visual_obligations']['obligations']=[pg.candidate_pack_visual_profile_obligation(profile,reg,activation_source=old['activation']['source'],source_intent_ids=old['activation']['source_intent_ids'])]
   composed={'chosen_visual_concept_ids':[], 'visual_obligation_evidence':{profile['id']:evidence}};prompt='wrap skirt. '+'. '.join(evidence.values());failures=ac.audit_visual_obligations(pack,composed,prompt);assert (not failures)==(name=='proposed' or loc=='front');assert not failures or all(x.get('field')=='diagonal_overlap_phrase' for x in failures)
   rows.append({'consumer':'actual composed visual-obligation audit; in-memory materialized obligation','profile':name,'case':loc+'-'+closure,'pass':not failures,'failures':failures})
 for lang,idx in [('English',0),('Korean',1)]:
  groups=profile['semantics']['component_semantics']['groups'];base=[g['any_terms'][idx] for g in groups]
  for loc in ['front','side']:
   terms=base.copy()
   if loc=='side':terms[2]=side if lang=='English' else after['semantics']['component_semantics']['groups'][2]['any_terms'][3]
   match=pg.candidate_pack_visual_component_match(profile,'. '.join(terms));rows.append({'consumer':'component match','profile':name,'language':lang,'case':loc,'match':match})
   for omit,g in enumerate(groups):
    result=pg.candidate_pack_visual_component_match(profile,'. '.join(t for j,t in enumerate(terms) if j!=omit));assert result is None,(name,lang,loc,g['id'],result)
    rows.append({'consumer':'component match','profile':name,'language':lang,'case':loc+'-missing-'+g['id'],'match':result})
 for text in before['semantics']['contrast_examples']:
  phrase=text+' with continuous visible textile boundaries and coherent physical construction surrounding the garment';result=binding(profile,'diagonal_overlap_phrase',phrase);assert not result['pass'];assert pg.candidate_pack_visual_component_match(profile,text) is None;rows.append({'consumer':'binding and component match','profile':name,'case':text,**result})
 result=binding(profile,'diagonal_overlap_phrase',side);assert not result['pass'];rows.append({'consumer':'content-word floor','profile':name,'case':'bare side anchor','content_words':len(pg.visual_intent_evidence_tokens(side)),**result})
# Composition checks still enforce literalness and exact field inventory; gate data is unchanged.
profile=after;pack=copy.deepcopy(packs['side-overlap']);old=pack['visual_obligations']['obligations'][0];pack['visual_obligations']['obligations']=[pg.candidate_pack_visual_profile_obligation(profile,reg,activation_source=old['activation']['source'],source_intent_ids=old['activation']['source_intent_ids'])]
evidence={f:req['must_mention_any'][0]+' maintaining coherent physical construction clearly observable' for f,req in profile['evidence_requirements'].items()};evidence['diagonal_overlap_phrase']=side+' with continuous fabric boundaries clearly traceable'
for case in ['missing-waist-field','nonliteral-side-evidence']:
 p=copy.deepcopy(pack);e=copy.deepcopy(evidence);prompt='wrap skirt. '+'. '.join(e.values())
 if case=='missing-waist-field':del e['shared_waist_phrase']
 elif case=='nonliteral-side-evidence':prompt=prompt.replace(e['diagonal_overlap_phrase'],'')
 failures=ac.audit_visual_obligations(p,{'chosen_visual_concept_ids':[], 'visual_obligation_evidence':{profile['id']:e}},prompt);assert failures;rows.append({'consumer':'composed audit negative control','profile':'proposed','case':case,'pass':False,'failures':failures})
assert all(sha(R/f)==h for f,h in source['sha256'].items());status=subprocess.check_output(['git','status','--short'],cwd=R,text=True);assert not status
save('approved-profile.json',after);save('exact-approved-changes.json',changes);save('measured-review.json',{'decision':'approve exact proposed two-array append-only profile without amendments','repository_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'repository_status':status,'source_files_verified_unchanged':len(source['sha256']),'public_before_packs':public,'consumer_controls':rows,'positive_semantic_text_changed':pg.visual_profile_semantic_text(before)!=pg.visual_profile_semantic_text(after),'bm25f_fields_changed':pg.visual_profile_bm25f_fields(before)!=pg.visual_profile_bm25f_fields(after),'approved_profile_sha256':sha(O/'approved-profile.json')})
print(json.dumps({'decision':'approved','controls':len(rows),'source_files_unchanged':len(source['sha256']),'component_full_controls':[x for x in rows if x['consumer']=='component match' and '-missing-' not in x['case']]},ensure_ascii=False,indent=2))
