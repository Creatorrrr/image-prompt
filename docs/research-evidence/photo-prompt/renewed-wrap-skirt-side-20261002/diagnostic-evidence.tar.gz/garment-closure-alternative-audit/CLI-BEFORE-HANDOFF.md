# Exact proposal and frozen public BEFORE handoff

Completed 2026-10-02 on b85dcbca. Repository clean before and after; every recorded source hash unchanged during both commands. No source edits, provider calls, or vector fabrication.

## Results

| Frozen synthetic regression case | Public CLI exit | Contract | Target obligation | Emitted overlap evidence |
|---|---:|---|---|---|
| side-overlap | 0 | photo-candidate-pack/v6 | wrap_skirt_overlap_closure | front-only |
| front-overlap-control | 0 | photo-candidate-pack/v6 | wrap_skirt_overlap_closure | front-only |

The side case requests a visible button fastening and real overlap across the skirt side. Its baseline preserves that request. The actual normal public CLI nevertheless exports the front-only required anchor. The front control uses an otherwise matching request and scene with front overlap. No binding was injected to force or suppress the target obligation. Both route to only the target profile. These results prove exported contract mismatch, not image-generation or pixel performance.

## Exact source proposal

`before-profile.json` and `proposed-profile.json` hold full source profiles. `exact-changed-leaves.json` identifies exactly two append-only arrays:

1. `/semantics/component_semantics/groups/2/any_terms` (group ID remains `diagonal_front_overlap`): append English “one panel crosses diagonally over the other across the skirt side” and Korean “한 판이 다른 판 위를 스커트 옆면에서 사선으로 가로질러 겹침”
2. `/evidence_requirements/diagonal_overlap_phrase/must_mention_any`: append the same English side-overlap anchor

Original front English/Korean terms and evidence remain byte-for-byte. All IDs, scales, min_content_words, component count, required fields, closure choices, gates, composition instruction, activation, and rejection conditions are unchanged. No extra garment or pose constraint is introduced by the proposal. Test fixture scene choices are confined to frozen inputs.

## Vector impact, measured

`semantic-text-impact.json`, `semantic-text-before.txt`, and `semantic-text-proposed.txt` contain actual production `visual_profile_semantic_text` outputs and hashes. The positive semantic text changes because component any_terms participates in the positive prototype; production BM25F fields also change. Thus a genuine vector refresh for this one changed profile is needed if accepted, plus normal derived index/source provenance rebuild. No provider call was made here.

## Reproduction artifacts

- `prepare_public_before.py`: authored the append-only proposal and frozen test inputs
- `run_public_before.py`: ran normal `generate_photo_prompt.py` CLI with the four contracts, seed 708, and output file
- `public-cli/inputs/{side-overlap,front-overlap-control}/`: immutable request-envelope, authorial-core, creative-controls, embodiment-review JSON inputs
- `public-cli/frozen-input-manifest.json`: all input hashes
- `public-cli/before-source-manifest.json`: HEAD, clean status, all top-level asset JSON and script Python source hashes
- `public-cli/before/run-manifest.json`: exact commands, return codes, source-hash stability, output hashes, and extracted target obligations
- `public-cli/before/*-pack.json`: complete actual candidate packs
- `public-cli/before/*.stdout` and `*.stderr`: command logs
- `consumer-controls.json`: earlier direct consumer control, front passes / side fails / side with proposed in-memory anchor passes, distinct from these normal CLI results

Recommended independent review: verify two-array append-only diff, source-definition front-or-side permission, preservation of all former alternatives/controls, semantic-text refresh requirement, and public BEFORE mismatch. After integration with legitimate index refresh, rerun these exact frozen inputs without authoring new inputs or changing hashes.
