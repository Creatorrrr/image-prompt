import json,hashlib
from pathlib import Path
O=Path(__file__).parent;P=O/'public-cli';D=O/'public-comparison';D.mkdir(exist_ok=True)
load=lambda p:json.loads(p.read_text())
save=lambda p,x:p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def delta(a,b,path=''):
 if type(a)!=type(b):return [{'path':path,'before':a,'after':b}]
 if isinstance(a,dict):
  out=[]
  for k in sorted(set(a)|set(b)):
   if k not in a:out.append({'path':path+'/'+k,'added':b[k]})
   elif k not in b:out.append({'path':path+'/'+k,'removed':a[k]})
   else:out+=delta(a[k],b[k],path+'/'+k)
  return out
 if isinstance(a,list):
  if len(a)!=len(b):return [] if a==b else [{'path':path,'before':a,'after':b}]
  return [r for i,(aa,bb) in enumerate(zip(a,b)) for r in delta(aa,bb,path+'/'+str(i))]
 return [] if a==b else [{'path':path,'before':a,'after':b}]
def collections(v,path=''):
 found={}
 if isinstance(v,dict):
  for k,w in v.items():
   q=path+'/'+k
   if isinstance(w,list) and ('candidate' in k or ('candidate' in path and all(isinstance(r,dict) and 'id' in r for r in w))):found[q]=w
   else:found.update(collections(w,q))
 elif isinstance(v,list):
  for i,w in enumerate(v):found.update(collections(w,path+'/'+str(i)))
 return found
runs=[load(P/k/'run-manifest.json') for k in ['before','after']]
assert len(runs[1]['cases'])==2 and all(r['exit_code']==0 and r['source_hashes_unchanged'] for r in runs[1]['cases'])
summary=[]
for c in load(P/'frozen-input-manifest.json'):
 case=c['case'];a=load(P/'before'/(case+'-pack.json'))[0];b=load(P/'after'/(case+'-pack.json'))[0]
 for n,h in c['inputs'].items():assert hashlib.sha256((P/'inputs'/case/n).read_bytes()).hexdigest()==h
 ca,cb=collections(a),collections(b);inventory=[]
 for path in sorted(set(ca)|set(cb)):
  aa,bb=ca.get(path,[]),cb.get(path,[])
  row={'path':path,'before_count':len(aa),'after_count':len(bb),'equal':aa==bb}
  if all(isinstance(r,dict) and 'id' in r for r in aa+bb):
   ia=[r['id'] for r in aa];ib=[r['id'] for r in bb];ma={r['id']:r for r in aa};mb={r['id']:r for r in bb}
   row.update(before_ids=ia,after_ids=ib,id_order_equal=ia==ib,added=[r for r in bb if r['id'] not in ma],removed=[r for r in aa if r['id'] not in mb],changed=[{'id':i,'leaves':delta(ma[i],mb[i])} for i in sorted(ma.keys()&mb.keys()) if ma[i]!=mb[i]])
  elif aa!=bb:row.update(before=aa,after=bb)
  inventory.append(row)
 diffs=delta(a,b);hard=delta(a.get('visual_obligations'),b.get('visual_obligations'))
 save(D/(case+'-full-pack-differences.json'),diffs);save(D/(case+'-candidate-inventory.json'),inventory);save(D/(case+'-hard-contract-differences.json'),hard)
 summary.append({'case':case,'candidate_collection_count':len(inventory),'candidate_ids_order_counts_equal':all(r['before_count']==r['after_count'] and r.get('id_order_equal',True) for r in inventory),'changed_candidate_collections':len([r for r in inventory if not r['equal']]),'changed_candidate_records':sum(len(r.get('changed',[])) for r in inventory),'added_candidates':sum(len(r.get('added',[])) for r in inventory),'removed_candidates':sum(len(r.get('removed',[])) for r in inventory),'full_changed_leaf_count':len(diffs),'hard_contract_changed_leaf_count':len(hard),'full_changed_paths':[d['path'] for d in diffs]})
save(D/'summary.json',{'before_source':runs[0]['source_manifest'],'after_source':runs[1]['source_manifest'],'cases':summary})
print(json.dumps(summary,indent=2))
