# Garment closure / strap / overlap alternative audit

Read-only scout, 2026-10-02, repository HEAD observed b85dcbca. No repository edits, provider calls, vector/index fabrication, image generation, or large snapshots. Artifacts live outside the repository. Excluded active ghost/boubou/repair leaves and previous hand/prop/light/capture repairs.

## Recommendation: one minimal data fix

**Profile:** `wrap_skirt_overlap_closure`

**Authoritative file:** `skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations.json`, `profiles[id=wrap_skirt_overlap_closure]` (all paths in this report are relative to image-prompt unless specified).

**Internal source inconsistency:** `semantics.definition` explicitly permits two panels crossing “over the front or side.” Yet `semantics.component_semantics.groups[id=diagonal_front_overlap].any_terms[0]` says “one panel crosses diagonally over the other across the skirt front,” and that same sentence is the sole accepted anchor in the mandatory `evidence_requirements.diagonal_overlap_phrase.must_mention_any`. `required_evidence_fields` includes that field. Thus an otherwise identical explicitly side-crossing construction cannot satisfy the accepted evidence without incorrectly asserting front geometry.

**Minimal repair proposal:** retain the existing front anchor and add “one panel crosses diagonally over the other across the skirt side” to both the component group's any_terms and evidence requirement's must_mention_any. Retain identifiers, component counts, evidence word threshold, waist continuity, actual panel edges, under-panel continuation, and all print/slit/scarf confounds. No closure taxonomy change. The render gate `vo_summer_wrap_skirt_diagonal_overlap` already says only “One panel visibly crosses diagonally over a continuing under-panel,” so it needs no alteration. The composition permits front or three-quarter view; do not loosen the visibility requirement for a hidden side.

**Source provenance:** `docs/research-evidence/photo-prompt/womens-summer-trends-20260901/source-research.md`, profile matrix row (line 31), describes the system without a front-only restriction. `docs/research-evidence/photo-prompt/research_evidence.jsonl` record `summer_kr_29cm_wrap_capri_layer_2026` (line 402) links https://www.29cm.co.kr/content/brand-event/2026/06/01/amomento and records two panel edges, overlap, and functional fastening, with retail-editorial limitations. This audit does not claim that source establishes a universal skirt taxonomy, and did not reopen the external page; the repair is justified by the repository's own explicit front-or-side definition.

**Actual consumer impact:**
- `scripts/prompt_generator.py::validate_visual_intent_binding` (around lines 6741–6776) rejects a binding unless one declared anchor occurs literally.
- `scripts/prompt_generator.py::candidate_pack_visual_profile_obligation` (around lines 7337–7400) exports evidence requirements and render gates unchanged into the public obligation. Executed against this profile: `side-wrap-public-obligation.json` records the relevant actual output.
- `scripts/audit_composed_prompt.py` (around lines 1800–1813) independently checks profile anchors and records missing-anchor failures.
- `consumer-controls.json` records actual validator execution: front passes, side fails, side passes after only adding its counterpart anchor to an in-memory requirement. No mutation was made to the repository.

**Follow-through if accepted:** add focused regression coverage for side-overlap obligation and binding acceptance while preserving front acceptance and confound rejection. Rebuild or refresh any required derived profile-index provenance by the project's established real-vector workflow; do not hand-edit vectors or substitute fake embeddings. No rendered-image quality gain is claimed by this scout.

## Keep / defer

- KEEP `wrap_front_overlap_closure`: definition, component/evidence clauses, composition, and `vo_garment_wrap_functional_fastening` all preserve side tie, button, or fixed seam. No source inconsistency found.
- KEEP `wrap_skirt_overlap_closure` closure options: tie, button, snap, or buckle survive semantics, evidence, and native gate. Its optional hand-near-tie composition example does not require a tie, so is not a repair target.
- KEEP `kebaya_front_open_blouse_sarong_system` fastening: buttons and linked kerongsang brooches are both represented in evidence anchors and render gate. Executed both actual evidence bindings: both pass.
- KEEP `sw_wetsuit` in `photo_prompt_visual_obligations_swimwear.json`: zipper or overlapping opening remains in selected definition, evidence, component instruction, and gate.
- KEEP `pfe_halter` in `photo_prompt_visual_obligations_portrait_fashion_exposure.json`: strap or fabric band remains in selected definition and rendered relation. Do not infer a mandatory thin strap from the general word “strap joins.”
- KEEP deliberately narrow authored qipao frog-closure, racerback Y-convergence, and tied sarong variants. There is no internal alternative warranting broader taxonomy changes.
- DEFER adjacent textile mismatch in kebaya: its definition permits fine lightweight cloth and says lace/translucency are supportive; required `embroidered_surface_phrase` only accepts embroidered or lace wording. Actual fine-lightweight-cloth binding fails (recorded in controls). Source provenance: `traditional-clothing-20260831/source-research.md:29` and `traditional-clothing-20260831/evidence.jsonl` record `traditional_clothing_unesco_kebaya`, linked to https://ich.unesco.org/en/RL/kebaya-knowledge-skills-traditions-and-practices-02090. The native textile gate already allows fine cloth weave or another finished edge treatment. This is a real adjacent evidence mismatch, but outside the requested closure/strap/overlap priority; route separately only if desired, preserving regional limits and existing ensemble obligations.
