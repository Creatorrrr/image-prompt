# Actual public AFTER result

Both frozen normal public CLI cases completed successfully against the parent's approved source/index update. The actual source profile exactly equals `proposed-profile.json`. Input hashes match the BEFORE freeze, seed remains 708, and all observed source hashes remain stable across execution. No source edits or provider calls were made by this worker.

- side-overlap: exit 0, photo-candidate-pack/v6, wrap_skirt_overlap_closure emitted
- front-overlap-control: exit 0, photo-candidate-pack/v6, wrap_skirt_overlap_closure emitted

## Complete-pack comparison

For each case, recursive comparison of the entire BEFORE and AFTER pack yields exactly three changed paths:

1. `/pack_id`
2. `/visual_obligations/obligations/0/component_semantics/groups/2/any_terms`
3. `/visual_obligations/obligations/0/evidence_requirements/diagonal_overlap_phrase/must_mention_any`

Paths 2 and 3 contain only the approved appended side alternatives. Original front English/Korean component entries and original English evidence remain intact. All other complete-pack content is identical, including scene/core content, exposure/pose requirements, gates, scales, floors, closure alternatives, and required evidence fields.

All 29 candidate collections in each pack are byte-identical as parsed JSON; counts, IDs, and ordering remain identical. Zero added, removed, or changed candidate records.

## Artifacts

- `public-cli/after/run-manifest.json`: commands, return codes, exact source/input/output hashes, extracted target obligations
- `public-cli/after/{side-overlap,front-overlap-control}-pack.json`: actual full packs
- `public-comparison/summary.json`: complete comparison summary
- `public-comparison/*-full-pack-differences.json`: all complete-pack differences
- `public-comparison/*-candidate-inventory.json`: all candidate collections with count and ID-order checks
- `public-comparison/*-hard-contract-differences.json`: isolated obligation delta

The actual AFTER packs and results were sent to `review_wrap_skirt_side_overlap` for independent complete evidence/audit checks. This result establishes public contract correction and candidate invariance, not image or pixel quality.
