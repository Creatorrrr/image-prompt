import copy,hashlib,json,sys,subprocess
from pathlib import Path
sys.dont_write_bytecode=True
R=Path('REPOSITORY_ROOT'); O=Path(__file__).parent; S=O.parent/'portrait-narrative-audit'; A=R/'skills/photo-prompt-image-generator/assets';sys.path.insert(0,str(A.parent/'scripts'))
import prompt_generator as pg
import audit_composed_prompt as audit
old=json.loads((S/'before-profile.json').read_text());new=json.loads((S/'proposed-profile.json').read_text());reg=pg.load_visual_obligation_registry(A/'photo_prompt_visual_obligations.json');assert pg.visual_obligation_profile_by_id(reg,new['id'])==old
rows=[]
def record(label,b,a,expected):
 rows.append({'case':label,'before':b,'after':a,'expected_after':expected,'pass':a==expected})
def match(p,s):return pg.candidate_pack_visual_component_match(p,s)
groups=new['semantics']['component_semantics']['groups'];f='overhead_foreshortening_phrase'
for lang in [0,1]:
 for branch in ['prop','hand']:
  terms=[g['any_terms'][lang+(2 if i==3 and branch=='hand' else 0)] for i,g in enumerate(groups)]
  full='; '.join(terms)
  record(f'component-{lang}-{branch}',match(old,full),match(new,full),'component_semantics')
  for i,g in enumerate(groups):
   text='; '.join(x for j,x in enumerate(terms) if j!=i)
   record(f'missing-{lang}-{branch}-{g["id"]}',match(old,text),match(new,text),None)
  for exclusion in new['activation']['exclude_if_any_terms']:
   text=full+'; '+exclusion
   record(f'exclusion-{lang}-{branch}-{exclusion}',match(old,text),match(new,text),None)
for text in ['near hand','head torso limbs and near hand are coherent','an empty hand near the camera','head torso limbs and one near hand follow coherent top-down foreshortening',new['semantics']['paraphrase_examples'][0]]:
 record('incomplete-component:'+text,match(old,text),match(new,text),'semantic_paraphrase_example' if text==new['semantics']['paraphrase_examples'][0] else None)
def binding(p,text):
 try:pg.validate_visual_intent_binding(obligation_index=0,field=f,phrase=text,requirement=p['evidence_requirements'][f]);return True
 except ValueError:return False
anchors=new['evidence_requirements'][f]['must_mention_any']
for i,text in enumerate(anchors):
 record('bare-anchor-floor-'+str(i),binding(old,text),binding(new,text),False)
 record('complete-binding-'+str(i),binding(old,text+' toward the elevated lens'),binding(new,text+' toward the elevated lens'),True)
for text in [groups[3]['any_terms'][1],groups[3]['any_terms'][3],'near hand',anchors[1].replace('head torso limbs and ',''),anchors[1].replace(' and scale change',''), 'One near hand is enlarged above the coherent adult body on a paved floor beside the subject']:
 record('invalid-binding:'+text,binding(old,text),binding(new,text),False)
base=json.loads((S/'public-cli/before/near-hand-no-prop-pack.json').read_text())[0]
def measured(p,branch,missing=None,nonliteral=False):
 pack=copy.deepcopy(base);ob=pack['visual_obligations']['obligations'][0]
 pack['visual_obligations']['obligations'][0]=pg.candidate_pack_visual_profile_obligation(p,reg,activation_source=ob['activation']['source'],source_intent_ids=ob['activation']['source_intent_ids'])
 evidence={k:v['must_mention_any'][0] for k,v in p['evidence_requirements'].items()}
 evidence[f]=anchors[0 if branch=='prop' else 1]+' toward the elevated lens'
 # Exact source anchors alone are below some existing floors: add concrete same-component details.
 evidence['overhead_camera_phrase']+=' above the paved plaza'
 evidence['overhead_ground_phrase']+=' across visible paving stones'
 evidence['overhead_response_phrase']+=' with chin tilted upward'
 prompt='. '.join(evidence.values())+'.'
 if missing:del evidence[missing]
 if nonliteral:prompt=prompt.replace(anchors[1],'The nearby hand is enlarged coherently.')
 failures=audit.audit_visual_obligations(pack,{'chosen_visual_concept_ids':[],'visual_obligation_evidence':{p['id']:evidence}},prompt)
 return failures
for branch in ['hand','prop']:
 b=measured(old,branch);a=measured(new,branch);record('real-audit-'+branch,len(b),len(a),0)
 for field in new['required_evidence_fields']:
  b=measured(old,branch,field);a=measured(new,branch,field);record('real-audit-missing-'+branch+'-'+field,bool(b),bool(a),True)
record('real-audit-nonliteral-hand',bool(measured(old,'hand',nonliteral=True)),bool(measured(new,'hand',nonliteral=True)),True)
# Structural scope and additive compatibility checks.
changes=json.loads((S/'exact-changed-leaves.json').read_text()); actual=[]
def diff(a,b,path=''):
 if type(a)!=type(b):actual.append(path)
 elif isinstance(a,dict):
  for k in sorted(a.keys()|b.keys()):diff(a.get(k),b.get(k),path+'/'+k)
 elif isinstance(a,list) and len(a)==len(b):
  for i,(x,y) in enumerate(zip(a,b)):diff(x,y,path+'/'+str(i))
 elif a!=b:actual.append(path)
diff(old,new);assert sorted(actual)==sorted(x['path'] for x in changes)
for leaf in ['activation','required_evidence_fields','reject_substitutes','runtime_expression','concept_candidate']:assert old[leaf]==new[leaf]
assert [(g['id'],g['review_scale']) for g in old['render_gates']]==[(g['id'],g['review_scale']) for g in new['render_gates']]
assert {k:v['min_content_words'] for k,v in old['evidence_requirements'].items()}=={k:v['min_content_words'] for k,v in new['evidence_requirements'].items()}
assert new['semantics']['component_semantics']['groups'][3]['any_terms'][:2]==old['semantics']['component_semantics']['groups'][3]['any_terms']
for name in ['proposed-profile.json','exact-changed-leaves.json']:(O/('reviewed-'+name)).write_bytes((S/name).read_bytes())
report={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'repo_status':subprocess.check_output(['git','status','--short'],cwd=R,text=True),'reviewed_source_sha256':{x:hashlib.sha256((S/x).read_bytes()).hexdigest() for x in ['proposed-profile.json','exact-changed-leaves.json']},'changed_paths':actual,'controls':rows,'summary':{'total':len(rows),'passed':sum(x['pass'] for x in rows)}}
(O/'measured-controls.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps(report['summary']));print(json.dumps([x for x in rows if not x['pass']],ensure_ascii=False,indent=2));print('hand audit',measured(new,'hand'))
