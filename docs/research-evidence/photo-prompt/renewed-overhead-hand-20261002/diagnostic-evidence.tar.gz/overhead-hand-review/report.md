# Independent overhead-hand proposal review

## Verdict
APPROVE the exact four-leaf DATA proposal for the current overhead profile, subject to the normal real-index update and public end-to-end release checks. No repository edits, paid/provider calls, generated embeddings, fake vectors, or renders were performed. This review is consumer-contract evidence, not pixel verification or a semantic-index publication approval.

Reviewed immutable copies: `reviewed-proposed-profile.json` and `reviewed-exact-changed-leaves.json`. SHA-256 and repository HEAD are in `measured-controls.json`. Current source matched the supplied before-profile exactly; repository status remained clean at review.

## Source and scope
The current profile definition explicitly says “enlarged near hand or prop”; its first paraphrase uses a raised hand as near anchor. The public tag embedding text likewise says “near raised hands or props enlarge coherently.” Thus allowing an empty near hand is already current authored intent. The four mandatory projection surfaces previously narrowed that alternative to a prop.

Historical nuance: `docs/research-evidence/photo-prompt/korean-emotional-photo-semantics-20260902/source-research.md`, hard-profile §2, itself lists a near prop. Do not claim unanimous historical provenance or that the history already explicitly allowed the hand. The correction is justified by current definition, paraphrase, and tag agreement.

Only four paths differ:
- `/composition_instruction`
- `/evidence_requirements/overhead_foreshortening_phrase/must_mention_any`
- `/render_gates/3/description`
- `/semantics/component_semantics/groups/3/any_terms`

The old English/Korean prop component alternatives are retained verbatim and the English prop evidence anchor remains first. Korean evidence has never been an accepted evidence anchor here; Korean remains a component-discovery path, and the proposal does not silently invent Korean evidence support. Added Korean hand wording faithfully substitutes 손 for 소품.

All five group IDs, minimum group count, required groups, render gate IDs/scales, evidence fields/floors, exact activation/exclusions, adult scope, reject substitutes, concept candidate, and runtime expression remain unchanged. No face-occlusion record is included or edited. No extra hand count, fingers, ownership, joint arrangement, visible-face requirement, occlusion prohibition, or held-object requirement is added. “One near hand” is the supported near-anchor count, not a one-hand anatomy limit. Right-hand, left-hand, standing pose, and uncovered-face details exist only in frozen scene fixtures, not the DATA proposal.

## Measured controls
`review.py` imports the actual repository `prompt_generator` and `audit_composed_prompt` consumers, uses the real loaded registry, and projects the proposed profile in memory only. `measured-controls.json` contains all 72 controls; all passed.

- Complete English and Korean prop components still match; complete hand components gain the intended match
- Removing any one of five groups prevents complete component matching in both languages and both branches
- Every existing exclusion blocks all four complete combinations
- Incomplete/short hand descriptions do not create complete component matches; the existing full paraphrase stays a soft paraphrase match
- Both bare full anchors have 12 unique content words and fail the preserved 13-word floor; extending them with concrete near-camera context passes. This existing floor is intentionally not lowered
- Complete prop evidence passes actual composed-obligation audit before and after; complete hand evidence fails the old prop anchor and passes the proposed hand anchor
- Omitting any of the five evidence fields still fails real audit for both branches; nonliteral hand evidence still fails
- Korean-only evidence anchors, shortened phrases, and a long but non-anchor paraphrase remain rejected

The measured real audit uses the frozen public-CLI before pack as the base and the real `candidate_pack_visual_profile_obligation` projector for the reviewed profile. This is a scoped in-memory consumer test, not a claim to have run an after-public-CLI pack against a rebuilt index. Existing public CLI before artifacts confirm the prop-only hard instruction is emitted for both hand and prop requests. No source/index hashes were fabricated or bypassed.

## Remaining release checks
Regenerate/validate real affected index data through the approved workflow, compare frozen raw-contract before/after CLI outputs, and run relevant repository tests. Neither strict substring evidence acceptance nor this review proves image anatomy, occlusion, or geometry; render gates retain that visual-review role. Existing soft paraphrase recognition is not a hard-activation bypass and was left untouched.

## Applied-source / genuine AFTER follow-through

The exact reviewed profile is now present in the working tree. The real visual-index loader validates the actual source/index pair. Index comparison independently confirms 1496 entries, only `overhead_social_snapshot_relation` changed (text, text SHA-256, vector), 1495 entries byte-equivalent as JSON values, and unchanged exact lookup, provider, model, and dimensions. This establishes update scope and loader integrity; provider provenance is supplied by the parent's refresh run, not inferred from vector values.

Both genuine public CLI AFTER packs from `portrait-narrative-audit/public-cli/after` passed the **full `audit_composed_prompt.py` CLI**, not just the focused visual audit. Each command exited 0 with zero failures. Complete composed artifacts and stdout/stderr are saved under `after-evidence/`; hashes and source verification are recorded there.

The original baseline is preserved verbatim as the prompt prefix in each case. Each added evidence phrase describes the same standing adult, upward response, surrounding pavement, and coherent projection. The hand case preserves the empty raised right hand and visible left hand; its new evidence contains no prop/card/object term. The prop case keeps its existing held blank card and English prop anchor. The composition adds no objects, pose changes, face-occlusion requirements, or anatomy counts.

Actual content-word counts (camera / ground / response / foreshortening / boundary) are 14 / 15 / 15 / 20 / 24 for the hand scene and 14 / 15 / 15 / 21 / 24 for the prop scene. All existing floors remain unchanged, including the 13-word foreshortening floor.

A cross-check of exactly the same complete evidence against genuine BEFORE contracts yields the intended single failure for hand evidence (missing mandatory prop anchor), while prop evidence passes both before and after. AFTER focused visual failures are zero for both.

Each full audit reports three quality warnings for candidate-pack uncovered intents being preserved through free description/assertion (subject, upward response, elevated-camera geometry). These are disclosed; full contract status is `pass`, quality status is `warn`. The prompts preserve those scene anchors literally. No render, pixel, or physical plausibility result is claimed.

Primary applied verification files:
- `after-evidence/source-verification.json`
- `after-evidence/index-entry-comparison.json`
- `after-evidence/full-composition-summary.json`
- `after-evidence/near-hand-no-prop-complete-composed.json`
- `after-evidence/near-hand-no-prop-complete-audit.json`
- `after-evidence/near-prop-control-complete-composed.json`
- `after-evidence/near-prop-control-complete-audit.json`
- `verify_after.py` reproduces the complete-authoring and actual auditor-CLI run

Historical provenance nuance above remains unchanged. Review work made no repository edits or paid calls.
