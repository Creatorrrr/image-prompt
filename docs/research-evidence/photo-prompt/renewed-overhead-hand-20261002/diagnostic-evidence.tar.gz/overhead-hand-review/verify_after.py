import copy,hashlib,json,sys,subprocess
from pathlib import Path
sys.dont_write_bytecode=True
R=Path('REPOSITORY_ROOT');O=Path(__file__).parent;S=O.parent/'portrait-narrative-audit';A=R/'skills/photo-prompt-image-generator/assets';sys.path.insert(0,str(A.parent/'scripts'))
import prompt_generator as pg
import audit_composed_prompt as ac
D=Path(sys.argv[1]);E=O/'after-evidence';E.mkdir(exist_ok=True)
save=lambda p,x:p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
reg=pg.load_visual_obligation_registry(A/'photo_prompt_visual_obligations.json');idx=pg.load_visual_profile_index(A/'photo_prompt_visual_profile_index.json',reg)
pid='overhead_social_snapshot_relation';profile=pg.visual_obligation_profile_by_id(reg,pid);assert profile==json.loads((O/'reviewed-proposed-profile.json').read_text())
results=[]
for name in ['near-hand-no-prop','near-prop-control']:
 p=json.loads((D/f'{name}-pack.json').read_text())[0];before=json.loads((S/'public-cli/before'/f'{name}-pack.json').read_text())[0];core=p['authorial_core'];lock=core['intent_lock'];baseline=core['baseline_prompt_en'];hand=name=='near-hand-no-prop';branch='hand' if hand else 'prop';ob=next(x for x in p['visual_obligations']['obligations'] if x['id']==pid)
 assert baseline==before['authorial_core']['baseline_prompt_en']
 assert ob['evidence_requirements']==profile['evidence_requirements']
 evidence={
 'overhead_camera_phrase':'Above the standing adult on the paved plaza, the camera is visibly close above one clearly adult subject and points steeply downward.',
 'overhead_ground_phrase':'Paving remains visible around the standing figure: a readable ground or floor plane surrounds the subject and anchors the vertical separation.',
 'overhead_response_phrase':"The adult tilts the chin upward toward the lens: the subject's face gaze or raised hand responds toward the elevated camera position.",
 'overhead_foreshortening_phrase':('The empty open right hand is nearest the lens above the standing adult: ' if hand else 'The blank card remains gripped nearest the lens above the standing adult: ')+f'head torso limbs and one near {branch} follow coherent top-down foreshortening and scale change.',
 'overhead_boundary_phrase':'The standing figure and surrounding paving form one consistent view: the nearby elevated camera ground plane upward subject response and coherent body foreshortening jointly establish the close overhead relation.'}
 prompt=baseline+' '+' '.join(evidence.values())
 c={'pack_id':p['pack_id'],'composer':'agent','prompt_en':prompt,'negative_en':p['negative_en'],'chosen_candidate_ids':[],'chosen_visual_concept_ids':[],'core_retrieval_sha256':p['core_retrieval']['canonical_sha256'],'visual_obligation_evidence':{pid:evidence},'authorial_core_binding':{'source_authorial_core_sha256':core['canonical_sha256'],'source_intent_lock_sha256':lock['canonical_sha256'],'preserved_anchor_ids':[a['anchor_id'] for a in lock['semantic_anchors']],'preserved_evidence':[a['prompt_evidence'] for a in lock['semantic_anchors']],'authorial_decisions':[]}}
 review=copy.deepcopy(p['embodiment_preflight']['baseline_review']);review['provenance']='agent_postcomposition';review['prompt_sha256']=hashlib.sha256(prompt.encode()).hexdigest();review['summary']='Text-only postcomposition plausibility review: the original standing adult, continuous raised right-arm chain, planted feet, upward gaze, visible left hand, and near anchor remain unchanged. Added evidence explains the same elevated viewpoint and scale relations. This is not pixel or kinematic verification.'
 c['embodiment_review']={'source_contract_sha256':p['embodiment_preflight']['canonical_sha256'],'review':review}
 c['semantic_clarification_decisions']=[]
 for row in p['semantic_clarification']['candidates']:
  apply=row.get('required_in_final_prompt') is True or row.get('profile_id')==pid
  d={'clarification_id':row['id'],'decision':'applied' if apply else 'rejected','rationale':'Preserve the frozen adult, paved plaza, upward response and close overhead geometry.' if apply else 'This optional interpretation is unnecessary for the requested overhead scene and would add unrelated meaning.'}
  if apply:d['prompt_evidence']=baseline.split('. ')[0]+'.' if row.get('source')=='requester_meaning_bound_by_authorial_core' else evidence['overhead_camera_phrase']
  c['semantic_clarification_decisions'].append(d)
 c['creative_augmentation_brief']={'decisions':[{'candidate_id':row['id'],'decision':'rejected','rationale':'Retain the frozen overhead viewpoint, subject action, near anchor and surrounding pavement without adding optional variations.'} for row in ac.creative_augmentation_candidates_from_pack(p)]}
 save(E/f'{name}-complete-composed.json',c)
 cmd=[str(R/'.venv/bin/python'),str(A.parent/'scripts/audit_composed_prompt.py'),'--pack',str(D/f'{name}-pack.json'),'--composed',str(E/f'{name}-complete-composed.json')];run=subprocess.run(cmd,text=True,capture_output=True)
 (E/f'{name}-audit.stdout').write_text(run.stdout);(E/f'{name}-audit.stderr').write_text(run.stderr)
 result=json.loads(run.stdout);save(E/f'{name}-complete-audit.json',result)
 # Cross-check exactly the same visual evidence against genuine pre-change contract.
 focused_before=ac.audit_visual_obligations(before,c,prompt);focused_after=ac.audit_visual_obligations(p,c,prompt)
 results.append({'case':name,'cli_command':cmd,'cli_exit':run.returncode,'status':result['status'],'failures':result['failures'],'warnings':result['warnings'],'before_visual_failures':focused_before,'after_visual_failures':focused_after,'baseline_preserved':prompt.startswith(baseline),'evidence_content_words':{k:len(ac.authorial_evidence_tokens(v)) for k,v in evidence.items()},'new_prop_terms_in_hand_evidence': [t for t in ['prop','card','object'] if hand and t in ' '.join(evidence.values()).lower()]})
 print(name,result['status'],result['failures'])
save(E/'full-composition-summary.json',results)
save(E/'source-verification.json',{'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'status':subprocess.check_output(['git','status','--short'],cwd=R,text=True),'reviewed_profile_equal_live':True,'index_validated_with_real_loader':True,'registry_sha256':pg.visual_profile_registry_sha256(reg),'index_registry_sha256':idx['registry_sha256'],'sha256':{str(x):hashlib.sha256(x.read_bytes()).hexdigest() for x in [A/'photo_prompt_visual_obligations.json',A/'photo_prompt_visual_profile_index.json',*[D/f'{n}-pack.json' for n in ['near-hand-no-prop','near-prop-control']]]}})
