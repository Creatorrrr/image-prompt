# Public CLI BEFORE and minimal proposal

This is the new normal public CLI stage, distinct from the earlier resolver/materializer-only probe. Both raw four-contract cases ran generate_photo_prompt.py against the unchanged hash-checked real repository index. No provider calls or image renders occurred.

## near-hand-no-prop
- CLI exit: 0; contract: photo-candidate-pack/v6; all recorded source hashes unchanged: True
- Hard profile: overhead_social_snapshot_relation
- Mandatory foreshortening evidence: ['head torso limbs and one near prop follow coherent top-down foreshortening and scale change']
- Output SHA-256: 82b3dbe33af0e4747c2bbb511efc97fda14f21300b233c637b4eca2bdb0c1f2d

## near-prop-control
- CLI exit: 0; contract: photo-candidate-pack/v6; all recorded source hashes unchanged: True
- Hard profile: overhead_social_snapshot_relation
- Mandatory foreshortening evidence: ['head torso limbs and one near prop follow coherent top-down foreshortening and scale change']
- Output SHA-256: 30bb3b656051d7b01b4abd94dac0f856de9d2dc1c0673c78dc940ba4feb260da

## Independent review inputs
- proposed-profile.json: complete proposed overhead profile
- exact-changed-leaves.json: four changed leaf values, with exact old/new content
- before-profile.json: exact original profile
- public-cli/inputs/: frozen raw request envelope, authorial core, creative controls, and embodiment review for each case
- public-cli/frozen-input-manifest.json: raw-input hashes and seeds
- public-cli/before-source-manifest.json: HEAD, dirty status, asset/script hashes
- public-cli/before/: full emitted packs, commands, stdout/stderr, output hashes and projected target obligations

The near-hand/no-prop case still receives a mandatory near-prop requirement before repair; the existing near-prop control receives the same contract. This establishes user-facing candidate-pack contract contamination; it does not claim composed-prompt audit or pixel validation.

## Minimal proposal boundary
Exactly four leaves change. The component any_terms appends one English and one Korean near-hand alternative; evidence must_mention_any appends the matching English alternative. Both old EN/KO component entries and the old evidence entry remain byte-for-byte. Instruction and foreshortening gate use hand-or-prop. All IDs, other groups, group requirements, adult/exclusion scope, definition, examples, labels, and numeric constraints remain unchanged. Face-occlusion is untouched. No change has been applied to repository assets.
