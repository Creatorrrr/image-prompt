import json,sys,hashlib,copy,subprocess
from pathlib import Path
sys.dont_write_bytecode=True
O=Path(__file__).parent;R=Path('REPOSITORY_ROOT');P=O/'public-cli';P.mkdir(exist_ok=True)
A=R/'skills/photo-prompt-image-generator/assets';sys.path.insert(0,str(A.parent/'scripts'));import prompt_generator as pg
save=lambda p,x:(p.parent.mkdir(parents=True,exist_ok=True),p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n'))
sha=lambda s:hashlib.sha256(s.encode()).hexdigest()
reg=pg.load_visual_obligation_registry(A/'photo_prompt_visual_obligations.json');pg.load_visual_profile_index(A/'photo_prompt_visual_profile_index.json',reg)
old=next(x for x in reg['profiles'] if x['id']=='overhead_social_snapshot_relation');new=copy.deepcopy(old)
group=next(x for x in new['semantics']['component_semantics']['groups'] if x['id']=='overhead_foreshortening')
group['any_terms'] += ['head torso limbs and one near hand follow coherent top-down foreshortening and scale change','머리 몸통 팔다리와 가까운 손이 일관된 탑다운 단축과 크기 변화를 따름']
new['evidence_requirements']['overhead_foreshortening_phrase']['must_mention_any'].append(group['any_terms'][-2])
new['composition_instruction']=new['composition_instruction'].replace('the body and a near prop','the body and a near hand or prop')
for g in new['render_gates']:
 if g['id']=='vo_social_overhead_coherent_foreshortening':g['description']=g['description'].replace('one near prop','one near hand or prop')
def diff(a,b,path=''):
 if type(a)!=type(b):return [{'path':path,'before':a,'after':b}]
 if isinstance(a,dict):return [r for k in a.keys()|b.keys() for r in diff(a.get(k),b.get(k),path+'/'+k)]
 if isinstance(a,list):
  if len(a)!=len(b):return [{'path':path,'before':a,'after':b}]
  return [r for i,(x,y) in enumerate(zip(a,b)) for r in diff(x,y,path+'/'+str(i))]
 return [] if a==b else [{'path':path,'before':a,'after':b}]
save(O/'proposed-profile.json',new);save(O/'exact-changed-leaves.json',diff(old,new));save(O/'before-profile.json',old)
base0='One clearly adult person stands steadily on a paved plaza with both feet planted beneath the body. A close camera above the person points steeply downward, keeping a readable floor plane around the entire figure. The adult tilts the head upward and looks toward the elevated lens. The right upper arm rises from its own shoulder, the elbow bends comfortably, and the forearm extends toward the camera with a relaxed wrist. '
base1='The empty open right hand is nearest the lens and appears larger than the head and torso below it. The left hand hangs visibly beside the hip, and neither hand holds an object. '
base2='The right hand holds one blank rectangular card between the thumb and fingers, maintaining visible contact without covering the face. The card is nearest the lens and appears larger than the head and torso below it. The left hand hangs visibly beside the hip. '
base3='Head, torso and limbs show coherent top-down foreshortening with continuous joints and believable relative scale. Soft daylight gives the shirt, skin and pavement consistent illumination. Open framing includes the raised hand, the full adult figure and nearby paving with no disconnected limb or isolated stretched body part.'
manifest=[]
scaffold=json.loads((O.parent/'reflection-material-audit/public-cli/inputs/matte-soft/authorial-core.json').read_text())
for case,detail,base in [('near-hand-no-prop','an empty raised hand nearest the lens and no held props',base0+base1+base3),('near-prop-control','a blank card held nearest the lens',base0+base2+base3)]:
 req='Photograph one clearly adult person with a close overhead social-snapshot relation on a paved plaza, looking up toward the nearby elevated camera, with '+detail+'. Preserve coherent top-down foreshortening and the surrounding ground plane.'
 subject='One clearly adult person';event='looks upward while raising the right hand toward the camera'
 d=P/'inputs'/case
 envraw={'contract_version':'photo-request-envelope/v1','provenance':'requesting_user','request_id':'overhead-ownership-'+case,'request_text':req,'request_sha256':sha(req),'active_spans':[{'span_id':'scene','start':0,'end':len(req),'text':req}]};env=pg.normalize_request_envelope(envraw)
 ctl=pg.creative_controls.resolve(req,overrides={'sensual':0,'fetish':0,'creativity':1,'surreal':0},seed=706)
 core=copy.deepcopy(scaffold)
 core.update(source_request=req,creative_controls_sha256=ctl['canonical_sha256'],interpreted_intent=req,subject=subject,setting='an open paved plaza in daylight',event=event,visual_priorities=[subject,event,'coherent near-to-far scale and readable ground plane'],baseline_prompt_en=base,interpretation_provenance=[{'term':'governing request','source_text':req,'basis':'request_context','resolution':req,'sources':[]}],style={'domain':'general_photo','family':'close overhead adult social portrait','evidence':['elevated camera','surrounding ground plane']},variation_key='overhead-ownership-'+case)
 core['intent_lock']['semantic_anchors']=[{'anchor_id':'subject','source_text':req,'dimension':'subject','prompt_evidence':subject},{'anchor_id':'event','source_text':req,'dimension':'event','prompt_evidence':'The adult tilts the head upward and looks toward the elevated lens.'},{'anchor_id':'concept','source_text':req,'dimension':'concept','prompt_evidence':'A close camera above the person points steeply downward, keeping a readable floor plane around the entire figure.'}]
 core['intent_lock']['open_dimensions']=['lighting','color','atmosphere']
 norm=pg.normalize_authorial_core(core,request_envelope=env,creative_control_snapshot=ctl)
 evidence={'body_ownership':('All visible limbs belong to one adult with explicit continuous joints.','Head, torso and limbs show coherent top-down foreshortening with continuous joints and believable relative scale.'),'joint_chain_and_reach':('Shoulder, upper arm, elbow, forearm and wrist form a plausible relaxed raised-arm chain.','The right upper arm rises from its own shoulder, the elbow bends comfortably, and the forearm extends toward the camera with a relaxed wrist.'),'support_and_balance':('Both feet support the upright body on the plaza.','One clearly adult person stands steadily on a paved plaza with both feet planted beneath the body.'),'contact_and_space':('The raised hand is empty and the arms remain independently positioned.' if case=='near-hand-no-prop' else 'The card is gripped between thumb and fingers with visible contact clear of the face.','The left hand hangs visibly beside the hip, and neither hand holds an object.' if case=='near-hand-no-prop' else 'The right hand holds one blank rectangular card between the thumb and fingers, maintaining visible contact without covering the face.'),'visibility_and_projection':('The near anchor is enlarged consistently with the close elevated camera, keeping the adult and floor legible.','The empty open right hand is nearest the lens and appears larger than the head and torso below it.' if case=='near-hand-no-prop' else 'The card is nearest the lens and appears larger than the head and torso below it.')}
 review={'contract_version':'photo-embodiment-review/v1','provenance':'agent_prepack','prompt_sha256':sha(base),'scope':'body_action','summary':'Text-only plausibility review of one standing adult raising a hand toward an overhead camera; this is not pixel or kinematic proof.','checks':{k:{'status':'supported','reason':v[0],'prompt_evidence':[v[1]]} for k,v in evidence.items()}}
 pg.photo_embodiment.build_policy(norm,review)
 for name,x in [('request-envelope',envraw),('authorial-core',core),('creative-controls',ctl),('embodiment-review',review)]:save(d/(name+'.json'),x)
 manifest.append({'case':case,'target_profile':old['id'],'seed':706,'inputs':{f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(d.glob('*.json'))}})
save(P/'frozen-input-manifest.json',manifest)
files=[A/'photo_prompt_visual_obligations.json',A/'photo_prompt_visual_profile_index.json',A/'photo_prompt_tags.json',A/'photo_prompt_semantic_index.json',*(A.parent/'scripts').glob('*.py')]
save(P/'before-source-manifest.json',{'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'status':subprocess.check_output(['git','status','--short'],cwd=R,text=True),'execution':'normal public CLI against live stable source; raw four contracts; no repository mutations or provider calls','sha256':{str(f.relative_to(R)):hashlib.sha256(f.read_bytes()).hexdigest() for f in files}})
print('Frozen two raw four-contract cases; proposed profile changed leaves:',len(diff(old,new)))
