import json,sys,hashlib,subprocess
from pathlib import Path
ROOT=Path('REPOSITORY_ROOT')
OUT=Path(__file__).parent
sys.path.insert(0,str(ROOT/'skills/photo-prompt-image-generator/scripts'))
import prompt_generator as pg
assets=ROOT/'skills/photo-prompt-image-generator/assets'
registry=pg.load_visual_obligation_registry(assets/'photo_prompt_visual_obligations.json')
index=json.load(open(assets/'photo_prompt_visual_profile_index.json'))
data={pg.VISUAL_OBLIGATIONS_DATA_KEY:registry,pg.VISUAL_PROFILE_INDEX_DATA_KEY:index}
cases={
'face_korean_generic':'성인 인물의 얼굴 안 보이는 감성샷. 긴 머리카락이 눈과 코를 가리고 창가에 조용히 서 있다.',
'face_english_exact':'An adult intentional face-occluded mood portrait: long hair covers the eyes and nose as the person stands quietly by a window.',
'face_english_generic':'An adult face-hidden mood portrait: long hair covers the eyes and nose as the person stands quietly by a window.',
'overhead_korean_prop_free':'성인 인물 항공샷. 가까운 상공 카메라를 올려다보며 양손을 펴고 서 있는 성인과 주변 바닥, 일관된 탑다운 단축.',
'overhead_exact_prop_free':'A close overhead social-snapshot relation with one adult standing on pavement, looking up at the nearby high camera, both empty hands visible, coherent foreshortening across head torso and limbs.',
'overhead_near_hand_positive':'A close overhead social-snapshot relation: an adult looks up toward the close elevated camera on a paved plaza; one empty raised hand is nearest the lens and appears coherently enlarged, with head torso and limbs consistently foreshortened and the ground surrounding the figure.',
'overhead_near_prop_control':'A close overhead social-snapshot relation: an adult looks up toward the close elevated camera on a paved plaza; one raised blank card is nearest the lens and appears coherently enlarged, with head torso and limbs consistently foreshortened and the ground surrounding the figure.',
'private_generic':'An adult portrait in a private bedroom, softly lit by a curtained window, quietly sitting on a chair.',
'private_authored':'A soft-window private-room adult portrait with an adult adjusting a shirt cuff next to a curtained window in a bedroom.',
}
rows=[]
for label,text in cases.items():
 result={'provenance':{'concept_lock':[text]}}
 resolution=pg.candidate_pack_resolve_visual_profiles(data,result,{},None)
 contract=pg.candidate_pack_visual_obligations(data,result,{},None,resolution)
 rows.append({'case':label,'request':text,'resolution':resolution,'contract':contract})
(OUT/'public-projection.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
selected=['intentional_face_occluded_mood_portrait','overhead_social_snapshot_relation','soft_window_private_room_adult_portrait','companion_viewpoint_everyday_candid','peak_action_event_phase']
(OUT/'profile-snapshots.json').write_text(json.dumps([p for p in registry['profiles'] if p['id'] in selected],ensure_ascii=False,indent=2)+'\n')
(OUT/'manifest.json').write_text(json.dumps({'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'files':{f:hashlib.sha256((assets/f).read_bytes()).hexdigest() for f in ['photo_prompt_visual_obligations.json','photo_prompt_visual_profile_index.json','photo_prompt_tags.json']},'mode':'read-only, existing real index, no model/provider calls'},indent=2)+'\n')
for row in rows:
 print(row['case'],[(h['profile_id'],h['match_basis'],h['hard_eligible']) for h in row['resolution']['hits']], [(p['id'],p['composition_instruction']) for p in (row['contract'] or {}).get('obligations',[])])
