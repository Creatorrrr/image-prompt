# Portrait/composition narrative scope audit

## Decision
Recommend **one DATA correction**, `overhead_social_snapshot_relation`: preserve the authored **near hand OR prop** alternative across its mandatory foreshortening surfaces. Defer changing face-occlusion narrative; its provenance explicitly authors that requirement, so a failed natural probe alone is insufficient authority to weaken it.

No repository edits, providers, paid calls, generated embeddings, fake vectors, or image renders. Read-only exact-request resolution used the repository's real visual index and normal `candidate_pack_resolve_visual_profiles` → `candidate_pack_visual_obligations` path. Evidence records contract behavior, not pixel success.

## 1. Strong correction: near-hand alternative is lost in overhead projection

Source: `skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations.json`, profile `overhead_social_snapshot_relation`.

The authored definition allows an “enlarged near hand or prop”. Its first paraphrase explicitly uses “one raised hand” as the near anchor. The public candidate in `photo_prompt_tags.json`, camera_direction slot, says “near raised hands or props enlarge coherently”. Its label/aliases ask for close overhead geometry, a readable floor, and upward subject response; they do not request a separate object.

Yet four hard-contract surfaces demand a prop:
- `semantics.component_semantics.groups[overhead_foreshortening].any_terms`: English and Korean both require head, torso, limbs AND a near prop
- `composition_instruction`: ends with scale changes across the body AND a near prop
- `evidence_requirements.overhead_foreshortening_phrase.must_mention_any`: mandatory English literal requires “one near prop”
- `render_gates[vo_social_overhead_coherent_foreshortening].description`: body parts AND one near prop

`public-projection.json` freezes a prop-free positive with an empty raised hand nearest the lens, and a near-prop control with a raised blank card. Both exact-route to this hard profile and receive the same prop-mandatory contract. Thus the near-hand scene loses an alternative the definition already grants; fixing that mismatch does not broaden to every overhead photograph or remove scene geometry.

### Bounded correction specification

Preserve profile ID, aliases, adult scope, all five group IDs, group count, gates, evidence field IDs, exclusions, close elevated camera, readable floor, upward response, and coherent head/torso/limb scale. Align the four surfaces above to **one near hand or prop**. Keep existing old English/Korean component alternatives and old evidence alternatives verbatim if the repository's accepted additive-alternative pattern requires backward compatibility; add the matching hand branch rather than delete prop evidence. Ensure composition instruction and gate express the disjunction, and retain existing near-prop paraphrase examples.

Do not introduce lexical request exceptions or contextual branches for particular probe sentences. Determine index and semantic-vector refresh requirements through the established DATA workflow; this read-only scout does not assert that fingerprint changes alone are sufficient or authorize fabricated vectors.

Suggested verification: frozen near-hand positive accepts coherent body + near-hand perspective; near-prop control remains valid; empty floor, drone distance, eye-level crop, isolated limb stretching, absent upward response still cannot satisfy all existing geometry groups. Re-run existing Korean emotional semantics and boundary suites, noting their archived external reference-image tests may have environment dependencies.

## 2. Face occlusion: confirmed broad alias inheritance, but defer semantic weakening

`얼굴 안 보이는 감성샷` and `얼굴 가린 감성 사진` are exact hard aliases for `intentional_face_occluded_mood_portrait`. The generic English candidate alias `face-hidden mood portrait` is NOT an exact hard alias. Frozen public projections show a static adult with hair covering eyes/nose standing quietly by a window hard-activates in Korean; an English formal profile term does too; the generic English alias does not.

The projected hard contract requires a concrete unfinished task in instruction, action-setting component, literal evidence, and render gate. The English boundary component also repeats that task, while the Korean boundary is only an exclusion statement. That multilingual asymmetry merits awareness, but is not an independent recommendation here.

Provenance: `docs/research-evidence/photo-prompt/korean-emotional-photo-semantics-20260902/source-research.md`, hard-profile section 3, explicitly defines concrete unfinished action plus identifiable setting as one of five necessary relations. The frozen greenhouse arm deliberately performs a seed-envelope action. Therefore this is authored style intent, not a clearly accidental projection-only addition.

The source ledger entry `korean_emotional_cvpr_still_action_components_2020` cites Girish et al. for still-image action legibility, explicitly admitting it does not define Korean aesthetic language. Primary paper abstract confirms its scope is recognizing actions, considering object-involving actions. That paper cannot establish that all face-hidden mood portraits require a task. The semantic risk is an overbroad Korean alias naming an intentionally narrower authored contract, not proof the narrow contract should lose its narrative.

Recommendation: leave the task requirement intact in this bounded change. A later scope decision could narrow exact aliases or split generic occlusion from the authored action-setting style, preserving the legacy contract. Such routing taxonomy changes need deliberate product intent and real index handling; no phrase-specific bypass.

Primary source checked: https://openaccess.thecvf.com/content_CVPRW_2020/papers/w23/Girish_Understanding_Action_Recognition_in_Still_Images_CVPRW_2020_paper.pdf . HTML page returned 403; official CVF PDF search result exposed the abstract. No empirical claim about broad Korean usage is made.

## Other controls rejected as corrections

- `soft_window_private_room_adult_portrait` explicitly defines dressing/grooming/room action and contrast-excludes passive reclining. Generic softly window-lit bedroom portrait did not hard-activate; only the formal authored style did. Preserve.
- `companion_viewpoint_everyday_candid` deliberately calls for an everyday task plus glance/offer/handoff toward an off-camera companion position. Exact aliases are narrowly companion-framed. No strong generic spillover established.
- `peak_action_event_phase` explicitly means decisive unfinished action; its event requirement is integral.
- General composition profiles inspected (thirds, central anchor, symmetry, counterbalance, lines, look/motion room, negative space, framing, depth, pattern break, figure-ground hierarchy) impose compositional relations rather than unrelated narrative events. No second strong correction identified.

## Files

- `probe.py`: reproducible offline public path
- `public-projection.json`: complete resolution and projected contracts for nine frozen requests
- `profile-snapshots.json`: five selected profile records
- `manifest.json`: source HEAD and asset SHA-256 at capture
- `probe-summary.txt`: terse exact-route/mandatory-instruction output
