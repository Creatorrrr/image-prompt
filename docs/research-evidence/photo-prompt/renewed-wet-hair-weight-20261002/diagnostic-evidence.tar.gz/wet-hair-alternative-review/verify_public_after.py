import json,hashlib,sys,subprocess,os
from pathlib import Path
O=Path(__file__).parent;S=O.parent/'hair-material-alternative-audit';P=S/'public-cli';R=Path('REPOSITORY_ROOT');load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=load(P/'after/run-manifest.json');assert len(manifest['cases'])==5
for f,h in manifest['source_manifest']['sha256'].items():assert sha(R/f)==h
out=[]
for row in manifest['cases']:
 case=row['case'];assert row['exit_code']==0 and row['source_hashes_unchanged'];packpath=P/'after'/f'{case}-pack.json';assert sha(packpath)==row['output_sha256']
 for f,h in row['input_sha256'].items():assert sha(P/'inputs'/case/f)==h
 a=load(P/'before'/f'{case}-pack.json')[0];b=load(packpath)[0];cpath=S/'after-evidence'/f'{case}-complete-composed.json';c=load(cpath)
 assert a['authorial_core']==b['authorial_core'] and c['prompt_en'].startswith(a['authorial_core']['baseline_prompt_en'])
 positive=case in ['weighted-without-contact','adhered-damp-control']
 if not positive:assert a==b and not b.get('visual_obligations',{}).get('obligations',[])
 else:
  aa=json.loads(json.dumps(a));aa['pack_id']=b['pack_id'];aa['visual_obligations']=b['visual_obligations'];assert aa==b
  assert [x['id'] for x in b['visual_obligations']['obligations']]==['wet_damp_clumped_hair_state']
 cmd=[sys.executable,str(R/'skills/photo-prompt-image-generator/scripts/audit_composed_prompt.py'),'--pack',str(packpath),'--composed',str(cpath)];r=subprocess.run(cmd,text=True,capture_output=True,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'});audit=json.loads(r.stdout);assert r.returncode==0 and audit['status']=='pass' and not audit['failures'];(O/f'{case}-independent-full-audit.json').write_text(json.dumps(audit,indent=2)+'\n');out.append({'case':case,'pack_hash_verified':True,'inputs_verified':True,'core_unchanged':True,'independent_full_cli_audit':'pass','warnings':audit['warnings']})
for f,h in manifest['source_manifest']['sha256'].items():assert sha(R/f)==h
(O/'after-public-verification.json').write_text(json.dumps(out,indent=2)+'\n');print('Five public packs independently verified; five full composed CLI audits rerun and passed; 96 source hashes unchanged')
