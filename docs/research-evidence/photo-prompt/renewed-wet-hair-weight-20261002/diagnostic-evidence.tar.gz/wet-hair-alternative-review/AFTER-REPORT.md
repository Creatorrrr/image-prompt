# Applied wet-hair patch: independent verification

Source/index checks pass at baseline HEAD 6c3296384dae4b01812b7c63f4f4f8f9d4ed3c31. The applied registry differs from HEAD by exactly the approved five leaves. All other registry content is structurally identical, not merely all other profile IDs.

The actual visual-profile index loads against the changed registry. Exactly wet_damp_clumped_hair_state changes; all 1,495 other entries are identical to wet-hair-original-index.json. The new vector differs from the old vector and equals the new cache entry keyed by SHA256 of actual semantic text: be2573d1d114c72970d4d7064caadd6b0dfb8c5605f6618af15ad6e72ab70f01. Ledger has exactly one matching cycle attempt, succeeded, with conservative USD 0.0016384 reservation. This verifies repository/cache/ledger consistency; this reviewer did not make or observe the provider request directly.

Original candidate/tag file, contact pixel fixture and existing hair test file are byte-identical to HEAD. No source edits, provider requests, fabricated vectors or images were made by this reviewer. No pixel-success improvement is claimed.

Machine-readable evidence: after-source-index-verification.json.

## Public pack comparison

All five frozen-input AFTER public CLI runs exited successfully. Independently checked output hashes, frozen input hashes and preserved authorial cores. Contact and noncontact positive packs differ from BEFORE only by pack_id and the five approved obligation leaves; dry gravity, glossy hair and gel negative packs are entirely identical, with no wet-hair obligation. Scout's full structural comparison reports all 144 candidate collections unchanged, with zero additions, removals, reordering or record changes. The negatives' successful composed audits mean their original dry/style requests remain valid, not that they qualify as wet hair.

The complete compositions retain the original baseline verbatim, bind the same authorial core, use the safe runtime label and satisfy all five fields on the positive cases. Actual BEFORE materialized obligation still rejects noncontact specifically at weighted_adherence_phrase; AFTER accepts it. Contact remains accepted. The textual full audits retain uncovered-intent warnings for freely described original content; they are not warning-free or image verification.

Independent full composed CLI rerun complete: 5/5 pass, zero failures. Per-case outputs are saved as *-independent-full-audit.json and summarized in after-public-verification.json; verify_public_after.py reproduces the checks. All 96 AFTER source-manifest hashes remained unchanged during these checks. Final decision: APPROVE applied source/index and textual public-contract evidence, with mixed historical provenance and absent pixel validation explicitly retained.
