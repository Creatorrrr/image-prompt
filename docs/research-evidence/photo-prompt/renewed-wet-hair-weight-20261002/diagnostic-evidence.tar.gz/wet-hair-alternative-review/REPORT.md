# Independent wet-hair alternative review

Decision: APPROVE exactly the five leaves in ../hair-material-alternative-audit/exact-changed-leaves.json. This is approval of a data-contract correction, not empirical pixel success or embedding refresh.

## Source judgment

The profile in original commit 1e589e8a95574918a5c4fd7c02051ebeeede7423 equals the current HEAD profile byte-for-value after JSON decoding. Its definition explicitly permits “directional weight or local adherence”; its weighted-bundle paraphrase and “weighted downward sections” concept term support a noncontact branch. Its identifier, category, English/Korean candidate labels, and exact activation phrases describe wet/damp clumped state rather than a named surface-contact scenario. Therefore the mandatory contact in anchors, composition and gate prose is a contradictory restriction of an authored alternative, rather than convincing evidence that this is a deliberately contact-only profile.

Provenance is mixed, not unanimous. The original candidate embedding and keywords require localized face/neck adherence. The hair-arm-e fixture chooses weighted local adherence. The optical-confound research ledger mentions adherence; the bundle-mechanics ledger supports clumping/collapse/weighted bundles and states its limits. These are genuine narrower contact evidence, not proof of the new branch. Keep the candidate, original fixture, research records and existing tests unchanged; they remain valid contact realizations. No external papers were freshly fetched or claimed to establish a universal wetness criterion.

## Approved minimal boundary

Append only “moisture pulls selected damp bundles downward into weighted sections” to the weighted_adherence group's any_terms and weighted_adherence_phrase's must_mention_any. Change composition to weighted behavior OR local adherence. Change only weighted-adherence and moisture-coherence gate descriptions to honor the selected branch. The exact proposed wording is approved.

Preserve all five mandatory groups, fields and gates; minimum content lengths; activation terms; definition; contrast/reject guards; contact anchors; other components; runtime expression. The existing spatially coherent moisture alternative already avoids unnecessary contact. Generic gravity-hanging hair is not the admitted relation: the new anchor explicitly demands moisture, damp bundles and weighted sections, alongside reduced volume, bundling, coherence and gloss-confound evidence.

This global alternative must not be used to waive an explicit user request or a scenario-specific contact requirement. The original contact fixture continues to require its observable contact success signal. The textual consumers do not establish actual pixels, and literal anchor acceptance is not a physical wetness classifier.

## Independent checks

review.py loads the actual registry and real consumers, independently replays the exact five changes, verifies equality to the supplied proposal, and compares original/current profile. It passes 42 cases covering validate_visual_intent_binding, candidate_pack_visual_component_match and audit_composed_prompt.audit_visual_obligations with real materialized obligations. controls.json records all outcomes.

Both contact and noncontact have positive composed evidence; noncontact fails before and passes proposed. Dry gravity, gloss, gel and wet-label-only substitutions fail binding and component completion. Every missing component fails. Missing bundling and nonliteral evidence fail composed audit. Gate materialization remains exact.

Harness adjustments during development: bare contact anchor fell below its existing content-word minimum, so the test adds visible contact patches; composed prompt explicitly supplies the safe runtime label to avoid an unrelated label-plus-definition failure. Neither required a proposal change. No source edits, vectors, images or provider calls were made.

Original hair test suite: 8 existing tests passed in 49.945 seconds on the unchanged source registry. The one existing synthetic-embedding test was intentionally excluded because this task forbids fabricated vectors. Tests and fixture were not edited. Concurrent work changed git status during this review; status-before.txt and status-after.txt retain the observations. The target registry hash was directly verified unchanged by the independent harness.
