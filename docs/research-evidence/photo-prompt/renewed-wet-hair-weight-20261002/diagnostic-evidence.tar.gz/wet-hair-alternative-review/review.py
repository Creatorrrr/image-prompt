import sys,json,copy,hashlib,subprocess,unittest
from pathlib import Path
sys.dont_write_bytecode=True
R=Path('REPOSITORY_ROOT'); O=Path(__file__).parent; A=R/'skills/photo-prompt-image-generator/assets'
sys.path.insert(0,str(A.parent/'scripts')); import prompt_generator as pg; import audit_composed_prompt as ac
src=A/'photo_prompt_visual_obligations.json'; sha=hashlib.sha256(src.read_bytes()).hexdigest(); reg=pg.load_visual_obligation_registry(src)
b=pg.visual_obligation_profile_by_id(reg,'wet_damp_clumped_hair_state'); p=json.loads((O.parent/'hair-material-alternative-audit/proposed-profile.json').read_text()); orig=json.loads((O/'original-profile.json').read_text()); assert orig==b
changes=json.loads((O.parent/'hair-material-alternative-audit/exact-changed-leaves.json').read_text()); replay=copy.deepcopy(b)
for c in changes:
 keys=c['path'].split('/')[1:]; x=replay
 for k in keys[:-1]:x=x[int(k)] if isinstance(x,list) else x[k]
 k=keys[-1]; assert x[k]==c['before']; x[k]=c['after']
assert replay==p and len(changes)==5
anchor='moisture pulls selected damp bundles downward into weighted sections'; rows=[]
for label,profile in [('before',b),('proposed',p)]:
 groups=profile['semantics']['component_semantics']['groups']; bases=[g['any_terms'][0] for g in groups];bases[3]=groups[3]['any_terms'][1]
 for name,weight,expected in [('contact',bases[2]+' with visible contact patches',True),('noncontact',anchor+' visibly below the crown and separated from nearby skin and clothing',label=='proposed'),('drygravity','dry long strands fall downward naturally through ordinary gravity beside the shoulders',False),('gloss','glossy smooth hair has shiny bright highlights throughout the long dry lengths',False),('gel','sleek gel styling forms smooth reflective bands along the sides of the head',False),('wetlabel','wet hair wet look styling is visible around the head and shoulders',False)]:
  text=bases.copy();text[2]=weight
  got=bool(pg.candidate_pack_visual_component_match(profile,'; '.join(text)));assert got==expected,(label,name,'component');rows.append([label,name,'component',got])
  try:pg.validate_visual_intent_binding(obligation_index=0,field='weighted_adherence_phrase',phrase=weight,requirement=profile['evidence_requirements']['weighted_adherence_phrase']);got=True
  except ValueError:got=False
  assert got==expected,(label,name,'binding');rows.append([label,name,'binding',got])
 for absent in range(5):
  text=bases.copy();text[2]=anchor;got=pg.candidate_pack_visual_component_match(profile,'; '.join(t for i,t in enumerate(text) if i!=absent));assert got is None;rows.append([label,'missing-'+groups[absent]['id'],'component',False])
 ob=pg.candidate_pack_visual_profile_obligation(profile,reg,activation_source='concept_lock',source_intent_ids=[]);assert ob['render_gates']==profile['render_gates']
 pack={'visual_obligations':{'enabled':True,'contract_version':pg.VISUAL_OBLIGATIONS_CONTRACT_VERSION,'obligations':[ob]}}
 for case in ['contact','noncontact','missing-bundling','nonliteral']:
  ev={k:v['must_mention_any'][0]+' clearly established across the same hair silhouette' for k,v in profile['evidence_requirements'].items()};ev['moisture_coherence_phrase']=profile['evidence_requirements']['moisture_coherence_phrase']['must_mention_any'][1]+' in the depicted hairstyle'
  if case!='contact':ev['weighted_adherence_phrase']=anchor+' visibly below the crown and separated from nearby skin and clothing'
  prompt='Wet damp clumped hair state. '+'. '.join(ev.values())
  if case=='missing-bundling':del ev['strand_bundling_phrase']
  if case=='nonliteral':prompt=prompt.replace(ev['weighted_adherence_phrase'],'')
  failures=ac.audit_visual_obligations(pack,{'chosen_visual_concept_ids':[],'visual_obligation_evidence':{profile['id']:ev}},prompt);got=not failures;assert got==(case=='contact' or (case=='noncontact' and label=='proposed')),(label,case,failures);rows.append([label,case,'composed',got,failures])
assert hashlib.sha256(src.read_bytes()).hexdigest()==sha
(O/'controls.json').write_text(json.dumps(rows,indent=2)+'\n');print('Independent assertions passed:',len(rows));print('Original profile equals current profile: true; registry untouched:',sha)
