# Wet-hair public AFTER verification

All five normal public AFTER candidate-pack runs and five full audit_composed_prompt.py CLI audits pass. Original frozen request envelope, authorial core, creative controls, and embodiment review inputs are reused with their recorded hashes verified. Final prompts preserve each complete original core baseline, adding explicit same-state visual evidence only for the two damp-hair positives.

## Exact comparison
- Weighted noncontact and adhered damp: entire emitted pack differs only in pack_id and the five approved visual-obligation data leaves
- Dry gravity, glossy, gel: entire emitted packs identical before/after
- All 144 candidate collections retain exact record content, counts, order, and IDs; no additions/removals
- All 96 source hashes remained fixed during AFTER execution
- Across BEFORE/AFTER baselines, only the intended visual registry and genuine refreshed profile index differ; 94 other tracked asset/script files remain identical despite intervening evidence-maintenance commits

## Actual audits
All five full composed CLI audits pass. On the identical authored evidence, actual BEFORE emitted obligation rejects weighted noncontact only at weighted_adherence_phrase; AFTER passes. Adhered damp stays passing. Negative cases stay obligation-free and pass their own unchanged dry/gel scene cores, rather than satisfying a wet-hair obligation.

Files: public-cli/after/run-manifest.json; public-comparison/summary.json and per-case recursive differences/candidate inventories; after-evidence/full-composition-summary.json; after-evidence/source-baseline-diff.json; per-case complete-composed.json and complete-audit.json.

Limits: frozen synthetic text controls, no rendered image or population-wide retrieval claim. Explicit authored composition evidence proves contract acceptance, not spontaneous independent composition. No repository edits or provider calls were made by this verifier.
