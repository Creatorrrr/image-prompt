# Read-only hair/material alternatives audit

## Recommendation
Submit the exact five-leaf wet_damp_clumped_hair_state proposal for independent review. No repository edit, paid call, generated vector, public CLI pack, or pixel proof was performed. Proposal restores only the already-authored moisture-weighted downward branch; it does not accept ordinary gravity-hanging dry hair or wet-look gloss alone.

## Provenance and interpretation
Source: skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations.json, profile wet_damp_clumped_hair_state. HEAD and source hash are recorded in source-manifest.json. Definition and mismatched gates were introduced together in 1e589e8a.

The definition explicitly says “directional weight or local adherence.” Its paraphrase “moist strands group into weighted bundles and lose airy separation” and concept term “weighted downward sections” independently support the noncontact weighted branch. The profile name/activation do not limit it to a selected face-contact variant. Mandatory group weighted_adherence, its binding anchors, composition, and two gates nevertheless collapse it to surface adherence. This is not a new general wet-hair definition inferred from outside facts.

Counterevidence was checked: photo_prompt_tags.json's candidate embedding specifies localized face/neck adherence, and tests/fixtures/photo_prompt/hair_semantics_pixel_test_cases_v1.jsonl hair-arm-e specifically chooses weighted local adherence. Keep both unchanged as narrower selected realizations that continue passing. Research ledger record hair_semantics_wet_optical_confound says volume/bundling/adherence, while hair_semantics_wet_bundle_mechanics says reduced airy volume/coherent bundles and explicitly credits weighted-bundle relations. These records are provenance only; the external scientific papers were not newly fetched or treated as universal wetness definitions. Independent reviewer should reject/defer if interpreting the entire named profile as intentionally restricted to the fixture's contact scenario.

## Exact proposal
See exact-changed-leaves.json and proposed-profile.json:
1. Append “moisture pulls selected damp bundles downward into weighted sections” to weighted_adherence component any_terms
2. Append identical anchor to weighted_adherence_phrase must_mention_any
3. Replace composition's weighted-behavior AND localized-adherence conjunction with OR
4. Weighted-adherence render gate permits moisture-weighted downward behavior OR local face/neck/garment adherence
5. Coherence render gate agrees with the selected weighted-behavior OR adherence branch

No IDs, min-content thresholds, five required groups/fields/gates, activation aliases, definition, contrast/reject guards, other groups, or narrower candidate/fixture change. Existing moisture-coherence alternate anchor already says spatially coherent evidence and requires no edit. Named five-part contract remains mandatory.

## Actual consumer evidence
Run reproduce.py and composed_controls.py. 28 binding/component controls plus 8 real composed-audit controls pass. Weighted branch fails before and passes proposed in validate_visual_intent_binding, candidate_pack_visual_component_match, and audit_composed_prompt.audit_visual_obligations. Adherence remains accepted. Dry gravity, dry gloss, gel, wet label alone fail binding; dry-gravity substitution and each missing component fail component match. Missing bundling evidence and nonliteral weighted evidence fail composed audit. Materialization verified both proposed render gates reach the real obligation output. Render review itself was not run; text gate exports are not image proof.

## Keep/defer elsewhere
Hair cut/braid/updo and Y2K forms inspected preserve narrow explicit definitions (cornrows scalp topology, locs interlock vs braid, separate tied buns/tails, selected spiky updo form). No defensible internally authored alternative collapse identified there. No broadening of narrow named hairstyles, regional dress/headwear, or fastening forms is proposed.

## Subsequent public BEFORE verification
After the read-only proposal, parent requested normal public CLI evidence. Five frozen four-contract cases were prepared against the genuine current kebaya-updated index and run through generate_photo_prompt.py. All five exited 0 with all 96 asset/script source hashes unchanged. Weighted noncontact and adhered-damp cases activate exactly wet_damp_clumped_hair_state; dry gravity, glossy, and gel controls activate no visual obligation. Actual composed audit against the two resulting public packs rejects weighted noncontact only at weighted_adherence_phrase and accepts adherence. See public-cli/before/run-manifest.json and composed-audit.json. This supersedes the initial statement that public CLI was not yet performed. No proposed source/index was installed; AFTER public verification remains a separate task if the reviewer approves.
