exec(open(__file__.replace('composed_controls.py','reproduce.py')).read())
import audit_composed_prompt as ac
out=[]
for label,profile in [('before',before),('proposed',after)]:
 obligation=pg.candidate_pack_visual_profile_obligation(profile,reg,activation_source='concept_lock',source_intent_ids=[])
 pack={'visual_obligations':{'enabled':True,'contract_version':pg.VISUAL_OBLIGATIONS_CONTRACT_VERSION,'obligations':[obligation]}}
 for case in ['adherent','weighted','missing-bundling','nonliteral-weight']:
  evidence={k:v['must_mention_any'][0]+' visibly established across the same hair silhouette' for k,v in profile['evidence_requirements'].items()}
  evidence['moisture_coherence_phrase']=profile['evidence_requirements']['moisture_coherence_phrase']['must_mention_any'][1]+' in the depicted hairstyle'
  if case!='adherent':evidence['weighted_adherence_phrase']=anchor+' while separated from face neck and garment'
  prompt='wet damp clumped hair state. '+'. '.join(evidence.values())
  if case=='missing-bundling':del evidence['strand_bundling_phrase']
  if case=='nonliteral-weight':prompt=prompt.replace(evidence['weighted_adherence_phrase'],'')
  failures=ac.audit_visual_obligations(pack,{'chosen_visual_concept_ids':[],'visual_obligation_evidence':{profile['id']:evidence}},prompt)
  expected=case=='adherent' or (case=='weighted' and label=='proposed')
  assert (not failures)==expected,(label,case,failures)
  out.append({'consumer':'audit_composed_prompt.audit_visual_obligations with real materialized obligation','profile':label,'case':case,'pass':not failures,'failures':failures})
save('composed-controls.json',out);print('8 composed controls passed')
