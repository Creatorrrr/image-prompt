import copy,json,sys,hashlib,subprocess
from pathlib import Path
sys.dont_write_bytecode=True
R=Path('REPOSITORY_ROOT');O=Path(__file__).parent;A=R/'skills/photo-prompt-image-generator/assets';sys.path.insert(0,str(A.parent/'scripts'));import prompt_generator as pg
save=lambda n,x:(O/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
f=A/'photo_prompt_visual_obligations.json';initial=hashlib.sha256(f.read_bytes()).hexdigest();reg=pg.load_visual_obligation_registry(f);before=pg.visual_obligation_profile_by_id(reg,'wet_damp_clumped_hair_state');after=copy.deepcopy(before)
anchor='moisture pulls selected damp bundles downward into weighted sections'
after['semantics']['component_semantics']['groups'][2]['any_terms'].append(anchor)
after['evidence_requirements']['weighted_adherence_phrase']['must_mention_any'].append(anchor)
after['composition_instruction']=before['composition_instruction'].replace('weighted downward behavior, and localized adherence to nearby surfaces','weighted downward behavior or localized adherence to nearby surfaces')
after['render_gates'][2]['description']='Damp sections show moisture-weighted downward behavior or adhere locally to the face neck or garment.'
after['render_gates'][3]['description']='Clumping volume reduction and the selected weighted behavior or adherence agree spatially as one moisture state.'
def diff(a,b,p=''):
 if a==b:return []
 if isinstance(a,dict) and isinstance(b,dict):return sum([diff(a[k],b[k],p+'/'+k) for k in a],[])
 if isinstance(a,list) and isinstance(b,list) and len(a)==len(b):return sum([diff(x,y,p+'/'+str(i)) for i,(x,y) in enumerate(zip(a,b))],[])
 return [{'path':p,'before':a,'after':b}]
rows=[]
for label,profile in [('before',before),('proposed',after)]:
 for case,phrase in [('adherent',before['evidence_requirements']['weighted_adherence_phrase']['must_mention_any'][0]+' with visible contact patches'),('weighted',anchor+' while separated from face neck and garment'),('dry-gloss','dry glossy hair carries bright highlights across its full length'),('dry-gravity','long dry hair hangs downward under gravity beside the shoulders'),('gel','sleek gel styling pulls the dry hair tightly backward'),('wet-label','the portrait subject has wet hair styled near her neck')]:
  try:pg.validate_visual_intent_binding(obligation_index=0,field='weighted_adherence_phrase',phrase=phrase,requirement=profile['evidence_requirements']['weighted_adherence_phrase']);result=True;error=None
  except ValueError as e:result=False;error=str(e)
  assert result==(case=='adherent' or (label=='proposed' and case=='weighted'))
  rows.append({'consumer':'validate_visual_intent_binding','profile':label,'case':case,'phrase':phrase,'pass':result,'error':error})
 groups=profile['semantics']['component_semantics']['groups'];terms=[g['any_terms'][0] for g in groups];terms[3]=groups[3]['any_terms'][1]
 for case,term in [('adherent',groups[2]['any_terms'][0]),('weighted',anchor),('dry-gravity','long dry hair hangs downward under gravity beside the shoulders')]:
  selected=terms.copy();selected[2]=term
  result=pg.candidate_pack_visual_component_match(profile,'; '.join(selected));assert bool(result)==(case=='adherent' or (label=='proposed' and case=='weighted'))
  rows.append({'consumer':'candidate_pack_visual_component_match','profile':label,'case':case,'match':result})
  if case=='weighted':
   for i,g in enumerate(groups):
    result=pg.candidate_pack_visual_component_match(profile,'; '.join(t for j,t in enumerate(selected) if j!=i));assert result is None
    rows.append({'consumer':'candidate_pack_visual_component_match','profile':label,'case':'weighted-missing-'+g['id'],'match':result})
 obligation=pg.candidate_pack_visual_profile_obligation(profile,reg,activation_source='concept_lock',source_intent_ids=[])
 assert obligation['render_gates']==profile['render_gates'];save(label+'-materialized-obligation.json',obligation)
assert hashlib.sha256(f.read_bytes()).hexdigest()==initial
save('before-profile.json',before);save('proposed-profile.json',after);save('exact-changed-leaves.json',diff(before,after));save('measured-controls.json',rows);save('source-manifest.json',{'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'registry_sha256':initial,'source_registry_unchanged':True,'provenance_commit':'1e589e8a','no_embedding_calls':True,'no_repository_edits':True,'controls':len(rows)})
print(len(rows),'controls passed; changes',len(diff(before,after)))
