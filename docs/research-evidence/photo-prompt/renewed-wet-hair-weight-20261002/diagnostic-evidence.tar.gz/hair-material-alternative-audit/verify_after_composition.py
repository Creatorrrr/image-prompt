import copy,hashlib,json,sys,subprocess,os
from pathlib import Path
sys.dont_write_bytecode=True
R=Path('REPOSITORY_ROOT');O=Path(__file__).parent;A=R/'skills/photo-prompt-image-generator/assets';sys.path.insert(0,str(A.parent/'scripts'));import prompt_generator as pg;import audit_composed_prompt as ac
D=O/'public-cli/after';E=O/'after-evidence';E.mkdir(exist_ok=True)
save=lambda p,x:p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n');load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source=load(D/'run-manifest.json')['source_manifest'];assert all(sha(R/f)==h for f,h in source['sha256'].items())
reg=pg.load_visual_obligation_registry(A/'photo_prompt_visual_obligations.json');idx=pg.load_visual_profile_index(A/'photo_prompt_visual_profile_index.json',reg);pid='wet_damp_clumped_hair_state';profile=pg.visual_obligation_profile_by_id(reg,pid);assert profile==load(O/'proposed-profile.json')
results=[]
for case in load(O/'public-cli/frozen-input-manifest.json'):
 name=case['case'];p=load(D/f'{name}-pack.json')[0];before=load(O/'public-cli/before'/f'{name}-pack.json')[0];core=p['authorial_core'];lock=core['intent_lock'];baseline=core['baseline_prompt_en'];assert baseline==before['authorial_core']['baseline_prompt_en']
 positive=name in ['weighted-without-contact','adhered-damp-control'];evidence={}
 if positive:
  ob=next(x for x in p['visual_obligations']['obligations'] if x['id']==pid);assert ob['evidence_requirements']==profile['evidence_requirements'];assert ob['component_semantics']==profile['semantics']['component_semantics'];assert ob['render_gates']==profile['render_gates']
  evidence={f:v['must_mention_any'][0]+' visibly established across the same hair silhouette' for f,v in profile['evidence_requirements'].items()}
  evidence['moisture_coherence_phrase']=profile['evidence_requirements']['moisture_coherence_phrase']['must_mention_any'][1]+' in the depicted hairstyle'
  if name=='weighted-without-contact':evidence['weighted_adherence_phrase']='moisture pulls selected damp bundles downward into weighted sections while separated from face neck and garment'
  for f,v in evidence.items():pg.validate_visual_intent_binding(obligation_index=0,field=f,phrase=v,requirement=profile['evidence_requirements'][f])
 prompt=baseline+(' Wet damp clumped hair state. '+'. '.join(evidence.values())+'.' if positive else '')
 c={'pack_id':p['pack_id'],'composer':'agent','prompt_en':prompt,'negative_en':p['negative_en'],'chosen_candidate_ids':[],'chosen_visual_concept_ids':[],'core_retrieval_sha256':p['core_retrieval']['canonical_sha256'],'visual_obligation_evidence':{pid:evidence} if positive else {},'authorial_core_binding':{'source_authorial_core_sha256':core['canonical_sha256'],'source_intent_lock_sha256':lock['canonical_sha256'],'preserved_anchor_ids':[a['anchor_id'] for a in lock['semantic_anchors']],'preserved_evidence':[a['prompt_evidence'] for a in lock['semantic_anchors']],'authorial_decisions':[]}}
 review=copy.deepcopy(p['embodiment_preflight']['baseline_review']);review['provenance']='agent_postcomposition';review['prompt_sha256']=hashlib.sha256(prompt.encode()).hexdigest();review['summary']='Text-only postcomposition review: the frozen single adult, planted feet, relaxed arms, scalp-owned hair and camera view remain unchanged. Added evidence describes only the originally requested hair finish. No body contact, posture, garment, ownership or support change is introduced. No pixel verification is claimed.';c['embodiment_review']={'source_contract_sha256':p['embodiment_preflight']['canonical_sha256'],'review':review}
 c['semantic_clarification_decisions']=[]
 for row in p['semantic_clarification']['candidates']:
  apply=row.get('required_in_final_prompt') is True or (positive and row.get('profile_id')==pid)
  d={'clarification_id':row['id'],'decision':'applied' if apply else 'rejected','rationale':'Preserve the frozen adult, requested hair finish, scalp continuity and original studio view.' if apply else 'This optional interpretation is unnecessary for the frozen hair-finish portrait and would add unrelated meaning.'}
  if apply:d['prompt_evidence']=baseline.split('. ')[0]+'.' if row.get('source')=='requester_meaning_bound_by_authorial_core' else (evidence['strand_bundling_phrase'] if positive else baseline)
  c['semantic_clarification_decisions'].append(d)
 c['creative_augmentation_brief']={'decisions':[{'candidate_id':row['id'],'decision':'rejected','rationale':'Preserve the requested hair finish and frozen portrait without adding optional variations.'} for row in ac.creative_augmentation_candidates_from_pack(p)]}
 save(E/f'{name}-complete-composed.json',c)
 cmd=[sys.executable,str(A.parent/'scripts/audit_composed_prompt.py'),'--pack',str(D/f'{name}-pack.json'),'--composed',str(E/f'{name}-complete-composed.json')];run=subprocess.run(cmd,text=True,capture_output=True,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'});(E/f'{name}-audit.stdout').write_text(run.stdout);(E/f'{name}-audit.stderr').write_text(run.stderr);result=json.loads(run.stdout);save(E/f'{name}-complete-audit.json',result)
 focused_before=ac.audit_visual_obligations(before,c,prompt);focused_after=ac.audit_visual_obligations(p,c,prompt)
 assert bool(focused_before)==(name=='weighted-without-contact'),focused_before
 results.append({'case':name,'cli_command':cmd,'cli_exit':run.returncode,'status':result['status'],'failures':result['failures'],'warnings':result['warnings'],'before_visual_failures':focused_before,'after_visual_failures':focused_after,'baseline_preserved':prompt.startswith(baseline)})
 print(name,result['status'],result['failures'],flush=True)
assert all(sha(R/f)==h for f,h in source['sha256'].items());save(E/'full-composition-summary.json',results);assert all(x['cli_exit']==0 and x['status']=='pass' for x in results)
