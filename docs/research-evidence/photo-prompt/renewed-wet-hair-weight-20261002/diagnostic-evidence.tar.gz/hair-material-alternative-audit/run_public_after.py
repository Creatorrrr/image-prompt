import json,hashlib,subprocess,sys,os
from pathlib import Path
O=Path(__file__).parent;R=Path('REPOSITORY_ROOT');P=O/'public-cli';D=P/'after';D.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((P/'frozen-input-manifest.json').read_text());old_source=json.loads((P/'before-source-manifest.json').read_text())
source={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'status':subprocess.check_output(['git','status','--short'],cwd=R,text=True),'sha256':{f:sha(R/f) for f in old_source['sha256']}}
reg=json.loads((R/'skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations.json').read_text());actual=next(p for p in reg['profiles'] if p['id']=='wet_damp_clumped_hair_state');assert actual==json.loads((O/'proposed-profile.json').read_text())
sys.dont_write_bytecode=True
sys.path.insert(0,str(R/'skills/photo-prompt-image-generator/scripts'));import prompt_generator as pg
registry=pg.load_visual_obligation_registry(R/'skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations.json');pg.load_visual_profile_index(R/'skills/photo-prompt-image-generator/assets/photo_prompt_visual_profile_index.json',registry)
meta={'source_manifest':source,'reviewed_profile_exactly_applied':True,'stage':'normal public CLI AFTER; identical frozen raw four contracts','cases':[]}
for c in manifest:
 for f,h in source['sha256'].items():assert sha(R/f)==h,(f,'source changed before run')
 case=c['case'];I=P/'inputs'/case
 for n,h in c['inputs'].items():assert sha(I/n)==h
 cmd=[sys.executable,str(R/'skills/photo-prompt-image-generator/scripts/generate_photo_prompt.py'),'--seed',str(c['seed'])]
 for a in ['request-envelope','authorial-core','creative-controls','embodiment-review']:cmd+=['--'+a+'-json',str(I/(a+'.json'))]
 cmd+=['--output-file',str(D/(case+'-pack.json'))]
 result=subprocess.run(cmd,cwd=R,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},capture_output=True,text=True,timeout=600)
 (D/(case+'.stdout')).write_text(result.stdout);(D/(case+'.stderr')).write_text(result.stderr)
 row={'case':case,'command':cmd,'exit_code':result.returncode,'input_sha256':c['inputs'],'source_hashes_unchanged':all(sha(R/f)==h for f,h in source['sha256'].items())}
 if result.returncode==0:
  path=D/(case+'-pack.json');pack=json.loads(path.read_text())[0];obs=(pack.get('visual_obligations') or {}).get('obligations',[])
  row.update(output_sha256=sha(path),contract_version=pack.get('contract_version'),obligation_ids=[o['id'] for o in obs],target_obligation=next((o for o in obs if o['id']==c['target_profile']),None))
 meta['cases'].append(row);(D/'run-manifest.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n');print(case,result.returncode,row.get('obligation_ids'),flush=True)
 if result.returncode:print(result.stderr,flush=True)
assert all(c['exit_code']==0 and c['source_hashes_unchanged'] for c in meta['cases'])
