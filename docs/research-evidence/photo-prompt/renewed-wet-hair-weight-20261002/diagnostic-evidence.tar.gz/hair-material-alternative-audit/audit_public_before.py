import sys,json
from pathlib import Path
sys.dont_write_bytecode=True
O=Path(__file__).parent;R=Path('REPOSITORY_ROOT');sys.path.insert(0,str(R/'skills/photo-prompt-image-generator/scripts'));import audit_composed_prompt as ac
profile=json.loads((O/'before-profile.json').read_text());rows=[]
for case in ['weighted-without-contact','adhered-damp-control']:
 pack=json.loads((O/'public-cli/before'/f'{case}-pack.json').read_text())[0]
 e={k:v['must_mention_any'][0]+' visibly established across the same hair silhouette' for k,v in profile['evidence_requirements'].items()}
 e['moisture_coherence_phrase']=profile['evidence_requirements']['moisture_coherence_phrase']['must_mention_any'][1]+' in the depicted hairstyle'
 if case=='weighted-without-contact':e['weighted_adherence_phrase']='moisture pulls selected damp bundles downward into weighted sections while separated from face neck and garment'
 prompt='wet damp clumped hair state. '+'. '.join(e.values());fails=ac.audit_visual_obligations(pack,{'chosen_visual_concept_ids':[],'visual_obligation_evidence':{profile['id']:e}},prompt)
 assert (not fails)==(case=='adhered-damp-control'),fails
 assert not fails or all(f.get('field')=='weighted_adherence_phrase' for f in fails),fails
 rows.append({'case':case,'normal_public_pack':True,'consumer':'audit_visual_obligations','pass':not fails,'failures':fails})
(O/'public-cli/before/composed-audit.json').write_text(json.dumps(rows,indent=2)+'\n');print('Public BEFORE composition controls verified')
