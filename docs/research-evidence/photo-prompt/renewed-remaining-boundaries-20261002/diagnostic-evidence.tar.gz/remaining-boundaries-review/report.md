# Independent review: remaining boundary self-exclusions

## Decision

Approve the seven source fixes after two narrow wording revisions (mirror and face-occluded). Accept the other five unchanged. No repository files were edited and no paid APIs were called. Current source profiles exactly matched all seven audit snapshots when checked.

Only the fourteen specified source leaves may change. Keep Korean alternatives, guards, thresholds, adult requirements, definitions, contrasts, instructions, gates, and component ownership unchanged. The revised phrases are positive boundary summaries within the full required-group conjunction, not replacements for every other required component.

## mirror_selfie_reflection_device_topology

Revised by inserting “any” before “facial occlusion”. Source mirror_gaze_occlusion makes occlusion conditional; a visible unobscured face remains valid. The proposed unconditional noun risks adding mandatory facial concealment. Other physical mirror, grip, gaze and placement relations already belong to this profile.

Exact accepted text:

> the physical mirror reflection contains the adult subject and visibly gripped phone with coherent hand contact gaze placement and any facial occlusion

Real unique content tokens: 17; unchanged floor: 15. Tokenizer: current audit_composed_prompt.authorial_evidence_tokens.

Tokens: adult, any, coherent, contact, contains, facial, gaze, gripped, hand, mirror, occlusion, phone, physical, placement, reflection, subject, visibly

## overhead_social_snapshot_relation

Accepted unchanged. Nearby elevated camera, ground plane, upward response and body foreshortening are existing relations. “Upward subject response” does not force all of face, gaze and hand to respond; their existing alternatives remain in the untouched group. The existing near-prop requirement remains in its own group.

Exact accepted text:

> the nearby elevated camera ground plane upward subject response and coherent body foreshortening jointly establish the close overhead relation

Real unique content tokens: 16; unchanged floor: 14. Tokenizer: current audit_composed_prompt.authorial_evidence_tokens.

Tokens: body, camera, close, coherent, elevated, establish, foreshortening, ground, jointly, nearby, overhead, plane, relation, response, subject, upward

## intentional_face_occluded_mood_portrait

Revised to explicitly preserve occlusion OR head turning and identify the eye-and-nose region. Source occluded_identity_zone allows covered OR turned away; occluder_contact allows overlap, contact OR directional cause. The original proposal’s “scene-bound occlusion” can be read as a physical obstruction only. Revised wording does not require a prop, hand contact, or additional occluder for a head turn. Surrounding head structure, adult readability, unfinished action and identifiable setting were already required. Existing instructions favor a physical occluder more narrowly than component alternatives; leave that pre-existing tension untouched in this limited patch.

Exact accepted text:

> the readable adult subject retains surrounding head structure while deliberate scene-bound occlusion or head turning hides the eye-and-nose region and concrete unfinished action within an identifiable setting carries the mood

Real unique content tokens: 23; unchanged floor: 14. Tokenizer: current audit_composed_prompt.authorial_evidence_tokens.

Tokens: action, adult, carries, concrete, deliberate, eye-and-nose, head, hides, identifiable, mood, occlusion, readable, region, retains, scene-bound, setting, structure, subject, surrounding, turning, unfinished, while, within

## under_eye_high_cheek_blush_distribution

Accepted unchanged. Bilateral upper-cheek cosmetic color, controlled hue, soft edges and clean lower-eyelid boundaries already exist. “Clean” refers to pigment staying outside the lid boundary, not an added skin-quality constraint. The untouched location/boundary groups retain directly-below placement and the narrow skin gap; this summary does not replace them.

Exact accepted text:

> bilateral upper-cheek color reads as deliberately placed cosmetic blush through controlled hue soft edges and clean lower-eyelid boundaries

Real unique content tokens: 16; unchanged floor: 11. Tokenizer: current audit_composed_prompt.authorial_evidence_tokens.

Tokens: bilateral, blush, boundaries, clean, color, controlled, cosmetic, deliberately, edges, hue, lower-eyelid, placed, reads, soft, through, upper-cheek

## cheekbone_temple_blush_drape

Accepted unchanged. Continuous bilateral high-cheek-to-temple cosmetic pigment with a recognizable blush hue and soft tapered edges restates the existing path and edge relations. The upward-outward direction and gradual thinning remain explicitly required by untouched groups. No change to anatomy or color-light exclusion guards.

Exact accepted text:

> bilateral cosmetic pigment remains continuous from high cheekbones toward temples with soft tapered edges and a recognizable blush hue

Real unique content tokens: 15; unchanged floor: 11. Tokenizer: current audit_composed_prompt.authorial_evidence_tokens.

Tokens: bilateral, blush, cheekbones, continuous, cosmetic, edges, high, hue, pigment, recognizable, remains, soft, tapered, temples, toward

## photobooth_four_cut_sequence

Accepted unchanged. “Timed progression” is verbatim in four_pose_progression; frontal lighting is already in four_stable_booth. It does not add timestamps, exact cadence, a narrated event, or animation. Pose OR gaze OR hand-action progression remains disjunctive. The untouched groups keep distinct beats across all four panels, stable appearance and consistent gutters.

Exact accepted text:

> exactly four separated photobooth panels retain the same clearly adult subject consistent crop background and frontal lighting while pose gaze or hand action advances a readable timed progression

Real unique content tokens: 24; unchanged floor: 15. Tokenizer: current audit_composed_prompt.authorial_evidence_tokens.

Tokens: action, adult, advances, background, clearly, consistent, crop, exactly, four, frontal, gaze, hand, lighting, panels, photobooth, pose, progression, readable, retain, same, separated, subject, timed, while

## material_replacement_deferral_repair_cycle

Accepted unchanged. Delete only the exclusion-bearing contrast suffix. Component 4 owns care/maintenance; component 5 owns return to use. Keep repairs, unavailable replacement, localized wear and return-to-use requirements in their respective components. Edit authored match_terms/evidence_terms only and let the compiler project derived surfaces; do not patch compiled mirrors.

Exact accepted text:

> clean tools aligned patches and prior careful mends show continued maintenance

Real unique content tokens: 10; unchanged floor: 6. Tokenizer: current audit_composed_prompt.authorial_evidence_tokens.

Tokens: aligned, careful, clean, continued, maintenance, mends, patches, prior, show, tools

## Verified lexical/matcher behavior

- All seven full English component conjunctions become context-applicable and return component_semantics
- All six available full Korean component conjunctions remain applicable and component-complete
- All 33 single-component and 33 leave-one-component-out probes remain unmatched
- All 36 explicit exclusion controls remain context-rejected and component-unmatched
- Token-floor calculations use the real current unique-content-token function, not word-count estimates
- These tests establish source/matcher consistency only; they do not establish retrieval ranking, model adherence or rendered image quality

## Separate paraphrase review (no edits authorized here)

Zero exact component-group matches is not evidence of missing meaning. In particular, drape [0] says pigment “thins toward each temple”: that is meaningful taper evidence, so the audit’s claim that it fails to establish tapered edges is overstated. Four-cut [0] carries the four-count, same adult, stable setup and distinct temporal beats in natural language. Under-eye [0] conveys bilateral location, soft cosmetic pigment and a clean lid boundary. These should not be automatically replaced with full component strings. Korean paraphrases also need semantic evaluation rather than lexical group accounting.

High-confidence underspecified entries if treated as sufficient whole-profile evidence:

- Mirror [2]: compatible reflection/gaze/phone-occlusion geometry, but it can describe an unheld phone or a non-adult; there is no explicit grip relation
- Overhead [2]: coherent top-down foreshortening alone does not specify a nearby elevated camera, surrounding ground and upward response
- Face-occluded [2]: storm light and unfinished task do not establish deliberate identity-zone hiding or turning, legible adult or scene-bound cause
- Under-eye [2]: controlled cosmetic placement does not identify bilateral upper-cheek/lower-eyelid geometry; it could describe other makeup
- Four-cut [2]: gutters and a coherent sequence do not establish same adult and stable booth; “rather than four unrelated images” should not be misreported as saying nothing about four, but does not establish the full format relation
- Repair-cycle [1]: generic constraint/response/outcome continuity lacks essential-item wear, unavailable replacement, material-appropriate repair, care evidence and return to use

Other condensed examples can carry substantial profile meaning without spelling out every low-level gate. This review does not blanket-label them incomplete merely because exact matcher groups are zero. For example, drape [1] has the correct bilateral upward-outward high-cheek-to-temple path, though taper is unstated; that is a fidelity detail for a separate review, not an automatic rewrite instruction.

The broad paraphrase fallback is pre-existing and unchanged. Keep any decision to tighten it separate from these fourteen source leaf edits. The repair-cycle full paraphrase [0] remains semantically complete but self-excluded because it still contains decorative distressing; the same term remains in its concept term, instruction and gate. This narrow patch does not fix every source surface. Do not silently remove required negative instructions or gates to clear matching.

## Artifacts

proposal.json contains exact accepted/revised strings, paths, real token sets, floors and review reasons. diagnostic.json and check-summary.json contain the reproduced checks. reproduce.py performs read-only imports and in-memory profile modifications before writing review artifacts outside the repository. source-snapshot.json records the checked sources.
