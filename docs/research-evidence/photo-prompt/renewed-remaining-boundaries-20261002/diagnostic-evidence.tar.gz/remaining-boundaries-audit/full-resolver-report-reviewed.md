# Reviewed seven-profile full-resolver diagnostic

Baseline 57e29730f0b5c2df336fd1e9dd58374b2025ee03; 1419 merged profiles. Fourteen authoritative source strings change; sixteen compiled runtime leaves change (the repair profile owns two authored source leaves plus two derived projections). No source mutation, query embeddings or paid API calls.

All raw input registries, hashes, complete resolver results, actual adult-context inference, evidence-field audit errors, and hit arrays are saved. This is an offline full-registry BM25F/resolver test, not an image, normalized authorial-core, or embedding validation.

## Summary

- canonical: {"count_per_arm": 13, "target_hits": {"before": 6, "after": 13}, "target_changes": 13, "inventory_order_changes": 7, "all_hit_changes": 13, "new_hit_rows": 7}
- exact_alias: {"count_per_arm": 34, "target_hits": {"before": 34, "after": 34}, "target_changes": 0, "inventory_order_changes": 0, "all_hit_changes": 19, "new_hit_rows": 0}
- exclusion: {"count_per_arm": 66, "target_hits": {"before": 0, "after": 0}, "target_changes": 0, "inventory_order_changes": 36, "all_hit_changes": 66, "new_hit_rows": 30}
- frozen_original_full: {"count_per_arm": 13, "target_hits": {"before": 6, "after": 6}, "target_changes": 6, "inventory_order_changes": 1, "all_hit_changes": 13, "new_hit_rows": 0}
- independent_scene: {"count_per_arm": 14, "target_hits": {"before": 0, "after": 0}, "target_changes": 0, "inventory_order_changes": 0, "all_hit_changes": 14, "new_hit_rows": 0}
- negated_alias: {"count_per_arm": 68, "target_hits": {"before": 0, "after": 0}, "target_changes": 0, "inventory_order_changes": 0, "all_hit_changes": 53, "new_hit_rows": 0}
- omission: {"count_per_arm": 61, "target_hits": {"before": 0, "after": 0}, "target_changes": 0, "inventory_order_changes": 26, "all_hit_changes": 61, "new_hit_rows": 26}
- original_paraphrase: {"count_per_arm": 20, "target_hits": {"before": 17, "after": 17}, "target_changes": 17, "inventory_order_changes": 0, "all_hit_changes": 20, "new_hit_rows": 0}
- original_single_component: {"count_per_arm": 61, "target_hits": {"before": 0, "after": 0}, "target_changes": 0, "inventory_order_changes": 2, "all_hit_changes": 61, "new_hit_rows": 1}
- boundary_audits: {"before": {"field_pass": 4, "full_profile_pass": 1}, "after": {"field_pass": 7, "full_profile_pass": 1}}

## Independent scenes

- mirror_selfie / positive: adult=True; target False → False; new IDs=[]; removed IDs=[]; inventory/order changed=False
- mirror_selfie / negative: adult=True; target False → False; new IDs=[]; removed IDs=[]; inventory/order changed=False
- overhead_social_portrait / positive: adult=True; target False → False; new IDs=[]; removed IDs=[]; inventory/order changed=False
- overhead_social_portrait / negative: adult=True; target False → False; new IDs=[]; removed IDs=[]; inventory/order changed=False
- obscured_mood_portrait / positive: adult=True; target False → False; new IDs=[]; removed IDs=[]; inventory/order changed=False
- obscured_mood_portrait / negative: adult=True; target False → False; new IDs=[]; removed IDs=[]; inventory/order changed=False
- upper_cheek_blush / positive: adult=True; target False → False; new IDs=[]; removed IDs=[]; inventory/order changed=False
- upper_cheek_blush / negative: adult=True; target False → False; new IDs=[]; removed IDs=[]; inventory/order changed=False
- blush_draping / positive: adult=True; target False → False; new IDs=[]; removed IDs=[]; inventory/order changed=False
- blush_draping / negative: adult=True; target False → False; new IDs=[]; removed IDs=[]; inventory/order changed=False
- four_cut_photobooth / positive: adult=True; target False → False; new IDs=[]; removed IDs=[]; inventory/order changed=False
- four_cut_photobooth / negative: adult=True; target False → False; new IDs=[]; removed IDs=[]; inventory/order changed=False
- repair_continued_use / positive: adult=True; target False → False; new IDs=[]; removed IDs=[]; inventory/order changed=False
- repair_continued_use / negative: adult=False; target False → False; new IDs=[]; removed IDs=[]; inventory/order changed=False

Independent fixtures are frozen prose, and their author-provided “positive” labels do not automatically establish all profile-specific requirements. In particular, the repair positive does not establish replacement unavailability or an active repair; the face-occluded positive does not establish a concrete unfinished task. Treat unchanged misses as measured limitations rather than force-fitting or rewriting these fixtures.

## New-hit risk controls

- exclusion mirror_selfie_reflection_device_topology: ['pc_pc16_owner_relation'] (en)
- exclusion mirror_selfie_reflection_device_topology: ['diegetic_reality_invariant_failure', 'pc_pc16_owner_relation'] (en)
- exclusion mirror_selfie_reflection_device_topology: ['diegetic_reality_invariant_failure'] (en)
- exclusion mirror_selfie_reflection_device_topology: ['diegetic_reality_invariant_failure'] (en)
- omission mirror_selfie_reflection_device_topology: ['pr_surface_wear_contact_owner', 'pc_pc12_owner_relation'] (en)
- omission mirror_selfie_reflection_device_topology: ['uncanny_coherence_mismatch', 'diegetic_reality_invariant_failure', 'pc_pc16_owner_relation', 'pc_pc21_owner_relation'] (en)
- omission mirror_selfie_reflection_device_topology: ['diegetic_reality_invariant_failure', 'mep_garment_clearance', 'pc_pc21_owner_relation'] (en)
- omission mirror_selfie_reflection_device_topology: ['uncanny_coherence_mismatch', 'pc_pc18_owner_relation', 'pc_pc16_owner_relation'] (en)
- exclusion overhead_social_snapshot_relation: ['pc_pc02_owner_relation', 'uncanny_coherence_mismatch'] (en)
- exclusion overhead_social_snapshot_relation: ['pc_pc02_owner_relation'] (en)
- exclusion overhead_social_snapshot_relation: ['pc_pc02_owner_relation'] (en)
- exclusion overhead_social_snapshot_relation: ['pc_pc02_owner_relation'] (en)
- exclusion overhead_social_snapshot_relation: ['pc_pc02_owner_relation', 'uncanny_coherence_mismatch'] (en)
- omission overhead_social_snapshot_relation: ['pc_pc02_owner_relation', 'uncanny_coherence_mismatch'] (en)
- omission overhead_social_snapshot_relation: ['pc_pc21_owner_relation', 'pc_pc02_owner_relation', 'uncanny_coherence_mismatch'] (en)
- omission overhead_social_snapshot_relation: ['pc_pc02_owner_relation', 'pfe_face_garment', 'diamond_central_torso_silhouette_relation'] (en)
- omission overhead_social_snapshot_relation: ['pc_pc02_owner_relation', 'pfe_face_garment'] (en)
- original_single_component overhead_social_snapshot_relation: ['pe_coarse_film_grain_relation'] (overhead_boundary)
- exclusion intentional_face_occluded_mood_portrait: ['pc_pc27_owner_relation', 'pfe_back_face', 'pc_pc12_owner_relation'] (en)
- exclusion intentional_face_occluded_mood_portrait: ['pc_pc27_owner_relation', 'pfe_back_face', 'pc_pc12_owner_relation'] (en)
- exclusion intentional_face_occluded_mood_portrait: ['pc_pc27_owner_relation', 'pfe_back_face', 'pc_pc12_owner_relation', 'mep_casting_full_length'] (en)
- exclusion intentional_face_occluded_mood_portrait: ['pfe_back_face', 'pc_pc12_owner_relation', 'mep_casting_full_length'] (en)
- exclusion intentional_face_occluded_mood_portrait: ['pc_pc27_owner_relation', 'pfe_back_face', 'pc_pc12_owner_relation', 'mep_casting_full_length'] (en)
- omission intentional_face_occluded_mood_portrait: ['pc_pc27_owner_relation', 'pfe_back_face', 'rb_foreground_occlusion', 'tribhanga_three_bend_pose', 'pfe_navel'] (en)
- omission intentional_face_occluded_mood_portrait: ['pc_pc27_owner_relation', 'pc_pc12_owner_relation', 'pfe_back_face'] (en)
- omission intentional_face_occluded_mood_portrait: ['pc_pc27_owner_relation', 'mep_casting_full_length', 'pc_pc12_owner_relation', 'pfe_navel'] (en)
- omission intentional_face_occluded_mood_portrait: ['pc_pc27_owner_relation', 'mep_casting_full_length', 'pfe_ruching'] (en)
- exclusion under_eye_high_cheek_blush_distribution: ['cr_alternating_color', 'y2kr_bronze_makeup', 'y2kr_gloss_tube', 'curvilinear_figure_relation', 'bust_prominence_relation'] (en)
- exclusion under_eye_high_cheek_blush_distribution: ['cr_alternating_color', 'y2kr_bronze_makeup', 'y2kr_gloss_tube', 'curvilinear_figure_relation'] (en)
- exclusion under_eye_high_cheek_blush_distribution: ['cr_alternating_color', 'y2kr_gloss_tube', 'curvilinear_figure_relation', 'bust_prominence_relation'] (en)
- exclusion under_eye_high_cheek_blush_distribution: ['cr_alternating_color', 'y2kr_gloss_tube', 'curvilinear_figure_relation', 'bust_prominence_relation'] (en)
- exclusion under_eye_high_cheek_blush_distribution: ['cr_alternating_color', 'triangle_lower_body_dominant_relation', 'y2kr_bronze_makeup', 'cr_cool_highlights', 'cr_warm_highlights'] (en)
- omission under_eye_high_cheek_blush_distribution: ['cr_alternating_color', 'cr_low_value_contrast', 'cr_mixed_chroma', 'cr_high_chroma'] (en)
- omission under_eye_high_cheek_blush_distribution: ['cr_alternating_color', 'cr_analogous', 'bust_prominence_relation'] (en)
- omission under_eye_high_cheek_blush_distribution: ['bust_prominence_relation', 'triangle_lower_body_dominant_relation'] (en)
- exclusion cheekbone_temple_blush_drape: ['spoon_high_hip_silhouette_relation', 'cr_color_repetition', 'cr_analogous', 'cr_monochromatic'] (en)
- exclusion cheekbone_temple_blush_drape: ['spoon_high_hip_silhouette_relation', 'cr_color_repetition', 'cr_analogous', 'cr_monochromatic'] (en)
- exclusion cheekbone_temple_blush_drape: ['spoon_high_hip_silhouette_relation', 'cr_color_repetition', 'cr_analogous', 'cr_monochromatic'] (en)
- exclusion cheekbone_temple_blush_drape: ['curvilinear_figure_relation', 'spoon_high_hip_silhouette_relation', 'cr_color_repetition', 'cr_analogous', 'cr_monochromatic'] (en)
- exclusion cheekbone_temple_blush_drape: ['spoon_high_hip_silhouette_relation', 'diamond_central_torso_silhouette_relation', 'cr_color_repetition', 'cr_analogous'] (en)
- omission cheekbone_temple_blush_drape: ['cr_monochromatic', 'y2kr_wraparound', 'medium_native_glitch', 'cr_color_repetition'] (en)
- omission cheekbone_temple_blush_drape: ['y2kr_ombre_lips', 'y2kr_bolero', 'cr_chroma_gradient', 'cr_monochromatic', 'y2kr_slip', 'y2kr_micro_mini'] (en)
- omission cheekbone_temple_blush_drape: ['y2kr_wraparound', 'spoon_high_hip_silhouette_relation', 'y2kr_silver_eye'] (en)
- exclusion photobooth_four_cut_sequence: ['pfe_cutout', 'pc_pc30_owner_relation'] (en)
- exclusion photobooth_four_cut_sequence: ['pfe_cutout'] (en)
- exclusion photobooth_four_cut_sequence: ['pfe_cutout', 'pc_pc30_owner_relation'] (en)
- exclusion photobooth_four_cut_sequence: ['pfe_cutout'] (en)
- omission photobooth_four_cut_sequence: ['pfe_cutout', 'mep_in_between'] (en)
- omission photobooth_four_cut_sequence: ['mep_in_between', 'pfe_mesh_skin'] (en)
- omission photobooth_four_cut_sequence: ['pr_casual_crop_subject_legibility', 'pfe_mesh_skin', 'mep_in_between', 'pr_fixed_surveillance_observation', 'mep_garment_movement'] (en)
- omission photobooth_four_cut_sequence: ['y2kr_retro_flash'] (en)
- exclusion material_replacement_deferral_repair_cycle: ['pr_environmental_portrait_subject_place'] (en)
- exclusion material_replacement_deferral_repair_cycle: ['pr_environmental_portrait_subject_place'] (en)
- omission material_replacement_deferral_repair_cycle: ['rb_repair_patch_locality', 'rb_soft_ground_contact'] (en)
- omission material_replacement_deferral_repair_cycle: ['diegetic_reality_invariant_failure'] (en)
- omission material_replacement_deferral_repair_cycle: ['y2kr_anklet', 'medium_native_glitch'] (en)
- omission material_replacement_deferral_repair_cycle: ['pr_surface_wear_contact_owner'] (en)

New hits in positive canonical probes are intended target recovery; arm-specific query wording differs, so non-target changes must be inspected as query/ranking effects rather than assumed semantic regression. Exact alias hard-eligibility depends on actual inferred adult context. Aliases lacking any adult cue can remain ineligible in both arms; do not override adult_context=True to manufacture a pass.

## Paraphrase preservation

- mirror_selfie_reflection_device_topology [0]: matcher semantic_paraphrase_example → semantic_paraphrase_example; target True → True; adult=True
- mirror_selfie_reflection_device_topology [1]: matcher semantic_paraphrase_example → semantic_paraphrase_example; target True → True; adult=True
- mirror_selfie_reflection_device_topology [2]: matcher semantic_paraphrase_example → semantic_paraphrase_example; target True → True; adult=False
- overhead_social_snapshot_relation [0]: matcher semantic_paraphrase_example → semantic_paraphrase_example; target True → True; adult=True
- overhead_social_snapshot_relation [1]: matcher semantic_paraphrase_example → semantic_paraphrase_example; target True → True; adult=False
- overhead_social_snapshot_relation [2]: matcher semantic_paraphrase_example → semantic_paraphrase_example; target True → True; adult=False
- intentional_face_occluded_mood_portrait [0]: matcher semantic_paraphrase_example → semantic_paraphrase_example; target True → True; adult=True
- intentional_face_occluded_mood_portrait [1]: matcher semantic_paraphrase_example → semantic_paraphrase_example; target True → True; adult=True
- intentional_face_occluded_mood_portrait [2]: matcher semantic_paraphrase_example → semantic_paraphrase_example; target True → True; adult=False
- under_eye_high_cheek_blush_distribution [0]: matcher semantic_paraphrase_example → semantic_paraphrase_example; target True → True; adult=False
- under_eye_high_cheek_blush_distribution [1]: matcher semantic_paraphrase_example → semantic_paraphrase_example; target True → True; adult=False
- under_eye_high_cheek_blush_distribution [2]: matcher semantic_paraphrase_example → semantic_paraphrase_example; target True → True; adult=False
- cheekbone_temple_blush_drape [0]: matcher semantic_paraphrase_example → semantic_paraphrase_example; target True → True; adult=False
- cheekbone_temple_blush_drape [1]: matcher semantic_paraphrase_example → semantic_paraphrase_example; target True → True; adult=False
- cheekbone_temple_blush_drape [2]: matcher None → None; target False → False; adult=False
- photobooth_four_cut_sequence [0]: matcher semantic_paraphrase_example → semantic_paraphrase_example; target True → True; adult=True
- photobooth_four_cut_sequence [1]: matcher semantic_paraphrase_example → semantic_paraphrase_example; target True → True; adult=True
- photobooth_four_cut_sequence [2]: matcher semantic_paraphrase_example → semantic_paraphrase_example; target True → True; adult=False
- material_replacement_deferral_repair_cycle [0]: matcher None → None; target False → False; adult=True
- material_replacement_deferral_repair_cycle [1]: matcher semantic_paraphrase_example → semantic_paraphrase_example; target False → False; adult=True

No paraphrase was rewritten. A paraphrase with zero literal component phrase matches can still express valid semantics; exact lexical group count is not a sufficient reason to remove it. Existing matcher fallback and source exclusions are preserved.

## Actual boundary-field audits

- before mirror_selfie_reflection_device_topology: tokens=13, floor=15, boundary failures=[{"check": "visual_obligation_semantic_evidence", "reason": "visual evidence phrase is too generic to prove its field", "profile_id": "mirror_selfie_reflection_device_topology", "field": "mirror_boundary_phrase", "minimum_content_words": 15, "actual_content_words": 13}]; full-profile failures=[{"check": "visual_obligation_semantic_evidence", "reason": "visual evidence phrase is too generic to prove its field", "profile_id": "mirror_selfie_reflection_device_topology", "field": "mirror_device_phrase", "minimum_content_words": 13, "actual_content_words": 11}, {"check": "visual_obligation_semantic_evidence", "reason": "visual evidence phrase is too generic to prove its field", "profile_id": "mirror_selfie_reflection_device_topology", "field": "mirror_gaze_phrase", "minimum_content_words": 11, "actual_content_words": 10}, {"check": "visual_obligation_semantic_evidence", "reason": "visual evidence phrase is too generic to prove its field", "profile_id": "mirror_selfie_reflection_device_topology", "field": "mirror_boundary_phrase", "minimum_content_words": 15, "actual_content_words": 13}]
- after mirror_selfie_reflection_device_topology: tokens=17, floor=15, boundary failures=[]; full-profile failures=[{"check": "visual_obligation_semantic_evidence", "reason": "visual evidence phrase is too generic to prove its field", "profile_id": "mirror_selfie_reflection_device_topology", "field": "mirror_device_phrase", "minimum_content_words": 13, "actual_content_words": 11}, {"check": "visual_obligation_semantic_evidence", "reason": "visual evidence phrase is too generic to prove its field", "profile_id": "mirror_selfie_reflection_device_topology", "field": "mirror_gaze_phrase", "minimum_content_words": 11, "actual_content_words": 10}]
- before overhead_social_snapshot_relation: tokens=12, floor=14, boundary failures=[{"check": "visual_obligation_semantic_evidence", "reason": "visual evidence phrase is too generic to prove its field", "profile_id": "overhead_social_snapshot_relation", "field": "overhead_boundary_phrase", "minimum_content_words": 14, "actual_content_words": 12}]; full-profile failures=[{"check": "visual_obligation_semantic_evidence", "reason": "visual evidence phrase is too generic to prove its field", "profile_id": "overhead_social_snapshot_relation", "field": "overhead_camera_phrase", "minimum_content_words": 12, "actual_content_words": 11}, {"check": "visual_obligation_semantic_evidence", "reason": "visual evidence phrase is too generic to prove its field", "profile_id": "overhead_social_snapshot_relation", "field": "overhead_ground_phrase", "minimum_content_words": 12, "actual_content_words": 9}, {"check": "visual_obligation_semantic_evidence", "reason": "visual evidence phrase is too generic to prove its field", "profile_id": "overhead_social_snapshot_relation", "field": "overhead_response_phrase", "minimum_content_words": 12, "actual_content_words": 10}, {"check": "visual_obligation_semantic_evidence", "reason": "visual evidence phrase is too generic to prove its field", "profile_id": "overhead_social_snapshot_relation", "field": "overhead_foreshortening_phrase", "minimum_content_words": 13, "actual_content_words": 12}, {"check": "visual_obligation_semantic_evidence", "reason": "visual evidence phrase is too generic to prove its field", "profile_id": "overhead_social_snapshot_relation", "field": "overhead_boundary_phrase", "minimum_content_words": 14, "actual_content_words": 12}]
- after overhead_social_snapshot_relation: tokens=16, floor=14, boundary failures=[]; full-profile failures=[{"check": "visual_obligation_semantic_evidence", "reason": "visual evidence phrase is too generic to prove its field", "profile_id": "overhead_social_snapshot_relation", "field": "overhead_camera_phrase", "minimum_content_words": 12, "actual_content_words": 11}, {"check": "visual_obligation_semantic_evidence", "reason": "visual evidence phrase is too generic to prove its field", "profile_id": "overhead_social_snapshot_relation", "field": "overhead_ground_phrase", "minimum_content_words": 12, "actual_content_words": 9}, {"check": "visual_obligation_semantic_evidence", "reason": "visual evidence phrase is too generic to prove its field", "profile_id": "overhead_social_snapshot_relation", "field": "overhead_response_phrase", "minimum_content_words": 12, "actual_content_words": 10}, {"check": "visual_obligation_semantic_evidence", "reason": "visual evidence phrase is too generic to prove its field", "profile_id": "overhead_social_snapshot_relation", "field": "overhead_foreshortening_phrase", "minimum_content_words": 13, "actual_content_words": 12}]
- before intentional_face_occluded_mood_portrait: tokens=14, floor=14, boundary failures=[]; full-profile failures=[{"check": "visual_obligation_semantic_evidence", "reason": "visual evidence phrase is too generic to prove its field", "profile_id": "intentional_face_occluded_mood_portrait", "field": "occluded_identity_zone_phrase", "minimum_content_words": 16, "actual_content_words": 14}, {"check": "visual_obligation_semantic_evidence", "reason": "visual evidence phrase is too generic to prove its field", "profile_id": "intentional_face_occluded_mood_portrait", "field": "occluder_contact_phrase", "minimum_content_words": 14, "actual_content_words": 13}, {"check": "visual_obligation_semantic_evidence", "reason": "visual evidence phrase is too generic to prove its field", "profile_id": "intentional_face_occluded_mood_portrait", "field": "occluded_action_setting_phrase", "minimum_content_words": 12, "actual_content_words": 9}]
- after intentional_face_occluded_mood_portrait: tokens=23, floor=14, boundary failures=[]; full-profile failures=[{"check": "visual_obligation_semantic_evidence", "reason": "visual evidence phrase is too generic to prove its field", "profile_id": "intentional_face_occluded_mood_portrait", "field": "occluded_identity_zone_phrase", "minimum_content_words": 16, "actual_content_words": 14}, {"check": "visual_obligation_semantic_evidence", "reason": "visual evidence phrase is too generic to prove its field", "profile_id": "intentional_face_occluded_mood_portrait", "field": "occluder_contact_phrase", "minimum_content_words": 14, "actual_content_words": 13}, {"check": "visual_obligation_semantic_evidence", "reason": "visual evidence phrase is too generic to prove its field", "profile_id": "intentional_face_occluded_mood_portrait", "field": "occluded_action_setting_phrase", "minimum_content_words": 12, "actual_content_words": 9}]
- before under_eye_high_cheek_blush_distribution: tokens=11, floor=11, boundary failures=[]; full-profile failures=[{"check": "visual_obligation_semantic_evidence", "reason": "visual evidence phrase is too generic to prove its field", "profile_id": "under_eye_high_cheek_blush_distribution", "field": "under_eye_pigment_phrase", "minimum_content_words": 12, "actual_content_words": 11}, {"check": "visual_obligation_semantic_evidence", "reason": "visual evidence phrase is too generic to prove its field", "profile_id": "under_eye_high_cheek_blush_distribution", "field": "under_eye_boundary_phrase", "minimum_content_words": 12, "actual_content_words": 10}, {"check": "visual_obligation_semantic_evidence", "reason": "visual evidence phrase is too generic to prove its field", "profile_id": "under_eye_high_cheek_blush_distribution", "field": "under_eye_edge_phrase", "minimum_content_words": 12, "actual_content_words": 10}]
- after under_eye_high_cheek_blush_distribution: tokens=16, floor=11, boundary failures=[]; full-profile failures=[{"check": "visual_obligation_semantic_evidence", "reason": "visual evidence phrase is too generic to prove its field", "profile_id": "under_eye_high_cheek_blush_distribution", "field": "under_eye_pigment_phrase", "minimum_content_words": 12, "actual_content_words": 11}, {"check": "visual_obligation_semantic_evidence", "reason": "visual evidence phrase is too generic to prove its field", "profile_id": "under_eye_high_cheek_blush_distribution", "field": "under_eye_boundary_phrase", "minimum_content_words": 12, "actual_content_words": 10}, {"check": "visual_obligation_semantic_evidence", "reason": "visual evidence phrase is too generic to prove its field", "profile_id": "under_eye_high_cheek_blush_distribution", "field": "under_eye_edge_phrase", "minimum_content_words": 12, "actual_content_words": 10}]
- before cheekbone_temple_blush_drape: tokens=11, floor=11, boundary failures=[]; full-profile failures=[{"check": "visual_obligation_semantic_evidence", "reason": "visual evidence phrase is too generic to prove its field", "profile_id": "cheekbone_temple_blush_drape", "field": "drape_origin_phrase", "minimum_content_words": 8, "actual_content_words": 7}, {"check": "visual_obligation_semantic_evidence", "reason": "visual evidence phrase is too generic to prove its field", "profile_id": "cheekbone_temple_blush_drape", "field": "drape_path_phrase", "minimum_content_words": 13, "actual_content_words": 10}, {"check": "visual_obligation_semantic_evidence", "reason": "visual evidence phrase is too generic to prove its field", "profile_id": "cheekbone_temple_blush_drape", "field": "drape_edge_phrase", "minimum_content_words": 14, "actual_content_words": 12}]
- after cheekbone_temple_blush_drape: tokens=15, floor=11, boundary failures=[]; full-profile failures=[{"check": "visual_obligation_semantic_evidence", "reason": "visual evidence phrase is too generic to prove its field", "profile_id": "cheekbone_temple_blush_drape", "field": "drape_origin_phrase", "minimum_content_words": 8, "actual_content_words": 7}, {"check": "visual_obligation_semantic_evidence", "reason": "visual evidence phrase is too generic to prove its field", "profile_id": "cheekbone_temple_blush_drape", "field": "drape_path_phrase", "minimum_content_words": 13, "actual_content_words": 10}, {"check": "visual_obligation_semantic_evidence", "reason": "visual evidence phrase is too generic to prove its field", "profile_id": "cheekbone_temple_blush_drape", "field": "drape_edge_phrase", "minimum_content_words": 14, "actual_content_words": 12}]
- before photobooth_four_cut_sequence: tokens=13, floor=15, boundary failures=[{"check": "visual_obligation_semantic_evidence", "reason": "visual evidence phrase is too generic to prove its field", "profile_id": "photobooth_four_cut_sequence", "field": "four_boundary_phrase", "minimum_content_words": 15, "actual_content_words": 13}]; full-profile failures=[{"check": "visual_obligation_semantic_evidence", "reason": "visual evidence phrase is too generic to prove its field", "profile_id": "photobooth_four_cut_sequence", "field": "four_subject_phrase", "minimum_content_words": 13, "actual_content_words": 11}, {"check": "visual_obligation_semantic_evidence", "reason": "visual evidence phrase is too generic to prove its field", "profile_id": "photobooth_four_cut_sequence", "field": "four_booth_phrase", "minimum_content_words": 12, "actual_content_words": 11}, {"check": "visual_obligation_semantic_evidence", "reason": "visual evidence phrase is too generic to prove its field", "profile_id": "photobooth_four_cut_sequence", "field": "four_boundary_phrase", "minimum_content_words": 15, "actual_content_words": 13}]
- after photobooth_four_cut_sequence: tokens=24, floor=15, boundary failures=[]; full-profile failures=[{"check": "visual_obligation_semantic_evidence", "reason": "visual evidence phrase is too generic to prove its field", "profile_id": "photobooth_four_cut_sequence", "field": "four_subject_phrase", "minimum_content_words": 13, "actual_content_words": 11}, {"check": "visual_obligation_semantic_evidence", "reason": "visual evidence phrase is too generic to prove its field", "profile_id": "photobooth_four_cut_sequence", "field": "four_booth_phrase", "minimum_content_words": 12, "actual_content_words": 11}]
- before material_replacement_deferral_repair_cycle: tokens=15, floor=6, boundary failures=[]; full-profile failures=[]
- after material_replacement_deferral_repair_cycle: tokens=10, floor=6, boundary failures=[]; full-profile failures=[]

Full-profile standalone-anchor failures in unchanged evidence fields are distinct from boundary-field performance and do not justify lowering floors.

## Files

- `full-resolver-diagnostic-reviewed.json`: complete before/after results including all-hit arrays and raw resolver output
- `full-resolver-summary-reviewed.json`: probe counts and aggregate changes
- `full-inventory-rank-changes.json`: every changed hit array, with before/after arrays
- `registry-before-57e29730.json` / `registry-after-in-memory-reviewed.json`: frozen merged registries
- `full_resolver.py`: reproduction; `full-resolver-run.log`: run log


## Supplemental adult-context aliases and collateral interpretation

All 34 exact aliases retain hard eligibility before/after when paired with “A clearly adult subject.” and evaluated using the production adult-context helper. All 68 negated aliases with that same adult context still reject the target. Bare aliases are separately retained in the main raw report, including their actual inferred adult status.

Two frozen-input controls acquire an unrelated optional candidate near the BM25F top-8 cutoff:

1. Original overhead boundary alone (“a drone landscape eye-level crop telephoto view or isolated stretched limb does not substitute”) gains `pe_coarse_film_grain_relation` at rank 7 (score 7.447993288789), displacing `one_piece_dress_construction`. No coarse grain is supported by that text, so this is a weak-evidence/false-positive optional retrieval collateral, not a repaired-target activation.
2. “without intentional face-occluded mood portrait” with a clearly adult subject context gains `pc_pc27_owner_relation` at rank 8 (score 19.876218381765), displacing `pr_fixed_surveillance_observation`. The target remains rejected. The generic adult/negated request does not establish the gained profile’s full relation; report it as unrelated optional retrieval collateral.

Both gained profiles are byte-for-byte identical before/after in the merged registry. Fixed query text plus unchanged candidate documents, with changes confined to seven indexed profile documents, supports a corpus BM25F statistics/top-8 competition explanation. This is an inference from controlled inputs, not a rendered failure. Raw details and definitions are in `frozen-input-new-hits.json`. Do not claim there are no new false hits globally.

The main diagnostics show 57 new-hit rows among exclusion/omission/original-single-component controls, but 56 use different EN canonical query wording across arms. They are recorded in `full-inventory-rank-changes.json`; their new non-target hits cannot isolate a source-index-only regression. The one frozen new-hit row in that main set is the grain example above. The separate adult alias run adds the second frozen new-hit row.

All 14 independent scenes retain the same complete hit identity/order and eligibility. All 14 have score changes only; they have zero target hits before/after. This repair proves canonical source consistency and preserves the tested target guards, but does not demonstrate held-out natural-prose recall improvement.

Six of seven complete standalone evidence-anchor audits still fail unchanged non-boundary floors; all seven proposed boundary fields pass. These unrelated failures remain explicit in raw audit results.
