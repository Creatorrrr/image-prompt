# Seven remaining English self-exclusions: read-only proposal

Baseline: `56fa0357`, repository clean before audit. No repository changes, model/image calls, paid embeddings, or source-policy changes. Diagnostics import the actual current `prompt_generator` matcher and `audit_composed_prompt.authorial_evidence_tokens`; proposed changes exist only in memory and files outside the repository.

## Outcome

- All seven old English full-component probes: `request_exclusion`, component match `None`
- All seven proposed English full-component probes: `context_applicable`, `component_semantics`
- All six available Korean full-component probes remain applicable and component-complete; repair-cycle has no Korean component alternatives to modify
- All 33 authored English single-component probes and all 33 leave-one-component-out probes remain unmatched after repair
- All 36 literal exclusion controls remain context-rejected and component-unmatched after repair (and before repair)
- Every changed evidence anchor meets its existing unique-content-token floor

These are source-consistency/matcher checks, not held-out retrieval, full resolver ranking, evidence-contract, runtime, or pixel proof. No claim of semantic quality from embeddings or rendered images is made.

## Minimal patch scope

For the six base-registry profiles, replace only final group `any_terms[0]` and the matching evidence requirement `must_mention_any[0]`. Retain every Korean alternative exactly. For repair-cycle, replace only authored component 4 `match_terms[0]` and `evidence_terms[0]`; let the compiler project its derived group/evidence surfaces. Do not directly edit compiled compatibility surfaces.

Keep activation and exclusions, adult requirements, semantic component-evidence flags, minimum/required groups, all evidence floors, definitions, contrasts, instructions and render gates unchanged. The supplied proposals introduce no new physical or narrative relation; positive boundaries restate existing components.

## mirror_selfie_reflection_device_topology

Source: `skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations.json`

**Definition:** A physical mirror boundary contains both one clearly adult subject's reflection and the phone held by that subject. The reflected gaze, hand-device contact, mirror-plane depth, and occlusion agree as one capture topology, so a direct front-camera selfie, an empty reflection, or an arbitrary phone cannot substitute.

**Exact activation aliases:** ["mirror-selfie reflection-device topology", "coherent mirror-selfie topology", "거셀", "거울 셀카", "미러 셀피"]

**Exact exclusion guards:** ["direct front-camera selfie", "empty mirror", "phone portrait", "software mirror frame", "phone screen photo"]

**Self-triggered exclusions:** `empty mirror`

**Required groups:** mirror_physical_plane, mirror_subject_inside, mirror_device_contact, mirror_gaze_occlusion, mirror_topology_boundary (minimum 5)

**Boundary component:** `mirror_topology_boundary` at zero-based index 4

Old: a direct selfie empty mirror detached phone phone-screen image or software border does not substitute

Proposed: the physical mirror reflection contains the adult subject and visibly gripped phone with coherent hand contact gaze placement and facial occlusion

Evidence `mirror_boundary_phrase`: 16 actual unique content tokens / floor 15

Tokens: adult, coherent, contact, contains, facial, gaze, gripped, hand, mirror, occlusion, phone, physical, placement, reflection, subject, visibly

Source paths: `/semantics/component_semantics/groups/4/any_terms/0`, `/evidence_requirements/mirror_boundary_phrase/must_mention_any/0`

Paraphrase diagnostics:
- [0] the mirror edge and reflected room establish a physical plane containing both the adult subject and her held phone
  Result: semantic_paraphrase_example; 0 exact component groups; exclusions: []
- [1] 거울 경계 안에서 성인 피사체와 손에 든 휴대폰이 같은 반사 공간을 공유함
  Result: semantic_paraphrase_example; 0 exact component groups; exclusions: []
- [2] the subject's reflection gaze and phone occlusion agree with the mirror rather than a software frame
  Result: semantic_paraphrase_example; 0 exact component groups; exclusions: []

## overhead_social_snapshot_relation

Source: `skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations.json`

**Definition:** A camera visibly close above one clearly adult subject looks steeply downward. A surrounding ground plane, upward response, coherent top-down body foreshortening, and enlarged near hand or prop establish the elevated relation without turning a drone view, eye-level crop, or isolated stretched limb into an overhead portrait.

**Exact activation aliases:** ["close overhead social-snapshot relation", "overhead adult social portrait geometry", "MZ 항공샷", "인물 항공샷", "초근접 탑다운 인물샷"]

**Exact exclusion guards:** ["drone landscape", "eye-level portrait", "telephoto overhead", "flat crop", "fisheye face filter"]

**Self-triggered exclusions:** `drone landscape`

**Required groups:** overhead_camera_position, overhead_ground_plane, overhead_subject_response, overhead_foreshortening, overhead_boundary (minimum 5)

**Boundary component:** `overhead_boundary` at zero-based index 4

Old: a drone landscape eye-level crop telephoto view or isolated stretched limb does not substitute

Proposed: the nearby elevated camera ground plane upward subject response and coherent body foreshortening jointly establish the close overhead relation

Evidence `overhead_boundary_phrase`: 16 actual unique content tokens / floor 14

Tokens: body, camera, close, coherent, elevated, establish, foreshortening, ground, jointly, nearby, overhead, plane, relation, response, subject, upward

Source paths: `/semantics/component_semantics/groups/4/any_terms/0`, `/evidence_requirements/overhead_boundary_phrase/must_mention_any/0`

Paraphrase diagnostics:
- [0] a crouching adult looks up toward a nearby high camera while pavement radiates around the body and one raised hand becomes the near anchor
  Result: semantic_paraphrase_example; 0 exact component groups; exclusions: []
- [1] 가까운 상공 카메라와 바닥면과 위로 향한 반응이 같은 수직 관계를 보임
  Result: semantic_paraphrase_example; 0 exact component groups; exclusions: []
- [2] top-down foreshortening remains coherent across head torso limbs and a raised prop
  Result: semantic_paraphrase_example; 0 exact component groups; exclusions: []

## intentional_face_occluded_mood_portrait

Source: `skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations.json`

**Definition:** One clearly adult subject remains readable through hair, posture, hands, clothing, and action while a scene-bound hand, prop, hair curtain, or deliberate head turn covers the identity-bearing eye-and-nose region. The occluder has visible contact or overlap, and setting plus action carries the mood; accidental crop, missed focus, total silhouette, or an absent face cannot substitute.

**Exact activation aliases:** ["intentional face-occluded mood portrait", "purposeful identity-zone occlusion portrait", "얼굴 안 보이는 감성샷", "얼굴 가린 감성 사진"]

**Exact exclusion guards:** ["accidental crop", "missed focus", "motion blur only", "empty scene", "full silhouette only"]

**Self-triggered exclusions:** `accidental crop`, `missed focus`, `empty scene`

**Required groups:** occluded_adult_subject, occluded_identity_zone, occluder_contact, occluded_action_setting, occluded_boundary (minimum 5)

**Boundary component:** `occluded_boundary` at zero-based index 4

Old: accidental crop missed focus motion blur empty scene or full silhouette alone does not substitute

Proposed: the readable adult subject retains surrounding head structure while deliberate scene-bound occlusion and concrete unfinished action within an identifiable setting carry the mood

Evidence `occluded_boundary_phrase`: 19 actual unique content tokens / floor 14

Tokens: action, adult, carry, concrete, deliberate, head, identifiable, mood, occlusion, readable, retains, scene-bound, setting, structure, subject, surrounding, unfinished, while, within

Source paths: `/semantics/component_semantics/groups/4/any_terms/0`, `/evidence_requirements/occluded_boundary_phrase/must_mention_any/0`

Paraphrase diagnostics:
- [0] a broad pressed fern held by the adult subject overlaps both eyes and the nose bridge while her hands and seed-sorting action remain clear
  Result: semantic_paraphrase_example; 0 exact component groups; exclusions: []
- [1] 소품 접촉이 눈과 콧대 식별 영역을 의도적으로 가리되 성인 인물의 행동과 장소는 읽힘
  Result: semantic_paraphrase_example; 0 exact component groups; exclusions: []
- [2] mood comes from storm light and an unfinished task rather than a missing or blurred face
  Result: semantic_paraphrase_example; 0 exact component groups; exclusions: []

## under_eye_high_cheek_blush_distribution

Source: `skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations.json`

**Definition:** Bilateral cosmetic pigment occupies the upper cheek directly below, but not inside, the lower-eyelid boundary. Its hue, soft edge, and controlled placement distinguish blush from dark circles, fatigue shadow, tears, eye irritation, or generalized facial redness.

**Exact activation aliases:** ["under-eye high-cheek blush distribution", "lower-lid-adjacent cosmetic blush", "언더아이 블러셔", "눈밑 블러셔", "애교살 아래 블러셔"]

**Exact exclusion guards:** ["dark circles", "eye irritation", "allergic redness", "tear stain", "fatigue shadow"]

**Self-triggered exclusions:** `dark circles`, `fatigue shadow`

**Required groups:** under_eye_bilateral_pigment, under_eye_lid_boundary, under_eye_soft_edges, under_eye_confound_control (minimum 4)

**Boundary component:** `under_eye_confound_control` at zero-based index 3

Old: dark circles fatigue shadow tears irritation and generalized redness do not substitute

Proposed: bilateral upper-cheek color reads as deliberately placed cosmetic blush through controlled hue soft edges and clean lower-eyelid boundaries

Evidence `under_eye_confound_phrase`: 16 actual unique content tokens / floor 11

Tokens: bilateral, blush, boundaries, clean, color, controlled, cosmetic, deliberately, edges, hue, lower-eyelid, placed, reads, soft, through, upper-cheek

Source paths: `/semantics/component_semantics/groups/3/any_terms/0`, `/evidence_requirements/under_eye_confound_phrase/must_mention_any/0`

Paraphrase diagnostics:
- [0] soft rose pigment sits on both upper cheeks immediately beneath the lower lids with a narrow clean eye boundary
  Result: semantic_paraphrase_example; 0 exact component groups; exclusions: []
- [1] 양쪽 눈 아래 높은 볼에 화장 색소가 놓이고 눈 점막과는 경계가 남음
  Result: semantic_paraphrase_example; 0 exact component groups; exclusions: []
- [2] the color reads as controlled cosmetic placement rather than shadow irritation or tears
  Result: semantic_paraphrase_example; 0 exact component groups; exclusions: []

## cheekbone_temple_blush_drape

Source: `skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations.json`

**Definition:** A continuous elongated path of cosmetic pigment begins on each high cheekbone and blends upward-outward toward the corresponding temple. Color continuity, tapered diffusion, and bilateral placement distinguish the drape from facial anatomy, contour stripes, cast shadow, or colored light.

**Exact activation aliases:** ["cheekbone-to-temple blush-drape distribution", "elongated high-cheek temple blush path", "드레이핑 블러셔", "블러셔 드레이핑", "광대 관자놀이 블러셔"]

**Exact exclusion guards:** ["cheekbone anatomy", "face-lifting claim", "cast shadow", "colored lighting", "contour stripe"]

**Self-triggered exclusions:** `cast shadow`, `colored lighting`, `contour stripe`

**Required groups:** drape_cheek_origin, drape_temple_path, drape_tapered_edges, drape_confound_control (minimum 4)

**Boundary component:** `drape_confound_control` at zero-based index 3

Old: facial anatomy contour stripes cast shadow and colored lighting do not substitute

Proposed: bilateral cosmetic pigment remains continuous from high cheekbones toward temples with soft tapered edges and a recognizable blush hue

Evidence `drape_confound_phrase`: 15 actual unique content tokens / floor 11

Tokens: bilateral, blush, cheekbones, continuous, cosmetic, edges, high, hue, pigment, recognizable, remains, soft, tapered, temples, toward

Source paths: `/semantics/component_semantics/groups/3/any_terms/0`, `/evidence_requirements/drape_confound_phrase/must_mention_any/0`

Paraphrase diagnostics:
- [0] rose pigment starts high on both cheeks and remains visibly continuous as it thins toward each temple
  Result: semantic_paraphrase_example; 0 exact component groups; exclusions: []
- [1] 양쪽 높은 광대에서 관자놀이까지 색소가 위쪽 바깥 방향으로 이어짐
  Result: semantic_paraphrase_example; 0 exact component groups; exclusions: []
- [2] soft tapered edges preserve a blush path instead of a hard contour stripe or lighting gradient
  Result: None; 0 exact component groups; exclusions: ['contour stripe']

## photobooth_four_cut_sequence

Source: `skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations.json`

**Definition:** Exactly four separated photobooth panels show the same clearly adult subject in one stable booth setup. Crop, background, and lighting remain coherent while pose, gaze, or hand action changes in a readable temporal progression; a single photo, random collage, duplicated tile, contact sheet, or illustrated comic cannot substitute.

**Exact activation aliases:** ["photobooth four-cut sequence contract", "same-subject four-panel photobooth strip", "인생네컷", "인생 네 컷", "대왕네컷", "네컷사진"]

**Exact exclusion guards:** ["single portrait", "random collage", "duplicate panels", "contact sheet", "comic strip"]

**Self-triggered exclusions:** `single portrait`, `random collage`, `contact sheet`, `comic strip`

**Required groups:** four_exact_panels, four_same_adult, four_stable_booth, four_pose_progression, four_format_boundary (minimum 5)

**Boundary component:** `four_format_boundary` at zero-based index 4

Old: a single portrait random collage duplicated tile contact sheet or comic strip does not substitute

Proposed: exactly four separated photobooth panels retain the same clearly adult subject consistent crop background and frontal lighting while pose gaze or hand action advances a readable timed progression

Evidence `four_boundary_phrase`: 24 actual unique content tokens / floor 15

Tokens: action, adult, advances, background, clearly, consistent, crop, exactly, four, frontal, gaze, hand, lighting, panels, photobooth, pose, progression, readable, retain, same, separated, subject, timed, while

Source paths: `/semantics/component_semantics/groups/4/any_terms/0`, `/evidence_requirements/four_boundary_phrase/must_mention_any/0`

Paraphrase diagnostics:
- [0] four equal booth panels repeat the same adult, backdrop, crop, and frontal light while each frame advances a different hand-and-gaze beat
  Result: semantic_paraphrase_example; 0 exact component groups; exclusions: []
- [1] 정확히 네 패널에서 같은 성인 피사체와 부스 조건은 유지되고 포즈만 순차적으로 달라짐
  Result: semantic_paraphrase_example; 0 exact component groups; exclusions: []
- [2] physical strip gutters separate a coherent timed sequence rather than four unrelated images
  Result: semantic_paraphrase_example; 0 exact component groups; exclusions: []

## material_replacement_deferral_repair_cycle

Source: `skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations_poverty.json`

**Definition:** An essential item with localized functional wear is actively repaired because replacement is unavailable, then visibly returned to continued use while remaining cared for. All five observable relations must coexist; a broad poverty label, isolated prop, appearance cue or mood treatment alone is not evidence.

**Exact activation aliases:** ["an adult repairs localized functional wear on an essential daily item because replacement is unavailable, then returns it to continued use", "a resource-constrained repair restores an essential shoe bag or garment to use while preserving visible care and localized wear", "교체할 수 없는 필수 생활품의 국소 마모를 성인이 수선하고 다시 사용 상태로 돌려놓는 장면", "필수 신발·가방·의복의 기능 손상을 임시 수선해 계속 사용하는 자원 제약 장면"]

**Exact exclusion guards:** ["vintage fashion", "decorative distressing", "slow fashion hobby", "heritage conservation", "cosplay repair", "dirty clothing only"]

**Self-triggered exclusions:** `decorative distressing`

**Required groups:** essential_item_with_localized_functional_wear, explicit_replacement_unavailability_context, active_material_appropriate_repair, care_and_maintenance_evidence, return_to_use_result (minimum 5)

**Boundary component:** `care_and_maintenance_evidence` at zero-based index 3

Old: clean tools aligned patches and prior careful mends show continued maintenance rather than neglect or decorative distressing

Proposed: clean tools aligned patches and prior careful mends show continued maintenance

Evidence `care_and_maintenance_evidence_phrase`: 10 actual unique content tokens / floor 6

Tokens: aligned, careful, clean, continued, maintenance, mends, patches, prior, show, tools

Source paths: `/authored_components/components/3/match_terms/0`, `/authored_components/components/3/evidence_terms/0`

Paraphrase diagnostics:
- [0] A same-frame photographic relation connects one essential daily-use item has localized functional wear while its broader structure remains cared for, the worn item remains the only serviceable example and a new replacement is visibly unavailable in context, an unmistakably adult user performs a material-appropriate repair directly on the worn functional area, clean tools aligned patches and prior careful mends show continued maintenance rather than neglect or decorative distressing, and the repaired item visibly returns to its ordinary practical use with the new mend still readable.
  Result: None; 5 exact component groups; exclusions: ['decorative distressing']
- [1] The constraint source, the same adult response, and the immediate material outcome remain spatially continuous while labels and appearance stay non-diagnostic.
  Result: semantic_paraphrase_example; 0 exact component groups; exclusions: []

## Partial-paraphrase risks: distinguish existing bypass from repair regression

No stored paraphrase duplicates a single component in a way that makes the tested component-only or leave-one-out context eligible after this patch. Those 66 incomplete controls all remain unmatched. Do not claim the seven have the same duplicate-single-component failure as previously audited families.

There is nevertheless an existing broader fallback: `candidate_pack_visual_component_match` checks all required groups first, then independently accepts any stored paraphrase. The semantic discovery component-evidence condition accepts either return value. Eighteen of twenty exact stored paraphrases produce `semantic_paraphrase_example` with zero exact group matches, both before and after this boundary patch. This is candidate/discovery eligibility, not hard activation or proof of a rendered violation.

Highest-risk partial examples:
- Mirror [2] discusses reflection gaze/phone occlusion only; it lacks complete physical-plane, adult-subject and grip proof
- Overhead [2] discusses coherent foreshortening only; it lacks near elevated camera, surrounding ground and upward response proof
- Face-occluded [2] discusses mood from storm light and an unfinished task; it lacks deliberate identity-zone occlusion, adult legibility and occluder contact proof
- Under-eye [2] says controlled cosmetic placement rather than shadow/irritation/tears; it lacks bilateral location and clean eyelid-boundary proof
- Drape [0]/[1] describe a continuous high-cheek-to-temple path but do not establish the full tapered-edge contract; [2] is currently excluded by `contour stripe` and should not simply be unpoisoned into an incomplete fallback
- Four-cut [2] supplies gutters and a coherent sequence but not the exact four count, same adult, or stable booth setup
- Repair-cycle [1] is a generic constraint/response/outcome sentence with zero exact component matches; it can bypass all five authored relations in the candidate matcher

Other examples combine several semantic aspects but still lack the complete authored contract. Zero exact group matches is a lexical measurement, not proof they carry zero semantic information.

Recommended treatment: keep the 14-field boundary fix separate from a reviewed paraphrase-completeness change. If tightening English paraphrases, replace incomplete English entries with full positive conjunctions of all required source components rather than deleting negatives alone. Retain valid Korean alternatives; their currently permitted partial paraphrase route must be reported as residual rather than silently deleted. The minimal proposal here does not change any paraphrase.

## Repair-cycle-specific source risks

The offending component is fourth (`care_and_maintenance_evidence`), not final (`return_to_use_result`). Truncating the “rather than neglect or decorative distressing” suffix is sufficient and stays above the floor. Existing guards and gates continue rejecting decorative distressing.

The old excluded phrase remains in the source full paraphrase [0], concept-candidate term [3], component instruction, and gate description. Keeping those unchanged is intentional for the smallest component/evidence-only scope and retained instructions/gates, but the full source paraphrase remains self-excluded and generated prose that copies the instruction can still be self-excluding in a later matcher context. Do not claim every source surface is fixed. A separately approved source-consistency pass could update the full English paraphrase and concept term by the same phrase substitution; unlike the generic paraphrase [1], the full paraphrase would remain component-complete. Keep negative gate semantics intact.

## Reproduction and deliverables

- `python reproduce.py`: rebuild source snapshot, exact matching diagnostics, and proposal using current checkout
- `proposal.json`: exact old/new strings, authoring paths, field floors and actual token sets
- `diagnostic.json`: before/after EN and KO contexts, single components, omissions, paraphrases, and exclusions
- `source-snapshot.json`: complete seven original source profiles, including preserved definitions, contrasts, gates and all alternatives

No dependency on public-source research is needed: this task is a source-data consistency audit, not a claim about external trends or scientific semantics.
