import ast,json,pathlib,sys
H=pathlib.Path(__file__).resolve().parent;ROOT=H.parents[1]/'image-prompt';sys.path.insert(0,str(ROOT/'skills/photo-prompt-image-generator/scripts'))
import prompt_generator as pg
# Reuse only pure helper function definitions, never run the main diagnostic again.
tree=ast.parse((H/'full_resolver.py').read_text());helpers=ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ['dump','resolve','pair']],type_ignores=[]);exec(compile(helpers,'full_resolver_helpers','exec'))
regs={a:json.loads((H/f).read_text()) for a,f in [('before','registry-before-57e29730.json'),('after','registry-after-in-memory-reviewed.json')]};profiles={a:{p['id']:p for p in r['profiles']} for a,r in regs.items()};indexes={a:pg.build_visual_profile_index_payload(r) for a,r in regs.items()};cache={};records=[]
proposal=json.loads((H.parent/'remaining-boundaries-review/proposal.json').read_text())
for c in proposal:
 pid=c['profile_id']
 for t in profiles['before'][pid]['activation']['exact_terms']:
  contexts={a:'A clearly adult subject.' for a in regs}
  records.append(pair('exact_alias_adult_context',pid,t,contexts,alias=t))
  for prefix in ['avoid ','without ']:records.append(pair('negated_alias_adult_context',pid,prefix+t,contexts,alias=t,prefix=prefix))
 print('finished',pid,flush=True)
dump('alias-adult-controls.json',records)
print(json.dumps({k:{'n':sum(r['kind']==k for r in records),'hard_hits':{a:sum(any(h.get('hard_eligible') for h in r[a]['target_hits']) for r in records if r['kind']==k) for a in regs},'new_hit_rows':sum(bool(r['changes']['new_hit_ids']) for r in records if r['kind']==k)} for k in {r['kind'] for r in records}},indent=2))
