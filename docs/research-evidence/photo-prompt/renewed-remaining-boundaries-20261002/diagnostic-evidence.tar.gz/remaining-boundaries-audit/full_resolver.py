import copy,hashlib,json,pathlib,sys,subprocess,itertools
H=pathlib.Path(__file__).resolve().parent; ROOT=H.parents[1]/'image-prompt'; A=ROOT/'skills/photo-prompt-image-generator/assets'; sys.path.insert(0,str(A.parent/'scripts'))
import prompt_generator as pg
import audit_composed_prompt as audit
from visual_profile_contracts import compile_visual_profile
P=H.parent/'remaining-boundaries-review/proposal.json'; S=H.parent/'independent-social-cosmetic-scenes.json'
def dump(n,x): (H/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def diff(a,b,path=''):
 if type(a)!=type(b):return [path]
 if isinstance(a,dict):
  assert a.keys()==b.keys();return sum((diff(a[k],b[k],path+'/'+k) for k in a),[])
 if isinstance(a,list):
  assert len(a)==len(b);return sum((diff(x,y,path+'/'+str(i)) for i,(x,y) in enumerate(zip(a,b))),[])
 return [] if a==b else [path]
head=subprocess.check_output(['git','-C',str(ROOT),'rev-parse','HEAD'],text=True).strip(); assert head.startswith('57e29730'),head
before=pg.load_visual_obligation_registry(A/'photo_prompt_visual_obligations.json');dump('registry-before-57e29730.json',before)
proposal=json.loads(P.read_text());after=copy.deepcopy(before);sources={};source_changes=[]
for c in proposal:
 f=ROOT/c['source'];sources[str(f)]=sha(f)
 p=next(p for p in json.loads(f.read_text())['profiles'] if p['id']==c['profile_id']);q=copy.deepcopy(p)
 for path in c['source_paths']:
  keys=path.strip('/').split('/');node=q
  for k in keys[:-1]:node=node[int(k)] if isinstance(node,list) else node[k]
  key=int(keys[-1]) if isinstance(node,list) else keys[-1];assert node[key]==c['old'];node[key]=c['new']
 changes=diff(p,q);assert changes==c['source_paths'];source_changes.extend([{'profile_id':p['id'],'path':x} for x in changes])
 ix=next(i for i,p in enumerate(after['profiles']) if p['id']==c['profile_id']);after['profiles'][ix]=compile_visual_profile(q)
assert len(source_changes)==14
runtime_changes=diff(before,after);assert len(runtime_changes)==16,len(runtime_changes)
dump('registry-after-in-memory-reviewed.json',after)
regs={'before':before,'after':after};profiles={a:{p['id']:p for p in r['profiles']} for a,r in regs.items()};indexes={a:pg.build_visual_profile_index_payload(r) for a,r in regs.items()}
cache={}
def resolve(a,request,context,pid):
 key=(a,request,context,pid)
 if key in cache:return cache[key]
 rows=[{'source':'user_requirement','text':request,'polarity':'required','priority':'critical','mandatory':True},{'source':'authorial_core_baseline_prompt','text':context,'polarity':'required'}]
 adult=pg.candidate_pack_visual_obligation_adult_context(rows,None)
 res=pg.resolve_visual_profile_hits(regs[a],rows,visual_profile_index=indexes[a],query_text=request+' '+context,query_fields={'active_request':request,'baseline_prompt':context},adult_context=adult)
 p=profiles[a][pid];t=request+' '+context
 out={'adult_context':adult,'request':request,'context':context,'target_hits':[h for h in res['hits'] if h['profile_id']==pid],'all_hits':res['hits'],'raw_resolver':res,'context_applicability':pg.visual_profile_context_applicability(p,t,has_authorial_core_context=bool(context)),'component_match':pg.candidate_pack_visual_component_match(p,t)};cache[key]=out;return out
def pair(kind,pid,request,contexts,**extra):
 row={'kind':kind,'profile_id':pid,**extra}
 for a in regs:row[a]=resolve(a,request,contexts[a],pid)
 b=row['before'];c=row['after'];bi=[x['profile_id'] for x in b['all_hits']];ci=[x['profile_id'] for x in c['all_hits']]
 row['changes']={'new_hit_ids':[x for x in ci if x not in bi],'removed_hit_ids':[x for x in bi if x not in ci],'identity_or_order_changed':bi!=ci,'all_hits_changed':b['all_hits']!=c['all_hits'],'target_changed':b['target_hits']!=c['target_hits']}
 return row
records=[];audits=[]
for change in proposal:
 pid=change['profile_id'];p=profiles['before'][pid]
 gs=p['semantics']['component_semantics']['groups']
 # All available parallel language alternatives; exact fixture preserves each original term too.
 for li in range(min(len(g['any_terms']) for g in gs)):
  lang='en' if li==0 else f'ko_{li}';parts={a:[g['any_terms'][li] for g in profiles[a][pid]['semantics']['component_semantics']['groups']] for a in regs};contexts={a:'. '.join(v) for a,v in parts.items()}
  records.append(pair('canonical',pid,'',contexts,language=lang))
  records.append(pair('frozen_original_full',pid,'',{a:contexts['before'] for a in regs},language=lang))
  for exclusion in p['activation'].get('exclude_if_any_terms',[]):records.append(pair('exclusion',pid,'',{a:v+'. Explicitly depict '+exclusion+'.' for a,v in contexts.items()},language=lang,exclusion=exclusion))
  for i,g in enumerate(gs):records.append(pair('omission',pid,'',{a:'. '.join(v[:i]+v[i+1:]) for a,v in parts.items()},language=lang,omitted=g['id']))
 for i,g in enumerate(gs):
  for j,t in enumerate(g['any_terms']):records.append(pair('original_single_component',pid,'',{a:t for a in regs},group=g['id'],alternative=j))
 for i,t in enumerate(p['semantics']['paraphrase_examples']):records.append(pair('original_paraphrase',pid,'',{a:t for a in regs},paraphrase_index=i))
 for t in p['activation']['exact_terms']:
  records.append(pair('exact_alias',pid,t,{a:'' for a in regs},alias=t))
  for prefix in ['avoid ','without ']:records.append(pair('negated_alias',pid,prefix+t,{a:'' for a in regs},alias=t,prefix=prefix))
 for a,r in regs.items():
  pr=profiles[a][pid];ob=pg.candidate_pack_visual_profile_obligation(pr,r,activation_source='explicit_request',source_intent_ids=[]);phrases={f:req['must_mention_any'][0] for f,req in pr['evidence_requirements'].items()};contract={'enabled':True,'contract_version':audit.VISUAL_OBLIGATIONS_CONTRACT_VERSION,'obligations':[ob],'required_hard_gates':[g['id'] for g in ob['render_gates']]}
  failures=audit.audit_visual_obligations({'visual_obligations':contract},{'visual_obligation_evidence':{pid:phrases}},'. '.join(phrases.values()));field=change['evidence_field'];bf=[f for f in failures if f.get('field')==field]
  audits.append({'arm':a,'profile_id':pid,'field':field,'phrase':phrases[field],'tokens':sorted(audit.authorial_evidence_tokens(phrases[field])),'floor':pr['evidence_requirements'][field]['min_content_words'],'boundary_failures':bf,'full_profile_failures':failures})
 print('finished',pid,flush=True)
scenes=json.loads(S.read_text());mapping=dict(zip(['mirror_selfie','overhead_social_portrait','obscured_mood_portrait','upper_cheek_blush','blush_draping','four_cut_photobooth','repair_continued_use'],[c['profile_id'] for c in proposal]))
for s in scenes:records.append(pair('independent_scene',mapping[s['pair_id']],s['korean_request'],{a:s['english_baseline'] for a in regs},scene=s))
assert all(sha(pathlib.Path(p))==h for p,h in sources.items());assert subprocess.check_output(['git','-C',str(ROOT),'status','--porcelain'],text=True)==''
out={'inputs':{'head':head,'sources_sha256':sources,'proposal_sha256':sha(P),'scenes_sha256':sha(S),'before_registry_sha256':pg.visual_profile_registry_sha256(before),'after_registry_sha256':pg.visual_profile_registry_sha256(after),'registry_profiles':len(before['profiles'])},'source_changes':source_changes,'runtime_changed_leaves':runtime_changes,'records':records,'boundary_field_audits':audits,'caveats':['Real full-registry resolver and BM25F; no query vectors supplied, no paid embeddings, no renders.','Adult context inferred with production helper for every probe, including aliases and Korean contexts.','Canonical probes change wording between arms: source consistency, not held-out retrieval gain.','Standalone evidence anchors can fail unrelated existing field minima; report boundary and complete audit separately.']}
dump('full-resolver-diagnostic-reviewed.json',out)
summary={}
for kind in sorted({r['kind'] for r in records}):
 rr=[r for r in records if r['kind']==kind];summary[kind]={'count_per_arm':len(rr),'target_hits':{a:sum(bool(r[a]['target_hits']) for r in rr) for a in regs},'target_changes':sum(r['changes']['target_changed'] for r in rr),'inventory_order_changes':sum(r['changes']['identity_or_order_changed'] for r in rr),'all_hit_changes':sum(r['changes']['all_hits_changed'] for r in rr),'new_hit_rows':sum(bool(r['changes']['new_hit_ids']) for r in rr)}
summary['boundary_audits']={a:{'field_pass':sum(not x['boundary_failures'] for x in audits if x['arm']==a),'full_profile_pass':sum(not x['full_profile_failures'] for x in audits if x['arm']==a)} for a in regs};dump('full-resolver-summary-reviewed.json',summary);print(json.dumps(summary,indent=2))
