import copy,json,pathlib,sys,hashlib
HERE=pathlib.Path(__file__).resolve().parent
ROOT=HERE.parents[1]/'image-prompt'
sys.path.insert(0,str(ROOT/'skills/photo-prompt-image-generator/scripts'))
import prompt_generator as pg
from audit_composed_prompt import authorial_evidence_tokens
from visual_profile_contracts import compile_visual_profile
ASSETS=ROOT/'skills/photo-prompt-image-generator/assets'
ids=['mirror_selfie_reflection_device_topology','overhead_social_snapshot_relation','intentional_face_occluded_mood_portrait','under_eye_high_cheek_blush_distribution','cheekbone_temple_blush_drape','photobooth_four_cut_sequence','material_replacement_deferral_repair_cycle']
new=[
 'the physical mirror reflection contains the adult subject and visibly gripped phone with coherent hand contact gaze placement and facial occlusion',
 'the nearby elevated camera ground plane upward subject response and coherent body foreshortening jointly establish the close overhead relation',
 'the readable adult subject retains surrounding head structure while deliberate scene-bound occlusion and concrete unfinished action within an identifiable setting carry the mood',
 'bilateral upper-cheek color reads as deliberately placed cosmetic blush through controlled hue soft edges and clean lower-eyelid boundaries',
 'bilateral cosmetic pigment remains continuous from high cheekbones toward temples with soft tapered edges and a recognizable blush hue',
 'exactly four separated photobooth panels retain the same clearly adult subject consistent crop background and frontal lighting while pose gaze or hand action advances a readable timed progression',
 'clean tools aligned patches and prior careful mends show continued maintenance'
]
reg=pg.load_visual_obligation_registry(ASSETS/'photo_prompt_visual_obligations.json')
profiles={p['id']:p for p in reg['profiles']}
raw={}
for f in [ASSETS/'photo_prompt_visual_obligations.json',ASSETS/'photo_prompt_visual_obligations_poverty.json']:
 for p in json.loads(f.read_text())['profiles']:
  if p['id'] in ids:raw[p['id']]={'source':str(f.relative_to(ROOT)),'profile':p}
def inspect(p,text):
 groups=p['semantics']['component_semantics']['groups']
 return {'text':text,'context_applicability':pg.visual_profile_context_applicability(p,text,has_authorial_core_context=True),'component_match':pg.candidate_pack_visual_component_match(p,text),'matched_groups':[g['id'] for g in groups if any(pg.intent_alias_matches(text,t) for t in g['any_terms'])], 'matched_exclusions':[t for t in p['activation']['exclude_if_any_terms'] if pg.intent_alias_matches(text,t)],'matched_paraphrases':[i for i,t in enumerate(p['semantics']['paraphrase_examples']) if pg.intent_alias_matches(text,t)]}
results=[];proposals=[]
for pid,phrase in zip(ids,new):
 p=profiles[pid];q=copy.deepcopy(p);groups=p['semantics']['component_semantics']['groups'];gi=3 if pid==ids[-1] else len(groups)-1;old=groups[gi]['any_terms'][0];field=next(k for k,r in p['evidence_requirements'].items() if old in r['must_mention_any'])
 if pid==ids[-1]:
  source=copy.deepcopy(raw[pid]['profile']);c=source['authored_components']['components'][gi];c['match_terms'][0]=phrase;c['evidence_terms'][0]=phrase;q=compile_visual_profile(source)
  paths=[f'/authored_components/components/{gi}/match_terms/0',f'/authored_components/components/{gi}/evidence_terms/0']
 else:
  q['semantics']['component_semantics']['groups'][gi]['any_terms'][0]=phrase;q['evidence_requirements'][field]['must_mention_any'][0]=phrase
  paths=[f'/semantics/component_semantics/groups/{gi}/any_terms/0',f'/evidence_requirements/{field}/must_mention_any/0']
 tokens=sorted(authorial_evidence_tokens(phrase));floor=p['evidence_requirements'][field]['min_content_words'];assert len(tokens)>=floor,(pid,len(tokens),floor)
 row={'profile_id':pid,'definition':p['semantics']['definition'],'activation':p['activation'],'component_group_id':groups[gi]['id'],'component_index':gi,'required_groups':p['semantics']['component_semantics']['required_group_ids'],'minimum_groups':p['semantics']['component_semantics']['minimum_component_groups'],'old_boundary':old,'new_boundary':phrase,'evidence_field':field,'floor':floor,'actual_tokens':tokens,'actual_count':len(tokens),'before':{},'after':{}}
 for arm,pr in [('before',p),('after',q)]:
  gs=pr['semantics']['component_semantics']['groups'];parts=[g['any_terms'][0] for g in gs];full='. '.join(parts)
  row[arm]['full_en']=inspect(pr,full)
  if all(len(g['any_terms'])>1 for g in gs):row[arm]['full_ko']=inspect(pr,'. '.join(g['any_terms'][1] for g in gs))
  row[arm]['single_components']=[inspect(pr,s) for s in parts]
  row[arm]['missing_components']=[{'omitted':gs[i]['id'],**inspect(pr,'. '.join(parts[:i]+parts[i+1:]))} for i in range(len(parts))]
  row[arm]['paraphrases']=[inspect(pr,s) for s in pr['semantics']['paraphrase_examples']]
  row[arm]['exclusion_controls']=[inspect(pr,full+'. '+t) for t in pr['activation']['exclude_if_any_terms']]
  assert all(x['context_applicability'][0]==False and x['component_match'] is None for x in row[arm]['exclusion_controls'])
 assert row['after']['full_en']['context_applicability'][0] and row['after']['full_en']['component_match']=='component_semantics',pid
 results.append(row);proposals.append({'profile_id':pid,'source':raw[pid]['source'],'source_paths':paths,'old':old,'new':phrase,'evidence_field':field,'actual_content_tokens':tokens,'minimum_content_words':floor})
for name,data in [('diagnostic.json',results),('proposal.json',proposals),('source-snapshot.json',raw)]:
 (HERE/name).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
print(json.dumps([{'id':r['profile_id'],'guard':r['before']['full_en']['matched_exclusions'],'tokens':r['actual_count'],'floor':r['floor'],'single_component_escape':[x['matched_groups'] for x in r['after']['single_components'] if x['component_match']], 'omission_escape':[x['omitted'] for x in r['after']['missing_components'] if x['component_match']],'paraphrase_matches':[(x['component_match'],x['matched_groups'],x['matched_exclusions']) for x in r['after']['paraphrases']]} for r in results],indent=2))
