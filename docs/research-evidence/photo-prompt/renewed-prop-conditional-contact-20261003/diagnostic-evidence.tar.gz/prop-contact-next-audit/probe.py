"""Read-only source/consumer probe; no network or paid calls."""
import json,sys,subprocess
from pathlib import Path
ROOT=Path('REPOSITORY_ROOT')
OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'skills/photo-prompt-image-generator/scripts'))
import prompt_generator as pg
p=ROOT/'skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations.json'
r=pg.load_visual_obligation_registry(p)
profiles={x['id']:x for x in r['profiles']}
results=[]
for term,pid in [('crossbow','crossbow_stock_prod_release_system'),('halberd','halberd_axe_point_rear_spike')]:
 request=f'A museum catalog still life of a {term} lying alone on a display plinth, with no people or hands present.'
 rows=[{'source':'concept_lock','text':request,'polarity':'required','priority':'critical','mandatory':True}]
 matches=pg.candidate_pack_auto_visual_obligation_matches(r,rows)
 assert pid in matches,(pid,matches)
 obligation=pg.candidate_pack_visual_profile_obligation(profiles[pid],r,activation_source='explicit_request_semantics',source_intent_ids=['probe'],context_text=request,request_text=request)
 results.append({'profile_id':pid,'request':request,'hard_matches':matches,'source_profile':profiles[pid],'materialized_obligation':obligation})
tags=json.loads((ROOT/'skills/photo-prompt-image-generator/assets/photo_prompt_tags.json').read_text())
ids={'halberd_museum_replica_prop','presenting_halberd_full_head_profile','deactivated_crossbow_display_prop','supporting_crossbow_mechanism_profile'}
candidates=[{'slot':slot,**row} for slot,rs in tags['slots'].items() for row in rs if row['id'] in ids]
provenance=[json.loads(line) for line in (ROOT/'docs/research-evidence/photo-prompt/research_evidence.jsonl').read_text().splitlines() if line.strip() and json.loads(line).get('topic_id') in profiles and json.loads(line).get('topic_id') in {x['profile_id'] for x in results}]
data={'baseline':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'results':results,'candidates':candidates,'provenance':provenance}
(OUT/'probe-results.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
print('Materialized two object-only requests; both retain unconditional human-contact composition; crossbow also retains human-support gate.')
