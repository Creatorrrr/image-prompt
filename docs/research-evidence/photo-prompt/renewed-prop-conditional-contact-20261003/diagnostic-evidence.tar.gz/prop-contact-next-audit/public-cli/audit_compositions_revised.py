import copy,hashlib,json,sys,subprocess
from pathlib import Path
D=Path(__file__).parent;phase=sys.argv[1] if len(sys.argv)>1 else 'after';E=D/(phase+'-compositions-revised');E.mkdir(exist_ok=True);R=Path('REPOSITORY_ROOT');S=R/'skills/photo-prompt-image-generator/scripts';sys.path.insert(0,str(S))
import audit_composed_prompt as ac
save=lambda p,x:p.write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
results=[]
for row in json.loads((D/'frozen-input-manifest.json').read_text()):
 name=row['case'];p=json.loads((D/phase/f'{name}-pack.json').read_text())[0];before=json.loads((D/'before'/f'{name}-pack.json').read_text())[0];core=p['authorial_core'];lock=core['intent_lock'];baseline=core['baseline_prompt_en'];pid=row['target_profile'];evidence={}
 assert baseline==before['authorial_core']['baseline_prompt_en']
 if pid:
  ob=next(x for x in p['visual_obligations']['obligations']if x['id']==pid)
  # Freeze evidence from BEFORE only; identical composition prose across phases.
  old_ob=next(x for x in before['visual_obligations']['obligations']if x['id']==pid)
  evidence={field: req['must_mention_any'][0].rstrip('.')+'.' for field,req in old_ob['evidence_requirements'].items()}
  supplements={
   'shaft_phrase':'The lower grip region connects through this continuous long shaft.',
   'axe_blade_phrase':'This blade is separately visible within the integrated head.',
   'spear_point_phrase':'The full outline preserves this apical component without cropping.',
   'rear_beak_phrase':'The opposing rear beak remains separately visible.',
   'polearm_confound_phrase':'The selected halberd remains the central displayed object.',
   'stock_phrase':'The complete subject remains inside this side-readable three-quarter frame.',
   'prod_phrase':'This complete transverse assembly remains joined to the longitudinal stock.',
   'string_track_phrase':'The spanning string remains visible within the complete object outline.',
   'release_phrase':'The mechanism remains visible as one continuous object.',
   'crossbow_confound_phrase':'The selected crossbow retains its exact stated object placement.'}
  evidence={field:phrase+' '+supplements[field]for field,phrase in evidence.items()}



 prompt=baseline+(' The scene renders '+ob['runtime_expression']['prompt_label_terms'][0]+'. '+' '.join(evidence.values())if evidence else'')
 c={'pack_id':p['pack_id'],'composer':'agent','prompt_en':prompt,'negative_en':p['negative_en'],'chosen_candidate_ids':[],'chosen_visual_concept_ids':[],'core_retrieval_sha256':p['core_retrieval']['canonical_sha256'],'visual_obligation_evidence':{pid:evidence}if pid else{},'authorial_core_binding':{'source_authorial_core_sha256':core['canonical_sha256'],'source_intent_lock_sha256':lock['canonical_sha256'],'preserved_anchor_ids':[a['anchor_id']for a in lock['semantic_anchors']],'preserved_evidence':[a['prompt_evidence']for a in lock['semantic_anchors']],'authorial_decisions':[]}}
 review=copy.deepcopy(p['embodiment_preflight']['baseline_review']);review.update(provenance='agent_postcomposition',prompt_sha256=hashlib.sha256(prompt.encode()).hexdigest(),summary='Source-guided diagnostic composition preserves frozen object display and person presence, including any explicitly requested hand contacts. Existing prose-level embodiment checks are retained. No pixel verification is claimed.')
 c['embodiment_review']={'source_contract_sha256':p['embodiment_preflight']['canonical_sha256'],'review':review};c['semantic_clarification_decisions']=[]
 for r in p['semantic_clarification']['candidates']:
  apply=r.get('required_in_final_prompt')is True or(pid is not None and r.get('profile_id')==pid)
  q={'clarification_id':r['id'],'decision':'applied'if apply else'rejected','rationale':'Preserve the frozen object geometry and requested display or held relation.'if apply else'This optional interpretation adds unnecessary meaning to the frozen object scene.'}
  if apply:q['prompt_evidence']=baseline.split('. ')[0]+'.'if r.get('source')=='requester_meaning_bound_by_authorial_core'else next(iter(evidence.values()),baseline.split('. ')[0]+'.')
  c['semantic_clarification_decisions'].append(q)
 c['creative_augmentation_brief']={'decisions':[{'candidate_id':r['id'],'decision':'rejected','rationale':'Retain the frozen object geometry and person presence without optional additions.'}for r in ac.creative_augmentation_candidates_from_pack(p)]}
 save(E/f'{name}-composed.json',c)
 command=[sys.executable,str(S/'audit_composed_prompt.py'),'--pack',str(D/phase/f'{name}-pack.json'),'--composed',str(E/f'{name}-composed.json')];run=subprocess.run(command,capture_output=True,text=True)
 (E/f'{name}.stdout').write_text(run.stdout);(E/f'{name}.stderr').write_text(run.stderr)
 result=json.loads(run.stdout);save(E/f'{name}-audit.json',result)
 results.append({'case':name,'command':command,'exit_code':run.returncode,'status':result['status'],'failures':result['failures'],'warnings':result['warnings'],'before_visual_failures':ac.audit_visual_obligations(before,c,prompt),'after_visual_failures':ac.audit_visual_obligations(p,c,prompt),'baseline_preserved':prompt.startswith(baseline),'evidence':evidence})
 print(name,result['status'],result['failures'],flush=True)
 save(E/'summary.json',results)
