import json,hashlib,copy,sys
from pathlib import Path
D=Path(__file__).parent;R=Path('REPOSITORY_ROOT')
sys.path.insert(0,str(R/'skills/photo-prompt-image-generator/scripts'))
import prompt_generator as pg
manifest=json.loads((D/'frozen-input-manifest.json').read_text());proposals=json.loads((D.parent/'exact-leaves.json').read_text())
current=json.loads((R/'skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations.json').read_text());profiles={p['id']:p for p in current['profiles']}
probe=json.loads((D.parent/'probe-results.json').read_text());checks=[]
for item in probe['results']:
 pid=item['profile_id'];expected=copy.deepcopy(item['source_profile'])
 for q in proposals:
  if q['profile_id']!=pid:continue
  if q['leaf']=='composition_instruction':expected['composition_instruction']=q['after']
  else:next(g for g in expected['render_gates']if g['id']=='vo_weapon_crossbow_contact_coherence')['description']=q['after']
 assert expected==profiles[pid],pid
for c in manifest:
 n=c['case'];a_path=D/'before'/f'{n}-pack.json';b_path=D/'after'/f'{n}-pack.json';a=json.loads(a_path.read_text())[0];b=json.loads(b_path.read_text())[0]
 expected=copy.deepcopy(a)
 for q in proposals:
  ob=next((x for x in expected.get('visual_obligations',{}).get('obligations',[])if x['id']==q['profile_id']),None)
  if ob is None:continue
  if q['leaf']=='composition_instruction':assert ob['composition_instruction']==q['before'];ob['composition_instruction']=q['after']
  else:
   g=next(g for g in ob['render_gates']if g['id']=='vo_weapon_crossbow_contact_coherence');assert g['description']==q['before'];g['description']=q['after']
 pg.candidate_pack_recompute_id(expected)
 assert expected==b,n+' unexpected pack delta'
 assert a['authorial_core']==b['authorial_core']
 byte_identical=a_path.read_bytes()==b_path.read_bytes()
 if c['target_profile'] is None:assert byte_identical
 held='-held' in n
 if held:
  assert 'Their left palm supports the lower object body while their right hand closes around its grip region.' in b['authorial_core']['baseline_prompt_en']
  assert a['embodiment_preflight']==b['embodiment_preflight']
 checks.append({'case':n,'only_exact_proposed_target_leaves_and_recomputed_pack_id_changed':True,'all_remaining_fields_including_candidates_order_counts_and_core_equal':True,'negative_pack_byte_identity':byte_identical if c['target_profile'] is None else None,'held_contact_baseline_and_embodiment_preserved':True if held else None})
(D/'verified-invariants.json').write_text(json.dumps({'source_target_profiles_equal_exact_three_leaf_patch':True,'cases':checks},indent=2)+'\n')
print(json.dumps(checks,indent=2))
