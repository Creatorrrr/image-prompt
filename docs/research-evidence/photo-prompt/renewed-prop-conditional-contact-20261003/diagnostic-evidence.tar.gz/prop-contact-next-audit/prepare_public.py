"""Source-guided diagnostic fixtures, NOT independent blind intent qualification."""
import hashlib,json,sys
from pathlib import Path
R=Path('REPOSITORY_ROOT');O=Path(__file__).parent/'public-cli'
sys.path[:0]=[str(R),str(R/'skills/photo-prompt-image-generator/scripts')]
import prompt_generator as pg
from tests import photo_prompt_fixtures as f
cases=[]
for noun,pid,geometry in [('halberd','halberd_axe_point_rear_spike','One continuous long shaft connects the lower grip region to the socket of an integrated head. A lateral axe blade, apical spear point and opposing rear beak remain separately visible.'),('crossbow','crossbow_stock_prod_release_system','A complete transverse prod and spanning string join one longitudinal stock at a perpendicular relation. The straight bolt track, release housing and trigger region remain visible as one continuous object.')]:
 for held in [False,True]:
  subject=('One adult presenting a '+noun) if held else ('One isolated '+noun+' on a museum display plinth')
  action=('One adult stands with both feet bearing weight on the gallery floor. Their left palm supports the lower object body while their right hand closes around its grip region. Bent elbows keep both wrists within comfortable reach. Both hands remain separated from the diagnostic head or mechanism, and the complete object clears the torso and floor.') if held else ('The object rests horizontally on two low display supports above a plain museum plinth. The scene contains no people, hands or body parts.')
  cases.append((noun+('-held' if held else '-still-life'),pid,noun,subject,geometry+' '+action,held))
cases.append(('negative-ceramic-vase',None,'ceramic vase','One isolated ceramic vase','A rounded glazed ceramic vessel stands alone on a display plinth. Its continuous curved body rises to a circular open neck; the scene contains no people or hands.',False))
def save(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
manifest=[]
for name,target,label,subject,scene,held in cases:
 request='Create a museum catalog photograph of '+label+'. '+scene+' Preserve the specified placement, contact relations and presence or absence of a person.'
 baseline=subject+'. '+scene+' Use a side-readable three-quarter view with the complete subject inside the frame. Soft directional gallery light keeps material boundaries clear and places coherent shadows on the plinth or floor. Neutral wall tones and a restrained background separate the selected object from the surrounding room. Preserve the full outline without cropping, duplicating or merging structural parts. The stated display relation remains the central event. Realistic texture and controlled reflections retain small surface detail without obscuring the geometric construction. The photograph should preserve the exact stated object placement and visible relationships, with an intentional focal hierarchy and legible material boundaries.'
 controls=pg.creative_controls.resolve(request,overrides={'sensual':0,'fetish':0,'creativity':1,'surreal':0},seed=823)
 core=f.core(request,interpreted_intent=request,subject=subject,setting='a quiet museum gallery with neutral walls and an uncluttered display floor',event=scene,visual_priorities=('complete object outline','coherent gallery light','specified object placement'),baseline_prompt_en=baseline,anchor_evidence=(subject,'complete subject','material boundaries'))
 core['creative_controls_sha256']=controls['canonical_sha256'];core['variation_key']='prop-contact-'+name
 envelope=f.envelope(request);envelope['request_id']='prop-contact-'+name
 review={'contract_version':'photo-embodiment-review/v1','provenance':'agent_prepack','prompt_sha256':hashlib.sha256(core['baseline_prompt_en'].encode()).hexdigest(),'scope':'not_applicable','summary':'Source-guided object-only diagnostic fixture; no body action or rendered-image assessment is claimed.','checks':{}}
 if held:
  review.update(scope='body_action',summary='Source-guided diagnostic fixture. One stationary adult presents one complete object with reachable hand support and both feet bearing weight; this is prose-level physical plausibility review, not image-quality evidence.')
  evidence={'body_ownership':('Their left palm supports the lower object body while their right hand closes around its grip region.','Both named hands belong to the sole adult.'),'joint_chain_and_reach':('Bent elbows keep both wrists within comfortable reach.','Bent elbows and nearby wrists provide reachable stationary support.'),'support_and_balance':('One adult stands with both feet bearing weight on the gallery floor.','Two planted feet support the stationary adult while hands support the displayed object.'),'contact_and_space':('Both hands remain separated from the diagnostic head or mechanism, and the complete object clears the torso and floor.','Contact remains at the designated support and grip, with clearance from body and floor.'),'visibility_and_projection':('Use a side-readable three-quarter view with the complete subject inside the frame.','The view preserves complete object geometry and assigned contacts.')}
  review['checks']={k:{'status':'supported','reason':v[1],'prompt_evidence':[v[0]]}for k,v in evidence.items()}
 norm=pg.normalize_authorial_core(core,request_envelope=pg.normalize_request_envelope(envelope),creative_control_snapshot=controls);pg.photo_embodiment.build_policy(norm,review)
 d=O/'inputs'/name
 for key,v in [('request-envelope',envelope),('authorial-core',core),('creative-controls',controls),('embodiment-review',review)]:save(d/(key+'.json'),v)
 manifest.append({'case':name,'seed':823,'target_profile':target,'qualification':'source-guided diagnostic fixture, no image-quality inference','inputs':{p.name:sha(p)for p in sorted(d.glob('*.json'))}})
save(O/'frozen-input-manifest.json',manifest)
print('Frozen',len(manifest),'normal public source-guided diagnostic cases')
