# Prop/contact DATA audit

Baseline: ef0ea3f6a396d06bad42b92bfe7915f71089a5a5. Read-only source inspection; no repository edits, paid calls or rendered images. Fixtures explicitly are source-guided diagnostics, not independent blind intention qualification or image-quality evidence.

## Recommended defects (two)

1. **Crossbow human support is mandatory for an object-only morphology request.** Profile `crossbow_stock_prod_release_system` activates for `crossbow` and sets `requires_adult_character: false`. Definition, five component groups, five literal evidence fields and candidate concept all describe object geometry. The prop candidate `deactivated_crossbow_display_prop` explicitly supports both human and object contexts; its separate human-only action candidate owns support. Yet composition requires “coherent support-hand contact”, and `vo_weapon_crossbow_contact_coherence` says “Hands support one coherent crossbow”. Both survive materialization unchanged even for an explicit museum still-life request excluding people/hands. The gate is copied into the hard gate set, making this stronger than a merely optional candidate influence.

2. **Halberd composition introduces hand spacing into a person-free morphology request.** Profile `halberd_axe_point_rear_spike` likewise activates for the noun without adult requirement. All five components/evidence fields and gates concern continuous shaft plus composite head, with no human requirement. Object-capable prop `halberd_museum_replica_prop` is separate from the human-only presenting action. Composition alone mandates “hand spacing”. The materializer preserves this in the still-life case, creating an unnecessary instruction conflict even though the five morphology gates do not demand hands.

## Independent source justification and precedent

Read full profiles, all component/evidence/gate alternatives, runtime labels, contrast/reject boundaries, and both original action/prop candidates; snapshots are in `probe-results.json`.

Original qualification: `docs/analysis/2026-09-01-weapon-visual-semantics.md` says the six profiles own subtype morphology only and hand/object ownership is separately governed. Its qualification rule applies the ownership gate **when a person is shown interacting with the object**. Therefore absence of a person is not itself a morphology failure. The same document lists halberd and crossbow diagnostic pixels exclusively as object geometry.

Original provenance rows `weapon_halberd_met_composite_head` and `weapon_crossbow_met_transverse_longitudinal_topology` in `docs/research-evidence/photo-prompt/research_evidence.jsonl` justify composite-head/shaft and perpendicular stock/prod topology. Neither claims mandatory hands; crossbow provenance explicitly says the source does not validate generated hand contact. Source URLs: https://www.metmuseum.org/art/collection/search/845840 and https://www.metmuseum.org/art/collection/search/24924. No new external research was required for this source-internal contradiction.

Reviewed corrected rapier/compound-bow profiles now preserve requested placement and person presence, and their morphology gates require no hand. The approved object-morphology evidence requalification in `daylong-progress-20261002/object-morphology-export/object-action-scope-audit/current-corpus/REQUALIFICATION.md` supports retaining separately requested held-object scenes. These are precedents, not substitutes for the independent halberd/crossbow source argument above.

## Exact minimal proposal

`exact-leaves.json` contains 3 complete before/after leaves: halberd composition, crossbow composition, crossbow contact gate description. No activation, morphology components, evidence alternatives, IDs, scale, gate count or runtime logic changes. Hand contact remains explicit and mandatory **when a person is holding/supporting the object**. No phrase-list exceptions. Human-held controls specify contact, reach, balance and visibility independently in the frozen core; these must remain unchanged after any patch.

## Actual consumer and diagnostic evidence

`prompt_generator.py:candidate_pack_visual_profile_obligation` calls `compile_visual_profile` then copies composition, components, evidence requirements and render gates into the obligation. These two source profiles have no authored-component specialization, so supplied object-only context does not remove the contact mandate. `candidate_pack_visual_obligations` extends `required_hard_gates` with every emitted gate and sets `strict_gate_set: true`.

`probe.py` uses the real loaded registry, hard matcher and materializer, with complete outputs in `probe-results.json`. `prepare_public.py` follows the existing glacier normal public preparation mechanics. `public-cli/run_phase.py` is adapted from the glacier runner only for baseline identity and target IDs, with current unrelated untracked status recorded rather than falsely requiring an entirely clean workspace. It runs the actual public CLI with frozen envelope, authorial core, controls and embodiment review; no injected profile/index or paid embedding call.

Five frozen inputs: halberd still-life and held; crossbow still-life and held; unrelated ceramic vase negative. The first fixture-preparation attempt used a nonexistent literal anchor (“complete object”) and failed before any pack or manifest was frozen; changing the anchor to existing baseline text “complete subject” fixed this schema error. The final frozen manifest records all input hashes. No image-quality inference is permitted.

## Clean keeps

No recommendation for rear-curtain trace: moving subject **or illuminated prop** remains allowed. No recommendation for spacecraft docking: the required contact is interface hardware, not human contact. Revolver's “while hands avoid covering” is weaker/conditional and was not promoted to a third defect. Ground mortar explicitly says “any examining hands”; keep. High-jewelry work-point wording has process/bench inspection support in its definition and was not promoted. Deferred instrument still-life/runtime activation issues were not pursued.

## Public BEFORE result and pending-delta boundary

All five actual public CLI runs exited 0, retained their frozen baseline bytes and passed expected target presence/absence. Both still-life cases retained the diagnosed contact wording; both held cases retain the separately requested hand geometry and five morphology gates. See `public-summary.json` and complete packs. The run began after the parent’s pending unrelated cumulonimbus edit: captured status includes registry/index modifications and the new cumulonimbus test. The runner verified all four frozen source hashes unchanged across all five runs; the final check also matches. Full pending registry/index diff is preserved in `public-cli/before/pending-delta.patch`. Comparing source profiles against HEAD shows only ['cumulonimbus_tower_anvil_precipitation_outflow'] changed; neither audited profile changed. This is a qualified working-tree BEFORE, not a claim of clean-baseline ef0ea3f6 execution.

## AFTER replay and exact invariants

The parent applied the independently reviewed three leaves on HEAD fb21b964 (cumulonimbus publication). All five AFTER normal public CLI runs exited 0 with expected profile presence/absence and unchanged source hashes across the replay. `public-cli/verified-invariants.json` verifies the two source profiles equal precisely the three-leaf proposal. For each public pack, applying those same leaves to BEFORE then recomputing the actual content-derived pack ID yields the entire AFTER object exactly. Thus every candidate value/order/count, core, baseline, contact description, embodiment preflight, evidence requirement, gate ID/count, semantic field and unrelated field is identical. The ceramic-vase negative pack is byte-identical. The initial verifier omitted the derived pack ID and stopped on that expected difference; corrected verification explicitly invokes the real ID recomputation and passes. Full diffs are preserved per case.

## Full-composition audit, initial fixed fixture

`audit_compositions_final.py` freezes each evidence field to the unchanged BEFORE canonical literal. The prompt and evidence are exactly identical between phases; binding metadata changes only as needed for the respective pack. These deliberately minimal phrases did not satisfy the existing content-word minima. All four target compositions fail before and after with five identical `visual_obligation_semantic_evidence` content-word failures each. The vase passes before and after. Every case has three identical `uncovered_intent` warnings, covering its subject, “complete subject” and “material boundaries”; each warning says the intent was preserved by free description/assertion. Complete original audits and exact failure values are retained in `before-compositions-final`, `after-compositions-final`, and `composition-comparison.json`. No acceptance improvement is claimed.

## Authored composition revision rationale

On parent instruction, preserve those initial failures and repair only the insufficient authored composition evidence. `audit_compositions_revised.py` retains the same canonical phrases and appends short, field-specific morphology or framing statements already supported by the frozen baseline: continuous shaft/grip connection; separately visible integrated head parts; full un-cropped outline; stock/transverse-assembly continuity; spanning string; visible release mechanism; unchanged object placement. No request, core, contract, source registry or frozen public input is changed. The same revised prose/evidence is generated from BEFORE for both phases. This is an explicitly documented fixture revision, not a source adjustment or fabricated before/after audit improvement. No new handling or operation instructions are introduced.

## Final revised audit result and recommendation

All five revised full-composition audits pass both BEFORE and AFTER with zero failures and the same three existing uncovered-intent warnings per case. `composition-revised-comparison.json` verifies identical prompt/evidence hashes across phases and unchanged original frozen public input hashes. Initial failed artifacts remain intact. Recommend accepting the narrow three-leaf DATA correction: actual materialized still-life instructions cease demanding hands while held-object requested geometry and all unrelated behavior remain preserved. This is an instruction-scope correction with regression stability, not evidence of improved automated audit acceptance or rendered image quality.
