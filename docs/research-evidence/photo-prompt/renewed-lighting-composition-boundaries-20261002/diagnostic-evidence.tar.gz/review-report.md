# Independent boundary-anchor review

## Verdict

Accept the seven-profile, 14-scalar repair scope, with four wording revisions below. Accept the audit's loop, split, and asymmetric-counterbalance proposals unchanged. No repository edits or external API calls were made. Exact paths, old strings, final proposed strings, tokens, and runtime checks are in `revised-proposals.json`.

### Required semantic corrections

- **Pattern break:** “consistent color orientation spacing and state” grammatically imposes consistency across all four dimensions. The original supports one stable repeated rule and an exception in one salient property; describing the dimensions as candidates in commentary does not repair the actual conjunction. Use: **surrounding similar forms preserve one stable repeated rule while a single local exception in a salient property becomes the first focal read**. Actual authorial token count: **18**, unchanged floor **15**. This preserves rule, local singular exception, salient property, focal priority, and surrounding baseline without fixing all dimensions.
- **Negative space:** “throughout” adds a whole-field distribution requirement; neither definition nor gate requires every region to show readable variation/texture. “Tonal variation or material texture” also narrows the original “tonal or material information.” Use: **subtle tonal or material information remains readable in the broad low-detail field and supports clear subject separation**. Actual count: **13**, unchanged floor **13**. This preserves intentional visible field information and existing contour relation, without requiring texture throughout or detailed scenery.

### Additional conservative wording refinements

- **Low key:** Correct exposure does not require visible surface texture; a smooth lit plane can retain detail and readable shape. Replace “readable surface texture” with “readable detail”: **correctly exposed lit planes retain readable detail within the predominantly dark scene**. Count **11**, floor **5**. Selected planes and coherent directional light remain in other required components.
- **Thirds:** “Visible frame edges” can be misread as an in-scene border, and “surrounding scenery” needlessly narrows the original surrounding field (which may be a studio backdrop or simple graphic field). Use: **the subject's actual position relative to frame boundaries and surrounding field establishes the off-center thirds placement**. Count **12**, floor **11**. This changes no existing intersection/off-center/context relation.

### Accepted physical relations

- **Loop, 14/5:** Detached short lateral nose shadow plus modeled facial sides matches existing downward/off-axis/cheek/far-eye components; graded illumination does not require equal brightness or flat light.
- **Split, 11/5:** Distinct illuminated and shadow-side planes across the central nose boundary matches existing readable modeled shadow and face-center division. No new cheek-turn requirement.
- **Asymmetric counterbalance, 14/12:** Unequal masses, equilibrium, scale contrast, and separation restate the existing relation. “Complementary” modifies their contribution to equilibrium, not color harmony. The original phrase already requires scale contrast and separation; this proposal does not newly replace the secondary cue's existing contrast-or-meaning alternative.

## Verification and limits

Imported the repository's real `authorial_evidence_tokens`, `visual_profile_context_applicability`, and `candidate_pack_visual_component_match`; did not estimate whitespace tokens. All seven final proposals meet unchanged floors and pass English complete-component applicability with `component_semantics`. All 31 exclusion terms still block individually when appended. Only two strings per profile change in the hypothetical copies; Korean variants and all other fields remain untouched.

The whole registry hash changed since the audit (audit: `aff01084cc100b6a776a154c6c7c287f0c17003d576e294f57aa43d57702edae`; reviewed current: `6a9d02e4ebab31ede31fe29dd39deedc99b6ac6acbeceb844ce4b11ef0aae8c1`). **All seven full profile snapshots are nevertheless exactly equal to the audit snapshots.** This is evidence of an unrelated registry change, not evidence of a changed target profile. Recheck paths/old values at application time.

This verifies narrow component eligibility and unchanged blocking, not full composed-prompt compliance, visual qualification, or user preference. Existing evidence floors/other short anchors and exclusion language elsewhere remain outside scope. No live-source verification was attempted; the review is against the repository definitions, required components, and gates.

Reproduce read-only checks from workspace root: `PYTHONDONTWRITEBYTECODE=1 python daylong-progress-20261002/lighting-composition-review/verify.py`. The script writes only its sibling review JSON, not repository files.
