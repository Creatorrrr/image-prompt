# Complete-relation lighting paraphrases: unpublished DATA candidate

## Finding

The three lighting profiles set `semantic_discovery_requires_component_evidence=true`, yet their three English `paraphrase_examples` each duplicate only one of component groups 1–3. In `candidate_pack_visual_component_match`, the full required-group test is followed by an any-paraphrase literal fallback. Consequently a single one of those incomplete clauses returns `semantic_paraphrase_example`. The name of the activation flag does not prevent that fallback in this function.

This is a DATA quality problem: prose advertised as a paraphrase of the relation is merely one fragment of it. Boundary self-exclusion previously masked the issue in complete-component or omission contexts. It does not make the incomplete examples legitimate.

## Proposed scope

Replace the nine existing English paraphrase scalar strings, preserving three variants per profile. Do not change any component groups, Korean, guards, thresholds, definitions, aliases, concept terms, evidence requirements, render gates, or the four composition profiles. Exact old/new values and paths are in `paraphrase-proposals.json`; this is a separate candidate, not permission to publish or modify the repository.

Each proposed sentence expresses the full positive physical relation:

- **Loop:** one dominant elevated off-axis source; short downward/lateral nose shadow; visible detachment from cheek shadow; modeled cheeks; readable far eye. No extra angle measurement, modifier shape, fixed exposure ratio, fill-light requirement, or equal facial brightness.
- **Split:** one nearly lateral ninety-degree key; nose/face-center boundary; clearly distinct lit and shadow halves; readable modeled shadow-side eye contour, cheek, jaw, and head outline. The approximate right angle comes from existing group 1, not a newly exact angular threshold. Head-outline readability comes from the existing definition. No cheek-turn requirement or prescribed fill intensity.
- **Low key:** deliberately dominant dark regions; selected correctly exposed planes under coherent directional light; differentiated shadow densities retaining structure; small controlled detailed highlights. No requirement for surface texture, an entirely black background, measured contrast ratio, or minimum numeric area percentage.

These sentences express positive geometry and exposure relationships rather than embedding negated guard phrases that could self-exclude. Existing negative guards remain untouched.

## What was checked

Read only the three target profiles and relevant matcher implementation. The independent 14-scene probe file was not opened; wording derives from the profile definitions/components/gates rather than test cases.

Using the real matcher on in-memory paraphrase-only copies:

- All nine old single-component examples change from `semantic_paraphrase_example` to no component/paraphrase match
- All nine new complete relational examples return `semantic_paraphrase_example`
- All 45 individual guard-appending checks (five guards × three paraphrases × three profiles) remain blocked
- No repository edits or API calls were made; review artifacts only

These checks establish the narrow lexical behavior, not full resolver performance or broad generalization. Reproduce from the workspace root with `PYTHONDONTWRITEBYTECODE=1 python daylong-progress-20261002/lighting-composition-review/paraphrase_proposal.py`.

## Important limitation

The fallback still exists and still does not prove component completeness computationally: it matches a stored full phrase. Complete replacement prose removes the specific ambiguous partial-clause shortcuts while retaining explicit whole-relation discovery. It does not guarantee recognition of arbitrary natural language paraphrases or neutralize contradictions elsewhere in a request. Nor does it turn optional discovery into hard activation or substitute for prompt evidence and visual qualification. Combined boundary-plus-paraphrase validation in the full resolver remains necessary before adoption.
