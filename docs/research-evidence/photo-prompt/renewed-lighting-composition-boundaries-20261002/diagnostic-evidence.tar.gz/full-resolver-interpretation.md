# Full merged-registry validation and interpretation

## Decision

ACCEPT the reviewed 14-scalar component/evidence repair as a narrow source-consistency correction. This audit does **not** establish improved independent scene retrieval, complete contract satisfaction, or rendered meaning. Preserve existing discovery policy and treat the measured optional-discovery increase and one collateral shortlist swap as explicit residuals rather than hidden passes.

Use `proposal-final-reviewed.json`, not the earlier provisional proposals or original report wording. The reviewer removed inadvertent texture, scenery, all-dimension consistency, and throughout-field requirements. Existing Korean variants are unchanged.

## Frozen inputs and output identity

- Baseline Git HEAD: `a21a08cb6e95fda0dd8f430fe68481878e5ea581`
- `registry-before-a21a08cb.json`: complete merged 1,419-profile registry, not base JSON alone
- Before canonical registry SHA-256: `055a6923d80a880b40f58c764e6021b2e21853f6c4fbb1c0184134b0a9973213`
- Hypothetical after canonical registry SHA-256: `ac0cac3dbd240395e0341812646f1600bba5dc40f19a1b815f3803eaa114862a`
- `registry-after-in-memory.json`: hypothetical after registry; no repository source edits
- Exactly 14 changed leaf strings: seven final component English anchors plus seven matching evidence `must_mention_any` anchors
- All definitions, exact aliases, Korean strings, exclusion guards, discovery flags, required/minimum groups, evidence floors, contrasts, rejects, render gates and other source content remain unchanged
- Existing lighting/composition test and fixture files were hash-checked without edits; four matched files are recorded in the diagnostic
- No external APIs, embeddings, generator, or image rendering were called

## Main measured results

| Measurement | Before | After |
|---|---:|---:|
| Complete EN canonical bundles with target optional hit | 0/7 | 7/7 |
| Available original KO canonical bundles with target optional hit | 4/4 | 4/4 |
| Affirmative exclusion probes blocked | 47/47 | 47/47 |
| Exact aliases retained with exact hard eligibility | 28/28 | 28/28 |
| Negated English aliases blocked | 28/28 | 28/28 |
| Omitted-group bundles with optional target hits | 3/47 | 15/47 |
| Omitted-group complete-component matches | 0/47 | 0/47 |
| Omitted-group hard-eligible target hits | 0/47 | 0/47 |
| Standalone boundary-field audits passing | 6/7 | 7/7 |
| Full-profile standalone-anchor audits passing | 4/7 | 4/7 |
| Independent natural scenes with intended target hit | 0/14 | 0/14 |

The before pattern boundary had 13 distinct authorial evidence tokens against a minimum of 15. The new pattern boundary passes the real field audit. Unchanged nonboundary anchors still explain the three full-profile audit failures; they require meaningful scene detail surrounding their literal anchor, not floor relaxation.

Canonical EN input changes with the authored source in each arm: this measures self-consistency, **not held-out retrieval gain**. Original before English bundles were also replayed unchanged after: their old excluded phrase still blocks them, as intended. Original valid KO bundles and English/Korean exact alias controls remain valid. No existing fixture was rewritten to turn a failing observation into a pass.

## Why omitted-group optional hits rise from 3 to 15

All seven profiles retain `semantic_discovery_requires_component_evidence=true`. The actual resolver policy is more permissive than that flag's name alone suggests: it allows semantic discovery when `candidate_pack_visual_component_match(...) is not None`, rather than requiring the precise return value `component_semantics`.

The component matcher first checks complete minimum/required groups. If those are not complete, it can still return `semantic_paraphrase_example`. Each of the three lighting profiles has paraphrase examples identical to its first three component sentences. Therefore every four-of-five lighting bundle retains at least two complete paraphrase examples.

Before the repair, only omission of final boundary group 5 removes the self-excluding phrase. Those three boundary-omitted bundles already return `semantic_paraphrase_example` and receive optional BM25F hits. The other twelve lighting omissions retain the self-excluding boundary and are blocked. After repair, all fifteen lighting omissions are no longer self-excluded, so the unchanged paraphrase fallback makes all fifteen optionally discoverable.

This is a real increase in incomplete-bundle optional discovery, not an all-groups contract pass. Every omitted-group probe in both arms lacks `component_semantics`, and none acquires hard eligibility. The four composition profiles have scene-oriented paraphrases rather than these duplicated component sentences and remain absent for every omitted-group probe. No source guard or required group was relaxed. Changing the resolver's fallback policy would be a separate behavior change and is not proposed here.

## Independent scenes: one collateral last-slot change

The 14 fixed, independently authored positive/negative scenes produce zero intended-target hits in both arms. All hit objects change scores because rebuilding BM25F changes corpus statistics; only one scene changes hit identity/order. No negative scene gains a new hit ID. No intended target changes hard eligibility.

For the positive red-buoy thirds scene, ranks 1–7 are stable. Rank 8 switches from `pc_pc16_owner_relation` (subject-attached hand offering an object toward the camera) to `pr_surface_wear_contact_owner` (material response and a use/contact trace). Neither profile was edited. Both have `requires_adult_character=false` and allow ordinary optional semantic discovery. The buoy scene lacks evidence sufficient to prove either full relation; their lexical shortlist presence is not a semantic qualification.

Causal isolation:

| Unchanged candidate | Before score | After score |
|---|---:|---:|
| pc_pc16_owner_relation | 37.239982621558 | 37.189415714555 |
| pr_surface_wear_contact_owner | 37.196336291417 | 37.196494821490 |

The revised thirds component introduces the token `position` into an additional profile. Its corpus document frequency increases from 26 to 27, decreasing its inverse-document-frequency contribution to the hand-offering candidate. The wear/contact candidate does not match `position`; its tiny score increase comes from the changed average visual-component field length, 38.61663143058492 to 38.62649753347428.

The two candidates' indexed document fields and tokenizer lexicon are byte-for-byte equal across arms. Substituting the old document frequencies into the after index restores the previous ordering. Substituting old document frequencies **and** old average field lengths exactly reproduces both original scores. Restoring old average lengths alone does not restore the ordering. This establishes a corpus-statistics effect at the top-eight cutoff, not a direct candidate change or a newly detected scene relation.

## Adult-context sensitivity

A separately saved pass uses the actual `candidate_pack_visual_obligation_adult_context(source_rows, None)` function on all 14 natural scenes instead of unconditional `True`.

- Six scenes infer adult context; eight infer no adult context
- Every before-arm hit ID/order matches the unconditional-True baseline
- Every after-arm hit ID/order matches the unconditional-True baseline
- Intended targets remain 0/14 before and after
- The same one positive buoy shortlist swap remains
- Both swapped profiles explicitly do not require adult context

Thus the still-life-appropriate context check does not remove or create this residual in this frozen set. This should not be generalized to unrelated scenes.

## Files and reproduction

- `diagnose_full_resolver.py proposal-final-reviewed.json`: full frozen comparison, full resolver/BM25F controls and real evidence-field audits
- `full-resolver-diagnostic.json`: original complete measurement
- `full-resolver-diagnostic-enriched.json`: measurement with discovery flags, group contracts, eligibility distinctions and scene-ID-change annotations
- `full-resolver-summary.json`: concise counts
- `adult_context_sensitivity.py`: separate natural-scene sensitivity and corpus-statistics counterfactual isolation
- `adult-context-sensitivity.json`: exact sensitivity hits, matched terms, scores and counterfactual outputs
- `full-resolver-run-attempt1.log`: preserved initial assertion failure caused by incorrectly inheriting a capture-specific no-omitted-hit expectation; subsequent diagnostic records the existing lighting behavior rather than suppressing it

The source-consistency gains and independent-scene residuals must remain separate in downstream reporting. Original audit artifacts and original natural-scene inputs are preserved.
