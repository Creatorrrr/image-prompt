from pathlib import Path
import json
from collections import Counter
D=Path(__file__).parent
p=json.loads((D/'combined-full-resolver-diagnostic.json').read_text());reg=json.loads((D/'registry-before-a21a08cb.json').read_text());lookup={r['id']:r for r in reg['profiles']}
for r in p['missing_required_groups']:
 profile=lookup[r['profile_id']];c=profile['semantics']['component_semantics'];r.update(semantic_discovery_requires_component_evidence=profile['activation'].get('semantic_discovery_requires_component_evidence'),minimum_component_groups=c['minimum_component_groups'],required_group_ids=c['required_group_ids'])
 r['target_hard_eligible']=any(h.get('hard_eligible') for h in r['result']['target_hits']);r['target_optional_eligible']=any(h.get('optional_eligible') for h in r['result']['target_hits']);r['complete_component_match']=r['result']['component_match']=='component_semantics'
for r in p['independent_scenes']:
 r['target_hard_eligibility_changed']=any(h.get('hard_eligible') for h in r['before']['target_hits'])!=any(h.get('hard_eligible') for h in r['after']['target_hits'])
 r['new_hit_ids']=[h['profile_id'] for h in r['after']['all_hits'] if h['profile_id'] not in {x['profile_id'] for x in r['before']['all_hits']}]
summary=dict(p['summary'])
summary['omitted_groups']={a:{'probes':sum(r['arm']==a for r in p['missing_required_groups']),'target_hits':sum(r['arm']==a and bool(r['result']['target_hits']) for r in p['missing_required_groups']),'optional_eligible':sum(r['arm']==a and r['target_optional_eligible'] for r in p['missing_required_groups']),'hard_eligible':sum(r['arm']==a and r['target_hard_eligible'] for r in p['missing_required_groups']),'complete_component_matches':sum(r['arm']==a and r['complete_component_match'] for r in p['missing_required_groups'])} for a in ('before','after')}
summary['negative_scenes_with_new_hit_ids']=[{'pair_id':r['pair_id'],'new_hit_ids':r['new_hit_ids']} for r in p['independent_scenes'] if r['polarity']=='negative' and r['new_hit_ids']]
summary['target_hard_eligibility_changes']=sum(r['target_hard_eligibility_changed'] for r in p['independent_scenes'])
summary['independent_identity_changes']=[{'pair_id':r['pair_id'],'polarity':r['polarity'],'before':[h['profile_id'] for h in r['before']['all_hits']],'after':[h['profile_id'] for h in r['after']['all_hits']]} for r in p['independent_scenes'] if r['hit_identity_or_order_changed']]
summary['standalone_full_profiles_passing']={a:sum(r['arm']==a and r['full_profile_passed'] for r in p['standalone_field_audits']) for a in ('before','after')}
summary['old_single_component_target_hits']={a:sum(bool(r['old'][a]['target_hits']) for r in p['paraphrase_controls']) for a in ('before','after')}
summary['new_full_paraphrase_optional_hits']={a:sum(any(h.get('optional_eligible') for h in r['new'][a]['target_hits']) for r in p['paraphrase_controls']) for a in ('before','after')}
summary['new_paraphrase_guard_probes']=sum(len(r['new_phrase_exclusions']) for r in p['paraphrase_controls'])
summary['new_paraphrase_guard_target_hits']=sum(bool(x['result']['target_hits']) for r in p['paraphrase_controls'] for x in r['new_phrase_exclusions'])
summary['inferred_adult_true_natural_scenes']=sum(r['after']['adult_context'] for r in p['independent_scenes'])
p['summary']=summary
(D/'combined-full-resolver-diagnostic-enriched.json').write_text(json.dumps(p,ensure_ascii=False,indent=2)+'\n');(D/'combined-full-resolver-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');print(json.dumps(summary,ensure_ascii=False,indent=2))
