import copy,json,sys
from pathlib import Path
D=Path(__file__).parent;sys.path.insert(0,str(D.parent.parent/'image-prompt/skills/photo-prompt-image-generator/scripts'))
import prompt_generator as pg
from bm25f_retrieval import rank_bm25f
regs={a:json.loads((D/f).read_text()) for a,f in [('before','registry-before-a21a08cb.json'),('after','combined-registry-after-in-memory.json')]};idx={a:pg.build_visual_profile_index_payload(r)['bm25f'] for a,r in regs.items()};d=json.loads((D/'combined-full-resolver-diagnostic-enriched.json').read_text());out=[]
for s in d['independent_scenes']:
 if not s['hit_identity_or_order_changed']:continue
 ids=['pc_pc16_owner_relation','pr_surface_wear_contact_owner'] if s['pair_id']=='composition_thirds_01' else ['mep_visual_juxtaposition','y2kr_asym_top'];q={'active_request':s['request_ko'],'baseline_prompt':s['baseline_en']};assert all(idx['before']['documents'][i]==idx['after']['documents'][i] for i in ids);assert idx['before']['lexicon']==idx['after']['lexicon'];v=copy.deepcopy(idx['after']);v['document_frequencies']=idx['before']['document_frequencies'];v['average_field_lengths']=idx['before']['average_field_lengths'];r={'pair_id':s['pair_id'],'unchanged_candidate_documents':True,'unchanged_lexicon':True,'scores':{a:rank_bm25f(x,q,allowed_ids=ids,limit=2) for a,x in list(idx.items())+[('after_old_corpus_stats',v)]}};assert r['scores']['before']==r['scores']['after_old_corpus_stats'];out.append(r)
(D/'combined-rank-change-causes.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps(out,indent=2))
