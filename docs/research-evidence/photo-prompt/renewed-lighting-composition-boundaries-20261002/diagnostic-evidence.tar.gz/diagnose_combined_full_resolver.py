#!/usr/bin/env python3
"""Read-only repository, no API: full-registry in-memory resolver/BM25F diagnostics.
Canonical probes use each arm's own authored component wording, so measure source
self-consistency, NOT held-out retrieval. Independent scenes are frozen inputs.
These probes lack full generator / normalized authorial-core proof.
"""
import copy,hashlib,json,pathlib,sys
HERE=pathlib.Path(__file__).resolve().parent
ROOT=pathlib.Path.cwd()
SCRIPTS=ROOT/'skills/photo-prompt-image-generator/scripts'
sys.path.insert(0,str(SCRIPTS))
import prompt_generator as pg
from audit_composed_prompt import authorial_evidence_tokens
import audit_composed_prompt as audit
REGISTRY=HERE/'registry-before-a21a08cb.json'
PROPOSAL=pathlib.Path(sys.argv[1]) if len(sys.argv)>1 else HERE/'combined-proposal-boundary14-paraphrase9.json'
SCENES=HERE/'independent-lighting-composition-scenes.json'

def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def differences(a,b,path=''):
 if type(a)!=type(b):return [path]
 if isinstance(a,dict):
  assert a.keys()==b.keys(),path
  return sum((differences(a[k],b[k],path+'/'+str(k)) for k in a),[])
 if isinstance(a,list):
  assert len(a)==len(b),path
  return sum((differences(x,y,path+'/'+str(i)) for i,(x,y) in enumerate(zip(a,b))),[])
 return [] if a==b else [path]

def extra_controls(before,after,proposal):
 indexes={a:pg.build_visual_profile_index_payload(r) for a,r in [('before',before),('after',after)]}
 regs={'before':before,'after':after};negated=[];evidence=[]
 for change in proposal:
  pid=change['profile_id']
  for arm,reg in regs.items():
   p=next(p for p in reg['profiles'] if p['id']==pid)
   for alias in p['activation']['exact_terms']:
    if not alias.isascii():continue
    for prefix in ['avoid ','without ']:
     request=prefix+alias
     result=pg.resolve_visual_profile_hits(reg,[{'source':'user_requirement','text':request,'polarity':'required','priority':'critical','mandatory':True}],visual_profile_index=indexes[arm],query_text=request,query_fields={'active_request':request},adult_context=True)
     target=[h for h in result['hits'] if h['profile_id']==pid]
     assert not any(h.get('hard_eligible') or h.get('optional_eligible') for h in target),(arm,request,target)
     negated.append({'arm':arm,'profile_id':pid,'request':request,'target_hits':target,'passed':True})
   obligation=pg.candidate_pack_visual_profile_obligation(p,reg,activation_source='explicit_request',source_intent_ids=[])
   phrases={field:req['must_mention_any'][0] for field,req in p['evidence_requirements'].items()}
   contract={'enabled':True,'contract_version':audit.VISUAL_OBLIGATIONS_CONTRACT_VERSION,'obligations':[obligation],'required_hard_gates':[g['id'] for g in obligation['render_gates']]}
   failures=audit.audit_visual_obligations({'visual_obligations':contract},{'visual_obligation_evidence':{pid:phrases}},'. '.join(phrases.values()))
   target_failures=[f for f in failures if f.get('field') in change['evidence_fields']]
   if arm=='after':assert not target_failures,(pid,target_failures)
   evidence.append({'arm':arm,'profile_id':pid,'boundary_phrases':{f:phrases[f] for f in change['evidence_fields']},'boundary_field_failures':target_failures,'boundary_fields_passed':not target_failures,'full_profile_failures':failures,'full_profile_passed':not failures,'scope':'Real audit_visual_obligations with all unchanged obligations and standalone anchor phrases; boundary-field pass is not full-profile proof.'})
 return {'negated_exact_aliases':negated,'standalone_field_audits':evidence}

def main():
 initial_hash=digest(REGISTRY);scene_hash=digest(SCENES)
 fixture_paths=list((ROOT/'tests').glob('*lighting*'))+list((ROOT/'tests').glob('*composition*'))+list((ROOT/'tests/fixtures/photo_prompt').glob('*lighting*'))+list((ROOT/'tests/fixtures/photo_prompt').glob('*composition*'))
 fixture_hashes={str(f):digest(f) for f in fixture_paths if f.is_file()}
 before=json.loads(REGISTRY.read_text())
 assert len(before['profiles'])==1419
 assert pg.visual_profile_registry_sha256(before)=='055a6923d80a880b40f58c764e6021b2e21853f6c4fbb1c0184134b0a9973213'
 after=copy.deepcopy(before)
 combined=json.loads(PROPOSAL.read_text())
 proposal=combined['boundary_changes']
 lookup={p['id']:p for p in after['profiles']}
 allowed=set();counts=[]
 for change in proposal:
  p=lookup[change['profile_id']];pi=after['profiles'].index(p)
  groups=p['semantics']['component_semantics']['groups']
  gi=next(i for i,g in enumerate(groups) if g['id']==change['group_id'])
  assert gi==len(groups)-1
  assert groups[gi]['any_terms']==change['old_terms']
  groups[gi]['any_terms']=change['new_terms']
  for j in range(1):allowed.add(f'/profiles/{pi}/semantics/component_semantics/groups/{gi}/any_terms/{j}')
  for field in change['evidence_fields']:
   req=p['evidence_requirements'][field]
   assert req['must_mention_any']==[change['old_terms'][0]]
   req['must_mention_any']=[change['new_terms'][0]]
   allowed.add(f'/profiles/{pi}/evidence_requirements/{field}/must_mention_any/0')
   n=len(authorial_evidence_tokens(change['new_terms'][0]));assert n>=req['min_content_words']
   counts.append({'profile_id':p['id'],'field':field,'content_tokens':n,'minimum':req['min_content_words'],'passed':True})
 for item in combined['paraphrase_changes']:
  p=lookup[item['profile_id']];pi=after['profiles'].index(p)
  for c in item['changes']:
   j=int(c['path'].split('/')[-1]);assert p['semantics']['paraphrase_examples'][j]==c['old']
   p['semantics']['paraphrase_examples'][j]=c['new'];allowed.add(f'/profiles/{pi}/semantics/paraphrase_examples/{j}')
 actual=set(differences(before,after));assert actual==allowed,(actual-allowed,allowed-actual)
 indexes={arm:pg.build_visual_profile_index_payload(reg) for arm,reg in [('before',before),('after',after)]}
 registries={'before':before,'after':after}
 profiles={arm:{p['id']:p for p in reg['profiles']} for arm,reg in registries.items()}
 def resolve(arm,request,context,pid,infer_adult=False):
  rows=[{'source':'user_requirement','text':request,'polarity':'required','priority':'critical','mandatory':True},{'source':'authorial_core_baseline_prompt','text':context,'polarity':'required'}]
  adult=pg.candidate_pack_visual_obligation_adult_context(rows,None) if infer_adult else True
  result=pg.resolve_visual_profile_hits(registries[arm],rows,visual_profile_index=indexes[arm],query_text=request+' '+context,query_fields={'active_request':request,'baseline_prompt':context},adult_context=adult)
  p=profiles[arm][pid]
  return {'adult_context':adult,'request':request,'context':context,'target_hits':[hit for hit in result['hits'] if hit['profile_id']==pid], 'all_hits':result['hits'],'bm25f_evaluated':result['bm25f_evaluated'],'embedding_evaluated':result['embedding_evaluated'],'context_applicability':pg.visual_profile_context_applicability(p,request+' '+context,has_authorial_core_context=True),'component_match':pg.candidate_pack_visual_component_match(p,request+' '+context)}
 canonical=[];exclusions=[];missing=[];aliases=[];original_controls=[]
 for change in proposal:
  pid=change['profile_id']
  for language,li in [('en',0),('ko',1)]:
   if any(len(g['any_terms'])<=li for g in profiles['before'][pid]['semantics']['component_semantics']['groups']):continue
   row={'profile_id':pid,'language':language}
   for arm in registries:
    p=profiles[arm][pid];groups=p['semantics']['component_semantics']['groups'];parts=[g['any_terms'][li] for g in groups]
    context='. '.join(parts)
    row[arm]=resolve(arm,'',context,pid)
    for excluded in p['activation']['exclude_if_any_terms']:
     probe=resolve(arm,'',context+'. Explicitly depict '+excluded+'.',pid)
     assert not probe['target_hits'],(arm,pid,excluded)
     exclusions.append({'arm':arm,'profile_id':pid,'language':language,'excluded_term':excluded,'result':probe})
    for i,g in enumerate(groups):
     probe=resolve(arm,'','. '.join(parts[:i]+parts[i+1:]),pid)
     probe['target_absent']=not bool(probe['target_hits'])
     probe['complete_component_match_absent']=probe['component_match']!='component_semantics'
     missing.append({'arm':arm,'profile_id':pid,'language':language,'omitted_group_id':g['id'],'semantic_discovery_requires_component_evidence':p['activation'].get('semantic_discovery_requires_component_evidence'),'minimum_component_groups':p['semantics']['component_semantics']['minimum_component_groups'],'required_group_ids':p['semantics']['component_semantics']['required_group_ids'],'result':probe})
   assert row['after']['component_match']=='component_semantics',row
   assert any(h['match_basis']=='bm25f' and not h['hard_eligible'] for h in row['after']['target_hits']),row
   canonical.append(row)
   old_context='. '.join(g['any_terms'][li] for g in profiles['before'][pid]['semantics']['component_semantics']['groups'])
   oldrow={'profile_id':pid,'language':language,'frozen_original_context':old_context}
   for arm in registries:oldrow[arm]=resolve(arm,'',old_context,pid)
   oldrow['target_eligibility_preserved']=bool(oldrow['before']['target_hits'])==bool(oldrow['after']['target_hits'])
   assert oldrow['target_eligibility_preserved'],oldrow
   original_controls.append(oldrow)
  for term in profiles['before'][pid]['activation']['exact_terms']:
   row={'profile_id':pid,'alias':term}
   for arm in registries:
    row[arm]=resolve(arm,term,'',pid)
    assert any(h['match_basis']=='exact' and h['hard_eligible'] for h in row[arm]['target_hits']),row
   aliases.append(row)
 scenes=json.loads(SCENES.read_text());scene_pairs=list(dict.fromkeys(s['pair_id'] for s in scenes))
 assert len(scene_pairs)==7 and len(scenes)==14,scene_pairs
 pair_map={'lighting_loop_01':'loop_face_light_pattern','lighting_split_01':'split_face_light_pattern','lighting_lowkey_01':'low_key_selective_illumination','composition_thirds_01':'third_grid_focal_anchor_relation','composition_counterbalance_01':'asymmetric_counterbalance_relation','composition_negative_space_01':'subject_field_negative_space_relation','composition_pattern_break_01':'pattern_break_focal_exception'}
 assert set(scene_pairs)==set(pair_map)
 independent=[]
 for scene in scenes:
  pid=pair_map[scene['pair_id']];row={**scene,'profile_id':pid}
  for arm in registries:row[arm]=resolve(arm,scene['request_ko'],scene['baseline_en'],pid,infer_adult=True)
  row['target_hard_eligibility_changed']=any(h.get('hard_eligible') for h in row['before']['target_hits'])!=any(h.get('hard_eligible') for h in row['after']['target_hits'])
  row['new_hit_ids']=[h['profile_id'] for h in row['after']['all_hits'] if h['profile_id'] not in {x['profile_id'] for x in row['before']['all_hits']}]
  row['target_changed']=row['before']['target_hits']!=row['after']['target_hits']
  row['all_hits_changed']=row['before']['all_hits']!=row['after']['all_hits']
  row['hit_identity_or_order_changed']=[h['profile_id'] for h in row['before']['all_hits']] != [h['profile_id'] for h in row['after']['all_hits']]
  independent.append(row)
 paraphrase_controls=[]
 for item in combined['paraphrase_changes']:
  pid=item['profile_id']
  for c in item['changes']:
   r={'profile_id':pid,'old_single_component':c['old'],'new_full_paraphrase':c['new'],'old':{},'new':{},'new_phrase_exclusions':[]}
   for arm in registries:
    r['old'][arm]=resolve(arm,'',c['old'],pid);r['new'][arm]=resolve(arm,'',c['new'],pid)
   assert not r['old']['after']['target_hits'],r
   assert r['new']['after']['component_match']=='semantic_paraphrase_example',r
   assert any(h.get('optional_eligible') and not h.get('hard_eligible') for h in r['new']['after']['target_hits']),r
   for term in profiles['after'][pid]['activation']['exclude_if_any_terms']:
    x=resolve('after','',c['new']+'; Explicitly depict '+term+'.',pid);assert not x['target_hits'];r['new_phrase_exclusions'].append({'term':term,'result':x})
   paraphrase_controls.append(r)
 summary={'profiles':len(proposal),'changed_leaf_paths':len(actual),'canonical_contexts_per_arm':len(canonical),'canonical_target_present':{arm:sum(bool(r[arm]['target_hits']) for r in canonical) for arm in registries},'canonical_by_language':{lang:{arm:sum(bool(r[arm]['target_hits']) for r in canonical if r['language']==lang) for arm in registries} for lang in ['en','ko']},'excluded_probes_per_arm':len(exclusions)//2,'missing_group_probes_per_arm':len(missing)//2,'retained_alias_probes_per_arm':len(aliases),'independent_scene_count':len(independent),'independent_target_present':{arm:sum(bool(r[arm]['target_hits']) for r in independent) for arm in registries},'independent_target_changes':sum(r['target_changed'] for r in independent),'independent_all_hit_changes':sum(r['all_hits_changed'] for r in independent)}
 assert digest(REGISTRY)==initial_hash and digest(SCENES)==scene_hash
 assert all(digest(pathlib.Path(f))==h for f,h in fixture_hashes.items())
 report={'summary':summary,'caveats':['Canonical contexts use each arm\'s authored phrases; source-derived self-consistency is not held-out benefit.','Independent scenes use actual full-registry resolver/BM25F but lack full generator and normalized authorial-core proof.','No embedding queries, render calls, pixel proof, or ranking-gain claim.','Korean component matching is tested, but English-only evidence token minima do not certify Korean evidence phrases.'],'inputs':{'registry_path':str(REGISTRY),'registry_sha256':initial_hash,'proposal_sha256':digest(PROPOSAL),'independent_scenes_sha256':scene_hash,'pair_mapping':pair_map},'preserved_test_and_fixture_sha256':fixture_hashes,'changed_leaf_paths':sorted(actual),'evidence_minima':counts,'canonical':canonical,'exclusion_injections':exclusions,'missing_required_groups':missing,'retained_exact_aliases':aliases,'independent_scenes':independent,'paraphrase_controls':paraphrase_controls,'frozen_original_component_controls':original_controls,'canonical_registry_sha256_before':pg.visual_profile_registry_sha256(before),'canonical_registry_sha256_after':pg.visual_profile_registry_sha256(after)}
 report.update(extra_controls(before,after,proposal))
 report['summary']['independent_hit_identity_or_order_changes']=sum(r['hit_identity_or_order_changed'] for r in independent)
 report['summary']['negated_alias_controls_per_arm']=len(report['negated_exact_aliases'])//2
 report['summary']['standalone_boundary_fields_passing']={a:sum(r['boundary_fields_passed'] for r in report['standalone_field_audits'] if r['arm']==a) for a in ['before','after']}
 (HERE/'combined-full-resolver-diagnostic.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
 (HERE/'combined-registry-after-in-memory.json').write_text(json.dumps(after,ensure_ascii=False,indent=2)+'\n')
 summary['old_single_components_after_target_hits']=sum(bool(r['old']['after']['target_hits']) for r in paraphrase_controls)
 summary['new_full_paraphrases_after_optional_hits']=sum(any(h.get('optional_eligible') for h in r['new']['after']['target_hits']) for r in paraphrase_controls)
 print(json.dumps(summary,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
