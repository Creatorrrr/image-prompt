# Combined boundary14 + paraphrase9 unpublished trial

Recommendation: ACCEPT as a DATA-only candidate for subsequent integration review. The 23-string trial fixes source self-exclusion and the lighting single-component paraphrase loophole together. It does not demonstrate independent natural-scene target retrieval or pixel meaning.

## Identity and preservation

Frozen merged registry: 1,419 profiles at source HEAD a21a08cb6e95fda0dd8f430fe68481878e5ea581.
Before canonical SHA: 055a6923d80a880b40f58c764e6021b2e21853f6c4fbb1c0184134b0a9973213
Combined after canonical SHA: 19877f7916d9f308a6558a0e5331f7fec96ad3679eebd3fb4a5862d2e261c63f

Exactly 23 scalar string changes: seven final English component terms, seven matching evidence anchors, and nine English paraphrase examples. Existing Korean, all activation/exclusion/discovery flags, aliases, required/minimum groups, evidence floors, definitions, contrasts, rejects and render gates remain unchanged. Original boundary14 artifacts and all independent scenes remain preserved. No repository edits or APIs were used.

## Results

- Canonical EN optional targets: 0/7 before, 7/7 after
- Original KO optional targets: 4/4 before and after
- Canonical affirmative exclusion probes: all 47 blocked per arm
- Exact aliases: all 28 retain exact hard eligibility per arm
- Negated EN aliases: all 28 blocked per arm
- Omitted-required-group optional targets: 3/47 before, 0/47 combined after (boundary14 alone had 15/47)
- Omitted-group complete component matches and hard hits: zero before and after
- Nine old single-component strings: 9/9 optional hits before, 0/9 after
- Nine new complete-relation paraphrases: 0/9 optional hits before, 9/9 after, with no hard hits
- New full-paraphrase plus affirmative exclusion: all 45 probes blocked
- Real standalone boundary-field audits: 6/7 before, 7/7 after
- Full-profile standalone-anchor audits: unchanged 4/7, due to previously documented unchanged nonboundary evidence floors

Replacing partial paraphrase examples with complete relation descriptions removes the fallback that previously let incomplete lighting component bundles qualify for optional discovery. The same resolver still returns semantic_paraphrase_example for the nine complete descriptions. No code, group threshold, or discovery flag was altered.

These nine descriptions are reviewed, authored source controls, not held-out natural-language retrieval evidence. They establish the intended optional route and the rejection of old partial aliases without claiming general semantic recall.

## Independent scenes with actual adult inference

All 14 fixed scenes use candidate_pack_visual_obligation_adult_context(source_rows, None): six true, eight false. Intended targets remain 0/14 in both arms. No negative scene gains new hit IDs. No target hard eligibility changes.

Two positive scene lists change:
1. Thirds buoy: rank 8 changes pc_pc16_owner_relation to pr_surface_wear_contact_owner, as in boundary14.
2. Counterbalance: ranks 7 and 8 swap mep_visual_juxtaposition and y2kr_asym_top; the set of IDs is unchanged.

All four involved candidate documents and the tokenizer lexicon are unchanged. A separate counterfactual restores the old document frequencies and average field lengths in the combined index, reproducing the exact original scores and orders for both pairs. Thus both changes are corpus-statistics effects on the lexical shortlist, not new scene meaning or target retrieval improvements.

Counterbalance scores: mep_visual_juxtaposition 42.137416715610 to 41.972492396083; y2kr_asym_top 42.097828618874 to 42.106097573404. The buoy scores are separately recorded in combined-rank-change-causes.json.

## Files

- combined-proposal-boundary14-paraphrase9.json: complete combined proposal with exact old/new strings
- diagnose_combined_full_resolver.py: reusable frozen full-resolver comparison
- combined-full-resolver-diagnostic.json: original combined measurements
- combined-full-resolver-diagnostic-enriched.json: explicit flags, eligibility and scene-change annotations
- combined-full-resolver-summary.json: concise results
- combined-registry-after-in-memory.json: hypothetical merged registry
- explain_combined_rank_changes.py and combined-rank-change-causes.json: exact corpus-statistics causal isolation

All existing source/test fixtures are read-only; their preserved hashes are recorded in the combined diagnostic. Original before canonical component text is replayed unchanged as an additional regression control. The nine partial lighting paraphrases are deliberately corrected invalid-scope controls, not rewritten valid full-relation fixtures.
