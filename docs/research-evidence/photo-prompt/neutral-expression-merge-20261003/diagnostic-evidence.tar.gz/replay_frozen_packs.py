from pathlib import Path
import hashlib,json,os,subprocess
ROOT=Path.cwd();E=ROOT/'output/neutral-expression-merge-20261003';N=ROOT/'docs/research-evidence/photo-prompt/neutral-expression-native-qualification-20261003'
def diff(a,b,p='$'):
 if type(a)!=type(b):return [{'path':p,'before':a,'after':b}]
 if isinstance(a,dict):return [r for k in sorted(set(a)|set(b)) for r in ([{'path':p+'.'+k,'before':a.get(k),'after':b.get(k)}] if k not in a or k not in b else diff(a[k],b[k],p+'.'+k))]
 if isinstance(a,list):return [{'path':p,'before':a,'after':b}] if len(a)!=len(b) else [r for i,(aa,bb) in enumerate(zip(a,b)) for r in diff(aa,bb,f'{p}[{i}]')]
 return [] if a==b else [{'path':p,'before':a,'after':b}]
rows=[]
for arm in 'abc':
 f=N/f'arm-{arm}';before=f/'candidate_pack.json';old=json.loads(before.read_text());after=E/f'arm-{arm}-merged-pack.json';seed=old[0]['provenance']['seed']
 argv=['.venv/bin/python','skills/photo-prompt-image-generator/scripts/generate_photo_prompt.py','--request-envelope-json',str(f/'request_envelope.json'),'--authorial-core-json',str(f/'authorial_core.json'),'--creative-controls-json',str(f/'creative_controls.json'),'--embodiment-review-json',str(f/'embodiment_review.json'),'--seed',str(seed),'--output-file',str(after)]
 proc=subprocess.run(argv,cwd=ROOT,env=dict(os.environ,GEMINI_API_KEY='',GOOGLE_API_KEY=''),text=True,capture_output=True,timeout=180);(E/f'arm-{arm}-replay.log').write_text(proc.stdout+proc.stderr);assert proc.returncode==0,(arm,proc.stdout,proc.stderr)
 changes=diff(old,json.loads(after.read_text()));row={'arm':arm.upper(),'cli_returncode':0,'original_pack_sha256':hashlib.sha256(before.read_bytes()).hexdigest(),'merged_pack_sha256':hashlib.sha256(after.read_bytes()).hexdigest(),'pack_bytes_equal':before.read_bytes()==after.read_bytes(),'diff_count':len(changes),'diff':changes,'frozen_core_file_sha256':hashlib.sha256((f/'authorial_core.json').read_bytes()).hexdigest(),'new_image_calls':0};rows.append(row);print(json.dumps({k:v for k,v in row.items() if k!='diff'}),flush=True)
baseline=json.loads((ROOT/'skills/subculture-illustration-image-generator/assets/photo_regression_baseline_v5.json').read_text());argv=baseline['command'][:];after=E/'current-boundary-merged.json';argv[argv.index('--output-file')+1]=str(after);proc=subprocess.run(argv,cwd=ROOT,env=dict(os.environ,GEMINI_API_KEY='',GOOGLE_API_KEY=''),text=True,capture_output=True,timeout=120);(E/'current-boundary-replay.log').write_text(proc.stdout+proc.stderr);assert proc.returncode==0,(proc.stdout,proc.stderr);digest=hashlib.sha256(after.read_bytes()).hexdigest();assert digest==baseline['sha256']
result={'method':'Normal public V6 CLI with original immutable core/envelope/controls/review and recorded pack seed','arms':rows,'current_sibling_boundary_bytes_equal':True,'current_sibling_boundary_sha256':digest,'new_native_image_calls':0,'old_pixel_results_not_relabelled_as_new_generation':True}
(E/'FROZEN-PACK-REPLAY.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print('Current sibling boundary matches reviewed SHA.',flush=True)
