"""Freeze evidence from the completed merge validation without changing runtime data."""
from __future__ import annotations

import hashlib
import json
import re
import subprocess
import tarfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).parent
PUBLIC = ROOT / 'docs/research-evidence/photo-prompt/neutral-expression-merge-20261003'


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    results = json.loads((OUT / 'full-suite/RESULTS.json').read_text())
    discovery = json.loads((OUT / 'full-suite/DISCOVERY.json').read_text())
    assert results['status'] == 'PASS', results
    assert results['discovered_test_count'] == results['tests_run'] == len(discovery['test_ids'])
    assert results['all_discovered_ids_executed']
    assert results['failed_batch_count'] == 0
    assert len(results['batches']) == results['batch_count']
    for batch in results['batches']:
        assert batch['status'] == 'PASS' and batch['returncode'] == 0
        assert sha(ROOT / batch['log']) == batch['log_sha256']
    skipped = sum(int(n) for batch in results['batches'] for n in re.findall(r'skipped=(\d+)', (ROOT / batch['log']).read_text()))
    assert skipped == 0, f'{skipped} skipped tests require an explicit qualification'
    inputs = json.loads((OUT / 'OPERATIONAL-INPUTS.json').read_text())
    changed = [entry['path'] for entry in inputs['inputs'] if sha(Path(entry['path'])) != entry['sha256']]
    assert not changed, changed
    assert len(inputs['inputs']) == 92
    replay = json.loads((OUT / 'FROZEN-PACK-REPLAY.json').read_text())
    assert all(arm['pack_bytes_equal'] and arm['cli_returncode'] == 0 for arm in replay['arms'])
    assert replay['current_sibling_boundary_bytes_equal']
    subprocess.run(['git', 'diff', '--cached', '--check'], cwd=ROOT, check=True)
    assert not subprocess.check_output(['git', 'diff', '--name-only'], cwd=ROOT, text=True).strip()
    assert not subprocess.check_output(['git', 'diff', '--name-only', '--diff-filter=U'], cwd=ROOT, text=True).strip()

    members = [(p, str(p.relative_to(OUT))) for p in sorted((OUT / 'full-suite').rglob('*')) if p.is_file()]
    for name in ('full-suite.log', 'replay_frozen_packs.py', 'FROZEN-PACK-REPLAY.json', 'OPERATIONAL-INPUTS.json', 'AUTHORED-PRESERVATION.json', 'INDEX-VERIFICATION.json', 'VALIDATORS.json'):
        members.append((OUT / name, name))
    for pattern in ('arm-*-merged-pack.*', 'current-boundary-merged.*'):
        members.extend((p, p.name) for p in sorted(OUT.glob(pattern)) if p.is_file())
    runner = ROOT / 'docs/research-evidence/photo-prompt/neutral-expression-integration-20261003/run_full_suite.py'
    members.append((runner, 'runner/run_full_suite.py'))
    members.append((Path(__file__), 'runner/finalize_evidence.py'))
    archive = PUBLIC / 'diagnostic-evidence.tar.gz'
    with tarfile.open(archive, 'w:gz') as tar:
        for path, arcname in members:
            tar.add(path, arcname=arcname, recursive=False)
    manifest = {
        'archive': archive.name,
        'archive_sha256': sha(archive),
        'archive_bytes': archive.stat().st_size,
        'members': [{'path': arcname, 'sha256': sha(path), 'bytes': path.stat().st_size} for path, arcname in members],
    }
    (PUBLIC / 'diagnostic-evidence-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    validation = {
        'status': 'PASS',
        'local_parent': '96f938e264a3ce4fdfc22bbc3d9548583059c5b0',
        'pulled_parent': '7307343d59bcd09624c2ea2aad461d8d5d9dd026',
        'full_suite': {key: value for key, value in results.items() if key != 'batches'},
        'skipped_test_count': skipped,
        'operational_input_count': len(inputs['inputs']),
        'operational_input_manifest_sha256': sha(OUT / 'OPERATIONAL-INPUTS.json'),
        'operational_inputs_unchanged_through_full_suite': not changed,
        'three_original_v6_packs_bytes_equal': all(arm['pack_bytes_equal'] for arm in replay['arms']),
        'current_sibling_boundary_bytes_equal': replay['current_sibling_boundary_bytes_equal'],
        'embedding_api_calls_for_merged_index': 0,
        'new_native_image_calls': 0,
        'git_unmerged_paths': [],
        'tracked_unstaged_paths': [],
        'staged_diff_whitespace': 'PASS',
        'diagnostic_archive_sha256': manifest['archive_sha256'],
    }
    (PUBLIC / 'VALIDATION.json').write_text(json.dumps(validation, indent=2) + '\n')
    readme = PUBLIC / 'README.md'
    old = '전체 unittest discovery 결과는 완료 후 `VALIDATION.json`에 저장한다.'
    new = f"전체 unittest discovery에서 {results['discovered_test_count']:,}개 테스트를 {results['batch_count']}개 독립 배치로 실행했고 모두 통과했다. 실패 배치 0개이며 발견된 ID 전체가 실행됐음을 확인했다. 검사 전후 운영 입력 92개의 SHA-256도 같았다. 결과는 `VALIDATION.json`에 저장했다."
    content = readme.read_text()
    assert old in content
    content = content.replace(old, new).replace('- [양쪽 원본·blob 보존]', '- [전체 검증 결과](VALIDATION.json)\n- [전체 진단 증거 SHA-256](diagnostic-evidence-manifest.json)\n- [양쪽 원본·blob 보존]')
    readme.write_text(content)
    print(json.dumps(validation, indent=2))
    print(f'Archived {len(members)} files; {archive.stat().st_size} bytes.')


if __name__ == '__main__':
    main()
