"""Bounded, source-exposed maintenance inspection; no production mutations."""
import hashlib,json,subprocess,sys
from pathlib import Path
sys.dont_write_bytecode=True
R=Path('/workspace/scratch/ce8f20680f5a/image-prompt'); O=Path(__file__).parent
S=R/'skills/photo-prompt-image-generator';sys.path.insert(0,str(S/'scripts'))
import prompt_generator as g
IDS=['pf_motte_bailey','pf_gate_sequence','pf_window_seat','pf_double_helix','pf_roofless_ruin','pf_garden_grotto']
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
registry=g.load_visual_obligation_registry(S/'assets/photo_prompt_visual_obligations.json')
index=g.load_visual_profile_index(S/'assets/photo_prompt_visual_profile_index.json',registry)
ps={p['id']:p for p in registry['profiles'] if p['id'] in IDS}
draft=json.loads((R/'docs/research-evidence/photo-prompt/palace-fortification-20260909/candidate-drafts.json').read_text())
extension=json.loads((S/'assets/photo_prompt_palace_fortification_extension.json').read_text())
sources=json.loads((R/'docs/research-evidence/photo-prompt/palace-fortification-20260909/sources.json').read_text())
ds={p['id']:p for p in draft['profiles'] if p['id'] in IDS}
source_ids={s for p in ds.values()for s in p['source_ids']}
write(O/'bounded-source-sample.json',{'scope':IDS,'provenance':'Source-exposed maintenance selection; not independent or natural-query sampling.','profiles':[ps[i]for i in IDS],'research_drafts':[ds[i]for i in IDS],'research_source_records':[s for s in sources['sources']if s['id']in source_ids],'extension_visual_semantics':[p for p in extension['visual_semantics']if p['id']in IDS],'extension_slots':{k:[p for p in v if any(p['id'].startswith(i+'_')for i in IDS)]for k,v in extension['slots'].items()}})
variants={
 'pf_gate_sequence':('unbounded_approach',' 두 입구 사이의 길은 난간이나 담으로 경계를 두르지 않은 넓은 광장을 가로지른다.'),
 'pf_window_seat':('timber_recess',' 벽은 두꺼운 원목 구조이며, 벽 속 고정 좌석과 창 측벽도 원목으로 이어진다.'),
 'pf_double_helix':('parallel_straight_flights',' 두 계단은 빈 중앙 공간의 양쪽에서 곧게 오르는 평행 직선 계단이다.'),
 'pf_roofless_ruin':('cleared_floor',' 파손된 상부 벽의 잘린 단면이 선명하며, 바닥의 떨어진 돌과 벽돌은 모두 치워져 매끈한 석판만 남아 있다.'),
}
cases=[]
for pid in IDS:
 for lang,t in zip(['en','ko'],ps[pid]['activation']['exact_terms']):
  cases.append({'id':pid+'_'+lang+'_exact','profile_id':pid,'kind':'source_exact_control','text':t})
 if pid in variants:
  label,suffix=variants[pid];cases.append({'id':pid+'_'+label,'profile_id':pid,'kind':'compatible_counterexample_candidate','text':ps[pid]['activation']['exact_terms'][1]+'.'+suffix})
# The obvious waterless and solid-core alternatives contradict explicit Korean facts;
# they are recorded as exclusions from the DATA-bug claim, never positive examples.
write(O/'frozen-resolver-cases.json',{'cases':cases,'claim_exclusions':['pf_motte_bailey without any connection between upper/lower levels contradicts the Korean approach continuity','pf_double_helix with a solid center contradicts the Korean visibly empty shared center','pf_garden_grotto without a water feature contradicts the Korean cave/water-feature design-space fact','pf_window_seat movable furniture in front of the window contradicts the Korean final clause']})
rows=[]
data={g.VISUAL_OBLIGATIONS_DATA_KEY:registry,g.VISUAL_PROFILE_INDEX_DATA_KEY:index}
for c in cases:
 text=c['text'];result={'provenance':{'prompt_id':c['id'],'concept_lock':[text]}}
 resolution=g.resolve_visual_profile_hits(registry,[{'source':'concept_lock','text':text,'polarity':'required','priority':'critical','mandatory':True}],visual_profile_index=index,adult_context=False)
 ob=g.candidate_pack_visual_obligations(data,result,{},None,resolution)
 rows.append({**c,'hard_profile_ids':[h['profile_id']for h in resolution['hits']if h.get('hard_eligible')],'target_hits':[h for h in resolution['hits']if h['profile_id']==c['profile_id']],'target_obligations':[x for x in (ob or{}).get('obligations',[])if x['id']==c['profile_id']]})
write(O/'merged-resolver-results.json',{'merged_registry_profile_count':len(registry['profiles']),'real_visual_index':True,'query_vector_supplied':False,'provider_calls':0,'cases':rows})
paths=['skills/photo-prompt-image-generator/SKILL.md','skills/photo-prompt-image-generator/references/maintenance.md','skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations_palace_fortification.json','skills/photo-prompt-image-generator/assets/photo_prompt_palace_fortification_extension.json','skills/photo-prompt-image-generator/assets/photo_prompt_visual_profile_index.json','docs/research-evidence/photo-prompt/palace-fortification-20260909/candidate-drafts.json','docs/research-evidence/photo-prompt/palace-fortification-20260909/install-runtime.py','docs/research-evidence/photo-prompt/palace-fortification-20260909/sources.json','docs/research-evidence/photo-prompt/palace-fortification-20260909/implementation-report.md','docs/research-evidence/photo-prompt/extension-maintenance/photo_prompt_palace_fortification_extension.json']
history={}
raw_current={p['id']:p for p in json.loads((S/'assets/photo_prompt_visual_obligations_palace_fortification.json').read_text())['profiles']}
for rev in ['b6e70b78','b4120b84']:
 old=json.loads(subprocess.check_output(['git','show',rev+':skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations_palace_fortification.json'],cwd=R,text=True))
 historical={p['id']:p for p in old['profiles']}
 history[rev]={pid:historical[pid]==raw_current[pid]for pid in IDS}
write(O/'source-manifest.json',{'repository_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'git_status_porcelain':subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True),'sources':{p:sha(R/p)for p in paths},'six_selected_profiles_unchanged_from_history':history,'probe_cases':len(rows)})
print(json.dumps([{'case':r['id'],'hard':r['hard_profile_ids']}for r in rows],ensure_ascii=False,indent=2))
