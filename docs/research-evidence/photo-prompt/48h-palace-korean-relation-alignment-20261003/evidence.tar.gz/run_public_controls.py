"""Unmodified public generator and composed auditor, six frozen controls."""
import concurrent.futures,copy,hashlib,json,os,subprocess,sys,time
from pathlib import Path
sys.dont_write_bytecode=True
R=Path('/workspace/scratch/ce8f20680f5a/image-prompt');O=Path(__file__).parent;S=R/'skills/photo-prompt-image-generator'
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((O/'frozen-public-input-manifest.json').read_text());env={k:v for k,v in os.environ.items()if not any(x in k.upper()for x in ['TOKEN','API_KEY','CREDENTIAL'])};env['PYTHONDONTWRITEBYTECODE']='1'
def run(c):
 d=O/'public-controls'/c['id']
 for name,h in c['files'].items():assert sha(d/name)==h,(c['id'],name)
 cmd=[sys.executable,str(S/'scripts/generate_photo_prompt.py'),'--request-envelope-json',str(d/'request-envelope.json'),'--authorial-core-json',str(d/'authorial-core.json'),'--creative-controls-json',str(d/'creative-controls.json'),'--embodiment-review-json',str(d/'embodiment-review.json'),'--seed',str(manifest['seed']),'--output-file',str(d/'candidate-pack.json')]
 started=time.time();r=subprocess.run(cmd,cwd=R,env=env,capture_output=True,text=True,timeout=300);(d/'generation.stdout.txt').write_text(r.stdout);(d/'generation.stderr.txt').write_text(r.stderr)
 row={'case':c['id'],'profile_id':c['profile_id'],'role':c['role'],'generation':{'command':cmd,'returncode':r.returncode,'seconds':round(time.time()-started,3),'stderr':r.stderr}}
 if r.returncode:return row
 p=json.loads((d/'candidate-pack.json').read_text())[0];core=p['authorial_core'];lock=core['intent_lock'];b=core['baseline_prompt_en'];review=copy.deepcopy(p['embodiment_preflight']['baseline_review']);review['provenance']='agent_postcomposition'
 hard=(p.get('visual_obligations')or{}).get('obligations',[]);conflict=c['role']=='compatible_ko'and any(x['id']==c['profile_id']for x in hard)
 composed={'core_retrieval_sha256':p['core_retrieval']['canonical_sha256'],'pack_id':p['pack_id'],'prompt_en':b,'negative_en':p['negative_en'],'chosen_candidate_ids':[],'chosen_visual_concept_ids':[],'composer':'agent','embodiment_review':{'source_contract_sha256':p['embodiment_preflight']['canonical_sha256'],'review':review},'candidate_interpretations':[],'authorial_core_binding':{'source_authorial_core_sha256':core['canonical_sha256'],'source_intent_lock_sha256':lock['canonical_sha256'],'preserved_anchor_ids':[x['anchor_id']for x in lock['semantic_anchors']],'preserved_evidence':[],'authorial_decisions':[]},'semantic_clarification_decisions':[],'creative_augmentation_brief':{'decisions':[{'candidate_id':x['id'],'decision':'rejected','rationale':'Preserve the complete frozen architectural request and decline optional scene changes'}for x in p['creative_augmentation']['candidates']]}}
 for x in p['semantic_clarification']['candidates']:
  incompatible=conflict and x.get('profile_id')==c['profile_id']
  composed['semantic_clarification_decisions'].append({'clarification_id':x['id'],'decision':'applied'if x.get('required_in_final_prompt')and not incompatible else'rejected','rationale':'This selected variant would replace a frozen requested relation; preserve the actual request instead'if incompatible else'Preserve the frozen requester-owned architecture and decline optional reinterpretations','prompt_evidence':c['components'][c['changed_index']]if x.get('source')=='visual_meaning_registry'else lock['semantic_anchors'][0]['prompt_evidence']})
 contract=p.get('semantic_assertion_obligations')
 if contract:composed['semantic_assertion_evidence']={'source_contract_sha256':contract['canonical_sha256'],'evidence':{x['assertion_id']:x['frozen_evidence']for x in contract['obligations']}}
 if hard:
  evidence={}
  for ob in hard:
   evidence[ob['id']]={}
   for name,req in ob['evidence_requirements'].items():
    phrases=[s for s in req.get('must_mention_any',[])if s in b]
    if phrases:evidence[ob['id']][name]=phrases[0]
    elif ob['id']==c['profile_id']and name=='component_'+str(c['changed_index']+1)+'_phrase':evidence[ob['id']][name]=c['components'][c['changed_index']]
    else:raise ValueError((c['id'],ob['id'],name,'No actual baseline evidence; never fabricate'))
  composed['visual_obligation_evidence']=evidence
 assert composed['prompt_en']==core['baseline_prompt_en'];assert all(v in b for fields in composed.get('visual_obligation_evidence',{}).values()for v in fields.values())
 write(d/'composed-baseline.json',composed)
 cmd=[sys.executable,str(S/'scripts/audit_composed_prompt.py'),'--pack',str(d/'candidate-pack.json'),'--composed',str(d/'composed-baseline.json')]
 started=time.time();a=subprocess.run(cmd,cwd=R,env=env,capture_output=True,text=True,timeout=300);(d/'composed-audit.stdout.json').write_text(a.stdout);(d/'composed-audit.stderr.txt').write_text(a.stderr);audit=json.loads(a.stdout)if a.stdout.strip().startswith('{')else None
 row.update({'pack_id':p['pack_id'],'pack_sha256':sha(d/'candidate-pack.json'),'pack_bytes':(d/'candidate-pack.json').stat().st_size,'hard_profile_ids':[ob['id']for ob in hard],'target_obligations':[ob for ob in hard if ob['id']==c['profile_id']],'baseline_unchanged':True,'evidence_literal_and_truthful':True,'chosen_candidate_ids':[],'chosen_visual_concept_ids':[],'incompatible_hard_duty':conflict,'audit':{'command':cmd,'returncode':a.returncode,'seconds':round(time.time()-started,3),'stderr':a.stderr,'result':audit},'input_hashes_preserved':all(sha(d/n)==h for n,h in c['files'].items())})
 print(c['id'],'generation',r.returncode,'hard',row['hard_profile_ids'],'audit',(audit or{}).get('status'),flush=True)
 return row
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:rows=list(pool.map(run,manifest['cases']))
write(O/'public-control-results.json',{'scope':'Six source-exposed diagnostic cases through unmodified public generation and composed auditing. Real merged runtime assets, no explicit visual intent, zero optional adoption, unchanged baseline prose and truthful literal evidence.','provider_calls':0,'cases':rows})
print(json.dumps([{'case':r['case'],'generation':r['generation']['returncode'],'audit':r.get('audit',{}).get('result',{}).get('status'),'failures':r.get('audit',{}).get('result',{}).get('failures')}for r in rows],ensure_ascii=False,indent=2))
