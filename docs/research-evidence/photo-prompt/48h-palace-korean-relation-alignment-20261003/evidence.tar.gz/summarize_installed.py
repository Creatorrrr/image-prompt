from pathlib import Path
import json,hashlib,subprocess,re,sys
D=Path(__file__).resolve().parent;O=D/'production-integration';R=D.parent.parent/'image-prompt';S=R/'skills/photo-prompt-image-generator';sys.dont_write_bytecode=True;sys.path.insert(0,str(S/'scripts'));import prompt_generator as g
sha=lambda b:hashlib.sha256(b).hexdigest()
before=json.loads((O/'before/results.json').read_text());after=json.loads((O/'after/results.json').read_text());assert len(before)==len(after)==18
assert all(all(r['same_as_reviewed_qualification'].values())for r in before+after)
assert sum(x['audit_passed']for x in before)==15 and all(x['audit_passed']for x in after)
tests=json.loads((O/'tests/results.json').read_text());assert len(tests)==14 and all(x['returncode']==0 for x in tests),tests
counts={}
for row in tests:
 if row['file']=='dictionary-validation':continue
 s=(O/'tests'/(row['file']+'.log')).read_text();m=re.search(r'Ran (\d+) tests?',s);assert m,row;counts[row['file']]=int(m[1])
old=json.loads(subprocess.check_output(['git','show','HEAD:skills/photo-prompt-image-generator/assets/photo_prompt_visual_profile_index.json'],cwd=R))
new=json.loads((S/'assets/photo_prompt_visual_profile_index.json').read_text());assert old['entries']==new['entries'] and len(new['entries'])==1622
rawold=json.loads(subprocess.check_output(['git','show','HEAD:skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations_palace_fortification.json'],cwd=R));rawnew=json.loads((S/'assets/photo_prompt_visual_obligations_palace_fortification.json').read_text());diff=[]
def walk(a,b,p='$'):
 if type(a)!=type(b):diff.append(p);return
 if isinstance(a,dict):
  assert a.keys()==b.keys()
  for k in a:walk(a[k],b[k],p+'.'+k)
 elif isinstance(a,list):
  assert len(a)==len(b)
  for i,(x,y)in enumerate(zip(a,b)):walk(x,y,p+'['+str(i)+']')
 elif a!=b:diff.append(p)
walk(rawold,rawnew);assert len(diff)==3 and all(p.endswith('.activation.exact_terms[1]')for p in diff)
reg=g.load_visual_obligation_registry(S/'assets/photo_prompt_visual_obligations.json');g.validate_visual_profile_index_metadata(new,reg)
try:g.validate_visual_profile_index_metadata(old,reg)
except ValueError as e:stale=str(e)
else:raise AssertionError('Stale index accepted')
boundary=json.loads((O/'current-boundary-delta.json').read_text());assert not boundary['leaf_diffs']
out={'status':'installed-validation-pass','source_pin':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'public_matrix':{'cases':18,'executions':36,'before_audit_pass':15,'before_expected_fail':3,'after_audit_pass':18,'all_pack_composition_audit_objects_equal_reviewed':True},'tests':counts,'focused_test_method_count':sum(counts.values()),'dictionary_validation':'pass','visual_profile_count':1622,'unchanged_visual_entries':1622,'actual_source_leaf_differences':diff,'registry_hash':g.visual_profile_registry_sha256(reg),'stale_index_rejection':stale,'boundary_delta':boundary,'provider_calls':0,'images':0,'regression_test_before':{'methods':6,'assertion_failures_including_subtests':9,'harness_failures_excluded':['wrong external test-root path','wrapper ran zero tests; corrected module namespace']},'integration_harness_failure':'Initial runner syntax error before any test execution; preserved and corrected','limitations':['Nine automatic profile gates lost on three fully explicit legacy-positive requests','Generic anchors do not replace pixel gates','Source-guided and theme-targeted synthetic controls are not natural query accuracy','Full historical v9 byte baseline still red from earlier nape/opacity changes; no new boundary difference here']}
(O/'SUMMARY.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps(out,ensure_ascii=False,indent=2))
