# Palace exact-trigger relation audit

## Result

Three inherited Korean exact-trigger gaps are concretely reproduced through the current public generator and composed auditor:

1. `pf_window_seat`: the Korean trigger omits the masonry material of the same wall recess
2. `pf_double_helix`: it omits the helical flights winding around the common core
3. `pf_roofless_ruin`: it omits fallen masonry below the broken upper structure

The six public packs all admit. The three complete English selected-variant controls pass composed audit. The three logically compatible Korean controls retain their frozen requests/baselines, automatically acquire the stronger target profile, and fail composed audit on that profile's missing component evidence and the attempt to reject its mandatory clarification. No optional candidates or visual concepts were adopted.

These are **source-exposed maintenance controls**, not naturally sampled requests, independent linguistic holdouts, natural-query accuracy, or image-quality evidence. Manual semantic comparison establishes why the requests are compatible with the Korean facts; the deterministic audit establishes only the resulting literal hard-duty conflict. The auditor is not a semantic contradiction oracle.

## Scope and pin

- Repository: `/workspace/scratch/ce8f20680f5a/image-prompt`
- Starting and finishing HEAD: `ca0f6d80c85e2538883da9a5a0e01818dfe7df0c`
- Exactly six profiles inspected: motte/bailey, gate sequence, window seat, double helix, roofless ruin, garden grotto
- Applicable `SKILL.md` and `references/maintenance.md` read
- Production source/index/code edits: zero; provider calls: zero; images: zero; Git writes: zero
- Portcullis and drawbridge are excluded from discovery counts. PR5 runtime work was not touched
- Artifact footprint is approximately 2.4 MB, including six actual public packs; no repository or index copies were made

## Six-profile dispositions

| Profile | Disposition | Reason |
|---|---|---|
| `pf_motte_bailey` | KEEP in this bounded audit | Summit/tower contact, distinct lower defended area, and connecting approach already encode the ordinary selected relationship. A tower founded beside the mound with its upper side touching the summit is a possible narrower semantic challenge, but is too interpretation-dependent to promote here. No claim of universal equivalence is made. Ascent is not separately counted as omitted: the connected upper/lower levels already support it |
| `pf_gate_sequence` | DEFER | The Korean approach clause does not expressly say bounded. An open-plaza approach still activates the exact profile in the merged resolver. However, the tested text excludes rails/walls, while the English word “bounded” can include other boundaries. The stronger no-boundary claim and main-doorway/passage ownership require cleaner controls. No public qualification or source-edit proposal is claimed |
| `pf_window_seat` | PROPOSE narrow DATA correction | All Korean facts allow a fixed seat in a thick timber recess. The public control explicitly exposes end grain and timber joinery through the full depth of the same wall and side reveals. This is neither a wooden bench inside masonry nor a claim about hidden structural construction. The automatic profile instead requires a masonry recess |
| `pf_double_helix` | PROPOSE narrow DATA correction | Two straight, parallel, separately continuous stairs beside a shared visibly open central space satisfy all three Korean clauses. The Korean trigger contains no winding or helical phrase. The automatic profile adds winding/helical geometry |
| `pf_roofless_ruin` | PROPOSE narrow DATA correction | A roofless former room can retain walls, windows, floor and broken upper structural boundaries after all loose stones/bricks have been removed. The Korean damage clause does not require rubble remaining on the floor. The automatic profile does |
| `pf_garden_grotto` | DEFER | Artificial chamber, garden connection and a water feature are already explicit. Waterless/natural-cave counterexamples would contradict those facts and are excluded. A cave-like facade with a constructed space behind it could expose a surrounding/placement gap, but “crafted rockwork surrounds” versus surface/entrance treatment needs a less ambiguous same-owner control. No hard material distinction between real rock and artificial rockwork is inferred |

The deferred possibilities are retained as hypotheses, not inflated into confirmed bugs. An independent semantic review raised these same stronger possibilities; this report deliberately qualifies only the three clear cases tested through normal consumers.

## Actual merged-resolver sample

`probe_resolver.py` loads the full merged production registry and its real, registry-bound visual index. It does not create a reduced or fake index, supply a query vector, or modify resolver behavior.

- 12 source-exact controls: the English and Korean exact string for each of six profiles
- Four compatible-counterexample candidates: open approach, same-wall timber recess, straight stair flights, cleared ruin floor
- 16/16 activate their target profile as an exact hard obligation

This is an activation observation. In particular, the open-approach candidate remains semantically unqualified as described above. All complete outputs and emitted evidence/render duties are in `merged-resolver-results.json`.

## Public controls

All six envelopes, controls, v3 cores, intent locks, assertions and embodiment reviews were normalized and frozen before the six public generation calls. The controls were authored after inspecting source data and are expressly synthetic maintenance fixtures. No unexposed pre-core or real user-request claim is made.

| Pair | Compatible Korean case | Complete English selected-variant control |
|---|---|---|
| Window seat | Pack admitted; `pf_window_seat` hard; audit FAIL at `component_1_phrase` requiring “a built-in seat occupies the depth of the masonry recess” | Pack admitted; same target hard; audit PASS |
| Double helix | Pack admitted; `pf_double_helix` hard; audit FAIL at `component_1_phrase` requiring “two distinct helical stair flights wind around one core” | Pack admitted; same target hard; audit PASS |
| Roofless ruin | Pack admitted; `pf_roofless_ruin` hard; audit FAIL at `component_3_phrase` requiring “localized fallen masonry lies below the broken upper structure” | Pack admitted; same target hard; audit PASS |

Each compatible case has exactly one component-evidence failure plus `semantic_clarification_required` because the composition truthfully rejects the incompatible mandatory meaning. Every evidence string actually occurs in its unchanged baseline. There are no forged hashes, missing-evidence placeholders, unrelated failure gates, or fabricated accepted evidence. The complete English controls show that the authoring/composition adapter can satisfy the same public path. The fixed English evidence phrases are used as indivisible declared anchors; they are not reinterpreted as conjunctions.

The six audit outputs retain their ordinary warnings. Those warnings do not change the PASS/FAIL status and are not hidden or presented as full photographic-quality qualification. No attempt was made to fix optional photographic-integration warnings by changing frozen prose.

## Source history and authority

All six raw profile objects are unchanged from historical commits `b6e70b78` and `b4120b84`. The recent portcullis correction did not introduce these discrepancies. A raw-source-to-raw-source comparison, rather than comparing a normalized registry object to a raw historical object, is recorded in `source-manifest.json`.

The original `palace-fortification-20260909/install-runtime.py` builds Korean exact terms by joining the research draft's Korean component-gate descriptions, but defines English components from a separately authored operationalization list. Its lines 49–51 install both as interchangeable hard triggers. The historical implementation report says only requests explicitly stating all three relations of the selected variant should hard-activate. The current Korean aliases for the three confirmed cases do not state every stronger English relation.

Recorded source scope: motte/bailey S03/S32; gate sequence S12/S32; window seat S12; double helix S21; roofless ruin S12/S08; garden grotto S28. The immutable research drafts explicitly say those sources support architectural premises while wording, gates and camera choices are proposed operationalizations. This audit checked the recorded source/history chain, not the current contents of those external web pages, and makes no new historical-architecture claim.

Existing palace tests pass 6/6 unchanged. They establish registration, exact-string routing, English component omissions, broad-name boundaries and provenance integrity. They do not establish cross-language factual completeness, which explains why the three cases coexist with a green suite.

## Frozen proposal only

`proposal/proposed-edits.json` changes only `activation.exact_terms[1]` in each of the three confirmed profiles:

- Window seat: the first clause explicitly makes the fixed seat occupy a masonry-wall recess
- Double helix: the first clause explicitly makes two distinct helical paths wind around one core
- Roofless ruin: the third clause explicitly places localized fallen masonry below the broken upper structure

All English definitions and exact terms, component duties, fixed evidence phrases, render gates, candidates, bundles, other profiles, code and installed indexes remain unchanged. The three complete proposed profile JSONs are review artifacts outside the repository. They were not installed.

The 21 frozen literal-comparator controls cover, per profile, the two original public requests, a new complete Korean positive, one relation substitution and three single-clause omissions. They establish the proposed string boundary only, not an after-arm public-build/audit result. The old incomplete Korean exact sentence stops activation even when later text separately supplies the missing relation. This explicit recall tightening is recorded; it is not described as a harmless synonym replacement. Ordinary frozen requester anchors/assertions continue to preserve the actual request, but this audit does not claim that they recreate omitted profile render gates.

Before promotion: review the exact replacements; rebuild/check the registry-bound visual index with verified vector cache reuse; run paired current normal consumers and exact/adjacent-negative tests on the integrated source. If new embeddings are genuinely needed, their authorization and batch-size requirements remain applicable. Do not turn occurrence-scoped contradictions or general semantic inference into topic-specific DATA exceptions.

## Evidence map

- `bounded-source-sample.json`: six normalized runtime profiles, raw research draft excerpts, extension candidates/relations, and relevant source records
- `frozen-resolver-cases.json`, `merged-resolver-results.json`: the bounded 16-case real merged-resolver sample
- `frozen-public-requests.json`, `frozen-public-input-manifest.json`, `pre-public-input-validation.json`: six source-exposed frozen control inputs and hashes
- `public-controls/*/`: exact public inputs, full packs, unchanged compositions, and generator/audit stdout/stderr
- `public-control-results.json`: complete actual commands, output status, relevant obligations, warnings and failures
- `proposal/`: three uninstalled exact-trigger replacements and 21 literal controls
- `existing-palace-tests.log`: unchanged six-test PASS
- `adapter-notes.json`: fixture normalization and report-comparator corrections, none involving production edits or result tuning
- `final-integrity.json`, `artifact-manifest.json`: unchanged source/input hashes, clean repository, and artifact hashes
