from pathlib import Path
import sys
sys.dont_write_bytecode=True
R=Path('/workspace/scratch/ce8f20680f5a/image-prompt')
P=Path(__file__).parent/'review/v2/compact_test_photo_palace_korean_relation_alignment.py'
source=P.read_text()
# Execute unchanged test bytes with their intended installed-file location.
ns={'__name__':'__main__','__file__':str(R/'tests/test_photo_palace_korean_relation_alignment.py')}
exec(compile(source,str(P),'exec'),ns)
