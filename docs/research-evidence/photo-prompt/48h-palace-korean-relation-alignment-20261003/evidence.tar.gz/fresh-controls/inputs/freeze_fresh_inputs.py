"""Adapt frozen fresh3 source/baseline pairs without changing their bytes."""
import contextlib,hashlib,importlib.util,io,json,os,subprocess,sys,traceback
from pathlib import Path
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent; FRESH=HERE.parent; AUDIT=FRESH.parent
REPO=AUDIT.parent.parent/'image-prompt'; SKILL=REPO/'skills/photo-prompt-image-generator'
PIN='ca0f6d80c85e2538883da9a5a0e01818dfe7df0c'
sha=lambda b:hashlib.sha256(b).hexdigest()
load=lambda p:json.loads(p.read_text(encoding='utf-8'))
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
request_path=FRESH/'requests.json'; request_file_sha=sha(request_path.read_bytes())
assert request_file_sha=='349b6773caf8e5beab2311f3b6aa5e330db2cd78d0839d312fc9488e2955d5c3'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip()==PIN
assert subprocess.check_output(['git','status','--porcelain=v1'],cwd=REPO,text=True)==''
isolation_events=[]
def hook(event,args):
 if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
  p=Path(os.fsdecode(args[0])).absolute()
  if str(p).startswith(str(SKILL/'assets')+os.sep):
   isolation_events.append({'event':event,'path':str(p),'blocked':True});raise RuntimeError('Runtime DATA forbidden')
 if event in ('socket.connect','socket.connect_ex','socket.getaddrinfo'):
  isolation_events.append({'event':event,'blocked':True});raise RuntimeError('Network forbidden')
sys.addaudithook(hook)
sys.path.insert(0,str(SKILL/'scripts'));import prompt_generator as g
spec=importlib.util.spec_from_file_location('fresh_candidate_free_controls',SKILL/'precore/creative_controls.py');cc=importlib.util.module_from_spec(spec);spec.loader.exec_module(cc)
def anchor(id,dim,evidence,raw,**props):return dict(anchor_id=id,source_text=raw,dimension=dim,prompt_evidence=evidence,**props)
D={
 'fresh_timber_recess_seat_01':{
  'profile_id':'pf_window_seat','changed_index':0,
  'subject':'A permanently built-in window seat','setting':'A deep recess in the same thick timber window wall','event':'The fixed seat is visibly integrated with the full-depth solid timber recess',
  'components':['window seat built permanently into a deep recess in a thick timber wall','includes the surrounding wall face and both deep side reveals','their exposed cut ends display growth rings across the full wall thickness'],
  'anchors':[
   ('photograph','concept','An architectural photograph',{}),
   ('seat_subject','subject','window seat',{}),
   ('integrated_seat','event','built permanently into a deep recess',{}),
   ('window_recess','setting','deep recess in a thick timber wall',{}),
   ('same_wall_construction','setting','solid-timber members continue from the wall into the opening',{}),
   ('timber_depth','material','their exposed cut ends display growth rings across the full wall thickness',{'target':'window_wall','property':'construction.full_depth_solid_timber'}),
   ('visible_joinery','setting','joints make the solid-wood construction legible',{}),
   ('wall_and_reveals','framing','includes the surrounding wall face and both deep side reveals',{'target':'window_recess','property':'visibility.wall_and_both_reveals'}),
   ('no_false_material','material','There is no masonry core or thin wood lining',{'target':'window_wall','property':'construction.excluded_substitutes'}),
  ],
  'exclusions':['석조 방에 나무 벤치를 따로 놓은 모습','돌벽 위에 얇게 나무만 덧댄 모습'],
  'assertion_axes':{'seat_installation':'fixed_into_same_wall_recess','wall_construction':'full_depth_exposed_solid_timber','material_evidence':'visible_end_grain_and_interlocking_joinery'},
  'assertion_evidence':{'integrated_seat_phrase':'built permanently into a deep recess','continuous_wall_phrase':'solid-timber members continue from the wall into the opening','full_depth_phrase':'their exposed cut ends display growth rings across the full wall thickness','joinery_phrase':'joints make the solid-wood construction legible'},
  'subject_evidence':'window seat',
 },
 'fresh_independent_straight_flights_02':{
  'profile_id':'pf_double_helix','changed_index':0,
  'subject':'Two independent straight stair flights','setting':'Two stair routes flank one shared open central space','event':'Each staircase is independently traceable from its bottom step to its own top landing',
  'components':['continuous straight stair flights','each route independently traceable','the upper landings remain separate'],
  'anchors':[
   ('photograph','concept','The photograph looks',{}),
   ('stair_subject','subject','straight stair flights',{}),
   ('independent_routes','event','making each route independently traceable',{}),
   ('same_open_space','setting','empty shared space between the flights',{}),
   ('two_straight_routes','setting','the two unbroken slopes',{}),
   ('complete_flights','framing','every tread, both bottom approaches, and both landing transitions visible',{'target':'stair_flights','property':'visibility.full_runs_and_landings'}),
   ('independent_landings','setting','the upper landings remain separate',{}),
   ('no_winding_or_merging','setting','Neither stair bends, winds, has a helical turn, or joins the other during its ascent',{}),
  ],
  'exclusions':['wind or turn like a helix','meet or merge halfway up'],
  'assertion_axes':{'stair_count':'two','path_geometry':'continuous_straight','shared_space':'one_open_central_space','circulation':'independent_bottom_to_own_top_landing','winding_and_midway_merger':'absent'},
  'assertion_evidence':{'straight_routes_phrase':'continuous straight stair flights','count_phrase':'the two unbroken slopes','shared_space_phrase':'empty shared space between the flights','independence_phrase':'each route independently traceable','separate_landings_phrase':'the upper landings remain separate','no_turn_or_merger_phrase':'Neither stair bends, winds, has a helical turn, or joins the other during its ascent'},
  'subject_evidence':'straight stair flights',
 },
 'fresh_cleared_roofless_room_03':{
  'profile_id':'pf_roofless_ruin','changed_index':2,
  'subject':'A formerly enclosed now roofless room','setting':'Broken surviving upper walls above a thoroughly cleared continuous floor','event':'The missing roof exposes the sky above broken wall edges and the floor remains clear beneath them',
  'components':['roof is entirely gone','Jagged broken upper wall edges','free of fallen blocks, rubble, chips, or other debris'],
  'anchors':[
   ('photograph','concept','An architectural photograph',{}),
   ('former_room','subject','once an indoor room',{}),
   ('missing_roof','event','roof is entirely gone',{}),
   ('broken_walls','setting','Jagged broken upper wall edges',{}),
   ('visible_sky','setting','patch of sky',{}),
   ('cleared_state','event','The ruin has deliberately been cleared',{}),
   ('continuous_floor','framing','include the continuous floor all the way to the wall bases beneath the broken edges',{'target':'room_floor','property':'visibility.continuous_to_broken_wall_bases'}),
   ('no_fallen_debris','setting','free of fallen blocks, rubble, chips, or other debris, including along every visible wall-foot junction',{}),
  ],
  'exclusions':['떨어진 돌덩이나 잔해'],
  'assertion_axes':{'former_space':'previously_roofed_interior','current_roof':'absent','upper_walls':'broken_irregular','floor_state':'thoroughly_cleared_and_continuous','fallen_blocks_and_debris':'absent_including_below_broken_walls'},
  'assertion_evidence':{'former_room_phrase':'once an indoor room','roof_phrase':'roof is entirely gone','broken_upper_walls_phrase':'Jagged broken upper wall edges','sky_phrase':'patch of sky','cleared_floor_phrase':'The ruin has deliberately been cleared','debris_absence_phrase':'free of fallen blocks, rubble, chips, or other debris, including along every visible wall-foot junction'},
  'subject_evidence':'once an indoor room',
 },
}
results=[]; cases=[]; rejections=[]
for source in load(request_path)['requests']:
 rid=source['request_id'];data=D[rid];raw=source['request_text'];baseline=source['baseline_prompt_en']
 folder=HERE/rid;attempt=folder/'attempts/attempt-001';attempt.mkdir(parents=True,exist_ok=False)
 (attempt/'request.txt').write_bytes(raw.encode('utf-8'));(attempt/'baseline.txt').write_bytes(baseline.encode('utf-8'))
 envelope={'contract_version':'photo-request-envelope/v1','provenance':'requesting_user','request_id':rid,'request_text':raw,'request_sha256':sha(raw.encode()),'active_spans':[{'span_id':'scene','start':0,'end':len(raw),'text':raw}]}
 write(attempt/'request-envelope.json',envelope)
 write(attempt/'creative-context.json',{'subject_category':'nonhuman','no_people':False,'explicit_nonsexual':False})
 review={'contract_version':'photo-embodiment-review/v1','provenance':'agent_prepack','prompt_sha256':sha(baseline.encode()),'scope':'not_applicable','summary':'The frozen scene depicts stationary architecture and structural relationships. It contains no living body or bodily actuation requiring embodiment checks.','checks':{}}
 write(attempt/'embodiment-review.json',review)
 out,err=io.StringIO(),io.StringIO();result={'id':rid,'attempt':1}
 try:
  with contextlib.redirect_stdout(out),contextlib.redirect_stderr(err):
   rc=cc.main(['--request-envelope-json',str(attempt/'request-envelope.json'),'--context-json',str(attempt/'creative-context.json'),'--seed','1003','--output',str(attempt/'creative-controls.json')])
  assert rc in (None,0)
  controls=load(attempt/'creative-controls.json');write(attempt/'control-resolution.json',json.loads(out.getvalue()))
  locked=['concept','subject','event','setting'];opened=['framing','composition','lighting','camera','material','color','atmosphere','style']
  anchors=[anchor(i,dim,ev,raw,**props)for i,dim,ev,props in data['anchors']]
  core={'contract_version':'photo-authorial-core/v3','provenance':'agent_prepack','source_request':raw,'creative_controls_sha256':controls['canonical_sha256'],'interpreted_intent':'Preserve the requester-specified architectural relationships and their visible positive and excluded physical states. Retain the independently authored frozen photographic baseline; camera position, lighting, style and unrequested material choices are authorial details, not requester locks.','subject':data['subject'],'setting':data['setting'],'event':data['event'],'visual_priorities':data['components'],'baseline_prompt_en':baseline,'user_definitions':[],'interpretation_provenance':[{'term':'requested architectural arrangement','source_text':raw,'basis':'request_context','resolution':'Preserve the complete requester constraints: '+' '.join(source['requester_constraints']),'sources':[]}],'unresolved_ambiguities':[],'user_exclusions':data['exclusions'],'runtime_forbidden_labels':[],'intent_lock':{'contract_version':'photo-intent-lock/v2','priority':'requesting_user','semantic_anchors':anchors,'locked_dimensions':locked,'open_dimensions':opened},'semantic_assertions':[{'assertion_id':'primary_subject_category','dimension':'subject','polarity':'required','source_span_ids':['scene'],'affected_dimensions':['subject'],'axes':{'subject_category':'object'},'evidence':{'subject_phrase':data['subject_evidence']}},{'assertion_id':'requester_architectural_relations','dimension':'setting','polarity':'required','source_span_ids':['scene'],'affected_dimensions':['setting'],'axes':data['assertion_axes'],'evidence':data['assertion_evidence']}],'request_lineage':None,'style':{'domain':'architectural photography','family':'naturalistic structural documentation','evidence':[data['components'][0],data['components'][1]]},'variation_key':rid}
  assert all(a['prompt_evidence']in baseline for a in anchors)
  assert all(x in raw for x in core['user_exclusions'])
  write(attempt/'authorial-core.json',core)
  ep=g.load_request_envelope_arg(str(attempt/'request-envelope.json'));norm=g.load_authorial_core_arg(str(attempt/'authorial-core.json'),request_envelope=ep,creative_control_snapshot=controls);pol=g.photo_embodiment.build_policy(norm,review)
  assert norm['baseline_prompt_en'].encode()==baseline.encode()
  write(attempt/'normalized-authorial-core.json',norm);write(attempt/'embodiment-policy.json',pol)
  result.update(status='pass',envelope_normalization='pass',creative_controls_resolution='pass',core_normalization='pass',embodiment_binding='pass',request_bytes_preserved=True,baseline_bytes_preserved=True,negated_prose_rewritten=False,request_sha256=sha(raw.encode()),baseline_prompt_utf8_sha256=sha(baseline.encode()),core_canonical_sha256=norm['canonical_sha256'],intent_lock_canonical_sha256=norm['intent_lock']['canonical_sha256'],creative_controls_canonical_sha256=controls['canonical_sha256'])
 except BaseException as ex:
  result.update(status='rejected',error_type=type(ex).__name__,error=str(ex),traceback=traceback.format_exc());rejections.append(result)
 (attempt/'resolver.stdout.txt').write_text(out.getvalue());(attempt/'resolver.stderr.txt').write_text(err.getvalue());write(attempt/'validation.json',result)
 results.append(result)
 names=['request.txt','baseline.txt','request-envelope.json','creative-context.json','creative-controls.json','control-resolution.json','authorial-core.json','embodiment-review.json']
 if result['status']=='pass':
  for name in names:(folder/name).write_bytes((attempt/name).read_bytes())
 cases.append({'id':rid,'profile_id':data['profile_id'],'role':'fresh_source_unexposed_authored_negative','components':data['components'],'changed_index':data['changed_index'],'input_dir':str(folder),'source_exposed':True,'source_unexposed_authoring':True,'source_exposed_schema_adaptation':True,'blind_data':False,'request_sha256':sha(raw.encode()),'baseline_prompt_utf8_sha256':sha(baseline.encode()),'validation':result,'files':{name:sha((folder/name).read_bytes())for name in names if(folder/name).exists()},'attempt_files':{str(p.relative_to(folder)):sha(p.read_bytes())for p in sorted((folder/'attempts').rglob('*'))if p.is_file()}})
write(FRESH/'adapter-attempt-notes.json',{'status':'complete'if not rejections else'blocked','source_request_file_sha256':request_file_sha,'requester_and_baseline_bytes_preserved':True,'schema_rejections':rejections,'corrections':[],'attempts':results,'isolation_events':isolation_events,'normalization_limit':'Schema/binding checks are input integrity only, not proof of runtime retrieval, composition or rendered fidelity.','provenance_limit':'Source-unexposed theme-targeted synthetic authoring; this schema adaptation is source-exposed. It is not blind traffic.','ownership_notes':['Only requester-supported architectural meaning and exclusions are anchored. All source_text citations equal the full exact raw requester text.','Requested solid timber and all-scene visibility are narrow property anchors on otherwise open material/framing dimensions.','No anchor or assertion requires the agent-chosen camera elevation/direction, oak species, limestone, dark-metal/plaster treatment, clear sky, warm lighting, doorway/beam sockets, plants or furnishings.','The existing grammatical negations in all three baselines remain byte-identical. No exclusion or negative sentence has been rewritten.','A material/semantic correction would require a separately versioned source; no failed case is repaired by changing its request or baseline.'],'provider_calls':0,'images':0,'runtime_retrieval_calls':0,'candidate_packs_generated':0,'production_edits':0,'git_writes':0})
assert sha(request_path.read_bytes())==request_file_sha
assert subprocess.check_output(['git','status','--porcelain=v1'],cwd=REPO,text=True)==''
write(FRESH/'frozen-input-manifest.json',{'contract_version':'palace-fresh-input-manifest/v1','repository_head':PIN,'status':'frozen_and_normalized'if not rejections else'blocked_with_preserved_rejections','case_count':3,'source_exposed':True,'source_unexposed_authoring':True,'source_exposed_schema_adaptation':True,'blind_data':False,'source_request_file':str(request_path),'source_request_file_sha256':request_file_sha,'cases':cases,'adapter_notes_sha256':sha((FRESH/'adapter-attempt-notes.json').read_bytes()),'adapter_script_sha256':sha(Path(__file__).read_bytes()),'execution':{'normalizations_passed':sum(r['status']=='pass'for r in results),'schema_rejections':len(rejections),'runtime_retrieval_calls':0,'provider_calls':0,'images':0,'candidate_packs_generated':0,'production_edits':0,'git_writes':0}})
print(json.dumps({'manifest':str(FRESH/'frozen-input-manifest.json'),'manifest_sha256':sha((FRESH/'frozen-input-manifest.json').read_bytes()),'normalizations_passed':sum(r['status']=='pass'for r in results),'schema_rejections':len(rejections)}))
if rejections:print(json.dumps(rejections,ensure_ascii=False));raise SystemExit(1)
