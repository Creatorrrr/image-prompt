"""Uninstalled narrow alias-only proposals; literal controls, not integrated claims."""
import copy,hashlib,json,sys
from pathlib import Path
sys.dont_write_bytecode=True
R=Path('/workspace/scratch/ce8f20680f5a/image-prompt');O=Path(__file__).parent;S=R/'skills/photo-prompt-image-generator'
sys.path.insert(0,str(S/'scripts'));import prompt_generator as g
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
source=S/'assets/photo_prompt_visual_obligations_palace_fortification.json';profiles={p['id']:p for p in json.loads(source.read_text())['profiles']}
new={
 'pf_window_seat':'고정 좌석이 조적 벽의 오목한 공간 깊이 안에 들어간다; 창 측벽과 바깥 개구부가 연결된다; 가구 하나를 창 앞에 둔 장면과 구별된다',
 'pf_double_helix':'서로 다른 두 나선형 계단 경로가 하나의 중심부 둘레를 감아 오른다; 공유 중심부가 비어 보인다; 두 경로가 중간에서 임의로 합쳐지거나 충돌하지 않는다',
 'pf_roofless_ruin':'지붕이 없어 방 안에서 하늘이 보인다; 남은 벽·창·바닥이 이전 실내를 이룬다; 파손된 상부 구조 아래에 떨어진 조적 잔해가 국소적으로 놓여 있다',
}
substitutions={
 'pf_window_seat':('조적 벽','통원목 벽'),
 'pf_double_helix':('서로 다른 두 나선형 계단 경로가 하나의 중심부 둘레를 감아 오른다','서로 다른 두 직선 계단 경로가 빈 중심부 양옆에서 평행하게 오른다'),
 'pf_roofless_ruin':('파손된 상부 구조 아래에 떨어진 조적 잔해가 국소적으로 놓여 있다','파손된 상부 구조 아래에는 잔해를 모두 치운 매끈한 석판 바닥이 있다'),
}
pub=json.loads((O/'frozen-public-requests.json').read_text())['cases'];prop=O/'proposal';prop.mkdir(exist_ok=True)
edits=[];checks=[]
for pid,n in new.items():
 old=profiles[pid]['activation']['exact_terms'][1];proposed=copy.deepcopy(profiles[pid]);proposed['activation']['exact_terms'][1]=n
 write(prop/(pid+'.proposed.json'),proposed)
 edits.append({'profile_id':pid,'json_field':'activation.exact_terms[1]','old_value':old,'new_value':n,'unchanged_english_definition_components_evidence_and_gates':True,'retained_exact_term_count':len(proposed['activation']['exact_terms'])})
 rows=[{'id':c['id'],'text':c['request'],'origin':'unchanged frozen public control'}for c in pub if c['profile_id']==pid]
 rows += [{'id':pid+'_proposed_ko_complete','text':n,'origin':'new canonical positive literal control'},{'id':pid+'_proposed_ko_relation_substitution','text':n.replace(*substitutions[pid]),'origin':'single disputed relation substitution control'}]
 clauses=n.split('; ')
 rows += [{'id':pid+'_proposed_ko_omit_'+str(i+1),'text':'; '.join(clauses[:i]+clauses[i+1:]),'origin':'single component omission control'}for i in range(3)]
 for row in rows:
  for name,p in [('current',profiles[pid]),('proposed',proposed)]:row[name+'_unnegated_exact_match']=any(g.intent_alias_matches(row['text'],t)and not g.intent_term_is_negated(row['text'],t)for t in p['activation']['exact_terms'])
  row['profile_id']=pid;checks.append(row)
 assert rows[0]['current_unnegated_exact_match']and not rows[0]['proposed_unnegated_exact_match']
 assert rows[1]['current_unnegated_exact_match']and rows[1]['proposed_unnegated_exact_match']
 assert rows[2]['proposed_unnegated_exact_match']and all(not r['proposed_unnegated_exact_match']for r in rows[3:])
write(prop/'proposed-edits.json',{'status':'proposal_only_not_installed_not_index_qualified','source_path':str(source.relative_to(R)),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'edits':edits,'unchanged':['all English selected-variant definitions and exact terms','all component/evidence/render duties','all ordinary candidates and bundles','all other profile data','production code and indexes'],'known_recall_change':'The old incomplete Korean exact sentence stops hard activation even if a later sentence adds the omitted relation. That relation remains protected by frozen requester anchors/assertions. The new complete Korean canonical exact string is the narrow positive. This is explicit recall tightening, not synonym-neutral cleanup.','qualification_needed':['Review the three Korean replacements against their unchanged English duties','Rebuild the visual profile index and verify unchanged vector text/cache reuse, with batch size 1 if any new embeddings are needed','Replay frozen normal public consumers on the integrated runtime','Add canonical Korean selected-variant positives, nearby missing-relation negatives and unchanged English controls','Do not treat literal-match controls as after-arm composed or image validation']})
write(prop/'literal-controls.json',{'scope':'21 source-exposed literal comparator diagnostics; no mutated runtime, fabricated vectors, after-arm pack, or image evidence','cases':checks})
print(json.dumps({'uninstalled_proposals':len(edits),'literal_controls':len(checks),'production_changes':0}))
