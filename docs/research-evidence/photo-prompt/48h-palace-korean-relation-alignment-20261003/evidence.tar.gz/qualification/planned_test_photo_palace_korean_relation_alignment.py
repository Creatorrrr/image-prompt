"""Draft only: copy to tests after approved installation; do not run as a claim of current-source success.
These source-guided regression cases use the real full merged registry/index.
They do not measure natural-query accuracy or rendered image quality.
"""
import json
import os
import sys
import unittest
from pathlib import Path
ROOT = Path(os.environ.get("IMAGE_PROMPT_REPO", str(Path(__file__).resolve().parents[1])))
SKILL = ROOT / "skills" / "photo-prompt-image-generator"
sys.path.insert(0, str(SKILL / "scripts"))
import prompt_generator as g

EXPECTED_PROFILES = {'pf_window_seat': {'id': 'pf_window_seat',
                    'category': 'palace_fortification_visible_relation',
                    'activation': {'exact_terms': ['a built-in seat occupies the depth of the masonry '
                                                   'recess; the side reveals connect the seat space to '
                                                   'the outer window; the outer opening sits beyond the '
                                                   'seat plane',
                                                   '붙박이 좌석이 조적 벽의 창 오목부 깊이 안에 자리한다; 창 측벽이 그 좌석 공간을 바깥 '
                                                   '창과 연결한다; 바깥 개구부는 좌석 면보다 바깥쪽에 놓이며 가구 하나를 창 앞에 둔 장면과 '
                                                   '구별된다'],
                                   'requires_adult_character': False,
                                   'semantic_discovery_requires_component_evidence': True},
                    'semantics': {'definition': '두꺼운 벽 속 창가 좌석 as a selected architectural variant: a '
                                                'built-in seat occupies the depth of the masonry '
                                                'recess; the side reveals connect the seat space to the '
                                                'outer window; the outer opening sits beyond the seat '
                                                'plane.',
                                  'paraphrase_examples': ['a built-in seat occupying a deep window '
                                                          'recess within thick masonry, with the window '
                                                          'beyond the seat plane',
                                                          'window recess',
                                                          'window seat',
                                                          '깊은 창가 좌석'],
                                  'contrast_examples': ['얇은 현대 벽과 이동식 의자', '인물 크롭으로 벽 두께 소실'],
                                  'claim_limits': ['거주·문루 실내 등의 특정 공간',
                                                   '형태의 적합성은 실제 장소·연대·소유자·용도의 확정 근거가 아니다.',
                                                   'Architecture does not establish a person identity, '
                                                   'rank, nationality or photograph capture date.']},
                    'concept_candidate': {'concept_terms': ['두꺼운 벽 속 창가 좌석',
                                                            'window recess',
                                                            'window seat',
                                                            '깊은 창가 좌석',
                                                            'a built-in seat occupies the depth of the '
                                                            'masonry recess',
                                                            'the side reveals connect the seat space to '
                                                            'the outer window',
                                                            'the outer opening sits beyond the seat '
                                                            'plane']},
                    'runtime_expression': {'default_mode': 'definition_with_optional_label',
                                           'prompt_label_terms': [],
                                           'forbidden_prompt_terms': [],
                                           'runtime_forbidden_labels': []},
                    'reject_substitutes': ['얇은 현대 벽과 이동식 의자', '인물 크롭으로 벽 두께 소실'],
                    'authored_components': {'contract_version': 'photo-authored-visual-components/v1',
                                            'components': [{'id': 'component_1',
                                                            'match_terms': ['a built-in seat occupies '
                                                                            'the depth of the masonry '
                                                                            'recess'],
                                                            'evidence_field': 'component_1_phrase',
                                                            'evidence_terms': ['a built-in seat '
                                                                               'occupies the depth of '
                                                                               'the masonry recess'],
                                                            'min_content_words': 3,
                                                            'instruction': 'Preserve this architectural '
                                                                           'relation: a built-in seat '
                                                                           'occupies the depth of the '
                                                                           'masonry recess',
                                                            'render_gate': {'id': 'vo_pf_window_seat_1',
                                                                            'review_scale': 'both',
                                                                            'description': 'a built-in '
                                                                                           'seat '
                                                                                           'occupies '
                                                                                           'the depth '
                                                                                           'of the '
                                                                                           'masonry '
                                                                                           'recess. The '
                                                                                           'relation '
                                                                                           'must be '
                                                                                           'visible in '
                                                                                           'the saved '
                                                                                           'image; a '
                                                                                           'hidden or '
                                                                                           'substituted '
                                                                                           'connection '
                                                                                           'does not '
                                                                                           'pass.'}},
                                                           {'id': 'component_2',
                                                            'match_terms': ['the side reveals connect '
                                                                            'the seat space to the '
                                                                            'outer window'],
                                                            'evidence_field': 'component_2_phrase',
                                                            'evidence_terms': ['the side reveals '
                                                                               'connect the seat space '
                                                                               'to the outer window'],
                                                            'min_content_words': 3,
                                                            'instruction': 'Preserve this architectural '
                                                                           'relation: the side reveals '
                                                                           'connect the seat space to '
                                                                           'the outer window',
                                                            'render_gate': {'id': 'vo_pf_window_seat_2',
                                                                            'review_scale': 'native',
                                                                            'description': 'the side '
                                                                                           'reveals '
                                                                                           'connect the '
                                                                                           'seat space '
                                                                                           'to the '
                                                                                           'outer '
                                                                                           'window. The '
                                                                                           'relation '
                                                                                           'must be '
                                                                                           'visible in '
                                                                                           'the saved '
                                                                                           'image; a '
                                                                                           'hidden or '
                                                                                           'substituted '
                                                                                           'connection '
                                                                                           'does not '
                                                                                           'pass.'}},
                                                           {'id': 'component_3',
                                                            'match_terms': ['the outer opening sits '
                                                                            'beyond the seat plane'],
                                                            'evidence_field': 'component_3_phrase',
                                                            'evidence_terms': ['the outer opening sits '
                                                                               'beyond the seat plane'],
                                                            'min_content_words': 3,
                                                            'instruction': 'Preserve this architectural '
                                                                           'relation: the outer opening '
                                                                           'sits beyond the seat plane',
                                                            'render_gate': {'id': 'vo_pf_window_seat_3',
                                                                            'review_scale': 'both',
                                                                            'description': 'the outer '
                                                                                           'opening '
                                                                                           'sits beyond '
                                                                                           'the seat '
                                                                                           'plane. The '
                                                                                           'relation '
                                                                                           'must be '
                                                                                           'visible in '
                                                                                           'the saved '
                                                                                           'image; a '
                                                                                           'hidden or '
                                                                                           'substituted '
                                                                                           'connection '
                                                                                           'does not '
                                                                                           'pass.'}}]}},
 'pf_double_helix': {'id': 'pf_double_helix',
                     'category': 'palace_fortification_visible_relation',
                     'activation': {'exact_terms': ['two distinct helical stair flights wind around one '
                                                    'core; the shared central core remains visibly '
                                                    'hollow; each flight retains a separate continuous '
                                                    'circulation path',
                                                    '서로 다른 두 나선형 계단 구간이 하나의 중심부 둘레를 감아 돈다; 두 계단이 공유하는 '
                                                    '중심부는 속이 빈 상태로 보인다; 각 계단은 서로 분리된 연속 동선을 유지하여 두 경로가 '
                                                    '각각 추적되며 중간에서 임의로 합쳐지거나 충돌하지 않는다'],
                                    'requires_adult_character': False,
                                    'semantic_discovery_requires_component_evidence': True},
                     'semantics': {'definition': '서로 만나는 듯 분리된 두 계단 as a selected architectural '
                                                 'variant: two distinct helical stair flights wind '
                                                 'around one core; the shared central core remains '
                                                 'visibly hollow; each flight retains a separate '
                                                 'continuous circulation path.',
                                   'paraphrase_examples': ['two distinct helical stair flights winding '
                                                           'around a shared hollow core, each retaining '
                                                           'its own landings and circulation path',
                                                           'double-helix staircase',
                                                           '이중 나선계단'],
                                   'contrast_examples': ['단일 나선계단', '좌우 대칭 갈래 계단', '외관 사진으로 내부 구조 증명'],
                                   'claim_limits': ['샹보르 사례의 구조 관계',
                                                    '형태의 적합성은 실제 장소·연대·소유자·용도의 확정 근거가 아니다.',
                                                    'Architecture does not establish a person identity, '
                                                    'rank, nationality or photograph capture date.']},
                     'concept_candidate': {'concept_terms': ['서로 만나는 듯 분리된 두 계단',
                                                             'double-helix staircase',
                                                             '이중 나선계단',
                                                             'two distinct helical stair flights wind '
                                                             'around one core',
                                                             'the shared central core remains visibly '
                                                             'hollow',
                                                             'each flight retains a separate continuous '
                                                             'circulation path']},
                     'runtime_expression': {'default_mode': 'definition_with_optional_label',
                                            'prompt_label_terms': [],
                                            'forbidden_prompt_terms': [],
                                            'runtime_forbidden_labels': []},
                     'reject_substitutes': ['단일 나선계단', '좌우 대칭 갈래 계단', '외관 사진으로 내부 구조 증명'],
                     'authored_components': {'contract_version': 'photo-authored-visual-components/v1',
                                             'components': [{'id': 'component_1',
                                                             'match_terms': ['two distinct helical '
                                                                             'stair flights wind around '
                                                                             'one core'],
                                                             'evidence_field': 'component_1_phrase',
                                                             'evidence_terms': ['two distinct helical '
                                                                                'stair flights wind '
                                                                                'around one core'],
                                                             'min_content_words': 3,
                                                             'instruction': 'Preserve this '
                                                                            'architectural relation: '
                                                                            'two distinct helical stair '
                                                                            'flights wind around one '
                                                                            'core',
                                                             'render_gate': {'id': 'vo_pf_double_helix_1',
                                                                             'review_scale': 'both',
                                                                             'description': 'two '
                                                                                            'distinct '
                                                                                            'helical '
                                                                                            'stair '
                                                                                            'flights '
                                                                                            'wind '
                                                                                            'around one '
                                                                                            'core. The '
                                                                                            'relation '
                                                                                            'must be '
                                                                                            'visible in '
                                                                                            'the saved '
                                                                                            'image; a '
                                                                                            'hidden or '
                                                                                            'substituted '
                                                                                            'connection '
                                                                                            'does not '
                                                                                            'pass.'}},
                                                            {'id': 'component_2',
                                                             'match_terms': ['the shared central core '
                                                                             'remains visibly hollow'],
                                                             'evidence_field': 'component_2_phrase',
                                                             'evidence_terms': ['the shared central '
                                                                                'core remains visibly '
                                                                                'hollow'],
                                                             'min_content_words': 3,
                                                             'instruction': 'Preserve this '
                                                                            'architectural relation: '
                                                                            'the shared central core '
                                                                            'remains visibly hollow',
                                                             'render_gate': {'id': 'vo_pf_double_helix_2',
                                                                             'review_scale': 'native',
                                                                             'description': 'the shared '
                                                                                            'central '
                                                                                            'core '
                                                                                            'remains '
                                                                                            'visibly '
                                                                                            'hollow. '
                                                                                            'The '
                                                                                            'relation '
                                                                                            'must be '
                                                                                            'visible in '
                                                                                            'the saved '
                                                                                            'image; a '
                                                                                            'hidden or '
                                                                                            'substituted '
                                                                                            'connection '
                                                                                            'does not '
                                                                                            'pass.'}},
                                                            {'id': 'component_3',
                                                             'match_terms': ['each flight retains a '
                                                                             'separate continuous '
                                                                             'circulation path'],
                                                             'evidence_field': 'component_3_phrase',
                                                             'evidence_terms': ['each flight retains a '
                                                                                'separate continuous '
                                                                                'circulation path'],
                                                             'min_content_words': 3,
                                                             'instruction': 'Preserve this '
                                                                            'architectural relation: '
                                                                            'each flight retains a '
                                                                            'separate continuous '
                                                                            'circulation path',
                                                             'render_gate': {'id': 'vo_pf_double_helix_3',
                                                                             'review_scale': 'both',
                                                                             'description': 'each '
                                                                                            'flight '
                                                                                            'retains a '
                                                                                            'separate '
                                                                                            'continuous '
                                                                                            'circulation '
                                                                                            'path. The '
                                                                                            'relation '
                                                                                            'must be '
                                                                                            'visible in '
                                                                                            'the saved '
                                                                                            'image; a '
                                                                                            'hidden or '
                                                                                            'substituted '
                                                                                            'connection '
                                                                                            'does not '
                                                                                            'pass.'}}]}},
 'pf_roofless_ruin': {'id': 'pf_roofless_ruin',
                      'category': 'palace_fortification_visible_relation',
                      'activation': {'exact_terms': ['open sky appears above the former room where its '
                                                     'roof is missing; surviving walls and window '
                                                     'openings enclose the former interior floor; '
                                                     'localized fallen masonry lies below the broken '
                                                     'upper structure',
                                                     '지붕이 없어 옛 방 안에서 그 방 위의 열린 하늘이 보인다; 남아 있는 벽과 창 개구부가 '
                                                     '그 방의 옛 실내 바닥을 둘러싼다; 파손된 상부 구조 아래에 떨어진 조적 잔해가 '
                                                     '국소적으로 놓여 있고 파손은 구조 경계와 연결되어 단순한 이끼와 구별된다'],
                                     'requires_adult_character': False,
                                     'semantic_discovery_requires_component_evidence': True},
                      'semantics': {'definition': '지붕 소실과 남은 실내 구조 as a selected architectural variant: '
                                                  'open sky appears above the former room where its '
                                                  'roof is missing; surviving walls and window openings '
                                                  'enclose the former interior floor; localized fallen '
                                                  'masonry lies below the broken upper structure.',
                                    'paraphrase_examples': ['a roofless former hall with wall returns, '
                                                            'surviving window openings and localized '
                                                            'fallen masonry beneath the missing upper '
                                                            'structure',
                                                            'roofless hall',
                                                            'castle ruins',
                                                            '폐성',
                                                            '성터'],
                                    'contrast_examples': ['잘 보존된 성에 담쟁이만 추가',
                                                          '전쟁 원인 단정',
                                                          '관리된 유적을 버려진 장소로 확정'],
                                    'claim_limits': ['상태 축; 원래 용도와 쇠락 원인은 별도',
                                                     '형태의 적합성은 실제 장소·연대·소유자·용도의 확정 근거가 아니다.',
                                                     'Architecture does not establish a person '
                                                     'identity, rank, nationality or photograph capture '
                                                     'date.']},
                      'concept_candidate': {'concept_terms': ['지붕 소실과 남은 실내 구조',
                                                              'roofless hall',
                                                              'castle ruins',
                                                              '폐성',
                                                              '성터',
                                                              'open sky appears above the former room '
                                                              'where its roof is missing',
                                                              'surviving walls and window openings '
                                                              'enclose the former interior floor',
                                                              'localized fallen masonry lies below the '
                                                              'broken upper structure']},
                      'runtime_expression': {'default_mode': 'definition_with_optional_label',
                                             'prompt_label_terms': [],
                                             'forbidden_prompt_terms': [],
                                             'runtime_forbidden_labels': []},
                      'reject_substitutes': ['잘 보존된 성에 담쟁이만 추가', '전쟁 원인 단정', '관리된 유적을 버려진 장소로 확정'],
                      'authored_components': {'contract_version': 'photo-authored-visual-components/v1',
                                              'components': [{'id': 'component_1',
                                                              'match_terms': ['open sky appears above '
                                                                              'the former room where '
                                                                              'its roof is missing'],
                                                              'evidence_field': 'component_1_phrase',
                                                              'evidence_terms': ['open sky appears '
                                                                                 'above the former room '
                                                                                 'where its roof is '
                                                                                 'missing'],
                                                              'min_content_words': 3,
                                                              'instruction': 'Preserve this '
                                                                             'architectural relation: '
                                                                             'open sky appears above '
                                                                             'the former room where its '
                                                                             'roof is missing',
                                                              'render_gate': {'id': 'vo_pf_roofless_ruin_1',
                                                                              'review_scale': 'both',
                                                                              'description': 'open sky '
                                                                                             'appears '
                                                                                             'above the '
                                                                                             'former '
                                                                                             'room '
                                                                                             'where its '
                                                                                             'roof is '
                                                                                             'missing. '
                                                                                             'The '
                                                                                             'relation '
                                                                                             'must be '
                                                                                             'visible '
                                                                                             'in the '
                                                                                             'saved '
                                                                                             'image; a '
                                                                                             'hidden or '
                                                                                             'substituted '
                                                                                             'connection '
                                                                                             'does not '
                                                                                             'pass.'}},
                                                             {'id': 'component_2',
                                                              'match_terms': ['surviving walls and '
                                                                              'window openings enclose '
                                                                              'the former interior '
                                                                              'floor'],
                                                              'evidence_field': 'component_2_phrase',
                                                              'evidence_terms': ['surviving walls and '
                                                                                 'window openings '
                                                                                 'enclose the former '
                                                                                 'interior floor'],
                                                              'min_content_words': 3,
                                                              'instruction': 'Preserve this '
                                                                             'architectural relation: '
                                                                             'surviving walls and '
                                                                             'window openings enclose '
                                                                             'the former interior floor',
                                                              'render_gate': {'id': 'vo_pf_roofless_ruin_2',
                                                                              'review_scale': 'native',
                                                                              'description': 'surviving '
                                                                                             'walls and '
                                                                                             'window '
                                                                                             'openings '
                                                                                             'enclose '
                                                                                             'the '
                                                                                             'former '
                                                                                             'interior '
                                                                                             'floor. '
                                                                                             'The '
                                                                                             'relation '
                                                                                             'must be '
                                                                                             'visible '
                                                                                             'in the '
                                                                                             'saved '
                                                                                             'image; a '
                                                                                             'hidden or '
                                                                                             'substituted '
                                                                                             'connection '
                                                                                             'does not '
                                                                                             'pass.'}},
                                                             {'id': 'component_3',
                                                              'match_terms': ['localized fallen masonry '
                                                                              'lies below the broken '
                                                                              'upper structure'],
                                                              'evidence_field': 'component_3_phrase',
                                                              'evidence_terms': ['localized fallen '
                                                                                 'masonry lies below '
                                                                                 'the broken upper '
                                                                                 'structure'],
                                                              'min_content_words': 3,
                                                              'instruction': 'Preserve this '
                                                                             'architectural relation: '
                                                                             'localized fallen masonry '
                                                                             'lies below the broken '
                                                                             'upper structure',
                                                              'render_gate': {'id': 'vo_pf_roofless_ruin_3',
                                                                              'review_scale': 'both',
                                                                              'description': 'localized '
                                                                                             'fallen '
                                                                                             'masonry '
                                                                                             'lies '
                                                                                             'below the '
                                                                                             'broken '
                                                                                             'upper '
                                                                                             'structure. '
                                                                                             'The '
                                                                                             'relation '
                                                                                             'must be '
                                                                                             'visible '
                                                                                             'in the '
                                                                                             'saved '
                                                                                             'image; a '
                                                                                             'hidden or '
                                                                                             'substituted '
                                                                                             'connection '
                                                                                             'does not '
                                                                                             'pass.'}}]}}}

COMPATIBLE_NEGATIVES = [{'id': 'pf_window_seat_compatible_ko',
  'profile_id': 'pf_window_seat',
  'text': '건축 사진을 만들어 주세요: 좌석이 벽 깊이 안에 들어간다; 창 측벽과 바깥 개구부가 연결된다; 가구 하나를 창 앞에 둔 장면과 구별된다. 벽은 두꺼운 원목 '
          '구조이며, 벽 속 고정 좌석과 창 측벽도 원목으로 이어진다. 같은 벽체와 깊은 창 측벽은 통원목으로 이루어져 있고, 벽 깊이 전체에서 원목 단면과 짜맞춤이 보인다.',
  'target_hard': False},
 {'id': 'pf_double_helix_compatible_ko',
  'profile_id': 'pf_double_helix',
  'text': '건축 사진을 만들어 주세요: 두 개의 계단 경로가 추적된다; 공유 중심부가 비어 보인다; 두 경로가 중간에서 임의로 합쳐지거나 충돌하지 않는다. 두 계단은 빈 중앙 '
          '공간의 양쪽에서 곧게 오르는 평행 직선 계단이다.',
  'target_hard': False},
 {'id': 'pf_roofless_ruin_compatible_ko',
  'profile_id': 'pf_roofless_ruin',
  'text': '건축 사진을 만들어 주세요: 지붕이 없어 방 안에서 하늘이 보인다; 남은 벽·창·바닥이 이전 실내를 이룬다; 파손이 구조 경계와 연결되며 단순 이끼가 아니다. 파손된 '
          '상부 벽의 잘린 단면이 선명하며, 바닥의 떨어진 돌과 벽돌은 모두 치워져 매끈한 석판만 남아 있다.',
  'target_hard': False},
 {'id': 'pf_window_seat_compatible_en',
  'profile_id': 'pf_window_seat',
  'text': 'Make an architectural photograph: the seat is set within the depth of the wall; the window '
          'side reveals connect to the outer opening; the scene is distinguishable from a piece of '
          'furniture placed in front of a window. The wall is a thick solid-timber structure, and the '
          'fixed seat inside the wall and the window side reveals continue in solid timber. This same '
          'wall and its deep window side reveals are solid timber, with exposed timber end grain and '
          'timber joinery visible through the full wall depth.',
  'target_hard': False},
 {'id': 'pf_double_helix_compatible_en',
  'profile_id': 'pf_double_helix',
  'text': 'Make an architectural photograph: two stair routes can be traced; the shared central core is '
          'visibly hollow; the two routes do not arbitrarily merge or collide midway. The two stairs '
          'are parallel straight flights rising straight along opposite sides of the empty central '
          'space.',
  'target_hard': False},
 {'id': 'pf_roofless_ruin_compatible_en',
  'profile_id': 'pf_roofless_ruin',
  'text': 'Make an architectural photograph: the sky is visible from inside the room because the roof '
          'is missing; the remaining walls, windows and floor form the former interior; the damage is '
          'connected to structural boundaries and is more than merely moss. The cut sections of the '
          'damaged upper walls are clearly visible, and all fallen stones and bricks have been cleared '
          'from the floor, leaving only smooth stone slabs.',
  'target_hard': False}]

COMPLETE_LEGACY = [{'id': 'pf_window_seat_old_ko_complete_v2',
  'profile_id': 'pf_window_seat',
  'text': '좌석이 벽 깊이 안에 들어간다; 창 측벽과 바깥 개구부가 연결된다; 가구 하나를 창 앞에 둔 장면과 구별된다. 좌석은 붙박이이며 같은 조적 벽의 창 오목부 깊이 안에 '
          '놓인다. 창 측벽은 좌석 공간을 바깥 창과 연결하며 바깥 개구부는 좌석 면보다 바깥쪽에 있다.'},
 {'id': 'pf_double_helix_old_ko_complete_v2',
  'profile_id': 'pf_double_helix',
  'text': '두 개의 계단 경로가 추적된다; 공유 중심부가 비어 보인다; 두 경로가 중간에서 임의로 합쳐지거나 충돌하지 않는다. 서로 다른 두 나선형 계단 구간이 같은 중심부 '
          '둘레를 감아 돌고 각 구간은 서로 분리된 연속 동선을 유지한다.'},
 {'id': 'pf_roofless_ruin_old_ko_complete_v2',
  'profile_id': 'pf_roofless_ruin',
  'text': '지붕이 없어 방 안에서 하늘이 보인다; 남은 벽·창·바닥이 이전 실내를 이룬다; 파손이 구조 경계와 연결되며 단순 이끼가 아니다. 남은 벽과 창 개구부가 그 방의 옛 '
          '실내 바닥을 둘러싸고 파손된 상부 구조 아래에 떨어진 조적 잔해가 국소적으로 놓여 있다.'}]

BOUNDARY_CONTROLS = [{'id': 'pf_window_seat_v2_complete',
  'profile_id': 'pf_window_seat',
  'role': 'canonical_complete',
  'text': '붙박이 좌석이 조적 벽의 창 오목부 깊이 안에 자리한다; 창 측벽이 그 좌석 공간을 바깥 창과 연결한다; 바깥 개구부는 좌석 면보다 바깥쪽에 놓이며 가구 하나를 창 '
          '앞에 둔 장면과 구별된다'},
 {'id': 'pf_window_seat_v2_omit_1',
  'profile_id': 'pf_window_seat',
  'role': 'one_clause_omission',
  'text': '창 측벽이 그 좌석 공간을 바깥 창과 연결한다; 바깥 개구부는 좌석 면보다 바깥쪽에 놓이며 가구 하나를 창 앞에 둔 장면과 구별된다'},
 {'id': 'pf_window_seat_v2_omit_2',
  'profile_id': 'pf_window_seat',
  'role': 'one_clause_omission',
  'text': '붙박이 좌석이 조적 벽의 창 오목부 깊이 안에 자리한다; 바깥 개구부는 좌석 면보다 바깥쪽에 놓이며 가구 하나를 창 앞에 둔 장면과 구별된다'},
 {'id': 'pf_window_seat_v2_omit_3',
  'profile_id': 'pf_window_seat',
  'role': 'one_clause_omission',
  'text': '붙박이 좌석이 조적 벽의 창 오목부 깊이 안에 자리한다; 창 측벽이 그 좌석 공간을 바깥 창과 연결한다'},
 {'id': 'pf_window_seat_v2_relation_substitution',
  'profile_id': 'pf_window_seat',
  'role': 'disputed_relation_substitution',
  'text': '붙박이 좌석이 통원목 벽의 창 오목부 깊이 안에 자리한다; 창 측벽이 그 좌석 공간을 바깥 창과 연결한다; 바깥 개구부는 좌석 면보다 바깥쪽에 놓이며 가구 하나를 창 '
          '앞에 둔 장면과 구별된다'},
 {'id': 'pf_double_helix_v2_complete',
  'profile_id': 'pf_double_helix',
  'role': 'canonical_complete',
  'text': '서로 다른 두 나선형 계단 구간이 하나의 중심부 둘레를 감아 돈다; 두 계단이 공유하는 중심부는 속이 빈 상태로 보인다; 각 계단은 서로 분리된 연속 동선을 유지하여 '
          '두 경로가 각각 추적되며 중간에서 임의로 합쳐지거나 충돌하지 않는다'},
 {'id': 'pf_double_helix_v2_omit_1',
  'profile_id': 'pf_double_helix',
  'role': 'one_clause_omission',
  'text': '두 계단이 공유하는 중심부는 속이 빈 상태로 보인다; 각 계단은 서로 분리된 연속 동선을 유지하여 두 경로가 각각 추적되며 중간에서 임의로 합쳐지거나 충돌하지 '
          '않는다'},
 {'id': 'pf_double_helix_v2_omit_2',
  'profile_id': 'pf_double_helix',
  'role': 'one_clause_omission',
  'text': '서로 다른 두 나선형 계단 구간이 하나의 중심부 둘레를 감아 돈다; 각 계단은 서로 분리된 연속 동선을 유지하여 두 경로가 각각 추적되며 중간에서 임의로 합쳐지거나 '
          '충돌하지 않는다'},
 {'id': 'pf_double_helix_v2_omit_3',
  'profile_id': 'pf_double_helix',
  'role': 'one_clause_omission',
  'text': '서로 다른 두 나선형 계단 구간이 하나의 중심부 둘레를 감아 돈다; 두 계단이 공유하는 중심부는 속이 빈 상태로 보인다'},
 {'id': 'pf_double_helix_v2_relation_substitution',
  'profile_id': 'pf_double_helix',
  'role': 'disputed_relation_substitution',
  'text': '서로 다른 두 직선 계단 구간이 하나의 중심부 양옆에서 평행하게 오른다; 두 계단이 공유하는 중심부는 속이 빈 상태로 보인다; 각 계단은 서로 분리된 연속 동선을 '
          '유지하여 두 경로가 각각 추적되며 중간에서 임의로 합쳐지거나 충돌하지 않는다'},
 {'id': 'pf_roofless_ruin_v2_complete',
  'profile_id': 'pf_roofless_ruin',
  'role': 'canonical_complete',
  'text': '지붕이 없어 옛 방 안에서 그 방 위의 열린 하늘이 보인다; 남아 있는 벽과 창 개구부가 그 방의 옛 실내 바닥을 둘러싼다; 파손된 상부 구조 아래에 떨어진 조적 '
          '잔해가 국소적으로 놓여 있고 파손은 구조 경계와 연결되어 단순한 이끼와 구별된다'},
 {'id': 'pf_roofless_ruin_v2_omit_1',
  'profile_id': 'pf_roofless_ruin',
  'role': 'one_clause_omission',
  'text': '남아 있는 벽과 창 개구부가 그 방의 옛 실내 바닥을 둘러싼다; 파손된 상부 구조 아래에 떨어진 조적 잔해가 국소적으로 놓여 있고 파손은 구조 경계와 연결되어 단순한 '
          '이끼와 구별된다'},
 {'id': 'pf_roofless_ruin_v2_omit_2',
  'profile_id': 'pf_roofless_ruin',
  'role': 'one_clause_omission',
  'text': '지붕이 없어 옛 방 안에서 그 방 위의 열린 하늘이 보인다; 파손된 상부 구조 아래에 떨어진 조적 잔해가 국소적으로 놓여 있고 파손은 구조 경계와 연결되어 단순한 '
          '이끼와 구별된다'},
 {'id': 'pf_roofless_ruin_v2_omit_3',
  'profile_id': 'pf_roofless_ruin',
  'role': 'one_clause_omission',
  'text': '지붕이 없어 옛 방 안에서 그 방 위의 열린 하늘이 보인다; 남아 있는 벽과 창 개구부가 그 방의 옛 실내 바닥을 둘러싼다'},
 {'id': 'pf_roofless_ruin_v2_relation_substitution',
  'profile_id': 'pf_roofless_ruin',
  'role': 'disputed_relation_substitution',
  'text': '지붕이 없어 옛 방 안에서 그 방 위의 열린 하늘이 보인다; 남아 있는 벽과 창 개구부가 그 방의 옛 실내 바닥을 둘러싼다; 파손된 상부 구조 아래에는 잔해를 모두 '
          '치운 석판 바닥만 있고 파손은 구조 경계와 연결되어 단순한 이끼와 구별된다'}]

class PalaceKoreanRelationAlignmentTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.registry = g.load_visual_obligation_registry(SKILL / "assets/photo_prompt_visual_obligations.json")
        cls.index = g.load_visual_profile_index(SKILL / "assets/photo_prompt_visual_profile_index.json", cls.registry)
        cls.raw_profiles = {p["id"]: p for p in json.loads((SKILL / "assets/photo_prompt_visual_obligations_palace_fortification.json").read_text())["profiles"]}
        cls.data = {g.VISUAL_OBLIGATIONS_DATA_KEY: cls.registry, g.VISUAL_PROFILE_INDEX_DATA_KEY: cls.index}

    def resolve(self, text):
        return g.resolve_visual_profile_hits(self.registry, [{"source": "concept_lock", "text": text, "polarity": "required", "priority": "critical", "mandatory": True}], visual_profile_index=self.index, adult_context=False)

    def hard(self, text):
        return {h["profile_id"] for h in self.resolve(text)["hits"] if h.get("hard_eligible")}

    def contract(self, text, pid):
        result = {"provenance": {"prompt_id": "palace-alignment-regression", "concept_lock": [text]}}
        contract = g.candidate_pack_visual_obligations(self.data, result, {}, None, self.resolve(text))
        return next(ob for ob in contract["obligations"] if ob["id"] == pid)

    def test_reviewed_alias_and_other_target_profile_fields_are_exact(self):
        for pid, expected in EXPECTED_PROFILES.items():
            with self.subTest(profile=pid):
                self.assertEqual(self.raw_profiles[pid], expected)

    def test_canonical_korean_and_unchanged_english_keep_identical_duties(self):
        for pid, profile in EXPECTED_PROFILES.items():
            with self.subTest(profile=pid):
                en, ko = profile["activation"]["exact_terms"]
                self.assertEqual(self.hard(en), {pid})
                self.assertEqual(self.hard(ko), {pid})
                a, b = self.contract(en, pid), self.contract(ko, pid)
                for field in ("composition_instruction", "component_semantics", "prompt_binding", "evidence_requirements", "runtime_expression", "render_gates", "reject_substitutes"):
                    self.assertEqual(a[field], b[field])
                self.assertEqual([gate["id"] for gate in b["render_gates"]], ["vo_" + pid + "_" + str(i) for i in (1, 2, 3)])

    def test_compatible_korean_and_english_negative_scenes_remain_nonhard(self):
        for row in COMPATIBLE_NEGATIVES:
            with self.subTest(case=row["id"]):
                self.assertNotIn(row["profile_id"], self.hard(row["text"]))

    def test_complete_legacy_korean_loses_automatic_gates_explicitly(self):
        # Accepted precision/recall tradeoff, not a claim that the meaning is invalid.
        for row in COMPLETE_LEGACY:
            with self.subTest(case=row["id"]):
                self.assertNotIn(row["profile_id"], self.hard(row["text"]))

    def test_each_omission_and_disputed_relation_substitution_is_nonhard(self):
        for row in BOUNDARY_CONTROLS:
            with self.subTest(case=row["id"]):
                self.assertEqual(row["profile_id"] in self.hard(row["text"]), row["role"] == "canonical_complete")

    def test_generic_names_do_not_import_selected_geometry_or_material(self):
        for text in ("an architectural photograph of a window seat", "an architectural photograph of two stair routes", "an architectural photograph of a roofless hall"):
            with self.subTest(text=text):
                self.assertFalse(set(EXPECTED_PROFILES) & self.hard(text))

if __name__ == "__main__":
    unittest.main()
