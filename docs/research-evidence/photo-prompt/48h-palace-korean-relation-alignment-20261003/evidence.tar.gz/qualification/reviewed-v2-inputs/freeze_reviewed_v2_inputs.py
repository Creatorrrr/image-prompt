"""Freeze reviewed v2 exact canonical and complete legacy-wording inputs."""
import contextlib,copy,hashlib,importlib.util,io,json,os,subprocess,sys,traceback
from pathlib import Path
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent;Q=HERE.parent;AUDIT=Q.parent;REPO=AUDIT.parent.parent/'image-prompt';S=REPO/'skills/photo-prompt-image-generator';PIN='ca0f6d80c85e2538883da9a5a0e01818dfe7df0c'
sha=lambda b:hashlib.sha256(b).hexdigest()
load=lambda p:json.loads(p.read_text(encoding='utf-8'))
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip()==PIN
assert subprocess.check_output(['git','status','--porcelain=v1'],cwd=REPO,text=True)==''
protected={str(p):sha(p.read_bytes())for p in sorted((Q/'additional-inputs').rglob('*'))if p.is_file()}
for name in ['additional-input-manifest.json','additional-adapter-notes.json']:
 p=Q/name;protected[str(p)]=sha(p.read_bytes())
replacement_path=AUDIT/'review/recommended-replacements.json';legacy_path=AUDIT/'review/resolver-and-recall-probes.json'
replacements={r['profile_id']:r for r in load(replacement_path)['edits']}
legacy={r['profile_id']:r for r in load(legacy_path)['cases']if r['group']=='old_wording_with_all_english_facts'}
original=load(AUDIT/'frozen-public-input-manifest.json'); original_rows={r['id']:r for r in original['cases']}
original_requests={r['id']:r for r in load(AUDIT/'frozen-public-requests.json')['cases']}
rows=[]
for pid in ['pf_window_seat','pf_double_helix','pf_roofless_ruin']:
 for suffix,role,text,source_file,selector in [
  ('canonical_ko_v2','canonical_ko_positive_v2',replacements[pid]['replacement'],replacement_path,'edits[profile_id='+pid+'].replacement'),
  ('old_ko_complete_v2','old_ko_complete_positive_v2',legacy[pid]['text'],legacy_path,'cases[group=old_wording_with_all_english_facts,profile_id='+pid+'].text')]:
  original_id=pid+'_selected_en_control';source_dir=AUDIT/'public-controls'/original_id
  for name,h in original_rows[original_id]['files'].items():assert sha((source_dir/name).read_bytes())==h
  core=load(source_dir/'authorial-core.json');baseline=core['baseline_prompt_en'];assert baseline.encode()==original_requests[original_id]['baseline'].encode()
  rows.append({'id':pid+'_'+suffix,'profile_id':pid,'role':role,'components':original_requests[original_id]['components'],'changed_index':original_requests[original_id]['changed_index'],'template_case_id':original_id,'source_exposed':True,'blind_data':False,'request':text,'request_sha256':sha(text.encode()),'baseline_prompt_en':baseline,'baseline_prompt_utf8_sha256':sha(baseline.encode()),'request_source_file':str(source_file),'request_source_file_sha256':sha(source_file.read_bytes()),'request_source_selector':selector,'exact_source_text_equal':True})
assert len(rows)==6
write(HERE/'frozen-requests.json',{'case_count':6,'provenance':'Source-exposed reviewed v2 maintenance controls, neither blind data nor independent natural traffic. Each raw requester text is exactly the identified review field, without prefix, suffix or rewrite.','cases':rows})
isolation_events=[]
def hook(event,args):
 if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
  p=Path(os.fsdecode(args[0])).absolute()
  if str(p).startswith(str(S/'assets')+os.sep):isolation_events.append({'event':event,'path':str(p),'blocked':True});raise RuntimeError('Runtime DATA forbidden')
 if event in ('socket.connect','socket.connect_ex','socket.getaddrinfo'):isolation_events.append({'event':event,'blocked':True});raise RuntimeError('Network forbidden')
sys.addaudithook(hook)
sys.path.insert(0,str(S/'scripts'));import prompt_generator as g
spec=importlib.util.spec_from_file_location('reviewed_v2_candidate_free_controls',S/'precore/creative_controls.py');cc=importlib.util.module_from_spec(spec);spec.loader.exec_module(cc)
def rebind(v,raw):
 if isinstance(v,dict):return {k:raw if k=='source_text' else rebind(c,raw)for k,c in v.items()}
 if isinstance(v,list):return [rebind(c,raw)for c in v]
 return v
def citations(v):
 if isinstance(v,dict):
  for k,c in v.items():
   if k=='source_text':yield c
   else:yield from citations(c)
 elif isinstance(v,list):
  for c in v:yield from citations(c)
results=[];rejections=[];cases=[]
for row in rows:
 folder=HERE/row['id'];attempt=folder/'attempts/attempt-001';attempt.mkdir(parents=True,exist_ok=False)
 source=AUDIT/'public-controls'/row['template_case_id'];raw=row['request'];b=row['baseline_prompt_en']
 (attempt/'request.txt').write_bytes(raw.encode());(attempt/'baseline.txt').write_bytes(b.encode())
 ep=copy.deepcopy(load(source/'request-envelope.json'));ep.update(request_id='synthetic-palace-qualification-'+row['id'],request_text=raw,request_sha256=sha(raw.encode()),active_spans=[{'span_id':'scene','start':0,'end':len(raw),'text':raw}]);write(attempt/'request-envelope.json',ep)
 for name in ['creative-context.json','embodiment-review.json']:(attempt/name).write_bytes((source/name).read_bytes())
 oldcontrols=load(source/'creative-controls.json');out,err=io.StringIO(),io.StringIO();result={'id':row['id'],'attempt':1}
 try:
  with contextlib.redirect_stdout(out),contextlib.redirect_stderr(err):rc=cc.main(['--request-envelope-json',str(attempt/'request-envelope.json'),'--context-json',str(attempt/'creative-context.json'),'--seed',str(oldcontrols['seed']),'--output',str(attempt/'creative-controls.json')])
  assert rc in (None,0)
  controls=load(attempt/'creative-controls.json');write(attempt/'control-resolution.json',json.loads(out.getvalue()))
  for field in oldcontrols:
   if field not in ['source_request_sha256','canonical_sha256']:assert controls[field]==oldcontrols[field]
  core=rebind(copy.deepcopy(load(source/'authorial-core.json')),raw);core['source_request']=raw;core['creative_controls_sha256']=controls['canonical_sha256'];core['variation_key']=row['id']
  # Raw review strings specify the architectural arrangement but omit a photo
  # request prefix. Do not fabricate requester ownership of photographic format.
  for a in core['intent_lock']['semantic_anchors']:
   if a['anchor_id']=='architecture':a['prompt_evidence']='the visible arrangement'
  write(attempt/'authorial-core.json',core)
  assert all(c==raw for c in citations(core))
  assert all(a['prompt_evidence']in b for a in core['intent_lock']['semantic_anchors'])
  epn=g.load_request_envelope_arg(str(attempt/'request-envelope.json'));n=g.load_authorial_core_arg(str(attempt/'authorial-core.json'),request_envelope=epn,creative_control_snapshot=controls);p=g.photo_embodiment.build_policy(n,load(attempt/'embodiment-review.json'))
  assert n['baseline_prompt_en'].encode()==b.encode()
  write(attempt/'normalized-authorial-core.json',n);write(attempt/'embodiment-policy.json',p)
  result.update(status='pass',envelope_normalization='pass',creative_controls_resolution='pass',core_normalization='pass',embodiment_binding='pass',baseline_byte_identical_to_original_selected_en_control=True,exact_raw_text_from_review_field=True,all_source_text_citations_rebound=True,request_sha256=sha(raw.encode()),baseline_prompt_utf8_sha256=sha(b.encode()),core_canonical_sha256=n['canonical_sha256'],intent_lock_canonical_sha256=n['intent_lock']['canonical_sha256'],creative_controls_canonical_sha256=controls['canonical_sha256'])
 except BaseException as ex:result.update(status='rejected',error_type=type(ex).__name__,error=str(ex),traceback=traceback.format_exc());rejections.append(result)
 (attempt/'resolver.stdout.txt').write_text(out.getvalue());(attempt/'resolver.stderr.txt').write_text(err.getvalue());write(attempt/'validation.json',result);results.append(result)
 names=['request.txt','baseline.txt','request-envelope.json','creative-context.json','creative-controls.json','control-resolution.json','authorial-core.json','embodiment-review.json']
 if result['status']=='pass':
  for name in names:(folder/name).write_bytes((attempt/name).read_bytes())
 case={k:v for k,v in row.items()if k not in ['request','baseline_prompt_en']};case.update(input_dir=str(folder),template_dir=str(source),validation=result,files={name:sha((folder/name).read_bytes())for name in names if(folder/name).exists()},attempt_files={str(p.relative_to(folder)):sha(p.read_bytes())for p in sorted((folder/'attempts').rglob('*'))if p.is_file()});cases.append(case)
write(HERE/'validation-results.json',{'cases':results,'schema_rejections':rejections,'isolation_events':isolation_events})
for path,h in protected.items():assert sha(Path(path).read_bytes())==h,path
assert subprocess.check_output(['git','status','--porcelain=v1'],cwd=REPO,text=True)==''
notes={'contract_version':'palace-reviewed-v2-adapter-notes/v1','source_exposed':True,'blind_data':False,'schema_rejections':rejections,'corrections':[],'adaptation_notes':['Every exact requester text is copied directly from the identified review field with no additional prefix, punctuation or rewrite.','All six baselines remain byte-identical to their original selected_en_control core. All subject, setting, event, priorities, assertion evidence, exclusions, material anchors and embodiment reviews remain from those original controls.','Every source_text citation, request ID/span/hash, source_request, creative-controls binding and variation key is rebound to the new input.','The governing concept anchor uses the existing literal baseline phrase "the visible arrangement" in place of "An architectural photograph": the exact reviewed source text specifies an arrangement but does not explicitly ask for photographic format. This truthful ownership adaptation changes no baseline or architectural fact.','The candidate-free resolver retains each original selected_en_control seed, definitions, defaults, context and authoring brief.','Original v1 files and manifests are preserved byte-for-byte; no paused runtime arms were resumed.'],'v1_preserved_hashes':protected,'isolation_guard':{'runtime_asset_reads_denied':True,'network_socket_operations_denied':True,'events':isolation_events},'runtime_retrieval_calls':0,'provider_calls':0,'images':0,'candidate_packs_generated':0,'production_edits':0,'git_writes':0,'limit':'Input normalization is integrity evidence only. No after-arm, runtime, natural-query recall or rendered-fidelity claim follows.'}
write(Q/'reviewed-v2-adapter-notes.json',notes)
manifest={'contract_version':'palace-reviewed-v2-input-manifest/v1','repository_head':PIN,'status':'frozen_and_normalized'if not rejections else'blocked_with_preserved_rejections','case_count':6,'source_exposed':True,'blind_data':False,'role_counts':{r:sum(c['role']==r for c in cases)for r in ['canonical_ko_positive_v2','old_ko_complete_positive_v2']},'cases':cases,'provenance':{'recommended_replacements_path':str(replacement_path),'recommended_replacements_sha256':sha(replacement_path.read_bytes()),'legacy_complete_requests_path':str(legacy_path),'legacy_complete_requests_sha256':sha(legacy_path.read_bytes()),'original_input_manifest_sha256':sha((AUDIT/'frozen-public-input-manifest.json').read_bytes())},'support_files':{p.name:sha(p.read_bytes())for p in sorted(HERE.iterdir())if p.is_file()},'adapter_notes_sha256':sha((Q/'reviewed-v2-adapter-notes.json').read_bytes()),'execution':{'normalizations_passed':sum(r['status']=='pass'for r in results),'schema_rejections':len(rejections),'v1_inputs_and_manifests_preserved':True,'runtime_retrieval_calls':0,'provider_calls':0,'images':0,'candidate_packs_generated':0,'production_edits':0,'git_writes':0}}
write(Q/'reviewed-v2-input-manifest.json',manifest)
print(json.dumps({'manifest':str(Q/'reviewed-v2-input-manifest.json'),'manifest_sha256':sha((Q/'reviewed-v2-input-manifest.json').read_bytes()),'adapter_notes_sha256':manifest['adapter_notes_sha256'],'case_count':6,'normalizations_passed':manifest['execution']['normalizations_passed'],'schema_rejections':len(rejections)}))
if rejections:print(json.dumps(rejections,ensure_ascii=False));raise SystemExit(1)
