# Palace Korean relation alignment: isolated V2 qualification

## Decision and boundary

The independently reviewed V2 replacements pass the bounded isolated qualification. **They are not installed or published.** The production checkout remains clean at `ca0f6d80c85e2538883da9a5a0e01818dfe7df0c`.

The final main matrix is **18 cases / 36 normal public-builder and composed-auditor executions**. All 36 builds admit. Before: 15 audits pass and the three original Korean incompatibility cases fail. After: all 18 audits pass with unchanged baseline prose.

The repair closes three source-exposed overactivation cases, while accepting a measurable recall tradeoff: all three fully explicit legacy-Korean positives lose automatic profile activation and **nine profile render gates**. Their requester facts remain literally bound by generic anchors/assertions. Those generic checks do not replace the lost profile-specific native/thumbnail review gates.

No provider calls, image generation, production edits, Git writes, ordinary dictionary/general-index changes, or runtime code changes occurred. No natural-query accuracy, rendered fidelity, or artistic-quality improvement is claimed.

## Which proposal was tested

`proposal-v2/proposed-edits.json` freezes the exact three strings in the independent review's `recommended-replacements.json`; SHA-256:

`05f90f550cb3d1301eb33df1bb4ab3d6eb91e3599815958ebeadf2efcef695ce`

V2 states every unchanged selected English duty and retains the older Korean facts:

- Window seat: built-in seat within the masonry recess depth; side reveals connect that seat space to the outer window; outer opening beyond the seat plane; distinct from furniture placed in front
- Double helix: two distinct helical flights around one core; visibly hollow shared center; separate continuous and traceable routes without arbitrary merging/collision
- Roofless ruin: sky above the same roofless former room; walls/window openings enclose its former floor; localized fallen masonry below broken upper structure; structural-boundary damage distinguished from moss alone

All English terms, definitions, component/evidence duties, render gates, ordinary candidates/bundles, other profiles and historical research remain unchanged. V1 proposals were preserved and no V1 after-arm was executed.

## Cohorts and denominators

| Cohort | Cases | Before → after audit | Automatic target behavior |
|---|---:|---|---|
| Original Korean compatible counterexamples | 3 | FAIL → PASS | Target hard → absent |
| Original complete English selected variants | 3 | PASS → PASS | Target hard → same target hard; all three gates retained |
| Separately frozen equivalent English negatives | 3 | PASS → PASS | No target hard in either arm |
| Fully explicit legacy-Korean positives | 3 | PASS → PASS | Target hard → absent; three automatic gates lost per case |
| Reviewed V2 canonical Korean positives | 3 | PASS → PASS | No target hard → target hard; all three unchanged gates |
| Fresh theme-targeted alternatives | 3 | PASS → PASS | No target hard in either arm |

The first five rows, 15 cases, are source-exposed investigator controls. The fresh three requests/baselines were authored without repository/source exposure, but were theme-targeted synthetic alternatives. Their later schema adaptation and all mutations are source-exposed. They are neither blind natural traffic nor representative independent accuracy samples. Bilingual pairs share scenes/baselines and are not counted as independent discoveries.

Four earlier V1 before-only executions are retained in `historical-v1-diagnostic-results.json`: three narrower old-wording positives and the superseded roofless canonical. Two other V1 canonicals were frozen but blocked before runtime. These are outside the final 18/36 denominator. `results.json` therefore preserves **40 total recorded arm executions**, of which 36 belong to the active V2 matrix. The input and before-run chronology remains visible through the `initial-13`, `with-fresh-16`, and `final-18` manifest snapshots.

## Same-runtime and rebuilt-index method

Both arms use the same unmodified `generate_candidate_pack` and `audit_composed_prompt` public functions from the clean pinned runtime. The six original before packs are object-for-object identical to their earlier actual public CLI packs. Normal envelope/core/creative-control/embodiment normalization remains in the path; no mocked resolver, hit list or fabricated vector was used.

Only the three alias fields were changed in a deep-copied full merged registry in memory. Each complete index was genuinely rebuilt by the production builder functions used by its CLI: `reusable_vectors`, `build_visual_profile_index_payload`, then `validate_visual_profile_index_metadata`. There were 1,622 profiles and **1,622/1,622 reusable cached vectors** in both arms. Every complete vector input text, provider/model/dimensions and vector value was checked unchanged. No text remained to embed, so zero embedding batches were dispatched. The old index rejects the changed registry hash. Exact lookup, BM25F documents/statistics and registry binding are regenerated.

- Before rebuilt index equals the installed index exactly
- Before registry hash: `e943d7d1af41c81d7495cfba05d3c0b19b335084c196689480790312682b9c22`
- After registry hash: `38217f0dc3d7dddb7ba53f132d558c69c62e1139ba16775c6641b3f575aa8b21`
- After index canonical hash: `6043ad09f323af032468a0c968ac68b2aad87ffb4ada428b18a1211275b2be79`

The full derived indexes were used in memory, with no large on-disk index copies. The receipt is `index-receipts/both-05f90f550cb3.json`. This is isolated source-data qualification, not a claim that an installed-file after-arm has already been run.

## Prompt and ordinary-candidate preservation

All 18 pairs have byte-identical positive prompt text and equal negative prompt text. The complete JSON objects, not just ID sets, are equal between arms for:

- ordinary slots and candidate bundles
- authorial core, creative controls and core retrieval
- semantic assertion obligations and embodiment preflight
- negative intent guard, adult appeal and creative augmentation

All original six inputs and every final matrix input retain their frozen hashes. No optional ordinary candidate or visual concept is adopted in the main matrix. Full equality and order checks are in `pairwise-results.json`; source/input integrity is in `final-integrity.json`.

## Optional redistribution

Optional profile exposure changes in six cases. This is disclosed separately from the intended hard-duty change:

| Case | Optional removal | Optional addition |
|---|---|---|
| Window V2 canonical | `pf_window_seat` | none |
| Window complete legacy | none | `pf_window_seat` |
| Helix V2 canonical | `pf_double_helix` | `rb_restrained_processing` |
| Helix complete legacy | none | `pf_double_helix` |
| Ruin V2 canonical | `pf_roofless_ruin` | `pf_keep_ward` |
| Ruin complete legacy | none | `pf_roofless_ruin` |

All IDs in this table are `visual-concept:` candidates. No ordinary-slot/bundle membership or ordering changes occur. The two non-target additions remain advisory and unadopted; they do not modify prompt prose or duties. This result does not establish that optional rankings are universally unchanged or that the new suggestions are desirable.

## Lost gates on valid old wording

The fully explicit legacy controls copy the independent review's exact old-wording-plus-all-English-facts texts. Every one currently activates its target and passes. After V2, the complete selected meaning remains in the frozen request/core/baseline, but the old literal trigger is gone. Thus the profile, required clarification, three evidence duties and three automatic render gates are absent. The profile becomes an optional concept in each of these three packs.

This is an accepted-but-visible precision/recall tradeoff for final review, not a “synonym-only” edit. Helper selection checks show that explicitly selecting each genuine optional profile restores its original three gates; those **three selected helper compositions are separate from the zero-adoption main matrix** and do not restore automatic coverage.

## Actual prose counterfactuals

Ten separate after-arm prompt mutations were passed through the unmodified public composed-audit CLI. The original packs/cores, input bindings and negative prose remain unchanged. Embodiment hashes and all supplied current evidence follow the actual changed text, so rejections are not manufactured by stale evidence or missing metadata.

**Three complete-legacy substitutions, 3/3 rejected by actual generic content anchors** (`counterfactuals/results.json`):

- requested masonry recess → same recess in solid timber
- requested helical flights → straight parallel flights
- requested fallen masonry → cleared stone floor

**Seven mutations of fresh after-arm scenes, 7/7 rejected by actual generic content anchors** (`generic-preservation/results.json`):

- full-depth timber wall/recess → masonry
- straight paths → helices
- separate routes → a middle merge/shared landing
- cleared floor → fallen rubble beneath broken walls
- absent roof/open sky → intact roof
- former enclosed room → freestanding outdoor wall
- real broken structural edges → intact moss-covered edges

Every case records the exact `intent_lock_prompt_evidence` failures and reports all other failures separately. Some substitutions remove more than one bound fact; they remain one mutation each. These are literal source-bound preservation checks. They do not prove detection of an appended contradiction that retains every literal anchor, a general owner/material reasoner, or restored native-pixel gate coverage.

## Helper-only boundary and gate coverage

These figures must not be pooled with the 18 public cases or interpreted as natural-query accuracy:

- Rebuilt V2 resolver: **15/15** controls, comprising three complete canonical positives, nine one-clause omissions and three disputed-relation substitutions. These use the full rebuilt index but are helper calls, not new public pack/composition runs
- Ownership controls: **10 bilingual source-guided cases / 20 before-after helper checks**, all pass. They cover wooden seat within masonry, same-owner timber plus unrelated masonry, empty center without winding, distinct hollow centers and rubble elsewhere. They establish exact activation boundaries, not semantic owner inference
- Generic names: **3 cases / 6 before-after full-index helper checks**, all remain non-hard
- Current installed-source focused regression: **31/31 test methods** pass, with 144 observed subtests and no failed subtests. These are current-source tests, not an after-installed suite
- Actual after canonical contract comparison: **3/3 profiles** retain all original English component/evidence/render contracts
- After canonical composed-duty helpers: **21/21 controls** (three unchanged positives, 18 evidence-field/prose mutations)
- After synthetic review-record helpers: **42/42 controls** (three positives, 39 partial/failed/missing/empty-evidence/extra-gate mutations). The sentinel bytes are explicitly not an image; no pixel observation or user acceptance exists
- Actual after legacy optional-selection helpers: **3/3 profiles** restore their original three gates when selected; original pack bytes and frozen prose remain unchanged
- Selected-contract synthetic review helpers add **21/21 controls**. Combined synthetic review validation is **63/63** (six complete controls and 57 expected rejections), kept separate from public prompt audits and image evidence

Artifacts are under `helper-coverage/`. The complete promotion-check mapping is in `coverage-checklist.json`.

## Adapter history

Original audit preflight corrections remain documented in the parent audit's `adapter-notes.json`. Qualification's additional9, fresh3 and reviewedV2 six input normalizations have **zero rejected attempts and zero schema repairs**. Every attempt and raw resolver output is preserved. Fresh request/baseline bytes, including explicit negative sentences, were not rewritten.

One planned V2 ownership adaptation is disclosed: the reviewed exact texts specify an arrangement but do not expressly request photography. Their concept anchor therefore uses the already-present baseline phrase “the visible arrangement” instead of locking photographic format. No baseline or architectural fact changed.

The original `frozen-public-requests.json` includes unused shared template `tail` metadata on English rows. Actual frozen English baselines/cores/compositions are the coherent selected positive scenes. This unused metadata was not consumed, silently corrected, or used to manufacture a failure.

## Unapplied installer and regression draft

`install_palace_aliases_v2.py` defaults to dry-run and requires an explicit `--apply` for any installation. It pins the clean source HEAD, raw source/index hashes and reviewed proposal hash; replaces exactly three JSON string values; requires all 1,622 vectors to be reusable; rebuilds through the actual full-index builder with no provider fallback; verifies the qualified index hash; and permits only the target profile source file and visual-profile index to differ. It performs no Git, ordinary dictionary/general-index, runtime-code or historical-source edits. The source/index apply branch has validation and rollback, but **has not been executed**.

The dry-run passed and produced `installer-dry-run-receipt.json` with `applied: false`. `planned_test_photo_palace_korean_relation_alignment.py` is an outside-repository six-method regression draft using the real registry/index; syntax parsed successfully. It is not installed or claimed to pass against the still-unmodified production data.

## Remaining boundaries

- No installed-file after-arm or installed-source regression run, because application is explicitly not authorized in this task
- No live/representative natural-language evaluation or recovery of lost legacy automatic coverage
- Clause-omission, owner and generic-name boundary controls are helper-only, not extra end-to-end public cases
- No new generic semantic contradiction/owner inference capability is claimed
- No full unrelated test-suite run, generated image, native-pixel qualification, user aesthetic judgment or publication

Within this bounded isolated task, no observed input, runtime, baseline-preservation, index-integrity or gate-check failure remains unresolved. Final independent review determines whether the measured recall/optional-exposure tradeoffs are acceptable for later installation.

## Main evidence

- `proposal-v2/`, `reviewed-v2-input-manifest.json`: exact reviewed source changes and separately frozen V2 inputs
- `frozen-input-manifest.final-18.json`: active matrix; earlier manifest snapshots preserve chronology
- `results.json`, `summary.json`, `pairwise-results.json`: actual runs, denominators, hard/optional collateral and full ordinary/prose equality
- `before/`, `after/`: complete admitted packs, unchanged baseline compositions and audit outputs
- `index-receipts/`, `source-mutation-diffs/`: genuine full-index rebuild/cache proof and exact isolated changes
- `counterfactuals/`, `generic-preservation/`: ten truthful after-arm public-auditor substitutions
- `helper-coverage/`: separately labeled resolver, regression, contract, selection and synthetic-review checks
- `final-integrity.json`, `qualification-artifact-manifest.json`: source/input integrity and final deliverable hashes
