"""Truthful prompt substitutions after removal of the old exact-trigger gates.

Immutable input cores/packs remain unchanged. Current prose, supplied evidence,
and embodiment prompt hashes follow the actual substitutions. Generic source-bound
prompt-content failures are reported separately from frozen-evidence metadata checks.
"""
import copy,hashlib,json,os,subprocess,sys
from pathlib import Path
sys.dont_write_bytecode=True
R=Path('/workspace/scratch/ce8f20680f5a/image-prompt');Q=Path(__file__).parent;S=R/'skills/photo-prompt-image-generator';O=Q/'counterfactuals';O.mkdir(exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
def write(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
manifest=json.loads((Q/'frozen-input-manifest.json').read_text())
selected=[c for c in manifest['cases']if c.get('role')=='old_ko_complete_positive_v2'];assert len(selected)==3
mutants={
 'pf_window_seat':('masonry_to_timber',{'a built-in seat occupies the depth of the masonry recess':'a built-in seat occupies the depth of the solid timber recess'},['relation_1','structural_state','recess_material']),
 'pf_double_helix':('helical_to_straight',{'two distinct helical stair flights wind around one core':'two distinct straight stair flights rise in parallel beside one core'},['relation_1','structural_state']),
 'pf_roofless_ruin':('fallen_masonry_to_cleared_floor',{'localized fallen masonry lies below the broken upper structure':'a cleared stone floor lies below the broken upper structure'},['relation_3','structural_state']),
}
env={k:v for k,v in os.environ.items()if not any(t in k.upper()for t in ['TOKEN','API_KEY','CREDENTIAL'])};env['PYTHONDONTWRITEBYTECODE']='1'
rows=[]
for case in selected:
 pid=case['profile_id'];P=Q/'after'/case['id'];packfile=P/'candidate-pack.json';pack=json.loads(packfile.read_text())[0];base=json.loads((P/'composed-baseline.json').read_text());passed=json.loads((P/'composed-audit.json').read_text());assert passed['status']=='pass'
 assert pid not in [o['id']for o in(pack.get('visual_obligations')or{}).get('obligations',[])]
 name,replacements,expected=mutants[pid];c=copy.deepcopy(base);prompt=c['prompt_en']
 for old,new in replacements.items():assert old in prompt;prompt=prompt.replace(old,new)
 c['prompt_en']=prompt;c['embodiment_review']['review']['prompt_sha256']=sha(prompt.encode());c['embodiment_review']['review']['summary']='The substituted prose still describes stationary architecture. No living-body mechanism is present. The changed physical relation is intentionally evaluated against the original immutable requester contract.'
 for ev in c.get('semantic_assertion_evidence',{}).get('evidence',{}).values():
  for field,value in list(ev.items()):
   for old,new in replacements.items():value=value.replace(old,new)
   ev[field]=value;assert value in prompt,(case['id'],field,value)
 for d in c['semantic_clarification_decisions']:
  value=d.get('prompt_evidence','')
  for old,new in replacements.items():value=value.replace(old,new)
  d['prompt_evidence']=value
  if d['decision']=='applied':assert value in prompt
 for ev in c.get('visual_obligation_evidence',{}).values():
  for field,value in list(ev.items()):
   for old,new in replacements.items():value=value.replace(old,new)
   ev[field]=value;assert value in prompt
 assert c['authorial_core_binding']==base['authorial_core_binding']and c['core_retrieval_sha256']==base['core_retrieval_sha256']and c['negative_en']==base['negative_en']
 path=O/(pid+'_'+name+'.composed.json');write(path,c)
 cmd=[sys.executable,str(S/'scripts/audit_composed_prompt.py'),'--pack',str(packfile),'--composed',str(path)]
 r=subprocess.run(cmd,cwd=R,env=env,capture_output=True,text=True,timeout=120);(O/(pid+'_'+name+'.audit.stdout.json')).write_text(r.stdout);(O/(pid+'_'+name+'.audit.stderr.txt')).write_text(r.stderr);a=json.loads(r.stdout)
 actual=[f for f in a['failures']if f['check']=='intent_lock_prompt_evidence'];actual_ids={f['anchor_id']for f in actual}
 rows.append({'case':case['id'],'profile_id':pid,'mutation':name,'replacements':replacements,'command':cmd,'returncode':r.returncode,'audit_status':a['status'],'failures':a['failures'],'actual_prompt_content_failures':actual,'other_failures_not_counted_as_content_protection':[f for f in a['failures']if f['check']!='intent_lock_prompt_evidence'],'expected_anchor_ids':expected,'expected_content_rejections_observed':set(expected)<=actual_ids,'source_pack_sha256':sha(packfile.read_bytes()),'core_and_pack_unchanged':True,'valid_binding_hashes_preserved':True,'evidence_literal_and_truthful':True,'automatic_target_profile_absent':True,'original_after_baseline_audit':'pass','new_adoption_count':0})
 assert a['status']=='fail'and set(expected)<=actual_ids,(case['id'],a)
 print(case['id'],'actual content failures',sorted(actual_ids),flush=True)
write(O/'results.json',{'scope':'Three source-guided actual prompt substitutions against old-Korean explicit-positive after-arm packs, where the edited automatic profile is absent.','limitation':'Literal generic source anchors reject these exact altered facts. This is not a general semantic contradiction detector, restored pixel-gate coverage, or rendered-image evidence.','cases':rows})
