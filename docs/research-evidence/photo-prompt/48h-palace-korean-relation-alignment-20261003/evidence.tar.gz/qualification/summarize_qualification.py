"""Summarize observed pairs without hiding optional/gate collateral."""
import collections,hashlib,json,subprocess
from pathlib import Path
R=Path('/workspace/scratch/ce8f20680f5a/image-prompt');Q=Path(__file__).parent;O=Q.parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
manifest=json.loads((Q/'frozen-input-manifest.json').read_text());all_results=json.loads((Q/'results.json').read_text());active_ids={c['id']for c in manifest['cases']};results=[r for r in all_results if r['case']in active_ids];historical=[r for r in all_results if r['case']not in active_ids];by={(r['case'],r['arm']):r for r in results};pairs=[]
write(Q/'historical-v1-diagnostic-results.json',{'scope':'Preserved earlier source-guided V1 diagnostics excluded from the final active18 denominator; these are not silently replaced or counted as V2 qualification','cases':historical})
for c in manifest['cases']:
 a=by.get((c['id'],'before'));b=by.get((c['id'],'after'));row={'case':c['id'],'cohort':c['cohort'],'profile_id':c.get('profile_id'),'role':c.get('role'),'before_present':a is not None,'after_present':b is not None}
 if a and b:
  row.update(before_audit=a.get('audit_status'),after_audit=b.get('audit_status'),before_admission=a['admission'],after_admission=b['admission'],baseline_unchanged_in_both=a.get('baseline_unchanged')and b.get('baseline_unchanged'),before_failures=a.get('failures'),after_failures=b.get('failures'),before_hard_ids=a['hard_ids'],after_hard_ids=b['hard_ids'])
  for key in ['hard_ids','hard_gate_ids','optional_visual_ids','ordinary_candidate_ids','bundle_ids']:
   old=set(a.get(key,[]));new=set(b.get(key,[]));row[key+'_removed']=sorted(old-new);row[key+'_added']=sorted(new-old);row[key+'_membership_unchanged']=old==new;row[key+'_order_unchanged']=a.get(key,[])==b.get(key,[])
  row['before_optional_visual_ids']=a['optional_visual_ids'];row['after_optional_visual_ids']=b['optional_visual_ids']
  row['before_required_clarifications']=[x['id']for x in a['clarifications']if x['required']];row['after_required_clarifications']=[x['id']for x in b['clarifications']if x['required']]
  ap=json.loads((Q/'before'/c['id']/'candidate-pack.json').read_text())[0];bp=json.loads((Q/'after'/c['id']/'candidate-pack.json').read_text())[0]
  surfaces=['slots','candidate_bundles','authorial_core','creative_controls','negative_en','core_retrieval','semantic_assertion_obligations','embodiment_preflight','negative_intent_guard','adult_appeal','creative_augmentation']
  assert all(k in ap and k in bp for k in surfaces)
  row['full_surface_equality']={k:ap[k]==bp[k]for k in surfaces}
  ac=json.loads((Q/'before'/c['id']/'composed-baseline.json').read_text());bc=json.loads((Q/'after'/c['id']/'composed-baseline.json').read_text())
  row['positive_prose_byte_equal_between_arms']=ac['prompt_en'].encode()==bc['prompt_en'].encode()
  row['negative_prose_byte_equal_between_arms']=ac['negative_en']==bc['negative_en']
 pairs.append(row)
write(Q/'pairwise-results.json',pairs)
cohorts={}
for name in sorted({c['cohort']for c in manifest['cases']}):
 cases=[c for c in manifest['cases']if c['cohort']==name];ids={c['id']for c in cases};obs=[r for r in results if r['case']in ids]
 cohorts[name]={'planned_cases':len(cases),'planned_arm_executions':2*len(cases),'completed_arm_executions':len(obs),'by_arm':{arm:{'completed':sum(r['arm']==arm for r in obs),'admitted':sum(r['arm']==arm and r['admission']=='pass'for r in obs),'audit_pass':sum(r['arm']==arm and r.get('audit_status')=='pass'for r in obs),'audit_fail':sum(r['arm']==arm and r.get('audit_status')=='fail'for r in obs)}for arm in ['before','after']}}
write(Q/'summary.json',{'planned_cases':len(manifest['cases']),'planned_arm_executions':2*len(manifest['cases']),'completed_arm_executions':len(results),'historical_v1_executions_not_in_active_denominator':len(historical),'all_recorded_arm_executions':len(all_results),'paired_cases_completed':sum(p['before_present']and p['after_present']for p in pairs),'cohorts':cohorts,'roles':dict(collections.Counter(c.get('role')for c in manifest['cases'])),'limitations':['Source-guided controls are not blind or naturally sampled requests','Fresh3 has source-unexposed theme-targeted baseline authoring, followed by source-exposed schema adaptation','No rendered-image or artistic-quality claim','Lost profile gates are not recreated by generic prompt-content anchor checks']})
invariants=json.loads((Q/'source-invariants.json').read_text());source_checks={p:sha(R/p)==h for p,h in invariants['source_sha256'].items()};input_checks={c['id']:{p:sha(Path(c['input_dir'])/p)==h for p,h in c['files'].items()}for c in manifest['cases']};assert all(source_checks.values())and all(all(v.values())for v in input_checks.values())
status=subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True);head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert status==''and head==invariants['head']
write(Q/'final-integrity.json',{'head':head,'git_status_porcelain':status,'source_hashes_unchanged':source_checks,'qualification_input_hashes_unchanged':input_checks,'original_input_manifest_unchanged':sha(O/'frozen-public-input-manifest.json')==invariants['original_manifest_sha256'],'v1_proposal_manifest_unchanged':sha(O/'proposal/proposed-edits.json')==invariants['v1_proposal_manifest_sha256'],'provider_calls':0,'images':0,'production_changes':0,'git_writes':0})
print(json.dumps({'cases':len(manifest['cases']),'completed_arm_executions':len(results),'paired':sum(p['before_present']and p['after_present']for p in pairs),'source_and_input_integrity':'pass'}))
