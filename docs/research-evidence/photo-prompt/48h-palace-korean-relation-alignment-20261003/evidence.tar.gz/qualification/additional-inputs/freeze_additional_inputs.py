"""Freeze nine source-guided maintenance controls; never load retrieval DATA.

This is maintenance preparation after source exposure, not blind pre-core authoring.
No original files, production files, Git state, candidate packs or providers change.
"""
import contextlib
import copy
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import traceback

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
Q = HERE.parent
AUDIT = Q.parent
REPO = AUDIT.parent.parent / 'image-prompt'
SKILL = REPO / 'skills/photo-prompt-image-generator'
PIN = 'ca0f6d80c85e2538883da9a5a0e01818dfe7df0c'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def load(path):
    return json.loads(path.read_text(encoding='utf-8'))

def write(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip()
status_before = subprocess.check_output(['git', 'status', '--porcelain=v1'], cwd=REPO, text=True)
assert head == PIN and not status_before, (head, status_before)
proposal_path = AUDIT / 'proposal/proposed-edits.json'
proposal = load(proposal_path)
edits = {edit['profile_id']: edit for edit in proposal['edits']}
original_manifest_path = AUDIT / 'frozen-public-input-manifest.json'
original_manifest = load(original_manifest_path)
original_requests_path = AUDIT / 'frozen-public-requests.json'
original_requests = {row['id']: row for row in load(original_requests_path)['cases']}
assert sha(original_requests_path.read_bytes()) == original_manifest['frozen_requests_sha256']
original_integrity = {}
for row in original_manifest['cases']:
    for filename, expected_sha in row['files'].items():
        path = AUDIT / 'public-controls' / row['id'] / filename
        actual_sha = sha(path.read_bytes())
        assert actual_sha == expected_sha, str(path)
        original_integrity[str(path.relative_to(AUDIT))] = actual_sha

# Requests are frozen here before resolver/normalization. English controls translate
# the Korean scene, retaining contradictions to the omitted selected fact exactly.
english_negatives = {
    'pf_window_seat': 'Make an architectural photograph: the seat is set within the depth of the wall; the window side reveals connect to the outer opening; the scene is distinguishable from a piece of furniture placed in front of a window. The wall is a thick solid-timber structure, and the fixed seat inside the wall and the window side reveals continue in solid timber. This same wall and its deep window side reveals are solid timber, with exposed timber end grain and timber joinery visible through the full wall depth.',
    'pf_double_helix': 'Make an architectural photograph: two stair routes can be traced; the shared central core is visibly hollow; the two routes do not arbitrarily merge or collide midway. The two stairs are parallel straight flights rising straight along opposite sides of the empty central space.',
    'pf_roofless_ruin': 'Make an architectural photograph: the sky is visible from inside the room because the roof is missing; the remaining walls, windows and floor form the former interior; the damage is connected to structural boundaries and is more than merely moss. The cut sections of the damaged upper walls are clearly visible, and all fallen stones and bricks have been cleared from the floor, leaving only smooth stone slabs.',
}
# The appended selected fact is copied verbatim from the relevant proposal clause;
# it cannot introduce a different fact or tune the proposed complete exact term.
changed_component_index = {'pf_window_seat': 0, 'pf_double_helix': 0, 'pf_roofless_ruin': 2}
cases = []
for pid in ['pf_window_seat', 'pf_double_helix', 'pf_roofless_ruin']:
    edit = edits[pid]
    append_fact = edit['new_value'].split('; ')[changed_component_index[pid]]
    variants = [
        ('compatible_en', 'compatible_ko', english_negatives[pid], 'English translation of the original Korean compatible negative scene'),
        ('old_ko_plus_selected_fact', 'selected_en_control', '건축 사진을 만들어 주세요: ' + edit['old_value'] + '. ' + append_fact + '.', 'Original Korean exact trigger plus the explicitly omitted selected fact'),
        ('proposed_ko_complete', 'selected_en_control', '건축 사진을 만들어 주세요: ' + edit['new_value'] + '.', 'Frozen proposed Korean canonical exact term, copied without modification'),
    ]
    for role, source_role, request, derivation in variants:
        case_id = pid + '_' + role
        source_id = pid + '_' + source_role
        source_core = load(AUDIT / 'public-controls' / source_id / 'authorial-core.json')
        baseline = source_core['baseline_prompt_en']
        assert baseline.encode('utf-8') == original_requests[source_id]['baseline'].encode('utf-8')
        case = {'id': case_id, 'profile_id': pid, 'role': role, 'template_case_id': source_id,
                'request': request, 'request_sha256': sha(request.encode('utf-8')),
                'baseline_prompt_en': baseline, 'baseline_prompt_utf8_sha256': sha(baseline.encode('utf-8')),
                'derivation': derivation, 'source_exposed': True, 'blind_data': False,
                'literal_old_value_present': edit['old_value'] in request,
                'literal_new_value_present': edit['new_value'] in request}
        if role == 'old_ko_plus_selected_fact':
            case['appended_fact_exact_from_proposal'] = append_fact
            assert case['literal_old_value_present'] and not case['literal_new_value_present']
        if role == 'proposed_ko_complete':
            assert case['literal_new_value_present'] and not case['literal_old_value_present']
        cases.append(case)
assert len(cases) == 9 and len({case['id'] for case in cases}) == 9
write(HERE / 'frozen-requests.json', {'contract_version': 'palace-additional-source-guided-inputs/v1', 'source_exposed': True, 'blind_data': False, 'cases': cases})

# Fail closed if normalizers try to read candidate DATA or use a network socket.
# Importing the normal core loader defines shared functions but invokes no runtime
# retrieval. The only normal functions invoked below are the envelope/core loaders
# and embodiment policy validator, plus the candidate-free pre-core resolver.
isolation_events = []
def audit_hook(event, args):
    if event == 'open' and isinstance(args[0], (str, bytes, os.PathLike)):
        path = Path(os.fsdecode(args[0])).absolute()
        if str(path).startswith(str(SKILL / 'assets') + os.sep):
            isolation_events.append({'event': event, 'path': str(path), 'blocked': True})
            raise RuntimeError('Runtime retrieval DATA access is forbidden in this input-only task')
    if event in ('socket.connect', 'socket.connect_ex', 'socket.getaddrinfo'):
        isolation_events.append({'event': event, 'blocked': True})
        raise RuntimeError('Provider/network access is forbidden in this input-only task')
sys.addaudithook(audit_hook)
sys.path.insert(0, str(SKILL / 'scripts'))
import prompt_generator as generator
spec = importlib.util.spec_from_file_location('qualification_candidate_free_controls', SKILL / 'precore/creative_controls.py')
controls_module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(controls_module)

results = []
rejections = []
allowed_inputs = ['request-envelope.json', 'creative-context.json', 'creative-controls.json', 'control-resolution.json', 'authorial-core.json', 'embodiment-review.json']

def rebind_source_text(value, raw):
    if isinstance(value, dict):
        return {key: raw if key == 'source_text' else rebind_source_text(child, raw) for key, child in value.items()}
    if isinstance(value, list):
        return [rebind_source_text(child, raw) for child in value]
    return value

def source_texts(value):
    if isinstance(value, dict):
        for key, child in value.items():
            if key == 'source_text':
                yield child
            else:
                yield from source_texts(child)
    elif isinstance(value, list):
        for child in value:
            yield from source_texts(child)

for case in cases:
    folder = HERE / case['id']
    attempt = folder / 'attempts/attempt-001'
    attempt.mkdir(parents=True, exist_ok=False)
    source = AUDIT / 'public-controls' / case['template_case_id']
    raw = case['request']
    baseline = case['baseline_prompt_en']
    (attempt / 'request.txt').write_bytes(raw.encode('utf-8'))
    (attempt / 'baseline.txt').write_bytes(baseline.encode('utf-8'))
    envelope = copy.deepcopy(load(source / 'request-envelope.json'))
    envelope.update(request_id='synthetic-palace-qualification-' + case['id'], request_text=raw, request_sha256=case['request_sha256'], active_spans=[{'span_id': 'scene', 'start': 0, 'end': len(raw), 'text': raw}])
    write(attempt / 'request-envelope.json', envelope)
    (attempt / 'creative-context.json').write_bytes((source / 'creative-context.json').read_bytes())
    (attempt / 'embodiment-review.json').write_bytes((source / 'embodiment-review.json').read_bytes())
    source_controls = load(source / 'creative-controls.json')
    seed = source_controls['seed']
    resolver_args = ['--request-envelope-json', str(attempt / 'request-envelope.json'), '--context-json', str(attempt / 'creative-context.json'), '--seed', str(seed), '--output', str(attempt / 'creative-controls.json')]
    stdout, stderr = io.StringIO(), io.StringIO()
    try:
        with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
            rc = controls_module.main(resolver_args)
        assert rc in (None, 0), rc
        controls = load(attempt / 'creative-controls.json')
        write(attempt / 'control-resolution.json', json.loads(stdout.getvalue()))
        # Seed/defaults/definitions stay equal to the matched original control.
        for field in source_controls:
            if field not in ('source_request_sha256', 'canonical_sha256'):
                assert controls[field] == source_controls[field], (case['id'], field)
        core = rebind_source_text(copy.deepcopy(load(source / 'authorial-core.json')), raw)
        core['source_request'] = raw
        core['creative_controls_sha256'] = controls['canonical_sha256']
        core['variation_key'] = case['id']
        write(attempt / 'authorial-core.json', core)
        assert core['baseline_prompt_en'].encode('utf-8') == baseline.encode('utf-8')
        assert all(text == raw for text in source_texts(core))
        assert all(anchor['prompt_evidence'] in baseline for anchor in core['intent_lock']['semantic_anchors'])
        envelope_normalized = generator.load_request_envelope_arg(str(attempt / 'request-envelope.json'))
        normalized = generator.load_authorial_core_arg(str(attempt / 'authorial-core.json'), request_envelope=envelope_normalized, creative_control_snapshot=controls)
        embodiment = generator.photo_embodiment.build_policy(normalized, load(attempt / 'embodiment-review.json'))
        assert normalized['baseline_prompt_en'].encode('utf-8') == baseline.encode('utf-8')
        write(attempt / 'normalized-authorial-core.json', normalized)
        write(attempt / 'embodiment-policy.json', embodiment)
        result = {'id': case['id'], 'attempt': 1, 'status': 'pass', 'request_envelope_normalization': 'pass', 'creative_controls_resolution': 'pass', 'core_normalization': 'pass', 'embodiment_binding': 'pass', 'baseline_byte_identical_to_template': True, 'source_text_citations_rebound_exactly': True, 'source_text_citation_count': len(list(source_texts(core))), 'creative_control_values_definitions_and_seed_identical_to_template': True, 'source_request_sha256': case['request_sha256'], 'baseline_prompt_utf8_sha256': case['baseline_prompt_utf8_sha256'], 'creative_controls_canonical_sha256': controls['canonical_sha256'], 'authorial_core_canonical_sha256': normalized['canonical_sha256'], 'intent_lock_canonical_sha256': normalized['intent_lock']['canonical_sha256'], 'request_envelope_canonical_sha256': envelope_normalized['canonical_sha256']}
    except BaseException as error:
        result = {'id': case['id'], 'attempt': 1, 'status': 'rejected', 'error_type': type(error).__name__, 'error': str(error), 'traceback': traceback.format_exc()}
        rejections.append(result)
    (attempt / 'resolver.stdout.txt').write_text(stdout.getvalue(), encoding='utf-8')
    (attempt / 'resolver.stderr.txt').write_text(stderr.getvalue(), encoding='utf-8')
    write(attempt / 'validation.json', result)
    results.append(result)
    if result['status'] == 'pass':
        for filename in allowed_inputs + ['request.txt', 'baseline.txt']:
            (folder / filename).write_bytes((attempt / filename).read_bytes())

# Any failed attempt remains immutable. No automatic source/baseline modification.
write(HERE / 'validation-results.json', {'checks': results, 'schema_rejections': rejections, 'isolation_events': isolation_events})
for relpath, original_sha in original_integrity.items():
    assert sha((AUDIT / relpath).read_bytes()) == original_sha, relpath
assert sha(original_requests_path.read_bytes()) == original_manifest['frozen_requests_sha256']
status_after = subprocess.check_output(['git', 'status', '--porcelain=v1'], cwd=REPO, text=True)
assert status_after == status_before == ''

notes = {
    'contract_version': 'palace-additional-adapter-notes/v1',
    'source_exposed': True,
    'blind_data': False,
    'scope': 'Exactly nine added maintenance input controls; no production DATA, runtime retrieval, packs, providers, images or Git writes.',
    'translation_and_support_notes': {
        'pf_window_seat_compatible_en': 'The English request translates the original Korean compatible scene. The same thick wall and deep side reveals are exposed solid timber through their full depth, with end grain and joinery. The fixed seat belongs to that same recess. This is not merely a wooden bench or concealed construction. The baseline is byte-identical to the original compatible_ko core.',
        'pf_double_helix_compatible_en': 'Both routes remain parallel straight flights beside the same hollow core, not helical flights. The nonmerging/noncolliding paths are preserved. The baseline is byte-identical to the original compatible_ko core.',
        'pf_roofless_ruin_compatible_en': 'The structural damage and former-room enclosure remain; all fallen stone/brick debris has been removed, leaving smooth slabs. The baseline is byte-identical to the original compatible_ko core.',
        'old_ko_plus_selected_fact': 'Each original Korean exact trigger is copied from proposed-edits.json old_value, then the omitted selected fact is appended verbatim from the corresponding new_value clause. The full proposed exact term is absent. These are explicit true-scene positives that can expose the known exact-match recall tightening.',
        'proposed_ko_complete': 'Each proposed new_value is copied byte-for-byte into the architectural request, with only the shared Korean photographic-request prefix and final full stop around it. No proposed value was tuned.',
        'window_opening_relation': 'As in the original template, the outer-opening-beyond-seat-plane evidence realizes a fixed seat set within the wall/recess depth with side reveals connecting to the exterior opening. This retains the original source-exposed interpretation; it is not new independent translation/architecture evidence.',
    },
    'template_adaptation': ['Deep-clone original valid envelope/core schemas.', 'Rebind source_request, full active scene span, request hashes, request ID, every source_text citation, and variation_key.', 'Run the candidate-free resolver with each template control seed; retain every control value, definition, authoring brief and context unchanged.', 'Keep baseline UTF-8 bytes, subject/setting/event/priorities, anchor evidence, typed assertions, exclusions, style and embodiment-review bytes unchanged.', 'Call only normal request-envelope/core normalization and embodiment build_policy; preserve full attempt inputs, raw resolver output and validation output.'],
    'schema_rejections': rejections,
    'corrections': [],
    'post_freeze_input_or_baseline_edits': 0,
    'original_inputs_verified_unchanged': True,
    'production_status_before': status_before,
    'production_status_after': status_after,
    'provider_calls': 0, 'images': 0, 'runtime_retrieval_calls': 0, 'candidate_packs_generated': 0, 'git_writes': 0,
    'isolation_guard': {'runtime_asset_open_denied': True, 'socket_network_denied': True, 'events': isolation_events},
    'limits': ['Source-exposed maintenance controls, not blind/natural-query accuracy data.', 'Normalization and embodiment binding are input-integrity checks, not after-arm composed or image-quality evidence.', 'No production proposal or index was installed or qualified by this task.'],
}
write(Q / 'additional-adapter-notes.json', notes)
manifest_cases = []
for case, result in zip(cases, results):
    folder = HERE / case['id']
    row = {key: case[key] for key in ['id', 'profile_id', 'role', 'template_case_id', 'request_sha256', 'baseline_prompt_utf8_sha256', 'derivation', 'literal_old_value_present', 'literal_new_value_present']}
    row['directory'] = str(folder)
    row['template_directory'] = str(AUDIT / 'public-controls' / case['template_case_id'])
    row['baseline_byte_identical_to_template'] = result.get('baseline_byte_identical_to_template', False)
    row['validation'] = result
    row['files'] = {filename: sha((folder / filename).read_bytes()) for filename in allowed_inputs + ['request.txt', 'baseline.txt'] if (folder / filename).exists()}
    row['attempt_files'] = {str(path.relative_to(folder)): sha(path.read_bytes()) for path in sorted((folder / 'attempts').rglob('*')) if path.is_file()}
    manifest_cases.append(row)
manifest = {
    'contract_version': 'palace-additional-input-manifest/v1', 'repository_head': PIN,
    'status': 'frozen_and_normalized' if not rejections else 'blocked_with_preserved_rejections',
    'source_exposed': True, 'blind_data': False, 'case_count': len(cases),
    'role_counts': {role: sum(case['role'] == role for case in cases) for role in ['compatible_en', 'old_ko_plus_selected_fact', 'proposed_ko_complete']},
    'provenance': {'proposal_path': str(proposal_path), 'proposal_sha256': sha(proposal_path.read_bytes()), 'original_manifest_path': str(original_manifest_path), 'original_manifest_sha256': sha(original_manifest_path.read_bytes()), 'original_requests_path': str(original_requests_path), 'original_requests_sha256': sha(original_requests_path.read_bytes()), 'source_input_file_hashes': original_integrity},
    'support_files': {path.name: sha(path.read_bytes()) for path in sorted(HERE.iterdir()) if path.is_file()},
    'adapter_notes_sha256': sha((Q / 'additional-adapter-notes.json').read_bytes()),
    'cases': manifest_cases,
    'execution': {'normalizations_passed': sum(result['status'] == 'pass' for result in results), 'schema_rejections': len(rejections), 'runtime_retrieval_calls': 0, 'provider_calls': 0, 'images': 0, 'candidate_packs_generated': 0, 'production_edits': 0, 'git_writes': 0},
}
write(Q / 'additional-input-manifest.json', manifest)
print(json.dumps({'manifest': str(Q / 'additional-input-manifest.json'), 'sha256': sha((Q / 'additional-input-manifest.json').read_bytes()), 'case_count': len(cases), 'normalizations_passed': manifest['execution']['normalizations_passed'], 'schema_rejections': len(rejections)}, ensure_ascii=False))
if rejections:
    print(json.dumps(rejections, ensure_ascii=False))
    raise SystemExit(1)
