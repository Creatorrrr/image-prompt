import json,hashlib,subprocess
from pathlib import Path
H=Path(__file__).parent;Q=H.parent;R=Path('/workspace/scratch/ce8f20680f5a/image-prompt')
read=lambda name:json.loads((H/name).read_text())
owner=read('owner-control-results.json');generic=read('generic-control-results.json');current=read('current-source-focused-tests.json');contracts=read('after-contract-surfaces.json');composed=read('after-composed-contract-mutations.json');gates=read('after-synthetic-review-gates.json');selected=read('after-selected-contracts.json')
coverage=[
 {'id':'original_public_six','coverage':'limited contribution','evidence':'Three before/after original English hard contracts unchanged; public generation and six-case outcome accounting belong to parent.'},
 {'id':'canonical_korean_positive','coverage':'actual-after artifact verification','evidence':'3/3 actual V2 canonical packs have original English components/evidence and three gates, literal baseline evidence, unchanged baseline prose, saved full composed audit pass. No new public packs generated here.'},
 {'id':'canonical_missing_clause','coverage':'not covered by this helper','evidence':'No final canonical clause-deletion resolver set executed here; defer to parent V2 boundary results.'},
 {'id':'canonical_relation_substitution','coverage':'helper-only partial contribution','evidence':'Owner controls substitute same-owner timber, straight stairs, separate cores and unrelated rubble with no embedded complete positive alias; does not replace frozen canonical substitution suite.'},
 {'id':'english_equivalent_negatives','coverage':'not covered by this helper','evidence':'Parent full paired public English equivalents remain separate from these different bilingual owner controls.'},
 {'id':'generic_content','coverage':'helper-only partial contribution','evidence':'Exact three reviewed generic_negative texts pass 6/6 current/V2 resolver checks with no hard imports. No full public generic pack or exclusion-preservation checks here.'},
 {'id':'valid_legacy_korean','coverage':'helper-only selected-variant contribution','evidence':'Actual after legacy-complete packs leave all three targets optional when unselected; local explicit selection restores all three gates with unchanged baseline prose and passes 3/3 full composed audits. Paired recall loss and fact preservation are parent work.'},
 {'id':'generic_preservation_mutations','coverage':'not covered by this helper','evidence':'No target-absent generic anchor/assertion mutations here. Our 18 focused composed mutations exercise active hard profile evidence only.'},
 {'id':'owner_material_controls','coverage':'helper-only bounded completed','evidence':'Five specified owner/relation scenarios in English and Korean, 10 frozen cases, 20/20 before/after checks, zero unrelated hard imports. Exact boundaries only; no semantic ownership inference claim.'},
 {'id':'index_integrity','coverage':'helper-only full-index execution evidence','evidence':'Both full 1,622-profile indexes genuinely rebuilt with production reusable_vectors/build_visual_profile_index_payload. 1,622/1,622 texts and vector values reused per arm; provider/model/dimensions preserved; metadata passes and stale installed index fails against V2. Generic rerun reproduces exact index hashes. No index files written.'},
 {'id':'unchanged_contract_surfaces','coverage':'target contract subset completed','evidence':'3/3 target English component, evidence and render-gate projections match original English public packs and source; before/after original English obligations equal including activation. Clean pinned checkout and input hashes preserved. Full 18-pair ordinary candidate/bundle invariance belongs to parent.'},
 {'id':'contract_and_gate_mutations','coverage':'bounded current/after checks completed separately','evidence':'Current source 31/31 methods (144 observed subtests); actual after hard contracts 3/3 profiles; focused composed checks 21/21 (3 positives + 18 mutations); selected full composed audits 3/3; synthetic review checks 63/63 (6 complete controls + 57 rejections), including partial/fail on every hard and selected target gate.'}
]
all_pass=owner['failed']==0 and generic['passed']==6 and current['passed_test_methods']==31 and contracts['passed_profiles']==3 and composed['passed']==21 and gates['passed']==42 and selected['profiles_passed']==3 and selected['synthetic_gate_passed']==21
summary={'overall_bounded_helper_status':'pass' if all_pass else 'fail','source_pin':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'git_status_porcelain':subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True),'provider_calls':0,'rendered_images':0,'production_writes':0,'new_public_packs':0,'pending_helper_work':False,'counts':{'owner_cases':10,'owner_before_after_checks':20,'generic_cases':3,'generic_before_after_checks':6,'current_test_methods':31,'observed_current_subtests':144,'after_canonical_contract_profiles':3,'after_focused_composed_checks':21,'after_selected_full_composed_audits':3,'synthetic_render_review_checks':63,'synthetic_positive_controls':6,'synthetic_negative_mutations':57},'promotion_check_coverage':coverage,'limitations':['All controls are source-exposed and helper-only, not natural-query holdouts.','Owner/material tests establish literal exact-alias boundaries, not semantic inference about owners or truth of prose.','Existing focused tests may use fake vectors or reduced registries; those remain unit evidence. Helper resolver before/after uses the complete real registry and genuine cached full index.','Synthetic render-review sentinel files are not images; they test record validators only. No actual pixel, perceptual quality, or user acceptance evidence exists.','Full public paired qualification and generic target-absent preservation mutation evidence must be read from parent artifacts; this helper alone is not complete promotion qualification.']}
assert summary['source_pin']=='ca0f6d80c85e2538883da9a5a0e01818dfe7df0c' and summary['git_status_porcelain']==''
(H/'coverage-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
report='''# Palace reviewed-V2 helper qualification

All bounded helper checks passed. Repository remains clean at `ca0f6d80c85e2538883da9a5a0e01818dfe7df0c`. No providers, rendered images, production writes, index copies, or new public packs.

## Exact denominators

- Ownership: 10 source-exposed frozen cases (five scenarios × English/Korean), 20/20 before/after resolver checks, zero unrelated hard imports
- Simple generic controls: exact three reviewed `generic_negative` texts, 6/6 before/after checks, no hard imports
- Current-source tests: 31/31 methods, zero failures/errors/skips; 144 explicitly observed subtests, zero failing subtests. Six palace + 13 retrieval + seven character-review + five focused visual/selection tests
- Actual after canonical contract surfaces: 3/3 profiles preserve English components, evidence requirements and all three render gates. Before/after original English contracts also equal
- Focused production composed-obligation checker: 21/21 controls, comprising three actual complete positives and 18 required-field/literal-evidence removal or replacement rejections
- Actual after legacy-complete packs, explicit helper-only opt-in: 3/3 full composed audits pass with unchanged frozen prose. Unselected targets remain optional; selecting the actual eligible candidate restores all three target gates
- Synthetic review validator: 63/63 checks across hard and selected targets, six complete-record controls and 57 negative mutations. Every target gate rejects partial and failed status; hard canonical gates additionally reject missing/empty evidence, plus extra-gate controls

## Index and ownership boundary

Before and V2 after each use the full 1,622-profile merged registry and production `reusable_vectors` / `build_visual_profile_index_payload` builder. All 1,622 cached embedding texts and vector values are unchanged; provider/model/dimensions remain the same. Metadata validation passes; the old installed index is rejected for the V2 registry. Generic checks rebuild and reproduce the same full-index hashes. No reduced or fabricated index is used as after evidence.

The wooden-seat positive expressly retains the complete masonry-recess relationship. Negatives replace the owned material, winding, shared center, or localized rubble relation; none embeds a full positive alias followed by a contradictory tail. These results establish only the tested exact boundary. They do not establish semantic ownership reasoning, general paraphrase recall, or a prose contradiction oracle.

## Promotion-check coverage and gaps

Completed within bounded helper scope: `owner_material_controls`, `index_integrity` execution checks, `contract_and_gate_mutations`. Actual artifacts also contribute to `canonical_korean_positive`, target-only `unchanged_contract_surfaces`, and selected-variant `valid_legacy_korean`. Simple resolver checks contribute only part of `generic_content`; owner substitutions contribute only part of `canonical_relation_substitution`; English contract comparison contributes only part of `original_public_six`.

Not executed here: the final canonical missing-clause set, frozen English-equivalent public negatives, all public generic preservation/exclusion checks, target-absent generic anchor/assertion mutations, or the full 18-pair candidate/bundle/source invariant suite. Parent artifacts own those checks. See `coverage-summary.json` for every exact promotion-check ID.

Current-source compatibility tests and actual-after checks are separate. Existing unit fixtures with reduced/fake indexes are not full-index after evidence. All synthetic gate inputs explicitly say they are synthetic; sentinel bytes are not images, and user judgment remains pending. No pixel or quality claim is supported. All results, including expected validator failures, are preserved. No helper work remains pending.
'''
(H/'REPORT.md').write_text(report)
files=[{'path':str(p.relative_to(H)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(H.rglob('*')) if p.is_file() and p.name!='artifact-manifest.json']
(H/'artifact-manifest.json').write_text(json.dumps({'scope':'helper-coverage only','files':files},ensure_ascii=False,indent=2)+'\n')
print(json.dumps(summary['counts'])); print('bounded_helper_status='+summary['overall_bounded_helper_status'])
