import copy,hashlib,json,sys,time
from pathlib import Path
sys.dont_write_bytecode=True
H=Path(__file__).parent;Q=H.parent;O=Q.parent;R=Path('/workspace/scratch/ce8f20680f5a/image-prompt');S=R/'skills/photo-prompt-image-generator';sys.path.insert(0,str(S/'scripts'))
import prompt_generator as g,build_visual_profile_index as b
sha=lambda v:hashlib.sha256(v).hexdigest();canon=lambda v:json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
def save(name,data):
 p=H/name
 if p.exists():raise RuntimeError('Do not overwrite '+str(p))
 p.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
p=O/'review/resolver-and-recall-probes.json';controls=[{k:c[k] for k in ('id','profile_id','group','text')} for c in json.loads(p.read_text())['cases'] if c['group']=='generic_negative'];assert len(controls)==3
save('frozen-generic-controls.json',{'scope':'Three exact source-exposed simple generic controls copied unchanged from reviewed probe file; helper-only, not full public packs','source':str(p),'source_sha256':sha(p.read_bytes()),'cases':controls})
start=time.time();data=g.load_runtime_data();installed=data[g.VISUAL_PROFILE_INDEX_DATA_KEY];reg=data[g.VISUAL_OBLIGATIONS_DATA_KEY];after=copy.deepcopy(reg);ep=Q/'proposal-v2/proposed-edits.json';edits=json.loads(ep.read_text())['edits']
for e in edits:
 p=next(p for p in after['profiles'] if p['id']==e['profile_id']);assert p['activation']['exact_terms'][1]==e['old_value'];p['activation']['exact_terms'][1]=e['new_value']
previous=json.loads((H/'owner-index-receipts.json').read_text())['arms'];receipts={};results=[]
for arm,registry in [('before',reg),('after',after)]:
 vs=b.reusable_vectors([S/'assets/photo_prompt_visual_profile_index.json'],registry,provider=g.SEMANTIC_PROVIDER,model=g.SEMANTIC_MODEL_ID,dimensions=g.DEFAULT_SEMANTIC_DIMENSIONS);assert len(vs)==len(registry['profiles']);assert all(installed['entries'][p['id']]['text']==g.visual_profile_semantic_text(p) for p in registry['profiles']);assert all(vs[k]==installed['entries'][k]['vector'] for k in vs)
 ix=b.build_visual_profile_index_payload(registry,vectors=vs,provider=g.SEMANTIC_PROVIDER,model=g.SEMANTIC_MODEL_ID,dimensions=g.DEFAULT_SEMANTIC_DIMENSIONS);g.validate_visual_profile_index_metadata(ix,registry);digest=sha(canon(ix));assert digest==previous[arm]['index_canonical_sha256']
 receipts[arm]={'profile_count':len(registry['profiles']),'cache_vectors_reused':len(vs),'all_text_and_vector_values_equal_to_installed':True,'index_canonical_sha256':digest,'matches_owner_control_index':True,'metadata_validation':'pass','provider_calls':0}
 for c in controls:
  res=g.resolve_visual_profile_hits(registry,[{'source':'concept_lock','text':c['text'],'polarity':'required','priority':'critical','mandatory':True}],visual_profile_index=ix,adult_context=False);hard=[h['profile_id'] for h in res['hits'] if h.get('hard_eligible')]
  results.append({'case_id':c['id'],'arm':arm,'hard_ids':hard,'expected_target_hard':False,'passed':not hard,'helper_only':True})
save('generic-control-results.json',{'scope':'Helper-only current/V2 exact resolver boundaries for three simple generic controls; no public-pack preservation claim','cases':3,'checks':6,'passed':sum(x['passed'] for x in results),'results':results,'index_receipts':receipts,'provider_calls':0,'seconds':time.time()-start});print(json.dumps({'checks':len(results),'passed':sum(x['passed'] for x in results),'seconds':time.time()-start}));sys.exit(any(not x['passed'] for x in results))
