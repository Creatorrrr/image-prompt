import json,sys,unittest,time,hashlib,subprocess
from pathlib import Path
R=Path('/workspace/scratch/ce8f20680f5a/image-prompt'); H=Path(__file__).parent
sys.path.insert(0,str(R)); sys.dont_write_bytecode=True
names=['tests.test_photo_palace_fortification_semantics','tests.test_photo_visual_profile_retrieval','tests.test_photo_character_render_review']
for name in ['test_composed_prompt_must_bind_every_distinct_visual_duty','test_indirect_components_surface_optional_candidate_and_selection_promotes_gates','test_selected_visual_concept_binds_runtime_and_render_review','test_visual_only_render_review_uses_effective_visual_gate_contract','test_visual_render_gate_failure_and_uncontracted_gate_fail_closed']:
 names.append('tests.test_photo_visual_obligations.PhotoVisualObligationTests.'+name)
class Records(unittest.TextTestResult):
 def __init__(self,*a,**k): super().__init__(*a,**k); self.rows=[]; self.subtest_total=0; self.subtest_failed=0
 def addSuccess(self,test): super().addSuccess(test); self.rows.append({'id':test.id(),'status':'pass'})
 def addFailure(self,test,err): super().addFailure(test,err); self.rows.append({'id':test.id(),'status':'fail','traceback':self._exc_info_to_string(err,test)})
 def addError(self,test,err): super().addError(test,err); self.rows.append({'id':test.id(),'status':'error','traceback':self._exc_info_to_string(err,test)})
 def addSubTest(self,test,subtest,err):
  super().addSubTest(test,subtest,err); self.subtest_total+=1
  if err: self.subtest_failed+=1
suite=unittest.defaultTestLoader.loadTestsFromNames(names); expected=suite.countTestCases(); start=time.time()
with (H/'current-source-focused-tests.log').open('w') as log:
 result=unittest.TextTestRunner(stream=log,verbosity=2,resultclass=Records).run(suite)
out={'scope':'Unmodified existing tests on current source; helper-only contract validation, not after-arm proof or image evidence','source_pin':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'test_names':names,'expected_test_methods':expected,'test_methods_run':result.testsRun,'passed_test_methods':sum(r['status']=='pass' for r in result.rows),'failures':len(result.failures),'errors':len(result.errors),'skipped':len(result.skipped),'observed_subtests':result.subtest_total,'failed_subtests':result.subtest_failed,'seconds':time.time()-start,'network_policy':'All outgoing socket connection/DNS attempts blocked by inherited helper sitecustomize audit guard; no providers requested','results':result.rows}
(H/'current-source-focused-tests.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n'); print(json.dumps({k:v for k,v in out.items() if k!='results'}));sys.exit(not result.wasSuccessful())
