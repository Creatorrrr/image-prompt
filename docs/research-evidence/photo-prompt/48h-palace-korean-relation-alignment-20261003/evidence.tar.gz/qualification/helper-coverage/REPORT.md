# Palace reviewed-V2 helper qualification

All bounded helper checks passed. Repository remains clean at `ca0f6d80c85e2538883da9a5a0e01818dfe7df0c`. No providers, rendered images, production writes, index copies, or new public packs.

## Exact denominators

- Ownership: 10 source-exposed frozen cases (five scenarios × English/Korean), 20/20 before/after resolver checks, zero unrelated hard imports
- Simple generic controls: exact three reviewed `generic_negative` texts, 6/6 before/after checks, no hard imports
- Current-source tests: 31/31 methods, zero failures/errors/skips; 144 explicitly observed subtests, zero failing subtests. Six palace + 13 retrieval + seven character-review + five focused visual/selection tests
- Actual after canonical contract surfaces: 3/3 profiles preserve English components, evidence requirements and all three render gates. Before/after original English contracts also equal
- Focused production composed-obligation checker: 21/21 controls, comprising three actual complete positives and 18 required-field/literal-evidence removal or replacement rejections
- Actual after legacy-complete packs, explicit helper-only opt-in: 3/3 full composed audits pass with unchanged frozen prose. Unselected targets remain optional; selecting the actual eligible candidate restores all three target gates
- Synthetic review validator: 63/63 checks across hard and selected targets, six complete-record controls and 57 negative mutations. Every target gate rejects partial and failed status; hard canonical gates additionally reject missing/empty evidence, plus extra-gate controls

## Index and ownership boundary

Before and V2 after each use the full 1,622-profile merged registry and production `reusable_vectors` / `build_visual_profile_index_payload` builder. All 1,622 cached embedding texts and vector values are unchanged; provider/model/dimensions remain the same. Metadata validation passes; the old installed index is rejected for the V2 registry. Generic checks rebuild and reproduce the same full-index hashes. No reduced or fabricated index is used as after evidence.

The wooden-seat positive expressly retains the complete masonry-recess relationship. Negatives replace the owned material, winding, shared center, or localized rubble relation; none embeds a full positive alias followed by a contradictory tail. These results establish only the tested exact boundary. They do not establish semantic ownership reasoning, general paraphrase recall, or a prose contradiction oracle.

## Promotion-check coverage and gaps

Completed within bounded helper scope: `owner_material_controls`, `index_integrity` execution checks, `contract_and_gate_mutations`. Actual artifacts also contribute to `canonical_korean_positive`, target-only `unchanged_contract_surfaces`, and selected-variant `valid_legacy_korean`. Simple resolver checks contribute only part of `generic_content`; owner substitutions contribute only part of `canonical_relation_substitution`; English contract comparison contributes only part of `original_public_six`.

Not executed here: the final canonical missing-clause set, frozen English-equivalent public negatives, all public generic preservation/exclusion checks, target-absent generic anchor/assertion mutations, or the full 18-pair candidate/bundle/source invariant suite. Parent artifacts own those checks. See `coverage-summary.json` for every exact promotion-check ID.

Current-source compatibility tests and actual-after checks are separate. Existing unit fixtures with reduced/fake indexes are not full-index after evidence. All synthetic gate inputs explicitly say they are synthetic; sentinel bytes are not images, and user judgment remains pending. No pixel or quality claim is supported. All results, including expected validator failures, are preserved. No helper work remains pending.
