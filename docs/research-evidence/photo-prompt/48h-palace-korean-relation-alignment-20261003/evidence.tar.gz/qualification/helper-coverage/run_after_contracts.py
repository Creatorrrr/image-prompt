"""Actual after canonical artifacts, with explicitly synthetic helper-only gate controls."""
import copy,hashlib,json,subprocess,sys,time
from pathlib import Path
sys.dont_write_bytecode=True
H=Path(__file__).parent;Q=H.parent;R=Path('/workspace/scratch/ce8f20680f5a/image-prompt');S=R/'skills/photo-prompt-image-generator';sys.path.insert(0,str(S/'scripts'))
import audit_composed_prompt as audit,audit_moe_render_review as render
sha=lambda b:hashlib.sha256(b).hexdigest()
canon=lambda x:json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
def read(p):return json.loads(p.read_text())
def save(name,x):
 p=H/name
 if p.exists():raise RuntimeError('Preserve existing artifact: '+str(p))
 p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
inputs={};contracts=[];composition=[];gates=[];start=time.time()
source_profiles={p['id']:p for p in read(S/'assets/photo_prompt_visual_obligations_palace_fortification.json')['profiles']}
placeholder=H/'synthetic-not-image.bin';placeholder.write_bytes(b'HELPER-ONLY SCHEMA TEST BYTES. This is not an image, render, pixel review, or actual evidence.')
for pid in ('pf_window_seat','pf_double_helix','pf_roofless_ruin'):
 folder=Q/'after'/(pid+'_canonical_ko_v2')
 paths={'canonical_pack':folder/'candidate-pack.json','canonical_composed':folder/'composed-baseline.json','canonical_audit':folder/'composed-audit.json','before_english_pack':Q/'before'/(pid+'_selected_en_control')/'candidate-pack.json','after_english_pack':Q/'after'/(pid+'_selected_en_control')/'candidate-pack.json'}
 if not all(p.exists() for p in paths.values()):
  contracts.append({'profile_id':pid,'status':'pending','missing':[str(p) for p in paths.values() if not p.exists()]});continue
 for p in paths.values():inputs[str(p)]=sha(p.read_bytes())
 pack=read(paths['canonical_pack'])[0];comp=read(paths['canonical_composed']);saved_audit=read(paths['canonical_audit'])
 ob=next(o for o in pack['visual_obligations']['obligations'] if o['id']==pid)
 before=next(o for o in read(paths['before_english_pack'])[0]['visual_obligations']['obligations'] if o['id']==pid)
 after=next(o for o in read(paths['after_english_pack'])[0]['visual_obligations']['obligations'] if o['id']==pid)
 projection=lambda o:{k:v for k,v in o.items() if k!='activation'}
 source=source_profiles[pid];components=source['authored_components']['components'];expected_fields=[c['evidence_field'] for c in components];expected_gates=[c['render_gate']['id'] for c in components]
 checks={'after_canonical_equals_before_english_contract_except_request_source_activation':projection(ob)==projection(before),'after_english_equals_before_english_contract':after==before,'english_components_unchanged':ob['component_semantics']['groups']==[{'id':c['id'],'any_terms':c['match_terms']} for c in components],'english_evidence_fields_unchanged':ob['prompt_binding']['required_evidence_fields']==expected_fields,'english_evidence_requirements_unchanged':ob['evidence_requirements']=={c['evidence_field']:{'min_content_words':c['min_content_words'],'must_mention_any':c['evidence_terms']} for c in components},'all_three_render_gate_rows_unchanged':ob['render_gates']==[c['render_gate'] for c in components],'all_three_gate_ids_in_required_set':all(g in pack['visual_obligations']['required_hard_gates'] for g in expected_gates),'actual_saved_composed_audit_pass':saved_audit['status']=='pass','baseline_prose_unchanged':comp['prompt_en']==pack['authorial_core']['baseline_prompt_en'],'actual_composed_evidence_literal':all(value in comp['prompt_en'] for value in comp['visual_obligation_evidence'][pid].values())}
 contracts.append({'profile_id':pid,'checks':checks,'passed':all(checks.values()),'canonical_contract_projection_sha256':sha(canon(projection(ob))),'before_english_contract_projection_sha256':sha(canon(projection(before))),'render_gate_ids':expected_gates,'evidence_fields':expected_fields})
 # This is the production focused obligation checker; full saved public audits stay separate.
 base_failures=audit.audit_visual_obligations(pack,comp,comp['prompt_en']);composition.append({'profile_id':pid,'mutation':'unaltered_complete_positive','expected_rejection':False,'passed':not base_failures,'failures':base_failures})
 for field in expected_fields:
  mutated=copy.deepcopy(comp);del mutated['visual_obligation_evidence'][pid][field]
  failures=audit.audit_visual_obligations(pack,mutated,mutated['prompt_en']);composition.append({'profile_id':pid,'mutation':'remove_required_evidence_field','field':field,'expected_rejection':True,'passed':bool(failures),'failures':failures})
  mutated=copy.deepcopy(comp);phrase=mutated['visual_obligation_evidence'][pid][field];mutated['prompt_en']=mutated['prompt_en'].replace(phrase,'unrelated empty visual space')
  assert phrase not in mutated['prompt_en']
  failures=audit.audit_visual_obligations(pack,mutated,mutated['prompt_en']);composition.append({'profile_id':pid,'mutation':'replace_literal_evidence_in_prompt','field':field,'expected_rejection':True,'passed':bool(failures),'failures':failures})
 effective,errors=audit.derive_effective_visual_obligation_contract(pack,comp);assert not errors
 egates,eerrors=audit.photo_embodiment.render_gate_ids(pack,comp);assert not eerrors
 gate_ids=list(dict.fromkeys(effective['required_hard_gates']+egates))
 review={'schema_version':'moe-render-review/v1','pack_id':pack['pack_id'],'contract_version':'photo-visual-obligations/v1','reviewer':'synthetic helper-only record validator; no pixel observation','result_image':str(placeholder),'result_sha256':sha(placeholder.read_bytes()),'hard_gates':{g:{'status':'pass','evidence':'Synthetic schema-control text only. No rendered image or pixel observation exists.'} for g in gate_ids},'user_judgment':{'baseline_available':False,'genuinely_moe':'pending','better_than_baseline':'not_applicable','source':'not_yet_received','evidence':''}}
 variants=[('all_declared_pass',None,review,False)]
 for gate in expected_gates:
  for mutation in ('partial','fail','missing','empty_evidence'):
   m=copy.deepcopy(review)
   if mutation=='missing':del m['hard_gates'][gate]
   elif mutation=='empty_evidence':m['hard_gates'][gate]['evidence']=''
   else:m['hard_gates'][gate]['status']=mutation
   variants.append((mutation,gate,m,True))
 extra=copy.deepcopy(review);extra['hard_gates']['uncontracted_helper_gate']={'status':'pass','evidence':'Synthetic helper only, no image observation.'};variants.append(('extra_gate',None,extra,True))
 for mutation,gate,r,expected_rejection in variants:
  result=render.audit_moe_render_review(pack,r,composed=comp)
  success=(not result['technical_qualified'])==expected_rejection and result['representative_eligible'] is False
  if mutation in ('partial','fail','missing'):success=success and gate in {g['gate'] for g in result['failed_hard_gates']}
  gates.append({'profile_id':pid,'mutation':mutation,'gate':gate,'expected_rejection':expected_rejection,'passed':success,'helper_only':True,'synthetic_input_review':r,'result':result})
 print(pid,'contracts',all(checks.values()),'composition_cases',len([c for c in composition if c['profile_id']==pid]),'synthetic_gate_cases',len(variants),flush=True)
assert all(sha(Path(p).read_bytes())==digest for p,digest in inputs.items())
save('after-contract-surfaces.json',{'scope':'Actual reviewed-V2 after canonical public packs and before/after English public packs; request-specific activation provenance is excluded only for cross-language contract comparison','input_sha256':inputs,'profile_checks':contracts,'profiles_expected':3,'profiles_checked':sum('checks' in x for x in contracts),'passed_profiles':sum(x.get('passed',False) for x in contracts),'source_assets_unmodified':subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True)==''})
save('after-composed-contract-mutations.json',{'scope':'Helper-only calls to production audit_visual_obligations on actual after canonical public packs; existing full public composed audits separately checked as pass','checks':len(composition),'passed':sum(x['passed'] for x in composition),'positive_controls':sum(not x['expected_rejection'] for x in composition),'negative_mutations':sum(x['expected_rejection'] for x in composition),'results':composition})
save('after-synthetic-review-gates.json',{'scope':'HELPER-ONLY SYNTHETIC GATE CHECKS. Sentinel bytes are not an image. No actual image or pixel evidence has been created; no rendered quality or promotion claim. Input evidence text is explicitly synthetic and requesting-user judgment remains pending.','checks':len(gates),'passed':sum(x['passed'] for x in gates),'positive_controls':sum(not x['expected_rejection'] for x in gates),'negative_mutations':sum(x['expected_rejection'] for x in gates),'results':gates,'seconds':time.time()-start})
print(json.dumps({'contract_profiles':len(contracts),'contract_passed':sum(x.get('passed',False) for x in contracts),'composed_checks':len(composition),'composed_passed':sum(x['passed'] for x in composition),'synthetic_gate_checks':len(gates),'synthetic_gate_passed':sum(x['passed'] for x in gates),'seconds':time.time()-start}));sys.exit(any(not x.get('passed',False) for x in contracts+composition+gates))
