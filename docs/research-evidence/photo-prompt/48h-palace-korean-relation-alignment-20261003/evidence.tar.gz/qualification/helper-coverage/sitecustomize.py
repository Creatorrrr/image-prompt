"""Helper-only validation process guard: no outgoing socket connections."""
import sys
sys.dont_write_bytecode = True
def _deny_network(event, args):
    if event in {'socket.connect', 'socket.connect_ex', 'socket.getaddrinfo'}:
        raise RuntimeError('helper-only qualification forbids network/provider calls: ' + event)
sys.addaudithook(_deny_network)
