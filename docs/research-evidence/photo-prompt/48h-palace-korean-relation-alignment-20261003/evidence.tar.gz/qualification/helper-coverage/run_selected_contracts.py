"""Helper-only opt-in transitions on genuine after legacy-complete public packs."""
import copy,hashlib,json,sys,time
from pathlib import Path
sys.dont_write_bytecode=True
H=Path(__file__).parent;Q=H.parent;R=Path('/workspace/scratch/ce8f20680f5a/image-prompt');sys.path.insert(0,str(R/'skills/photo-prompt-image-generator/scripts'))
import audit_composed_prompt as audit,audit_moe_render_review as render
sha=lambda b:hashlib.sha256(b).hexdigest();read=lambda p:json.loads(p.read_text())
inputs={};rows=[];gate_rows=[];start=time.time();placeholder=H/'synthetic-not-image.bin'
for pid in ('pf_window_seat','pf_double_helix','pf_roofless_ruin'):
 folder=Q/'after'/(pid+'_old_ko_complete_v2');pp=folder/'candidate-pack.json';cp=folder/'composed-baseline.json';inputs[str(pp)]=sha(pp.read_bytes());inputs[str(cp)]=sha(cp.read_bytes());pack=read(pp)[0];original=read(cp);comp=copy.deepcopy(original);cid='visual-concept:'+pid
 candidate=next(c for c in pack['visual_concept_candidates']['candidates'] if c['id']==cid);ob=candidate['opt_in_contract']['obligation'];assert candidate['applicability']['status']=='eligible'
 comp['chosen_visual_concept_ids']=[cid];comp['visual_obligation_evidence']={pid:{field:next(t for t in req['must_mention_any'] if t in comp['prompt_en']) for field,req in ob['evidence_requirements'].items()}}
 before,berrors=audit.derive_effective_visual_obligation_contract(pack,original);selected,serrors=audit.derive_effective_visual_obligation_contract(pack,comp);expected=[g['id'] for g in ob['render_gates']]
 # Full composition check is a helper-only derivative, not another public generated pack.
 result=audit.audit_composed_prompt(pack,comp)
 checks={'source_pack_unchanged':True,'frozen_prompt_unchanged':comp['prompt_en']==original['prompt_en'],'no_target_hard_when_unselected':pid not in [x['id'] for x in (before or {}).get('obligations',[])],'all_three_gates_after_selection':all(g in selected['required_hard_gates'] for g in expected),'selection_derivation_valid':not serrors and not berrors,'selected_full_composed_audit_pass':result['status']=='pass'}
 rows.append({'profile_id':pid,'helper_only':True,'checks':checks,'passed':all(checks.values()),'selected_gate_ids':selected['required_hard_gates'],'full_composed_audit':result,'derived_composed':comp})
 egates,errs=audit.photo_embodiment.render_gate_ids(pack,comp);assert not errs;all_gates=list(dict.fromkeys(selected['required_hard_gates']+egates))
 review={'schema_version':'moe-render-review/v1','pack_id':pack['pack_id'],'contract_version':'photo-visual-obligations/v1','reviewer':'synthetic helper-only opt-in validator; no pixels reviewed','result_image':str(placeholder),'result_sha256':sha(placeholder.read_bytes()),'hard_gates':{g:{'status':'pass','evidence':'Synthetic schema control only; no rendered image or pixel observation exists.'} for g in all_gates},'user_judgment':{'baseline_available':False,'genuinely_moe':'pending','better_than_baseline':'not_applicable','source':'not_yet_received','evidence':''}}
 variants=[('all_declared_pass',None,review,False)]
 for gate in expected:
  for status in ('partial','fail'):
   m=copy.deepcopy(review);m['hard_gates'][gate]['status']=status;variants.append((status,gate,m,True))
 for mutation,gate,review,expected_reject in variants:
  rr=render.audit_moe_render_review(pack,review,composed=comp);ok=(not rr['technical_qualified'])==expected_reject and not rr['representative_eligible'];gate_rows.append({'profile_id':pid,'helper_only':True,'mutation':mutation,'gate':gate,'expected_rejection':expected_reject,'passed':ok,'result':rr})
 print(pid,'opt_in_checks',checks,flush=True)
assert all(sha(Path(p).read_bytes())==s for p,s in inputs.items())
out={'scope':'HELPER-ONLY selected variants of three actual reviewed-V2 after legacy-complete public packs. Only local copies of composed selection/evidence change; genuine pack bytes and frozen prose stay unchanged. No new public packs, no image evidence or rendered qualification.','input_sha256':inputs,'profiles':3,'profiles_passed':sum(r['passed'] for r in rows),'selection_results':rows,'synthetic_gate_checks':len(gate_rows),'synthetic_gate_passed':sum(r['passed'] for r in gate_rows),'gate_results':gate_rows,'seconds':time.time()-start}
p=H/'after-selected-contracts.json';assert not p.exists();p.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'profiles_passed':out['profiles_passed'],'synthetic_gate_checks':len(gate_rows),'synthetic_gate_passed':out['synthetic_gate_passed'],'seconds':time.time()-start}));sys.exit(any(not r['passed'] for r in rows+gate_rows))
