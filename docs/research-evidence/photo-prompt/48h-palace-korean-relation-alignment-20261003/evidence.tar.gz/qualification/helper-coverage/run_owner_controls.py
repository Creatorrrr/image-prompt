"""Read-only helper control probe; all synthesized controls are source-exposed."""
import copy,hashlib,json,subprocess,sys,time
from pathlib import Path
sys.dont_write_bytecode=True
R=Path('/workspace/scratch/ce8f20680f5a/image-prompt'); H=Path(__file__).parent;Q=H.parent;S=R/'skills/photo-prompt-image-generator';sys.path.insert(0,str(S/'scripts'))
import prompt_generator as g,build_visual_profile_index as builder
sha=lambda b:hashlib.sha256(b).hexdigest()
canon=lambda x:json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
def write(name,x):
 p=H/name
 if p.exists():raise RuntimeError('Preserve existing artifact: '+str(p))
 p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
pin=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert pin=='ca0f6d80c85e2538883da9a5a0e01818dfe7df0c'
proposal=Q/'proposal-v2/proposed-edits.json';edits=json.loads(proposal.read_text())['edits'];es={e['profile_id']:e for e in edits}
source=S/'assets/photo_prompt_visual_obligations_palace_fortification.json';profiles={p['id']:p for p in json.loads(source.read_text())['profiles']}
seat='pf_window_seat';helix='pf_double_helix';ruin='pf_roofless_ruin'
e={p:profiles[p]['activation']['exact_terms'][0] for p in es};k={p:es[p]['new_value'] for p in es}
rows=[]
def add(i,p,lang,text,positive=False):rows.append({'id':i+'_'+lang,'profile_id':p,'language':lang,'text':text,'role':'complete_positive' if positive else 'relation_negative','expected_before_target_hard':positive and lang=='en','expected_after_target_hard':positive,'source_exposed':True})
add('wooden_seat_same_masonry_recess',seat,'en',e[seat]+'. The built-in seat itself is wooden; the surrounding full-depth window recess belongs to the masonry wall.',True)
add('wooden_seat_same_masonry_recess',seat,'ko',k[seat]+'. 그 붙박이 좌석 자체는 나무로 만들어졌고 좌석을 둘러싼 창 오목부의 전체 깊이는 조적 벽에 속한다.',True)
add('same_timber_recess_unrelated_masonry',seat,'en','a built-in seat occupies the depth of the full-depth timber recess; the side reveals connect the seat space to the outer window; the outer opening sits beyond the seat plane. This seat and its timber recess form one assembly; an unrelated masonry wall stands across the room.')
add('same_timber_recess_unrelated_masonry',seat,'ko','붙박이 좌석이 전체 깊이가 목재로 만들어진 창 오목부 안에 자리한다; 창 측벽이 그 좌석 공간을 바깥 창과 연결한다; 바깥 개구부는 좌석 면보다 바깥쪽에 놓이며 가구 하나를 창 앞에 둔 장면과 구별된다. 이 좌석을 둘러싼 오목부는 전체가 목재이고 관계없는 조적 벽은 방 반대쪽에 서 있다.')
add('empty_shared_core_straight_flights',helix,'en','two distinct straight parallel stair flights rise alongside one core; the shared central core remains visibly hollow; each flight retains a separate continuous circulation path')
add('empty_shared_core_straight_flights',helix,'ko','서로 다른 두 직선 계단 구간이 하나의 중심부 양쪽을 따라 나란히 오른다; 두 계단이 공유하는 중심부는 속이 빈 상태로 보인다; 각 계단은 서로 분리된 연속 동선을 유지하여 두 경로가 각각 추적되며 중간에서 임의로 합쳐지거나 충돌하지 않는다')
add('two_distinct_hollow_centers',helix,'en','two distinct helical stair flights each wind around its own separate core; the two spatially distinct cores remain visibly hollow; each flight retains a separate continuous circulation path')
add('two_distinct_hollow_centers',helix,'ko','서로 다른 두 나선형 계단 구간이 각각 별도의 중심부 둘레를 감아 돈다; 두 계단의 서로 떨어진 중심부 두 곳은 각각 속이 빈 상태로 보인다; 각 계단은 서로 분리된 연속 동선을 유지하여 두 경로가 각각 추적되며 중간에서 임의로 합쳐지거나 충돌하지 않는다')
add('rubble_elsewhere_broken_room_clear',ruin,'en','open sky appears above the former room where its roof is missing; surviving walls and window openings enclose the former interior floor; that floor below the broken upper structure is fully cleared. A masonry rubble pile stands in an unrelated courtyard beyond a separate intact building.')
add('rubble_elsewhere_broken_room_clear',ruin,'ko','지붕이 없어 옛 방 안에서 그 방 위의 열린 하늘이 보인다; 남아 있는 벽과 창 개구부가 그 방의 옛 실내 바닥을 둘러싼다; 파손된 상부 구조 아래 그 방의 바닥은 완전히 치워져 있고 파손은 구조 경계와 연결되어 단순한 이끼와 구별된다. 관계없는 조적 잔해 더미는 별도의 온전한 건물 너머 다른 뜰에 놓여 있다.')
for c in rows:
 if c['role']=='relation_negative':
  aliases=profiles[c['profile_id']]['activation']['exact_terms']+[k[c['profile_id']]]
  assert not any(a in c['text'] for a in aliases),c['id']
write('frozen-owner-controls.json',{'scope':'10 source-exposed helper resolver controls: 5 owner/relation scenarios in English and Korean. Frozen before loading/rebuilding actual indexes. No fixed evidence-field labels as conjunctions, no complete positive alias plus contradictory tail in negatives.','proposal_manifest_sha256':sha(proposal.read_bytes()),'cases':rows})
started=time.time();base=g.load_runtime_data();installed=base[g.VISUAL_PROFILE_INDEX_DATA_KEY];before=base[g.VISUAL_OBLIGATIONS_DATA_KEY];after=copy.deepcopy(before)
for edit in edits:
 p=next(p for p in after['profiles'] if p['id']==edit['profile_id']);assert p['activation']['exact_terms'][1]==edit['old_value'];p['activation']['exact_terms'][1]=edit['new_value']
receipts={};results=[];cache=S/'assets/photo_prompt_visual_profile_index.json'
for label,reg in [('before',before),('after',after)]:
 vectors=builder.reusable_vectors([cache],reg,provider=g.SEMANTIC_PROVIDER,model=g.SEMANTIC_MODEL_ID,dimensions=g.DEFAULT_SEMANTIC_DIMENSIONS)
 assert len(vectors)==len(reg['profiles'])
 assert all(installed['entries'][p['id']]['text']==g.visual_profile_semantic_text(p) for p in reg['profiles'])
 assert all(vectors[p]==installed['entries'][p]['vector'] for p in vectors)
 index=builder.build_visual_profile_index_payload(reg,vectors=vectors,provider=g.SEMANTIC_PROVIDER,model=g.SEMANTIC_MODEL_ID,dimensions=g.DEFAULT_SEMANTIC_DIMENSIONS);g.validate_visual_profile_index_metadata(index,reg)
 receipts[label]={'profile_count':len(reg['profiles']),'reused_vectors':len(vectors),'embedding_texts_identical':True,'all_vector_values_identical':True,'provider':index['provider'],'embedding_model':index['embedding_model'],'embedding_dimensions':index['embedding_dimensions'],'index_canonical_sha256':sha(canon(index)),'registry_sha256':index['registry_sha256'],'exact_lookup_sha256':sha(canon(index['exact_lookup'])),'bm25f_sha256':sha(canon(index['bm25f'])),'metadata_validation':'pass','provider_calls':0}
 for c in rows:
  resolved=g.resolve_visual_profile_hits(reg,[{'source':'concept_lock','text':c['text'],'polarity':'required','priority':'critical','mandatory':True}],visual_profile_index=index,adult_context=False)
  hard=[h['profile_id'] for h in resolved['hits'] if h.get('hard_eligible')]
  expected=c['expected_'+label+'_target_hard'];target=c['profile_id'] in hard
  results.append({'case_id':c['id'],'arm':label,'profile_id':c['profile_id'],'hard_ids':hard,'expected_target_hard':expected,'actual_target_hard':target,'passed':target==expected,'unrelated_hard_ids':[h for h in hard if h!=c['profile_id']],'target_hit_summaries':[{k:h.get(k) for k in ['profile_id','match_basis','hard_eligible','optional_eligible']} for h in resolved['hits'] if h['profile_id']==c['profile_id']]})
stale=None
try:g.validate_visual_profile_index_metadata(installed,after)
except ValueError as exc:stale=str(exc)
assert stale and 'registry_sha256' in stale
write('owner-index-receipts.json',{'source_pin':pin,'proposal_sha256':sha(proposal.read_bytes()),'cache_sha256':sha(cache.read_bytes()),'consumer':'production reusable_vectors / build_visual_profile_index_payload / validate_visual_profile_index_metadata; full merged registry, no fabricated or reduced index','stale_installed_index_against_after_rejected':stale,'arms':receipts,'provider_calls':0,'disk_index_copies':0,'seconds':time.time()-started})
write('owner-control-results.json',{'scope':'Helper-only exact activation boundary, not semantic owner inference or natural-query holdout; all controls are source-exposed','cases':len(rows),'case_arm_checks':len(results),'passed':sum(r['passed'] for r in results),'failed':sum(not r['passed'] for r in results),'unrelated_hard_imports':sum(bool(r['unrelated_hard_ids']) for r in results),'results':results,'limitation':'Matching exact aliases as a whole does not establish inference about ownership, masonry, winding, shared cores, or owned rubble. Complete explicit clauses and their replacements establish only tested exact boundary behavior.'})
print(json.dumps({'cases':len(rows),'checks':len(results),'passed':sum(r['passed'] for r in results),'failed':sum(not r['passed'] for r in results),'profile_count':len(before['profiles']),'seconds':time.time()-started}));sys.exit(any(not r['passed'] for r in results))
