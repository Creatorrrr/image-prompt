#!/usr/bin/env python3
"""Narrow reviewed-V2 installer. Default is dry-run; not applied in qualification.

Only the three approved Korean alias strings and the regenerated full visual
profile index may change. Rebuild uses the actual production builder, requires
complete identical cached vectors, and has no embedding/provider fallback.
"""
import argparse,copy,hashlib,json,os,subprocess,sys
from pathlib import Path
sys.dont_write_bytecode=True
PIN='ca0f6d80c85e2538883da9a5a0e01818dfe7df0c'
SOURCE_SHA='98ba8f3affe1cf12f4e6ce557ab98827a8c13d71f404944fed0dec693e8b8dcd'
INDEX_SHA='c777b85ef03a3fd077d6b88fbfd9a293cc68338a3339f5b82a75321748630bd0'
PROPOSAL_SHA='05f90f550cb3d1301eb33df1bb4ab3d6eb91e3599815958ebeadf2efcef695ce'
IDS={'pf_window_seat','pf_double_helix','pf_roofless_ruin'}
sha=lambda b:hashlib.sha256(b).hexdigest()
canonical=lambda x:json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
def atomic(path,content):
 tmp=path.with_name(path.name+'.palace-v2-staging')
 with tmp.open('wb')as f:f.write(content);f.flush();os.fsync(f.fileno())
 tmp.replace(path)
def main():
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--repo',type=Path,required=True);parser.add_argument('--apply',action='store_true',help='Apply only after the user authorizes installation; otherwise dry-run');parser.add_argument('--receipt',type=Path);args=parser.parse_args()
 R=args.repo.resolve();Q=Path(__file__).resolve().parent;proposal_path=Q/'proposal-v2/proposed-edits.json';proposal_bytes=proposal_path.read_bytes();assert sha(proposal_bytes)==PROPOSAL_SHA,'Frozen proposal changed'
 if args.receipt:assert not args.receipt.resolve().is_relative_to(R),'Write qualification receipt outside the repository'
 head=lambda:subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
 status=lambda:subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True)
 assert head()==PIN and status()=='','Installer requires the exact clean qualified source pin'
 S=R/'skills/photo-prompt-image-generator';source=S/'assets/photo_prompt_visual_obligations_palace_fortification.json';index_path=S/'assets/photo_prompt_visual_profile_index.json'
 source_bytes=source.read_bytes();index_bytes=index_path.read_bytes();assert sha(source_bytes)==SOURCE_SHA and sha(index_bytes)==INDEX_SHA,'Source or cached index differs from qualified input'
 edits=json.loads(proposal_bytes)['edits'];assert len(edits)==3 and{e['profile_id']for e in edits}==IDS
 raw=json.loads(source_bytes);edited=copy.deepcopy(raw);new_text=source_bytes.decode()
 for e in edits:
  p=next(p for p in edited['profiles']if p['id']==e['profile_id']);assert p['activation']['exact_terms'][1]==e['old_value'];p['activation']['exact_terms'][1]=e['new_value']
  old=json.dumps(e['old_value'],ensure_ascii=False);new=json.dumps(e['new_value'],ensure_ascii=False);assert new_text.count(old)==1;new_text=new_text.replace(old,new,1)
 new_source_bytes=new_text.encode();assert json.loads(new_source_bytes)==edited
 reverted=copy.deepcopy(edited)
 for e in edits:next(p for p in reverted['profiles']if p['id']==e['profile_id'])['activation']['exact_terms'][1]=e['old_value']
 assert reverted==raw,'Unexpected source edit outside approved alias fields'
 sys.path.insert(0,str(S/'scripts'));import prompt_generator as g,build_visual_profile_index as builder
 registry=g.load_visual_obligation_registry(S/'assets/photo_prompt_visual_obligations.json');old_index=g.load_visual_profile_index(index_path,registry);prospective=copy.deepcopy(registry)
 for e in edits:
  p=next(p for p in prospective['profiles']if p['id']==e['profile_id']);assert p['activation']['exact_terms'][1]==e['old_value'];p['activation']['exact_terms'][1]=e['new_value']
 vectors=builder.reusable_vectors([index_path],prospective,provider=g.SEMANTIC_PROVIDER,model=g.SEMANTIC_MODEL_ID,dimensions=g.DEFAULT_SEMANTIC_DIMENSIONS)
 assert len(vectors)==len(prospective['profiles'])==1622,'Missing reusable vector; stop without provider fallback'
 assert all(old_index['entries'][p['id']]['text']==g.visual_profile_semantic_text(p)for p in prospective['profiles'])
 assert all(vectors[k]==old_index['entries'][k]['vector']for k in vectors)
 rebuilt=builder.build_visual_profile_index_payload(prospective,vectors=vectors,provider=g.SEMANTIC_PROVIDER,model=g.SEMANTIC_MODEL_ID,dimensions=g.DEFAULT_SEMANTIC_DIMENSIONS);g.validate_visual_profile_index_metadata(rebuilt,prospective)
 assert sha(canonical(rebuilt))=='6043ad09f323af032468a0c968ac68b2aad87ffb4ada428b18a1211275b2be79','Rebuilt index differs from qualified V2'
 rebuilt_bytes=(json.dumps(rebuilt,ensure_ascii=False,indent=2)+'\n').encode()
 receipt={'mode':'apply'if args.apply else'dry_run','applied':False,'source_pin':PIN,'proposal_sha256':PROPOSAL_SHA,'only_changed_profile_fields':[{ 'profile_id':e['profile_id'],'field':'activation.exact_terms[1]'}for e in edits],'source_before_sha256':SOURCE_SHA,'source_after_sha256':sha(new_source_bytes),'index_before_sha256':INDEX_SHA,'index_after_byte_sha256':sha(rebuilt_bytes),'index_after_canonical_sha256':sha(canonical(rebuilt)),'reused_vectors':len(vectors),'new_vectors':0,'batch_size':1,'embedding_batches_dispatched':0,'provider_calls':0,'ordinary_dictionary_or_general_index_writes':0,'runtime_code_or_historical_source_writes':0,'git_writes':0}
 if args.apply:
  assert head()==PIN and status()=='' and source.read_bytes()==source_bytes and index_path.read_bytes()==index_bytes,'Concurrent source change; stop'
  try:
   atomic(source,new_source_bytes);atomic(index_path,rebuilt_bytes)
   installed_registry=g.load_visual_obligation_registry(S/'assets/photo_prompt_visual_obligations.json');installed_index=g.load_visual_profile_index(index_path,installed_registry)
   assert installed_registry==prospective and installed_index==rebuilt
   changed=set(subprocess.check_output(['git','diff','--name-only'],cwd=R,text=True).splitlines())
   expected={str(source.relative_to(R)),str(index_path.relative_to(R))};assert changed==expected,(changed,expected)
   receipt['applied']=True;receipt['post_install_validation']='pass'
  except BaseException:
   atomic(source,source_bytes);atomic(index_path,index_bytes)
   for p in [source,index_path]:p.with_name(p.name+'.palace-v2-staging').unlink(missing_ok=True)
   raise
 text=json.dumps(receipt,ensure_ascii=False,indent=2)+'\n'
 if args.receipt:args.receipt.parent.mkdir(parents=True,exist_ok=True);args.receipt.write_text(text)
 print(text,end='')
if __name__=='__main__':main()
