from pathlib import Path
import json,subprocess,os,hashlib
P=Path(__file__).resolve().parent.parent;R=P.parent/'image-prompt';O=P/'palace-relation-audit/production-integration';b=json.loads((R/'skills/subculture-illustration-image-generator/assets/photo_regression_baseline_v9.json').read_text());cmd=b['command'][:];cmd[cmd.index('--output-file')+1]=str(O/'current-boundary.pack.json');env={k:v for k,v in os.environ.items()if not any(s in k.upper()for s in ['TOKEN','API_KEY','CREDENTIAL'])};r=subprocess.run(cmd,cwd=R,env=env,capture_output=True,text=True,timeout=180);(O/'current-boundary.stdout.txt').write_text(r.stdout);(O/'current-boundary.stderr.txt').write_text(r.stderr);assert r.returncode==0
old=json.loads((P/'portcullis-state-audit/production-integration/current-boundary.pack.json').read_text());new=json.loads((O/'current-boundary.pack.json').read_text());diff=[]
def walk(a,b,path='$'):
 if type(a)!=type(b):diff.append({'path':path,'before':a,'after':b});return
 if isinstance(a,dict):
  for k in sorted(set(a)|set(b)):
   if k not in a or k not in b:diff.append({'path':path+'.'+k,'before':a.get(k),'after':b.get(k)})
   else:walk(a[k],b[k],path+'.'+k)
 elif isinstance(a,list):
  if len(a)!=len(b):diff.append({'path':path+'.length','before':len(a),'after':len(b)})
  for i,(x,y)in enumerate(zip(a,b)):walk(x,y,f'{path}[{i}]')
 elif a!=b:diff.append({'path':path,'before':a,'after':b})
walk(old,new);out={'previous_portcullis_pack_sha256':hashlib.sha256((P/'portcullis-state-audit/production-integration/current-boundary.pack.json').read_bytes()).hexdigest(),'after_palace_pack_sha256':hashlib.sha256((O/'current-boundary.pack.json').read_bytes()).hexdigest(),'leaf_diffs':diff,'comparison':'same frozen v9 command/inputs, prior portcullis source vs installed three palace aliases; historical v9 remains unchanged and byte check non-green','provider_calls':0};(O/'current-boundary-delta.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2));print('Leaf difference count:',len(diff))
