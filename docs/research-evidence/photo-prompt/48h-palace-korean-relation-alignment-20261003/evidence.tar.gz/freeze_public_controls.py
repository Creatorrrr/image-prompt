"""Freeze six source-exposed diagnostic controls before public generation.

These are synthetic requester roles used for maintenance, not live user requests,
unexposed authoring samples, natural-query accuracy, or image-quality evidence.
"""
import hashlib,json,os,re,subprocess,sys
from pathlib import Path
sys.dont_write_bytecode=True
R=Path('/workspace/scratch/ce8f20680f5a/image-prompt');O=Path(__file__).parent;S=R/'skills/photo-prompt-image-generator'
sys.path.insert(0,str(S/'scripts'));import prompt_generator as g
sha=lambda b:hashlib.sha256(b).hexdigest()
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
frozen=json.loads((O/'frozen-resolver-cases.json').read_text())['cases'];requests={c['id']:c['text']for c in frozen}
defs=[
 {'profile_id':'pf_window_seat','variant':'timber_recess','changed_index':0,'alternative':'a built-in seat occupies the depth of the timber recess','subject':'A built-in window seat','setting':'A deep window recess inside a thick timber wall','tail':'The wall and its solid timber side reveals expose end grain and timber joinery through the full wall depth. The fixed seat belongs to this same timber recess. A side-oblique view retains the complete recess depth and the outer opening together. Soft daylight reveals the grain and joins while the surrounding wall remains visually quiet.','material':True},
 {'profile_id':'pf_double_helix','variant':'parallel_straight_flights','changed_index':0,'alternative':'two distinct straight stair flights rise in parallel beside one core','subject':'Two separate straight stair flights','setting':'An interior hall around a visibly open central core','tail':'Each straight flight climbs along one side of the open central space. An oblique view keeps both stair routes and their separate upper landings visible together. Soft daylight describes the treads, vertical rise and open center while the surrounding hall remains visually quiet.','material':False},
 {'profile_id':'pf_roofless_ruin','variant':'cleared_floor','changed_index':2,'alternative':'a cleared stone floor lies below the broken upper structure','subject':'A roofless former stone room','setting':'The surviving walls of a roofless stone room','tail':'All loose fallen stones and bricks have been removed, leaving only fitted floor slabs beneath the broken wall tops. An interior view preserves the wall-to-floor connections and open sky together. Soft daylight makes the broken upper edges and smooth cleared floor legible.','material':False},
]
cases=[]
for d in defs:
 pid=d['profile_id'];complete=requests[pid+'_en_exact'].split('; ')
 for role in ['compatible_ko','selected_en_control']:
  c=dict(d);c['id']=pid+'_'+role;c['role']=role;c['components']=list(complete)
  if role=='compatible_ko':
   c['request']='건축 사진을 만들어 주세요: '+requests[pid+'_'+d['variant']];c['components'][d['changed_index']]=d['alternative'];tail=d['tail']
   if pid=='pf_window_seat':c['request']+=' 같은 벽체와 깊은 창 측벽은 통원목으로 이루어져 있고, 벽 깊이 전체에서 원목 단면과 짜맞춤이 보인다.'
  else:
   c['request']='Make an architectural photograph: '+requests[pid+'_en_exact']+'.';tail='An oblique architectural view keeps the three connected structural relations readable together. Soft daylight describes the surfaces and their connections, while the surrounding setting remains visually quiet. The complete arrangement is the central photographic subject.'
   if pid=='pf_window_seat':c['setting']='A deep window recess inside a thick masonry wall'
   if pid=='pf_double_helix':c['subject']='Two separate helical stair flights'
  c['baseline']='An architectural photograph studies the visible arrangement: '+'; '.join(c['components'])+'. '+tail
  cases.append(c)
write(O/'frozen-public-requests.json',{'provenance':'Six source-exposed maintenance controls: one compatible Korean request and one complete English selected-variant control for each of three concrete gaps. Each pair is one controlled architectural comparison, not independent natural samples.','cases':cases})
manifest={'repository_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'seed':1003,'source_exposed':True,'cases':[]};checks=[]
env={k:v for k,v in os.environ.items()if not any(x in k.upper()for x in ['TOKEN','API_KEY','CREDENTIAL'])};env['PYTHONDONTWRITEBYTECODE']='1'
for c in cases:
 d=O/'public-controls'/c['id'];d.mkdir(parents=True,exist_ok=True);raw=c['request'];b=c['baseline'];components=c['components']
 envelope={'contract_version':'photo-request-envelope/v1','provenance':'requesting_user','request_id':'synthetic-palace-relation-'+c['id'],'request_text':raw,'request_sha256':sha(raw.encode()),'active_spans':[{'span_id':'scene','start':0,'end':len(raw),'text':raw}]}
 write(d/'request-envelope.json',envelope);write(d/'creative-context.json',{'subject_category':'nonhuman','no_people':False,'explicit_nonsexual':False})
 cmd=[sys.executable,str(S/'precore/creative_controls.py'),'--request-envelope-json',str(d/'request-envelope.json'),'--context-json',str(d/'creative-context.json'),'--output',str(d/'creative-controls.json')]
 r=subprocess.run(cmd,cwd=R,env=env,capture_output=True,text=True);assert r.returncode==0,r.stderr
 controls=json.loads((d/'creative-controls.json').read_text());write(d/'control-resolution.json',json.loads(r.stdout))
 anchors=[{'anchor_id':'architecture','source_text':raw,'dimension':'concept','prompt_evidence':'An architectural photograph'}]+[{'anchor_id':'relation_'+str(i+1),'source_text':raw,'dimension':'setting','prompt_evidence':p}for i,p in enumerate(components)]
 subject_phrase={'pf_window_seat':'a built-in seat','pf_double_helix':' '.join(components[0].split()[:6]),'pf_roofless_ruin':'former room'}[c['profile_id']]
 anchors.append({'anchor_id':'subject','source_text':raw,'dimension':'subject','prompt_evidence':subject_phrase})
 anchors.append({'anchor_id':'structural_state','source_text':raw,'dimension':'event','prompt_evidence':' '.join(components[c['changed_index']].split()[1:])})
 locked=['concept','subject','setting','event']
 if c['material']:
  locked.append('material');anchors.append({'anchor_id':'recess_material','source_text':raw,'dimension':'material','prompt_evidence':'timber recess'if c['role']=='compatible_ko'else'masonry recess'})
 dimensions=['concept','subject','setting','event','composition','framing','lighting','camera','material','color','atmosphere']
 core={'contract_version':'photo-authorial-core/v3','provenance':'agent_prepack','source_request':raw,'creative_controls_sha256':controls['canonical_sha256'],'interpreted_intent':'Preserve the complete requested structural arrangement, including its specified physical state and material. The authorial direction uses an oblique architectural view and quiet daylight to keep those relations legible together.','subject':c['subject'],'setting':c['setting'],'event':'The specified architectural arrangement remains visibly intact in one continuous spatial view','visual_priorities':components,'baseline_prompt_en':b,'user_definitions':[],'interpretation_provenance':[{'term':'architectural arrangement','source_text':raw,'basis':'request_context','resolution':'The architectural subject retains these exact requested relations: '+'; '.join(components)+'.','sources':[]}],'unresolved_ambiguities':[],'user_exclusions':[],'runtime_forbidden_labels':[],'intent_lock':{'contract_version':'photo-intent-lock/v2','priority':'requesting_user','semantic_anchors':anchors,'locked_dimensions':locked,'open_dimensions':[x for x in dimensions if x not in locked]},'semantic_assertions':[{'assertion_id':'primary_subject_category','dimension':'subject','polarity':'required','source_span_ids':['scene'],'affected_dimensions':['subject'],'axes':{'subject_category':'object'},'evidence':{'subject_phrase':components[0]}},{'assertion_id':'architectural_relations','dimension':'setting','polarity':'required','source_span_ids':['scene'],'affected_dimensions':['setting'],'axes':{'structural_arrangement':c['variant']if c['role']=='compatible_ko'else'selected_variant_complete'},'evidence':{'relation_'+str(i+1)+'_phrase':p for i,p in enumerate(components)}}],'request_lineage':None,'style':{'domain':'architectural photography','family':'restrained naturalistic architecture','evidence':['An architectural photograph','Soft daylight']},'variation_key':c['id']}
 review={'contract_version':'photo-embodiment-review/v1','provenance':'agent_prepack','prompt_sha256':sha(b.encode()),'scope':'not_applicable','summary':'The scene contains architecture and stationary structural surfaces. No living body or bodily mechanism appears; the architectural relations remain visible together.','checks':{}}
 assert all(a['source_text']in raw and a['prompt_evidence']in b for a in anchors)
 write(d/'authorial-core.json',core);write(d/'embodiment-review.json',review)
 ep=g.load_request_envelope_arg(str(d/'request-envelope.json'));normalized=g.load_authorial_core_arg(str(d/'authorial-core.json'),request_envelope=ep,creative_control_snapshot=controls);g.photo_embodiment.build_policy(normalized,review)
 checks.append({'case':c['id'],'normalization':'pass','embodiment_binding':'pass','baseline_words':len(re.findall(r"[A-Za-z0-9]+(?:['’-][A-Za-z0-9]+)*",b)),'core_sha256':normalized['canonical_sha256'],'intent_lock_sha256':normalized['intent_lock']['canonical_sha256']})
 manifest['cases'].append({k:c[k]for k in ['id','profile_id','role','changed_index','components']});manifest['cases'][-1]['files']={p.name:sha(p.read_bytes())for p in sorted(d.iterdir())if p.is_file()}
write(O/'pre-public-input-validation.json',checks);manifest['frozen_requests_sha256']=sha((O/'frozen-public-requests.json').read_bytes());write(O/'frozen-public-input-manifest.json',manifest)
print(json.dumps({'frozen_cases':len(cases),'input_normalization':'all pass','retrieval_calls':0}))
