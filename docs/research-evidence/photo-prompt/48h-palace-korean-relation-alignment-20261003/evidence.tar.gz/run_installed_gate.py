from pathlib import Path
import ast,copy,json,hashlib,sys,subprocess,time
D=Path(__file__).resolve().parent; Q=D/'qualification'; R=D.parent.parent/'image-prompt'; O=D/'production-integration'; ARM=sys.argv[1]; assert ARM in ('before','after'); DEST=O/ARM; DEST.mkdir(parents=True,exist_ok=True)
sys.dont_write_bytecode=True;sys.path.insert(0,str(R/'skills/photo-prompt-image-generator/scripts'))
import prompt_generator as g,audit_composed_prompt as audit
node=next(n for n in ast.parse((Q/'run_qualification.py').read_text()).body if isinstance(n,ast.FunctionDef)and n.name=='compose');ns={'copy':copy};exec(compile(ast.Module(body=[node],type_ignores=[]),str(Q/'run_qualification.py'),'exec'),ns);compose=ns['compose']
def forbidden(*a,**k):raise AssertionError('No provider calls permitted')
g.embed_texts_with_gemini=forbidden
sha=lambda b:hashlib.sha256(b).hexdigest()
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
data=g.load_runtime_data();manifest=json.loads((Q/'frozen-input-manifest.final-18.json').read_text());assert len(manifest['cases'])==18;rows=[];pin=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert pin=='ca0f6d80c85e2538883da9a5a0e01818dfe7df0c'
for case in manifest['cases']:
 idir=Path(case['input_dir']);start=time.monotonic()
 for name,h in case['files'].items():assert sha((idir/name).read_bytes())==h
 env=g.load_request_envelope_arg(str(idir/'request-envelope.json'));controls=json.loads((idir/'creative-controls.json').read_text());core=g.load_authorial_core_arg(str(idir/'authorial-core.json'),request_envelope=env,creative_control_snapshot=controls);review=json.loads((idir/'embodiment-review.json').read_text());g.photo_embodiment.build_policy(core,review)
 pack=g.generate_candidate_pack(data,core,controls,review,seed=manifest['seed']);c=compose(pack,case);a=audit.audit_composed_prompt(pack,c);dest=DEST/case['id'];dest.mkdir(exist_ok=True);write(dest/'candidate-pack.json',[pack]);write(dest/'composed-baseline.json',c);write(dest/'composed-audit.json',a)
 qualified=Q/ARM/case['id']; eq={'pack':pack==json.loads((qualified/'candidate-pack.json').read_text())[0],'composition':c==json.loads((qualified/'composed-baseline.json').read_text()),'audit':a==json.loads((qualified/'composed-audit.json').read_text())};assert all(eq.values()),(case['id'],eq)
 row={'case':case['id'],'cohort':case['cohort'],'arm':ARM,'same_as_reviewed_qualification':eq,'audit_passed':not a['failures'],'pack_id':pack['pack_id'],'pack_sha256':sha((dest/'candidate-pack.json').read_bytes()),'baseline_unchanged':c['prompt_en']==core['baseline_prompt_en'],'seconds':round(time.monotonic()-start,3)};rows.append(row);write(DEST/'results.json',rows);print(case['id'],ARM,row['audit_passed'],flush=True)
assert sum(x['audit_passed']for x in rows)==(15 if ARM=='before' else 18)
write(DEST/'source-receipt.json',{'head':pin,'provider_calls':0,'consumer':'Actual installed public builder and composed auditor; no registry/index substitution','cases':18,'all_qualified_pack_composition_audit_objects_identical':True,'seed':manifest['seed'],'dictionary_hash':g.dictionary_hash(data),'registry_hash':g.visual_profile_registry_sha256(data[g.VISUAL_OBLIGATIONS_DATA_KEY]),'asset_sha256':{n:sha((R/'skills/photo-prompt-image-generator/assets'/n).read_bytes())for n in ['photo_prompt_visual_obligations_palace_fortification.json','photo_prompt_visual_profile_index.json','photo_prompt_semantic_index.json']}})
