# Independent review of three palace DATA proposals

## Decision

**Accept the three inherited activation defects and the alias-only repair layer. Request wording changes before promotion; none of the three proposals is integrated or qualified as an after-arm.** The current replacements close the specifically tested timber / straight-flight / cleared-floor boundary, but a complete canonical alias should state every unchanged English duty and retain the older Korean facts without relying on architectural inference.

- **Window seat: revise.** The proposed first clause adds masonry and a fixed seat, but `고정` (fixed) is less explicit than `붙박이` (built-in). The unchanged Korean second clause connects the side reveals to the opening without expressly naming the seat space. The third clause does not expressly state the English opening-beyond-seat-plane geometry. Make all three relations explicit.
- **Double helix: revise.** Winding around one core is now explicit. The original first clause's traceability is removed, however, and the remaining non-arbitrary-merge clause is not an explicit statement that each flight keeps a separate continuous circulation path. Preserve traceability and name separate continuity directly.
- **Roofless ruin: revise for complete preservation.** The added localized fallen masonry is the correct disputed duty. Its reference to a broken upper structure ordinarily implies real structural damage, so I do **not** count a new independent moss-only bug. Still, replacing the old third clause removes its explicit structural-boundary connection and moss distinction; retaining those words costs no new architectural requirement. Also spell out that the remaining walls and window openings enclose this former room's floor, rather than leaving enclosure implicit in `이전 실내를 이룬다`.

These wording concerns are **not three additional demonstrated runtime defects**. They are reasons the proposed strings are not yet certified as fact-complete replacements. This review supplies fully explicit alternatives in `recommended-replacements.json`; they remain review artifacts and were not installed.

## What was independently verified

Repository: `/workspace/scratch/ce8f20680f5a/image-prompt`, clean at `ca0f6d80c85e2538883da9a5a0e01818dfe7df0c` before and after.

1. All ten original source hashes match current files. Each proposed complete profile differs from its current raw object only at `activation.exact_terms[1]`.
2. All six frozen public input sets match their manifests. Raw requests agree between frozen manifest, envelope, authored core and admitted pack; baselines agree between source fixture, core, admitted pack and composed prompt. All reported visual evidence literally occurs in the unchanged prompt. No optional candidate or concept was selected.
3. The unmodified public composed auditor was independently rerun on each saved pack/composition. Every complete JSON result matches the earlier saved result, including warnings: three Korean failures and three English passes.
4. The six public generations were **verified from their saved admitted packs, bindings and hashes**, not independently regenerated during this review. The six auditor calls really were rerun.
5. Fifteen request probes were executed against the real full merged registry and existing registry-bound index, with no supplied query vector. These comprise six original requests, three English-equivalent counterexamples, three generic negatives and three semantically complete legacy-wording positives. The English-equivalent and generic controls do not hard-activate the target. All three complete legacy-wording requests hard-activate now but fail the proposed literal exact comparator.
6. The unchanged six-test `tests.test_photo_palace_fortification_semantics` suite passes. Its local test index and synthetic-vector coverage are not confused with the separately run real-index probes.
7. Vector input text is identical for all three proposed profiles; BM25F fields change for all three. Alias edits require a real generated-index rebuild and validation, even though compatible unchanged vectors can be reused.

Zero production edits, Git writes, provider calls, images, index rebuilds or repository/index copies were made. Review artifacts are small text/JSON outputs only.

## Clause-by-clause compatibility of the original counterexamples

### `pf_window_seat`

Original Korean trigger:

> 좌석이 벽 깊이 안에 들어간다; 창 측벽과 바깥 개구부가 연결된다; 가구 하나를 창 앞에 둔 장면과 구별된다

- **Seat within wall depth:** The frozen request and baseline place a built-in/fixed seat within the depth of the same thick timber recess. A chair merely standing in front of a window is not substituted.
- **Side reveal / outer opening connection:** The unchanged baseline expressly connects the seat space, side reveals and outer window. It also retains an exterior opening beyond the seat plane, stronger than the original Korean wording.
- **Distinction from furniture before a window:** The fixed seat belongs to the same wall recess, rather than being a movable item in front of it.
- **Material ownership:** The source request says that the same wall and deep side reveals consist of solid timber, with exposed end grain and joinery through the full wall depth. The baseline preserves that. This is not an inference from a wooden seat, wood paneling, or an unseen structural core. Masonry elsewhere in the photograph cannot satisfy the English duty of this recess.
- **Conflict:** The English component imports a *masonry recess* for that same seat. A completely timber wall/reveal assembly with exposed full-depth material evidence is compatible with every old Korean clause and incompatible with this imported material requirement.

The English control actually uses a masonry setting and masonry baseline. `frozen-public-requests.json` retains unused template metadata such as the original timber `tail` on its English row; inspecting the actual frozen input/core/baseline confirms that text is not consumed into the English control. It is a fixture-labeling cleanup opportunity, not a failed or self-contradictory control.

### `pf_double_helix`

Original Korean trigger:

> 두 개의 계단 경로가 추적된다; 공유 중심부가 비어 보인다; 두 경로가 중간에서 임의로 합쳐지거나 충돌하지 않는다

- **Two traceable paths:** The frozen baseline has two separate continuous straight flights and keeps both routes and their distinct upper landings visible.
- **Shared visibly empty center:** Both flights climb on opposite sides of the same open central space. Two unrelated staircases with unrelated centers are not substituted.
- **No arbitrary merging/collision:** The two continuous routes remain separate. Nothing in the counterexample requires a junction or physical intersection.
- **Conflict:** Straight parallel flights can satisfy all three Korean facts but cannot be the English pair of helical flights winding around that core. A solid-center counterexample would contradict the old Korean text and is not used.

The English control's actual subject and baseline are helical. The unused straight-flight `tail` retained in the fixture metadata does not enter its core or composition.

### `pf_roofless_ruin`

Original Korean trigger:

> 지붕이 없어 방 안에서 하늘이 보인다; 남은 벽·창·바닥이 이전 실내를 이룬다; 파손이 구조 경계와 연결되며 단순 이끼가 아니다

- **Missing roof / sky from inside:** Both are expressly retained.
- **Former interior:** The surviving walls and window openings enclose its existing floor; a freestanding picturesque wall is not substituted for a room.
- **Structural damage, not moss:** Clearly cut/broken upper wall surfaces and wall-top boundaries remain visible. Removing loose debris does not repair those broken structural boundaries.
- **Conflict:** The source request removes all fallen stones/bricks from the floor, and the baseline says all loose fallen masonry has been removed, leaving fitted floor slabs. Fitted paving is not fallen masonry. The room can therefore satisfy every inherited Korean fact while lacking the English component requiring localized fallen masonry below the broken upper structure.

The English control's actual baseline contains localized fallen masonry and no cleared-floor tail. Its unused shared fixture metadata is not evidence of a prompt contradiction.

## What the audit failures prove

For each Korean composition the only failures are:

- `visual_obligation_semantic_evidence` on the changed component (`component_1_phrase` for seat/stairs, `component_3_phrase` for ruin)
- `semantic_clarification_required` because the corresponding mandatory profile meaning was truthfully rejected

There are no hidden unrelated failure gates. The English controls pass with their warnings retained. This establishes the literal, public contract conflict when a stronger duty is automatically imported. The auditor itself does not prove semantic compatibility or a contradiction; that conclusion rests on the clause/owner analysis above. These six packs are three source-exposed controlled comparisons, **not six independent natural queries**. No result here establishes photographic or native-pixel quality.

## Source and history findings

Authoritative current owner: `skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations_palace_fortification.json`. It separately stores canonical exact terms, selected English meaning, component anchors and render gates.

All three raw profiles are unchanged from `b6e70b78` and `b4120b84`. The latter commit changed muqarnas data in this file, not these profiles. The current `ca0f6d80` change concerns the portcullis alias and generated index. Thus these defects predate the latest portcullis fix.

The original `docs/research-evidence/photo-prompt/palace-fortification-20260909/install-runtime.py` has two sources of wording:

- English operationalizations at lines 24, 31 and 40 specify the now-enforced duties
- Line 51 creates the Korean exact term by joining the research draft's three `description_ko` gate strings, while simultaneously installing the English operationalization as the other exact term

The corresponding draft objects explicitly say that sources establish architectural premises, while wording, gates and camera choices are proposed operationalizations. The implementation report says all three selected-variant relations should be explicitly present before hard activation. Source records are S12 (English Heritage, Dunstanburgh) for the window seat, S21 (Chambord) for the stair, and S12/S08 (English Heritage / UNESCO Carcassonne) for the ruin. This review verifies the checked-in source chain; it does not claim to reread current external web pages or to prove any new historical architecture proposition.

No independent defect was found that requires changing ordinary candidate or bundle records, English duties, historical research drafts, historical installer, source ledger, or extension-maintenance provenance. Keep those unchanged. The historical installer records how the original data was produced; it is not a live alternate source to silently rewrite to erase the discrepancy. Tests and new maintenance evidence should record a new correction separately.

## Recall and lost-gate tradeoff

The proposed replacement removes a supported literal Korean trigger. This affects **valid** old wording too. The review probes append every missing English-selected fact in separate Korean sentences to each old exact trigger. Current normal resolution hard-activates all three. The proposed exact comparator does not match them, even though they now describe the complete selected variant.

This is a real loss of automatic coverage: profile evidence fields, mandatory clarification and three profile render gates may stop being attached. Frozen requester anchors/assertions must still preserve the request, but they are not equivalent to those profile-specific thumbnail/native gates. Therefore the loss cannot be characterized as a harmless synonym edit or as completely protected merely because the general request stays locked.

A narrow canonical-trigger policy can accept this precision/recall tradeoff, but must record it explicitly and show the actual after-arm. Do not retain the overbroad old alias just to recover recall, and do not create a paraphrase soup, owner-agnostic material exception or topic-specific semantic contradiction logic. If future work aims to recover natural Korean selected-variant coverage, qualify it as a separate bounded coverage change under the existing topic-neutral contracts.

## Required promotion checks

Detailed machine-readable test specification: `promotion-checks.json`. Minimum sequence:

1. Review the final canonical Korean text clause by clause against every English component and every old Korean fact. Freeze the request/core/lock/control/review inputs before installing any edited source. Mark these as source-exposed maintenance fixtures.
2. Install only the reviewed alias fields and rebuild the real visual-profile index from the full merged registry. Verify full vector text, provider/model/dimensions and vector values are unchanged for reused entries. Regenerate exact lookup, BM25F documents/statistics and registry hash. Check the real rebuilt index and show stale old index rejection. No re-embedding is needed if reuse checks succeed; if any changed vector text is found, stop for the separately authorized provider workflow.
3. Replay the original six inputs through normal public generation and composed audit. Korean counterexamples should lose this target's automatic duty and pass while preserving their original concrete facts; English complete controls must retain the same hard profile, evidence fields and all three gate IDs. Keep baseline bytes fixed. Adapt only contract bindings/evidence inventory and required-decision bookkeeping to the actual new pack, not the architecture or prompt.
4. Test the three final canonical Korean positives through that same complete path. Require all unchanged English component duties and gate IDs. One-clause omissions and each material/geometry/state substitution must remain non-hard. A literal comparator alone cannot establish these after-results.
5. Run the three English-equivalent negative requests and generic controls before and after. They must remain non-hard with the same concrete requested content. Do not put a complete positive English alias before a contradictory tail and label that an English-equivalent negative.
6. Test complete legacy-wording Korean requests before and after. Record expected gate loss without disguising it as a positive routing pass. Show that concrete request content remains preserved, and separately identify that automatic profile gates are absent.
7. Mutate generic locked facts in final compositions: timber recess to masonry; straight stairs to helices or lost separation; cleared floor to added rubble; remove roof absence / former-room enclosure / real structural damage. Use mutations that actually remove or replace the corresponding bound evidence; these must fail the existing generic anchor/assertion/intent machinery even where the profile no longer activates. A contradictory extra sentence that leaves all literal anchors intact is a separate semantic review problem, not a promised detector capability. Also preserve nonarchitectural locks, requester exclusions, unrelated setting details, empty optional selection and open creative dimensions.
8. Pair material and geometry ownership controls: a wooden seat **inside a masonry recess** is compatible with the selected seat profile; an unrelated masonry wall cannot satisfy a timber recess's duty. A hollow center alone does not imply winding; arbitrary discarded masonry elsewhere does not satisfy rubble beneath this broken upper structure. Keep these owner checks distinct from hard-activation counts and from rendered verification.
9. Check unrelated profile and ordinary candidate/bundle/provenance hashes, focused palace and retrieval suites, actual-index routing, composed-evidence mutations, selection-to-gate behavior and partial/failed render-review mutations. Do not represent those synthetic gate checks as image evidence.

## Artifact map

- `review_probe.py`: reproducible read-only verification/replay driver
- `verification-summary.json`: clean start/end and result counts
- `source-and-input-checks.json`: source/history hashes, exact proposal surface, public input integrity
- `independent-composed-audit-replays.json`: six complete rerun results and commands
- `resolver-and-recall-probes.json`: all fifteen actual full-registry probes and proposed literal comparisons
- `palace-tests.log`: unchanged six-test PASS
- `recommended-replacements.json`: explicit replacement strings and clause rationale, uninstalled
- `promotion-checks.json`: required paired after-arm / preservation checks, not claimed as executed
