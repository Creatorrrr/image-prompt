# Final independent installed-source review

## Recommendation

**Approve the installed V2 DATA change. No blocking issue was found.** The working tree is still uncommitted at `ca0f6d80c85e2538883da9a5a0e01818dfe7df0c`; this review made no source edits or publication/Git writes.

The previously required installed-state validation has now been completed. The accepted limitation remains: three semantically complete legacy-Korean requests lose automatic activation and nine profile render gates. Generic prompt anchors and optional adoption do not replace that automatic coverage. No natural-query accuracy or image-quality claim is justified.

## Actual Git and source review

The complete unstaged change set is exactly:

1. `skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations_palace_fortification.json`
2. `skills/photo-prompt-image-generator/assets/photo_prompt_visual_profile_index.json`
3. New, currently untracked: `tests/test_photo_palace_korean_relation_alignment.py`

There is no staged diff. `git diff --check` passes. The authored profile file has exactly three changed leaves, each `activation.exact_terms[1]`, for window seat, double helix and roofless ruin. The resulting three complete profile objects exactly equal the reviewed V2 proposals; all other profile objects equal HEAD. English duties, ordinary candidates/bundles, runtime code and historical records remain unchanged.

The installed regression test is byte-identical to the approved 190-line compact draft, SHA-256 `717e492fe7b1b3b1b4b0e98ca52d0dfbb3836a4e5b42c4ab867a3a8e4158a613`. It contains no complete-profile snapshot or permanent requirement that valid legacy wording remain non-hard. Future equivalent aliases are permitted. The untracked test must remain part of the eventual change set, rather than relying on the tracked-file diff alone.

## Installed index and receipt

The apply receipt matches the actual installed files:

- Profile source SHA-256: `976dfef4750b1d79e11c0550c8296707a0fbe97a6dab1deda72c68d4fed08f34`
- Index byte SHA-256: `9a279002707290f79ad3b4de646644dfe4146bf4948dd07977e3d16a458482c6`
- Index canonical SHA-256: `6043ad09f323af032468a0c968ac68b2aad87ffb4ada428b18a1211275b2be79`
- Registry hash: `38217f0dc3d7dddb7ba53f132d558c69c62e1139ba16775c6641b3f575aa8b21`

I directly compared the installed index with HEAD: **all 1,622 entry objects are identical**, including their embedding text and vectors. Only the top-level `registry_sha256`, `exact_lookup` and `bm25f` values change. The installed full-index loader/metadata validation passes, and the HEAD index is rejected against the changed registry with the expected stale registry-hash error. The resulting canonical digest is identical to the independently qualified V2 index.

Fifteen other tracked source/code/test assets checked against the qualification invariant hashes are unchanged, including the ordinary extension, general semantic index and historical research sources. There is no provider work or new vector to account for.

## Public installed integration

I inspected the integration runner: it calls `load_runtime_data()` on the installed files, normal envelope/core/control/embodiment loading, and the unmodified production `generate_candidate_pack` and full composed-auditor functions. There is no registry/index substitution in this installed replay. This is actual installed production-function integration, not 36 separate CLI subprocess builds.

I directly compared all **18 before/after pairs**, including their complete pack, composition and audit JSON objects, against the previously reviewed qualification. All **36 triples** are equal. Their frozen input hashes and baseline prose are unchanged. Thus the previously established contract preservation, explicit legacy gate loss and disclosed optional redistribution reproduce on installed files:

- 18/18 before builds and 18/18 after builds admit
- Before composed audit: 15 PASS, 3 expected Korean imported-duty FAIL
- After composed audit: 18 PASS
- Complete English hard contracts and all their gates remain unchanged
- V2 canonical Korean requests gain the intended hard contracts
- Complete legacy Korean requests lose automatic gates and retain optional, unselected profile candidates

The three fresh theme-targeted alternatives and English-equivalent negatives still pass without hard target import. These remain bounded synthetic evidence, not an independent representative traffic sample.

## Independent execution during this review

In addition to artifact comparison, I independently ran the installed compact regression suite: **6/6 methods pass**.

I also independently generated three representative packs directly from installed runtime data and reran their full composed audits:

- Original compatible Korean timber recess: PASS, exact saved pack/audit reproduced
- V2 canonical Korean double helix: PASS, exact saved pack/audit reproduced
- Fully complete legacy Korean roofless ruin: PASS, exact saved pack/audit reproduced, with its accepted automatic-gate loss

These are spot replays, not an assertion that I regenerated all 36 integration arms again. The 36 full artifact comparisons and the earlier independent qualification audit replays provide the broader matching evidence.

## Tests and genuine before failure

I inspected every installed test log and its nonzero collected-test count. The 13 focused files sum to **133 passing test methods**, with successful completion logs; the dictionary validator reports valid metadata. This is the focused suite, not the entire unrelated repository suite. My independent six-method rerun repeats part of those 133 and is not added as six new methods.

The before log is genuinely red: six methods execute and nine assertion/subtest failures occur across the expected Korean-negative, canonical-activation and alias-presence checks. The old selected-duty invariants, generic names and clause boundaries still pass.

The preserved earlier errors are correctly excluded from that red result and from successful run counts:

- External draft-root import failure (`ModuleNotFoundError`)
- Wrapper collecting zero tests (`NO TESTS RAN`)
- Initial integration-harness syntax error, verified to fail parsing before execution

None is counted as an architectural defect or as a passing test. Their correction does not change the approved compact test, frozen request text or baseline prose.

## Frozen teacup boundary

The current installed palace teacup pack is byte-identical to both prior portcullis and CT091 packs, SHA-256:

`6c097471705589a4db45daf5aa164017f2c7b512dcaab880e9e58bb3882f5589`

The historical v9 fixture file itself is unchanged from HEAD. This supports **zero incremental boundary change from the palace aliases**. It does not make the entire historical v9 byte baseline green: the earlier nape/opacity divergence remains a disclosed pre-existing boundary condition.

## Final limits

No unresolved installed-source, index, regression, integration or preservation failure was found within this bounded change. Optional-profile redistribution and the legacy automatic-gate recall tradeoff remain as reviewed; they were not erased by passing prompt audits. There was no generated image, native-pixel verification, user aesthetic judgment, full unrelated-suite run or publication.

The review began and ended with the same expected uncommitted three-file change set. Evidence is in `artifact-checks.json`, `independent-execution.json`, `independent-installed-regression.log`, `installed-git.diff` and `verify_installed.py` beside this report.
