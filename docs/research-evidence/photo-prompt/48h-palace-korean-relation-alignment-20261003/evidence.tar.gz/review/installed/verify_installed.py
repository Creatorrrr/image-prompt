"""Independent read-only review of installed V2 aliases/index/test."""
from pathlib import Path
import copy,hashlib,io,json,re,subprocess,sys,time,unittest
sys.dont_write_bytecode=True
R=Path('/workspace/scratch/ce8f20680f5a/image-prompt');O=Path(__file__).resolve().parent;A=O.parents[1];Q=A/'qualification';I=A/'production-integration';S=R/'skills/photo-prompt-image-generator'
sys.path.insert(0,str(R));sys.path.insert(0,str(S/'scripts'))
def guard(event,args):
 if event in {'socket.connect','socket.getaddrinfo','socket.bind'}:raise RuntimeError('No network/provider calls in installed review')
sys.addaudithook(guard)
import prompt_generator as g,audit_composed_prompt as audit
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
canon=lambda x:json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode();digest=lambda x:hashlib.sha256(canon(x)).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=R)
def save(name,x):(O/name).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def diff(a,b,p='$'):
 if isinstance(a,dict)and isinstance(b,dict):return [v for k in sorted(set(a)|set(b))for v in diff(a.get(k),b.get(k),p+'.'+k)]
 if isinstance(a,list)and isinstance(b,list)and len(a)==len(b):return [v for i,(x,y)in enumerate(zip(a,b))for v in diff(x,y,p+f'[{i}]')]
 return []if a==b else[p]
start={'head':git('rev-parse','HEAD').decode().strip(),'status':git('status','--porcelain').decode()};assert start['head']=='ca0f6d80c85e2538883da9a5a0e01818dfe7df0c'
source_rel='skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations_palace_fortification.json';index_rel='skills/photo-prompt-image-generator/assets/photo_prompt_visual_profile_index.json';test_rel='tests/test_photo_palace_korean_relation_alignment.py'
assert set(git('diff','--name-only').decode().splitlines())=={source_rel,index_rel};assert git('diff','--cached','--name-only')==b'';assert git('ls-files','--others','--exclude-standard').decode().splitlines()==[test_rel]
subprocess.run(['git','diff','--check'],cwd=R,check=True,capture_output=True);(O/'installed-git.diff').write_bytes(git('diff','--',source_rel,index_rel))
installed_profiles=read(R/source_rel);old_profiles=json.loads(git('show','HEAD:'+source_rel));leaves=diff(old_profiles,installed_profiles);assert len(leaves)==3 and all(x.endswith('.activation.exact_terms[1]')for x in leaves)
oldmap={p['id']:p for p in old_profiles['profiles']};newmap={p['id']:p for p in installed_profiles['profiles']};edits=read(Q/'proposal-v2/proposed-edits.json')['edits'];targets={e['profile_id']for e in edits}
assert all(newmap[pid]==oldmap[pid]for pid in newmap if pid not in targets)
for e in edits:assert newmap[e['profile_id']]==read(Q/'proposal-v2'/f"{e['profile_id']}.proposed.json")
compact=A/'review/v2/compact_test_photo_palace_korean_relation_alignment.py';assert (R/test_rel).read_bytes()==compact.read_bytes()
newindex=read(R/index_rel);oldindex=json.loads(git('show','HEAD:'+index_rel));assert newindex['entries']==oldindex['entries'] and len(newindex['entries'])==1622
changed_index_roots=[k for k in set(newindex)|set(oldindex)if newindex.get(k)!=oldindex.get(k)];assert set(changed_index_roots)=={'registry_sha256','exact_lookup','bm25f'}
receipt=read(I/'install-receipt.json');assert receipt['applied']and receipt['source_after_sha256']==sha(R/source_rel)and receipt['index_after_byte_sha256']==sha(R/index_rel)and receipt['index_after_canonical_sha256']==digest(newindex)=='6043ad09f323af032468a0c968ac68b2aad87ffb4ada428b18a1211275b2be79'
reg=g.load_visual_obligation_registry(S/'assets/photo_prompt_visual_obligations.json');loaded=g.load_visual_profile_index(R/index_rel,reg);assert loaded==newindex
try:g.validate_visual_profile_index_metadata(oldindex,reg)
except ValueError as e:stale=str(e)
else:raise AssertionError('stale old index was accepted')
source_baseline=read(Q/'source-invariants.json')['source_sha256'];unchanged={p:sha(R/p)==h for p,h in source_baseline.items()if p not in {source_rel,index_rel}};assert all(unchanged.values())
manifest=read(Q/'frozen-input-manifest.final-18.json');pairs=[]
for case in manifest['cases']:
 cid=case['id'];idir=Path(case['input_dir']);assert all(sha(idir/n)==h for n,h in case['files'].items())
 for arm in ['before','after']:
  comparisons={name:read(I/arm/cid/name)==read(Q/arm/cid/name)for name in ['candidate-pack.json','composed-baseline.json','composed-audit.json']};assert all(comparisons.values()),(cid,arm,comparisons)
  p=read(I/arm/cid/'candidate-pack.json')[0];c=read(I/arm/cid/'composed-baseline.json');a=read(I/arm/cid/'composed-audit.json');record=next(x for x in read(I/arm/'results.json')if x['case']==cid)
  assert sha(I/arm/cid/'candidate-pack.json')==record['pack_sha256'];assert c['prompt_en']==p['authorial_core']['baseline_prompt_en']==read(idir/'authorial-core.json')['baseline_prompt_en'];pairs.append({'case':cid,'arm':arm,'comparisons':comparisons,'audit_status':a['status'],'input_hashes_preserved':True})
assert len(pairs)==36 and sum(p['audit_status']=='pass'for p in pairs if p['arm']=='before')==15 and sum(p['audit_status']=='pass'for p in pairs if p['arm']=='after')==18
logs=[]
for row in read(I/'tests/results.json'):
 assert row['returncode']==0
 if row['file']=='dictionary-validation':assert 'photo prompt dictionary metadata is valid'in(I/'tests/dictionary-validation.log').read_text();continue
 text=(I/'tests'/(row['file']+'.log')).read_text();count=int(re.search(r'Ran (\d+) tests?',text).group(1));assert re.search(r'\nOK\s*$',text),row['file'];assert count>0;logs.append({'file':row['file'],'methods':count,'log_success_verified':True})
assert sum(x['methods']for x in logs)==133
red=(I/'draft-before.stderr.log').read_text();assert 'Ran 6 tests'in red and 'FAILED (failures=9)'in red;assert len(re.findall(r'^FAIL:',red,re.M))==9;assert 'ERROR:'not in red
boundary_paths=[I/'current-boundary.pack.json',A.parent/'portcullis-state-audit/production-integration/current-boundary.pack.json',A.parent/'material-effect-audit/production-integration/current-boundary.pack.json'];assert len({sha(p)for p in boundary_paths})==1;baseline='skills/subculture-illustration-image-generator/assets/photo_regression_baseline_v9.json';assert (R/baseline).read_bytes()==git('show','HEAD:'+baseline)
save('artifact-checks.json',{'start':start,'actual_source_leaves':leaves,'approved_v2_profiles_equal':True,'compact_test_byte_identical':True,'compact_test_sha256':sha(compact),'source_sha256':sha(R/source_rel),'index_byte_sha256':sha(R/index_rel),'index_canonical_sha256':digest(newindex),'index_changed_roots':sorted(changed_index_roots),'all_1622_index_entries_identical':True,'installed_index_validation':'pass','stale_old_index_rejected':stale,'unchanged_other_sources':unchanged,'public_object_comparisons':pairs,'test_logs':logs,'focused_methods_verified_from_logs':133,'genuine_before_failure_count':9,'harness_failures_not_counted':True,'teacup_pack_hashes':{str(p):sha(p)for p in boundary_paths},'historical_v9_file_unchanged':True,'historical_v9_full_baseline_still_non_green':'Prior nape/opacity divergence remains; zero incremental palace change is the supported claim.'})
print('Artifact/source/index comparisons passed',flush=True)
# Independent installed execution: six-method test and three actual public builds.
stream=io.StringIO();suite=unittest.defaultTestLoader.loadTestsFromName('tests.test_photo_palace_korean_relation_alignment');res=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite);(O/'independent-installed-regression.log').write_text(stream.getvalue());assert res.testsRun==6 and res.wasSuccessful(),stream.getvalue();print('Installed regression passed 6/6',flush=True)
data=g.load_runtime_data();builds=[]
selected={'pf_window_seat_compatible_ko','pf_double_helix_canonical_ko_v2','pf_roofless_ruin_old_ko_complete_v2'}
for case in manifest['cases']:
 if case['id']not in selected:continue
 d=Path(case['input_dir']);env=g.load_request_envelope_arg(str(d/'request-envelope.json'));controls=read(d/'creative-controls.json');core=g.load_authorial_core_arg(str(d/'authorial-core.json'),request_envelope=env,creative_control_snapshot=controls);review=read(d/'embodiment-review.json');p=g.generate_candidate_pack(data,core,controls,review,seed=manifest['seed']);saved=read(I/'after'/case['id']/'candidate-pack.json')[0];assert p==saved
 c=read(I/'after'/case['id']/'composed-baseline.json');a=audit.audit_composed_prompt(p,c);assert a==read(I/'after'/case['id']/'composed-audit.json');builds.append({'case':case['id'],'pack_and_audit_equal_installed_saved':True,'status':a['status']});print('Independent installed pack',case['id'],'PASS',flush=True)
end={'head':git('rev-parse','HEAD').decode().strip(),'status':git('status','--porcelain').decode()};assert start==end
save('independent-execution.json',{'installed_regression_methods':res.testsRun,'installed_regression_failures':len(res.failures),'installed_regression_errors':len(res.errors),'independently_regenerated_installed_packs':builds,'source_and_worktree_unchanged_by_review':start==end,'end':end,'source_edits':0,'provider_calls':0,'images':0,'git_writes':0,'pushes':0})
print('Installed independent review execution complete',flush=True)
