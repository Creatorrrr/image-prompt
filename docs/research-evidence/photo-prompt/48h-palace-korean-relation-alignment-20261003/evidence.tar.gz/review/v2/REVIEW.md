# Independent V2 qualification and promotion review

## Recommendation

**Approve the reviewed V2 alias-only DATA correction for promotion, with the legacy automatic-gate loss explicitly recorded. No blocking semantic or bounded qualification issue remains.** This approves the proposal's content, not publication, an installed checkout, general recall, or image quality.

Use only `qualification/proposal-v2/proposed-edits.json`, SHA-256 `05f90f550cb3d1301eb33df1bb4ab3d6eb91e3599815958ebeadf2efcef695ce`. Its three replacement strings exactly match the independent review's `recommended-replacements.json`. Each complete proposed profile changes only `activation.exact_terms[1]`. The English definitions, evidence anchors, component duties, render gates, ordinary candidates/bundles and historical sources remain unchanged.

The original V1 wording concerns are resolved:

- Window seat now explicitly says built-in, assigns masonry to the same recess, connects that seat space through the reveal to the exterior window, and places the opening beyond the seat plane, while retaining the furniture distinction
- Double helix now retains both-route traceability and explicitly requires distinct winding flights, a shared visibly hollow core, and separate continuous paths without arbitrary merging/collision
- Roofless ruin now explicitly names the missing-roof/sky relation, enclosure of that former room's floor, localized fallen masonry beneath the broken upper structure, and the original structural-boundary/moss distinction

These additions express the existing selected variant. They do not require a masonry seat, a particular stair handedness/turn count, a particular historical cause of ruin, an era, a camera setup, or a new topic-specific rule.

## Independently established result

Clean start and finish: `ca0f6d80c85e2538883da9a5a0e01818dfe7df0c`.

- Verified all 18 current input sets against the frozen final manifest, both saved packs and compositions per case, exact V2 proposal binding, raw-request preservation, baseline preservation and literal visual evidence
- Independently reran the production composed-auditor function on all **36 saved arm packs**; complete outputs match, including warnings
- Independently rebuilt the full V2 registry-bound index in memory with production builder functions, reusing all **1,622** existing vectors and unchanged vector inputs; the index exactly matches the qualification receipt
- Independently regenerated **six representative actual after packs** with the production generator function: all three canonical Korean positives, the original compatible timber-seat case, the fully complete legacy Korean stair case, and the fresh cleared-ruin case. Every resulting pack object equals its saved after pack
- Independently compared full ordinary slots, bundles, core, controls, core-retrieval contract, assertion obligations, embodiment preflight, negative guard, adult-appeal and creative-augmentation objects across all 18 pairs. Every compared object is equal. Positive and negative prose are byte-equal in every pair
- Independently verified current hashes of 17 source/code/test assets and preserved fresh author request/baseline text

Observed composed-audit outcome: **15/18 before → 18/18 after**, with all **36/36 admitted**.

| Cohort | Cases | Before | After | Target hard-profile change |
|---|---:|---|---|---|
| Original compatible Korean | 3 | 3 FAIL | 3 PASS | hard → absent |
| Original complete English | 3 | 3 PASS | 3 PASS | hard → same hard contract |
| English-equivalent negatives | 3 | 3 PASS | 3 PASS | absent → absent |
| Complete canonical V2 Korean | 3 | 3 PASS | 3 PASS | absent → hard |
| Fully complete legacy Korean | 3 | 3 PASS | 3 PASS | hard → optional, unselected |
| Fresh source-unexposed authored negatives | 3 | 3 PASS | 3 PASS | absent → absent |

The only failures removed are the three original imported component-duty/required-clarification conflicts. Their actual architectural prose is not changed to manufacture success.

The final matrix contains 18 paired cases. Four earlier V1 **before-only diagnostic records** remain preserved outside that denominator; they do not create four extra V2 cases, and are not silently presented as V2 successes.

## Execution levels and limits

The qualification's 36 arm records are **real complete production generator-function builds**, with normal envelope/core/control/embodiment loading and the unmodified full composed-auditor function. They use the complete runtime data and genuinely rebuilt full cached indexes. They are not resolver-only or reduced-index stand-ins.

They are also **not 36 CLI subprocess runs against installed modified assets**. The changed registry and derived index are supplied in memory while the repository stays untouched. The original six before packs were shown equal to the earlier CLI-built packs. This review independently confirms after-pack reproduction for six cases, and audit reproduction for all 36. At installation, the ordinary on-disk builder/check and current pinned regressions still need to verify the actual applied patch; this review does not claim that deployment step happened.

The 15 final canonical/omission/substitution checks are real rebuilt-index resolver checks, not extra public generated packs. Their split is 3 complete canonical positives, 9 one-clause omissions and 3 disputed-relation substitutions, all matching their intended boundary.

The helper work remains separately labeled:

- 20/20 bilingual owner/material before/after resolver checks and 6/6 bare generic-name resolver checks
- 31/31 existing current-source test methods, 144 observed subtests; these do not become V2 installed-suite evidence
- 3/3 actual canonical-after contract comparisons, preserving all English evidence fields and gate rows
- 21/21 focused active-obligation checker controls, including 3 complete positives and 18 evidence-removal/replacement negatives
- 3/3 helper-only optional selections on actual after legacy-complete packs, with unchanged prose, passing full composed audits and restoring all three target gates only when selected
- 63/63 synthetic review-record checks across hard and selected profiles, including 6 complete-record controls and 57 negative mutations

The sentinel used for those last checks is explicitly not an image. Gate-validator success is neither pixel review nor technical rendering qualification. Helper selection does not turn the unselected legacy-positive arm into an automatically gated success.

## Recall tradeoff: real, measured and not repaired by generic anchors

The legacy-positive requests are now fully explicit. They retain the old Korean exact sentence and add all previously missing selected English facts in separate Korean sentences:

- Same masonry recess, built-in seat, seat/reveal/window connection and beyond-seat opening
- Distinct helices around the same hollow core and separate continuous paths
- Former-room enclosure plus localized fallen masonry below its broken upper structure

All three deserve the selected variant semantically. Before, each has its hard profile, mandatory clarification and three target gate IDs. After, each still preserves its full requested prose and passes composed audit, but loses all three automatic target gates. The target appears only as an eligible optional visual candidate and remains unselected in the main matrix.

This is a deliberate precision/recall tradeoff: retiring an overbroad exact alias avoids forcing contradictory selected geometry/material, while requiring the new complete canonical wording for automatic activation. The old complete prose is not an invalid request and must not be labeled an intentional negative. A release or maintenance note must make its automatic-gate loss visible.

The three old-complete preservation counterfactuals replace masonry with timber, winding with straight flights, or fallen masonry with a cleared floor. The existing generic prompt-content anchors reject all three with the target profile absent. The seven fresh-scene mutations likewise reject removal/replacement of solid timber, straight routes, separation, cleared floor, roof absence, former-room identity and actual broken structure. This review inspected all ten saved failures, confirmed the expected literal source-bound evidence really was removed, checked valid unchanged core/pack bindings, and distinguished content failures from extra metadata failures.

That demonstrates specific prompt-content protection. It does **not** recreate the lost profile thumbnail/native gates, provide a general contradiction detector, or establish native-pixel faithfulness. Contradictory append-only prose preserving literal evidence remains outside these tests.

## Fresh controls and preservation

The three fresh texts are recorded as source-unexposed, theme-targeted synthetic authoring followed by source-exposed schema adaptation. Their exact author request and baseline bytes survive adaptation and both arms. There were no schema rejections or factual rewrites in the fresh adaptation record.

They are useful protection against an alias repair silently changing related timber, straight-stair or cleared-ruin scenes. They are **not sampled traffic, blind natural-query holdouts, or three fresh confirmations of the original bug**: all already pass before the edit. Their author was deliberately assigned the disputed themes. The six original source-exact packs are three controlled comparisons, not six independent natural cases.

Bare generic names were tested only at resolver-helper level. Complete public prompt preservation is instead covered by the three fresh negative scenes, their seven content mutations, the English equivalents and all paired full-object/prose comparisons. No universal generic-query preservation claim follows from this bounded set.

## Optional redistribution

The authored ordinary candidate objects and bundles, and their sampled full public objects, are unchanged across every pair. Approximate visual-profile retrieval is not entirely unchanged:

- The three V2 canonical positives remove their own target from optional inventory because it becomes hard
- The complete legacy positives add their own targets to optional inventory because automatic activation is removed
- The canonical stair positive additionally admits `visual-concept:rb_restrained_processing` to its optional inventory
- The canonical ruin positive additionally admits `visual-concept:pf_keep_ward` to its optional inventory
- No other optional membership changes were observed in the 18 pairs

No extra target or unrelated profile becomes hard, and no optional candidate/concept is adopted in the main matrix. These finite optional-list changes are expected collateral effects of changed aliases/BM25F and hard-versus-optional inventory filtering. They should be disclosed rather than described as no retrieval change. The bounded sample cannot prove optional rankings elsewhere are identical.

## Source/index integrity

The independent rebuilt V2 index has canonical SHA-256:

`6043ad09f323af032468a0c968ac68b2aad87ffb4ada428b18a1211275b2be79`

It matches the worker receipt exactly. All 1,622 vector values are reused, provider/model/dimensions remain unchanged, and no new embedding call is required for these alias-only fields. The old installed index is rejected against the changed registry with the expected registry-hash mismatch. Exact lookup, registry hash and BM25F derivations legitimately change; ordinary dictionary hash does not.

The merged registry differs only at the three intended aliases. No independent defect justifies changing historical research records, the archived installer, ordinary candidates/bundles, selected English facts, or general generator/auditor logic. Keep all of those unchanged.

## Promotion conditions and remaining limits

There is no remaining blocking proposal-content issue. Promotion should:

1. Apply exactly the V2 three-alias manifest, never the preserved V1 diagnostic strings
2. Regenerate/check the installed full visual-profile index and confirm the same unchanged-vector reuse and registry binding
3. Add focused regression evidence without rewriting old holdouts or silently claiming legacy gate preservation
4. Preserve the recorded before/after cohort definitions, source/prose invariants, optional redistribution and explicit legacy-positive gate loss
5. Continue to distinguish preflight/audit validity from photographs, actual pixel gates, natural-query recall and user aesthetic judgment

No source edit, publication, provider call or generated image was performed by this review. The data are ready for the bounded promotion step; actual installed-state validation remains that step's responsibility.

## Evidence

- `summary.json`: independent counts and clean start/end
- `pack-replay-checks.json`: 36 independent audit replays, 18 full paired-object/prose checks and exact V2 replacements
- `index-and-generator-checks.json`: independent complete rebuilt-index digest and six reproduced after packs
- `source-and-supplemental-checks.json`: source hashes, fresh author-text equality, ten actual content-failure inspections and helper-artifact integrity
- `verify_qualification.py`: independent replay/check implementation
- `qualification/REPORT.md` and `qualification/coverage-checklist.json`: final consolidated evidence map reviewed and reconciled; hashes recorded in `checklist-review.json`

## Final checklist reconciliation

The final qualification report and all 12 checklist items have been reviewed. Their public/helper distinctions, 18/36 active denominator, 15/18 → 18/18 outcomes, 3+7 content mutations, partial generic-name coverage and uninstalled status agree with this independent review. No reported helper count is used as additional public builds. No unresolved failure is hidden by the remaining scope limits. The bare generic-name queries, owner scenarios, omissions and request substitutions remain resolver-helper evidence; future installed-state validation is still outstanding because no application occurred. These disclosed limits do not block the conservative three-alias recommendation.
