"""Independent V2 artifact verification and current-consumer replay. No source writes."""
import copy,hashlib,json,sys,time,subprocess
from pathlib import Path
sys.dont_write_bytecode=True
R=Path('/workspace/scratch/ce8f20680f5a/image-prompt');O=Path(__file__).resolve().parent;A=O.parents[1];Q=A/'qualification';S=R/'skills/photo-prompt-image-generator'
sys.path.insert(0,str(S/'scripts'))
def guard(event,args):
 if event in {'socket.connect','socket.getaddrinfo','socket.bind'}:raise RuntimeError('Network blocked by independent review')
sys.addaudithook(guard)
import prompt_generator as g,build_visual_profile_index as builder,audit_composed_prompt as audit
read=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
canonical=lambda x:json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
digest=lambda x:hashlib.sha256(canonical(x)).hexdigest()
def write(name,x):(O/name).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def git(*a):return subprocess.check_output(['git',*a],cwd=R,text=True).strip()
def diff(a,b,p=''):
 if isinstance(a,dict)and isinstance(b,dict):return [v for k in sorted(set(a)|set(b))for v in diff(a.get(k),b.get(k),p+'.'+k)]
 if isinstance(a,list)and isinstance(b,list)and len(a)==len(b):return [v for i,(x,y)in enumerate(zip(a,b))for v in diff(x,y,p+f'[{i}]')]
 return []if a==b else[p.lstrip('.')]
start={'head':git('rev-parse','HEAD'),'status':git('status','--porcelain')};assert start['head']=='ca0f6d80c85e2538883da9a5a0e01818dfe7df0c'and not start['status']
manifest=read(Q/'frozen-input-manifest.final-18.json');assert manifest==read(Q/'frozen-input-manifest.json');cases=manifest['cases'];assert len(cases)==18
rows=read(Q/'results.json');assert len(rows)==len({(x['case'],x['arm'])for x in rows});by={(x['case'],x['arm']):x for x in rows}
proposed=read(Q/'proposal-v2/proposed-edits.json');psha=sha(Q/'proposal-v2/proposed-edits.json');recommended=read(A/'review/recommended-replacements.json')
raw={p['id']:p for p in read(S/'assets/photo_prompt_visual_obligations_palace_fortification.json')['profiles']}
proposal_checks=[]
for e in proposed['edits']:
 pid=e['profile_id'];p=read(Q/'proposal-v2'/f'{pid}.proposed.json');rr=next(x for x in recommended['edits']if x['profile_id']==pid)
 assert p['activation']['exact_terms'][1]==e['new_value']==rr['replacement'];assert diff(raw[pid],p)==['activation.exact_terms[1]']
 proposal_checks.append({'profile_id':pid,'exact_reviewer_string':True,'changed_fields':diff(raw[pid],p),'english_fields_and_other_data_unchanged':True})
results=[];surfaces=['slots','candidate_bundles','authorial_core','creative_controls','negative_en','core_retrieval','semantic_assertion_obligations','embodiment_preflight','negative_intent_guard','adult_appeal','creative_augmentation']
for case in cases:
 cid=case['id'];idir=Path(case['input_dir']);assert all(sha(idir/n)==h for n,h in case['files'].items())
 rawcore=read(idir/'authorial-core.json');env=read(idir/'request-envelope.json');packs={};comps={}
 for arm in ['before','after']:
  r=by[cid,arm];d=Q/arm/cid;p=read(d/'candidate-pack.json')[0];c=read(d/'composed-baseline.json');a=read(d/'composed-audit.json')
  assert sha(d/'candidate-pack.json')==r['pack_sha256'];assert sha(d/'composed-baseline.json')==r['composed_sha256']
  assert p['authorial_core']['source_request']==rawcore['source_request']==env['request_text'];assert p['authorial_core']['baseline_prompt_en']==c['prompt_en']==rawcore['baseline_prompt_en']
  assert a['status']==r['audit_status'];assert not c['chosen_candidate_ids']and not c['chosen_visual_concept_ids'];assert all(v in c['prompt_en']for fs in c.get('visual_obligation_evidence',{}).values()for v in fs.values())
  if arm=='after':assert r['proposal_sha256']==psha
  rerun=audit.audit_composed_prompt(p,c);assert rerun==a,(cid,arm,'audit mismatch')
  packs[arm]=p;comps[arm]=c
 ordinary={k:packs['before'].get(k)==packs['after'].get(k)for k in surfaces};assert all(ordinary.values()),(cid,ordinary)
 ph=lambda arm:[o['id']for o in(packs[arm].get('visual_obligations')or{}).get('obligations',[])]
 pg=lambda arm:[x['id']for o in(packs[arm].get('visual_obligations')or{}).get('obligations',[])for x in o['render_gates']]
 po=lambda arm:[x['id']for x in(packs[arm].get('visual_concept_candidates')or{}).get('candidates',[])]
 b,a=ph('before'),ph('after');pid=case.get('profile_id');role=case['role'];exp={'compatible_ko':(True,False),'selected_en_control':(True,True),'canonical_ko_positive_v2':(False,True),'old_ko_complete_positive_v2':(True,False),'english_equivalent_negative':(False,False),'fresh_source_unexposed_authored_negative':(False,False)}[role]
 assert (pid in b,pid in a)==exp,(cid,b,a,exp)
 assert comps['before']['negative_en']==comps['after']['negative_en'];assert comps['before']['prompt_en']==comps['after']['prompt_en']
 for arm,on in zip(['before','after'],exp):
  if on:assert pg(arm)==[f'vo_{pid}_{i}'for i in [1,2,3]]
  else:assert not ph(arm)and not pg(arm)
 results.append({'case':cid,'role':role,'input_hashes_unchanged':True,'audits_independently_replayed_and_equal':True,'before_status':by[cid,'before']['audit_status'],'after_status':by[cid,'after']['audit_status'],'before_hard_ids':b,'after_hard_ids':a,'before_gate_ids':pg('before'),'after_gate_ids':pg('after'),'ordinary_surfaces_equal':ordinary,'positive_and_negative_prose_equal':True,'optional_removed':sorted(set(po('before'))-set(po('after'))),'optional_added':sorted(set(po('after'))-set(po('before')))})
 print('verified pair',cid,flush=True)
write('pack-replay-checks.json',{'scope':'Independent audit-function replays for all 36 saved V2-arm packs; exact input/proposal/ordinary-object checks; not 36 new generator calls','proposal_checks':proposal_checks,'cases':results})
base=g.load_runtime_data();installed=base[g.VISUAL_PROFILE_INDEX_DATA_KEY];br=base[g.VISUAL_OBLIGATIONS_DATA_KEY];ar=copy.deepcopy(br)
for e in proposed['edits']:next(p for p in ar['profiles']if p['id']==e['profile_id'])['activation']['exact_terms'][1]=e['new_value']
source_diffs=diff(br,ar);assert len(source_diffs)==3 and all(x.endswith('activation.exact_terms[1]')for x in source_diffs)
cache=S/'assets/photo_prompt_visual_profile_index.json';vectors=builder.reusable_vectors([cache],ar,provider=g.SEMANTIC_PROVIDER,model=g.SEMANTIC_MODEL_ID,dimensions=g.DEFAULT_SEMANTIC_DIMENSIONS)
assert len(vectors)==len(ar['profiles'])==1622;assert all(vectors[pid]==installed['entries'][pid]['vector']for pid in vectors)
rebuilt=g.build_visual_profile_index_payload(ar,vectors=vectors,provider=g.SEMANTIC_PROVIDER,model=g.SEMANTIC_MODEL_ID,dimensions=g.DEFAULT_SEMANTIC_DIMENSIONS);g.validate_visual_profile_index_metadata(rebuilt,ar)
receipt=read(Q/'index-receipts/both-05f90f550cb3.json');assert digest(rebuilt)==receipt['arms']['after']['index_canonical_sha256']
try:g.validate_visual_profile_index_metadata(installed,ar)
except ValueError as e:stale_error=str(e)
else:raise AssertionError('Stale old index unexpectedly accepted')
data={**base,g.VISUAL_OBLIGATIONS_DATA_KEY:ar,g.VISUAL_PROFILE_INDEX_DATA_KEY:rebuilt}
assert g.dictionary_hash(data)==g.dictionary_hash(base)
# Three canonical positives plus one counterexample, one legacy positive and one fresh negative.
regenerate={'pf_window_seat_compatible_ko','pf_window_seat_canonical_ko_v2','pf_double_helix_canonical_ko_v2','pf_roofless_ruin_canonical_ko_v2','pf_double_helix_old_ko_complete_v2','fresh_cleared_roofless_room_03'}
builds=[]
for case in cases:
 if case['id']not in regenerate:continue
 idir=Path(case['input_dir']);env=g.load_request_envelope_arg(str(idir/'request-envelope.json'));controls=read(idir/'creative-controls.json');core=g.load_authorial_core_arg(str(idir/'authorial-core.json'),request_envelope=env,creative_control_snapshot=controls);review=read(idir/'embodiment-review.json')
 p=g.generate_candidate_pack(data,core,controls,review,seed=manifest['seed']);saved=read(Q/'after'/case['id']/'candidate-pack.json')[0];assert p==saved,case['id']
 builds.append({'case':case['id'],'independent_public_generator_function_replay_equal':True,'pack_canonical_sha256':digest(p)});print('rebuilt after pack',case['id'],flush=True)
write('index-and-generator-checks.json',{'scope':'Independent full-registry production-builder V2 index rebuild in memory and six public generator-function rebuilds, with zero provider calls or disk index copies','index_canonical_sha256':digest(rebuilt),'index_equals_qualification_receipt':True,'profile_count':len(ar['profiles']),'cached_vectors_reused':len(vectors),'new_vectors':0,'all_vector_values_unchanged':True,'stale_old_index_rejected':stale_error,'ordinary_dictionary_hash_unchanged':True,'source_differences':source_diffs,'builds':builds})
end={'head':git('rev-parse','HEAD'),'status':git('status','--porcelain')};assert start==end
write('summary.json',{'start':start,'end':end,'active_cases':len(cases),'active_public_build_records':2*len(cases),'preserved_earlier_v1_before_records':len(rows)-2*len(cases),'independent_composed_audit_function_replays':2*len(cases),'independent_generator_function_replays':len(builds),'before_audit_pass':sum(r['before_status']=='pass'for r in results),'after_audit_pass':sum(r['after_status']=='pass'for r in results),'all_frozen_input_and_pack_hashes_match':True,'all_ordinary_objects_and_prose_equal':True,'proposal_exact_reviewer_strings':True,'provider_calls':0,'images':0,'source_edits':0,'git_writes':0,'disk_index_copies':0})
print(json.dumps(read(O/'summary.json'),indent=2))
