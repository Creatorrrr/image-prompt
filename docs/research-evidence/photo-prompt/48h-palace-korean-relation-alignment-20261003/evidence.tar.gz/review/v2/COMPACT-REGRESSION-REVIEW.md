# Compact regression draft review

Agreement with both maintenance concerns: avoid complete-profile snapshots and do not encode known complete-legacy recall loss as permanently required behavior.

The original 633-line draft is preserved byte-for-byte. The separate compact draft is 190 lines with six focused test methods. It pins only the reviewed Korean aliases, the unchanged selected English relations, their component/evidence/gate invariants, bilingual contract parity, six equivalent negative scenes, nine clause omissions, three relation substitutions and three generic-name boundaries.

Aliases are tested by membership, not equality of the complete alias list, so future genuinely equivalent aliases are permitted. There is no legacy-positive gate-loss assertion, full-profile JSON snapshot, fixed registry size or optional-inventory snapshot. The old complete-legacy gate loss remains qualification evidence only.

Syntax checks (`ast.parse` and compilation) pass without importing or executing the suite. This is an outside-repository draft intended to be copied into the repository's tests directory after approved installation; it uses the usual repository-relative root and the real complete registry/index. No production tests were run with this new file, no source was installed, and no provider was called. Installed-state execution remains required during promotion.

No remaining design concern was found in the compact draft. Existing qualification evidence continues to own the detailed before/after, semantic review, source-history and gate-loss observations.
