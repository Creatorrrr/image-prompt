"""Independent review-only checks, no repository writes or external providers.

Current real merged resolver, six saved-pack public-auditor replays, exact-only
proposal diagnostics and source integrity. No integrated after-arm is claimed.
"""
from pathlib import Path
import concurrent.futures,copy,hashlib,json,os,subprocess,sys,time
sys.dont_write_bytecode=True
R=Path('/workspace/scratch/ce8f20680f5a/image-prompt')
A=Path(__file__).resolve().parents[1];O=Path(__file__).parent
S=R/'skills/photo-prompt-image-generator';sys.path.insert(0,str(S/'scripts'))
import prompt_generator as g
PIDS=['pf_window_seat','pf_double_helix','pf_roofless_ruin']
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,v):(O/name).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def git(*args):return subprocess.check_output(['git',*args],cwd=R,text=True).strip()
def changes(a,b,path=''):
 if isinstance(a,dict) and isinstance(b,dict):
  return [x for k in sorted(set(a)|set(b)) for x in (changes(a.get(k),b.get(k),path+'.'+k))]
 if isinstance(a,list) and isinstance(b,list) and len(a)==len(b):
  return [x for i,(x1,x2)in enumerate(zip(a,b))for x in changes(x1,x2,path+f'[{i}]')]
 return [] if a==b else [path.lstrip('.')]
source=S/'assets/photo_prompt_visual_obligations_palace_fortification.json'
raw={p['id']:p for p in read(source)['profiles']}
old_manifest=read(A/'source-manifest.json')
source_checks={p:sha(R/p)==h for p,h in old_manifest['sources'].items()}
initial={'head':git('rev-parse','HEAD'),'status':git('status','--porcelain')}
assert initial=={'head':'ca0f6d80c85e2538883da9a5a0e01818dfe7df0c','status':''},initial
assert all(source_checks.values()),source_checks
proposals={pid:read(A/'proposal'/f'{pid}.proposed.json')for pid in PIDS}
registry=g.load_visual_obligation_registry(S/'assets/photo_prompt_visual_obligations.json')
index=g.load_visual_profile_index(S/'assets/photo_prompt_visual_profile_index.json',registry)
normalized={p['id']:p for p in registry['profiles']}
proposal_checks={pid:{'changed_paths':changes(raw[pid],proposals[pid]),'vector_input_text_unchanged':g.visual_profile_semantic_text(raw[pid])==g.visual_profile_semantic_text(proposals[pid]),'bm25f_fields_unchanged':g.visual_profile_bm25f_fields(raw[pid])==g.visual_profile_bm25f_fields(proposals[pid])}for pid in PIDS}
assert all(x['changed_paths']==['activation.exact_terms[1]']for x in proposal_checks.values())
history={}
for rev in ['b6e70b78','b4120b84']:
 historic={p['id']:p for p in json.loads(git('show',rev+':'+str(source.relative_to(R))))['profiles']}
 history[rev]={pid:raw[pid]==historic[pid]for pid in PIDS}
inputs=read(A/'frozen-public-input-manifest.json')
pubs=read(A/'frozen-public-requests.json')['cases']
request_map={p['id']:p for p in pubs}
checks=[]
for c in inputs['cases']:
 d=A/'public-controls'/c['id'];p=read(d/'candidate-pack.json')[0];composed=read(d/'composed-baseline.json');core=read(d/'authorial-core.json');env=read(d/'request-envelope.json');r=request_map[c['id']]
 check={'case':c['id'],'input_hashes_match':all(sha(d/n)==h for n,h in c['files'].items()),'raw_request_equal':r['request']==env['request_text']==core['source_request']==p['authorial_core']['source_request'],'baselines_equal':r['baseline']==core['baseline_prompt_en']==p['authorial_core']['baseline_prompt_en']==composed['prompt_en'],'pack_hash_matches_record':sha(d/'candidate-pack.json')==next(x for x in read(A/'public-control-results.json')['cases']if x['case']==c['id'])['pack_sha256'],'all_visual_evidence_occurs':all(v in composed['prompt_en']for e in composed.get('visual_obligation_evidence',{}).values()for v in e.values()),'no_optional_adoption':composed['chosen_candidate_ids']==[]and composed['chosen_visual_concept_ids']==[],'hard_profiles':[ob['id']for ob in (p.get('visual_obligations')or{}).get('obligations',[])],'actual_input_files':[str((d/n).relative_to(A))for n in c['files']]}
 assert all(v for k,v in check.items()if isinstance(v,bool)),check
 checks.append(check)
english_neg={
'pf_window_seat':'The seat is inset within the wall depth; the window side reveals connect to the outer aperture; the scene is distinct from a piece of furniture placed in front of a window. The same wall and the side reveals consist of solid timber, with exposed end grain and timber joints through the full wall depth. The seat is built into this same timber recess.',
'pf_double_helix':'Two stair routes can be traced; the shared central area appears empty; the routes do not merge arbitrarily or collide midway. Both stairs rise as separate continuous straight parallel flights on opposite sides of the same open central space.',
'pf_roofless_ruin':'With its roof absent, the sky is visible from within the room; the remaining walls, windows and floor define the former interior; the damage is connected to structural boundaries rather than merely moss. The broken upper wall edges remain exposed, while all fallen stones and bricks have been removed from the floor, leaving only fitted paving slabs.'}
generic={'pf_window_seat':'an architectural photograph of a window seat','pf_double_helix':'an architectural photograph of two stair routes','pf_roofless_ruin':'an architectural photograph of a roofless hall'}
complete_tails={
'pf_window_seat':' 좌석은 붙박이이며 같은 조적 벽의 창 오목부 깊이 안에 놓인다. 창 측벽은 좌석 공간을 바깥 창과 연결하며 바깥 개구부는 좌석 면보다 바깥쪽에 있다.',
'pf_double_helix':' 서로 다른 두 나선형 계단 구간이 같은 중심부 둘레를 감아 돌고 각 구간은 서로 분리된 연속 동선을 유지한다.',
'pf_roofless_ruin':' 남은 벽과 창 개구부가 그 방의 옛 실내 바닥을 둘러싸고 파손된 상부 구조 아래에 떨어진 조적 잔해가 국소적으로 놓여 있다.'}
probes=[{'id':r['id'],'profile_id':r['profile_id'],'group':'original_public_request','text':r['request']}for r in pubs]
for pid in PIDS:
 probes += [{'id':pid+'_english_equivalent_negative','profile_id':pid,'group':'english_equivalent_negative','text':english_neg[pid]}, {'id':pid+'_generic_negative','profile_id':pid,'group':'generic_negative','text':generic[pid]}, {'id':pid+'_old_wording_complete_facts','profile_id':pid,'group':'old_wording_with_all_english_facts','text':raw[pid]['activation']['exact_terms'][1]+'.'+complete_tails[pid]}]
results=[]
for c in probes:
 result=g.resolve_visual_profile_hits(registry,[{'source':'concept_lock','text':c['text'],'polarity':'required','priority':'critical','mandatory':True}],visual_profile_index=index,adult_context=False)
 row={**c,'current_real_merged_hard_profiles':[h['profile_id']for h in result['hits']if h.get('hard_eligible')],'current_exact_match':any(g.intent_alias_matches(c['text'],t)and not g.intent_term_is_negated(c['text'],t)for t in raw[c['profile_id']]['activation']['exact_terms']),'proposed_exact_match_only':any(g.intent_alias_matches(c['text'],t)and not g.intent_term_is_negated(c['text'],t)for t in proposals[c['profile_id']]['activation']['exact_terms'])}
 results.append(row)
 if c['group']in ['english_equivalent_negative','generic_negative']:assert c['profile_id']not in row['current_real_merged_hard_profiles'],row
 if c['group']=='old_wording_with_all_english_facts':assert c['profile_id']in row['current_real_merged_hard_profiles']and not row['proposed_exact_match_only'],row
write('source-and-input-checks.json',{'initial_repo':initial,'source_hashes_match_prior_audit':source_checks,'proposal_surface':proposal_checks,'raw_profile_history_equality':history,'public_input_integrity':checks,'claims':'No source mutation or integrated after-arm; no external provider or image calls.'})
write('resolver-and-recall-probes.json',{'scope':'15 current full-registry real-index resolver cases, including three new English-equivalent synthetic negatives, three generic negatives and three complete-fact legacy-wording recall controls. Proposed matches are literal diagnostics only.','real_registry_count':len(registry['profiles']),'query_vector_supplied':False,'provider_calls':0,'cases':results})
env={k:v for k,v in os.environ.items()if not any(x in k.upper()for x in ['TOKEN','API_KEY','CREDENTIAL'])};env['PYTHONDONTWRITEBYTECODE']='1'
def audit(c):
 d=A/'public-controls'/c['id'];cmd=[str(R/'.venv/bin/python'),str(S/'scripts/audit_composed_prompt.py'),'--pack',str(d/'candidate-pack.json'),'--composed',str(d/'composed-baseline.json')]
 start=time.monotonic();p=subprocess.run(cmd,cwd=R,env=env,text=True,capture_output=True,timeout=180)
 row={'case':c['id'],'command':cmd,'returncode':p.returncode,'seconds':round(time.monotonic()-start,3),'result':json.loads(p.stdout),'stderr':p.stderr}
 original=read(d/'composed-audit.stdout.json');row['matches_saved_result']=row['result']==original
 assert row['matches_saved_result'],row
 return row
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool: replays=list(pool.map(audit,inputs['cases']))
write('independent-composed-audit-replays.json',{'scope':'Reruns unchanged public auditor against all six originally saved packs/compositions; does not regenerate packs or run an integrated proposal after-arm.','cases':replays})
cmd=[str(R/'.venv/bin/python'),'-m','unittest','tests.test_photo_palace_fortification_semantics','-v'];p=subprocess.run(cmd,cwd=R,env=env,text=True,capture_output=True,timeout=180);(O/'palace-tests.log').write_text(p.stdout+p.stderr)
final={'head':git('rev-parse','HEAD'),'status':git('status','--porcelain')};assert final==initial
write('verification-summary.json',{'start':initial,'end':final,'public_admissions_independently_verified_from_saved_artifacts':6,'public_audits_independently_replayed':len(replays),'audit_statuses':{x['case']:x['result']['status']for x in replays},'all_audit_outputs_match':all(x['matches_saved_result']for x in replays),'current_real_index_resolver_cases':len(probes),'palace_test_returncode':p.returncode,'source_hashes_unchanged':all(sha(R/q)==h for q,h in old_manifest['sources'].items()),'production_edits':0,'git_writes':0,'provider_calls':0,'images':0,'index_rebuilds':0})
print(json.dumps(read(O/'verification-summary.json'),indent=2))
