import json
from pathlib import Path
O=Path(__file__).parent;proof=json.loads((O/'real-index-proof.json').read_text());results=[]
for c in proof['cases']:
 b,a=[v['resolution'] for v in c['variants']]
 def rows(r):return [dict(rank=i+1,**h) for i,h in enumerate(r['hits'])]
 br,ar=rows(b),rows(a)
 identity=lambda rows:[(r['rank'],r['profile_id'],r['match_basis'],r['applicability_status'],r['hard_eligible'],r['optional_eligible']) for r in rows]
 assert identity(br)==identity(ar)
 results.append(dict(case=c['name'],ordered_membership_and_eligibility_equal=True,before=br,proposed_lexical_diagnostic=ar,score_changes=[dict(profile_id=x['profile_id'],before_bm25f=x.get('bm25f_score'),proposed_bm25f=y.get('bm25f_score'),before_fusion=x.get('fusion_score'),proposed_fusion=y.get('fusion_score')) for x,y in zip(br,ar) if x.get('bm25f_score')!=y.get('bm25f_score') or x.get('fusion_score')!=y.get('fusion_score')]))
(O/'rank-membership-comparison.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n')
for r in results:print(r['case'],'same membership/ranks/eligibility','score changes',len(r['score_changes']))
