#!/usr/bin/env python3
import copy,hashlib,json,subprocess,sys
from pathlib import Path
O=Path(__file__).resolve().parent;R=Path('REPOSITORY_ROOT');S=R/'skills/photo-prompt-image-generator'
sys.path.insert(0,str(S/'scripts'))
import prompt_generator as pg
proposal=json.loads((O/'frozen-proposal.json').read_text());assert hashlib.sha256(proposal['proposed'].encode()).hexdigest()==proposal['proposed_sha256']
reg=pg.load_visual_obligation_registry(S/'assets/photo_prompt_visual_obligations.json');index=pg.load_visual_profile_index(S/'assets/photo_prompt_visual_profile_index.json',reg)
pid=proposal['profile_id'];p=next(x for x in reg['profiles'] if x['id']==pid);assert p['semantics']['paraphrase_examples'][7]==proposal['before']
newreg=copy.deepcopy(reg);pn=next(x for x in newreg['profiles'] if x['id']==pid);pn['semantics']['paraphrase_examples'][7]=proposal['proposed'];newindex=pg.build_visual_profile_index_payload(newreg)
controls=json.loads((O/'independent-controls.json').read_text());controls=controls.get('cases',controls) if isinstance(controls,dict) else controls
cases=[dict(name='old_authored',text=proposal['before']),dict(name='proposed_authored',text=proposal['proposed']),dict(name='old_authored_exact',text='one-piece dress. '+proposal['before']),dict(name='proposed_authored_exact',text='one-piece dress. '+proposal['proposed']),*controls]
results=[]
for case in cases:
 name=case.get('name',case.get('case_name',case.get('case')));text=case['text'];rows=[dict(source='concept_lock',text=text,polarity='required'),dict(source='authorial_core_baseline',text=text,polarity='advisory')];fields=dict(active_request=[text],baseline_prompt=[text])
 variants=[]
 for label,r,i,profile in [('actual_bound_baseline',reg,index,p),('proposed_lexical_diagnostic',newreg,newindex,pn)]:
  result=pg.resolve_visual_profile_hits(r,rows,visual_profile_index=i,query_fields=fields,adult_context=True)
  variants.append(dict(lane=label,target_hits=[h for h in result['hits'] if h['profile_id']==pid],resolution=result,applicability=pg.visual_profile_context_applicability(profile,text,has_authorial_core_context=True),component_match=pg.candidate_pack_visual_component_match(profile,text)))
 results.append(dict(name=name,source_case=case,source_rows=rows,query_fields=fields,variants=variants))
manifest=dict(head=subprocess.check_output(['git','-C',str(R),'rev-parse','HEAD'],text=True).strip(),status=subprocess.check_output(['git','-C',str(R),'status','--short'],text=True),source_hashes={str(f.relative_to(R)):hashlib.sha256(f.read_bytes()).hexdigest() for f in [S/'assets/photo_prompt_visual_obligations.json',S/'assets/photo_prompt_visual_profile_index.json',S/'scripts/prompt_generator.py']},proposed_index_mode='Fresh production lexical-only index; no reused or generated vectors; no embedding lane exercised; not registry-bound production embedding qualification')
(O/'real-index-proof.json').write_text(json.dumps(dict(manifest=manifest,proposal=proposal,cases=results),ensure_ascii=False,indent=2)+'\n')
for c in results:print(c['name'],[(v['lane'],v['applicability'],[(h['match_basis'],h.get('hard_eligible'),h.get('optional_eligible')) for h in v['target_hits']]) for v in c['variants']],flush=True)
