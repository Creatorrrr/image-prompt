import json,sys
from pathlib import Path
R=Path('REPOSITORY_ROOT'); O=Path(__file__).parent
sys.path.insert(0,str(R/'skills/photo-prompt-image-generator/scripts'))
import prompt_generator as pg
reg=pg.load_visual_obligation_registry(R/'skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations.json')
rows=[]; old=json.loads((O.parent/'current-self-context-conflicts.json').read_text());oldids={x['id'] for x in old}
for p in reg['profiles']:
 a=p.get('activation') or {}; guards=a.get('exclude_if_any_terms',[])+(a.get('context_disambiguation') or {}).get('exclude_if_any_terms',[])
 sem=p.get('semantics') or {}; groups=(sem.get('component_semantics') or {}).get('groups',[])
 leaves=[('definition',sem.get('definition',''))]+[('paraphrase/'+str(i),x) for i,x in enumerate(sem.get('paraphrase_examples',[]))]+[(f'component/{i}/{j}',x) for i,g in enumerate(groups) for j,x in enumerate(g.get('any_terms',[]))]
 for path,text in leaves:
  hits=[g for g in guards if pg.intent_alias_matches(text,g)]
  if hits:rows.append(dict(profile_id=p['id'],path=path,text=text,guards=hits,from_old_21=p['id'] in oldids))
checks=[]
for p in reg['profiles']:
 if p['id'] not in oldids:continue
 groups=(p.get('semantics',{}).get('component_semantics') or {}).get('groups',[])
 text='; '.join(g['any_terms'][0] for g in groups)
 checks.append(dict(id=p['id'],text=text,applicability=pg.visual_profile_context_applicability(p,text,has_authorial_core_context=True)))
(O/'scan.json').write_text(json.dumps(dict(profile_count=len(reg['profiles']),current_positive_leaf_conflicts=rows,old_21_current_components=checks),ensure_ascii=False,indent=2)+'\n')
print(json.dumps(rows,ensure_ascii=False,indent=2))
