#!/usr/bin/env python3
"""Replay frozen ten resolver queries against a registry-bound real AFTER index; no provider call."""
import hashlib,json,subprocess,sys
from pathlib import Path
O=Path(__file__).resolve().parent;R=Path('REPOSITORY_ROOT');S=R/'skills/photo-prompt-image-generator';sys.path.insert(0,str(S/'scripts'))
import prompt_generator as pg
proof=json.loads((O/'real-index-proof.json').read_text());proposal=json.loads((O/'frozen-proposal.json').read_text());reg=pg.load_visual_obligation_registry(S/'assets/photo_prompt_visual_obligations.json');index=pg.load_visual_profile_index(S/'assets/photo_prompt_visual_profile_index.json',reg)
pid=proposal['profile_id'];p=next(x for x in reg['profiles'] if x['id']==pid);assert p['semantics']['paraphrase_examples'][7]==proposal['proposed']
results=[]
for c in proof['cases']:
 name=c['name'];baseline=c['variants'][0]['resolution'];result=pg.resolve_visual_profile_hits(reg,c['source_rows'],visual_profile_index=index,query_fields=c['query_fields'],adult_context=True)
 assert not result['embedding_evaluated']
 br=[dict(rank=i+1,**h) for i,h in enumerate(baseline['hits'])];ar=[dict(rank=i+1,**h) for i,h in enumerate(result['hits'])]
 identity=lambda rows:[(r['rank'],r['profile_id'],r['match_basis'],r['applicability_status'],r['hard_eligible'],r['optional_eligible']) for r in rows]
 results.append(dict(case=name,source_case=c['source_case'],source_rows=c['source_rows'],query_fields=c['query_fields'],ordered_membership_ranks_flags_equal=identity(br)==identity(ar),before=br,after=ar,after_resolution=result,after_applicability=pg.visual_profile_context_applicability(p,c['source_case']['text'],has_authorial_core_context=True),after_component_match=pg.candidate_pack_visual_component_match(p,c['source_case']['text'])))
manifest=dict(head=subprocess.check_output(['git','-C',str(R),'rev-parse','HEAD'],text=True).strip(),status=subprocess.check_output(['git','-C',str(R),'status','--short'],text=True),files={str(f.relative_to(R)):hashlib.sha256(f.read_bytes()).hexdigest() for f in [S/'assets/photo_prompt_visual_obligations.json',S/'assets/photo_prompt_visual_profile_index.json',S/'scripts/prompt_generator.py']},qualification='Actual registry-bound index replay using frozen queries and BM25F. Stored vector binding checked by production loader; no query vectors/provider calls, embedding retrieval not exercised.')
(O/'actual-bound-after-proof.json').write_text(json.dumps(dict(manifest=manifest,cases=results),ensure_ascii=False,indent=2)+'\n')
for r in results:print(r['case'],'same ordered membership/ranks/flags:',r['ordered_membership_ranks_flags_equal'])
assert all(r['ordered_membership_ranks_flags_equal'] for r in results)
