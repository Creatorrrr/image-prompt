import hashlib,json,sys
from pathlib import Path
R=Path('REPOSITORY_ROOT');O=Path(__file__).parent/'public-cli';sys.path[:0]=[str(R),str(R/'skills/photo-prompt-image-generator/scripts')]
import prompt_generator as pg
from tests import photo_prompt_fixtures as f
proposal=json.loads((O.parent/'frozen-proposal.json').read_text());controls=json.loads((O.parent/'independent-controls.json').read_text())
cases=[dict(name='source-original',text=proposal['before'],subject='One continuous dress garment',source='source-guided diagnostic'),dict(name='source-proposed',text=proposal['proposed'],subject='One continuous dress garment',source='source-guided diagnostic')]
for i,subject in [(0,'A woman wearing a calf-length wrap dress'),(2,'A connected garment with separate trouser legs'),(4,'An empty boutique window with a clothing sign')]:
 x=controls[i];cases.append(dict(name=x['case_name'],text=x['text'],subject=subject,source='independent blind reviewer diagnostic'))
manifest=[]
for case in cases:
 n=case['name'];request=case['text'];subject=case['subject'];scene=request
 if n=='sign_caption_only_negative':scene='An empty boutique window contains a large sign reading ONE-PIECE DRESS and a caption saying Our newest dress has arrived. Lettering and empty display stands occupy the entire display.'
 baseline=subject+'. '+scene+' The framing preserves the stated subject and its complete visible structure. Coherent directional daylight reveals construction details and clear material boundaries. A quiet background separates the subject from surrounding surfaces without disrupting its specified relationships. Natural colors, controlled highlights and legible shadows preserve local texture. The camera provides a straightforward view at a moderate distance, with intentional focal hierarchy and clear foreground-to-background separation. All stated objects retain their original ownership and spatial relationships. The photograph preserves the stated geometry and construction without adding a new event or changing the selected subject.'
 controls_snapshot=pg.creative_controls.resolve(request,overrides={'sensual':0,'fetish':0,'creativity':1,'surreal':0},seed=824)
 core=f.core(request,interpreted_intent=request,subject=subject,setting='the stated photographic scene',event=scene,visual_priorities=('stated subject','construction details','clear material boundaries'),baseline_prompt_en=baseline,anchor_evidence=(subject,'stated subject','clear material boundaries'))
 core['creative_controls_sha256']=controls_snapshot['canonical_sha256'];core['variation_key']='dress-self-context-'+n
 envelope=f.envelope(request);envelope['request_id']='dress-self-context-'+n
 review=dict(contract_version='photo-embodiment-review/v1',provenance='agent_prepack',prompt_sha256=hashlib.sha256(core['baseline_prompt_en'].encode()).hexdigest(),scope='not_applicable',summary='Static garment/display diagnostic has no specified biomechanical action requiring body-action review. No image assessment is claimed.',checks={})
 d=O/'inputs'/n;d.mkdir(parents=True,exist_ok=True)
 for key,v in [('request-envelope',envelope),('authorial-core',core),('creative-controls',controls_snapshot),('embodiment-review',review)]:
  (d/(key+'.json')).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
 manifest.append(dict(case=n,seed=824,source_guidance=case['source'],inputs={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(d.glob('*.json'))}))
(O/'frozen-input-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print('Frozen five diagnostic cases; no expectation of same-query recall gain')
