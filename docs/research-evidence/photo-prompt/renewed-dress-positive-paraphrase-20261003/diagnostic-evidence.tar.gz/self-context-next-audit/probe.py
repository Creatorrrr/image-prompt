#!/usr/bin/env python3
import copy,hashlib,json,subprocess,sys
from pathlib import Path
R=Path('REPOSITORY_ROOT');O=Path(__file__).resolve().parent;A=R/'skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations.json'
sys.path.insert(0,str(R/'skills/photo-prompt-image-generator/scripts'))
import prompt_generator as pg
reg=pg.load_visual_obligation_registry(A);pid='one_piece_dress_construction';p=next(x for x in reg['profiles'] if x['id']==pid)
old=p['semantics']['paraphrase_examples'][7]
assert old.endswith('and the lower section does not divide into trouser legs.')
new=old.replace('and the lower section does not divide into trouser legs.','and the lower section forms one continuous skirt-shaped dress silhouette.')
after=copy.deepcopy(reg);pa=next(x for x in after['profiles'] if x['id']==pid);pa['semantics']['paraphrase_examples'][7]=new
index=pg.build_visual_profile_index_payload(reg);index_after=pg.build_visual_profile_index_payload(after)
cases=[('old_authored',old),('proposed_authored',new),('old_with_exact','one-piece dress. '+old),('proposed_with_exact','one-piece dress. '+new),('unchanged_short_paraphrase',p['semantics']['paraphrase_examples'][5]),('real_trouser_confound','one-piece dress. A dress garment whose lower section divides into trouser legs.'),('real_jumpsuit','one-piece dress. A dress garment with jumpsuit construction.'),('swimsuit','one-piece swimsuit product view.'),('anime','One Piece anime with Luffy.'),('opposite_clothing_exact','몸판에서 긴 두 바짓가랑이로 이어지는 원피스형 의복')]
results=[]
for name,text in cases:
 rows=[dict(source='user_requirement',text=text),dict(source='authorial_core_appearance',text='dress garment. '+text)]
 variants=[]
 for label,r,i,target in [('before',reg,index,p),('proposed',after,index_after,pa)]:
  result=pg.resolve_visual_profile_hits(r,rows,visual_profile_index=i,adult_context=True)
  variants.append(dict(variant=label,applicability=pg.visual_profile_context_applicability(target,'dress garment. '+text,has_authorial_core_context=True),target_hits=[x for x in result['hits'] if x['profile_id']==pid],component_match=pg.candidate_pack_visual_component_match(target,text)))
 results.append(dict(case=name,text=text,rows=rows,results=variants))
(O/'consumer-proof.json').write_text(json.dumps(dict(head=subprocess.check_output(['git','-C',str(R),'rev-parse','HEAD'],text=True).strip(),status=subprocess.check_output(['git','-C',str(R),'status','--short'],text=True),source_sha256=hashlib.sha256(A.read_bytes()).hexdigest(),before=p,proposed=pa,cases=results),ensure_ascii=False,indent=2)+'\n')
(O/'exact-leaves.json').write_text(json.dumps([dict(file=str(A.relative_to(R)),profile_id=pid,path=['semantics','paraphrase_examples',7],before=old,proposed=new)],indent=2)+'\n')
for x in results:print(x['case'],[(y['variant'],y['applicability'],[(z.get('status'),z.get('hard_eligible'),z.get('optional_eligible')) for z in y['target_hits']]) for y in x['results']],flush=True)
