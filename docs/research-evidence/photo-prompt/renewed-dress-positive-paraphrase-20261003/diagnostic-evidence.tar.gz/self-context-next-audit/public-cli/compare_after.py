#!/usr/bin/env python3
import hashlib,json
from pathlib import Path
O=Path(__file__).resolve().parent;rows=[]
for c in json.loads((O/'frozen-input-manifest.json').read_text()):
 name=c['case'];d=O/'inputs'/name
 for f,h in c['inputs'].items():assert hashlib.sha256((d/f).read_bytes()).hexdigest()==h
 bpath=O/'before'/f'{name}-pack.json';apath=O/'after'/f'{name}-pack.json';b=json.loads(bpath.read_text())[0];a=json.loads(apath.read_text())[0]
 assert a['authorial_core']==b['authorial_core']
 bh=(b.get('visual_obligations') or {}).get('obligations',[]);ah=(a.get('visual_obligations') or {}).get('obligations',[])
 assert bh==ah
 rows.append(dict(case=name,inputs_frozen=True,authorial_core_equal=True,hard_obligations_equal=True,pack_byte_equal=bpath.read_bytes()==apath.read_bytes(),changed_top_level_keys=[k for k in sorted(set(b)|set(a)) if b.get(k)!=a.get(k)]))
B=json.loads((O/'before/run-manifest.json').read_text());A=json.loads((O/'after/run-manifest.json').read_text());changes=[k for k,v in B['hashes'].items() if A['hashes'].get(k)!=v]
assert set(changes)=={'skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations.json','skills/photo-prompt-image-generator/assets/photo_prompt_visual_profile_index.json'},changes
(O/'after/comparison.json').write_text(json.dumps(dict(source_changes=changes,cases=rows),indent=2)+'\n');print(json.dumps(rows,indent=2))
