# Positive self-context audit: one source-consistency proposal

## Recommendation

A narrowly justified DATA-only correction is available in `one_piece_dress_construction`, `semantics.paraphrase_examples[7]`. Change only its final clause from `and the lower section does not divide into trouser legs.` to `and the lower section forms one continuous skirt-shaped dress silhouette.` The rest of the sentence is unchanged. The proposed text and its SHA256 were frozen before evaluating independent reviewer controls (`frozen-proposal.json`). No repo edit, paid call, or runtime modification was made by this audit.

This is a positive-example/source-consistency repair, **not a same-query recall gain**. The proposed wording already resolves as optional BM25F in the existing registry-bound index; with its exact label it is already hard-eligible. The DATA edit does not make the original negative-worded request eligible. It merely replaces an authored positive example that its own context consumer rejects with positive geometry preserving the same selected meaning.

## Historical inventory and scan boundaries

The historical 21 self-context component bundles are stale: every current first-alternative component bundle passes the production shared context-applicability predicate. `scan.json` records the current texts and results. This is not a statement of complete natural-query recall.

The new lexical scan finds 48 overlapping positive-source leaves: 46 definitions and 2 paraphrases. **These are scan candidates, not 48 defects.** Definitions often deliberately explain differences from excluded concepts and need not be intended as standalone positive query examples. No bulk definition rewrite is recommended. The separate blush paraphrase was not fully qualified in this audit, so no second proposal is made.

Previously deferred inverted/triangle nested aliases, rectangular/square specificity, and global owner-context applicability remain deferred. This proposal does not delete exclusions, change precedence, add phrase exceptions, or relax ownership requirements.

## Original intent and data ownership

The original dress paragraph is explicitly authored as the detailed English positive neutral description in the October 2 concept card `dress-one-unit`, under `neutral_descriptions.detailed.en`. Its three project-selected invariants are: bodice and skirt form one garment; that same garment has a dress-shaped lower outline; seams/closure/drape belong to that garment. Waist seams, panels, and wrap closures are allowed. Trousers, matching separates, swimwear, and franchise meanings are outside the selected scope.

Source: `docs/research-evidence/photo-prompt/semantic-guidance-data-research-20261002/phase-1/concept-cards.json`, corroborated by `CONCEPTS.md:66–100` and `build_pack.py`. The original draft metadata is retained in `source-provenance.json`; current registry adoption is independently present in the runtime asset, and git traces the paragraph to `0adb5f6e`. The card cites Collins' broader one-piece clothing definition, while explicitly marking the dress-only boundaries as **project-selected scope**. This audit does not claim independent dictionary revalidation.

The relevant schema-owned field is `semantics.paraphrase_examples` in the main visual-obligation registry. There are no authored-component overrides for this profile. The shared context guard lives in `activation.context_disambiguation.exclude_if_any_terms`, includes `trouser legs`, and is conditional on authorial-core context. All activation/context guards, components, evidence, gates, labels, claims, and reject substitutes remain identical. The proposal does not edit source-history documents.

## Actual consumer evidence

`probe.py` is the initial source-isolation diagnostic using fresh lexical indexes and explicit dress-sense context. `real_index_probe.py` is the stronger comparison: baseline uses `load_visual_profile_index` against the actual current registry; the proposed side builds a fresh production lexical-only index from the in-memory one-leaf copy. No old vector is reused as if it described changed text. No embeddings/providers are exercised.

- Original positive paragraph: component matcher recognizes `semantic_paraphrase_example`, but shared context rejects it as `context_disambiguation_exclusion` because of `trouser legs`
- Original paragraph plus exact label: recorded exact hit is context-mismatched, hard=false, optional=false
- Proposed paragraph: shared context succeeds and existing real index already retrieves it as optional BM25F; exact-label version is already hard-eligible
- Editing the paragraph changes which source sentence has literal paraphrase-example status, but does not alter any tested same-query target eligibility

The six independent controls were written by a separate reviewer who saw the original meaning/boundaries, not the proposed rewrite or probes. Their untouched texts and expected interpretations are in `independent-controls.json`:

- English natural dress positive: BM25F optional in both; strict context-sense check itself lacks an authored positive phrase in both
- Korean natural dress positive: exact hit exists but is context-mismatched and ineligible in both; this existing natural recall limitation is not fixed
- Trousers, matching separates, and mixed-owner negatives: target absent/ineligible in both
- Sign/caption-only negative: exact hit is recorded but `context_mismatch`, hard=false, optional=false in both. **It is rejected, not an eligible false positive**

`rank-membership-comparison.json` includes all ordered hits, ranks, applicability, eligibility, BM25F and fusion scores. All ten same-query hit lists retain identical membership, order, match basis and eligibility. Several BM25F scores change due to lexical-index text statistics, but no observed neighbor gains/losses or rank changes occur. This small diagnostic set does not establish global rank stability, natural recall improvement, or embedding behavior.

## Frozen normal CLI BEFORE

Five cases are frozen under `public-cli/inputs`: original authored paragraph, proposed authored paragraph, independent English natural positive, independent adjacent-trouser negative, and independent sign-only negative. The first two are explicitly source-guided diagnostics. No candidate IDs are preselected and no images are generated. The sign baseline positively describes the empty display while its untouched request retains the reviewer's sign-only wording.

The initial run guard correctly refused the obsolete baseline after the parent committed unrelated weapon changes. BEFORE was restarted against the clean current `c37e21f6` baseline, without modifying the frozen input files or the dress proposal. Actual CLI results and source hashes are preserved under `public-cli/before/`; failures, if any, are retained rather than silently repaired.

BEFORE closure: all five normal CLI cases exited 0 and all recorded source hashes remained unchanged. `public-cli/before/frozen-verification.json` verifies each input hash and exact emitted baseline equality; the raw packs and logs preserve all observed discovery results. This qualification remains provider-free and source-consistency-only.

## Final actual registry-bound AFTER qualification

After the parent applied the exact frozen paragraph leaf and regenerated its genuine vector/index binding, `actual_bound_after.py` replayed the same ten query texts, source rows, and query fields against the production-loaded current index. All ordered hit membership, rank, match basis, applicability, hard eligibility, and optional eligibility remain equal to the saved actual baseline. Full score-bearing rows and source hashes are preserved in `actual-bound-after-proof.json`. This is a real registry-bound BM25F consumer check; no query vector/provider was used and embedding retrieval recall is not claimed.

`public-cli/run_phase.py after` completed all five normal CLI cases with exit 0. `public-cli/compare_after.py` verifies each frozen input hash, unchanged full authorial core and hard obligations, and **all five pack files byte-for-byte identical BEFORE versus AFTER**. Source hash differences are restricted to the main registry and derived index; runtime tools and the natural-environment extension are unchanged. `applied-leaf-verification.json` independently verifies precisely `/semantics/paraphrase_examples/7` changed in the dress profile, including identical guards and all other fields.

Therefore the qualified outcome is solely a coherent authored positive example, with no demonstrated same-query pipeline change or recall gain. Original negative-worded queries remain blocked, the proposed wording was already accepted by baseline, the independent Korean positive remains context-mismatched, and the sign control remains rejected. No source edits or paid calls were performed by this audit worker; the parent owns the separate genuine embedding/index update and its cost ledger.
