import json,sys,hashlib
from pathlib import Path
P=Path(__file__).parent;R=P.parent/'image-prompt';A=R/'skills/photo-prompt-image-generator/assets';sys.path.insert(0,str(A.parent/'scripts'))
import prompt_generator as pg
import build_visual_profile_index as bi
D=P/'liminal-alternative-validation';D.mkdir(exist_ok=True)
f=A/'photo_prompt_visual_obligations.json';ip=A/'photo_prompt_visual_profile_index.json';before=f.read_text();ibefore=ip.read_text();raw=json.loads(before);old=json.loads(ibefore);assert json.dumps(raw,ensure_ascii=False,indent=2)+'\n'==before
leaf=json.load(open(P/'architecture-visibility-audit/exact-leaves.json'))[0];p=next(p for p in raw['profiles']if p['id']==leaf['profile_id']);(D/'baseline-profile.json').write_text(json.dumps(p,ensure_ascii=False,indent=2)+'\n');(D/'original-index.json').write_text(ibefore)
node=p
for key in leaf['path'][:-1]:node=node[key]
assert node[leaf['path'][-1]]==leaf['before'];node[leaf['path'][-1]]=leaf['proposed'];text=json.dumps(raw,ensure_ascii=False,indent=2)+'\n'
try:
 f.write_text(text);reg=pg.load_visual_obligation_registry(f);vectors=bi.reusable_vectors([ip],reg,provider=pg.SEMANTIC_PROVIDER,model=pg.SEMANTIC_MODEL_ID,dimensions=pg.DEFAULT_SEMANTIC_DIMENSIONS);assert len(vectors)==len(reg['profiles'])==1507
 new=pg.build_visual_profile_index_payload(reg,vectors=vectors);changes=[k for k in old if old[k]!=new[k]];assert changes==['registry_sha256'],changes
 bi.write_payload(ip,new);pg.load_visual_profile_index(ip,reg)
 result={'only_index_change':changes,'unchanged_entries':len(vectors),'all_vectors_texts_bm25f_identical':True,'provider_calls':0,'source_before_sha256':hashlib.sha256(before.encode()).hexdigest(),'source_after_sha256':hashlib.sha256(text.encode()).hexdigest(),'source_profile_id':leaf['profile_id']};(D/'index-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
except Exception:
 f.write_text(before);ip.write_text(ibefore);raise
