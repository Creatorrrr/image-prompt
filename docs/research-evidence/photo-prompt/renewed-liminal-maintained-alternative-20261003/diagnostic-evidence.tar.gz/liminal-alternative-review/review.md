# Independent liminal maintained-cue alternative review

Decision: accept the exact one-item append as a source-authorized canonical evidence alternative, subject to unchanged-boundary verification during integration. No source change was made by this review.

## Why this is authorized

The proposed string is exactly the English `familiar_maintained_service_cues.any_terms[0]` already in the profile:

`working lights clean surfaces furniture signs or route markers imply normal use`

Both that OR-bearing component literal and the existing AND-bearing evidence anchor were introduced in commit `84e63c02ba328ec774d9222a6881634530b3a526` (2026-09-01). A parsed comparison proves the entire original liminal profile equals the profile at reviewed HEAD `f4d3532dd295275f7d64d94d720e57ace509de36`. This is not a new paraphrase invented after an evaluation result.

Independent semantic support is consistent across the maintained familiar-place definition, the five-component contract, the composition instruction and the maintained-cue render gate. The gate asks for working maintained cues that make expected ordinary use concrete; it does not prescribe a universal furniture-plus-route-marker pair. The four approved-evidence-linked candidate rows likewise describe signs/doors/lights/furnishings, route/use cues and maintained transition depth. Their original English semantic text already used these alternatives. The narrow append repairs a mismatch between those authored alternatives and a single evidence literal, while retaining the old anchor byte-for-byte as the first option.

## Source ownership and limit

The registry owns this project-specific five-part visual contract. The original research note, section 3.6, supplies familiar wayfinding/furniture/lighting, expected-use/occupancy gaps, temporal traces and a small readable deviation, and rejects a ruin or empty room alone. The approved `imaginal_liminal_place_diel_lewis` evidence row links this profile and all four candidates to place-familiarity/configural-deviation research. It explicitly says that the research is related to liminal imagery rather than a closed definition. Accordingly, the research supports the bounded design, not a claim that scholars mandated this English literal or a universally exhaustive five-part definition.

The earlier provenance snapshots of the registry and original research note match their recorded SHA-256 values. No proposing-audit conclusion or holdout result was used.

## Exact boundaries that must remain unchanged

1. Append only the exact string above to `evidence_requirements.maintained_cues_phrase.must_mention_any`. Preserve `working lights clean surfaces furniture and route markers imply normal service` unchanged and first. Keep `min_content_words: 9`.
2. Preserve all five mandatory groups and `minimum_component_groups: 5`: transition/collective-use function; familiar maintained service cues; expected occupancy/use gap; temporal residue/deviation; unresolved route/threshold.
3. Preserve all five evidence fields, the other four exact anchor lists, every minimum, distinct/literal binding checks and all five render gates with their existing IDs, descriptions and review scales.
4. Preserve the definition, composition, candidates, activation/exclusions, runtime expression, contrasts and reject substitutes. Route depth must connect maintained cues, missing expected use, temporal residue and unresolved destination in one familiar place.
5. Working normal-use cues are essential. Surviving signs or furniture in abandonment, ordinary closure, darkness or emptiness alone do not satisfy the relation. A generic closed venue cannot substitute for the expected-use gap, material temporal residue and unresolved endpoint. Conversely, do not invent a blanket exclusion for every temporary pause: suspended operation is already part of the original meaning.
6. Do not change matchers, runtime/audit code, activation, requester-definition priority, optional semantic discovery, provider behavior or retrieval weights/text. Reconcile necessary derived registry/index identity only through the approved integration workflow.

## What this acceptance does not establish

The consumer checks for a complete canonical anchor string. It does not interpret the embedded word “or” as a grammar accepting arbitrary sign-only or furniture-free natural prose. Acceptance therefore covers one previously authored canonical alternative, not natural-paraphrase improvement. A passing text contract also cannot establish rendered-image fidelity, aesthetic quality or user preference. Broader anchor growth, changes to other evidence fields, boundary exclusions or activation require a separate proposal and evidence.

This source-only review ran JSON/provenance/equality checks, not runtime evaluation. Provider calls, source edits, runtime changes and remote writes: none. Integration still needs its separately scoped evidence that the old and new canonical anchors work while missing-part/near-miss cases and all unchanged boundaries remain intact. `decision.json` records the exact proposed leaf and hashes for this review.
