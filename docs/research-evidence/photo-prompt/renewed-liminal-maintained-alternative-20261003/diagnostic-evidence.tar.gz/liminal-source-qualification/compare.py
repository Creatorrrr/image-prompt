#!/usr/bin/env python3
"""Compare immutable canonical DATA fixtures; refuse silent expectation or input drift."""
from pathlib import Path
import copy, hashlib, json, sys
P=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_text())
def dump(p,o):p.write_text(json.dumps(o,ensure_ascii=False,indent=2)+'\n')
def diff(a,b,path=''):
 if type(a)!=type(b):return [{'path':path,'before':a,'after':b}]
 if isinstance(a,dict):
  rows=[]
  for k in sorted(set(a)|set(b)):
   if k not in a or k not in b:rows.append({'path':path+'/'+k,'before':a.get(k),'after':b.get(k)})
   else:rows.extend(diff(a[k],b[k],path+'/'+k))
  return rows
 if isinstance(a,list):
  if len(a)!=len(b):return [{'path':path,'before':a,'after':b}]
  return [r for i,(x,y)in enumerate(zip(a,b))for r in diff(x,y,path+'/'+str(i))]
 return []if a==b else [{'path':path,'before':a,'after':b}]

def summarize(arm):
 root=P/arm;report=read(root/'report.json');man=read(P/'manifest.json');issues=[];summary={'arm':arm,'input_hashes_unchanged':all(hashlib.sha256((P/p).read_bytes()).hexdigest()==h for p,h in man['input_hashes'].items()),'cli_cases':[],'compositions':[]}
 if not summary['input_hashes_unchanged']:issues.append('Frozen input bytes changed')
 for row in report['cases']:
  if row['exit_code']:issues.append(row['id']+': CLI failed')
  pack=read(root/row['id']/'pack.json')[0];hard=pack.get('visual_obligations',{}).get('obligations',[]);optional=pack.get('visual_concept_candidates',{}).get('candidates',[])
  summary['cli_cases'].append({'id':row['id'],'exit_code':row['exit_code'],'hard_profile_ids':[o['id']for o in hard],'liminal_optional_candidate_exposed':any(x['id']=='visual-concept:liminal_transition_use_gap'for x in optional),'optional_visual_candidate_ids':[x['id']for x in optional],'ordinary_candidate_count':len(row['slot_candidates']),'liminal_slot_candidates':[x for x in row['slot_candidates']if any(t in x['id']for t in ['liminal','between_use'])],'chosen_candidate_ids':[],'chosen_visual_concept_ids':[],'target_hard_gate_ids':[v['id']for o in hard if o['id']=='liminal_transition_use_gap'for v in o['render_gates']]})
  expected=['liminal_transition_use_gap']if row['id']in['old_and','source_or']else[]
  if row['obligation_ids']!=expected:issues.append(row['id']+': unexpected hard profiles')
  if any(x['id']=='visual-concept:liminal_transition_use_gap'for x in optional):issues.append(row['id']+': unexpected optional target exposure')
 for row in report['compositions']:
  wanted='expected_after'if arm.startswith('after')else'expected_before';t=next(x for x in read(P/'compositions.json')if x['id']==row['id'])
  own=row['direct_visual_failures'];other=[x for x in row['failures']if x not in own]
  summary['compositions'].append({'id':row['id'],'status':row['status'],'expected':t[wanted],'direct_visual_failures':own,'other_full_audit_failures':other})
  if row['status']!=t[wanted]:issues.append(row['id']+': unexpected full audit status')
  if other:issues.append(row['id']+': unrelated full-audit failure present')
 if len(report['cases'])!=len(man['case_ids']):issues.append('Incomplete CLI case set')
 if len(report['compositions'])!=len(read(P/'compositions.json')):issues.append('Incomplete composed set')
 summary['issues']=issues;summary['status']='pass'if not issues else'fail';dump(root/'summary.json',summary);return summary

if __name__=='__main__':
 arm=sys.argv[1];s=summarize(arm)
 if not arm.startswith('after'):print(json.dumps({'arm':arm,'status':s['status'],'issues':s['issues']},indent=2));raise SystemExit(bool(s['issues']))
 before=read(P/'before/summary.json');man=read(P/'manifest.json');issues=s['issues'][:];out={'arm':arm,'input_hashes_unchanged':s['input_hashes_unchanged'],'cases':[],'composition_changes':[],'pack_leaf_changes':{},'limitations':['Synthetic source-aware canonical metadata qualification, not clean pre-core authorship or natural-query recall.','Ordinary noncanonical maintained-cue paraphrase is deliberately still rejected.','No optional candidates were adopted. Eligibility, exposure and adoption remain separate.','No rendered images, provider calls, runtime changes, corpus edits or index writes by this harness.']}
 for id in man['case_ids']:
  b=read(P/'before'/id/'pack.json')[0];a=read(P/arm/id/'pack.json')[0]
  checks={k:b.get(k)==a.get(k)for k in ['slots','core_retrieval','authorial_core','embodiment_preflight','semantic_clarification','negative_en','negative_intent_guard','intent_preservation','creative_controls','visual_concept_candidates','candidate_bundles']}
  bo=b.get('visual_obligations',{}).get('obligations',[]);ao=a.get('visual_obligations',{}).get('obligations',[])
  checks['active_profile_ids']=[o['id']for o in bo]==[o['id']for o in ao]
  checks['five_groups_gates_binding_and_rejects']=[{k:o.get(k)for k in ['component_semantics','render_gates','reject_substitutes','prompt_binding','runtime_expression','composition_instruction','activation']}for o in bo]==[{k:o.get(k)for k in ['component_semantics','render_gates','reject_substitutes','prompt_binding','runtime_expression','composition_instruction','activation']}for o in ao]
  for k,v in checks.items():
   if not v:issues.append(id+': changed invariant '+k)
  out['cases'].append({'id':id,'preservation':checks});out['pack_leaf_changes'][id]=diff(b,a)
 for t in read(P/'compositions.json'):
  id=t['id'];b=read(P/'before/compositions'/id/'audit.json');a=read(P/arm/'compositions'/id/'audit.json');bc=read(P/'before/compositions'/id/'composed.json');ac=read(P/arm/'compositions'/id/'composed.json')
  unchanged=all(bc.get(k)==ac.get(k)for k in ['prompt_en','negative_en','visual_obligation_evidence','chosen_candidate_ids','chosen_visual_concept_ids','authorial_core_binding','semantic_clarification_decisions','creative_augmentation_brief'])
  row={'id':id,'before':b['status'],'after':a['status'],'expected_before':t['expected_before'],'expected_after':t['expected_after'],'before_failures':b['failures'],'after_failures':a['failures'],'prompt_evidence_selections_and_authorship_unchanged':unchanged};out['composition_changes'].append(row)
  if b['status']!=t['expected_before']or a['status']!=t['expected_after']:issues.append(id+': unexpected status')
  if not unchanged:issues.append(id+': changed composition')
 out['issues']=issues;out['status']='pass'if not issues else'fail';dump(P/'comparison.json',out);print(json.dumps({'arm':arm,'status':out['status'],'issues':issues,'cases':len(out['cases']),'compositions':len(out['composition_changes'])},indent=2))
 raise SystemExit(bool(issues))
