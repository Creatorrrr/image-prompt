#!/usr/bin/env python3
"""Source-aware synthetic canonical-metadata qualification with immutable offline CLI inputs."""
from pathlib import Path
import copy, hashlib, json, os, subprocess, sys, time, traceback
P=Path(__file__).resolve().parent
R=P.parent.parent/'image-prompt'
S=R/'skills/photo-prompt-image-generator/scripts'
A=R/'skills/photo-prompt-image-generator/assets'
sys.path.insert(0,str(S))
import prompt_generator as g
import audit_composed_prompt as audit
PID='liminal_transition_use_gap'
PIN='f4d3532dd295275f7d64d94d720e57ace509de36'
SEED=1807

def sha(b):return hashlib.sha256(b).hexdigest()
def read(p):return json.loads(p.read_text())
def dump(p,o):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(o,ensure_ascii=False,indent=2)+'\n')
def anchor(id,src,ev,dim,target=None,prop=None):
 o={'anchor_id':id,'source_text':src,'prompt_evidence':ev,'dimension':dim}
 if prop:o.update(target=target,property=prop)
 return o

def review(prompt,c,phase='agent_prepack'):
 if not c.get('people'):
  return {'contract_version':'photo-embodiment-review/v1','provenance':phase,'prompt_sha256':sha(prompt.encode()),'scope':'not_applicable','summary':'This architectural interior study depicts built surfaces and service fixtures without bodies, actors, limb mechanics, or bodily contact. Spatial lines and material cues remain readable.','checks':{}}
 phrases=['Each traveler has one distinct body','Their hands remain close to their own luggage handles','their feet resting on the level paving','The travelers stand in a loose queue with clear space between their bodies','A broad eye-level view separates the travelers from the counter edge']
 reasons=['The visible adults and their clothing each belong to a single distinct body.','Hands stay beside each traveler on nearby luggage handles, so reach does not cross bodies.','Each standing traveler is supported by both feet on level paving.','The queue leaves clearance between bodies, bags and the counter.','The eye-level view separates silhouettes and retains the visible queue and service boundary.']
 return {'contract_version':'photo-embodiment-review/v1','provenance':phase,'prompt_sha256':sha(prompt.encode()),'scope':'body_action','summary':'Ordinary adult travelers stand in a separated queue with local hand-to-luggage contact and floor support. This is a prose plausibility review, not a rendered-image result.','checks':{k:{'status':'supported','reason':r,'prompt_evidence':[e]}for k,r,e in zip(['body_ownership','joint_chain_and_reach','support_and_balance','contact_and_space','visibility_and_projection'],reasons,phrases)}}

def prepare():
 if (P/'manifest.json').exists() or (P/'drafts').exists():raise SystemExit('Refusing to overwrite preparation artifacts')
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==PIN
 cases=[]
 common_request='Photograph a liminal space in a maintained transit concourse while expected passenger use is paused. The clean concourse connects the ticket hall to boarding passages. {} The expected passengers and boarding activity are absent. A recently shifted service trolley leaves a faint dry track that suggests operation just before this moment. Repeated door bays lead toward an unresolved destination. Keep the scene unoccupied.'
 common_base='A maintained transit concourse forms a between-use liminal transition space. Expected passenger use is paused in the clean concourse connecting the ticket hall to boarding passages. {} The expected passengers and boarding activity are absent, leaving the boarding openings vacant. A faint dry trolley track suggests operation just before this moment. Repeated door bays lead toward an unresolved destination beyond a shallow turn. The scene remains unoccupied. A low oblique viewpoint follows the orderly floor joints and the changing size of the doorways, while balanced ceiling light preserves clean surfaces and distant depth.'
 for id,cues_request,cues_base in [('old_and','Working lights, benches, and route markers indicate normal service.','Working lights, benches, and route markers indicate normal service.'),('source_or','Working lights and painted directional signs indicate the ordinary transfer route.','Working lights and painted directional signs indicate the ordinary transfer route.')]:
  req=common_request.format(cues_request);base=common_base.format(cues_base)
  anchors=[anchor('concept','liminal space','between-use liminal transition space','concept'),anchor('subject','maintained transit concourse','A maintained transit concourse','subject'),anchor('event','expected passenger use is paused','Expected passenger use is paused','event'),anchor('transition','connects the ticket hall to boarding passages','connecting the ticket hall to boarding passages','setting','concourse','transition_function'),anchor('service_cues',cues_request,cues_base,'setting','concourse','maintained_cues'),anchor('absent_use','The expected passengers and boarding activity are absent','The expected passengers and boarding activity are absent','setting','concourse','expected_use_gap'),anchor('temporal_trace','A recently shifted service trolley leaves a faint dry track that suggests operation just before this moment','A faint dry trolley track suggests operation just before this moment','material','concourse','temporal_residue'),anchor('destination','Repeated door bays lead toward an unresolved destination','Repeated door bays lead toward an unresolved destination','setting','concourse','unresolved_route'),anchor('occupancy','Keep the scene unoccupied','The scene remains unoccupied','setting','concourse','occupancy')]
  cases.append(dict(id=id,request=req,baseline=base,anchors=anchors,subject='one maintained transit concourse',setting='a clean transit concourse linking ticket and boarding areas',event='expected passenger use is paused between service moments',profile=PID,people=False))
 controls=[
  ('ordinary_empty','Photograph an ordinary empty room used as a spare office. It is currently vacant, with a plain desk and a closed interior door.','An ordinary empty room serves as a spare office. It is currently vacant, with a plain desk and a closed interior door. A small ceiling panel spreads even light across pale walls and clean carpet. The desk sits flush against the far wall, with a chair tucked beneath its edge. A straightforward corner view shows the room as a complete, modest interior, with an ordinary settled arrangement and a clearly bounded end wall.','one ordinary empty spare office','a plain bounded spare office with desk and closed door','the spare office is currently vacant', 'ordinary empty room','An ordinary empty room','It is currently vacant','It is currently vacant','with a plain desk and a closed interior door','with a plain desk and a closed interior door',False),
  ('abandoned','Photograph an abandoned ruin of a station corridor. Broken lamps and peeling wall surfaces surround a passage filled with rubble.','An abandoned ruin of a station corridor stands beneath a fractured ceiling. Broken lamps and peeling wall surfaces surround a passage filled with rubble. Chunks of plaster lie across the former walking lane, and an old frame leans into the fallen masonry. A broad side opening lets cool daylight reveal the coarse debris and stripped wall layers. A still architectural view keeps the damaged surfaces and obstructed circulation plainly visible across the whole corridor.','one ruined station corridor','an abandoned station corridor with damaged masonry and rubble','broken lamps and peeling surfaces surround a rubble-filled passage','abandoned ruin','An abandoned ruin','Broken lamps and peeling wall surfaces surround a passage filled with rubble','Broken lamps and peeling wall surfaces surround a passage filled with rubble','Broken lamps and peeling wall surfaces','Broken lamps and peeling wall surfaces',False),
  ('closed','Photograph a permanently closed station ticket hall. Boards seal the service windows and dust covers the disconnected fixtures.','A permanently closed station ticket hall contains sealed counters and disconnected fixtures. Boards seal the service windows and dust covers the disconnected fixtures. The circulation ends at a locked partition across the center of the hall, while redundant signs lie stacked against a wall. Soft daylight from a high pane reveals thick dust over the unused counter. A frontal view describes the final closure through its blocked route, dormant equipment, and long-settled material surfaces.','one permanently closed station ticket hall','a shut ticket hall with boarded service windows','boards seal service windows and dust covers disconnected fixtures','permanently closed station ticket hall','A permanently closed station ticket hall','Boards seal the service windows','Boards seal the service windows','dust covers the disconnected fixtures','dust covers the disconnected fixtures',False),
  ('active_use','Photograph a busy transit station in active service. Adult travelers queue at the open ticket counter while illuminated route signs guide current departures.','A busy transit station operates in active service. Adult travelers queue at the open ticket counter while illuminated route signs guide current departures. Each traveler has one distinct body, with their feet resting on the level paving. Their hands remain close to their own luggage handles. The travelers stand in a loose queue with clear space between their bodies. A broad eye-level view separates the travelers from the counter edge and shows the functioning signs above the occupied hall. Balanced overhead light keeps the queue and current service activity clearly readable.','adult travelers and an operating transit ticket counter','a busy station hall with an open ticket counter','adult travelers queue at the open ticket counter during active service','busy transit station','A busy transit station','Adult travelers queue at the open ticket counter','Adult travelers queue at the open ticket counter','illuminated route signs guide current departures','illuminated route signs guide current departures',True)]
 for id,req,base,sub,setting,event,concept,ce,es,ee,ps,pe,people in controls:
  # All requester concept, subject and event anchors remain explicit. Specific scene properties use partial locks.
  se=('Adult travelers' if people else ce)
  ss=('Adult travelers' if people else concept)
  anchors=[anchor('concept',concept,ce,'concept'),anchor('subject',ss,se,'subject'),anchor('event',es,ee,'event'),anchor('property',ps,pe,'setting','interior','requested_condition')]
  # A separate concept and subject may share the same idea, but the wire contract requires distinct evidence.
  if not people:
   anchors[1]['prompt_evidence']={'ordinary_empty':'spare office','abandoned':'station corridor','closed':'station ticket hall'}[id]
   anchors[1]['source_text']=anchors[1]['prompt_evidence']
  cases.append(dict(id=id,request=req,baseline=base,anchors=anchors,subject=sub,setting=setting,event=event,profile=None,people=people))
 prior=read(P.parent/'architecture-visibility-audit/evidence-audit-probe.json');dump(P/'prior-isolated-evidence.json',prior)
 dump(P/'proposed-leaves.json',read(P.parent/'architecture-visibility-audit/exact-leaves.json'))
 comps=[]
 standard=copy.deepcopy(prior['cases'][0]['before']['composed']['visual_obligation_evidence'][PID])
 alternate=copy.deepcopy(prior['cases'][1]['before']['composed']['visual_obligation_evidence'][PID])
 for c in cases:
  d=P/'drafts'/c['id'];req=c['request'];base=c['baseline']
  env={'contract_version':'photo-request-envelope/v1','provenance':'requesting_user','request_id':'synthetic-liminal-data-'+c['id'],'request_text':req,'request_sha256':sha(req.encode()),'active_spans':[{'span_id':'scene','start':0,'end':len(req),'text':req}]}
  controls=g.creative_controls.resolve(req,overrides={'sensual':0,'fetish':0,'creativity':0,'surreal':0},context={'subject_category':'human' if c['people'] else 'nonhuman','no_people':not c['people']},seed=SEED)
  locked=['concept','subject','event'];opened=['setting','appearance','pose','body_geometry','material','framing','composition','lighting','camera','color','atmosphere','relationship']
  core={'contract_version':'photo-authorial-core/v3','provenance':'agent_prepack','source_request':req,'creative_controls_sha256':controls['canonical_sha256'],'interpreted_intent':'A source-aware synthetic architectural contract study of '+c['event']+'. Requester conditions remain fixed while photographic craft details remain authorial choices.','subject':c['subject'],'setting':c['setting'],'event':c['event'],'visual_priorities':[c['subject'],c['event'],'clear interior geometry and service state'],'baseline_prompt_en':base,'user_definitions':[],'interpretation_provenance':[{'term':'synthetic architectural request','source_text':req,'basis':'request_context','resolution':'Show '+c['event']+' within the requested interior.','sources':[]}],'unresolved_ambiguities':[],'user_exclusions':[],'runtime_forbidden_labels':[],'intent_lock':{'contract_version':'photo-intent-lock/v2','priority':'requesting_user','semantic_anchors':c['anchors'],'locked_dimensions':locked,'open_dimensions':opened},'semantic_assertions':[],'request_lineage':None,'style':{'domain':'general_photo','family':'context-led architectural photograph','evidence':['clear interior geometry','readable material surfaces']},'variation_key':'liminal-data-'+c['id']}
  for name,obj in [('envelope',env),('controls',controls),('core',core),('review',review(base,c)),('spec',c)]:dump(d/(name+'.json'),obj)
  bindings=standard if c['id']=='old_and' else alternate if c['id']=='source_or' else {}
  prompt=base+(' '+'. '.join(bindings.values())+'.' if bindings else '')
  comps.append({'id':c['id'],'case':c['id'],'prompt':prompt,'bindings':bindings,'expected_before':'fail' if c['id']=='source_or' else 'pass','expected_after':'pass','purpose':'complete valid canonical evidence' if bindings else 'ordinary near-negative routing and composition control'})
 source=next(c for c in cases if c['id']=='source_or')
 for row in prior['cases'][2:]:
  ev=row['before']['composed']['visual_obligation_evidence'][PID]
  comps.append({'id':'malformed_'+row['id'],'case':'source_or','prompt':source['baseline']+' '+'. '.join(ev.values())+'.','bindings':ev,'expected_before':'fail','expected_after':'fail','purpose':row['note'],'contradictory_content':row['id']in ['abandoned_missing_maintained_cues','closed_service_missing_maintained_cues']})
 # Missing the maintained group and an active-use replacement close the five-group and adjacent-use boundary.
 ev=copy.deepcopy(alternate);del ev['maintained_cues_phrase']
 comps.append({'id':'malformed_missing_maintained_cues_phrase','case':'source_or','prompt':source['baseline']+' '+'. '.join(ev.values())+'.','bindings':ev,'expected_before':'fail','expected_after':'fail','purpose':'Missing maintained group stays rejected'})
 ev=copy.deepcopy(alternate);ev['expected_use_gap_phrase']='Adult travelers fill the departure lanes while clerks serve the current queue and scheduled boarding proceeds normally'
 comps.append({'id':'malformed_active_use_replaces_gap','case':'source_or','prompt':source['baseline']+' '+'. '.join(ev.values())+'.','bindings':ev,'expected_before':'fail','expected_after':'fail','purpose':'Active functioning service cannot replace the required expected-use gap','contradictory_content':True})
 ev=copy.deepcopy(alternate);ev['maintained_cues_phrase']='Illuminated directional signs and working ceiling lamps along the clean concourse indicate the expected passenger transfer route'
 comps.append({'id':'natural_cue_paraphrase_limitation','case':'source_or','prompt':source['baseline']+' '+'. '.join(ev.values())+'.','bindings':ev,'expected_before':'fail','expected_after':'fail','purpose':'Ordinary noncanonical maintained-cue paraphrase remains outside this metadata correction'})
 dump(P/'compositions.draft.json',comps)
 print('Prepared',len(cases),'drafts and',len(comps),'composition templates')

def preflight():
 n=len(list((P/'preflight').glob('attempt-*')))+1;out=P/'preflight'/f'attempt-{n:02d}';out.mkdir(parents=True)
 rows=[]
 for d in sorted((P/'drafts').iterdir()):
  row={'id':d.name}
  for f in d.glob('*.json'):dump(out/d.name/f.name,read(f))
  try:
   envelope=g.load_request_envelope_arg(str(d/'envelope.json'));controls=read(d/'controls.json')
   core=g.load_authorial_core_arg(str(d/'core.json'),request_envelope=envelope,creative_control_snapshot=controls)
   policy=g.photo_embodiment.build_policy(core,read(d/'review.json'))
   row.update(status='pass',core_sha256=core['canonical_sha256'],lock_sha256=core['intent_lock']['canonical_sha256'],embodiment_contract=policy)
  except Exception as e:row.update(status='fail',error=str(e),traceback=traceback.format_exc())
  rows.append(row)
 dump(out/'report.json',rows);print(json.dumps([{'id':r['id'],'status':r['status'],'error':r.get('error')}for r in rows],indent=2))
 return rows

def freeze():
 if (P/'manifest.json').exists():raise SystemExit('Refusing to overwrite frozen inputs')
 rows=preflight();assert all(r['status']=='pass' for r in rows),'Preflight is not valid'
 for f in (P/'drafts').rglob('*.json'):dump(P/'inputs'/f.relative_to(P/'drafts'),read(f))
 dump(P/'compositions.json',read(P/'compositions.draft.json'))
 source_files=list(A.glob('*.json'))+list(S.glob('*.py'))
 man={'baseline_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'synthetic_canonical_source_metadata_qualification':True,'wire_provenance_note':'Production requesting_user and agent_prepack enums exercise the real CLI using explicitly synthetic fixtures. Source-aware authored fixtures are not a clean pre-core test or natural-query-gain experiment.','offline':True,'provider_calls':0,'case_ids':sorted(d.name for d in (P/'inputs').iterdir()),'source_files':{str(p.relative_to(R)):sha(p.read_bytes())for p in source_files},'input_hashes':{str(f.relative_to(P)):sha(f.read_bytes())for f in [*list((P/'inputs').rglob('*.json')),P/'compositions.json',P/'prior-isolated-evidence.json',P/'proposed-leaves.json']}}
 assert man['baseline_head']==PIN
 dump(P/'manifest.json',man);print('Frozen valid inputs:',len(man['case_ids']))

def run(arm):
 man=read(P/'manifest.json');assert all(sha((P/f).read_bytes())==h for f,h in man['input_hashes'].items()),'Frozen input drift'
 out=P/arm
 if out.exists():raise SystemExit('Refusing to overwrite prior run')
 out.mkdir();dump(out/'source-state.json',{'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'status':subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True),'files':{f:sha((R/f).read_bytes())for f in man['source_files']}})
 env={k:v for k,v in os.environ.items() if not any(t in k.upper() for t in ['API_KEY','TOKEN','SECRET','CREDENTIAL'])};env['PYTHONDONTWRITEBYTECODE']='1'
 report={'arm':arm,'cases':[],'compositions':[],'scope':'Actual public V6 CLI and full-composition audit with offline deterministic lexical retrieval. Canonical source metadata only.'};packs={}
 for id in man['case_ids']:
  d=P/'inputs'/id;dest=out/id;dest.mkdir();cmd=[str(R/'.venv/bin/python'),str(S/'generate_photo_prompt.py'),'--seed',str(SEED),'--request-envelope-json',str(d/'envelope.json'),'--authorial-core-json',str(d/'core.json'),'--creative-controls-json',str(d/'controls.json'),'--embodiment-review-json',str(d/'review.json'),'--output-file',str(dest/'pack.json')]
  t=time.time();p=subprocess.run(cmd,cwd=R,env=env,text=True,capture_output=True);dump(dest/'cli.json',{'command':cmd,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'seconds':time.time()-t});row={'id':id,'exit_code':p.returncode,'stderr':p.stderr}
  if p.returncode==0:
   pack=read(dest/'pack.json')[0];packs[id]=pack
   row.update(contract_version=pack['contract_version'],obligation_ids=[o['id']for o in pack.get('visual_obligations',{}).get('obligations',[])],visual_concept_ids=[v['id']for v in pack.get('visual_concept_candidates',{}).get('candidates',[])],slot_candidates=[{'slot':s,'id':v['id'],'applicability':v.get('applicability')}for s,b in pack['slots'].items() for v in b.get('candidates',[])],core_retrieval_sha256=pack['core_retrieval']['canonical_sha256'],core_sha256=pack['authorial_core']['canonical_sha256'])
  report['cases'].append(row);dump(out/'report.json',report);print(arm,id,p.returncode,row.get('obligation_ids'),flush=True)
 for template in read(P/'compositions.json'):
  id=template['id'];case=template['case']
  if case not in packs:continue
  pack=packs[case];core=pack['authorial_core'];lock=core['intent_lock'];c=read(P/'inputs'/case/'spec.json');prompt=template['prompt']
  composed={'core_retrieval_sha256':pack['core_retrieval']['canonical_sha256'],'pack_id':pack['pack_id'],'prompt_en':prompt,'negative_en':pack['negative_en'],'chosen_candidate_ids':[],'chosen_visual_concept_ids':[],'composer':'agent','candidate_interpretations':[],'authorial_core_binding':{'source_authorial_core_sha256':core['canonical_sha256'],'source_intent_lock_sha256':lock['canonical_sha256'],'preserved_anchor_ids':[a['anchor_id']for a in lock['semantic_anchors']],'preserved_evidence':[],'authorial_decisions':[]},'semantic_clarification_decisions':[{'clarification_id':r['id'],'decision':'applied' if r.get('required_in_final_prompt') else 'rejected','rationale':'Preserve frozen requested interior meaning and decline optional reinterpretation.','prompt_evidence':lock['semantic_anchors'][0]['prompt_evidence']}for r in pack.get('semantic_clarification',{}).get('candidates',[])],'creative_augmentation_brief':{'decisions':[{'candidate_id':r['id'],'decision':'rejected','rationale':'The complete architectural scene needs no optional augmentation.'}for r in pack.get('creative_augmentation',{}).get('candidates',[])]},'embodiment_review':{'source_contract_sha256':pack['embodiment_preflight']['canonical_sha256'],'review':review(prompt,c,'agent_postcomposition')}}
  if c['profile']:composed['visual_obligation_evidence']={c['profile']:template['bindings']}
  dest=out/'compositions'/id;dump(dest/'composed.json',composed)
  # Isolate evidence checks using the same real CLI pack and exact full composed input.
  direct=audit.audit_visual_obligations(pack,composed,prompt);dump(dest/'direct-visual-evidence.json',{'failures':direct,'status':'pass'if not direct else 'fail'})
  cmd=[str(R/'.venv/bin/python'),str(S/'audit_composed_prompt.py'),'--pack',str(out/case/'pack.json'),'--composed',str(dest/'composed.json')];p=subprocess.run(cmd,cwd=R,env=env,text=True,capture_output=True);dump(dest/'cli.json',{'command':cmd,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr})
  try:result=json.loads(p.stdout)
  except Exception:result={'status':'error','failures':[{'reason':p.stderr}]}
  dump(dest/'audit.json',result);report['compositions'].append({'id':id,'case':case,'status':result['status'],'expected':template['expected_after' if arm.startswith('after')else'expected_before'],'failures':result['failures'],'direct_visual_failures':direct,'warnings':result.get('warnings',[]),'chosen_candidate_ids':[],'chosen_visual_concept_ids':[],'semantic_claim_limit':'Deliberately contradictory invalid evidence is a parser boundary probe, not a coherent final scene'if template.get('contradictory_content')else'Canonical source-aware contract qualification'})
  dump(out/'report.json',report);print(id,result['status'],[(r.get('check'),r.get('field'))for r in result['failures']],flush=True)
 print('Completed',arm,flush=True)
if __name__=='__main__':
 action=sys.argv[1]
 if action=='prepare':prepare()
 elif action=='preflight':preflight()
 elif action=='freeze':freeze()
 else:run(action)
