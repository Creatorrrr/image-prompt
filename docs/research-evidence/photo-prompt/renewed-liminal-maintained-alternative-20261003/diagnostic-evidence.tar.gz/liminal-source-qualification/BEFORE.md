# Liminal maintained-cue source metadata qualification: BEFORE

Baseline: `f4d3532dd295275f7d64d94d720e57ace509de36`.

The six explicitly synthetic, source-aware request/core/control/review sets passed the production wire preflight twice before CLI execution. All initial preflight records are retained under `preflight/attempt-01` and `preflight/attempt-02`. There were zero input errors and zero revised fields. Frozen file SHA-256 values are in `manifest.json`; the real BEFORE source hashes match that manifest.

This is canonical source metadata qualification. The synthetic envelope's `requesting_user` and core's `agent_prepack` values are required production wire enums, not assertions that an actual user supplied these requests or that the scenes were independently authored before seeing source data. No clean pre-core process, natural-query gain, vector-query retrieval improvement, rendered fidelity, or preference uplift is claimed.

## BEFORE result

Six actual `generate_photo_prompt.py` V6 invocations succeeded. The normal full `audit_composed_prompt.py` CLI evaluated 17 frozen composition templates, and every outcome matches its declared expectation:

- Existing full maintained-cue AND anchor passes
- The exact existing source OR component literal fails only `visual_obligation_semantic_evidence` for `maintained_cues_phrase`
- Four separate ordinary empty-room, abandoned, closed-service, and busy active-use controls pass their own full compositions. None exposes the liminal hard profile or optional visual-profile candidate
- Ten malformed evidence/missing-group probes remain rejected. Missing each of the five fields is covered, along with abandoned/closed/generic/active-use replacements and missing activity alone
- One sensible natural maintained-cue paraphrase remains rejected. The proposed change does not make arbitrary furniture-free natural language acceptable

Direct `audit_visual_obligations` results use the very same actual CLI packs, composed objects, and prompt strings as the full audits. Every full failure equals those direct visual-evidence failures; no unrelated full-audit errors appeared. Contradictory malformed replacements deliberately probe field enforcement, not coherent scene authorship or automatic semantic comprehension.

## Eligibility, exposure, and adoption

The canonical registry already contains the OR phrase in its maintained-service component. The append would extend only the consumer's accepted evidence-anchor array; it does not change the definition, source retrieval text, activation, or five-part meaning.

Actual source-aware exact requests expose `liminal_transition_use_gap` as a hard request-scoped obligation in both positive CLI packs. Each also exposes eligible ordinary candidates `slot:composition:liminal_expected_route_depth_frame` and `slot:location:between_use_transit_interior`. The four ordinary controls expose neither of these slot candidates nor the liminal hard/optional profile.

Every composition chooses zero ordinary candidates and zero optional visual concepts. Thus source eligibility and actual candidate exposure do not imply semantic adoption. The hard liminal meaning originates from the exact synthetic request; it is realized through complete declared evidence, not promoted by rank or candidate selection. The only intended before/after acceptance change is the canonical OR evidence binding. Unrelated optional candidates are left unselected and create no duties.

## Ownership and invariants

Every frozen core includes distinct concept, subject, and event anchors and the three required whole-dimension locks. Requester-owned details such as transition function, maintained cues, missing use, temporal trace, unresolved destination and occupancy receive targeted property anchors. Camera position, lighting treatment, framing, and other agent-chosen craft details stay open. The inputs do not blanket-lock the scene's descriptive prose.

Both positive packs retain all five component groups and five hard render gates. `baseline-source-profile.json` preserves the complete source profile, production-materialized obligation, semantic text, and BM25F fields for the AFTER comparison. No corpus, runtime, test, registry, index, or remote files were changed by this qualification. No provider or image calls ran.

The exact same frozen input files and final prompt/evidence strings are ready for AFTER once the parent applies the reviewed leaf and completes its required index synchronization. `qualify.py after` refuses to overwrite an arm and rejects any frozen-input drift. `compare.py after` compares full pack leaf deltas, invariant surfaces, actual exposure, full/direct audit failures, and unchanged prompt/evidence/adoption bytes.

Artifacts: `before/summary.json`, `before/report.json`, all six `before/<case>/pack.json` and `cli.json` files, and each `before/compositions/<id>/{composed,audit,direct-visual-evidence,cli}.json`.
