# Liminal maintained-cue alternative: canonical DATA qualification

## Result

PASS for the exact one-list append. Twelve actual public V6 CLI runs succeeded: the same six frozen input sets before and after. All 34 full-composition audit outcomes match their predeclared expectations. Exactly one composition status changes: the complete existing source OR alternative goes from failed to passed.

- Existing AND anchor: pass → pass
- Existing source OR anchor: fail → pass
- Four separate ordinary-empty, abandoned, permanently closed and active-use scenes: pass → pass, with no liminal hard or optional profile exposure
- Ten malformed/missing-group evidence probes: fail → fail
- One sensible noncanonical natural-cue paraphrase: fail → fail

BEFORE has five accepted and twelve deliberately rejected compositions; AFTER has six accepted and eleven deliberately rejected compositions. Expected negative rejection is a successful boundary check, not a failed qualification. There are no unrelated full-audit errors in either arm.

## Scope and provenance

Baseline HEAD: `f4d3532dd295275f7d64d94d720e57ace509de36`.

Applied registry SHA-256: `81da5bb9491b99a6fef50b85b2ffbc106da65421cdaa8b7bceb9852c3c2ada4b`.

The parent applied the reviewed source leaf and synchronized the registry-bound index before authorizing AFTER. This harness did not edit repository source, corpus, tests, indexes, runtime, or remote state. No provider, image-generation, or external-agent calls were made. Source fingerprints show only the registry and its index differed among the tracked source assets/scripts used by the two arms.

This is explicitly source-aware, synthetic canonical metadata qualification. Production `requesting_user` and `agent_prepack` enums are necessary CLI wire values, not claims of actual user messages or independent pre-core authorship. No natural-query gain, vector-query improvement, rendered fidelity, aesthetic preference, or general scene comprehension is claimed.

## Frozen inputs and ownership

All six draft inputs passed production envelope/core/embodiment validation before CLI execution. A second preflight during freezing also passed all six. Both complete attempts are preserved, including original input values and production normalization hashes. There were zero wire errors, zero fixture revisions, and no rescue edits in either arm.

`manifest.json` freezes the exact envelopes, cores, control snapshots, reviews, scene specifications, composition templates, proposed leaf, and prior isolated evidence. Every hash still matches after the comparison. Final prompt strings, target binding strings, candidate choices, semantic decisions, and authorship bindings are unchanged between arms; only the positive packs' content-derived pack IDs change.

Every core explicitly locks requester concept, subject, and event with distinct literal evidence. Requested transition function, maintained cues, occupancy/use gap, temporal trace, unresolved destination, and occupancy conditions use targeted property anchors. Agent-chosen viewpoint, framing, light treatment and other photographic craft remain open. The qualification neither omits requester anchors nor blanket-locks authorial details.

## Exact consumer delta and invariants

Only this source and production-materialized obligation path changes:

`evidence_requirements.maintained_cues_phrase.must_mention_any`

The original literal remains byte-identical:

> working lights clean surfaces furniture and route markers imply normal service

The exact component literal already present in the canonical source is appended:

> working lights clean surfaces furniture signs or route markers imply normal use

`source-comparison.json` verifies unchanged definition, activation and exclusions, all five component groups, all five render gates, prompt-binding fields, reject boundaries, runtime expression, composition instruction, semantic text and BM25F fields. The natural phrase remains outside this narrow canonical-anchor acceptance change.

Across the six actual before/after packs:

- All four ordinary-control packs are fully identical
- Each positive pack differs only in `pack_id` and the one accepted-anchor array
- All frozen core and ownership data, ordinary retrieval inventory and hashes, candidates, creative controls, embodiment contracts, semantic clarification, negatives/negative guard, intent preservation and bundles are unchanged
- The same five hard gates remain attached to both positive requests, and none is introduced into an ordinary control

The complete leaf diff is in `comparison.json`, rather than a hand-selected invariant subset alone.

## Eligibility, exposure, and adoption

The registry already defined the OR-maintained-service phrase in its component semantics. This correction aligns the accepted evidence list with that source meaning; it does not add retrieval examples, exact aliases, candidate records, or a new interpretation.

Both positive exact requests expose `liminal_transition_use_gap` as a hard request-scoped obligation before and after. They also expose eligible ordinary candidates `slot:composition:liminal_expected_route_depth_frame` and `slot:location:between_use_transit_interior`. The four ordinary controls expose neither of those target slot candidates nor the target hard/optional profile. Exposure remains unchanged after the append.

Every composition chooses zero ordinary candidates and zero optional visual concepts. Thus eligible/exposed candidates are not automatically adopted and do not create duties. The hard five-part meaning is owned by the synthetic exact request, and full evidence is required independently of any candidate. No semantic adoption improvement is inferred from this metadata acceptance correction.

## Direct evidence and full-audit boundaries

Every composition also runs production `audit_visual_obligations` directly against its actual CLI pack and the exact same full composed object and prompt used by the full audit. Every full-audit failure is accounted for by those direct failures; `other_full_audit_failures` is empty in all 34 outcomes.

The valid source OR's original failure is exactly the maintained-cue declared-anchor error. AFTER removes that error and produces a full pass. The old AND stays fully accepted. Missing each of the five evidence groups is independently covered; missing-activity-only, abandoned/closed/generic cue replacements, and an active-service replacement for the expected-use gap remain rejected. Some negative failure arrays lose the now-valid maintained-cue error while retaining the intended missing/incorrect-group failure, so unchanged negative status does not mean byte-identical diagnostic arrays.

Malformed contradictory phrases intentionally test evidence-field enforcement under a hard contract. Their rejection does not establish that the audit can understand all scene contradictions. No pixel-level scene or gate assessment was attempted.

## Artifacts and reproduction

- `manifest.json`: baseline source and frozen input hashes
- `preflight/attempt-01`, `preflight/attempt-02`: every initial input and wire validation result; no revisions needed
- `inputs/`, `compositions.json`: exact shared inputs and final evidence templates
- `before/`, `after/`: all commands, stdout/stderr, complete packs, composed objects, full audits and direct visual audits
- `before/summary.json`, `after/summary.json`: exposure, decisions, expected results and isolated/unrelated error attribution
- `baseline-source-profile.json`, `after-source-profile.json`, `source-comparison.json`: complete source/consumer comparison
- `comparison.json`: every pack leaf delta, invariant checks, and all 17 paired outcomes
- `qualify.py`, `compare.py`: reproducible offline harness and comparison

From the repository, run `PYTHONDONTWRITEBYTECODE=1 .venv/bin/python ../daylong-progress-20261002/liminal-source-qualification/qualify.py after-replay`, then the same Python with `compare.py after-replay`. The runner refuses to overwrite any prior arm and rejects altered input bytes. A BEFORE replay needs the recorded baseline source/index; never mutate the active source merely to create a fresh BEFORE result.
