# Architecture / visibility source-consistency audit

## Result

Recommend one additive, source-aligned evidence-list leaf for review. KEEP 49 other inspected profiles; DEFER one ambiguous submerged-settlement scale conflict. No repository source edits, index rebuilds, paid/provider calls, runtime changes, remote operations, image generation, or visual-fidelity claims.

Original requested source pin: `b4acb4110ba00b6f6e8a40da238022dbbe7dad0a`.

The shared HEAD advanced during this audit to `f4d3532dd295275f7d64d94d720e57ace509de36`. `git diff --name-only` proved the intervening change contains only the two repair/precore KEEP documentation files listed in `verification-summary.json`; no source under audit changed. The original pin remains recorded. Source hashes and clean worktree state were verified before/after the final probe.

## Frozen minimal candidate: liminal maintained-cue alternatives

Profile: `liminal_transition_use_gap` in `skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations.json`.

Only proposed path: `evidence_requirements.maintained_cues_phrase.must_mention_any`.

Retain the existing anchor unchanged:

> working lights clean surfaces furniture and route markers imply normal service

Append the exact existing English component literal:

> working lights clean surfaces furniture signs or route markers imply normal use

The complete old/new array is frozen in `exact-leaves.json`. This is not a new synonym, query expansion, or change to profile activation. It prevents the required evidence from turning an authored choice of familiar service cues into an obligation to supply furniture **and** route markers together.

### Direct internal evidence and scope

- The definition requires that “route or service cues remain.” It does not define furniture as mandatory.
- The existing `familiar_maintained_service_cues` component contains the exact proposed alternative above.
- Gate `vo_imaginal_liminal_maintained_cues` requires “Working maintained cues make the expected ordinary use concrete.” It does not insist on furniture plus wayfinding together.
- The full `waiting_in_between_use_space` candidate says “signs doors lights or furnishings imply passage and destination.” It remains a narrower lone-subject waiting action when selected; no candidate source is changed.
- `liminal_expected_route_depth_frame` permits repeating “doors lights lanes or ceiling bays.” Its unresolved expected endpoint/active-use relation is retained.
- The local approved evidence record `imaginal_liminal_place_diel_lewis` says transitional function, expected-use markers, occupancy gap, and restrained deviation are independent visual dimensions. It explicitly warns that liminality need not be frightening, abandoned, nostalgic, or supernatural. This is supporting local provenance, not a newly fetched paper or an external validation of this implementation's full definition.

The counterexample is a maintained, clean transit concourse whose working lamps and painted directional signs establish ordinary expected passage, while the expected use is absent, a just-before/after trace remains, and depth runs toward an unresolved destination. Movable furniture need not be added merely to satisfy the current evidence conjunction. The correction does not remove the ordinary-use cues themselves or reduce the five-part relation to an empty room.

### Measured proof and controls

`probe.py` uses the real production loader, `candidate_pack_visual_profile_obligation`, and `audit_visual_obligations`. It changes a copied in-memory profile only. All 10 frozen isolated consumer outcomes match expectations:

1. Old all-cue AND-positive remains accepted unchanged
2. Exact source OR-alternative plus concrete lit-sign scene cue fails the old anchor test and passes the proposed one
3. Abandoned/damaged corridor lacking maintained service evidence still fails
4. Permanently closed/boarded service room with no maintained cue evidence still fails
5. Missing activity alone still fails the other four required fields
6–9. Omitting each other required group still fails after adding the alternative
10. Generic familiar-interior prose lacking a declared anchor still fails

`materialization-proof.json` shows only the accepted-anchor list changes. Definition, activation, all five groups, all five render gates, composition, evidence minima, strict binding, expression mode, and reject boundaries are unchanged. The production embedding-input text and BM25F fields are identical. A later accepted source edit would still require the normal registry-bound derived-index refresh; this audit neither writes the index nor claims that refresh has occurred.

The fixtures deliberately use source-declared evidence anchors. They are not independently authored user requests, normal public-CLI qualification, natural prose recall evidence, or rendered-image validation. Rejected negative cases test missing/incorrect evidence under an explicitly active contract. They do not demonstrate automatic scene comprehension. The new positive still contains the disjunctive source literal; furniture-free natural paraphrases are not claimed to work automatically. Existing conjunctions remain accepted because the change is append-only.

During diagnostic preparation, two bare existing evidence anchors were below their unchanged content-word minima. Concrete scene detail was added to those two fixture phrases before the final freeze. No source minimum or test outcome was relaxed. The final tests retain all required fields and pass independently of the proposed cue-list append where expected.

## KEEP decisions

### All 34 palace / fortification profiles

All 34 complete records were inspected. Their definitions expressly say “as a selected architectural variant,” and their exact activation phrases enumerate the same relations. For every authored component, match terms and evidence terms agree; instructions and render-gate descriptions preserve that same relation. Their 68 linked location/composition candidate records were checked across every field against their source structure, and all unique composition prose was reviewed. Complete records are saved, not just snippets.

Important non-defects:

- `pf_machicolation`: underside openings are the selected visible relation, and the composition explicitly chooses a low-oblique exterior view. Do not waive them merely because some other viewpoint would conceal them
- `pf_arrow_loop`: the selected profile deliberately joins the exterior slit to a wider interior recess and wall thickness; its candidate uses an interior-oblique view
- `pf_window_seat`: the profile intentionally requires a built-in seat within a deep masonry recess. It does not add a person
- `pf_portcullis` / `pf_drawbridge`: partly lowered grid and raised hinge bridge are selected states, not universal definitions of all gates/bridges
- `pf_enfilade`: the specific selected composition asks for at least three thresholds, while the profile explicitly says this is a test visibility condition rather than a historical minimum. Preserve candidate specificity
- `pf_double_helix`: hollow core and separate flights belong to the selected Chambord-related structural study; an exterior-only view is expressly rejected
- `pf_parterre_axis` preserves low planting **or** lawn borders; `pf_bosquet` preserves basin **or** sculpture across components and gates
- Roofless ruin, orangery, mirror gallery, gun battery, chapel, court, and garden-grotto requirements remain intentionally narrow configurations. No general castle/architecture rewrite is justified

### Architectural infrastructure and ordinary built-environment profiles

KEEP the six inspected `rb_` profiles. Recessed doorway/path/fixtures, flush drain/pipe/supports/clear passage, drain-to-stain ownership, paired near/far doorway scale, reflection-plus-transmission, and clean-room joints/materials are explicitly selected manifestations. Claims state that concrete objects are not defaults for broad realism. No person/contact requirement was added to these six object-environment contracts. Their optional bundles can be human-specific if selected; that does not broaden a profile's definition.

KEEP `opening_hybrid_veranda_architecture`: roof, veranda, central hall, motifs, connected building and oblique view repeat consistently. KEEP `opening_hanok_chair_contact`: seated-person/feet support is already in its definition and activation, not an accidental addition to an object-only chair concept.

KEEP the six emotional-place relations: window-seat, threshold, circulation, overlook, adaptive reuse, and hanok. Each explicitly defines action or daily-use relations in addition to place geometry. Broad place labels and object-only scenes must not be used to erase those intentionally authored action components. KEEP `fantasy_portal_two_world_threshold`: crossing subject **or object**, near/far spaces and local consequence alternatives survive composition/evidence/gates; no human-only addition was found.

## DEFER: submerged-settlement survey-scale conflict

`submerged_settlement_in_situ_structure` has uneven scale wording:

- Component: “an adult diver ROV scale marker or survey light makes the settlement dimensions legible”
- Evidence: “an adult diver ROV or scale marker makes settlement dimensions legible”
- Gate: “A diver ROV or survey marker establishes architectural scale”
- Definition and composition: diver or ROV scale

However, the full original extension's semantic group is **human or ROV scale evidence**, and `diver_records_fixed_structure_action` describes an adult diver or ROV using light/camera/scale markers. Its composition candidate also requires diver or ROV scale. Thus, the permissive marker wording does not establish an intentionally independent marker-only alternative. The provenance requires survey/site evidence but does not settle this distinction. No definition/composition broadening is frozen, and no physics of uncalibrated survey lights is invented. Preserve the source until scope is resolved.

## Files / reproduction

- `inspected-ids.json`: 51 profile IDs, 126 candidate records, linked semantics
- `source-provenance.json`: full relevant records, selectors, source hashes, local evidence, 68 complete palace-candidate field checks
- `decisions.json`: per-profile KEEP / proposed / DEFER classification and exact evidence
- `exact-leaves.json`: one additive proposed evidence-array leaf
- `materialization-proof.json`: real consumer before/proposed contracts, preserved-field assertions
- `evidence-audit-probe.json`: exact prompts, evidence, expected outcomes and actual failures for all 10 isolated cases
- `verification-summary.json`: original/current pins, docs-only rebind, unchanged-source proof
- `frozen-manifest.json`: audit-file hashes after final preparation

Reproduce with `PYTHONDONTWRITEBYTECODE=1 python daylong-progress-20261002/architecture-visibility-audit/probe.py` from the parent workspace. No full regression or provider calls are needed to reproduce this read-only isolated proof. Normal public-CLI qualification and independent review remain prerequisites before any acceptance decision.
