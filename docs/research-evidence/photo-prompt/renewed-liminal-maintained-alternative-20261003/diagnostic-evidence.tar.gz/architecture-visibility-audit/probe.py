"""Read-only source-consistency audit and frozen in-memory evidence proposal.
No embeddings, provider clients, runtime mutations, remote operations or source edits.
"""
import copy, hashlib, json, subprocess, sys
from pathlib import Path
ROOT=Path('REPOSITORY_ROOT')
OUT=Path(__file__).parent
ASSETS=ROOT/'skills/photo-prompt-image-generator/assets'
EXPECTED_HEAD='b4acb4110ba00b6f6e8a40da238022dbbe7dad0a'
def write(name,value):
 (OUT/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
head=subprocess.check_output(['git','-C',str(ROOT),'rev-parse','HEAD'],text=True).strip()
intervening_files=subprocess.check_output(['git','-C',str(ROOT),'diff','--name-only',EXPECTED_HEAD,head],text=True).splitlines()
assert all(x.startswith('docs/research-evidence/photo-prompt/renewed-repair-precore-keep-20261003/') for x in intervening_files),(head,intervening_files)
start_status=subprocess.check_output(['git','-C',str(ROOT),'status','--porcelain'],text=True)
main_ids=['fantasy_portal_two_world_threshold','liminal_transition_use_gap','submerged_settlement_in_situ_structure','window_seat_daylight_activity_relation','architectural_threshold_frame_depth_relation','circulation_path_mid_action_depth_relation','overlook_edge_foreground_vista_relation','adaptive_reuse_old_new_material_junction','hanok_madang_maru_inside_outside_relation']
rb_ids=['rb_architecture_connectivity','rb_infrastructure_attachment','rb_glass_reflection_transmission','rb_scale_perspective','rb_clean_space_plausibility','rb_water_path_stain']
opening_ids=['opening_hybrid_veranda_architecture','opening_hanok_chair_contact']
selections={
 'photo_prompt_visual_obligations.json':main_ids,
 'photo_prompt_visual_obligations_palace_fortification.json':None,
 'photo_prompt_visual_obligations_realistic_background.json':rb_ids,
 'photo_prompt_visual_obligations_opening_era.json':opening_ids,
}
profiles=[]; hashes={}; source_files=set()
for filename, ids in selections.items():
 f=ASSETS/filename;d=json.loads(f.read_text());hashes[str(f.relative_to(ROOT))]=sha(f);source_files.add(f)
 for i,p in enumerate(d['profiles']):
  if ids is None or p['id'] in ids:profiles.append({'file':str(f.relative_to(ROOT)),'json_pointer':f'/profiles/{i}','record':p})
pids={x['record']['id'] for x in profiles}
assert len(pids)==51,len(pids)
# Inspect all directly linked visual-semantic and candidate records, retaining every field.
source_payloads=[]
for f in sorted(ASSETS.glob('photo_prompt*_extension.json'))+[ASSETS/'photo_prompt_tags.json']:
 d=json.loads(f.read_text());source_payloads.append((f,d))
semantics=[];candidate_ids=set();
for f,d in source_payloads:
 for i,v in enumerate(d.get('visual_semantics',[])):
  if v.get('id') in pids or set(v.get('hard_profile_ids',[])) & pids:
   semantics.append({'file':str(f.relative_to(ROOT)),'json_pointer':f'/visual_semantics/{i}','record':v})
   candidate_ids.update(v.get('candidate_ids',[]));source_files.add(f)
candidate_ids.update(['waiting_in_between_use_space','between_use_transit_interior','liminal_expected_route_depth_frame','between_use_liminal_suspension'])
candidate_ids.update(pid+'_candidate' for pid in rb_ids)
candidates=[]
for f,d in source_payloads:
 for slot,cs in d.get('slots',{}).items():
  if not isinstance(cs,list):continue
  for i,c in enumerate(cs):
   if c.get('id') in candidate_ids or set(c.get('tags',[])) & pids:
    candidates.append({'file':str(f.relative_to(ROOT)),'json_pointer':f'/slots/{slot}/{i}','slot':slot,'record':c});source_files.add(f)
for f in source_files:hashes[str(f.relative_to(ROOT))]=sha(f)
# Palace candidate records use exact templates. Verify EVERY field, not only EN prose.
pf={x['record']['id']:x['record'] for x in profiles if x['record']['id'].startswith('pf_')}
pfchecks=[]
for c0 in candidates:
 c=c0['record'];slot=c0['slot']
 if c0['file'].endswith('photo_prompt_palace_fortification_extension.json'):
  pid=c['id'].removesuffix('_'+slot);p=pf[pid];title=p['concept_candidate']['concept_terms'][0]
  expected={'id':c['id'],'ko':title+(' 공간 관계' if slot=='location' else ' 관찰 구도'),'en':c['en'],'aliases':p['semantics']['paraphrase_examples'][1:] if slot=='location' else [],'concept_units':[c['en']],'affected_dimensions':['setting' if slot=='location' else 'composition'],'weight':.55,'tags':['palace_fortification_visual_semantics',slot],'keywords':[title]+p['semantics']['paraphrase_examples'][1:]+[c['en']],'embedding_text':title+': '+c['en']}
  assert c==expected,c['id']
  if slot=='location':assert c['en']==p['semantics']['paraphrase_examples'][0]
  pfchecks.append({'id':c['id'],'all_fields_equal_to_inspected_template':True,'unique_prose':c['en']})
assert len(pfchecks)==68
# Preserve exact local provenance rows; no primary web page was independently re-fetched.
evidence=[]
for rel in ['docs/research-evidence/photo-prompt/legend-visual-semantics-20260901/evidence.jsonl','docs/research-evidence/photo-prompt/imaginal-visual-semantics-20260901/evidence.jsonl']:
 f=ROOT/rel;hashes[rel]=sha(f)
 for i,line in enumerate(f.read_text().splitlines(),1):
  row=json.loads(line)
  if row.get('topic_id')=='liminal_transition_use_gap' or any(x in row.get('affected_contract_ids',[]) for x in ['visual_obligation:liminal_transition_use_gap','visual_obligation:submerged_settlement_in_situ_structure']):
   evidence.append({'file':rel,'line':i,'record':row})
for rel in ['skills/photo-prompt-image-generator/scripts/prompt_generator.py','skills/photo-prompt-image-generator/scripts/visual_profile_contracts.py','skills/photo-prompt-image-generator/scripts/audit_composed_prompt.py','skills/photo-prompt-image-generator/references/maintenance.md','docs/research-evidence/photo-prompt/palace-fortification-20260909/profile-matrix.md','docs/research-evidence/photo-prompt/legend-visual-semantics-20260901/source-research.md','docs/research-evidence/photo-prompt/imaginal-visual-semantics-20260901/source-research.md']:
 hashes[rel]=sha(ROOT/rel)
write('source-provenance.json',{'baseline_head':head,'source_hashes':hashes,'profiles':profiles,'visual_semantics':semantics,'candidates':candidates,'local_research_evidence':evidence,'palace_candidate_complete_field_checks':pfchecks,'scope_notes':['Complete 51 profile records inspected','Complete 68 palace candidate records structurally checked, with every unique composition reviewed','Directly linked candidate source records retained without field omission','Primary public sources were not re-fetched; findings concern authored source consistency only']})
write('inspected-ids.json',{'profiles':sorted(pids),'candidates':[{'id':x['record']['id'],'slot':x['slot'],'file':x['file']} for x in candidates],'visual_semantics':[x['record']['id'] for x in semantics]})
# Freeze one additive evidence-anchor proposal, retaining the old conjunction.
pid='liminal_transition_use_gap';field='maintained_cues_phrase'
raw=next(x['record'] for x in profiles if x['record']['id']==pid)
source_alternative=next(g for g in raw['semantics']['component_semantics']['groups'] if g['id']=='familiar_maintained_service_cues')['any_terms'][0]
old=raw['evidence_requirements'][field]['must_mention_any']
assert old==['working lights clean surfaces furniture and route markers imply normal service']
assert source_alternative=='working lights clean surfaces furniture signs or route markers imply normal use'
new=old+[source_alternative]
leaf={'file':'skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations.json','profile_id':pid,'path':['evidence_requirements',field,'must_mention_any'],'before':old,'proposed':new,'operation':'append one existing component literal, preserving current accepted anchor','intent':'Do not require furniture and route markers together when the maintained-cue source declares alternatives. All five liminal component groups and gates remain mandatory.'}
write('exact-leaves.json',[leaf])
sys.path.insert(0,str(ROOT/'skills/photo-prompt-image-generator/scripts'))
import prompt_generator as pg
import audit_composed_prompt as acp
reg=pg.load_visual_obligation_registry(ASSETS/'photo_prompt_visual_obligations.json')
loaded=next(p for p in reg['profiles'] if p['id']==pid)
assert loaded==raw
proposal=copy.deepcopy(loaded);proposal['evidence_requirements'][field]['must_mention_any']=new
before=pg.candidate_pack_visual_profile_obligation(loaded,reg,activation_source='audit',source_intent_ids=[])
after=pg.candidate_pack_visual_profile_obligation(proposal,reg,activation_source='audit',source_intent_ids=[])
expected=copy.deepcopy(before);expected['evidence_requirements'][field]['must_mention_any']=new
assert after==expected
assert loaded['activation']==proposal['activation']
assert loaded['semantics']==proposal['semantics']
assert before['prompt_binding']==after['prompt_binding']
assert before['render_gates']==after['render_gates']
assert before['component_semantics']==after['component_semantics']
assert len(before['component_semantics']['required_group_ids'])==5
assert len(before['render_gates'])==5
assert pg.visual_profile_semantic_text(loaded)==pg.visual_profile_semantic_text(proposal)
assert pg.visual_profile_bm25f_fields(loaded)==pg.visual_profile_bm25f_fields(proposal)
write('materialization-proof.json',{'baseline_head':head,'before':before,'proposed':after,'only_materialized_delta':leaf['path'],'all_other_obligation_fields_identical':True,'all_definition_activation_and_candidate_sources_unchanged':True,'five_component_groups_and_gates_preserved':True,'embedding_input_text_identical':True,'bm25f_fields_identical':True})

def pack(ob):return {'visual_obligations':{'enabled':True,'contract_version':'photo-visual-obligations/v1','strict_gate_set':True,'obligations':[ob],'required_hard_gates':[g['id'] for g in ob['render_gates']]}}
def default_ev():
 ev={f:r['must_mention_any'][0] for f,r in before['evidence_requirements'].items()}
 ev['transition_function_phrase']+='; adjoining doorways link the ticket hall to boarding platforms'
 ev['expected_use_gap_phrase']+='; vacant boarding bays contrast with illuminated departure signage'
 return ev
def check(ev,ob):
 prompt='between-use liminal transition space. '+'; '.join(ev.values())+'.'
 composed={'prompt_en':prompt,'visual_obligation_evidence':{pid:ev}}
 return {'prompt_en':prompt,'composed':composed,'failures':acp.audit_visual_obligations(pack(ob),composed,prompt)}
cases=[]
def add(id,ev,expected_pass_before,expected_pass_after,note):
 b=check(ev,before);a=check(ev,after)
 assert (not b['failures'])==expected_pass_before,(id,'before',b['failures'])
 assert (not a['failures'])==expected_pass_after,(id,'after',a['failures'])
 cases.append({'id':id,'note':note,'expected_pass_before':expected_pass_before,'expected_pass_after':expected_pass_after,'before':b,'proposed':a})
add('old_all_cues_positive',default_ev(),True,True,'Existing full AND literal remains accepted byte-for-byte; all five evidence fields retained.')
e=default_ev();e[field]=source_alternative+'; here lit directional signs along the clean concourse support expected passenger use'
add('source_alternative_positive',e,False,True,'Exact source OR literal plus a concrete maintained lit-sign cue; no claim that a natural furniture-free paraphrase alone passes.')
e=default_ev();e[field]='A deserted corridor contains broken lamps peeling paint scattered fragments and exposed damaged wall surfaces'
add('abandoned_missing_maintained_cues',e,False,False,'An abandoned damaged corridor cannot replace maintained service cues.')
e=default_ev();e[field]='A permanently closed boarded service room contains dusty empty shelves with blocked interior circulation'
add('closed_service_missing_maintained_cues',e,False,False,'Closure alone supplies neither maintained ordinary-use cues nor a complete liminal relation.')
e={'expected_use_gap_phrase':default_ev()['expected_use_gap_phrase']}
add('missing_activity_alone',e,False,False,'Missing activity alone omits transition function, maintained cues, temporal residue and unresolved route.')
for f in ['transition_function_phrase','expected_use_gap_phrase','temporal_residue_phrase','unresolved_route_phrase']:
 e=default_ev();e[field]=source_alternative;del e[f]
 add('missing_'+f,e,False,False,'Adding the cue alternative cannot erase another one of the five required evidence fields.')
e=default_ev();e[field]='The interior looks convincingly ordinary with several familiar practical objects visible near the corridor'
add('generic_cue_without_source_anchor',e,False,False,'Unanchored generic prose is not newly accepted; natural-language matching is not broadened.')
write('evidence-audit-probe.json',{'method':'production audit_visual_obligations against production-materialized isolated contract','not_claimed':['normal public CLI end-to-end qualification','natural prose recall improvement','independent scene authorship','rendered-image fidelity or aesthetic quality'],'cases':cases})
end_status=subprocess.check_output(['git','-C',str(ROOT),'status','--porcelain'],text=True)
assert end_status==start_status
for rel,digest in hashes.items():assert sha(ROOT/rel)==digest,rel
write('verification-summary.json',{'head':head,'profile_count':len(pids),'candidate_count':len(candidates),'visual_semantics_count':len(semantics),'palace_complete_field_checks':len(pfchecks),'isolated_evidence_cases':len(cases),'expected_outcomes_verified':True,'repository_status_before':start_status,'repository_status_after':end_status,'source_hashes_unchanged':True,'original_requested_baseline':EXPECTED_HEAD,'intervening_docs_only_files':intervening_files,'network_or_provider_calls':0,'source_edits':0})
print(json.dumps({'profiles':len(pids),'candidates':len(candidates),'evidence_cases':len(cases),'proposal':'one appended source evidence alternative','status':'PASS; repository source hashes unchanged'}))
