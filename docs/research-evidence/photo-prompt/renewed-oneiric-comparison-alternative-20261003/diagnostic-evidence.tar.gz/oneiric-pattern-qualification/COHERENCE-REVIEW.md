# Source-guided fixture coherence

The source-inspired impossible scene has exactly one architectural doorway seam. Near-side room remains upright; far-side room is rotated ninety degrees. An adult stands wholly supported on the near floor, with only the naturally extended forearm crossing the doorway plane. Body joints remain normal; the requested anomaly belongs to the architecture. Each scene includes light boundary, perspective change, frame contact and shadow cues. All existing conjunctions remain.

Separate pattern and threshold positives name comparison ownership explicitly; they do not assert there are no objects elsewhere. Painted chevron stripe and distinctive stepped threshold appear across the same seam. Legacy comparison is the repeated red-banded brass lamp. The same continuous adult is independent of the comparison reference.

An ordinary lighting control has aligned upright rooms with different light colors, no actual spatial violation and no target activation request. Five omitted-binding probes, a lighting-only wrong-discontinuity binding, an unrelated-pattern binding and a uniform-warp binding are deliberate diagnostics against the complete legacy scene, not organic negative scenes.

All prompts contain enough same-duty content and safe runtime label before freeze. Initial preflight rejected a blanket negative anatomy clause; the draft was rewritten as positive normal joint geometry before any retrieval. Original preflight failure is retained. No fixture changes after freeze are planned.

This is openly source-guided synthetic textual qualification, not clean pre-core sampling, actual user-request history, pixel success, geometric simulation or retrieval-quality evidence. Every optional slot/concept is rejected.
