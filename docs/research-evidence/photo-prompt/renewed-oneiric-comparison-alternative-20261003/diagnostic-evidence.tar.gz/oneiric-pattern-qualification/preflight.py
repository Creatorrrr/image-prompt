from fixture_common import *
import prompt_generator as g
rows=[]
for d in sorted((P/'inputs').iterdir()):
 row=dict(id=d.name)
 try:
  env=g.load_request_envelope_arg(str(d/'envelope.json'));ctl=D(d/'controls.json');core=g.load_authorial_core_arg(str(d/'core.json'),request_envelope=env,creative_control_snapshot=ctl);g.photo_embodiment.build_policy(core,D(d/'review.json'))
  cmd=[str(R/'.venv/bin/python'),str(S/'validate_precore_feature_selection.py'),'--catalog',str(PRE/'visual_feature_catalog.json'),'--request-envelope',str(d/'envelope.json'),'--authorial-core',str(d/'core.json'),'--embodiment-review',str(d/'review.json'),'--selection',str(d/'feature-selection.json')]
  run=subprocess.run(cmd,cwd=R,capture_output=True,text=True);row.update(command=cmd,exit_code=run.returncode,stdout=run.stdout,stderr=run.stderr);assert run.returncode==0
  row['status']='pass'
 except Exception as e:row.update(status='fail',error=str(e))
 rows.append(row)
W(P/'preflight.json',rows);print(json.dumps(rows,indent=2));assert all(x['status']=='pass'for x in rows)
# Check content minima separately before freezing; intended branch-anchor failures are preserved.
p=D(P/'before-profile.json');check=[]
for c in D(P/'compositions.json'):
 if c['kind']!='positive':continue
 for field,phrase in c['bindings'].items():
  try:g.validate_visual_intent_binding(obligation_index=0,field=field,phrase=phrase,requirement=p['evidence_requirements'][field]);result='pass'
  except ValueError as e:result=str(e)
  check.append(dict(id=c['id'],field=field,result=result))
W(P/'binding-preflight.json',check)
assert all(x['result']=='pass' or(x['id']in ['pattern_en','threshold_en']and x['field']==FIELD and 'must contain one profile component anchor'in x['result'])for x in check)
