# Oneiric pattern/threshold recovery qualified on current a1dc baseline

The reviewed two-leaf source recovery passes bounded qualification against current a1dc739da4e40bdc474a934fc90ba8ccfe23d1a8 BEFORE. Original120 qualification and the separate upstream-drift replay remain preserved; no frozen request, V3 core, controls, embodiment review or composition changed.

## Paired outcomes

Four AFTER normal V6 CLI packs and twelve complete composition audits:
- Repeated painted architectural pattern: fail→pass
- Repeated distinctive stepped threshold: fail→pass
- Legacy repeated red-banded lamp: pass→pass, target active
- Mundane upright rooms differing only in lighting: pass→pass, target absent
- Five omitted-duty and three wrong-binding controls: fail→fail

Negative checks, fields and reasons are identical. The unrelated-pattern failure's accepted_anchors diagnostic properly includes the appended valid source branch; that expected diagnostic-content difference is retained in AFTER-CURRENT-SUMMARY.json. Unrelated patterns, lighting-only change, uniform warp and any omitted duty still fail.

## Complete pack/order delta

All four packs were compared field-by-field against current BEFORE, not against the old120 corpus. comparison-after-a1dc/ includes complete leaf diffs, all-list order differences and identity-aligned candidate comparison.

Each of the three target-active packs differs at exactly three leaves: pack_id, appended comparison evidence anchor, and reviewed repeated-comparison render-gate description. The ordinary lighting control pack has no structural difference. Authorial cores, embodiment, core retrieval, all slot candidates and their order, all visual concepts and their order, and semantic clarifications are unchanged.

The earlier120→a1dc optional gaze replacement remains documented in CURRENT-BEFORE-REPORT.md; it does not recur in this current BEFORE→AFTER comparison and is not attributed to this correction.

## Source/index integrity

Parent's integration verification confirms only the reviewed evidence append and gate description changed. All 1,564 profile entries, vectors/texts, BM25F and exact lookup remain identical; only the index registry fingerprint was reconciled. Zero provider calls.

Compared with current BEFORE, only photo_prompt_visual_obligations.json and photo_prompt_visual_profile_index.json changed among source assets/scripts. Runtime is unchanged relative to a1dc BEFORE. Runtime/corpus are not unchanged relative to the original120 baseline; that upstream change is explicitly preserved separately.

All source assets/scripts, including newly introduced upstream files, were stable during AFTER. Frozen input hashes match. No source edits were made by this worker.

## Scope

This recovers a source-supported comparison-pattern/threshold branch while preserving the legacy object and all five duties. The separate light/perspective/contact/shadow conjunction is unchanged. The comparison remains same-identity across the one seam, independent of the continuous reaching adult; the fix does not mean there are no physical objects in the picture.

These are openly source-guided synthetic text-contract results. No organic-query/clean-precore/retrieval-quality claim, no pixel proof of impossible-space geometry or reference identity, no aesthetic judgment. The gate leaf is inspected through actual materialization and source review, not an image. No images or providers.

Key artifacts: AFTER-CURRENT-SUMMARY.json, after-a1dc/report.json, comparison-after-a1dc/, AFTER-AUTHORIZED.json, after-all-source-start/end.json, and after-current-artifact-manifest.json.
