# Oneiric current-baseline BEFORE at a1dc739d

The original clean-120f07d0 qualification is preserved unchanged. This separate replay uses the identical four frozen requests/cores/controls/embodiment reviews and twelve compositions on clean a1dc739da4e40bdc474a934fc90ba8ccfe23d1a8, after parent-verified upstream loader/index integrity.

Upstream added religion/iconography data: 1,564 visual profiles and 9,819 general entries per the parent's readiness check. Runtime is not unchanged across baselines: prompt_generator.py adds the visual-profile and research-extension filenames. The exact runtime diff is retained in upstream-runtime-a1dc.diff. The oneiric target profile still equals the original frozen BEFORE profile.

## Results

Four normal V6 generations and twelve full composed-prompt CLI audits completed. Every audit status, target-contract status and failure object exactly matches the original baseline:
- Pattern and threshold positives fail solely comparison_anchor_phrase
- Legacy repeated object passes active target
- Ordinary lighting-only scene passes with no target
- Five omitted-duty and three wrong-binding controls fail

No provider calls or images. Every frozen input hash remains unchanged. Source assets and scripts, including new upstream files, were stable during this replay. Current source hashes and upstream changes are retained separately; this is not a claim that current and original source states match.

## All-pack comparison

comparison-a1dc/ preserves full leaf diffs, all-list order diffs and identity-aligned candidate comparisons for all four packs.

All packs have upstream slot-corpus and slot-ownership fingerprints, their resulting core-retrieval canonical hash, tags hash and pack ID changed. Authorial cores, embodiment, target obligations, visual-concept candidates and clarification content/order remain identical.

Only pattern_en changes an optional slot offer: slot:gaze_engagement:pc_pc04_component_3 (camera-holder-directed glance/gesture) is replaced by slot:gaze_engagement:pv_side_eye (pupils lateral to head orientation, without inferred emotional attitude), with corresponding eligible-pool hash. The other three packs keep slot candidate order. Both gaze offers are optional and were rejected; the frozen request specifies the architectural comparison and ordinary reach, not either gaze relationship. The change is upstream-corpus drift, not an effect of the unapplied oneiric correction, and not a claimed retrieval improvement.

## Handoff

Use this current BEFORE as the comparison arm if the independently reviewed exact two-leaf source correction is applied now. Preserve original120 results as historical qualification, preserve this upstream-drift account, and rerun the same frozen inputs/compositions AFTER. No source changes were made by this worker.

CURRENT-BEFORE-SUMMARY.json contains asserted integrity/results. This remains source-guided synthetic text qualification, not organic/clean-precore retrieval evaluation or pixel/aesthetic evidence.
