"""Planned post-integration regression; not run against BEFORE source."""
import sys,unittest
from pathlib import Path
R=Path(__file__).resolve().parents[1];S=R/'skills/photo-prompt-image-generator/scripts';sys.path.insert(0,str(S));import prompt_generator as g
PID='oneiric_dream_logic_discontinuity';FIELD='comparison_anchor_phrase';NEW='the same distinctive object pattern or threshold appears on both sides';OLD='the same distinctive object appears clearly on both sides of the seam'
class OneiricPatternAlternativeTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.registry=g.load_visual_obligation_registry(S.parent/'assets/photo_prompt_visual_obligations.json');cls.profile=next(x for x in cls.registry['profiles']if x['id']==PID)
 def test_legacy_and_existing_source_branch_validate(self):
  for phrase in [OLD,NEW]:g.validate_visual_intent_binding(obligation_index=0,field=FIELD,phrase=phrase+' with the same comparison identity legible across the join',requirement=self.profile['evidence_requirements'][FIELD])
 def test_unrelated_patterns_rejected(self):
  with self.assertRaises(ValueError):g.validate_visual_intent_binding(obligation_index=0,field=FIELD,phrase='Unrelated decorative patterns occupy separate room regions without any same identity comparison across the doorway',requirement=self.profile['evidence_requirements'][FIELD])
 def test_all_five_component_groups_required_for_component_fixture(self):
  groups=self.profile['semantics']['component_semantics']['groups'];self.assertEqual(len(groups),5);self.assertEqual(self.profile['semantics']['component_semantics']['minimum_component_groups'],5)
  complete=' '.join(x['any_terms'][0]for x in groups);self.assertEqual(g.candidate_pack_visual_component_match(self.profile,complete),'component_semantics')
  for group in groups:self.assertIsNone(g.candidate_pack_visual_component_match(self.profile,' '.join(x['any_terms'][0]for x in groups if x['id']!=group['id'])))
 def test_legacy_minima_seam_physics_and_gate_preserved(self):
  ev=self.profile['evidence_requirements'];self.assertEqual(ev[FIELD]['min_content_words'],9);self.assertIn(OLD,ev[FIELD]['must_mention_any']);self.assertEqual(ev['seam_physics_phrase']['must_mention_any'],['light perspective contact and shadow localize the change to that single seam'])
  mat=g.candidate_pack_visual_profile_obligation(self.profile,self.registry,activation_source='regression',source_intent_ids=[]);gate=next(x for x in mat['render_gates']if x['id']=='vo_imaginal_dream_repeated_anchor');self.assertEqual(gate['description'],'One distinctive comparison object, pattern, or threshold appears clearly across both sides of the seam.')
if __name__=='__main__':unittest.main()
