from fixture_common import *
r=D(P/'after-a1dc/report.json');assert r.get('finished_at_utc');rows={x['id']:x for x in r['compositions']};assert len(rows)==12
for id in ['pattern_en','threshold_en','legacy_object_en']:
 assert rows[id]['status']=='pass'and rows[id]['target_contract_status']=='active'and not rows[id]['failures']
assert rows['mundane_lighting_control']['status']=='pass'and rows['mundane_lighting_control']['target_contract_status']=='not_requested'
negative=[x for x in rows.values()if x['kind']in ['missing_binding','wrong_binding_control']];assert len(negative)==8 and all(x['status']=='fail'for x in negative)
before={x['id']:x for x in D(P/'before-a1dc/report.json')['compositions']}
def failure_shape(fs):return [{k:v for k,v in f.items()if k!='accepted_anchors'}for f in fs]
assert all(failure_shape(x['failures'])==failure_shape(before[x['id']]['failures'])for x in negative)
negative_diagnostic_deltas=[]
for x in negative:
 for old,new in zip(before[x['id']]['failures'],x['failures']):
  if old!=new:
   assert old.get('field')==FIELD and new.get('accepted_anchors')==D(P/'proposed-profile.json')['evidence_requirements'][FIELD]['must_mention_any']
   negative_diagnostic_deltas.append(dict(id=x['id'],before=old,after=new))
compare=D(P/'comparison-after-a1dc/summary.json');assert len(compare)==4
assert all(x['authorial_core_equal']and x['core_retrieval_equal']and x['embodiment_equal']and x['slot_candidate_orders_equal']and x['visual_concept_order_before']==x['visual_concept_order_after']for x in compare)
assert all(not x['identity_aligned'][key]['common_changed']and not x['identity_aligned'][key]['added']and not x['identity_aligned'][key]['removed']for x in compare for key in ['semantic_clarification','visual_concept_candidates'])
for c in compare:
 ds=D(P/'comparison-after-a1dc'/c['id']/'full-pack-diff.json')
 if c['id']=='mundane_lighting_control':assert not ds
 else:
  assert len(ds)==3
  assert {x['path']for x in ds}=={'/pack_id','/visual_obligations/obligations/0/evidence_requirements/comparison_anchor_phrase/must_mention_any/1','/visual_obligations/obligations/0/render_gates/2/description'}
m=D(P/'manifest.json');assert all(H((P/f).read_bytes())==h for f,h in m['input_hashes'].items())
all_start=D(P/'after-all-source-start.json');all_end={str(f.relative_to(R)):H(f.read_bytes())for f in [*A.glob('*.json'),*S.glob('*.py')]};W(P/'after-all-source-end.json',all_end);assert all_start==all_end
before_sources=D(P/'current-all-source-end.json');changed=[k for k in all_end if all_end[k]!=before_sources.get(k)]
assert sorted(changed)==sorted(['skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations.json','skills/photo-prompt-image-generator/assets/photo_prompt_visual_profile_index.json'])
assert D(P/'proposed-profile.json')==next(x for x in D(A/'photo_prompt_visual_obligations.json')['profiles']if x['id']==PID)
W(P/'AFTER-CURRENT-SUMMARY.json',dict(decision='QUALIFIED_TWO_LEAF_SOURCE_RECOVERY_ON_A1DC_BASELINE',normal_v6_after_generations=4,complete_paired_audits=12,pattern_and_threshold_fail_to_pass=2,legacy_active_pass_to_pass=True,mundane_no_target_pass_to_pass=True,eight_negatives_fail_to_fail_with_identical_checks_fields_reasons=True,negative_accepted_anchor_diagnostic_deltas=negative_diagnostic_deltas,all_frozen_inputs_unchanged=True,all_current_before_artifacts_preserved=True,source_files_stable_during_after=True,source_changes_from_current_before=changed,runtime_unchanged_relative_to_current_a1dc_before=True,runtime_unchanged_relative_to_original120=False,pack_delta_summary='Each of three target-active packs changes only pack ID plus the reviewed evidence append and gate description. Mundane control pack structurally identical. All slot/concept/clarification content and candidate ordering unchanged from current BEFORE.',all_pack_comparisons=compare,upstream_optional_gaze_drift='Original120-to-a1dc drift remains recorded separately; no additional gaze-offer changes from current BEFORE to AFTER.',integration_proof=D(P/'AFTER-AUTHORIZED.json'),provider_calls=0,images=0,scope='Source-guided synthetic exact-route text-contract expressibility. No organic recall, clean pre-core, pixel geometry or aesthetic claim. Seam physics conjunction unchanged.'))
print('PASS: two repaired branches pass, legacy and ordinary controls preserved, all8 negative checks/fields/reasons identical with expected comparison accepted-anchor diagnostic update; only reviewed contract leaves and pack IDs differ; current source/inputs stable.')
