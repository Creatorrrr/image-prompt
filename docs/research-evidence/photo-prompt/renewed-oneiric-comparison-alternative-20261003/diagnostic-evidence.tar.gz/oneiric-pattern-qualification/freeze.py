from fixture_common import *
review=P.parent/'oneiric-anchor-review/proof.json';proof=D(review);assert proof['verdict']=='APPROVE_EXACT_TWO_LEAF_RECOVERY_PENDING_FULL_PUBLIC_QUALIFICATION';assert proof['exact_two_leaf_delta']
assert D(P/'before-profile.json')==D(P.parent/'oneiric-anchor-review/profile-before.json');assert D(P/'proposed-profile.json')==D(P.parent/'oneiric-anchor-review/profile-proposed.json')
assert all(x['status']=='pass'for x in D(P/'preflight.json'))
assert not(P/'manifest.json').exists()
W(P/'ACCEPT-VERIFIED.json',dict(review_path=str(review),review_proof=proof,review_sha256=H(review.read_bytes())))
files=[*A.rglob('*.json'),*S.rglob('*.py'),*PRE.glob('*.*')];hashes={str(f.relative_to(R)):H(f.read_bytes())for f in files if f.is_file()}
state=dict(head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),status=subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True).strip(),source_hashes=hashes)
for f in [A/'photo_prompt_visual_obligations.json',S/'prompt_generator.py',S/'audit_composed_prompt.py']:
 dest=P/'source-freeze'/f.relative_to(R);dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(f.read_bytes())
for f in (P.parent/'oneiric-anchor-review').iterdir():
 if f.is_file():dest=P/'source-freeze/independent-review'/f.name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(f.read_bytes())
frozen=[*P.glob('*.py'),*P.glob('*.json'),*P.glob('*.md'),*(P/'inputs').rglob('*.json'),*(P/'source-freeze').rglob('*')]
W(P/'manifest.json',dict(baseline_head=state['head'],source_state=state,case_ids=sorted(d.name for d in(P/'inputs').iterdir()),source_hashes=hashes,input_hashes={str(f.relative_to(P)):H(f.read_bytes())for f in frozen if f.is_file()},frozen_at_utc=subprocess.check_output(['date','-u','+%FT%TZ'],text=True).strip()))
print('Frozen four source-guided requests and twelve complete composition templates after independent acceptance and preflight.')
