from fixture_common import *
r=D(P/'before/report.json');assert r.get('finished_at_utc');rows=r['compositions'];assert len(rows)==12
for id in ['pattern_en','threshold_en']:
 x=next(x for x in rows if x['id']==id);assert x['status']=='fail'and x['target_contract_status']=='active';assert len(x['failures'])==1 and x['failures'][0]['field']==FIELD
for id,status in [('legacy_object_en','active'),('mundane_lighting_control','not_requested')]:
 x=next(x for x in rows if x['id']==id);assert x['status']=='pass'and x['target_contract_status']==status
neg=[x for x in rows if x['kind']in ['missing_binding','wrong_binding_control']];assert len(neg)==8 and all(x['status']=='fail'for x in neg)
m=D(P/'manifest.json');start=D(P/'before/source-start.json');end=D(P/'before/source-end.json')
assert start==end;assert all(H((P/f).read_bytes())==h for f,h in m['input_hashes'].items());assert all(x['exit_code']==0 for x in r['cases'])
W(P/'BEFORE-SUMMARY.json',dict(decision='BEFORE_ISOLATES_REPEATED_PATTERN_THRESHOLD_COMPARISON_GAP',normal_v6_cli_generations=4,full_composed_cli_audits=12,positive_alternative_cases_fail_only_comparison_anchor=2,legacy_object_active_pass=True,mundane_lighting_no_target_pass=True,all_eight_negative_binding_controls_fail=True,source_state_unchanged=True,frozen_inputs_unchanged=True,provider_calls=0,images=0,source_guided_synthetic=True,organic_recall=False,clean_precore=False,limits=['No AFTER integration or index-readiness claim','No pixel confirmation of comparison identity or impossible-space geometry','No missing seam-physics alternative supported; existing conjunction preserved','Gate text change is proven by production materializer but not pixel-tested']))
print((P/'BEFORE-SUMMARY.json').read_text())
