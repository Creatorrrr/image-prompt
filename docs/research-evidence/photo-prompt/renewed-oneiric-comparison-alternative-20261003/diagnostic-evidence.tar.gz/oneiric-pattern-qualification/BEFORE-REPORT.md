# Oneiric repeated pattern/threshold BEFORE

Independent exact two-leaf approval is preserved in ACCEPT-VERIFIED.json and source-freeze/independent-review/. The reviewed proposal appends the existing object/pattern/threshold component literal to comparison evidence and expands only its gate. All five duties and the separate light/perspective/contact/shadow conjunction remain unchanged.

Four source-guided synthetic requests, V3 cores, controls, five-category feature selections, body reviews, and twelve complete final composition templates were frozen at clean 120f07d025340bd067097f947ca23d4dd828e7cf before retrieval. Initial draft preflight rejected a blanket negative anatomy clause; the draft was rewritten positively before freeze, with failed preflight retained. No inputs changed after freeze.

Results:
- Painted architectural pattern: active profile; fail only comparison_anchor_phrase
- Distinctive stepped threshold: active profile; fail only comparison_anchor_phrase
- Repeated red-banded lamp: active profile; pass
- Ordinary upright rooms differing only in lighting: no target; pass
- All five omitted-duty controls: fail
- Lighting-only wrong discontinuity, unrelated patterns, and uniform-warp wrong discontinuity binding controls: fail

All four normal V6 generations and twelve full composed CLI audits completed. No optional slot or concept was selected. The full source state and frozen input hashes were unchanged from start to finish. BEFORE-SUMMARY.json verifies those assertions.

The impossible geometry belongs to the single architectural seam. The adult remains grounded in the near room, with an ordinary relaxed continuous arm reaching through the doorway. Pattern/threshold comparison ownership is explicit and separate from the continuous adult. It does not imply an object-free image. See COHERENCE-REVIEW.md.

This demonstrates a narrow source-guided text-contract expressibility gap, not organic request recall, clean pre-core evaluation, pixel confirmation or aesthetic improvement. Gate wording is covered by source/materializer review, not a generated image. No provider calls or source/index/runtime edits. No AFTER claim yet.

For integration, apply only the reviewed exact leaves and reconcile the index source fingerprint. Reviewer proved unchanged visual/general retrieval documents, all existing vectors and BM25F fields, so these leaves require no new embeddings. Reuse frozen inputs and compositions unchanged for AFTER, retaining all negative controls. planned_test_photo_oneiric_pattern_alternative.py is an unexecuted post-integration regression draft.
