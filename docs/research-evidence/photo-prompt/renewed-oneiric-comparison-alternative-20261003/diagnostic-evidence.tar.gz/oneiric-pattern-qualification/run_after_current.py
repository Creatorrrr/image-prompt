from fixture_common import *
import os,time,traceback
sys.dont_write_bytecode=True
SEED=1003
sha=H;read=D;dump=W
def git(*args):return subprocess.check_output(["git",*args],cwd=R,text=True).strip()
def utc():return subprocess.check_output(["date","-u","+%FT%TZ"],text=True).strip()
def modules():
 import prompt_generator as g;import audit_composed_prompt as a
 return g,a
def state(man):return dict(head=git("rev-parse","HEAD"),status=git("status","--porcelain"),source_hashes={f:sha((R/f).read_bytes())for f in man["source_hashes"]})
def run(arm):
 g,audit=modules();man=read(P/'manifest.json');assert all(sha((P/f).read_bytes())==h for f,h in man['input_hashes'].items()),'Frozen-input drift'
 assert arm=='after-a1dc'
 assert (P/'AFTER-AUTHORIZED.json').exists()
 assert D(P/'proposed-profile.json')==next(x for x in D(A/'photo_prompt_visual_obligations.json')['profiles']if x['id']==PID)
 assert not(P/arm).exists(),'Never overwrite a run';dump(P/'after-a1dc-readiness.json',dict(authorization=D(P/'AFTER-AUTHORIZED.json'),verification=D(P.parent/'oneiric-anchor-integration/verification.json'),source_state=state(man)))
 out=P/arm;out.mkdir();dump(out/'source-start.json',state(man))
 env={k:v for k,v in os.environ.items()if not any(t in k.upper()for t in ['API_KEY','TOKEN','SECRET','CREDENTIAL'])};env['PYTHONDONTWRITEBYTECODE']='1'
 report=dict(arm=arm,started_at_utc=utc(),cases=[],compositions=[],scope='Actual public V6 CLI and complete composed-prompt CLI audits, source-aware synthetic fixtures, local deterministic retrieval only, zero provider calls or images.');packs={}
 for id in man['case_ids']:
  d=P/'inputs'/id;dest=out/id;dest.mkdir();cmd=[str(R/'.venv/bin/python'),str(S/'generate_photo_prompt.py'),'--seed',str(SEED)]
  for a,n in [('request-envelope','envelope'),('authorial-core','core'),('creative-controls','controls'),('embodiment-review','review')]:cmd+=['--'+a+'-json',str(d/(n+'.json'))]
  cmd+=['--output-file',str(dest/'pack.json')];start=time.monotonic();p=subprocess.run(cmd,cwd=R,env=env,capture_output=True,text=True,timeout=600);dump(dest/'cli.json',dict(command=cmd,exit_code=p.returncode,stdout=p.stdout,stderr=p.stderr,seconds=time.monotonic()-start));row=dict(id=id,exit_code=p.returncode,stderr=p.stderr)
  if p.returncode==0:
   pack=read(dest/'pack.json')[0];packs[id]=pack
   row.update(contract_version=pack.get('contract_version'),hard_profiles=[x['id']for x in pack.get('visual_obligations',{}).get('obligations',[])],optional_profiles=[dict(candidate_id=x['id'],profile_id=x.get('opt_in_contract',{}).get('obligation',{}).get('id'))for x in pack.get('visual_concept_candidates',{}).get('candidates',[])],slot_candidate_ids=[x['id']for b in pack['slots'].values()for x in b.get('candidates',[])],core_sha256=pack['authorial_core']['canonical_sha256'],lock_sha256=pack['authorial_core']['intent_lock']['canonical_sha256'],retrieval_sha256=pack['core_retrieval']['canonical_sha256'])
   cv=[str(R/'.venv/bin/python'),str(S/'compose_pack_view.py'),'--pack',str(dest/'pack.json'),'--output',str(dest/'composer-view.json')]
   v=subprocess.run(cv,cwd=R,env=env,capture_output=True,text=True);dump(dest/'view-cli.json',dict(command=cv,exit_code=v.returncode,stdout=v.stdout,stderr=v.stderr))
   candidates=[x for x in pack.get('visual_concept_candidates',{}).get('candidates',[])if x.get('opt_in_contract',{}).get('obligation',{}).get('id')==PID]
   dump(dest/'target-offers.json',candidates)
  report['cases'].append(row);dump(out/'report.json',report);print(arm,id,p.returncode,row.get('hard_profiles'),flush=True)
 for t in read(P/'compositions.json'):
  id=t['id'];case=t['case']
  if case not in packs:report['compositions'].append(dict(id=id,status='not_run_no_pack'));continue
  pack=packs[case];core=pack['authorial_core'];lock=core['intent_lock'];prompt=t['prompt'];spec=read(P/'inputs'/case/'spec.json');chosen=[]
  offers=[x for x in pack.get('visual_concept_candidates',{}).get('candidates',[])if x.get('opt_in_contract',{}).get('obligation',{}).get('id')==PID]
  if t.get('select_target_if_offered'):chosen=[x['id']for x in offers if x.get('applicability',{}).get('status','eligible')=='eligible']
  hard=PID in [x['id']for x in pack.get('visual_obligations',{}).get('obligations',[])];active=hard or bool(chosen)
  composed=dict(core_retrieval_sha256=pack['core_retrieval']['canonical_sha256'],pack_id=pack['pack_id'],prompt_en=prompt,negative_en=pack['negative_en'],chosen_candidate_ids=[],chosen_visual_concept_ids=chosen,composer='agent',candidate_interpretations=[],authorial_core_binding=dict(source_authorial_core_sha256=core['canonical_sha256'],source_intent_lock_sha256=lock['canonical_sha256'],preserved_anchor_ids=[a['anchor_id']for a in lock['semantic_anchors']],preserved_evidence=[],authorial_decisions=[]),semantic_clarification_decisions=[dict(clarification_id=r['id'],decision='applied'if r.get('required_in_final_prompt')else'rejected',rationale='Preserve the frozen localized architectural scene and decline optional reinterpretation.',prompt_evidence=lock['semantic_anchors'][0]['prompt_evidence'])for r in pack.get('semantic_clarification',{}).get('candidates',[])],creative_augmentation_brief=dict(decisions=[dict(candidate_id=r['id'],decision='rejected',rationale='The architectural scene is complete without optional augmentation.')for r in pack.get('creative_augmentation',{}).get('candidates',[])]),embodiment_review=dict(source_contract_sha256=pack['embodiment_preflight']['canonical_sha256'],review=embodiment(prompt,'agent_postcomposition')))
  if active:composed['visual_obligation_evidence']={PID:t['bindings']}
  if pack.get('semantic_assertion_obligations'):
   composed['semantic_assertion_evidence']=dict(source_contract_sha256=pack['semantic_assertion_obligations']['canonical_sha256'],evidence={x['assertion_id']:x['evidence']for x in core['semantic_assertions']if x['polarity']=='required'and x['dimension']!='character_response'})
  dest=out/'compositions'/id;dump(dest/'composed.json',composed);direct=audit.audit_visual_obligations(pack,composed,prompt);effective,ef=audit.derive_effective_visual_obligation_contract(pack,composed)
  cmd=[str(R/'.venv/bin/python'),str(S/'audit_composed_prompt.py'),'--pack',str(out/case/'pack.json'),'--composed',str(dest/'composed.json')];p=subprocess.run(cmd,cwd=R,env=env,capture_output=True,text=True,timeout=600);dump(dest/'cli.json',dict(command=cmd,exit_code=p.returncode,stdout=p.stdout,stderr=p.stderr))
  try:result=json.loads(p.stdout)
  except Exception:result=dict(status='error',failures=[dict(reason=p.stderr)])
  dump(dest/'audit.json',result);dump(dest/'direct-visual.json',dict(failures=direct,effective_contract=effective,effective_contract_failures=ef))
  row=dict(id=id,case=case,kind=t['kind'],status=result['status'],expected=t['expected_after'],exit_code=p.returncode,failures=result['failures'],direct_visual_failures=direct,warnings=result.get('warnings',[]),target_contract_status='active'if active else'unavailable'if spec['profile']else'not_requested',chosen_candidate_ids=[],chosen_visual_concept_ids=chosen,effective_profile_ids=[x['id']for x in(effective or{}).get('obligations',[])],effective_gate_ids=(effective or{}).get('required_hard_gates',[]))
  report['compositions'].append(row);dump(out/'report.json',report);print(id,row['status'],row['target_contract_status'],[(f.get('check'),f.get('field'))for f in row['failures']],flush=True)
 reg=g.load_visual_obligation_registry(A/'photo_prompt_visual_obligations.json');profile=next(x for x in reg['profiles']if x['id']==PID);helpers=[]
 for t in read(P/'compositions.json'):
  if not t['bindings']:continue
  phrase=' '.join(t['bindings'].values());vi=dict(contract_version=g.VISUAL_INTENT_CONTRACT_VERSION,provenance='agent_prepack',obligations=[dict(profile_id=PID,source='explicit_user_requirement',scope='request_only',source_text=profile['activation']['exact_terms'][0],bindings=t['bindings'])])
  try:g.normalize_visual_intent(vi,reg);normalized=dict(ok=True)
  except Exception as e:normalized=dict(ok=False,error=str(e))
  helpers.append(dict(id=t['id'],component_match=g.candidate_pack_visual_component_match(profile,phrase),normalized=normalized))
 dump(out/'helper-boundaries.json',helpers);dump(out/'source-end.json',state(man));report['finished_at_utc']=utc();dump(out/'report.json',report)
 print('Finished',arm,'input drift:',any(sha((P/f).read_bytes())!=h for f,h in man['input_hashes'].items()),flush=True)

run(sys.argv[1])
