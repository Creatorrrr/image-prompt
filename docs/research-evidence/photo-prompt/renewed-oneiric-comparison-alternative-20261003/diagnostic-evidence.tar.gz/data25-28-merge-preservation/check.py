"""Target-record preservation only; no full-corpus metadata/retrieval audit."""
from pathlib import Path
import hashlib,json,subprocess
P=Path(__file__).resolve().parent;R=P.parent.parent/'image-prompt';BASE='skills/photo-prompt-image-generator/assets/';CURRENT='a1dc739da4e40bdc474a934fc90ba8ccfe23d1a8'
def git(*a):return subprocess.check_output(['git',*a],cwd=R,text=True).strip()
def blob(ref,path):return json.loads(git('show',ref+':'+path))
def digest(o):return hashlib.sha256(json.dumps(o,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def profile(ref,path,pid):return next(p for p in blob(ref,path)['profiles']if p['id']==pid)
def diff(a,b,p=''):
 if type(a)!=type(b):return [dict(path=p,before=a,after=b)]
 if isinstance(a,dict):return [x for k in sorted(a.keys()|b.keys())for x in ([dict(path=p+'/'+k,before=a.get(k),after=b.get(k))]if k not in a or k not in b else diff(a[k],b[k],p+'/'+k))]
 if isinstance(a,list):return []if a==b else[dict(path=p,before=a,after=b)]
 return []if a==b else[dict(path=p,before=a,after=b)]
assert git('rev-parse','HEAD')==CURRENT
status=git('status','--porcelain');assert not status
specs=[('DATA25','2c4e06ea','photo_prompt_visual_obligations_photo_era.json','mounted_slide_transparency_object_relation'),('DATA26','280ea12d','photo_prompt_visual_obligations.json','ghost_ship_former_vessel_breach'),('DATA27','53de5652','photo_prompt_visual_obligations.json','biaoju_guarded_cargo_departure'),('DATA28','120f07d0','photo_prompt_visual_obligations.json','auroral_arc_curtain_atmosphere')]
latest_idx=blob(CURRENT,BASE+'photo_prompt_visual_profile_index.json');results=[]
for cycle,ref,name,pid in specs:
 path=BASE+name;before=profile(ref+'^',path,pid);published=profile(ref,path,pid);current=profile(CURRENT,path,pid);working=next(p for p in json.loads((R/path).read_text())['profiles']if p['id']==pid)
 assert current==published==working,(pid,'authored record changed')
 index=blob(ref,BASE+'photo_prompt_visual_profile_index.json')
 assert index['entries'][pid]==latest_idx['entries'][pid],(pid,'index entry changed')
 assert index['bm25f']['documents'][pid]==latest_idx['bm25f']['documents'][pid],(pid,'target BM25F changed')
 old_exact=[x for x in index['exact_lookup']if x['profile_id']==pid];current_exact=[x for x in latest_idx['exact_lookup']if x['profile_id']==pid];assert old_exact==current_exact
 # Canonical old valid evidence and runtime labels remain retained for all changes.
 evidence={}
 for field,req in before.get('evidence_requirements',{}).items():
  anchors=req.get('must_mention_any',[]);now=current['evidence_requirements'][field].get('must_mention_any',[]);assert all(x in now for x in anchors)
  assert req.get('min_content_words')==current['evidence_requirements'][field].get('min_content_words');evidence[field]=dict(legacy_anchors_retained=True,minimum_unchanged=True)
 old_labels=before.get('runtime_expression',{}).get('prompt_label_terms',[]);new_labels=current.get('runtime_expression',{}).get('prompt_label_terms',[]);assert all(x in new_labels for x in old_labels)
 assert before['activation']==current['activation'];assert before['reject_substitutes']==current['reject_substitutes']
 results.append(dict(cycle=cycle,published_commit=git('rev-parse',ref),profile_id=pid,source_file=path,complete_authored_record_equals_publication=True,authored_record_sha256=digest(current),published_source_delta=diff(before,published),complete_index_entry_text_hash_vector_equals_publication=True,index_entry_sha256=digest(latest_idx['entries'][pid]),target_BM25F_document_equals_publication=True,target_BM25F_sha256=digest(latest_idx['bm25f']['documents'][pid]),exact_lookup_rows_equal=True,old_evidence_checks=evidence,legacy_runtime_labels_retained=True,activation_and_rejects_unchanged=True))
# Independently enumerate pre-existing source profile edits made by religion/iconography integration.
upstream_before='900848816f88a494e5bf16ea475a25074d584911';upstream_after='b4120b84'
files=git('diff','--name-only',upstream_before,upstream_after,'--',BASE+'photo_prompt_visual_obligations*.json').splitlines();upstream_changes=[];new_profiles=[]
for path in files:
 try:a={p['id']:p for p in blob(upstream_before,path)['profiles']}
 except subprocess.CalledProcessError:a={}
 b={p['id']:p for p in blob(upstream_after,path)['profiles']}
 for pid in sorted(a.keys()&b.keys()):
  if a[pid]!=b[pid]:
   latest=profile(CURRENT,path,pid);assert latest==b[pid],('upstream profile changed',pid)
   upstream_changes.append(dict(profile_id=pid,source_file=path,latest_equals_upstream_authored_record=True,record_sha256=digest(latest)))
 new_profiles += [dict(profile_id=pid,source_file=path)for pid in sorted(b.keys()-a.keys())]
assert len(upstream_changes)==12,len(upstream_changes)
target_ids={r['profile_id']for r in results};overlap=sorted(target_ids&{x['profile_id']for x in upstream_changes});assert not overlap
assert git('rev-parse','HEAD')==CURRENT and git('status','--porcelain')==status
report=dict(verdict='NO_LOSS_NO_RECORD_OVERLAP',latest_commit=CURRENT,read_only_scope='Four accepted DATA25-28 complete authored records and their own index entries/BM25F documents/exact aliases; upstream 12 changed pre-existing records. No duplicate whole-index hash/text/dimension audit.',accepted_records=results,upstream_change_base=upstream_before,upstream_change_commit=git('rev-parse',upstream_after),upstream_modified_existing_record_count=len(upstream_changes),upstream_modified_existing_records=upstream_changes,upstream_new_profile_count=len(new_profiles),target_overlap_with_upstream_modified_ids=overlap,upstream_12_records_also_preserved=True,working_tree_clean_and_stable=True,provider_calls=0,source_mutations=0,limits=['Corpus-wide BM25F statistics legitimately changed with added upstream documents; only target document fields compared.','No new CLI, pixel, organic retrieval or regression-suite claim; parent owns current full-index and boundary-V7 audit.'])
(P/'preservation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items()if k not in ['accepted_records','upstream_modified_existing_records']},indent=2))
