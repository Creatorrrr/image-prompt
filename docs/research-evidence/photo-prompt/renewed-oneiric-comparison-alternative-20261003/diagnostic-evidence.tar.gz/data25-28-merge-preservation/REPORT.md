# DATA25–28 preservation after religion/iconography merges

Result: NO LOSS; NO RECORD OVERLAP

Checked latest `a1dc739da4e40bdc474a934fc90ba8ccfe23d1a8` against each accepted publication by profile ID, not whole-file equality:

- DATA25 `2c4e06ea`: `mounted_slide_transparency_object_relation` remains exactly equal to publication. Original density-or-thickness and density anchors remain; added thickness branch remains.
- DATA26 `280ea12d`: `ghost_ship_former_vessel_breach` remains exactly equal. Bounded translucency, absence and displacement gate alternatives remain; opaque baseline and all other duties unchanged.
- DATA27 `53de5652`: `biaoju_guarded_cargo_departure` remains exactly equal. Original EN/KO route anchors and additive transport-contact branch remain; five duties and minimums untouched by this merge.
- DATA28 `120f07d0`: `auroral_arc_curtain_atmosphere` remains exactly equal. Existing horizon runtime label and additive atmospheric-anchor label remain; horizon/atmosphere branch and strict arc/curtain/ray duties retained.

For all four IDs, complete visual-index entries (text, text hash, vector), target BM25F documents and exact-lookup rows also equal their respective publication records. Original accepted evidence anchors and content minima are retained; activation, rejects and old runtime labels are preserved. This does not claim whole-index equality: upstream additions legitimately alter global corpus statistics.

## Upstream overlap check

Independently compared original religion/iconography integration `90084881` → `b4120b84`, finding 54 new profiles and these 12 changed pre-existing owners:

axis_mundi_three_realm_connection; chaoskampf_cosmogonic_ordering; cosmic_egg_world_emergence; earth_diver_first_land_creation; egyptian_heart_weighing_judgment; griffin_eagle_lion_topology; katabasis_living_underworld_descent; moirai_fate_thread_life_allocation; mythic_apotheosis_mortal_divine_transition; mythic_flood_preservation_vessel; world_parent_separation_creation; pf_muqarnas.

None overlaps the four accepted IDs. All 12 latest authored records also equal their enriched upstream versions. No concrete merge conflict or lost branch was found.

## Evidence and limits

`preservation.json` stores per-record hashes, publication source deltas, target index checks and the enumerated upstream overlap result. `check.py` reproduces the read-only check. The expected absence of the newly added religion-iconography file in its pre-integration commit is recorded in `check.log`; it is handled as a new file, not a failed assertion.

The current tree was clean and stable throughout. No source/provider/index mutation. Parent already owns full current metadata/text/dimension/BM25F and boundary-V7 checks; this review intentionally did not repeat them or claim new CLI/pixel quality results.
