"""Independent source/consumer/index proof without providers or source mutation."""
from pathlib import Path
import copy,hashlib,json,subprocess,sys
from unittest.mock import patch
sys.dont_write_bytecode=True
P=Path(__file__).resolve().parent;Q=P.parent/'component-evidence-coverage-audit';R=P.parent.parent/'image-prompt';A=R/'skills/photo-prompt-image-generator/assets';sys.path.insert(0,str(A.parent/'scripts'))
import prompt_generator as pg
import build_visual_profile_index as builder
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def dump(n,x):(P/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
PID='oneiric_dream_logic_discontinuity';FIELD='comparison_anchor_phrase';ANCHOR='the same distinctive object pattern or threshold appears on both sides'
old=read(Q/'oneiric-profile-before.json');proposed=read(Q/'oneiric-profile-proposed.json');dump('profile-before.json',old);dump('profile-proposed.json',proposed);dump('exact-leaves.json',read(Q/'oneiric-exact-leaves.json'))
expected=copy.deepcopy(old);expected['evidence_requirements'][FIELD]['must_mention_any'].append(ANCHOR);expected['render_gates'][2]['description']='One distinctive comparison object, pattern, or threshold appears clearly across both sides of the seam.';assert proposed==expected
tracked=[A/'photo_prompt_visual_obligations.json',A/'photo_prompt_visual_profile_index.json',A/'photo_prompt_tags.json',A/'photo_prompt_imaginal_extension.json',Q/'oneiric-profile-before.json',Q/'oneiric-profile-proposed.json'];hashes={str(p):sha(p)for p in tracked}
with patch.object(pg,'embed_texts_with_gemini',side_effect=AssertionError('provider forbidden')),patch.object(builder,'embed_texts_with_gemini',side_effect=AssertionError('provider forbidden')),patch('socket.create_connection',side_effect=AssertionError('network forbidden')):
 reg=pg.load_visual_obligation_registry(A/'photo_prompt_visual_obligations.json');assert next(x for x in reg['profiles']if x['id']==PID)==old
 new=copy.deepcopy(reg);new['profiles'][next(i for i,p in enumerate(new['profiles'])if p['id']==PID)]=proposed
 assert pg.compile_visual_profile(proposed)==proposed
 for key in ['activation','semantics','concept_candidate','composition_instruction','required_evidence_fields','runtime_expression','reject_substitutes']:assert old[key]==proposed[key]
 assert old['evidence_requirements'][FIELD]['min_content_words']==proposed['evidence_requirements'][FIELD]['min_content_words']==9
 assert len(proposed['required_evidence_fields'])==5 and len(proposed['render_gates'])==5
 for field in old['evidence_requirements']:
  if field!=FIELD:assert old['evidence_requirements'][field]==proposed['evidence_requirements'][field]
 for a,b in zip(old['render_gates'],proposed['render_gates']):
  assert a['id']==b['id']and a['review_scale']==b['review_scale']
  if a['id']!='vo_imaginal_dream_repeated_anchor':assert a==b
 ot={x['id']:pg.visual_profile_semantic_text(x)for x in reg['profiles']};nt={x['id']:pg.visual_profile_semantic_text(x)for x in new['profiles']};assert ot==nt
 assert pg.visual_profile_bm25f_documents(reg)==pg.visual_profile_bm25f_documents(new)
 cache=pg.load_json(A/'photo_prompt_visual_profile_index.json');kw=dict(provider=cache['provider'],model=cache['embedding_model'],dimensions=cache['embedding_dimensions']);ov=builder.reusable_vectors([A/'photo_prompt_visual_profile_index.json'],reg,**kw);nv=builder.reusable_vectors([A/'photo_prompt_visual_profile_index.json'],new,**kw);assert ov==nv and len(ov)==len(ot)
 ob=pg.build_visual_profile_index_payload(reg,vectors=ov,**kw);nb=pg.build_visual_profile_index_payload(new,vectors=nv,**kw);delta=[k for k in ob if ob[k]!=nb[k]];assert delta==['registry_sha256'];pg.validate_visual_profile_index_metadata(nb,new,**kw)
 with patch.object(pg,'load_visual_obligation_registry',return_value=reg):c1=pg.load_json(A/'photo_prompt_tags.json')
 with patch.object(pg,'load_visual_obligation_registry',return_value=new):c2=pg.load_json(A/'photo_prompt_tags.json')
 assert c1==c2
 st1={k:pg.semantic_text_for_entry(e,s,kind=t)for k,t,e,s in pg.iter_semantic_entries(c1)};st2={k:pg.semantic_text_for_entry(e,s,kind=t)for k,t,e,s in pg.iter_semantic_entries(c2)};assert st1==st2 and pg.semantic_bm25f_documents(c1)==pg.semantic_bm25f_documents(c2)
 checks=[]
 phrases={'legacy_object':old['evidence_requirements'][FIELD]['must_mention_any'][0]+' with its distinctive shape visible beside the localized physical boundary','pattern':ANCHOR+' with the same doorway stripe continuing as the comparison marker across that seam','threshold':ANCHOR+' with the same notched threshold marking matching positions across that seam','unrelated_patterns':'unrelated wall patterns decorate separate corners of the ordinary room without a matched cross-boundary comparison'}
 for name,phrase in phrases.items():
  row=dict(case=name,phrase=phrase)
  for arm,p in [('before',old),('proposed',proposed)]:
   try:pg.validate_visual_intent_binding(obligation_index=0,field=FIELD,phrase=phrase,requirement=p['evidence_requirements'][FIELD]);row[arm]='pass'
   except ValueError as e:row[arm]=dict(status='fail',error=str(e))
  if name=='legacy_object':assert row['before']==row['proposed']=='pass'
  elif name in ['pattern','threshold']:assert isinstance(row['before'],dict)and row['proposed']=='pass'
  else:assert isinstance(row['before'],dict)and isinstance(row['proposed'],dict)
  checks.append(row)
 component_checks=[]
 for omit in [None]+old['semantics']['component_semantics']['required_group_ids']:
  text=' '.join(x['any_terms'][0]for x in old['semantics']['component_semantics']['groups']if x['id']!=omit)
  a=pg.candidate_pack_visual_component_match(old,text);b=pg.candidate_pack_visual_component_match(proposed,text);assert a==b;assert bool(a)==(omit is None);component_checks.append(dict(omitted_group=omit,before=a,proposed=b))
 candidates=[dict(slot=s,record=x)for s,rs in c1['slots'].items()for x in rs if x['id']in ['repeated_orientation_object_anchor','repeated_dream_orientation_anchor_prop']];assert len(candidates)==2
 materialized=[]
 for p in [old,proposed]:materialized.append(pg.candidate_pack_visual_profile_obligation(p,reg,activation_source='explicit_user_requirement',source_intent_ids=['source-guided-review']))
 assert materialized[0]['runtime_expression']==materialized[1]['runtime_expression'];assert materialized[0]['composition_instruction']==materialized[1]['composition_instruction'];assert materialized[0]['render_gates'][4]==materialized[1]['render_gates'][4]
assert hashes=={str(p):sha(p)for p in tracked}
dump('proof.json',dict(verdict='APPROVE_EXACT_TWO_LEAF_RECOVERY_PENDING_FULL_PUBLIC_QUALIFICATION',source_candidates=candidates,exact_two_leaf_delta=True,legacy_anchor_retained=True,comparison_min_content_words=9,all_five_groups_fields_gates_preserved=True,seam_physics_conjunction_unchanged=old['evidence_requirements']['seam_physics_phrase'],seam_physics_gate_unchanged=old['render_gates'][4],all_activation_exclusions_runtime_composition_and_other_fields_unchanged=True,binding_results=checks,component_group_omission_results=component_checks,visual_document_count=len(ot),all_visual_texts_BM25F_fields_vectors_equal=True,cached_vectors_reusable=len(ov),complete_index_payload_changed_keys=delta,general_document_count=len(st1),all_general_texts_and_BM25F_equal=True,source_fingerprints=hashes,head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),status=subprocess.check_output(['git','status','--short'],cwd=R,text=True),provider_calls=0,source_writes=0))
print('APPROVE: exact two leaves, five duties/seam physics intact, all retrieval documents and vectors identical, source fingerprint only changes.')
