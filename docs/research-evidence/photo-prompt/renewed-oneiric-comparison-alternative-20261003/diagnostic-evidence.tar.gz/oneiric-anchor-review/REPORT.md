# Independent oneiric comparison-anchor review

## Decision: APPROVE exact two-leaf recovery, pending full public qualification

Profile `oneiric_dream_logic_discontinuity`, base visual-obligation registry.

1. Retain existing object-only evidence anchor and append the already authored component literal: “the same distinctive object pattern or threshold appears on both sides”
2. Change only gate `vo_imaginal_dream_repeated_anchor` description to “One distinctive comparison object, pattern, or threshold appears clearly across both sides of the seam.”

This is a bounded recovery of existing alternatives, not permission for generic pattern repetition, similar decorations, or unrelated thresholds to replace comparison across one localized seam.

## Source supports more than freestanding objects

Reviewed the full maintained profile, original imaginal source report sections 3.1 and 4, evidence row `imaginal_dream_bizarreness_hobson`, and linked imaginal extension candidates.

- Definition requires a repeated anchor and preserved subject/object continuity; composition requires the comparison anchor, complete localized seam and same crossing subject/object; runtime label is generic `localized dream-logic discontinuity`
- Required component `repeated_comparison_anchor` explicitly permits same distinctive object, pattern or threshold on both sides, with a parallel Korean term
- Candidate `repeated_orientation_object_anchor` explicitly names object/pattern/threshold; its embedding text permits an unchanged object OR surface marker
- Candidate `repeated_dream_orientation_anchor_prop` includes a doorway stripe alongside chair/lamp/personal-object realizations
- Original source report specifies a familiar orientation anchor, one dominant violation, localized join and subject/object continuity. It does not prescribe a freestanding comparison object

The original scientific evidence supplies broad discontinuity/incongruity/uncertainty axes. These photographic comparisons are authored fictional scene relations, not empirical proof of dream experience, cognition, sleep state or dream causation. No external scientific facts were newly researched or asserted.

## Exact preserved duties and boundaries

`prove_proposal.py` independently verifies that the proposed profile equals the current target plus exactly those two edits. It preserves:

- All five required groups, fields and render gates, their IDs/scales and all content minima
- Comparison evidence minimum remains nine content words; old object anchor retains its original array position
- Familiar ordinary context; exactly one localized orientation/scale/adjacency/continuity break; same comparison identity across both sides; identifiable crossing subject/object; localized seam physics
- Activation aliases and exclusions, definition, paraphrases, components, concept fields, composition and runtime label
- All other evidence requirements and gates byte-logically unchanged
- All existing rejects: mood-only blur/pastel, sleeping-only scene, random floating props, uniform warp, fog/bloom-only and unrelated collage

The separate component OR versus evidence/gate AND issue for light/perspective/contact/shadow is outside scope. Current evidence still requires “light perspective contact and shadow localize the change to that single seam”, and the native seam-physics gate stays unchanged. Qualification must retain all of those cues. The fact that source component language is looser does not authorize silently relaxing the stronger current duty during this proposal.

## Actual consumer and retrieval proof

The production materializer preserves both edits and all unaffected duty fields. The actual `validate_visual_intent_binding` helper accepts legacy object evidence before/proposed; pattern and threshold evidence carrying the existing component literal fail the old canonical-anchor requirement and pass the proposed requirement; unrelated-pattern evidence fails both. Complete-group matching and each one-group omission retain identical outcomes. These are bounded helper tests, not a claim of full CLI acceptance or pixel validity.

The exact alternative phrase itself can require scene-specific elaboration to meet existing content-word minima. The proof appends concrete same-comparison detail and does not lower thresholds. The public qualification author must freeze any such authoring before execution and preserve failed attempts if revisions are needed.

Actual builder projection comparison, with provider/network entrypoints blocked:

- All 1,510 visual-profile embedding texts, BM25F document fields and cached vectors remain identical
- Complete in-memory visual-index entries, BM25F and exact lookup remain identical; only `registry_sha256` changes
- All 9,739 separate general-index embedding documents and BM25F fields remain identical
- All current vectors remain reusable; a fingerprint-only source-binding refresh is sufficient after an authorized edit

No provider calls, index persistence or repository writes occurred. Current concurrent source/index state is recorded in `proof.json`; this review validates a target-specific in-memory edit against stable file fingerprints rather than claiming an unchanged historical whole-tree baseline.

## Fixture/adoption constraints

Before source integration, freeze distinct pattern and threshold positives and a legacy-object positive. Their comparison marker must remain the same identifiable marker on both sides of the same seam, separate from the role of the crossing subject/object. A stripe or threshold being a physical thing is not a defect: this change addresses permitted comparison-owner wording, not a claim that the scene contains no physical objects.

Retain the complete ordinary setting, one local orientation/scale change, crossing continuity, all light/perspective/contact/shadow duties, exact safe runtime label and fixed minima. Include an ordinary scene, unrelated-pattern/cross-seam failure and uniform-warp/missing-seam near misses, plus all five omitted-duty controls. Diagnose boundary mutations as synthetic contract probes rather than organic scenes. Do not force optional candidate exposure.

After authorized application and valid index binding, use unchanged source-aware public inputs and complete compositions for actual V6 BEFORE/AFTER comparison. Require legacy/control stability, expected branch expressibility and retained negative failures. Report unavailable component routes as unavailable. No image-quality, actual-dream, organic-recall or clean-precore claim is supported.

## Artifacts

`proof.json`, `profile-before.json`, `profile-proposed.json`, `exact-leaves.json`, `prove_proposal.py`, `proof.log`. Run the proof from repository root before integration with `python ../daylong-progress-20261002/oneiric-anchor-review/prove_proposal.py`.
