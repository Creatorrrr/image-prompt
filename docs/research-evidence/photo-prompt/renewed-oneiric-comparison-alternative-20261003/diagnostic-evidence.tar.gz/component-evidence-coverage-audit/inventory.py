from pathlib import Path
import json,sys,hashlib,subprocess
sys.dont_write_bytecode=True
O=Path(__file__).resolve().parent;R=O.parent.parent/'image-prompt';S=R/'skills/photo-prompt-image-generator/scripts';A=S.parent/'assets';sys.path.insert(0,str(S));import prompt_generator as g
reg=g.load_visual_obligation_registry(A/'photo_prompt_visual_obligations.json')
def W(n,x):(O/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
rows=[]
for p in reg['profiles']:
 mat=g.candidate_pack_visual_profile_obligation(p,reg,activation_source='read_only_coverage_inventory',source_intent_ids=[])
 groups=mat.get('component_semantics',{}).get('groups',[]);evidence=mat.get('evidence_requirements',{});anchors=[(field,t)for field,q in evidence.items()for t in q.get('must_mention_any',[])]
 checked=[]
 for gr in groups:
  terms=[]
  for t in gr.get('any_terms',[]):
   # Literal reuse only: never equate synonym similarity with semantic coverage.
   hits=[dict(field=f,anchor=a)for f,a in anchors if t.casefold()in a.casefold()or a.casefold()in t.casefold()]
   terms.append(dict(term=t,literal_evidence_reuse=hits))
  checked.append(dict(id=gr['id'],required=gr['id']in mat['component_semantics'].get('required_group_ids',[]),terms=terms))
 rows.append(dict(id=p['id'],authored_components=bool(p.get('authored_components')),groups=checked,evidence_fields=list(evidence),unreused_component_term_count=sum(not t['literal_evidence_reuse']for gr in checked for t in gr['terms']),runtime_expression=mat.get('runtime_expression'),definition=p.get('semantics',{}).get('definition'),paraphrases=p.get('semantics',{}).get('paraphrase_examples',[])))
W('inventory.json',rows);W('inventory-summary.json',dict(profile_count=len(rows),authored_component_profiles=sum(x['authored_components']for x in rows),profiles_with_component_terms_not_literally_reused=sum(bool(x['unreused_component_term_count'])for x in rows),source_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),scope='All compiled profiles and actual materialized obligations. Literal reuse is a triage inventory, not semantic correctness or evidence-language coverage.',provider_calls=0,images=0,source_hashes={str(f.relative_to(R)):hashlib.sha256(f.read_bytes()).hexdigest()for f in A.glob('photo_prompt_visual_obligations*.json')}))
for r in rows:
 if r['unreused_component_term_count']and not r['authored_components']:
  missing=[t['term']for gr in r['groups']for t in gr['terms']if not t['literal_evidence_reuse'] and t['term'].isascii()]
  if missing:print(r['id'],json.dumps(missing))
