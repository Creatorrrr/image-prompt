# Compiled component/evidence coverage inventory

One bounded proposal for review; one unresolved lead deferred. No repository source/runtime/index changes or API calls.

## Coverage

inventory.py loads the actual registry and invokes production candidate_pack_visual_profile_obligation for all 1,510 profiles. It records 3,743 component groups, 6,625 component terms, required-group flags, canonical evidence fields, runtime expressions, definitions and paraphrases. 2,290 terms in 627 profiles lack literal substring reuse in any evidence anchor; 106 profiles have at least one such ASCII term.

These are NOT defect counts. Multilingual discovery aliases, alternate discovery wording, optional groups, and deliberately narrower canonical evidence can all produce non-reuse. The inventory does not split on English “or” or assume synonyms. Only two focused leads received full semantic/source review; do not describe all 1,510 profiles as independently source-validated.

## Proposal: repeated dream comparison pattern/threshold

Profile: oneiric_dream_logic_discontinuity.

The definition requires a repeated anchor; composition requires a repeated comparison anchor; runtime label is the neutral “localized dream-logic discontinuity.” The required repeated_comparison_anchor group explicitly permits “the same distinctive object pattern or threshold appears on both sides,” including a Korean parallel. Yet comparison_anchor_phrase accepts only a repeated distinctive object, and vo_imaginal_dream_repeated_anchor describes only an object.

This is supported beyond an isolated permissive word: source candidates repeated_orientation_object_anchor and repeated_dream_orientation_anchor_prop explicitly include a surface marker, doorway stripe, pattern or threshold as the repeated comparison reference. The original source research specifies a familiar orientation anchor and one localized violation, not an obligatory freestanding comparison object. Its evidence ledger limits the scientific source to general discontinuity/incongruity/uncertainty and original scene relations; this proposal makes no claim about actual dream cognition.

Propose exactly two leaves:
1. Append the already-authored component literal “the same distinctive object pattern or threshold appears on both sides” to comparison_anchor_phrase.must_mention_any
2. Change vo_imaginal_dream_repeated_anchor description to “One distinctive comparison object, pattern, or threshold appears clearly across both sides of the seam.”

The old accepted object evidence remains. Minimum content words, all five required duties, familiar scene, single localized seam, physically continuous subject/object, seam-physics constraints, exclusions, activation, composition and runtime label stay unchanged. Do not broaden this into generic repetition or patterns without same-identity cross-seam comparison.

A separate component OR versus evidence/gate AND tension exists for light/perspective/contact/shadow. It is explicitly outside this proposal; any qualification must retain all existing seam-physics duties rather than claiming this fix accepts missing light/contact/shadow evidence. The “subject” continuity evidence does not by itself prove a human-only constraint: an object can be the photographic subject. No owner-terminology rewrite proposed.

review_leads.py proves the two exact in-memory changes survive the actual production materializer. The legacy evidence validates before and after; the existing source pattern/threshold branch is rejected before and accepted in the proposal; an unrelated-pattern control remains rejected. These are focused binding diagnostics, not complete V6 composition qualification. Semantic embedding text, BM25F fields and exact lookup remain identical; source-binding hash changes. No embedding call is needed for these two leaves, but index source-binding reconciliation would still be required if accepted.

Artifacts: oneiric-profile-before.json, oneiric-profile-proposed.json, oneiric-exact-leaves.json, lead-consumer-proof.json. Parent should seek independent review and frozen normal V6 BEFORE/AFTER qualification before integration. This audit does not claim that an image or full composed prompt passes.

## Deferred: legendary-rock structural scale

legendary_rock_trace_evidence has a component allowing “a hand body tool or nearby structure” and a render gate allowing structural scale comparison. Its definition, canonical scale evidence, action candidate and composition candidate instead emphasize human/body/tool scale. A direct existing component phrase cannot satisfy the current evidence literal.

Original local evidence supports fixed distinctive rock, embedded trace, site ownership and scale relation. The primary record abstractions cover footprints, handprints, equipment marks, body-shaped traces and adjacent site objects; they do not independently specify a reliably scaled architectural reference. The source definition and canonical candidates remain narrower. Therefore no evidence-only addition is recommended. A structural-only branch would require deciding the complete source scope and how recognizable scale is established, without relaxing fixed site, embedded trace, contact logic or site-reading duties. KEEP current data pending that decision.

## Provenance and boundary

Original maintained research inspected:
- imaginal-visual-semantics-20260901/source-research.md sections 3.1 and 4; evidence.jsonl record imaginal_dream_bizarreness_hobson
- legend-visual-semantics-20260901/source-research.md and evidence records legend_aks_genre_site_evidence, legend_aks_warrior_rock and legend_duchas_giants_bed
- Full profile definitions/paraphrases/components/evidence/instructions/runtime labels/gates and complete linked extension candidates

source-provenance.json and source-snapshots/ preserve exact records/files and hashes. Original public pages were not fetched again. Findings are maintained source consistency, not new scientific or cultural claims. Newly fixed slide/convoy/aurora/ghost, renewed architecture/optical cases and previously reviewed phantasmagoria were excluded from new proposals. The registry hashes remained unchanged during this audit.

No source/API/runtime edits, no provider calls, no images, no organic retrieval or aesthetic claims.
