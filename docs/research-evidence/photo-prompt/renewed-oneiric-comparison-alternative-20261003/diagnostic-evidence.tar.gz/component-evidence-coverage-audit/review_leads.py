from pathlib import Path
import json,sys,hashlib,copy
sys.dont_write_bytecode=True
O=Path(__file__).resolve().parent;R=O.parent.parent/'image-prompt';S=R/'skills/photo-prompt-image-generator/scripts';A=S.parent/'assets';sys.path.insert(0,str(S));import prompt_generator as g
D=lambda p:json.loads(p.read_text());H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def W(n,x):(O/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def delta(a,b,path=''):
 if isinstance(a,dict)and isinstance(b,dict):return sum((delta(a.get(k),b.get(k),path+'/'+k)for k in sorted(a.keys()|b.keys())),[])
 if isinstance(a,list)and isinstance(b,list)and len(a)==len(b):return sum((delta(x,y,path+'/'+str(i))for i,(x,y)in enumerate(zip(a,b))),[])
 return []if a==b else[dict(path=path,before=a,after=b)]
reg=g.load_visual_obligation_registry(A/'photo_prompt_visual_obligations.json');ids=['oneiric_dream_logic_discontinuity','legendary_rock_trace_evidence'];ps={p['id']:p for p in reg['profiles']if p['id']in ids};PID=ids[0];p=ps[PID];q=copy.deepcopy(p)
branch=next(x for x in p['semantics']['component_semantics']['groups']if x['id']=='repeated_comparison_anchor')['any_terms'][0]
q['evidence_requirements']['comparison_anchor_phrase']['must_mention_any'].append(branch)
next(x for x in q['render_gates']if x['id']=='vo_imaginal_dream_repeated_anchor')['description']='One distinctive comparison object, pattern, or threshold appears clearly across both sides of the seam.'
changes=delta(p,q);assert len(changes)==2
proposed=copy.deepcopy(reg);proposed['profiles'][next(i for i,x in enumerate(reg['profiles'])if x['id']==PID)]=q
before=g.candidate_pack_visual_profile_obligation(p,reg,activation_source='read_only_audit',source_intent_ids=[]);after=g.candidate_pack_visual_profile_obligation(q,proposed,activation_source='read_only_audit',source_intent_ids=[]);assert delta(before,after)==changes
checks=[]
for label,phrase in [('legacy_object',p['evidence_requirements']['comparison_anchor_phrase']['must_mention_any'][0]+' within the continuous scene'),('source_pattern_threshold_branch',branch+' with a painted doorway stripe serving as the repeated pattern anchor'),('unrelated_patterns','Two unrelated decorative patterns appear in distant unconnected regions without establishing one repeated same-identity comparison')]:
 row=dict(id=label,phrase=phrase)
 for arm,prof in [('before',p),('proposed',q)]:
  try:g.validate_visual_intent_binding(obligation_index=0,field='comparison_anchor_phrase',phrase=phrase,requirement=prof['evidence_requirements']['comparison_anchor_phrase']);row[arm]=dict(accepted=True)
  except ValueError as e:row[arm]=dict(accepted=False,error=str(e))
 checks.append(row)
assert checks[0]['before']['accepted']and checks[0]['proposed']['accepted'];assert not checks[1]['before']['accepted']and checks[1]['proposed']['accepted'];assert not checks[2]['proposed']['accepted']
W('oneiric-profile-before.json',p);W('oneiric-profile-proposed.json',q);W('oneiric-exact-leaves.json',changes)
W('lead-consumer-proof.json',dict(proposed_profile_id=PID,before_materialized=before,proposed_materialized=after,materialized_changes=delta(before,after),target_binding_diagnostics=checks,semantic_text_unchanged=g.visual_profile_semantic_text(p)==g.visual_profile_semantic_text(q),bm25f_unchanged=g.visual_profile_bm25f_fields(p)==g.visual_profile_bm25f_fields(q),exact_lookup_unchanged=g.visual_profile_exact_term_rows(reg)==g.visual_profile_exact_term_rows(proposed),registry_hash_changed=g.visual_profile_registry_sha256(reg)!=g.visual_profile_registry_sha256(proposed),embedding_calls_required_for_these_two_leaves=0,normal_v6_qualification_performed=False,rock_materialized=g.candidate_pack_visual_profile_obligation(ps[ids[1]],reg,activation_source='read_only_audit',source_intent_ids=[]),rock_full_profile=ps[ids[1]]))
linked=[];files=set()
for f in A.glob('*extension.json'):
 d=D(f)
 for x in d.get('visual_semantics',[]):
  if x.get('id')in ids or set(x.get('hard_profile_ids',[]))&set(ids):linked.append(dict(file=str(f.relative_to(R)),record=x));files.add(f)
 for slot,rows in d.get('slots',{}).items():
  for c in rows:
   if c['id']in ['following_one_seam_dream_discontinuity','repeated_dream_orientation_anchor_prop','familiar_room_single_discontinuity','one_seam_dream_discontinuity','repeated_orientation_object_anchor','dream_discontinuity_local_light_seam','legendary_trace_boulder_subject','rock_trace_scale_reading_action','distinctive_rock_site_location','legendary_rock_anomalous_mark_prop','rock_trace_causal_axis_composition']:linked.append(dict(file=str(f.relative_to(R)),slot=slot,record=c));files.add(f)
W('linked-source-records.json',linked)
evidence=[]
for folder in ['imaginal-visual-semantics-20260901','legend-visual-semantics-20260901']:
 base=R/'docs/research-evidence/photo-prompt'/folder
 files.update([base/'source-research.md',base/'evidence.jsonl'])
 for i,line in enumerate((base/'evidence.jsonl').read_text().splitlines(),1):
  e=json.loads(line)
  if e.get('topic_id')in ids or set(e.get('affected_contract_ids',[]))&{'visual_obligation:'+x for x in ids}:evidence.append(dict(file=str((base/'evidence.jsonl').relative_to(R)),line=i,record=e))
W('source-provenance.json',dict(evidence=evidence,source_hashes={str(f.relative_to(R)):H(f)for f in files},public_original_sources_refetched=False,scope='Original repository source research and candidate records; no new historical or scientific facts asserted.'))
for f in files:
 dest=O/'source-snapshots'/f.relative_to(R);dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(f.read_bytes())
assert all(H(R/f)==h for f,h in D(O/'inventory-summary.json')['source_hashes'].items())
print('PASS: exact two-leaf in-memory proposal survives materialization; legacy accepted, existing source branch newly accepted, unrelated control rejected; semantic/BM25F/exact text unchanged. Source files unchanged. No CLI qualification claim.')
