import json,hashlib,pathlib,subprocess,shutil,sys
sys.dont_write_bytecode=True
ROOT=pathlib.Path('/workspace/scratch/ce8f20680f5a');REPO=ROOT/'image-prompt';OUT=pathlib.Path(__file__).parent; D=OUT.parent/'photo-baseline-drift-diagnosis'
A=REPO/'skills/subculture-illustration-image-generator/assets'; P=REPO/'skills/photo-prompt-image-generator/assets'
def h(raw):return hashlib.sha256(raw).hexdigest()
def canon(v):return json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
def diff(a,b,p=''):
 if type(a)!=type(b):return [[p,a,b]]
 if isinstance(a,dict):
  assert a.keys()==b.keys(),p
  return sum([diff(a[k],b[k],p+'/'+k) for k in sorted(a)],[])
 if isinstance(a,list):
  assert len(a)==len(b),p
  return sum([diff(x,y,p+'/'+str(i)) for i,(x,y) in enumerate(zip(a,b))],[])
 return [] if a==b else [[p,a,b]]
base=(A/'photo_regression_baseline_v5.json').read_bytes();baseline=json.loads(base)
pinned=(REPO/'docs/research-evidence/photo-prompt/body-terminology-20261002/integration/photo-boundary.final.json').read_bytes()
current=(D/'current-pack.json').read_bytes(); previous=json.loads(pinned);now=json.loads(current)
assert h(pinned)==baseline['sha256']; assert previous[0]['pack_id']==baseline['pack_id']
assert current==(D/'current-repeat-pack.json').read_bytes()==(D/'840d4b8f-pack.json').read_bytes()
derived={'/0/pack_id','/0/provenance/tags_hash','/0/core_retrieval/canonical_sha256','/0/core_retrieval/slot_corpus_sha256'}
upstream=json.loads((D/'0adb5f6e-pack.json').read_bytes());updelta=diff(upstream,now);delta=diff(previous,now)
assert {x[0] for x in updelta}==derived
assert {x[0] for x in delta}==derived|{'/0/semantic_clarification/candidates/2/interpreted_meaning'}
sys.path.insert(0,str(REPO/'skills/photo-prompt-image-generator/scripts'))
import prompt_generator
tags=prompt_generator.load_json(P/'photo_prompt_tags.json'); material={k:tags.get(k,d) for k,d in [('version',None),('slots',{}),('facet_vocab',{}),('character_mechanism_graph',{}),('candidate_bundles',[]),('candidate_semantic_policy',{})]}
assert h(canon(material))==now[0]['provenance']['tags_hash']
assert h(canon(tags['slots']))==now[0]['core_retrieval']['slot_corpus_sha256']
assert h(canon({k:v for k,v in now[0]['core_retrieval'].items() if k!='canonical_sha256'}))==now[0]['core_retrieval']['canonical_sha256']
assert h(canon(dict(now[0],pack_id=None)))[:16]==now[0]['pack_id']
assert sum(len(s['candidates']) for s in now[0]['slots'].values())==baseline['public_candidate_count']==64
assert now[0]['negative_en']==baseline['negative_en']
for k in ['slots','authorial_core','negative_en']:assert previous[0][k]==now[0][k]
for name,raw in [('photo-regression-v5.before.json',base),('pinned-complete-pack.json',pinned),('current-complete-pack.json',current),('upstream-0adb5f6e-complete-pack.json',(D/'0adb5f6e-pack.json').read_bytes())]: (OUT/name).write_bytes(raw)
history=[]
for i in range(1,5):
 p=A/f'photo_regression_baseline_v{i}.json';raw=p.read_bytes(); old=subprocess.check_output(['git','show',f'9594c556:{p.relative_to(REPO)}'],cwd=REPO);assert raw==old
 shutil.copy2(p,OUT/p.name);history.append({'path':str(p.relative_to(REPO)),'sha256':h(raw)})
record={'status':'APPROVE_TWO_LEAF_CURRENT_OBSERVATION_REFRESH_WITH_EXPLICIT_UPSTREAM_SEMANTIC_DELTA','reviewed_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip(),'source_modified':False,'provider_called':False,'pinned_pack_sha256':h(pinned),'current_pack_sha256':h(current),'original_v5_asset_sha256':h(base),'current_equals_840d4b8f_and_repeat':True,'derived_hashes_independently_recomputed':True,'pinned_to_current_differences':delta,'upstream_to_current_differences':updelta,'candidate_inventory_core_negative_exact':True,'public_candidate_count':64,'approved_minimal_leaves_if_parent_accepts_known_upstream_delta':{'sha256':h(current),'pack_id':now[0]['pack_id']},'additional_provenance_fields_approved':[],'preserved_history':history,'prohibited_changes':['runtime validators','V1-V4 baselines','historical research receipts','historical packs','fixture authored inputs','other V5 leaves'],'qualification':'The exact old V5-pinned complete pack has one interpreted_meaning semantic revision already committed in 0adb5f6e. It is false to describe old-pin-to-current as only four derived fields. No semantic changes beyond integrated upstream are present. Approval is only current-observation evidence maintenance, never a DATA improvement cycle or full-suite pass.'}
(OUT/'review.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in record.items() if k not in ['pinned_to_current_differences','upstream_to_current_differences']},indent=2))
