# Photo baseline byte drift diagnosis

## Result
The failing immutable-photo check is an exact whole-corpus hash coupling, not evidence of a semantic regression in this fixture. The first local failure after renewal baseline 9594c556 is ebd10bcb, the instrument-hand-role DATA correction. That change alters only four digest/derived-ID fields in the actual public baseline pack; every other field is identical. Separately, upstream 0adb5f6e updates the pinned baseline digest but its own committed source cannot reproduce that new digest. Neither discrepancy is nondeterministic in the repeated runs checked.

All replay evidence is produced by the baseline's real public `generate_photo_prompt.py` command, original authored fixture inputs, original repository snapshots, and seed 910000. Only interpreter and output paths were substituted. API-key variables were blanked, and no provider calls, fabricated vectors/images, source edits, expected-hash updates, or history changes occurred. Snapshot trees are isolated outside the repository. Existing full-suite snapshots lacked the subculture baseline JSON, so this diagnosis created independent exact `git archive` snapshots containing photo sources/assets, current_boundary fixtures and the pinned baseline JSON.

## Exact results

| Snapshot | Pinned SHA-256 | Actual SHA-256 | Pinned pack ID | Actual pack ID |
|---|---|---|---|---|
| 9594c556 | 127292e6d6a6879acb4acaa249ac192ec2f6486a5d340b579332403ed7951e37 | 127292e6d6a6879acb4acaa249ac192ec2f6486a5d340b579332403ed7951e37 | 78d7a982d125daad | 78d7a982d125daad |
| ebd10bcb | 127292e6d6a6879acb4acaa249ac192ec2f6486a5d340b579332403ed7951e37 | 13dfab59ad7a5fd7383ae3ce73458de1efa388303528aa2d64e094d0bdec1792 | 78d7a982d125daad | 3188e998cf82bddd |
| 57e2973 | 127292e6d6a6879acb4acaa249ac192ec2f6486a5d340b579332403ed7951e37 | 13dfab59ad7a5fd7383ae3ce73458de1efa388303528aa2d64e094d0bdec1792 | 78d7a982d125daad | 3188e998cf82bddd |
| 0adb5f6e | 4efd1e92ec9fd557ec088056965d73c24033c32f2a2747f55ca76c6d6151f83a | 19e863d22fb9683d4456c6af4331c3ee36ebb49595c022049328ecb1aa6c7517 | 782bfaa18be4d465 | 6666456a3201f7e2 |
| 840d4b8f | 4efd1e92ec9fd557ec088056965d73c24033c32f2a2747f55ca76c6d6151f83a | 878167e663d6d8a3ce33cde24c18c70ea350e3861a0f9580486ebc18b0e5f3bb | 782bfaa18be4d465 | e153ad2c064e14fb |
| current | 4efd1e92ec9fd557ec088056965d73c24033c32f2a2747f55ca76c6d6151f83a | 878167e663d6d8a3ce33cde24c18c70ea350e3861a0f9580486ebc18b0e5f3bb | 782bfaa18be4d465 | e153ad2c064e14fb |

Current is cad6f905. Current and 840d4b8f replay outputs are byte-identical. Repeated current and upstream 0adb5f6e runs reproduce their own complete bytes exactly (`current-repeat-pack.json`, `upstream-repeat-pack.json`). All commands exited zero and output 64 public candidates.

## Causal mechanism
`validate_illustration_assets.py:6408` checks SHA-256 over the complete serialized public pack against `photo_regression_baseline_v5.json`. `prompt_generator.py:10421` dictionary_hash includes all slots, facet vocabulary, character mechanism graph, candidate bundles and semantic policy. `prompt_generator.py:11360` independently hashes the entire slot corpus. Those appear as public `provenance.tags_hash` and `core_retrieval.slot_corpus_sha256`; the latter feeds `core_retrieval.canonical_sha256`, and all feed `pack_id`.

Thus unrelated instrument-slot text changes still alter the teacup/no-people fixture's exact bytes even when no selected candidate changes. The ebd10bcb source diff corrects trumpet left-hand support/right-hand fingering and generic wind-instrument playing/support roles. The recursive JSON comparison from 9594c556 to ebd10bcb (and to 57e2973) finds exactly:
- /0/provenance/tags_hash
- /0/core_retrieval/slot_corpus_sha256
- /0/core_retrieval/canonical_sha256
- /0/pack_id

There are no other differences, including candidate contents/order/counts, core, safety, coverage, conflicts, negative prompt and provenance contract.

Pure upstream 0adb5f6e versus 840d4b8f/current also differs in exactly these same four fields. The upstream commit itself changes the baseline pin from 127292… / 78d7a982d125daad to 4efd1e… / 782bfaa18be4d465, but actual pristine-upstream output is 19e863… / 6666456a3201f7e2, confirmed twice. The original pinned pack was subsequently found and hash-verified at docs/research-evidence/photo-prompt/body-terminology-20261002/integration/photo-boundary.final.json; see the refresh assessment below.

Comparison of original renewal baseline 9594c556 with current has seven differing leaves: the four above, slot_ownership_sha256, retrieval naming (`frozen_assertion` to `frozen_observation`), and one semantic clarification's interpreted_meaning. These additional three differences are already present in pure upstream 0adb5f6e; they are not caused by the local DATA fixes. See 9594c556--current-diff.json for verbatim originals. Public candidate slot contents/order/counts remain identical.

## Classification and action boundary
- Local exact-byte test regression: yes, first introduced at ebd10bcb, because corpus-changing DATA edits invalidate a hash over unrelated corpus material
- Demonstrated semantic regression of the public fixture: no
- Upstream latent expectation mismatch: yes, 0adb5f6e's own pinned digest is not reproduced by its pristine committed source
- Nondeterminism: not observed in current and pristine-upstream repeats
- Later fixes after 840d4b8f: do not change the baseline pack at all

Do not silently refresh the pin or weaken tests. Any future repair should preserve historical assets, establish a reviewed current fixture/version, retain exact corpus provenance checks, and distinguish corpus identity from independently asserted semantic invariants. The original pinned generation artifact is preserved and compared in the refresh assessment below.

## Evidence files
`*-pack.json`: unmodified public replay outputs. `*-result.json`: hashes, pack IDs, exit status and byte counts. `*-stderr.txt`: CLI diagnostics. `*-diff.json`: exhaustive recursive leaf comparisons. `replay.py`, `replay-first.py`, `replay-repeat.py`, `diff_packs.py`: reproduction scripts. Isolated snapshots under `snapshot-*` contain exact committed files used for replay.

## Requested DATA-only refresh assessment (not applied)

The original pin is recoverable: docs/research-evidence/photo-prompt/body-terminology-20261002/integration/photo-boundary.final.json hashes to 4efd1e92ec9fd557ec088056965d73c24033c32f2a2747f55ca76c6d6151f83a exactly, pack 782bfaa18be4d465. It is copied unchanged as pinned-original-pack.json. Original V5 JSON is preserved as photo-regression-v5.original.json (file SHA-256 c65def2076ab9db5d6669a6192508e4a8f5fd45f3d6642eb3ef013c1b91e9036).

Current pack versus that actual pinned pack differs in FIVE leaves, exhaustively recorded in pinned-original--current-diff.json: the four corpus/derived-ID fields PLUS /0/semantic_clarification/candidates/2/interpreted_meaning. This is the upstream kuudere/archetype definition revision in photo_prompt_visual_obligations.json, introduced in 0adb5f6e. It distinguishes the general contextual meaning from one operationalized adult fictional still-image realization. Both versions retain composed outward behavior, selective affiliation toward the same counterpart, local warmth, practical help, and an already-visible benefit. The revised text additionally says the action is an operational cue rather than a universal archetype definition. This is a genuine wording/semantic-framing difference that MUST be explicitly reviewed and named; a claim that only hashes changed relative to the original pin would be false. All selected slot data, frozen core, negative, intent contract, mandatory intents, safety, coverage, conflicts and creative controls are exactly equal (refresh-invariants.json).

Current equals 840d4b8f byte-for-byte, but equality alone is NOT sufficient proof for a truthful hash-only refresh. Combined with the recovered original artifact, exhaustive five-leaf comparison, provenance of the one upstream wording revision, and unchanged semantic invariants, it supports an explicitly reviewed current-observation refresh. Approval should acknowledge that fifth change, not classify it as corpus metadata.

### Dependencies
Exhaustive repository text search is saved in v5-references.txt. No active manifest pins the V5 FILE hash, and there is no V6 successor whose historical lineage pins V5. The only runtime reader is validate_photo_regression_baseline. It validates V5's schema/status/current command/current output fields and V5 -> V4 historical hash, which must remain untouched. Universal-scene baseline pins V1, not V5.

Historical documentation records V5's old file/pack hashes in:
- body-terminology-20261002/integration/CURRENT-BOUNDARY-REFRESH.json, photo-boundary.final.json and refresh_current_boundary.py
- semantic-guidance-data-research-20261002/phase-1/source-snapshot.json
- semantic-guidance-data-research-20261002/phase-2-20261003/implementation/baseline.json and current-snapshot.json
- semantic-guidance-merge-20261003/source-preservation.json and followup-904b5893/source-preservation.json
- neutral-expression-semantics-20261003/CURRENT-DATA-AUDIT.json and CORPUS-RECEIPT.json
These are historical receipts/snapshots; preserve them unchanged, including their old hashes. Add a new dated receipt pointing to prior and new file hashes rather than retroactively updating history. Keep V1–V4 and V5's historical_baseline exactly unchanged. No dependent runtime manifest update is required.

### Exact bounded future procedure
1. Preserve the original V5 JSON and original pinned public pack (already done), and record all V1–V4 asset hashes before any change.
2. Independently rerun the original command twice, blanking provider keys, from the source commit being refreshed. Confirm current output exactly equals this diagnosis's current/840d outputs; if source moved or bytes differ, stop and re-review.
3. Verify original artifact hash against the existing pin; exhaustively compare originals and new outputs. Require exactly the five documented leaf paths, with exact reviewed old/new wording, and all refresh-invariants true. Validate canonical pack-ID derivation, 64 candidates, public provenance/omitted private fields, no newly exposed private fields, V6 contract and unchanged negative prompt.
4. With explicit acceptance of the reviewed upstream definition wording, change only V5.sha256 to 878167e663d6d8a3ce33cde24c18c70ea350e3861a0f9580486ebc18b0e5f3bb; V5.pack_id to e153ad2c064e14fb; change_scope to reviewed_current_corpus_and_upstream_semantic_clarification; and purpose to a truthful description naming the corpus-provenance refresh plus the upstream archetype-definition clarification, while noting exact slot inventory/frozen core/negative preservation and immutable V1–V4 history. Leave schema, date, command, status, lineage and all other assertions unchanged.
5. Add a new evidence receipt containing source commit, original V5 file SHA, original pinned pack SHA, new V5 file SHA, new actual pack SHA, exhaustive diff, review rationale and V1–V4 preservation hashes. Preserve every existing receipt and source-preservation manifest.
6. Run all THREE original affected tests unmodified, not just the photo validator. Record true outcomes, including any newly reached missing-artifact errors. Also run validate_photo_regression_baseline directly and assert V1–V4 byte immutability and no validator/runtime/test changes. Do not claim full-suite green based on targeted tests.
7. Review the final diff: only the four approved V5 fields and new evidence. If any selected candidate, core, negative, safety, intent or other unreviewed semantic field differs, do not refresh.

No refresh was applied. This worker remains available for independent verification after a future authorized application.

## Post-refresh independent verification
Parent subsequently authorized/applied ONLY V5.sha256 and V5.pack_id; scope/purpose were retained and explicit upstream wording review is to be recorded in a new receipt. This worker made no source changes.

PASS: fresh public replay matches pinned SHA 878167e663d6d8a3ce33cde24c18c70ea350e3861a0f9580486ebc18b0e5f3bb and pack e153ad2c064e14fb, byte-identical to pre-refresh current/840d output. V1–V4 byte-identical to cad6f905 and historical recorded hashes. Final repository diff is exactly the two approved V5 leaves, with no test/runtime/history modifications. Machine-readable verification: post-refresh-verification.json; public output: post-refresh-public-pack.json; repeatable checker: verify_refresh.py.

PASS: all three original tests, unchanged, 3 tests in 50.432s, OK. Correct command:

.venv/bin/python -m unittest -v tests.test_subculture_illustration_contract_v1.SubcultureIllustrationContractV1Tests.test_aggregate_validator_does_not_hide_partial_pixel_qualification tests.test_subculture_illustration_universal_scene_v3.UniversalSceneDataContractTests.test_existing_render_manifests_keep_historical_failure_labels tests.test_subculture_illustration_universal_scene_v3.UniversalSceneRuntimeContractTests.test_v1_v2_exact_replay_and_photo_baseline_remain_immutable

Full log: post-refresh-three-tests-corrected.log. Transparency: an initial invocation used UniversalSceneRuntimeContractTests instead of UniversalSceneDataContractTests for the second test and produced an AttributeError for that selection while the other two passed. Its log is retained as post-refresh-three-tests.log. The corrected invocation actually executed and passed all three, with no suppressed failures. These targeted results do not assert the unrelated full-suite failures are resolved.
