import json,pathlib,sys
out=pathlib.Path(__file__).parent
def diff(a,b,p=''):
 if type(a)!=type(b):return [(p,a,b)]
 if isinstance(a,dict):
  return sum([diff(a.get(k),b.get(k),p+'/'+k) for k in sorted(a.keys()|b.keys())],[])
 if isinstance(a,list):
  if len(a)!=len(b):return [(p+'/length',len(a),len(b))]
  return sum([diff(x,y,p+'/'+str(i)) for i,(x,y) in enumerate(zip(a,b))],[])
 return [] if a==b else [(p,a,b)]
for first,last in [('9594c556','57e2973'),('0adb5f6e','840d4b8f'),('0adb5f6e','current')]:
 if not (out/(first+'-pack.json')).exists() or not (out/(last+'-pack.json')).exists():continue
 d=diff(json.load(open(out/(first+'-pack.json'))),json.load(open(out/(last+'-pack.json'))));(out/(first+'--'+last+'-diff.json')).write_text(json.dumps(d,indent=2)+'\n');print(first,last,len(d));print(json.dumps(d,indent=2)[:18000])
