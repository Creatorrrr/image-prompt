import pathlib,subprocess,json,hashlib,os,sys
repo=pathlib.Path('REPOSITORY_ROOT')
out=repo.parent/'daylong-progress-20261002/photo-baseline-drift-diagnosis'
for name,root in [(ref,out/('snapshot-'+ref)) for ref in ['9594c556','57e2973','0adb5f6e','840d4b8f']]:
 b=json.loads((root/'skills/subculture-illustration-image-generator/assets/photo_regression_baseline_v5.json').read_text());cmd=b['command'][:];cmd[0]=str(repo/'.venv/bin/python');cmd[cmd.index('--output-file')+1]=str(out/(name+'-pack.json'))
 env=os.environ.copy();env.update(GEMINI_API_KEY='',GOOGLE_API_KEY='',PYTHONDONTWRITEBYTECODE='1')
 p=subprocess.run(cmd,cwd=root,env=env,capture_output=True,text=True);(out/(name+'-stderr.txt')).write_text(p.stderr)
 r={'name':name,'returncode':p.returncode,'expected_sha256':b['sha256'],'expected_pack_id':b['pack_id']}
 if p.returncode==0:
  raw=(out/(name+'-pack.json')).read_bytes(); pack=json.loads(raw)[0];r.update(actual_sha256=hashlib.sha256(raw).hexdigest(),actual_pack_id=pack['pack_id'],bytes=len(raw))
 (out/(name+'-result.json')).write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True)
