import pathlib,json,hashlib,subprocess,os
repo=pathlib.Path('REPOSITORY_ROOT');out=repo.parent/'daylong-progress-20261002/photo-baseline-drift-diagnosis';assets=repo/'skills/subculture-illustration-image-generator/assets'
old=json.loads((out/'photo-regression-v5.original.json').read_bytes());new=json.loads((assets/'photo_regression_baseline_v5.json').read_bytes());delta={k:{'before':old.get(k),'after':new.get(k)} for k in old.keys()|new.keys() if old.get(k)!=new.get(k)}
assert set(delta)=={'sha256','pack_id'},delta
hist={}
for n in range(1,5):
 p=assets/f'photo_regression_baseline_v{n}.json';raw=p.read_bytes(); original=subprocess.check_output(['git','show','cad6f905:'+str(p.relative_to(repo))],cwd=repo);assert raw==original;hist[p.name]=hashlib.sha256(raw).hexdigest()
cmd=new['command'][:];cmd[0]=str(repo/'.venv/bin/python');dest=out/'post-refresh-public-pack.json';cmd[cmd.index('--output-file')+1]=str(dest);env=os.environ.copy();env.update(GEMINI_API_KEY='',GOOGLE_API_KEY='',PYTHONDONTWRITEBYTECODE='1');subprocess.run(cmd,cwd=repo,env=env,check=True,capture_output=True,text=True)
raw=dest.read_bytes();pack=json.loads(raw)[0];assert hashlib.sha256(raw).hexdigest()==new['sha256'];assert pack['pack_id']==new['pack_id'];assert raw==(out/'current-pack.json').read_bytes()
r={'status':'PASS','changed_leaves':delta,'immutable_v1_v4_sha256':hist,'fresh_public_sha256':hashlib.sha256(raw).hexdigest(),'fresh_public_pack_id':pack['pack_id'],'exact_pre_refresh_output_preserved':True,'git_diff_names':subprocess.check_output(['git','diff','--name-only'],cwd=repo,text=True).splitlines(),'git_status':subprocess.check_output(['git','status','--short'],cwd=repo,text=True)};(out/'post-refresh-verification.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
