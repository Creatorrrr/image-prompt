# 전체 테스트 기준선 진단 증거

이 묶음은 프로젝트 테스트 진단만 포함합니다. 절대 작업 경로와 원본 사용자 Downloads 경로는 플레이스홀더로 치환했습니다. 파일의 논리적 프로젝트 경로와 고정 SHA-256은 보존했습니다.

- 현재 코드: cad6f90549d9fd6348310a71a23025f003fd00d6
- 비교 기준선: 57e29730f0b5c2df336fd1e9dd58374b2025ee03
- 초기 체크아웃: 9594c5567973832d9f3daf7acb3f72beaddd086d
- 기준선에서는 문제가 된 메서드만 원본 소스/자산으로 재실행했습니다. 기준선 전체 스위트를 재실행했다는 의미가 아닙니다.
- 대용량 소스 스냅샷과 개인 파일 복구 목록은 포함하지 않았습니다.
- export-manifest.json은 원본 및 경로 비식별화 후 파일 해시를 구분합니다.
- SHA256SUMS는 배포용 파일 바이트를 검증합니다.

플레이스홀더: <PROJECT_ROOT>, <BASELINE_57E2973_ROOT>, <INITIAL_9594C556_ROOT>, <WORKSPACE_ROOT>, <REFERENCE_IMAGE_PATH>, <PYTHON_RUNTIME>
