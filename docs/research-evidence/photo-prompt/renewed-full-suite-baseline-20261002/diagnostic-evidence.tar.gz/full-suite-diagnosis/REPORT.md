# Full-suite missing-artifact diagnosis

Date: 2026-10-02 UTC. Repository inspected read-only at cad6f90549d9fd6348310a71a23025f003fd00d6. The local origin/main ref points to the same commit. No network fetch was performed.

## Result

The observed Korean emotional and makeup failures are reproducible baseline checkout/environment failures, not newly introduced by the current data changes. This does **not** establish that these tests failed on the original author's computer, where ignored run artifacts and an absolute-path reference image may have existed. It also does not certify the whole suite as passing or classify any other newly emerging failure.

Current execution of both complete test modules: **18 methods, 15 passing methods, 3 failing/erroring methods**, represented by **4 assertion failures and 1 error** because the Korean method has 3 failing subtests. Targeted execution of the 3 affected methods on independent git-exported snapshots of baseline 57e2973 and initial 9594c556 reproduces exactly **4 failures + 1 error** at the same checks.

- Korean `test_three_arm_fixture_is_frozen_independent_and_reference_bound`: all three arms fail at test line 335, `reference.is_file()`. They share one absent external reference JPEG at the absolute original Mac Downloads path. Expected SHA-256: `3d363f7e1bfde96cd153cd22550e11144de30cf0aec492a3c97007653ec92aea`.
- Makeup `test_five_frozen_cores_are_distinct_and_share_only_the_makeup_contract`: test line 150 asserts 5 authorial cores; glob returns 0. Expected under `artifacts/photo-runs/20260831-makeup-reference-five-arm-v1/arms/arm-*/authorial_core.json`.
- Makeup `test_source_observation_is_hash_bound_and_identity_independent`: FileNotFoundError at test line 133 reading that run's `shared/source_observation.json`. If restored, this test subsequently also needs the same external JPEG; no synthetic substitute can satisfy the intended provenance contract.

Minimum missing unique dependencies: **1 JPEG + 6 JSON files** (5 makeup cores and 1 observation). Other unexecuted requirements inside those missing files cannot be verified from absent content.

## Provenance evidence

Both test modules and both corresponding fixture files have identical Git blob IDs at 57e2973, 9594c556, cad6f905, and local origin/main. The entire makeup run has **zero tracked files** at all four refs and is covered by `artifacts/.gitignore:4:*`. This is not a current deletion from Git.

All **12 Korean frozen manifest JSON artifacts** (request envelope, authorial core, visual intent, candidate pack for each arm) exist in the current checkout and match their fixture SHA-256. They also match the same hashes in all four Git refs. Therefore restoring only the external image would clear the currently observed file-presence blocker for the Korean arms; subsequent assertions have not been artificially bypassed or represented as a test pass.

Some Korean runtime profile values differ baseline-to-current. `profile-differences.json` preserves exact changed field paths and values. Two involved profiles, including makeup, are fully unchanged; five Korean profiles have changes to semantic/evidence language, and overhead_social_snapshot_relation additionally changes composition and a gate description. The gate IDs compared before the absent-file assertion still pass on both baselines and current. These source changes do not explain the observed failures, which reproduce under original source snapshots.

## Reproduction and files

- `makeup-current.log`: complete current 7-test module, 5 pass, 1 fail, 1 error
- `korean-current.log`: complete current 11-test module, 10 pass, 1 method with 3 failing subtests
- `baseline-57e2973-affected-tests.log`: baseline source/asset snapshot, exact affected 3 methods, 4 failures + 1 error
- `baseline-9594c556-affected-tests.log`: initial source/asset snapshot, same result
- `dependency-evidence.json`: resolved commits, Git blob IDs, missing paths/counts, all 12 manifest hash comparisons
- `profile-differences.json`: transparent source-profile differences rather than an unsupported assertion of source identity
- `inspect_dependencies.py`: read-only evidence collection script
- `snapshot-57e2973/` and `snapshot-9594c556/`: Git-exported targeted reproduction trees, containing the full photo skill/scripts/assets, exact original affected test modules, Korean case fixture, and all tracked Korean run artifacts

Current commands: `PYTHONDONTWRITEBYTECODE=1 python -m unittest discover -s tests -p test_photo_makeup_reference_balance.py -v` and the analogous Korean module command.

Baseline commands run from each snapshot with `PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=tests python -m unittest -v` followed by the three fully qualified affected test names. No test source was changed, skipped, monkey-patched, or supplied fabricated artifacts. Snapshots and diagnostic files are outside the repository; repository working tree remains clean.

The known poverty PNG failures remain separate and were not rerun or newly classified here. The parent-owned full-suite process remains the source of authoritative final aggregate counts.

## Rare-photo additional diagnosis (22:10 UTC)

The later full-suite failure `test_photo_rare_photo_visual_semantics.PhotoRarePhotoVisualSemanticsTests.test_three_arm_fixture_is_frozen_and_reference_bound` was reproduced directly on current cad6f905 and independently on both original-source snapshots (57e2973 and 9594c556): **1 method, 3 subtest failures** on each revision. There were no skips and no errors. Every failure occurs at line 252, `self.assertTrue(artifact.is_file())`, on that arm's first `request_envelope.json` check.

The fixture points to `generated_images/rare-photo-three-agent-20260902/arm-1/`, `arm-2/`, and `arm-3/`. All **6 files actually asserted by this method** (3 request envelopes and 3 authorial cores) are absent at these exact current checkout paths. The fixture additionally names 3 candidate packs, also absent, making **9 absent fixture-listed JSON artifacts**. This method does not assert candidate-pack existence and does not read the external JPEG, although the fixture names the same shared JPEG discussed above. The current failure must therefore be described as absent run JSON artifacts, not as a JPEG-presence failure.

The test and fixture Git blobs are identical at baseline, initial, current, and local upstream. All four refs contain **zero tracked files** under this named run; `.gitignore:29:/generated_images/` excludes it. Frozen required gate IDs match the respective profile gate IDs at every revision. Some profile fields have changed, preserved transparently in `rare-dependency-evidence.json`, but the original baseline/initial source executions reproduce the exact same missing-artifact failures.

Additional evidence:
- `rare-current-affected-test.log`
- `rare-57e2973-affected-test.log`
- `rare-9594c556-affected-test.log`
- `rare-dependency-evidence.json` (all exact fixture paths, expected hashes, current absence, revision identities, profile differences, and gate-ID comparisons)

The existing baseline snapshots were extended only with their own original rare-photo test and fixture via `git archive`. No missing input was fabricated, no test was changed or suppressed, and no private-file search or recovery was attempted. Absence from these exact paths and Git histories does not imply permanent loss or unavailability elsewhere.

Combined scoped diagnosis now explains **7 assertion failures + 1 error across 4 affected methods** (3 Korean subtest failures, 2 makeup failing/erroring methods, 3 rare-photo subtest failures). This remains separate from known poverty PNG failures and from the parent-owned full-suite aggregate.

## Terminal full-suite result and unresolved errors (22:29 UTC)

The current full-suite log and companion exit file now establish: **1205 tests in 3980.265 seconds; FAILED (failures=10, errors=4); exit code 1**. The log's aggregate is authoritative; subtest failures must not be subtracted from 1205 to invent a passing-method count.

Of those results, this report independently diagnoses 7 missing-artifact failures + 1 missing-artifact error in Korean/makeup/rare-photo methods. A further 3 poverty subtest failures are at `result_path.is_file()` (line 385), consistent with the separately known poverty PNG absence; poverty baseline reproduction is not part of this report.

The remaining **3 errors are unresolved by this diagnosis** and must not be classified as missing-file baseline failures. All report `ValidationFailure: current photo baseline candidate-pack bytes drift` from `validate_illustration_assets.py:6408`:
- `test_subculture_illustration_contract_v1.SubcultureIllustrationContractV1Tests.test_aggregate_validator_does_not_hide_partial_pixel_qualification`
- `test_subculture_illustration_universal_scene_v3.UniversalSceneDataContractTests.test_existing_render_manifests_keep_historical_failure_labels`
- `test_subculture_illustration_universal_scene_v3.UniversalSceneRuntimeContractTests.test_v1_v2_exact_replay_and_photo_baseline_remain_immutable`

These three require a separate investigation. This report does not establish whether they are baseline behavior, current regression, fixture drift, or another cause. The full suite remains red.
