import json
from pathlib import Path
P=Path(__file__).resolve().parent.parent;out=[]
for p in sorted((P/'public-cli-property/baseline').glob('*-pack.json')):
 new=json.loads(p.read_text())[0];old=json.loads((P/'public-cli/baseline'/p.name).read_text())[0]
 def flat(x):return {c['id']:c for v in x['slots'].values() for c in v['candidates']}
 a,b=flat(new),flat(old);case=p.name.replace('-pack.json','')
 c1=json.loads((P/'public-cli/inputs'/case/'authorial-core.json').read_text());c2=json.loads((P/'public-cli-property/inputs'/case/'authorial-core.json').read_text())
 oldanchors=c1['intent_lock']['semantic_anchors'];newanchors=c2['intent_lock']['semantic_anchors'];c2['intent_lock']['semantic_anchors']=oldanchors
 out.append({'case':case,'id_sets_equal':set(a)==set(b),'slot_sets_equal':set(new['slots'])==set(old['slots']),'all_public_candidate_content_equal_except_applicability': all({k:v for k,v in c.items() if k!='applicability'}=={k:v for k,v in b[id].items() if k!='applicability'} for id,c in a.items()),'only_added_core_anchors':c1==c2 and newanchors[:len(oldanchors)]==oldanchors,'added_anchors':newanchors[len(oldanchors):], 'status_changes':[{'id':id,'before':b[id]['applicability'],'after':c['applicability']} for id,c in a.items() if b[id]['applicability']!=c['applicability']],'remaining_eligible_count':sum(c['applicability']['status']=='eligible' for c in a.values()),'train_directions':[c for c in new['slots'].get('camera_direction',{}).get('candidates',[])] if case=='blind_scene_006' else []})
(P/'missing-slot-diagnosis/qualified-comparison.json').write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n')
print('cases',len(out),'sets unchanged',sum(x['id_sets_equal'] for x in out),'status changes',sum(len(x['status_changes']) for x in out),'new anchors',sum(len(x['added_anchors']) for x in out),'only added anchors',all(x['only_added_core_anchors'] for x in out))
