"""Read-only production retrieval trace; no provider calls, no corpus/runtime edits."""
import sys,json,inspect,collections
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];REPO=ROOT/'image-prompt';BASE=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(REPO/'skills/photo-prompt-image-generator/scripts'))
import prompt_generator as pg
D=pg.load_runtime_data();out=[]
source,start=inspect.getsourcelines(pg.retrieve_core_slots)
cutline=start+next(i for i,l in enumerate(source) if 'if (not broad or not focal) and not observed:' in l)
for n in [1,7,9,10,11,12]:
 case=f'blind_scene_{n:03d}'; p=BASE/'public-cli-property/inputs'/case
 controls=json.loads((p/'creative-controls.json').read_text()); envelope=pg.normalize_request_envelope(json.loads((p/'request-envelope.json').read_text()));core=pg.normalize_authorial_core(json.loads((p/'authorial-core.json').read_text()),request_envelope=envelope,creative_control_snapshot=controls)
 stages=[]
 def trace(frame,event,arg):
  if frame.f_code is pg.retrieve_core_slots.__code__ and event=='line' and frame.f_lineno==cutline:
   v=frame.f_locals;stages.append({'slot':v['slot'],'before_total':v['total'],'limit':v['limit'],'eligible':len(v['entries']),'broad':v['broad'],'focal':v['focal'],'observed':v['observed'],'observed_count':len(v['observed'])})
  return trace if frame.f_code is pg.retrieve_core_slots.__code__ else None
 sys.settrace(trace)
 try: slots,binding,contract=pg.retrieve_core_slots(D,core,controls)
 finally:sys.settrace(None)
 targets=['surface_material','texture'] if n>=9 else ['focus'] if n==7 else ['light_direction']
 details={}
 for slot in targets:
  query,fields=pg.core_slot_focus_text(D,core,slot);_,picked=pg.frozen_core_context(D,core,controls); entries=D['slots'].get(slot,[])
  details[slot]={'corpus_count':len(entries),'applicability_policy':pg.slot_applicability_policy(D,slot),'ownership':pg.photo_candidate_semantics.slot_dimensions(slot,D.get('candidate_semantic_policy')),'query':query,'query_fields':fields,'slot_block_reason':pg.slot_block_reason(D,slot,contract),'eligible_count':sum(pg.core_slot_entry_eligible(D,core,contract,picked,slot,e) for e in entries),'stage':next((s for s in stages if s['slot']==slot),None),'returned_count':len(slots.get(slot,{}).get('candidates',[]))}
 pack=json.loads((BASE/'public-cli-property/baseline'/f'{case}-pack.json').read_text())[0]
 out.append({'case':case,'subject_category':contract['subject_category'],'subject_categories':contract['intent_constraints']['subject_categories'],'domains':contract['domains'],'targets':details,'stages':stages,'returned_total':sum(len(s['candidates']) for s in slots.values()),'production_returned_ids':{s:[c['id'] for c in v['candidates']] for s,v in slots.items()},'saved_public_ids':{s:[c['id'] for c in v['candidates']] for s,v in pack['slots'].items()},'public_order_contract':pack.get('authorial_composition',{}).get('candidate_order')})
 print(case,[(s,d['slot_block_reason'],d['eligible_count'],d['stage']['before_total'] if d['stage'] else None,d['returned_count']) for s,d in details.items()],flush=True)
(Path(__file__).parent/'qualified-trace.json').write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n')
