# Qualified property-anchor arm: read-only comparison

This adds evidence without replacing REPORT.md or the first-arm traces. The comparison is between public-cli/baseline and public-cli-property/baseline at the same repository HEAD6c2cc0f9. No source/corpus/runtime changes or paid API calls were made.

## Findings

- All12 public packs have exactly the same slot sets and candidate ID sets as the first arm, with64 candidate occurrences each.
- Candidate content keyed by ID is identical except applicability. Across all12 packs, **22 candidate occurrences** change from eligible/frozen_core_slot_contract to ineligible/authored_property_scope with reason “effect overlaps a protected requester property.” Counts by case001–012: 2,1,2,1,2,2,2,2,2,3,1,2.
- Independently compared the input core JSONs: the only changes are **30 additional semantic anchors**. Original anchors remain intact and in order; all other fields are unchanged. This verifies the reported bounded change without making a broader claim about how the author worked.
- Replayed the critical six cases001,007,009–012 through production retrieve_core_slots. Every recorded target query, ownership, category/applicability result, raw ranking list/score, observation hit, slot budget state, and raw production candidate ID order is exactly equal to the first-arm trace. The original missing-slot causes therefore remain unchanged, now under qualified requester-property metadata.

## Train directions: still eligible

Case006 protects camera/viewpoint.height_and_direction, toy_train/projection.relative_size, and ceiling/visibility.above_train with literal frozen-baseline evidence. Nevertheless all four returned camera_direction rows retain eligible/frozen_core_slot_contract:

- strict_top_down_flat_view
- birds_eye
- dutch_tilt_dynamic_view
- mirror_reflection_camera_view

The first two directly oppose the required below-shelf upward view. Dutch tilt and mirror view are off-request alternatives and do not establish the required relation; they should not be called necessarily contradictory in every possible implementation. **None of the four is reclassified ineligible by the new property anchors.**

Exact reason: all four authored rows in photo_prompt_tags.json omit affected_properties. `photo_candidate_semantics.semantic_source` (219–233) inherits affected_dimensions=[camera] from ownership but only copies affected_properties when the source entry actually contains it. `build_candidate_pack` (10381–10395) invokes the property-effect eligibility annotation only under `if "affected_properties" in source`. The legacy rows bypass that call entirely. They retain the earlier frozen-core-slot eligibility, which denotes category/context admission, not a demonstrated match to the requested camera relation.

The guard itself is conservative: `photo_contracts.property_effects_allowed` (59–90) returns false for missing/unknown effects under partial locks, and false for an empty effect list when the candidate affects the protected camera dimension. A direct, non-mutating probe confirms false for all four rows with either None or []. This is a **guard-invocation/metadata-coverage distinction**, not absence of the new user property anchors.

The22 changed occurrences prove that the current path honors the new locks for candidates with explicit effect metadata. The unchanged legacy directions prove that this protection is not uniformly applied to ordinary slot candidates. Being marked ineligible signals guard overlap/unknown scope, not an independently reviewed semantic contradiction; the22 should not be scored as22 definitely wrong suggestions.

## Missing specialized targets remain explained

- surface_material009–012: subject_category=generic, subject_categories=[], allowed-category mismatch, zero eligible entries
- texture009–012:104 eligible; broad12/focal12/observed0; total64 before admission
- focus007:25 eligible; broad12/focal12/observed0; total64 before admission
- light_direction001:17 eligible; broad12/focal0/observed0; setting-only query “Garden table at sunrise”; total64 as a secondary barrier

Adding partial property anchors does not revise category routing, query field projection, slot ordering or shared budget. This is why it changes candidate applicability after retrieval without fixing those absences.

## Scope implications, not an implemented fix

The first-arm caution about permissive requester metadata has now been narrowed by this qualified arm. It is no longer enough to attribute train direction eligibility solely to missing requester-property anchors. Protection is bounded by source effect metadata and the runtime condition that only checks explicitly annotated candidates.

Adding truthful affected_properties to legacy corpus rows would be a structured candidate-semantics migration, not a lexical label/alias change. It must describe the real effects of each row, use reviewed property/target vocabulary, and test effects across unrelated requests; adding a case-specific property string just to make this test pass would be invalid. Changing the runtime to treat missing effects conservatively would expand Python scope and potentially mark broad inventories ineligible. Neither change is performed or recommended without explicit scope and tradeoff review. The budget/category/focal-query repair boundaries remain those in REPORT.md.

## Evidence files

- compare_qualified.py and qualified-comparison.json: all12 input/candidate/status comparisons, all30 added anchors, exact22 status changes, and full train direction records
- qualified_probe.py and qualified-trace.json: unchanged production six-case retrieval trace from qualified inputs
- qualified-train-guard.json: actual eligible states versus direct pure guard results for missing/empty effects
- Original REPORT.md, probe.py, trace.json, summary.json remain untouched by this addendum
