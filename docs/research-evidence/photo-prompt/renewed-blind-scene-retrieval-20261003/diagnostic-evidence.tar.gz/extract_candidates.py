import json,hashlib
from pathlib import Path
P=Path(__file__).parent;x=json.load(open(P/'inputs-normalized.json'));targets={c['case']:c['target_slots'] for c in json.load(open(P/'target-slots.json'))['cases']};families=json.load(open(P/'supplementary-slot-families.json'))['families'];out=[]
for c in x['cases']:
 p=json.load(open(P/'public-cli/baseline'/(c['case_id']+'-pack.json')))[0];selected={}
 for slot in families[c['category']]:
  if slot not in p['slots']:continue
  s=p['slots'][slot];selected[slot]={'returned_count':len(s['candidates']),'leading_candidates':[{'rank':i+1,**v}for i,v in enumerate(s['candidates'][:3])]}
 out.append({'case_id':c['case_id'],'category':c['category'],'request':c['request'],'baseline':c['baseline_photograph_prompt'],'gold':c['gold'],'nearby_wrong_interpretations':c['nearby_wrong_interpretations'],'predeclared_target_slots':targets[c['case_id']],'missing_predeclared_slots':[s for s in targets[c['case_id']] if s not in p['slots']],'supplementary_family_slots':selected,'active_slot_names':list(p['slots']),'retrieval_metadata':p.get('core_retrieval',{})})
(P/'candidate-review-input.json').write_text(json.dumps({'method':'Predeclared narrow slots plus separately labeled exploratory family coverage; order is returned public pack order, not assumed raw rank.','cases':out},ensure_ascii=False,indent=2)+'\n')
print('extracted',len(out),'cases',sum(len(v['leading_candidates'])for c in out for v in c['supplementary_family_slots'].values()),'leading candidate rows')
