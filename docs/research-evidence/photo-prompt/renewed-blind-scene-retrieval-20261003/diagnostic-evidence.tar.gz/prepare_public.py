import json,hashlib,sys
from pathlib import Path
P=Path(__file__).parent;R=P.parent.parent/'image-prompt';sys.path[:0]=[str(R),str(R/'skills/photo-prompt-image-generator/scripts')]
import prompt_generator as pg
from tests import photo_prompt_fixtures as f
src=P/'inputs-normalized.json';x=json.loads(src.read_text());cases=x['cases'];manifest=[];failures=[]
for c in cases:
 try:
  q=c['request'];b=c['baseline_photograph_prompt'];controls=pg.creative_controls.resolve(q,overrides={'sensual':0,'fetish':0,'creativity':1,'surreal':0},context={'subject_category':'nonhuman','no_people':False,'explicit_nonsexual':False},seed=829)
  a=c['anchor_evidence'];core=f.core(q,interpreted_intent=c['gold'],subject=c['subject'],setting=c['setting'],event=c['event'],visual_priorities=tuple(c['visual_priorities']),baseline_prompt_en=b,anchor_evidence=tuple(a[k] for k in ['concept','subject','event']))
  assert core['baseline_prompt_en']==b,'fixture must not add words to frozen baseline'
  core['style']={'domain':'general_photo','family':'independently authored scene study','evidence':c['visual_priorities']}
  core['creative_controls_sha256']=controls['canonical_sha256'];core['variation_key']=c['case_id'];env=f.envelope(q);env['request_id']=c['case_id']
  review={'contract_version':'photo-embodiment-review/v1','provenance':'agent_prepack','prompt_sha256':hashlib.sha256(b.encode()).hexdigest(),'scope':'not_applicable','summary':'Independent static object scene; no specified biomechanical body action requiring body-action review. No rendered-image assessment is claimed.','checks':{}}
  norm=pg.normalize_authorial_core(core,request_envelope=pg.normalize_request_envelope(env),creative_control_snapshot=controls);pg.photo_embodiment.build_policy(norm,review)
  d=P/'public-cli/inputs'/c['case_id'];d.mkdir(parents=True,exist_ok=True)
  for key,v in [('request-envelope',env),('authorial-core',core),('creative-controls',controls),('embodiment-review',review)]: (d/(key+'.json')).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
  manifest.append({'case':c['case_id'],'seed':829,'category':c['category'],'inputs':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(d.glob('*.json'))}})
 except Exception as e: failures.append({'case':c['case_id'],'type':type(e).__name__,'error':str(e)})
(P/'public-cli').mkdir(exist_ok=True);(P/'public-cli/frozen-input-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');(P/'preflight.json').write_text(json.dumps({'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'prepared':len(manifest),'failures':failures},ensure_ascii=False,indent=2)+'\n');print(json.dumps({'prepared':len(manifest),'failures':failures},ensure_ascii=False,indent=2))
