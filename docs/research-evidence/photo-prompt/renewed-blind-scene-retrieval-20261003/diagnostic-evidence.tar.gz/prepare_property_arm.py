import json,hashlib,sys,copy
from pathlib import Path
P=Path(__file__).parent;R=P.parent.parent/'image-prompt';sys.path.insert(0,str(R/'skills/photo-prompt-image-generator/scripts'));import prompt_generator as pg
A=json.load(open(P/'property-anchors.json'));assert hashlib.sha256((P/'inputs-normalized.json').read_bytes()).hexdigest()==A['source']['sha256']; anchors={c['case_id']:c['property_anchors']for c in A['cases']}; manifest=[];failures=[]
for c in json.load(open(P/'public-cli/frozen-input-manifest.json')):
 try:
  n=c['case'];I=P/'public-cli/inputs'/n;D=P/'public-cli-property/inputs'/n;D.mkdir(parents=True,exist_ok=True);data={k:json.load(open(I/(k+'.json')))for k in ['request-envelope','authorial-core','creative-controls','embodiment-review']};before=copy.deepcopy(data['authorial-core']);data['authorial-core']['intent_lock']['semantic_anchors'].extend(anchors[n])
  core=data['authorial-core'];norm=pg.normalize_authorial_core(core,request_envelope=pg.normalize_request_envelope(data['request-envelope']),creative_control_snapshot=data['creative-controls']);pg.photo_embodiment.build_policy(norm,data['embodiment-review'])
  assert core['baseline_prompt_en']==before['baseline_prompt_en'];assert core['source_request']==before['source_request'];assert core['intent_lock']['semantic_anchors'][:len(before['intent_lock']['semantic_anchors'])]==before['intent_lock']['semantic_anchors']
  for k,v in data.items():(D/(k+'.json')).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
  manifest.append({**c,'added_property_anchor_count':len(anchors[n]),'inputs':{p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in sorted(D.glob('*.json'))}})
 except Exception as e:failures.append({'case':c['case'],'error':str(e)})
(P/'public-cli-property/frozen-input-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');(P/'property-preflight.json').write_text(json.dumps({'prepared':len(manifest),'failures':failures,'only_core_delta':'request-grounded partial property anchors; all text/controls/existing anchors preserved'},indent=2)+'\n');print(len(manifest),failures)
assert len(manifest)==12 and not failures
