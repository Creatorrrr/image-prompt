import sys,os,json,hashlib,subprocess,time
from pathlib import Path
O=Path(__file__).parent;R=O.parents[2]/'image-prompt';D=O/'baseline';D.mkdir(exist_ok=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.load(open(O/'frozen-input-manifest.json'));paths=['skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations.json','skills/photo-prompt-image-generator/assets/photo_prompt_visual_profile_index.json','skills/photo-prompt-image-generator/assets/photo_prompt_tags.json','skills/photo-prompt-image-generator/scripts/prompt_generator.py','skills/photo-prompt-image-generator/scripts/generate_photo_prompt.py']
meta={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'status':subprocess.check_output(['git','status','--short'],cwd=R,text=True),'hashes':{p:sha(R/p)for p in paths},'provider_calls':0,'cases':[]};assert not meta['status']
for c in manifest:
 n=c['case'];I=O/'inputs'/n
 for f,h in c['inputs'].items():assert sha(I/f)==h
 cmd=[sys.executable,str(R/'skills/photo-prompt-image-generator/scripts/generate_photo_prompt.py'),'--seed',str(c['seed'])]
 for arg in ['request-envelope','authorial-core','creative-controls','embodiment-review']:cmd+=['--'+arg+'-json',str(I/(arg+'.json'))]
 out=D/(n+'-pack.json');cmd+=['--output-file',str(out)];t=time.time();p=subprocess.run(cmd,cwd=R,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','GEMINI_API_KEY':'','GOOGLE_API_KEY':''},capture_output=True,text=True,timeout=300)
 (D/(n+'.stdout')).write_text(p.stdout);(D/(n+'.stderr')).write_text(p.stderr)
 row={'case':n,'exit_code':p.returncode,'duration_seconds':time.time()-t,'command':cmd};meta['cases'].append(row)
 if not p.returncode:
  pack=json.load(open(out))[0];row['pack_sha256']=sha(out);assert pack['authorial_core']['baseline_prompt_en']==json.load(open(I/'authorial-core.json'))['baseline_prompt_en'];row['baseline_preserved']=True
 print(n,p.returncode,flush=True);(D/'manifest.json').write_text(json.dumps(meta,indent=2)+'\n')
assert all(sha(R/p)==h for p,h in meta['hashes'].items());assert all(c['exit_code']==0 for c in meta['cases']);print('All 12 public cases complete; source and frozen inputs preserved',flush=True)
