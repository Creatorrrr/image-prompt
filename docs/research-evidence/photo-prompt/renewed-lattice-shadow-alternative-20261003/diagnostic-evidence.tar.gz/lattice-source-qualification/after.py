#!/usr/bin/env python3
"""Separately authorized frozen AFTER; inputs and original BEFORE runner remain unchanged."""
from qualify import *
def assert_source(man):
 pin=read(P/'after-source-pin.json')
 changed=[f for f,h in pin['source_files'].items()if sha((R/f).read_bytes())!=h]
 if changed:
  dump(P/'after-concurrent-source-drift.json',{'changed_files':changed,'head':git('rev-parse','HEAD')})
  raise AssertionError('Unexpected source/runtime/index delta: '+str(changed))
 assert all(sha((P/f).read_bytes())==h for f,h in man['input_hashes'].items()),'Frozen input drift'

def run(arm,stage):
 man=read(P/'manifest.json');assert all(sha((P/f).read_bytes())==h for f,h in man['input_hashes'].items()),'Frozen input drift'
 out=P/arm
 if stage=='packs' and out.exists():raise SystemExit('Refusing to overwrite prior AFTER retrieval')
 if arm!='after' or stage not in ['packs','compose']:raise SystemExit('Authorized frozen AFTER stages only')
 if stage=='packs':
  out.mkdir();dump(out/'source-state.json',{'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'status':subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True),'files':{f:sha((R/f).read_bytes())for f in man['source_files']}})
 env={k:v for k,v in os.environ.items() if not any(t in k.upper() for t in ['API_KEY','TOKEN','SECRET','CREDENTIAL'])};env['PYTHONDONTWRITEBYTECODE']='1'
 report={'arm':arm,'cases':[],'compositions':[],'scope':'Actual public V6 CLI and full-composition audit with offline deterministic lexical retrieval. Canonical source metadata only.'};packs={}
 if stage=='packs':
  for id in man['case_ids']:
   assert_source(man)
   d=P/'inputs'/id;dest=out/id;dest.mkdir();cmd=[str(R/'.venv/bin/python'),str(S/'generate_photo_prompt.py'),'--seed',str(SEED),'--request-envelope-json',str(d/'envelope.json'),'--authorial-core-json',str(d/'core.json'),'--creative-controls-json',str(d/'controls.json'),'--embodiment-review-json',str(d/'review.json'),'--output-file',str(dest/'pack.json')]
   t=time.time();p=subprocess.run(cmd,cwd=R,env=env,text=True,capture_output=True);dump(dest/'cli.json',{'command':cmd,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'seconds':time.time()-t});row={'id':id,'exit_code':p.returncode,'stderr':p.stderr}
   if p.returncode==0:
    pack=read(dest/'pack.json')[0];packs[id]=pack
    row.update(target_component_eligibility=g.candidate_pack_visual_component_match(next(p for p in g.load_visual_obligation_registry(A/'photo_prompt_visual_obligations.json')['profiles']if p['id']==PID),read(d/'envelope.json')['request_text']),contract_version=pack['contract_version'],obligation_ids=[o['id']for o in pack.get('visual_obligations',{}).get('obligations',[])],visual_concept_ids=[v['id']for v in pack.get('visual_concept_candidates',{}).get('candidates',[])],slot_candidates=[{'slot':s,'id':v['id'],'applicability':v.get('applicability')}for s,b in pack['slots'].items() for v in b.get('candidates',[])],core_retrieval_sha256=pack['core_retrieval']['canonical_sha256'],core_sha256=pack['authorial_core']['canonical_sha256'])
   report['cases'].append(row);dump(out/'report.json',report);print(arm,id,p.returncode,row.get('obligation_ids'),flush=True)
  report['stage']='public_cli_complete_before_adoption';dump(out/'report.json',report);assert_source(man);print('AFTER public retrieval complete; composition is paused pending parent notification',flush=True);return
 report=read(out/'report.json');assert report.get('stage')=='public_cli_complete_before_adoption' and not report['compositions'],'Do not repeat or overwrite composition attempts'
 assert (P/'after-reachability-notified.json').exists(),'Report actual target reachability to parent before adoption'
 packs={id:read(out/id/'pack.json')[0]for id in man['case_ids']if (out/id/'pack.json').exists()}
 for template in read(P/'compositions.json'):
  assert_source(man)
  id=template['id'];case=template['case']
  if case not in packs:continue
  pack=packs[case];core=pack['authorial_core'];lock=core['intent_lock'];c=read(P/'inputs'/case/'spec.json');prompt=template['prompt']
  chosen=[CID]if template.get('select_target_if_publicly_exposed')else[]
  exposed=[v['id']for v in pack.get('visual_concept_candidates',{}).get('candidates',[])]
  if chosen and CID not in exposed:
   report['compositions'].append({'id':id,'case':case,'status':'not_run_target_not_exposed','chosen_visual_concept_ids':[],'purpose':template['purpose']});dump(out/'report.json',report);continue
  composed={'core_retrieval_sha256':pack['core_retrieval']['canonical_sha256'],'pack_id':pack['pack_id'],'prompt_en':prompt,'negative_en':pack['negative_en'],'chosen_candidate_ids':[],'chosen_visual_concept_ids':chosen,'composer':'agent','candidate_interpretations':[],'authorial_core_binding':{'source_authorial_core_sha256':core['canonical_sha256'],'source_intent_lock_sha256':lock['canonical_sha256'],'preserved_anchor_ids':[a['anchor_id']for a in lock['semantic_anchors']],'preserved_evidence':[],'authorial_decisions':[]},'semantic_clarification_decisions':[{'clarification_id':r['id'],'decision':'applied' if r.get('required_in_final_prompt') else 'rejected','rationale':'Preserve frozen requested architectural meaning and decline optional reinterpretation.','prompt_evidence':lock['semantic_anchors'][0]['prompt_evidence']}for r in pack.get('semantic_clarification',{}).get('candidates',[])],'creative_augmentation_brief':{'decisions':[{'candidate_id':r['id'],'decision':'rejected','rationale':'The complete requested architectural scene needs no optional augmentation.'}for r in pack.get('creative_augmentation',{}).get('candidates',[])]},'embodiment_review':{'source_contract_sha256':pack['embodiment_preflight']['canonical_sha256'],'review':review(prompt,c,'agent_postcomposition')}}
  if c['profile'] or chosen:composed['visual_obligation_evidence']={PID:template['bindings']}
  dest=out/'compositions'/id;dump(dest/'composed.json',composed)
  # Isolate evidence checks using the same real CLI pack and exact full composed input.
  direct=audit.audit_visual_obligations(pack,composed,prompt);dump(dest/'direct-visual-evidence.json',{'failures':direct,'status':'pass'if not direct else 'fail'})
  cmd=[str(R/'.venv/bin/python'),str(S/'audit_composed_prompt.py'),'--pack',str(out/case/'pack.json'),'--composed',str(dest/'composed.json')];p=subprocess.run(cmd,cwd=R,env=env,text=True,capture_output=True);dump(dest/'cli.json',{'command':cmd,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr})
  try:result=json.loads(p.stdout)
  except Exception:result={'status':'error','failures':[{'reason':p.stderr}]}
  dump(dest/'audit.json',result);report['compositions'].append({'id':id,'case':case,'status':result['status'],'expected':template['expected_after' if arm.startswith('after')else'expected_before'],'failures':result['failures'],'direct_visual_failures':direct,'warnings':result.get('warnings',[]),'chosen_candidate_ids':[],'chosen_visual_concept_ids':chosen,'semantic_claim_limit':'Deliberately contradictory invalid evidence is a parser boundary probe, not a coherent final scene'if template.get('contradictory_content')else'Canonical source-aware contract qualification'})
  dump(out/'report.json',report);print(id,result['status'],[(r.get('check'),r.get('field'))for r in result['failures']],flush=True)
 assert_source(man)
 dump(out/'ending-source-state.json',{'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'status':subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True),'files':{f:sha((R/f).read_bytes())for f in man['source_files']}})
 report['stage']='complete';dump(out/'report.json',report);print('Completed',arm,flush=True)

if __name__=='__main__':run('after',sys.argv[1])
