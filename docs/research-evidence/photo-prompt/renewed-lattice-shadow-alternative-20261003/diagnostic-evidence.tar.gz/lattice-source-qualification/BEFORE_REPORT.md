# Frozen lattice DATA qualification: BEFORE

## Result

BEFORE is complete and paused. Exactly one target profile is qualified: `patterned_cast_shadow_receiver_continuity`. The reviewed four-string source proposal was not applied.

- All 11 actual public `generate_photo_prompt.py` executions returned valid `photo-candidate-pack/v6` packs
- All 26 executed full `audit_composed_prompt.py` audits matched their frozen expected outcomes: 12 pass and 14 deliberate failure
- Two lattice optional-adoption templates were not executed because their actual public packs did not expose the target. The harness never injected a missing candidate or fabricated a contract
- Source, runtime, top-level source manifests, and genuine visual profile index remained byte-identical during the complete run; no source, index, runtime, test, or git state was changed by this worker
- No provider calls, query embeddings, image generation, external APIs, publication, or AFTER run

## Measured BEFORE behavior

### Eligibility, public exposure, and adoption are separate

`before/component-eligibility.json` measures the production component helper against the real BEFORE source. Complete canonical all-English and all-Korean legacy leaf/slat chains match. Complete canonical all-English and all-Korean lattice chains do not match. Removing each of the five components from each of those four chains yields 20 nonmatches. The Korean diagnostic is entirely Korean, rather than one Korean component inside an English chain.

`before/eligibility-exposure-adoption.json` records the independent public boundary:

- Exact EN and all-Korean lattice requests both activate the target's real hard profile. Their complete final compositions each fail on exactly one item: `pattern_occluder_phrase` lacks the declared lattice anchor. There are no confounding word-budget, overlap, crop-binding, preflight, or other composition failures
- Exact leaf and slat requests retain the legacy contract and pass complete composition audits
- Component-only EN and all-Korean lattice requests remain non-hard, fail the target component precondition, and do not expose the target visual concept. Their no-adoption compositions pass. Frozen optional selection templates are recorded as not run, because the target was unavailable
- Component-only EN and all-Korean legacy requests remain non-hard but qualify and expose the real target visual concept. No-adoption compositions pass; separate scripted opt-ins select that exact exposed candidate and pass the full promoted-obligation composition audit
- The ordinary printed-motif, flat-overlay, and insufficient-receiver requests remain target-non-hard, target-non-exposed, and unadopted. Each coherent authored scene passes its complete composition audit without being repaired into a cast-shadow scene

Other optional visual concepts appeared in some packs and were preserved in the evidence logs. None were selected. Their presence is outside this one-profile DATA recovery claim.

### All five relations, source ownership, and crop

Every valid positive baseline already describes a coherent directional source, one identified occluding mechanism, alternating bright/dark structure, deformation with receiver curvature/depth, and continuity across two physically connected receiving regions. Both receivers and the uninterrupted join remain inside one frame. The same source and occluder own the whole pattern. These are unoccupied architectural scenes; body-action reviews are correctly not applicable.

Each positive baseline was fully authored and frozen before its CLI pack existed. New candidate wording was not used to invent absent mechanisms. Canonical evidence strings were deliberately prepared from reviewed source data as synthetic contract probes, while the complete physical relations already appeared in the baseline. The leaf/slat literal disjunction retains its existing canonical wording; the explicit scene fixes one physical branch.

The optical reviews are in every frozen input's `optical-review.json`. They are prose consistency reviews, not rendered geometry measurements. `before/source-projection-proof.json` verifies that every actual hard or exposed target opt-in contract equals the genuine production projection, including all five required component groups, five evidence fields, five render gates, and unchanged ownership, observability, crop and occlusion metadata. No proposed source was bound to the old index.

### Hard-profile missing and malformed probes

A valid legacy hard-profile pack anchors these deliberately invalid composition probes:

- All five missing evidence-field cases reject, including the missing-field and insufficient-distinct-evidence checks
- Replacing one required relation with a printed motif, competing source directions, a uniform dark wash, a flat overlay, or one isolated receiver rejects at the intended field's declared-anchor check
- A bound occluder phrase absent from prompt text rejects at the literal prompt-binding check

Malformed probes deliberately disagree with their valid baseline and are labelled as parser-boundary tests. They are not presented as coherent ordinary negative photographs. The coherent ordinary controls are separate requests and packs.

## Unchanged runtime limitation: literal negated anchors

The complete legacy composition containing `It is not true that` followed by the valid canonical occluder anchor **passes the full BEFORE audit**. This reproduces the literal checker's inability to establish semantic affirmation or physical truth merely from anchor membership. The analogous lattice probe fails BEFORE only because the lattice anchor is absent. No runtime fix or AFTER result is claimed.

The DATA recovery must not be reported as unrestricted contradiction detection, real source ownership verification, physical geometry success, or pixel success. The five unchanged image render gates remain necessary in any separately authorized image qualification.

## Frozen provenance and first attempts

- Baseline and execution HEAD: `978f38defbc70ea47dbd028af47baf701eada1bd`
- Frozen input manifest SHA-256: `365017b5dced44dfe80c0bccfcc8be978831667947d22d45d7b38a7c8b7dd713`
- Target BEFORE canonical source profile: `87e318b6f31dce32bc451bded7c9a730b28e70c8ad4a8a2fc7884df9ba2a8cc9`
- Genuine visual profile index file: `00c781887527c4cbc31f1dcbbf6db52fa72531aa6406f6f1d5d61b51b74f3317`
- `prompt_generator.py`: `0f0c2e6ff6a069e28d96b86857aa9553674f9c5e5996b4f032e055805e624ce4`
- `audit_composed_prompt.py`: `c41619e6293961c7edaddc049d4056538d24fa27391fec08fd20caf89ff95cf5`

The complete runtime/source hashes are in `manifest.json` and `before/index-and-runtime-pin.json`; runtime files are also preserved under `runtime-freeze/`. Start/end source states and the actual genuine index entry are retained. All input hashes were frozen before any V6 CLI execution and revalidated after the run.

Preparation attempt 01 failed on a diagnostic helper-name typo before fixtures were created. Its original script is preserved. Preflight attempt 01 passed 8 cases and rejected the 3 ordinary controls because their subject binding contained only the word “wall.” The corrected preflight uses concrete receiver phrases already present in the unchanged requests/baselines. It passed all 11 before freezing. Both complete preflight attempts are preserved; no failed preflight was forced through. An early finalizer correctly refused to complete while the CLI process was still running. `diagnostic-log.md` records these events. Every actual first CLI/audit result remains intact.

## Scope and next condition

This is an explicitly source-aware synthetic DATA qualification, not a clean independent pre-core trial, natural-query recall study, natural composer adoption study, or rendered-image test. All-Korean refers to the requester text and component chains; the production baseline/composed prompt contract is English.

Only BEFORE was authorized and performed. The runner refuses AFTER. Before any later AFTER, the parent must authorize it and reconcile runtime/source hashes. If a separately coordinated runtime edit lands, rerun the same frozen inputs against unchanged lattice DATA on that runtime before applying the four-string patch, or explicitly separate runtime and DATA effects. A docs-only HEAD change is not runtime drift when the pinned source/runtime/index bytes match. Any source application needs a genuine changed-text profile index refresh; this task did neither.

## Main deliverables

- `SUMMARY.json`: concise measured counts, hashes and paused state
- `manifest.json`, `inputs/`, `compositions.json`: frozen run inputs and hashes
- `before/report.json`: all actual public CLI and full-composition outcomes
- `before/component-eligibility.json`: complete EN/Korean chains and 20 omission controls
- `before/eligibility-exposure-adoption.json`: separated eligibility, observed exposure, real selection, and effective-gate outcomes
- `before/source-projection-proof.json`: actual source-to-public-contract equivalence
- `before/index-and-runtime-pin.json`: genuine index validation and exact runtime pin
- `preflight/`, `diagnostic-log.md`, `before-run.log`: preserved attempts and execution history
- `source-freeze/`: unchanged independent review and accepted source proposal
