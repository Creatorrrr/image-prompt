"""Finalize measured BEFORE evidence without touching source or replacing first attempts."""
import importlib.util,json
from pathlib import Path
P=Path(__file__).parent
spec=importlib.util.spec_from_file_location('qualify',P/'qualify.py');q=importlib.util.module_from_spec(spec);spec.loader.exec_module(q)
man=q.read(P/'manifest.json');q.assert_source(man)
assert all(q.sha((P/f).read_bytes())==h for f,h in man['input_hashes'].items())
assert (P/'before/ending-source-state.json').exists(),'Run has not finished'
r=q.read(P/'before/report.json');assert len(r['cases'])==11 and len(r['compositions'])==28
assert all(x['exit_code']==0 and x['contract_version']=='photo-candidate-pack/v6'for x in r['cases'])
profile=q.read(P/'source-freeze/baseline-materialized-profile.json');reg=q.g.load_visual_obligation_registry(q.A/'photo_prompt_visual_obligations.json');index=q.g.load_visual_profile_index(q.A/'photo_prompt_visual_profile_index.json',reg)
projection=[];exposure=[];effective=[]
for case in r['cases']:
 pack=q.read(P/'before'/case['id']/'pack.json')[0]
 for ob in pack.get('visual_obligations',{}).get('obligations',[])+[c['opt_in_contract']['obligation']for c in pack.get('visual_concept_candidates',{}).get('candidates',[])if c['id']==q.CID]:
  if ob['id']!=q.PID:continue
  act=ob['activation'];expected=q.g.candidate_pack_visual_profile_obligation(profile,reg,activation_source=act['source'],source_intent_ids=act['source_intent_ids'])
  checks={'entire_projected_obligation_matches_production_source':ob==expected,'five_components_required':ob['component_semantics']['minimum_component_groups']==5 and len(ob['component_semantics']['required_group_ids'])==5,'five_evidence_fields':len(ob['prompt_binding']['required_evidence_fields'])==5,'five_render_gates':len(ob['render_gates'])==5,'visual_relation_ownership_crop_occlusion_unchanged':ob['visual_relation']==profile['visual_relation']}
  assert all(checks.values()),(case['id'],checks)
  projection.append({'case':case['id'],'activation_source':act['source'],'obligation_canonical_sha256':q.canon(ob),'checks':checks})
 exposure.append({'case':case['id'],'component_helper_eligible':case['target_component_eligibility']is not None,'public_target_hard':q.PID in case['obligation_ids'],'public_target_optional':q.CID in case['visual_concept_ids'],'public_target_slot_ids':[v['id']for v in case['slot_candidates']if q.PID in v['id']],'all_public_visual_concept_ids':case['visual_concept_ids'],'claim':'Public exposure is observed independently of helper eligibility; incidental other-profile candidates are not selected.'})
for row in r['compositions']:
 if row['status']=='not_run_target_not_exposed':continue
 assert row['status']==row['expected'],row
 d=P/'before/compositions'/row['id'];comp=q.read(d/'composed.json');pack=q.read(P/'before'/row['case']/'pack.json')[0]
 eff,errors=q.audit.derive_effective_visual_obligation_contract(pack,comp)
 assert not errors,errors
 checked=dict(pack)
 if eff:checked['visual_obligations']=eff
 else:checked.pop('visual_obligations',None)
 fail=q.audit.audit_visual_obligations(checked,comp,comp['prompt_en'])
 effective.append({'composition':row['id'],'target_adopted':q.CID in comp['chosen_visual_concept_ids'],'target_required_from_request':q.PID in[x['id']for x in pack.get('visual_obligations',{}).get('obligations',[])],'target_effective':q.PID in[x['id']for x in(eff or{}).get('obligations',[])],'effective_gate_ids':(eff or{}).get('required_hard_gates',[]),'effective_direct_evidence_failures':fail,'full_composition_status':row['status'],'full_failures':row['failures'],'claim':'Scripted source-aware opt-in is an audit capability check, not natural composer uptake.'})
q.dump(P/'before/source-projection-proof.json',projection)
q.dump(P/'before/eligibility-exposure-adoption.json',{'exposure':exposure,'composition_adoption':effective,'not_run':[x for x in r['compositions']if x['status']=='not_run_target_not_exposed'],'known_runtime_limitation':'Negated canonical anchors pass the literal checker when the anchor exists. Legacy negation passes the full BEFORE audit. Lattice negation fails BEFORE only because its anchor is absent. No AFTER has been run.'})
assert q.read(P/'before/source-state.json')['files']==q.read(P/'before/ending-source-state.json')['files']==man['source_files']
assert len([x for x in r['compositions']if x['status']=='not_run_target_not_exposed'])==2
exact=[x for x in r['compositions']if x['id']in['lattice_en','lattice_ko']]
assert all(len(x['failures'])==1 and x['failures'][0]['field']=='pattern_occluder_phrase'for x in exact)
summary={'status':'BEFORE_COMPLETE_PAUSED','head':q.git('rev-parse','HEAD'),'frozen_input_manifest_sha256':q.sha((P/'manifest.json').read_bytes()),'source_runtime_hashes_unchanged_during_run':True,'full_v6_cli_cases':11,'full_v6_cli_passes':11,'composition_templates':28,'executed_full_composition_audits':26,'expected_audit_outcomes':26,'non_exposed_lattice_opt_ins_not_run':2,'lattice_exact_failures':'EN and all-Korean requests each fail only the missing lattice occluder anchor','legacy_exact_controls':'leaf and slat pass','legacy_optional_opt_ins':'EN and Korean eligibility/public exposure/actual synthetic adoption pass','near_negative_controls':'printed motif, flat overlay and insufficient receiver all remain non-hard, target non-exposed, unadopted and pass as their coherent authored scenes','missing_fields_reject':5,'malformed_relations_reject':5,'nonliteral_binding_reject':1,'negated_legacy_anchor_full_audit_pass_known_runtime_limitation':True,'all_component_omissions_reject':20,'provider_calls':0,'repository_edits':False,'after_run':False,'source_profile_canonical_sha256':q.canon(q.read(P/'source-freeze/before-profile.json')),'index_file_sha256':q.sha((q.A/'photo_prompt_visual_profile_index.json').read_bytes()),'runtime_prompt_generator_sha256':q.sha((q.S/'prompt_generator.py').read_bytes()),'runtime_audit_composed_prompt_sha256':q.sha((q.S/'audit_composed_prompt.py').read_bytes())}
q.dump(P/'SUMMARY.json',summary)
print(json.dumps(summary,indent=2))
