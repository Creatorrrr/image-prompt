#!/usr/bin/env python3
"""Frozen source-aware synthetic lattice DATA qualification; BEFORE only; no provider calls."""
from pathlib import Path
import copy, datetime, hashlib, json, os, shutil, subprocess, sys, time, traceback
sys.dont_write_bytecode=True
P=Path(__file__).resolve().parent;R=P.parent.parent/'image-prompt'
S=R/'skills/photo-prompt-image-generator/scripts';A=S.parent/'assets'
sys.path.insert(0,str(S))
import prompt_generator as g
import audit_composed_prompt as audit
PID='patterned_cast_shadow_receiver_continuity';CID='visual-concept:'+PID;SEED=2003
PIN='978f38defbc70ea47dbd028af47baf701eada1bd'
SOURCE='skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations_reactorprompt.json'
REVIEW=P.parent/'lattice-source-review'
def sha(b):return hashlib.sha256(b).hexdigest()
def canon(o):return sha(json.dumps(o,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())
def read(p):return json.loads(p.read_text())
def dump(p,o):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(o,ensure_ascii=False,indent=2)+'\n')
def git(*args):return subprocess.check_output(['git',*args],cwd=R,text=True).strip()
def anchor(id,src,ev,dim,target=None,prop=None):
 o={'anchor_id':id,'source_text':src,'prompt_evidence':ev,'dimension':dim}
 if prop:o.update(target=target,property=prop)
 return o

def review(prompt,c,phase='agent_prepack'):
 return {'contract_version':'photo-embodiment-review/v1','provenance':phase,'prompt_sha256':sha(prompt.encode()),'scope':'not_applicable','summary':'An unoccupied architectural scene contains wall surfaces and a stable light-pattern mechanism. There are no people, animals, body parts, or bodily actions. Source ownership, pattern geometry and crop continuity are separately checked in the optical scene review.','checks':{}}

def prepare():
 assert not(P/'drafts').exists(),'Refusing to overwrite first drafts'
 assert git('rev-parse','HEAD')==PIN
 patch=read(REVIEW/'frozen-patch.json');profile=next(x for x in read(R/SOURCE)['profiles']if x['id']==PID)
 assert canon(profile)==patch['before_canonical_sha256']
 for n in ['REPORT.md','frozen-patch.json','before-profile.json','accepted-profile.json','candidate-record.json','index-consequences.json','consumer-proof-independent.json']:
  d=P/'source-freeze'/n;d.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(REVIEW/n,d)
 reg=g.load_visual_obligation_registry(A/'photo_prompt_visual_obligations.json');index=g.load_visual_profile_index(A/'photo_prompt_visual_profile_index.json',reg)
 material=next(x for x in reg['profiles']if x['id']==PID)
 dump(P/'source-freeze/baseline-materialized-profile.json',material)
 dump(P/'source-freeze/actual-index-entry.json',index['entries'][PID])
 dump(P/'source-freeze/genuine-index-validation.json',{'head':PIN,'registry_profile_count':len(reg['profiles']),'registry_hash':g.visual_profile_registry_hash(reg),'index_file_sha256':sha((A/'photo_prompt_visual_profile_index.json').read_bytes()),'index_entry_canonical_sha256':canon(index['entries'][PID]),'source_profile_canonical_sha256':canon(profile),'actual_index_loaded':True,'provider_calls':0})
 proof=read(REVIEW/'consumer-proof-independent.json');old=proof['legacy_evidence'];new=proof['lattice_evidence']
 clauses={
 'source':'A single high window at camera left directs the entire shadow field down and right',
 'structure':'Bright openings alternate with distinct dark cast bands across the plaster',
 'deformation':'The pattern bends around the rounded wall corner, with spacing and edge scale changing through the shallow recess',
 'receivers':'The same cast pattern continues from the curved plaster wall onto its physically joined recessed return',
 'crop':'Both connected receiver regions and their uninterrupted patterned join remain visible together inside one continuous frame'}
 ko={'source':'왼쪽 높은 창 하나가 전체 그림자를 오른쪽 아래로 향하게 한다','structure':'밝은 틈과 분명한 어두운 투사 띠가 회벽 위에서 번갈아 보인다','deformation':'패턴은 둥근 모서리를 따라 휘고 얕은 홈의 깊이에 따라 간격과 가장자리 크기가 바뀐다','receivers':'같은 투사 패턴이 굽은 회벽에서 물리적으로 연결된 안쪽 벽면으로 이어진다','crop':'연결된 두 수신 영역과 가려지지 않은 패턴의 연결부가 연속된 한 화면 안에 함께 보인다'}
 cases=[]
 groups=profile['semantics']['component_semantics']['groups'];accepted=read(REVIEW/'accepted-profile.json')
 for lang in ['en','ko']:
  for mech in ['lattice','legacy']:
   terms=[x['any_terms'][0 if lang=='en'else 1]for x in groups]
   if mech=='lattice':terms[1]=accepted['semantics']['component_semantics']['groups'][1]['any_terms'][2 if lang=='en'else 3]
   # A pure all-one-language component chain is an independent eligibility diagnostic.
   cases.append({'id':'chain_'+mech+'_'+lang,'terms':terms,'language':lang,'mechanism':mech})
 dump(P/'component-chains.json',cases);cases=[]
 for id,mech,lang,hard in [('lattice_en','lattice','en',True),('lattice_ko','lattice','ko',True),('leaf_legacy','leaf','en',True),('slat_legacy','slat','en',True),('component_lattice_en','lattice','en',False),('component_lattice_ko','lattice','ko',False),('component_legacy_en','slat','en',False),('component_legacy_ko','slat','ko',False)]:
  occluder={'lattice':'One wooden lattice screen intercepts that light and casts its repeating intersecting bars onto the two joined plaster surfaces','leaf':'One leafy branch intercepts that light and casts its identifiable leaf-edge field onto the two joined plaster surfaces','slat':'One slatted wooden screen intercepts that light and casts its repeating parallel bars onto the two joined plaster surfaces'}[mech]
  concept={'lattice':'lattice cast field','leaf':'leaf cast field','slat':'slatted cast field'}[mech]
  base=f'A {concept} is the central subject of an unoccupied architectural photograph. A curved plaster wall joins a shallow recessed plaster return. '+'. '.join([clauses['source'],occluder,clauses['structure'],clauses['deformation'],clauses['receivers'],clauses['crop']])+'. An oblique view separates the curved wall, the recessed return and their shared corner. Fine plaster grain remains readable within the bright areas and the cast shadows. The source direction, single occluder grammar and connected receiving surfaces belong to this same room and the same moment.'
  alias='patterned cast shadow receiver continuity'if lang=='en'else'패턴 그림자 수신면 연속성'
  if not hard:
   chain=next(x for x in read(P/'component-chains.json')if x['language']==lang and x['mechanism']==('lattice'if mech=='lattice'else'legacy'))
   alias='; '.join(chain['terms'])
  if lang=='en':
   req=f'Photograph {alias}. Show a {concept} on a curved plaster wall and adjoining recessed return in an unoccupied room. '+'. '.join([clauses['source'],occluder,clauses['structure'],clauses['deformation'],clauses['receivers'],clauses['crop']])+'.'
   concept_src=alias;sub_src='curved plaster wall and adjoining recessed return';event_src=occluder
   props=[(k,clauses[k],clauses[k])for k in clauses];occ_src=occluder
  else:
   oc_ko='나무 격자 가림막 하나가 그 빛을 가로막아 연결된 두 회벽 위에 교차 막대 그림자를 만든다'if mech=='lattice'else'나무 슬랫 가림막 하나가 그 빛을 가로막아 연결된 두 회벽 위에 평행 막대 그림자를 만든다'
   req=f'{alias}. 사람이 없는 방의 굽은 회벽과 연결된 안쪽 벽면을 촬영한다. '+'. '.join([ko['source'],oc_ko,ko['structure'],ko['deformation'],ko['receivers'],ko['crop']])+'.'
   concept_src=alias;sub_src='굽은 회벽과 연결된 안쪽 벽면';event_src=oc_ko
   props=[(k,ko[k],clauses[k])for k in clauses];occ_src=oc_ko
  aa=[anchor('concept',concept_src,concept,'concept'),anchor('subject',sub_src,'A curved plaster wall joins a shallow recessed plaster return','subject'),anchor('event',event_src,occluder,'event')]
  aa += [anchor(k,src,ev,'lighting'if k!='crop'else'composition','shadow_field'if k!='crop'else'photograph',k)for k,src,ev in props]
  c=dict(id=id,request=req,baseline=base,anchors=aa,subject='one curved plaster wall and its joined recessed return',setting='one unoccupied room with joined plaster receivers',event=occluder,profile=PID if hard else None,mechanism=mech,people=False,language=lang,kind='exact_positive'if hard else'component_optional',complete_mechanism=True)
  cases.append(c)
 controls=[
  ('printed_motif','printed lattice motif','A printed lattice motif covers a curved plaster wall and its joined recessed return','Broad diffuse illumination reveals pigment fixed to the plaster, with even line widths across the wall relief','The pigment pattern remains decorative surface paint and the illumination has no intervening patterned occluder'),
  ('flat_overlay','flat decorative overlay','A flat decorative overlay lies over a photograph of a curved plaster wall and adjoining recessed return','The overlay keeps constant line width and spacing across the photographed corner and recess','Its regular grid belongs to the two-dimensional overlay rather than a cast shadow bending with the wall'),
  ('insufficient_receiver','isolated single-panel lattice shadow','An isolated single-panel lattice shadow falls on one flat square wall panel','A single high window sends light through one lattice screen onto only that isolated panel','A wide bare margin surrounds the panel and separates it from every other wall region')]
 for id,concept,event,state,boundary in controls:
  req=f'Photograph a {concept}. {event}. {state}. {boundary}. Show the complete requested arrangement inside one continuous frame in an unoccupied room.'
  base=f'A {concept} is the central subject of an unoccupied architectural photograph. {event}. {state}. {boundary}. The complete requested arrangement remains visible inside one continuous frame. An oblique camera position keeps the surface and its surrounding border easy to distinguish. A restrained neutral palette preserves fine plaster grain and local material differences without obscuring the requested pattern state.'
  aa=[anchor('concept',concept,concept,'concept'),anchor('subject','wall','wall','subject'),anchor('event',event,event,'event'),anchor('state',state,state,'lighting','pattern','source_state'),anchor('boundary',boundary,boundary,'relationship','pattern','mechanism_boundary'),anchor('crop','inside one continuous frame','inside one continuous frame','composition','photograph','crop')]
  cases.append(dict(id=id,request=req,baseline=base,anchors=aa,subject='the requested architectural pattern surface',setting='one unoccupied room with a complete visible arrangement',event=event,profile=None,mechanism=id,people=False,language='en',kind='coherent_near_negative',complete_mechanism=False))
 templates=[]
 for c in cases:
  req=c['request'];base=c['baseline'];d=P/'drafts'/c['id']
  envelope={'contract_version':'photo-request-envelope/v1','provenance':'requesting_user','request_id':'synthetic-lattice-'+c['id'],'request_text':req,'request_sha256':sha(req.encode()),'active_spans':[{'span_id':'scene','start':0,'end':len(req),'text':req}]}
  controls=g.creative_controls.resolve(req,overrides={'sensual':0,'fetish':0,'creativity':0,'surreal':0},context={'subject_category':'nonhuman','no_people':True},seed=SEED)
  core={'contract_version':'photo-authorial-core/v3','provenance':'agent_prepack','source_request':req,'creative_controls_sha256':controls['canonical_sha256'],'interpreted_intent':'A source-aware synthetic architectural qualification scene. Preserve the stated physical source, pattern mechanism, receiving geometry and frame visibility; avoid adding absent mechanisms from optional candidates.','subject':c['subject'],'setting':c['setting'],'event':c['event'],'visual_priorities':[c['subject'],c['event'],'clear visibility of the requested pattern and surface arrangement'],'baseline_prompt_en':base,'user_definitions':[],'interpretation_provenance':[{'term':'synthetic architectural pattern request','source_text':req,'basis':'request_context','resolution':c['event']+' within the requested visible arrangement.','sources':[]}],'unresolved_ambiguities':[],'user_exclusions':[],'runtime_forbidden_labels':[],'intent_lock':{'contract_version':'photo-intent-lock/v2','priority':'requesting_user','semantic_anchors':c['anchors'],'locked_dimensions':['concept','subject','event'],'open_dimensions':['setting','appearance','pose','body_geometry','material','framing','composition','lighting','camera','color','atmosphere','relationship']},'semantic_assertions':[],'request_lineage':None,'style':{'domain':'general_photo','family':'architectural source and surface study','evidence':['readable plaster grain','coherent surface relief']},'variation_key':'lattice-data-'+c['id']}
  optical={'source_ownership':'supported'if c['complete_mechanism']else'control_boundary','occluder_ownership':c['mechanism'],'both_receivers_visible':c['mechanism']!='insufficient_receiver','crop_preserves_transition':c['complete_mechanism'],'all_five_mechanisms_authored_before_candidate_exposure':c['complete_mechanism'],'body_review_not_applicable':True,'qualitative_prose_review_only':True,'baseline_sha256':sha(base.encode()),'evidence':clauses if c['complete_mechanism']else{'requested_state':c['event']},'note':'The flat-overlay and printed-motif controls preserve their requested non-cast mechanisms. No source fixture or second receiver is added to repair a near-negative.'}
  for name,obj in [('envelope',envelope),('controls',controls),('core',core),('review',review(base,c)),('spec',c),('optical-review',optical)]:dump(d/(name+'.json'),obj)
  ev=new if c['mechanism']=='lattice'else old
  bindings=ev if c['profile']else{}
  templates.append({'id':c['id'],'case':c['id'],'prompt':base+(' '+'. '.join(bindings.values())+'.'if bindings else''),'bindings':bindings,'expected_before':'fail'if c['profile']and c['mechanism']=='lattice'else'pass','expected_after':'pass','kind':c['kind'],'purpose':'Full canonical source-aware exact-profile evidence'if c['profile']else'No adoption; preserve complete frozen authored scene or near-negative'})
  if c['kind']=='component_optional':
   templates.append({'id':c['id']+'_opt_in_if_exposed','case':c['id'],'prompt':base+' '+'. '.join(ev.values())+'.','bindings':ev,'select_target_if_publicly_exposed':True,'expected_before':'fail'if c['mechanism']=='lattice'else'pass','expected_after':'pass','kind':'synthetic_optional_adoption','purpose':'Select only a real public candidate; every mechanism was already explicit before retrieval, and candidate wording supplies no missing mechanism'})
 # Deliberate evidence parser probes are bound to a valid legacy hard-profile pack.
 legacy=next(c for c in cases if c['id']=='slat_legacy')
 for field in old:
  ev=copy.deepcopy(old);del ev[field]
  templates.append({'id':'missing_'+field,'case':'slat_legacy','prompt':legacy['baseline']+' '+'. '.join(ev.values())+'.','bindings':ev,'expected_before':'fail','expected_after':'fail','kind':'missing_relation_probe','failure_field':field,'purpose':'Required canonical evidence field omitted'})
 wrong=[('printed','pattern_occluder_phrase','A printed lattice decoration covers the broad curved plaster wall and its adjoining recessed return'),('source','pattern_source_phrase','Unrelated dark patches cover the curved plaster wall while illumination arrives from competing directions'),('structure','pattern_structure_phrase','A uniform dark wash covers the plaster wall and adjoining return with the entire field remaining dark'),('overlay','pattern_deformation_phrase','A flat decorative projection keeps identical edges spacing and scale despite the curved wall and recessed return'),('one_receiver','pattern_receivers_phrase','The lattice appears on one isolated flat wall panel with the adjacent surface entirely clear')]
 for name,field,phrase in wrong:
  ev={**old,field:phrase}
  templates.append({'id':'malformed_'+name,'case':'slat_legacy','prompt':legacy['baseline']+' '+'. '.join(ev.values())+'.','bindings':ev,'expected_before':'fail','expected_after':'fail','kind':'malformed_relation_probe','contradictory_content':True,'failure_field':field,'purpose':'Substitute a different physical meaning for one required component; parser probe is deliberately inconsistent with the frozen valid baseline'})
 ev=copy.deepcopy(old);field='pattern_occluder_phrase'
 templates.append({'id':'nonliteral_occluder_binding','case':'slat_legacy','prompt':legacy['baseline']+' '+'. '.join(v for k,v in ev.items()if k!=field)+'.','bindings':ev,'expected_before':'fail','expected_after':'fail','kind':'literal_binding_probe','failure_field':field,'purpose':'Bound canonical evidence is absent from prompt'})
 for kind,case,ev in [('legacy','slat_legacy',old),('lattice','lattice_en',new)]:
  neg={**ev,'pattern_occluder_phrase':'It is not true that '+ev['pattern_occluder_phrase']}
  base=next(c for c in cases if c['id']==case)['baseline']
  templates.append({'id':'literal_negated_anchor_'+kind,'case':case,'prompt':base+' '+'. '.join(neg.values())+'.','bindings':neg,'expected_before':'pass'if kind=='legacy'else'fail','expected_after':'pass','kind':'known_runtime_limitation','contradictory_content':True,'purpose':'Literal anchor membership ignores semantic negation; a parser pass is a known runtime vulnerability, never physical or pixel proof'})
 dump(P/'compositions.draft.json',templates)
 dump(P/'qualification-scope.json',{'profile_id':PID,'source_aware_synthetic':True,'clean_precore':False,'natural_query_gain_claim':False,'english_baselines_for_all_requests':True,'all_korean_requests_and_component_chains':True,'provider_calls':0,'source_index_runtime_edits':0,'publication':False,'before_only':True,'no_new_candidate_mechanism_authorship':True,'eligibility_exposure_adoption_distinct':True,'literal_negated_anchor_limitation':'Unchanged runtime accepts a canonical evidence anchor under explicit negation. This DATA recovery neither fixes nor claims semantic contradiction detection.','control_layers':['coherent ordinary public-CLI/composition controls','hard-profile missing/malformed literal-evidence probes'],'expected_claim':'Exactly one lattice evidence anchor is missing before; all five physical relations and gate duties remain required.'})
 print('Prepared',len(cases),'drafts and',len(templates),'compositions',flush=True)
def assert_source(man):
 changed=[f for f,h in man['source_files'].items()if sha((R/f).read_bytes())!=h]
 if changed:
  dump(P/'concurrent-source-drift.json',{'time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'changed_files':changed,'head':git('rev-parse','HEAD')})
  raise AssertionError('Source/runtime/index drift detected; preserve this attempt and ask parent before continuing: '+str(changed))

def preflight():
 n=len(list((P/'preflight').glob('attempt-*')))+1;out=P/'preflight'/f'attempt-{n:02d}';out.mkdir(parents=True)
 rows=[]
 for d in sorted((P/'drafts').iterdir()):
  row={'id':d.name}
  for f in d.glob('*.json'):dump(out/d.name/f.name,read(f))
  try:
   env=g.load_request_envelope_arg(str(d/'envelope.json'));controls=read(d/'controls.json')
   core=g.load_authorial_core_arg(str(d/'core.json'),request_envelope=env,creative_control_snapshot=controls)
   policy=g.photo_embodiment.build_policy(core,read(d/'review.json'))
   row.update(status='pass',core_sha256=core['canonical_sha256'],lock_sha256=core['intent_lock']['canonical_sha256'],embodiment_contract=policy)
  except Exception as e:row.update(status='fail',error=str(e),traceback=traceback.format_exc())
  rows.append(row)
 dump(out/'report.json',rows);print(json.dumps([{'id':r['id'],'status':r['status'],'error':r.get('error')}for r in rows],indent=2));return rows

def freeze():
 assert not(P/'manifest.json').exists(),'Refusing to overwrite frozen manifest'
 rows=preflight();assert all(x['status']=='pass'for x in rows),'Preflight failed'
 for f in(P/'drafts').rglob('*.json'):dump(P/'inputs'/f.relative_to(P/'drafts'),read(f))
 dump(P/'compositions.json',read(P/'compositions.draft.json'))
 source_files=sorted(set(list(A.glob('*.json'))+list(S.glob('*.py'))+list((S.parent/'precore').glob('*.*'))))
 hashes={str(p.relative_to(R)):sha(p.read_bytes())for p in source_files if p.is_file()}
 source_artifacts=[f for f in (P/'source-freeze').rglob('*')if f.is_file()]
 inputs=list((P/'inputs').rglob('*.json'))+[P/'compositions.json',P/'qualification-scope.json',P/'component-chains.json']+source_artifacts
 man={'baseline_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'synthetic_canonical_source_metadata_qualification':True,'wire_provenance_note':'Production requesting_user and agent_prepack enums exercise actual CLI with synthetic source-aware fixtures, not clean pre-core or organic query qualification.','offline':True,'provider_calls':0,'case_ids':sorted(d.name for d in(P/'inputs').iterdir()),'source_files':hashes,'input_hashes':{str(p.relative_to(P)):sha(p.read_bytes())for p in inputs}}
 assert man['baseline_head'].startswith(PIN)
 dump(P/'manifest.json',man);print('Frozen valid inputs:',len(man['case_ids']))

def run(arm):
 man=read(P/'manifest.json');assert all(sha((P/f).read_bytes())==h for f,h in man['input_hashes'].items()),'Frozen input drift'
 out=P/arm
 if out.exists():raise SystemExit('Refusing to overwrite prior run')
 if arm!='before':raise SystemExit('This task is authorized only for BEFORE; obtain parent instructions before any AFTER')
 out.mkdir();dump(out/'source-state.json',{'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'status':subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True),'files':{f:sha((R/f).read_bytes())for f in man['source_files']}})
 env={k:v for k,v in os.environ.items() if not any(t in k.upper() for t in ['API_KEY','TOKEN','SECRET','CREDENTIAL'])};env['PYTHONDONTWRITEBYTECODE']='1'
 report={'arm':arm,'cases':[],'compositions':[],'scope':'Actual public V6 CLI and full-composition audit with offline deterministic lexical retrieval. Canonical source metadata only.'};packs={}
 for id in man['case_ids']:
  assert_source(man)
  d=P/'inputs'/id;dest=out/id;dest.mkdir();cmd=[str(R/'.venv/bin/python'),str(S/'generate_photo_prompt.py'),'--seed',str(SEED),'--request-envelope-json',str(d/'envelope.json'),'--authorial-core-json',str(d/'core.json'),'--creative-controls-json',str(d/'controls.json'),'--embodiment-review-json',str(d/'review.json'),'--output-file',str(dest/'pack.json')]
  t=time.time();p=subprocess.run(cmd,cwd=R,env=env,text=True,capture_output=True);dump(dest/'cli.json',{'command':cmd,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'seconds':time.time()-t});row={'id':id,'exit_code':p.returncode,'stderr':p.stderr}
  if p.returncode==0:
   pack=read(dest/'pack.json')[0];packs[id]=pack
   row.update(target_component_eligibility=g.candidate_pack_visual_component_match(next(p for p in g.load_visual_obligation_registry(A/'photo_prompt_visual_obligations.json')['profiles']if p['id']==PID),read(d/'envelope.json')['request_text']),contract_version=pack['contract_version'],obligation_ids=[o['id']for o in pack.get('visual_obligations',{}).get('obligations',[])],visual_concept_ids=[v['id']for v in pack.get('visual_concept_candidates',{}).get('candidates',[])],slot_candidates=[{'slot':s,'id':v['id'],'applicability':v.get('applicability')}for s,b in pack['slots'].items() for v in b.get('candidates',[])],core_retrieval_sha256=pack['core_retrieval']['canonical_sha256'],core_sha256=pack['authorial_core']['canonical_sha256'])
  report['cases'].append(row);dump(out/'report.json',report);print(arm,id,p.returncode,row.get('obligation_ids'),flush=True)
 for template in read(P/'compositions.json'):
  assert_source(man)
  id=template['id'];case=template['case']
  if case not in packs:continue
  pack=packs[case];core=pack['authorial_core'];lock=core['intent_lock'];c=read(P/'inputs'/case/'spec.json');prompt=template['prompt']
  chosen=[CID]if template.get('select_target_if_publicly_exposed')else[]
  exposed=[v['id']for v in pack.get('visual_concept_candidates',{}).get('candidates',[])]
  if chosen and CID not in exposed:
   report['compositions'].append({'id':id,'case':case,'status':'not_run_target_not_exposed','chosen_visual_concept_ids':[],'purpose':template['purpose']});dump(out/'report.json',report);continue
  composed={'core_retrieval_sha256':pack['core_retrieval']['canonical_sha256'],'pack_id':pack['pack_id'],'prompt_en':prompt,'negative_en':pack['negative_en'],'chosen_candidate_ids':[],'chosen_visual_concept_ids':chosen,'composer':'agent','candidate_interpretations':[],'authorial_core_binding':{'source_authorial_core_sha256':core['canonical_sha256'],'source_intent_lock_sha256':lock['canonical_sha256'],'preserved_anchor_ids':[a['anchor_id']for a in lock['semantic_anchors']],'preserved_evidence':[],'authorial_decisions':[]},'semantic_clarification_decisions':[{'clarification_id':r['id'],'decision':'applied' if r.get('required_in_final_prompt') else 'rejected','rationale':'Preserve frozen requested architectural meaning and decline optional reinterpretation.','prompt_evidence':lock['semantic_anchors'][0]['prompt_evidence']}for r in pack.get('semantic_clarification',{}).get('candidates',[])],'creative_augmentation_brief':{'decisions':[{'candidate_id':r['id'],'decision':'rejected','rationale':'The complete requested architectural scene needs no optional augmentation.'}for r in pack.get('creative_augmentation',{}).get('candidates',[])]},'embodiment_review':{'source_contract_sha256':pack['embodiment_preflight']['canonical_sha256'],'review':review(prompt,c,'agent_postcomposition')}}
  if c['profile'] or chosen:composed['visual_obligation_evidence']={PID:template['bindings']}
  dest=out/'compositions'/id;dump(dest/'composed.json',composed)
  # Isolate evidence checks using the same real CLI pack and exact full composed input.
  direct=audit.audit_visual_obligations(pack,composed,prompt);dump(dest/'direct-visual-evidence.json',{'failures':direct,'status':'pass'if not direct else 'fail'})
  cmd=[str(R/'.venv/bin/python'),str(S/'audit_composed_prompt.py'),'--pack',str(out/case/'pack.json'),'--composed',str(dest/'composed.json')];p=subprocess.run(cmd,cwd=R,env=env,text=True,capture_output=True);dump(dest/'cli.json',{'command':cmd,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr})
  try:result=json.loads(p.stdout)
  except Exception:result={'status':'error','failures':[{'reason':p.stderr}]}
  dump(dest/'audit.json',result);report['compositions'].append({'id':id,'case':case,'status':result['status'],'expected':template['expected_after' if arm.startswith('after')else'expected_before'],'failures':result['failures'],'direct_visual_failures':direct,'warnings':result.get('warnings',[]),'chosen_candidate_ids':[],'chosen_visual_concept_ids':chosen,'semantic_claim_limit':'Deliberately contradictory invalid evidence is a parser boundary probe, not a coherent final scene'if template.get('contradictory_content')else'Canonical source-aware contract qualification'})
  dump(out/'report.json',report);print(id,result['status'],[(r.get('check'),r.get('field'))for r in result['failures']],flush=True)
 assert_source(man)
 dump(out/'ending-source-state.json',{'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'status':subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True),'files':{f:sha((R/f).read_bytes())for f in man['source_files']}})
 print('Completed',arm,flush=True)

if __name__=='__main__':
 action=sys.argv[1]
 if action=='prepare':prepare()
 elif action=='preflight':preflight()
 elif action=='freeze':freeze()
 else:run(action)
