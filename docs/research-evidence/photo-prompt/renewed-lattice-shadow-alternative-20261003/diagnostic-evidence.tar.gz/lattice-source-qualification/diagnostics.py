"""Read-only BEFORE diagnostics, explicitly separated from public exposure/adoption."""
import importlib.util,sys
from pathlib import Path
P=Path(__file__).parent
spec=importlib.util.spec_from_file_location('qualify',P/'qualify.py');q=importlib.util.module_from_spec(spec);spec.loader.exec_module(q)
q.assert_source(q.read(P/'manifest.json'))
reg=q.g.load_visual_obligation_registry(q.A/'photo_prompt_visual_obligations.json');idx=q.g.load_visual_profile_index(q.A/'photo_prompt_visual_profile_index.json',reg);profile=next(x for x in reg['profiles']if x['id']==q.PID)
rows=[]
for c in q.read(P/'component-chains.json'):
 text='; '.join(c['terms']);match=q.g.candidate_pack_visual_component_match(profile,text)
 omitted=[]
 for i,group in enumerate(profile['semantics']['component_semantics']['groups']):
  txt='; '.join(v for j,v in enumerate(c['terms'])if i!=j)
  omitted.append({'omitted_group':group['id'],'text':txt,'component_match':q.g.candidate_pack_visual_component_match(profile,txt)})
 rows.append({**c,'text':text,'component_match':match,'missing_group_controls':omitted})
 assert match==('component_semantics'if c['mechanism']=='legacy'else None)
 assert all(x['component_match']is None for x in omitted)
q.dump(P/'before/component-eligibility.json',{'scope':'Pure production component helper against actual BEFORE source; eligibility is neither public exposure nor adoption. No proposed source was loaded into runtime.','rows':rows})
q.dump(P/'before/index-and-runtime-pin.json',{'head':q.git('rev-parse','HEAD'),'registry_sha256':q.g.visual_profile_registry_sha256(reg),'index_registry_sha256':idx['registry_sha256'],'genuine_index_load_succeeded':True,'actual_entry_canonical_sha256':q.canon(idx['entries'][q.PID]),'index_file_sha256':q.sha((q.A/'photo_prompt_visual_profile_index.json').read_bytes()),'positive_text_sha256':q.sha(q.g.visual_profile_semantic_text(profile).encode()),'runtime_files':{f:h for f,h in q.read(P/'manifest.json')['source_files'].items()if '/scripts/'in f or '/precore/'in f},'canonical_source_profile_sha256':q.canon(next(x for x in q.read(q.R/q.SOURCE)['profiles']if x['id']==q.PID)),'qualification_runner_sha256':q.sha((P/'qualify.py').read_bytes()),'provider_calls':0})
print('BEFORE eligibility 2 legacy matches; 2 lattice nonmatches; all 20 omission controls rejected; actual source/index validated')
