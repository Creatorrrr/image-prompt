"""Verify genuine AFTER projections and compare all frozen BEFORE/AFTER inputs and outputs."""
from after import *
man=read(P/'manifest.json');pin=read(P/'after-source-pin.json');assert_source(man)
assert(P/'after/ending-source-state.json').exists(),'AFTER is not complete'
before=read(P/'before/report.json');r=read(P/'after/report.json');assert r['stage']=='complete'
assert len(r['cases'])==11 and len(r['compositions'])==28
assert all(x['exit_code']==0 and x['contract_version']=='photo-candidate-pack/v6'for x in r['cases'])
assert all(x['status']==x['expected']for x in r['compositions'])
reg=g.load_visual_obligation_registry(A/'photo_prompt_visual_obligations.json');idx=g.load_visual_profile_index(A/'photo_prompt_visual_profile_index.json',reg);profile=next(x for x in reg['profiles']if x['id']==PID)
projection=[];exposure=[];effective=[]
for case in r['cases']:
 pack=read(P/'after'/case['id']/'pack.json')[0]
 for ob in pack.get('visual_obligations',{}).get('obligations',[])+[c['opt_in_contract']['obligation']for c in pack.get('visual_concept_candidates',{}).get('candidates',[])if c['id']==CID]:
  if ob['id']!=PID:continue
  act=ob['activation'];expected=g.candidate_pack_visual_profile_obligation(profile,reg,activation_source=act['source'],source_intent_ids=act['source_intent_ids'])
  checks={'entire_projected_obligation_matches_production_source':ob==expected,'five_components_required':ob['component_semantics']['minimum_component_groups']==5 and len(ob['component_semantics']['required_group_ids'])==5,'five_evidence_fields':len(ob['prompt_binding']['required_evidence_fields'])==5,'five_render_gates':len(ob['render_gates'])==5,'visual_relation_ownership_crop_occlusion_unchanged':ob['visual_relation']==profile['visual_relation']}
  assert all(checks.values()),(case['id'],checks)
  projection.append({'case':case['id'],'activation_source':act['source'],'obligation_canonical_sha256':canon(ob),'checks':checks})
 exposure.append({'case':case['id'],'component_helper_eligible':case['target_component_eligibility']is not None,'public_target_hard':PID in case['obligation_ids'],'public_target_optional':CID in case['visual_concept_ids'],'public_target_slot_ids':[v['id']for v in case['slot_candidates']if PID in v['id']],'all_public_visual_concept_ids':case['visual_concept_ids']})
for row in r['compositions']:
 d=P/'after/compositions'/row['id'];comp=read(d/'composed.json');pack=read(P/'after'/row['case']/'pack.json')[0]
 eff,errors=audit.derive_effective_visual_obligation_contract(pack,comp);assert not errors
 checked=dict(pack)
 if eff:checked['visual_obligations']=eff
 else:checked.pop('visual_obligations',None)
 fail=audit.audit_visual_obligations(checked,comp,comp['prompt_en'])
 effective.append({'composition':row['id'],'target_adopted':CID in comp['chosen_visual_concept_ids'],'target_required_from_request':PID in[x['id']for x in pack.get('visual_obligations',{}).get('obligations',[])],'target_effective':PID in[x['id']for x in(eff or{}).get('obligations',[])],'effective_gate_ids':(eff or{}).get('required_hard_gates',[]),'effective_direct_evidence_failures':fail,'full_composition_status':row['status'],'full_failures':row['failures'],'claim':'Scripted source-aware opt-in proves audit capability, not natural composer uptake.'})
dump(P/'after/source-projection-proof.json',projection)
dump(P/'after/eligibility-exposure-adoption.json',{'exposure':exposure,'composition_adoption':effective,'new_reachability_reported_before_adoption':read(P/'after-reachability-notified.json'),'known_runtime_limitation':'Both negated legacy and negated lattice anchors pass the full AFTER audit. No runtime change fixed the literal semantic-negation vulnerability; the newly accepted anchor inherits it.'})
assert read(P/'after/source-state.json')['files']==read(P/'after/ending-source-state.json')['files']==pin['source_files']
assert all(not x['failures']for x in r['compositions']if x['id']in['lattice_en','lattice_ko'])
cases=[]
for b,a in zip(before['cases'],r['cases']):
 assert b['id']==a['id'];assert b['obligation_ids']==a['obligation_ids'];assert b['core_sha256']==a['core_sha256'];assert b['core_retrieval_sha256']==a['core_retrieval_sha256']
 cases.append({'id':a['id'],'core_sha256_unchanged':True,'retrieval_sha256_unchanged':True,'hard_ids_unchanged':True,'before_component_eligible':b['target_component_eligibility'],'after_component_eligible':a['target_component_eligibility'],'before_target_exposed':CID in b['visual_concept_ids'],'after_target_exposed':CID in a['visual_concept_ids'],'optional_ids_added':sorted(set(a['visual_concept_ids'])-set(b['visual_concept_ids'])),'optional_ids_removed':sorted(set(b['visual_concept_ids'])-set(a['visual_concept_ids'])),'slot_candidates_unchanged':b['slot_candidates']==a['slot_candidates']})
comps=[]
for b,a in zip(before['compositions'],r['compositions']):
 assert b['id']==a['id']
 comps.append({'id':a['id'],'before':b['status'],'after':a['status'],'before_selected':b['chosen_visual_concept_ids'],'after_selected':a['chosen_visual_concept_ids'],'after_failures':a['failures'],'after_warnings':a.get('warnings',[])})
changed=[x for x in comps if x['before']!=x['after']]
assert set(x['id']for x in changed)=={'lattice_en','lattice_ko','component_lattice_en_opt_in_if_exposed','component_lattice_ko_opt_in_if_exposed','literal_negated_anchor_lattice'}
assert all(x['slot_candidates_unchanged']for x in cases)
assert all(not(set(x['optional_ids_added'])-{CID})for x in cases)
optional_displacements=[{'case':x['id'],'removed':x['optional_ids_removed']}for x in cases if x['optional_ids_removed']]
assert optional_displacements==[{'case':'component_lattice_ko','removed':['visual-concept:pc_pc27_owner_relation']}],optional_displacements
dump(P/'BEFORE-AFTER-COMPARISON.json',{'frozen_input_hashes_unchanged':True,'runtime_source_files_unchanged':True,'only_accepted_source_and_genuine_index_files_changed':True,'public_cases':cases,'compositions':comps,'changed_composition_outcomes':changed,'new_lattice_reachability_reported_before_adoption':True,'observed_optional_candidate_displacement':optional_displacements,'claim':'Canonical source-aware DATA contract recovery only; no natural-query, natural-adoption, or pixel success claim.'})
summary={'status':'AFTER_COMPLETE','head':git('rev-parse','HEAD'),'frozen_input_manifest_sha256':sha((P/'manifest.json').read_bytes()),'runtime_unchanged_from_before':True,'source_after_profile_canonical_sha256':canon(next(x for x in read(R/SOURCE)['profiles']if x['id']==PID)),'index_after_sha256':sha((A/'photo_prompt_visual_profile_index.json').read_bytes()),'actual_registry_sha256':g.visual_profile_registry_sha256(reg),'actual_genuine_index_validated':True,'full_public_v6_cases':11,'cli_successes':11,'full_composition_audits':28,'expected_audit_outcomes':28,'exact_lattice_en_ko_recovered':2,'newly_exposed_target_optional_cases':2,'new_lattice_optional_adoptions_audited_successfully':2,'all_legacy_leaf_slat_controls_preserved':True,'all_three_coherent_negative_controls_preserved':True,'all_20_component_omissions_reject':True,'all_5_missing_fields_reject':True,'all_5_malformed_relations_reject':True,'nonliteral_binding_rejects':True,'both_literal_negated_anchor_probes_pass_known_runtime_limitation':True,'hard_profile_sets_unchanged':True,'slot_candidate_surfaces_unchanged':True,'unrelated_visual_concept_additions':0,'observed_optional_candidate_displacement':optional_displacements,'other_selected_candidates':0,'worker_provider_calls':0,'worker_source_runtime_index_edits':0,'after_source_runtime_unchanged_during_run':True}
dump(P/'AFTER-SUMMARY.json',summary);print(json.dumps(summary,indent=2))
