# Lattice source recovery: frozen BEFORE / AFTER qualification

## Result

**The reviewed lattice DATA recovery qualifies within the frozen source-aware contract scope.** Exactly one target profile was tested: `patterned_cast_shadow_receiver_continuity`.

The parent applied the independently reviewed four append-only strings and one genuine refreshed profile vector between the arms. This worker changed no repository source, runtime, index, tests, or git state and made no provider/API calls. The qualification used the actual public V6 CLI and complete composition audit in both arms.

- BEFORE: 11/11 public V6 runs succeeded; 26/26 executed composition audits matched their frozen expected outcomes, with 2 optional lattice templates correctly not run because the target was not exposed
- AFTER: 11/11 public V6 runs succeeded; 28/28 composition audits matched their frozen expected outcomes (17 pass; 11 intentional rejection)
- All frozen request/core/control/embodiment/composition inputs remained unchanged. The same seed was used. All per-case core and retrieval hashes match between arms
- Runtime bytes remained identical between and throughout the arms. Only the accepted source file and genuine visual profile index changed. The separate HEAD change was docs-only

## Recovery at three distinct boundaries

1. **Component eligibility:** Complete canonical all-English and all-Korean lattice chains changed from no match to `component_semantics`. Legacy English/Korean chains remain eligible. All 20 one-component omission probes remain ineligible
2. **Public exposure:** The actual English and all-Korean component-only lattice packs now expose `visual-concept:patterned_cast_shadow_receiver_continuity`. They remain non-hard. Actual reachability was reported to the parent before any adoption occurred; `after-reachability-notified.json` binds that notification to the new packs
3. **Actual scripted adoption:** The two unchanged conditional templates selected only the genuine exposed candidate IDs and passed the full effective-obligation audit, with the same five gates. This measures source-aware opt-in capability, not natural composer uptake

The English and all-Korean exact lattice requests already activated the genuine hard profile BEFORE. Their complete compositions failed on exactly the missing lattice occluder evidence anchor. The identical compositions pass AFTER. Exact leaf and slat controls, and English/Korean legacy component eligibility/exposure/opt-in, pass both arms.

All positive baselines already contained the complete physical mechanism before public retrieval: one directional source, one identifiable occluder, separated bright/dark cast structure, curvature/depth deformation, and pattern continuity across two connected receivers. Both receivers and their uninterrupted join were kept inside one frame. Optional candidate wording did not supply a missing mechanism. The all-Korean requests and pure Korean component chains use the production English baseline/composed-prompt contract.

## Boundaries preserved

- Printed motif, flat decorative overlay, and insufficient single receiver remain coherent ordinary controls. They never hard-activate, expose, or adopt the target, and their full compositions pass without inventing an occluder or second receiver
- All five missing evidence fields reject in both arms
- Five deliberately malformed hard-profile evidence relations reject at the intended anchor: printed motif, competing sources, uniform dark wash, flat overlay, and one receiver
- Evidence absent from the prompt still rejects at literal binding
- Actual source projection checks pass for every hard or exposed target opt-in contract: five components, five evidence fields, five gates, and unchanged ownership/crop/occlusion metadata
- Every hard-profile set and every slot-candidate surface is unchanged between arms

The malformed hard-profile probes deliberately conflict with the baseline and are parser tests, separate from the coherent ordinary negative requests. No image was generated; optical reviews are prose consistency checks and do not establish compliant pixels.

## Recorded optional-candidate displacement

The Korean component-only lattice pack gains the target and loses `visual-concept:pc_pc27_owner_relation`. No unrelated optional concept was added and no other optional ID was removed. Full raw candidate comparisons are retained.

The displaced profile's unchanged source is `photo_prompt_visual_obligations_portrait_composition.json`, `/profiles/13`. Its declared relation requires architectural symmetry, a head or limb arrangement departing from that symmetry, and face focal priority. The frozen Korean scene explicitly contains an unoccupied room and joined plaster receivers; it has no portrait subject, head, face or limbs. Adopting that relation would add an absent subject. Its removal loses no requested relation in this fixture. It was already unselected in BEFORE, so no BEFORE final composition inherited it.

This is a fixture-specific contextual compatibility judgment, not a claim of globally improved ranking or a newly fixed context filter. See `after/displaced-candidate-context-review.json` for the complete source/candidate/request evidence. The corpus-level lexical change and finite candidate set are retained as the explanation consistent with this measured displacement; no ranking or fixture rescue was performed.

## Unchanged literal-negation vulnerability

The legacy full composition containing `It is not true that` plus its canonical occluder anchor passes BEFORE and AFTER. The corresponding lattice negation probe fails BEFORE solely because its anchor is unavailable and passes AFTER once the anchor exists. Thus both negated-anchor probes pass the full AFTER audit.

This is an explicitly retained runtime limitation: literal membership does not prove semantic affirmation, physical source ownership, correct geometry, or rendered success. It is not counted as a desired negative-control rejection or a semantic-understanding improvement. The DATA patch neither changes nor fixes that runtime behavior. Image-level qualification would still need the five unchanged render gates.

## Exact provenance

- BEFORE HEAD: `978f38defbc70ea47dbd028af47baf701eada1bd`
- AFTER HEAD: `bbc3a457484bf0bedca40026c3f2850ac80deacd`
- Unchanged frozen input manifest SHA-256: `365017b5dced44dfe80c0bccfcc8be978831667947d22d45d7b38a7c8b7dd713`
- BEFORE target source profile: `87e318b6f31dce32bc451bded7c9a730b28e70c8ad4a8a2fc7884df9ba2a8cc9`
- AFTER target source profile: `6c5c1c751060c172f8a47a0d69ef013cd076de94b5761612ba910580d11cf71b`
- BEFORE genuine visual index file: `00c781887527c4cbc31f1dcbbf6db52fa72531aa6406f6f1d5d61b51b74f3317`
- AFTER genuine visual index file: `19d58c07a48c1c6b7a8b7a89dc7b112c837225c32a6945a7b9ffe754ea06fe87`
- AFTER registry: `f8faefa466cf29431c3d1acd38b72d9dfc0b879618998d972643f6683a00236a`
- Unchanged `prompt_generator.py`: `0f0c2e6ff6a069e28d96b86857aa9553674f9c5e5996b4f032e055805e624ce4`
- Unchanged `audit_composed_prompt.py`: `c41619e6293961c7edaddc049d4056538d24fa27391fec08fd20caf89ff95cf5`

`after-source-reconciliation.json` independently proves that the complete source file equals BEFORE plus precisely the four accepted operations, with all other records unchanged. The actual AFTER registry/index loader passed. The copied integration receipt reports 1,510 profiles, 1,509 unchanged profile entries, 3,667 unchanged exact rows, and one genuinely refreshed changed-text vector. There was no fake index, relabelled vector, optional candidate injection, or weakened gate.

## First attempts and scope

The original preparation helper-name failure and the complete first preflight are preserved. The first preflight rejected three ordinary controls only for the one-content-word subject anchor “wall”; correction bound their already-present concrete receiver phrases without altering requests or baselines. The second preflight passed all 11 before freezing. No failed preflight was forced through. All first public CLI and audit results remain intact. See `diagnostic-log.md`, `preflight/`, and the preserved `BEFORE_REPORT.md`.

This qualification is explicitly synthetic and source-aware. It is not a clean pre-core test, natural-query recall trial, natural composer adoption study, full repository regression, or pixel evaluation. The per-composition low-level `direct-visual-evidence.json` checks use the raw pack; authoritative optional-adoption evidence comes from the actual full CLI audit and separately derived effective-contract checks in each arm's `eligibility-exposure-adoption.json`.

## Deliverables

- `FINAL-SUMMARY.json`, `AFTER-SUMMARY.json`: measured final state and counts
- `BEFORE-AFTER-COMPARISON.json`: every case, public surface delta, adoption and composition outcome
- `REPORT.md`: this final qualification report
- `BEFORE_REPORT.md`, `SUMMARY.json`: preserved completed BEFORE result
- `manifest.json`, `inputs/`, `compositions.json`: immutable shared inputs and hashes
- `before/`, `after/`: all public packs, full composed payloads, CLI/audit outputs, component checks, exact source projections and start/end source pins
- `source-freeze/`, `runtime-freeze/`: reviewed proposal and preserved original runtime
- `after/displaced-candidate-context-review.json`: full contextual review of the one optional displacement

The requested BEFORE/AFTER qualification is complete. No additional execution, source editing, or publication is initiated by this worker.
