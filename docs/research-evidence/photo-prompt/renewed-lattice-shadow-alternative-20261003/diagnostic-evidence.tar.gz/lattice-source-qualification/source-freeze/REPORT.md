# Independent lattice-occluder source review

## Decision

**ACCEPT the original four append-only strings unchanged. Freeze only; do not apply.**

The proposed addition repairs an internal declaration/consumer mismatch for `patterned_cast_shadow_receiver_continuity`. It does not add a new photographic mechanism or make generic lattice decoration eligible. The source definition, composition instruction, render gate, candidate row, and original research already name lattice alongside leaf and slat.

Repository HEAD at review: `a260aab748411ac822cdf651fcd56a694a3e213a` (food DATA22). Active merge head: `900848816f88a494e5bf16ea475a25074d584911` (neutral-expression upstream). The actual merge-in-progress registry loaded 1,510 profiles and its genuine hash-bound visual index validated. This worker did not change repository source, runtime, tests, index, git staging, providers, packages, or published state. All outputs live in this external review directory. The nine tracked source/runtime/index files fingerprinted for review remained unchanged during the probe.

## Source and candidate authority

Primary source: `skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations_reactorprompt.json`, `/profiles/0`.

- Definition explicitly lists leaf, slat, or lattice and requires alternating bright/dark structure, at least two connected receiver regions, and curvature/depth deformation
- Composition instruction repeats the same alternatives and geometry
- `vo_pattern_shadow_occluder_grammar` explicitly accepts leaf, slat, or lattice
- `photo_prompt_reactorprompt_visual_relations_extension.json`, `slots.light_shape`, matching candidate ID explicitly uses a leaf/slat/lattice occluder and the same receiving-surface relation
- Original research, `docs/research-evidence/photo-prompt/reactorprompt-incremental-visual-semantics-20260902/topics/04-lighting-exposure-material-response.md`, lines 262–293, first lists leaf/slat/lattice continuity and then specifies activation for leafy/slatted/lattice cast patterns with all five components

The missing surfaces are the required occluder component anchor, the corresponding Korean component anchor, the positive concept term, and the English literal-evidence alternative. Candidate scope is advisory inspiration; it does not independently authorize hard activation.

## Accepted source patch and hashes

`frozen-patch.json` contains the four original append operations, with the same paths and values as the audited proposal:

1. English lattice component anchor: `an identifiable lattice occluder grammar shapes the cast pattern`
2. Korean lattice component anchor: `식별 가능한 격자 차폐 문법이 투사 패턴을 만듦`
3. Concept term: `lattice occluder grammar`
4. English lattice evidence alternative matching item 1

Canonical JSON SHA-256 uses UTF-8, `ensure_ascii=False`, sorted keys, and compact separators:

- Before profile: `87e318b6f31dce32bc451bded7c9a730b28e70c8ad4a8a2fc7884df9ba2a8cc9`
- Accepted profile: `6c5c1c751060c172f8a47a0d69ef013cd076de94b5761612ba910580d11cf71b`
- Unchanged candidate record: `26db8a5dcd48635fe813b0c7befd7c83bc535c6e4dcae51c4fedb02e40b05c51`

The complete source records are `before-profile.json`, `accepted-profile.json`, and `candidate-record.json`. Reversing exactly the four append operations restores the original source record. No fifth change is needed. This is minimal for the selected component/evidence/concept consistency correction; it makes no claim to solve every possible natural-language paraphrase.

## Required meaning and boundaries preserved

All five component groups remain required, with a minimum of five, and all five evidence fields remain required:

| Duty | Evidence minimum | Gate and review scale |
|---|---:|---|
| Coherent source direction | 8 content words | `vo_pattern_shadow_source_direction`, both |
| Identifiable occluder grammar | 10 | `vo_pattern_shadow_occluder_grammar`, thumbnail |
| Alternating bright/dark cast structure | 8 | `vo_pattern_shadow_bright_dark_structure`, both |
| Surface curvature/depth deformation | 8 | `vo_pattern_shadow_surface_deformation`, native |
| Continuity across at least two connected receiver regions | 10 | `vo_pattern_shadow_connected_receivers`, both |

The physical relation remains source → occluder → cast pattern → connected receivers. A printed lattice, refracted caustic, reflection, flat projected overlay, or merely atmospheric shaft is not the declared physical mechanism. Curvature, edge spacing, scale, and receiver-depth changes must remain coherent. Both connected receiver regions and the transition must remain visible in the evaluated frame; occlusion may not hide that transition. The patch does not require a new visible light fixture or fully in-frame lattice object: the existing profile asks for identifiable occluder grammar and readable source direction, and its specified visible regions are unchanged.

All original leaf/slat English and Korean alternatives remain byte-equivalent. Exact aliases, activation policy, definition, composition, five gates, rejection substitutes, visual-relation ownership, visibility/crop/occlusion rules, prompt-literal requirement, five distinct phrases, overlap ceiling, filler restrictions, and evidence minimums are unchanged. After restoring just the added component and evidence anchors in the projected contract, the entire proposed materialized contract equals the original.

## Independent measured controls

See `consumer-proof-independent.json` and reproducible `review.py`.

- Current genuine registry/index validation: pass
- Canonical legacy leaf/slat evidence: 0 failures before and after
- Canonical lattice evidence: exactly one missing-occluder-anchor failure before, 0 failures under the in-memory accepted source
- All-English and **all-Korean** lattice component chains: no match before, `component_semantics` after
- All-English and all-Korean legacy leaf/slat chains: match both before and after
- Remove any one component in those four language/mechanism chains: all 20 controls reject
- Remove each of the five evidence fields: all 5 controls reject
- Leave an evidence phrase out of prompt text: literal-binding failure
- Replace a required canonical component with a printed lattice, absent real occluder, competing directions, uniform dark wash, flat overlay, single receiver, disconnected receivers, water caustic, or atmospheric shafts: all 9 controls reject in both the component helper and literal evidence audit. Every evidence rejection is specifically missing the declared anchor, without a confounding minimum-word-count failure
- Eight generic/wrong-neighbor requests produce no target hard hit using the actual current index's exact lane. Exact lookup/activation are identical after the proposed patch, so no new exact hard trigger is introduced. This is an unchanged-boundary inference for the proposed source, not a measured proposed-index result

The old audit's row marked `language: ko` changed only the occluder anchor into Korean, leaving four groups in English. That was a valid mixed-language test but not a complete Korean-chain test. This independent run adds the actual all-Korean chain and verifies all five omissions. No source revision is needed.

## Limits: artificial canonical recovery, not natural or pixel proof

The passing positive examples are deliberately assembled from canonical source anchors. They establish source-contract recovery. The component helper is lexical and advisory; its `component_semantics` result is not hard activation or public-CLI success. There is no natural composer run, natural holdout completion, query embedding, generated image, or visual/pixel inspection in this review.

Wrong-neighbor tests prove that substituting those unrelated descriptions for required anchors still fails. They do **not** establish unrestricted semantic contradiction detection. A deliberately negated anchor (`It is not true that …`) passes the literal evidence checker with both the original leaf/slat contract and the proposed lattice contract. This existing limitation is recorded explicitly in `known_literal_checker_limitations`. Therefore neither old nor new anchor acceptance certifies real occlusion, accurate geometry, or compliant pixels. The five unchanged render gates still require independent image-level evidence in any subsequent authorized qualification.

The phrase “cast bands” remains untouched. This review does not broaden it to arbitrary lattice-like decoration, relax the two-region geometry, or infer improved natural-language retrieval from a new concept term.

## Positive-text and index consequences

`index-consequences.json` gives computed values for this exact integration snapshot.

The production positive-field projection gains exactly three units: the English/Korean component alternatives and the concept term. The fourth addition, the evidence alternative, is outside the positive-field allowlist. Definition, paraphrases, and aliases are unchanged.

- Before positive-text SHA-256: `7cba1d794cfb71d660b88116792a196720e3f931fd61f5dac08d78ceaa883930`
- Accepted positive-text SHA-256: `e25647e6023ce3b612b299a3a774d816498de65e953dfd6fe608c5117882b4e4`
- UTF-8 payload: 1,411 → 1,572 bytes
- Current registry hash: `3ef34ad0d67ce4236b717a77eaa42eeb22eba032b384b9a5190d9f128cbb51cb`
- Hypothetical accepted registry hash: `f8faefa466cf29431c3d1acd38b72d9dfc0b879618998d972643f6683a00236a`
- Exact lookup remains identical
- BM25F documents, document frequencies, and average field lengths change. Unchanged-profile rankings are not guaranteed, because lexical corpus statistics change
- With the current provider/model/dimensions (`gemini`, `gemini-embedding-2`, 768), production cache-selection logic reuses 1,509 same-text vectors and excludes exactly the changed lattice profile
- One genuine changed-text profile embedding would therefore be needed after authorized application, plus regeneration of registry binding/BM25F/text hashes. A previous vector must not be relabelled as a new-text vector
- The old genuine index is correctly rejected against the hypothetical new registry for a source-hash mismatch
- Candidate data and candidate embedding text are unchanged; this proposal alone does not require a candidate semantic-index refresh
- No runtime/routing edit is indicated

No proposed runtime index was built or bound, no vector was fabricated, and no provider was called. The positive text files are diagnostic text, with trailing newline excluded from the reported production text hashes. Whole-registry hashes and reuse counts must be recomputed after the concurrent merge lands; the per-record hashes permit precise reconciliation.

## Frozen deliverable and stop

The accepted patch is ready for the parent's separately authorized integration workflow. Recheck the profile's before hash, apply only the four additions if still applicable, and perform a genuine index refresh only when authorized. This read-only review is complete and does not authorize application, provider use, installation, or publication.
