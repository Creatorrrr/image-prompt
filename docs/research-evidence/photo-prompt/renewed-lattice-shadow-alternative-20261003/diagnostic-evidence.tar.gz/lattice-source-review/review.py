"""Independent, provider-free, read-only repository review; writes only beside this script."""
from pathlib import Path
import copy, datetime, hashlib, json, subprocess, sys
sys.dont_write_bytecode=True
R=Path('REPOSITORY_ROOT'); O=Path(__file__).parent
S=R/'skills/photo-prompt-image-generator/scripts'; A=S.parent/'assets'
sys.path.insert(0,str(S))
import prompt_generator as pg
import audit_composed_prompt as ac
import build_visual_profile_index as ib
from visual_profile_contracts import compile_visual_profile
PID='patterned_cast_shadow_receiver_continuity'
SRC=A/'photo_prompt_visual_obligations_reactorprompt.json'
CAND=A/'photo_prompt_reactorprompt_visual_relations_extension.json'
IDX=A/'photo_prompt_visual_profile_index.json'
RESEARCH=R/'docs/research-evidence/photo-prompt/reactorprompt-incremental-visual-semantics-20260902/topics/04-lighting-exposure-material-response.md'
OLD=O.parent/'light-medium-receiver-audit'
sha=lambda b:hashlib.sha256(b).hexdigest()
canon=lambda v:sha(json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())
def save(name,obj):(O/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
def git(*args):return subprocess.check_output(['git',*args],cwd=R,text=True).strip()
def fingerprint(paths):return {str(p.relative_to(R)):sha(p.read_bytes()) for p in paths}
tracked=[SRC,CAND,IDX,S/'prompt_generator.py',S/'photo_visual_retrieval.py',S/'visual_profile_contracts.py',S/'audit_composed_prompt.py',S/'build_visual_profile_index.py',RESEARCH]
initial=fingerprint(tracked)
head=git('rev-parse','HEAD'); status=git('status','--short'); merge=git('rev-parse','-q','--verify','MERGE_HEAD') if (R/'.git/MERGE_HEAD').exists() else None
source=json.loads(SRC.read_text()); p=next(x for x in source['profiles'] if x['id']==PID)
prop=json.loads((OLD/'minimal-source-proposal.json').read_text()); q=copy.deepcopy(p)
assert canon(p)==prop['before_canonical_sha256']
for op in prop['changes']:
 assert op['op']=='add'
 parts=op['path'].strip('/').split('/'); target=q
 for key in parts[:-1]:target=target[int(key)] if isinstance(target,list) else target[key]
 assert isinstance(target,list) and int(parts[-1])==len(target),op
 target.append(op['value'])
assert canon(q)==prop['proposed_canonical_sha256']
# Remove only the four appended strings: every other source byte-equivalent canonical value must survive.
restored=copy.deepcopy(q)
for op in reversed(prop['changes']):
 parts=op['path'].strip('/').split('/'); target=restored
 for key in parts[:-1]:target=target[int(key)] if isinstance(target,list) else target[key]
 assert target.pop(int(parts[-1]))==op['value']
assert restored==p
candidate=next(x for x in json.loads(CAND.read_text())['slots']['light_shape'] if x['id']==PID)
assert 'leaf slat or lattice' in candidate['embedding_text']
research=RESEARCH.read_text(); assert 'leafy/slatted/lattice' in research and 'at least two connected receiver regions' in research
save('before-profile.json',p);save('accepted-profile.json',q);save('candidate-record.json',candidate)
reg=pg.load_visual_obligation_registry(A/'photo_prompt_visual_obligations.json')
idx=pg.load_visual_profile_index(IDX,reg)
p_loaded=next(x for x in reg['profiles'] if x['id']==PID)
assert p_loaded==compile_visual_profile(p)
q_loaded=compile_visual_profile(q)
regq=copy.deepcopy(reg);regq['profiles']=[q_loaded if x['id']==PID else x for x in regq['profiles']]
exact_before=pg.visual_profile_exact_term_rows(reg); exact_after=pg.visual_profile_exact_term_rows(regq)
assert exact_before==exact_after
changed_profiles=[a['id'] for a,b in zip(reg['profiles'],regq['profiles']) if a!=b];assert changed_profiles==[PID]

def contract(profile):
 o=pg.candidate_pack_visual_profile_obligation(profile,reg,activation_source='explicit_request_semantics',source_intent_ids=['independent_read_only_source_review'])
 return {'enabled':True,'contract_version':pg.VISUAL_OBLIGATIONS_CONTRACT_VERSION,'strict_gate_set':True,'obligations':[o],'required_hard_gates':[g['id'] for g in o['render_gates']]}
cb,cq=contract(p_loaded),contract(q_loaded)
assert cb['required_hard_gates']==cq['required_hard_gates'] and len(cb['required_hard_gates'])==5
assert p['render_gates']==q['render_gates'] and p['visual_relation']==q['visual_relation']
# Restore added component/evidence anchors in projected contract, proving entire remaining contract invariant.
contract_restored=copy.deepcopy(cq)
contract_restored['obligations'][0]['component_semantics']['groups'][1]['any_terms']=copy.deepcopy(cb['obligations'][0]['component_semantics']['groups'][1]['any_terms'])
contract_restored['obligations'][0]['evidence_requirements']['pattern_occluder_phrase']['must_mention_any']=copy.deepcopy(cb['obligations'][0]['evidence_requirements']['pattern_occluder_phrase']['must_mention_any'])
assert contract_restored==cb
suffixes={'pattern_source_phrase':' from the upper window toward the joined plaster wall', 'pattern_occluder_phrase':' across the curved plaster wall and adjoining return', 'pattern_structure_phrase':' along the curved wall and adjacent recessed return', 'pattern_deformation_phrase':' around the rounded wall corner and the recessed join', 'pattern_receivers_phrase':' across the rounded wall corner and the adjacent plaster return'}
legacy={f:r['must_mention_any'][0]+suffixes[f] for f,r in p['evidence_requirements'].items()}
lattice={**legacy,'pattern_occluder_phrase':q['evidence_requirements']['pattern_occluder_phrase']['must_mention_any'][-1]+suffixes['pattern_occluder_phrase']}
def audit(c,e,prose=None):return ac.audit_visual_obligations({'visual_obligations':c},{'visual_obligation_evidence':{PID:e}},prose if prose is not None else '. '.join(e.values()))
assert audit(cb,legacy)==audit(cq,legacy)==[]
lbefore=audit(cb,lattice);assert len(lbefore)==1 and lbefore[0]['field']=='pattern_occluder_phrase'
assert audit(cq,lattice)==[]
chains=[]
for lang,lang_index in [('en',0),('ko',1)]:
 for kind,oi in [('legacy_leaf_slat',lang_index),('lattice',lang_index+2)]:
  ts=[g['any_terms'][lang_index] for g in p['semantics']['component_semantics']['groups']]
  ts[1]=q['semantics']['component_semantics']['groups'][1]['any_terms'][oi]
  text='; '.join(ts); before=pg.candidate_pack_visual_component_match(p,text); after=pg.candidate_pack_visual_component_match(q,text)
  assert after=='component_semantics' and before==('component_semantics' if kind=='legacy_leaf_slat' else None)
  omissions=[]
  for i,g in enumerate(q['semantics']['component_semantics']['groups']):
   result=pg.candidate_pack_visual_component_match(q,'; '.join(t for j,t in enumerate(ts) if j!=i));assert result is None
   omissions.append({'omitted_group':g['id'],'after_match':result})
  chains.append({'language':lang,'kind':kind,'text':text,'before_match':before,'after_match':after,'omission_controls':omissions})
wrong=[
 ('printed_lattice','pattern_occluder_phrase','A printed lattice decoration covers the broad curved plaster wall and its adjoining recessed return'),
 ('no_actual_occluder','pattern_occluder_phrase','Painted dark lines decorate the curved wall without any object interrupting light from the upper window'),
 ('no_coherent_source','pattern_source_phrase','Unrelated random dark patches cover the curved plaster wall while illumination arrives from competing directions'),
 ('no_bright_dark_structure','pattern_structure_phrase','A uniform dark wash covers the plaster wall and adjoining return without alternating bright dark regions'),
 ('flat_overlay','pattern_deformation_phrase','A flat decorative projection keeps identical edges spacing and scale despite the curved wall and recessed return'),
 ('single_receiver','pattern_receivers_phrase','The lattice appears only on one isolated flat wall panel with no continuous pattern on another region'),
 ('disconnected_receivers','pattern_receivers_phrase','Different unrelated lattice shapes decorate two disconnected wall panels separated by a wide black void'),
 ('water_caustic','pattern_occluder_phrase','Refracted rays through rippling water create convergent bright caustic curves across the adjacent plaster surfaces'),
 ('volumetric_shafts','pattern_receivers_phrase','Suspended haze reveals separated luminous shafts and shadow gaps in the air without visible connected receiving surfaces'),
]
wrong_controls=[]
for name,field,text in wrong:
 e={**lattice,field:text};fs=audit(cq,e)
 assert any(f.get('field')==field and f.get('reason')=='visual evidence phrase lacks a profile-declared component anchor' for f in fs),(name,fs)
 ts=[g['any_terms'][0] for g in q['semantics']['component_semantics']['groups']];ts[1]=q['semantics']['component_semantics']['groups'][1]['any_terms'][2]
 idx_field=q['required_evidence_fields'].index(field);ts[idx_field]=text
 match=pg.candidate_pack_visual_component_match(q,'; '.join(ts));assert match is None
 wrong_controls.append({'name':name,'replaced_field':field,'replacement':text,'component_match_after':match,'audit_failures':fs})
missing=[]
for field in lattice:
 e={k:v for k,v in lattice.items() if k!=field};fs=audit(cq,e);assert fs
 missing.append({'removed_field':field,'failures':fs})
literal_failure=audit(cq,lattice,'. '.join(v for k,v in lattice.items() if k!='pattern_occluder_phrase'))
assert any(f.get('field')=='pattern_occluder_phrase' for f in literal_failure)
# Negation of the exact canonical phrase probes the boundary of a literal-anchor checker; it is not a patch regression.
limitations=[]
for label,e,c in [('legacy',legacy,cb),('lattice',lattice,cq)]:
 contrad={**e,'pattern_occluder_phrase':'It is not true that '+e['pattern_occluder_phrase']}
 fs=audit(c,contrad)
 limitations.append({'kind':label,'case':'negated_anchor_retained','text':contrad['pattern_occluder_phrase'],'failures':fs,'interpretation':'A literal checker is not a semantic entailment or pixel verifier; passing contradictory anchor prose must not be reported as physical occlusion proof.'})
requests=['Photograph an ordinary cast shadow on a wall.','Photograph a printed lattice motif on fabric.','Photograph fog illuminated by a broad lamp.','Photograph a tabletop with water caustic patterns.','Photograph an isolated lattice pattern on one wall.','Photograph a digital lattice projection pasted flat across a curved wall.','Photograph reflected window-grid light shimmering on two polished walls.','Photograph refractive glass grid caustics across a wall and its adjoining return.']
routing=[]
for text in requests:
 r=pg.resolve_visual_profile_hits(reg,[{'source':'concept_lock','text':text,'polarity':'required','priority':'critical','mandatory':True}],visual_profile_index=idx,adult_context=False)
 hits=[h for h in r['hits'] if h['profile_id']==PID and h.get('hard_eligible')];assert not hits
 routing.append({'text':text,'target_hard_hits_current_real_index':hits,'expected_after_exact_only':'unchanged because all exact lookup and activation fields are byte-equivalent; not a measured proposed-index result'})
positive={}; fields={}
for name,x in [('before',p),('accepted',q)]:
 t=pg.visual_profile_semantic_text(x); (O/f'{name}-positive-text.txt').write_text(t+'\n')
 positive[name]={'sha256':sha(t.encode()),'characters':len(t),'utf8_bytes':len(t.encode())}
 fields[name]=pg.visual_profile_bm25f_fields(x)
field_changes={k:{'added':[v for v in fields['accepted'][k] if v not in fields['before'][k]],'removed':[v for v in fields['before'][k] if v not in fields['accepted'][k]]} for k in fields['before'] if fields['before'][k]!=fields['accepted'][k]}
assert set(field_changes)=={'visual_components','support_cues'}
assert sum(len(v['added']) for v in field_changes.values())==3
assert idx['entries'][PID]['text_sha256']==positive['before']['sha256']
# Metadata deliberately rejects the old index against proposed source. No proposed index is fabricated.
try:pg.validate_visual_profile_index_metadata(idx,regq)
except ValueError as ex:stale_index_error=str(ex)
else:raise AssertionError('Stale source-bound index was unexpectedly accepted')
reusable=ib.reusable_vectors([IDX],regq,provider=idx['provider'],model=idx['embedding_model'],dimensions=idx['embedding_dimensions'])
nonreusable=sorted(set(x['id'] for x in regq['profiles'])-set(reusable));assert nonreusable==[PID]
# BM25F payload is calculated as lexical consequences only, never saved as a runtime/index substitute.
bm_before=pg.build_visual_profile_bm25f_payload(reg);bm_after=pg.build_visual_profile_bm25f_payload(regq)
assert bm_before==idx['bm25f'] and bm_before!=bm_after
index_consequences={'positive_text':positive,'positive_fields_changes':field_changes,'evidence_only_fourth_string_enters_positive_projection':False,'exact_lookup_equal':exact_before==exact_after,'before_registry_sha256':pg.visual_profile_registry_sha256(reg),'accepted_registry_sha256_hypothetical':pg.visual_profile_registry_sha256(regq),'current_index_registry_sha256':idx['registry_sha256'],'stale_current_index_rejected_for_hypothetical_registry':stale_index_error,'profile_count':len(reg['profiles']),'vector_reusable_profiles':len(reusable),'genuine_embedding_refresh_required_for':nonreusable,'provider':idx['provider'],'embedding_model':idx['embedding_model'],'embedding_dimensions':idx['embedding_dimensions'],'bm25f_before_sha256':canon(bm_before),'bm25f_accepted_sha256_hypothetical':canon(bm_after),'bm25f_top_level_changed_keys':[k for k in bm_before if bm_before[k]!=bm_after[k]],'candidate_sidecar_expected_change':False,'runtime_or_routing_change_required':False,'qualification':'One changed positive visual-profile text. Existing target vector cannot legitimately be relabelled. Rebuild registry binding and BM25F from source, use a genuine new target embedding and cache all same-text compatible vectors. Counts/hashes are pinned to this merge-in-progress snapshot and must be recomputed after integration.'}
save('index-consequences.json',index_consequences)
save('consumer-proof-independent.json',{'claim_scope':'Local pure source functions, current genuine hash-bound index, and hypothetical in-memory source contract only. All recovery inputs are author-constructed canonical anchors. No public CLI AFTER, provider or pixel success.','legacy_evidence':legacy,'lattice_evidence':lattice,'legacy_before_failures':audit(cb,legacy),'legacy_accepted_failures':audit(cq,legacy),'lattice_before_failures':lbefore,'lattice_accepted_failures':audit(cq,lattice),'language_chains':chains,'missing_evidence_fields':missing,'wrong_neighbor_replacement_controls':wrong_controls,'literal_prompt_absence_failure':literal_failure,'current_genuine_index_wrong_neighbor_exact_routing':routing,'known_literal_checker_limitations':limitations,'same_five_gates':cb['required_hard_gates']==cq['required_hard_gates'],'entire_other_materialized_contract_unchanged':contract_restored==cb})
save('frozen-patch.json',{**prop,'status':'ACCEPTED_FROZEN_SOURCE_PROPOSAL_NOT_APPLIED','review_head':head,'review_merge_head':merge,'review_disposition':'Accept original four append-only strings unchanged; qualify proof as artificial canonical source-contract recovery','patch_size_strings':4,'candidate_record_sha256':canon(candidate),'positive_text_before_sha256':positive['before']['sha256'],'positive_text_accepted_sha256':positive['accepted']['sha256']})
save('manifest.json',{'review_timestamp_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'repository':str(R),'head':head,'merge_head':merge,'status_at_review_start':status,'source_profile_pointer':f'/profiles/{source["profiles"].index(p)}','source_profile_before_sha256':canon(p),'source_profile_accepted_sha256':canon(q),'candidate_record_sha256':canon(candidate),'actual_index_entry_sha256':canon(idx['entries'][PID]),'original_artifacts_sha256':{n:sha((OLD/n).read_bytes()) for n in ['REPORT.md','minimal-source-proposal.json','consumer-proof.json','proposed-profile.json']},'tracked_file_hashes_before':initial,'tracked_file_hashes_after':fingerprint(tracked),'source_changed_by_any_worker_during_probe':initial[str(SRC.relative_to(R))]!=sha(SRC.read_bytes()),'repository_write_performed_by_review':False,'provider_calls':0,'install_or_publish_actions':0})
print(json.dumps({'disposition':'ACCEPT FOUR STRINGS UNCHANGED','profiles':len(reg['profiles']),'changed_profiles':changed_profiles,'before_sha256':canon(p),'accepted_sha256':canon(q),'vector_refresh_needed':nonreusable,'all_korean_chain_after':next(x['after_match'] for x in chains if x['language']=='ko' and x['kind']=='lattice'),'wrong_neighbor_controls':len(wrong_controls),'canonical_chain_omission_controls':sum(len(x['omission_controls']) for x in chains),'literal_checker_limitations':limitations,'index_consequences':index_consequences},ensure_ascii=False,indent=2))
