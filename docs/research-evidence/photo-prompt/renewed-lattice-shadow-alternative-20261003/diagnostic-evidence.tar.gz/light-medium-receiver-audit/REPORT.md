# Light / medium / receiver DATA audit

## Result

One demonstrated source-consistency defect and one frozen minimal proposal, not applied:

- `patterned_cast_shadow_receiver_continuity` explicitly permits a **lattice** occluder in its definition, composition instruction, render gate, candidate row, and original research intent
- Its required occluder component and evidence alternatives contain only **leaf or slat**
- An exact request for the declared pattern relation activates five hard gates through the current production resolver and actual hash-bound index. A lattice-only evidence phrase fails exactly `pattern_occluder_phrase` because the only accepted anchor says leaf or slat
- The frozen proposal adds a lattice-specific English component anchor, corresponding Korean component anchor, lattice concept term, and English evidence alternative. All existing alternatives, exact aliases, source direction, five components, two connected receivers, curvature/depth relation, evidence thresholds, rejection controls, and render gates remain unchanged

No repository source, test, runtime, index or vector was changed by this worker. No provider or external-agent calls, remote writes, web research or image generation were used.

## Strongest source evidence

Source profile: `skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations_reactorprompt.json`, profile `patterned_cast_shadow_receiver_continuity`.

Before canonical profile SHA-256: `87e318b6f31dce32bc451bded7c9a730b28e70c8ad4a8a2fc7884df9ba2a8cc9`.

- `/semantics/definition`: explicitly “leaf, slat, or lattice”
- `/composition_instruction`: explicitly “leaf, slat, or lattice”
- `/render_gates/1/description`: explicitly “leaf, slat, or lattice”
- `/semantics/component_semantics/groups/1/any_terms`: only English leaf/slat and Korean leaf/slat alternatives
- `/evidence_requirements/pattern_occluder_phrase/must_mention_any`: only the English leaf/slat anchor
- Original repository research at `docs/research-evidence/photo-prompt/reactorprompt-incremental-visual-semantics-20260902/topics/04-lighting-exposure-material-response.md`, lines 262–293, explicitly includes leafy/slatted/lattice patterns and the same five required relations
- Current candidate `light_shape:patterned_cast_shadow_receiver_continuity` in `photo_prompt_reactorprompt_visual_relations_extension.json` also explicitly lists leaf/slat/lattice

This is source agreement across five surfaces versus a missing declared alternative, not a newly inferred optical fact.

## Frozen proposal

`minimal-source-proposal.json` contains four append-only JSON changes to one source profile. `proposed-profile.json` is the complete proposed source record. The English lattice anchor is:

“an identifiable lattice occluder grammar shapes the cast pattern”

The original 10-content-word evidence minimum stays in force. A complete prompt evidence phrase adds concrete receiver detail rather than reducing that threshold.

The proposal deliberately does not change brightness-pattern wording, generic profile scope, source visibility, atmospheric behavior, or the two-connected-receivers requirement. A legitimate semantic-index refresh would be needed if this source proposal were later applied. No frozen proposal is a request or authorization to call a provider.

## Measured consumer scope

See `consumer-proof.json` and reproducible `probe.py`.

Actual current production functions used:

1. Registry loader and genuine hash-bound index loader
2. Request-only source extraction and exact profile resolver
3. Public obligation projection
4. Literal composed-evidence audit

Results:

- Legacy source-prescribed leaf/slat evidence: 0 failures
- Lattice-only occluder evidence: exactly 1 missing-anchor failure in the current contract
- Same evidence under the in-memory proposed source: 0 failures
- Legacy evidence under proposed source: 0 failures
- Complete five-group lattice component chain, English and Korean: no component match before; `component_semantics` match in the proposal
- Remove any one component from either language chain: no match (10 omission controls)
- Remove any evidence field: rejected (5 controls)
- Replace required evidence with a printed-pattern, no-source, flat-overlay or single-receiver statement: corresponding anchor still rejected (4 controls)
- Five generic/candidate-only requests: no target hard activation in the current exact-only path
- Same five gate IDs and same evidence minimums before/proposed

These controls test source materialization and literal-anchor contracts. They do not establish a model's semantic understanding of free paraphrases, full CLI retrieval quality, pixel geometry, or image success. The proposed profile was never bound to a fabricated index. Hypothetical AFTER is explicitly in-memory source materialization, not a public-CLI AFTER claim.

The initial probe used bare anchors without enough concrete content; the audit correctly rejected the harness input for minimum-word counts. The corrected probe adds scene-specific detail while preserving all thresholds. `diagnostic-log.md` records this harness-only correction.

## Receiver-language leads deferred

### `volumetric_occluded_light_shafts`

The definition/composition say “receiving surfaces,” while component 5, concept terms, evidence and gate explicitly preserve “subject floor wall or atmospheric layer.” The original lighting proposal already contains both wordings.

This is a prose-specificity mismatch, but this audit did not establish that the mandatory consumer contract rejects a visible atmospheric-layer receiver or requires adding a solid surface. The optional surface-color candidate may intentionally choose a surface realization. **No frozen patch.** Do not remove the visible scattering medium, identifiable occluder, separated shafts/shadow gaps or allowed receiver relation.

### `phantasmagoria_projected_spectral_sequence`

The definition/component/evidence/gate explicitly allow a wall; composition summarizes “haze or screen.” The original museum-derived repository source lists wall, smoke and translucent screen.

A projection wall can function as a screen, and the mandatory receiving-surface evidence explicitly retains wall. No forced wall-to-haze substitution was demonstrated. The haze/screen candidate is allowed to be narrower than the full profile. **No frozen patch.** Keep visible apparatus/operator, bounded light path, apparatus-tied sequence/scale change and separate coherent depth.

## KEEP decisions

`findings.json` records every inspected ID, per-record hash, disposition and rationale. Eighteen profiles are KEEP; two are DEFER; one has the frozen source proposal.

- Optical ghosting, veiling flare, diffusion-filter halos and selected warm film-edge halo remain distinct. Near/inside-frame wording is not a blanket excuse to relax declared source visibility
- Wet reflection remains intentionally in-frame-owner + wet/dry-transition scoped
- Glass/transmitted-face/reflection owners stay separate; mirror-led and handheld-mirror selected manifestations keep their stated body/hand evidence
- Peripheral refraction retains displacement OR spectral-separation alternatives without requiring actual prism hardware
- Rim-with-readable-front, silhouette mass, motivated visible practical light and low-sun shadow relations remain intentionally narrow
- The near-and-far shallow-focus transition relation is a specific variant; it is not redefined as all shallow-depth photography
- Water caustic, tabletop caustic, face caustic and prism-flare rows are candidate-only scoped manifestations. No mandatory caustic profile was identified in the complete current registry. Reflection-related tags alone are not enough to infer a wrong physical mechanism
- The already-fixed hard/soft receiver-material profiles were excluded from new-proposal work

## Source pin and concurrent work

Pinned commit: `7307343d59bcd09624c2ea2aad461d8d5d9dd026`.

Inspection captured 21 complete source profiles, their compiled contracts, 27 candidate rows and source file hashes. The actual registry load contained 1,507 profiles.

During this audit, the parent applied a separately authorized food actor-count source correction and genuine profile-vector refresh. The poverty registry extension and the whole bound visual index changed; a food recovery test also appeared. These are unrelated concurrent changes and are neither this worker's edits nor evidence that this audit preserved the entire registry/index byte-for-byte.

`concurrent-change-reconciliation.json` verifies that all 21 inspected light/optical profile records, all 27 inspected candidate records, and all 21 inspected profile index entries are unchanged against pinned HEAD and snapshots. It records exact current status and whole-index hashes. The production index was successfully loaded against the actual working registry.

## Files

- `manifest.json`: source pin, full-file hashes, registry size, initial concurrent status
- `source-profile-snapshots.json`: full source records, pointers and canonical hashes
- `compiled-profile-snapshots.json`: complete production-loaded contracts
- `source-candidate-snapshots.json`: candidate scope and exact source rows
- `findings.json`: complete KEEP/DEFER/proposal inventory
- `minimal-source-proposal.json` and `proposed-profile.json`: frozen one-profile proposal
- `consumer-proof.json`: measured current failure, hypothetical source-only result and unchanged-boundary controls
- `concurrent-change-reconciliation.json`: exact pin/current reconciliation
- `snapshot.py`, `probe.py`, `finalize.py`: local diagnostic scripts

Stopping condition reached: bounded source audit complete, strongest exact contradiction isolated, minimal proposal frozen, alternatives and controls recorded. Implementation and any paid refresh require the parent's separate authorized workflow.
