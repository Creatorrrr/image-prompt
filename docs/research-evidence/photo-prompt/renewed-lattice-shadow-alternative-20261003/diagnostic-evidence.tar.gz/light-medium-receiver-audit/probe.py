"""Source/consumer diagnostic. No provider call, vector fabrication, or repository write."""
import copy,json,hashlib,sys,subprocess
from pathlib import Path
R=Path('REPOSITORY_ROOT');O=Path(__file__).parent;A=R/'skills/photo-prompt-image-generator/assets'
sys.path.insert(0,str(A.parent/'scripts'))
import prompt_generator as pg
import audit_composed_prompt as ac
sha=lambda b:hashlib.sha256(b).hexdigest()
canon=lambda x:sha(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())
def save(name,x):(O/name).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
pid='patterned_cast_shadow_receiver_continuity'
records=json.loads((O/'source-profile-snapshots.json').read_text());snap=next(x for x in records if x['profile_id']==pid)
raw=json.loads((R/snap['file']).read_text())['profiles'][int(snap['json_pointer'].split('/')[-1])]
assert canon(raw)==snap['canonical_sha256']
reg=pg.load_visual_obligation_registry(A/'photo_prompt_visual_obligations.json')
idx=pg.load_visual_profile_index(A/'photo_prompt_visual_profile_index.json',reg)
p=next(p for p in reg['profiles'] if p['id']==pid)
q=copy.deepcopy(p)
lattice_en='an identifiable lattice occluder grammar shapes the cast pattern'
lattice_ko='식별 가능한 격자 차폐 문법이 투사 패턴을 만듦'
q['semantics']['component_semantics']['groups'][1]['any_terms'] += [lattice_en,lattice_ko]
q['concept_candidate']['concept_terms'] += ['lattice occluder grammar']
q['evidence_requirements']['pattern_occluder_phrase']['must_mention_any'] += [lattice_en]
changes=[{'op':'add','path':'/semantics/component_semantics/groups/1/any_terms/2','value':lattice_en},
 {'op':'add','path':'/semantics/component_semantics/groups/1/any_terms/3','value':lattice_ko},
 {'op':'add','path':'/concept_candidate/concept_terms/7','value':'lattice occluder grammar'},
 {'op':'add','path':'/evidence_requirements/pattern_occluder_phrase/must_mention_any/1','value':lattice_en}]
save('minimal-source-proposal.json',{'status':'FROZEN_PROPOSAL_ONLY_NOT_APPLIED','head_pin':'7307343d59bcd09624c2ea2aad461d8d5d9dd026','source_file':snap['file'],'profile_pointer':snap['json_pointer'],'profile_id':pid,'before_canonical_sha256':canon(raw),'proposed_canonical_sha256':canon(q),'changes':changes,'unchanged_boundaries':['all exact aliases','five required component IDs and threshold','all five evidence field IDs and minimum word counts','all five render gates and review scales','composition_instruction','definition','all legacy component and evidence anchors','all rejection substitutes','all visual_relation ownership/visibility/occlusion/crop constraints','candidate slot records','all other profiles','runtime and routing code'],'qualification_limit':'In-memory source proposal materialization only. Semantic index must be legitimately refreshed if applied; no public-CLI AFTER or pixel success claimed.'})
save('proposed-profile.json',q)
request='Photograph patterned cast shadow receiver continuity from a lattice screen onto a curved plaster wall and its joined return, with one coherent source direction and visible deformation across both receiver regions.'
res={'provenance':{'concept_lock':[request]}}
sources=pg.candidate_pack_visual_obligation_request_sources(res,{})
resolution=pg.resolve_visual_profile_hits(reg,sources,visual_profile_index=idx,adult_context=False)
c=pg.candidate_pack_visual_obligations({pg.VISUAL_OBLIGATIONS_DATA_KEY:reg},res,{},None,visual_profile_resolution=resolution)
assert c and [o['id'] for o in c['obligations']]==[pid]
o=c['obligations'][0]
suffixes = {'pattern_source_phrase': ' from the high window at camera left', 'pattern_occluder_phrase': ' across the curved plaster receiver', 'pattern_structure_phrase': ' on the upper connected receiver plane', 'pattern_deformation_phrase': ' around the rounded corner and shallow recessed edge', 'pattern_receivers_phrase': ' linking the curved wall and its adjoining return'}
ev={f:r['must_mention_any'][0]+suffixes[f] for f,r in o['evidence_requirements'].items()}
def audit(contract,evidence):return ac.audit_visual_obligations({'visual_obligations':contract},{'visual_obligation_evidence':{pid:evidence}},'. '.join(evidence.values()))
base=audit(c,ev);assert not base,base
lattice_ev={**ev,'pattern_occluder_phrase':lattice_en+' across the curved plaster receiver'}
before=audit(c,lattice_ev)
assert len(before)==1 and before[0]['field']=='pattern_occluder_phrase' and before[0]['reason']=='visual evidence phrase lacks a profile-declared component anchor',before
new_o=pg.candidate_pack_visual_profile_obligation(q,reg,activation_source='explicit_request_semantics',source_intent_ids=['source_consistency_diagnostic'])
new_c={'enabled':True,'contract_version':pg.VISUAL_OBLIGATIONS_CONTRACT_VERSION,'strict_gate_set':True,'obligations':[new_o],'required_hard_gates':[g['id'] for g in new_o['render_gates']]}
assert not audit(new_c,lattice_ev)
assert not audit(new_c,ev)
terms=[g['any_terms'][0] for g in p['semantics']['component_semantics']['groups']]
lexical=[]
for lang,term in [('en',lattice_en),('ko',lattice_ko)]:
 t=terms.copy();t[1]=term
 pre=pg.candidate_pack_visual_component_match(p,'; '.join(t));post=pg.candidate_pack_visual_component_match(q,'; '.join(t))
 assert pre is None and post=='component_semantics',(lang,pre,post)
 missing=[]
 for i in range(5):
  r=pg.candidate_pack_visual_component_match(q,'; '.join(v for j,v in enumerate(t) if i!=j));assert r is None
  missing.append({'omitted_group':q['semantics']['component_semantics']['groups'][i]['id'],'match':r})
 lexical.append({'language':lang,'before_match':pre,'proposed_match':post,'missing_group_controls':missing})
controls=[]
for field in ev:
 e={k:v for k,v in lattice_ev.items() if k!=field};f=audit(new_c,e);assert f
 controls.append({'kind':'missing_evidence_field','field':field,'failures':f})
for label,field,phrase in [('printed-pattern','pattern_occluder_phrase','An attractive printed lattice motif decorates the curved plaster receiver surface'),('no-source','pattern_source_phrase','The decorative dark pattern has no coherent illumination owner across the curved wall'),('flat-overlay','pattern_deformation_phrase','The projected pattern keeps the same flat scale irrespective of wall curvature and depth'),('single-receiver','pattern_receivers_phrase','The lattice pattern appears only on one flat isolated wall area in this photograph')]:
 e={**lattice_ev,field:phrase};fs=audit(new_c,e);assert any(f.get('field')==field for f in fs),(label,fs)
 controls.append({'kind':'specific_anchor_removed','label':label,'field':field,'evidence':phrase,'failures':fs})
negative_requests=['Photograph an ordinary cast shadow on a wall.','Photograph a printed lattice motif on fabric.','Photograph fog illuminated by a broad lamp.','Photograph a tabletop with water caustic patterns.','Photograph an isolated lattice pattern on one wall.']
neg=[]
for text in negative_requests:
 r=pg.resolve_visual_profile_hits(reg,[{'source':'concept_lock','text':text,'polarity':'required','priority':'critical','mandatory':True}],visual_profile_index=idx,adult_context=False)
 hard=[h for h in r['hits'] if h['profile_id']==pid and h.get('hard_eligible')]
 assert not hard
 neg.append({'request':text,'target_hard_hits':hard})
save('consumer-proof.json',{'scope':'Actual current-registry and genuine hash-bound index exact resolution, production obligation projection and literal evidence audit; hypothetical AFTER uses only an in-memory proposed source profile. No provider, image, broad retrieval-quality or full CLI claim.','head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'status_at_probe':subprocess.check_output(['git','status','--short'],cwd=R,text=True),'registry_file_sha256':sha((A/'photo_prompt_visual_obligations.json').read_bytes()),'index_file_sha256':sha((A/'photo_prompt_visual_profile_index.json').read_bytes()),'actual_index_loaded':True,'source_profile_hash_unchanged_from_snapshot':True,'request':request,'exact_hits':[h for h in resolution['hits'] if h['match_basis']=='exact'],'materialized_contract':c,'legacy_evidence':ev,'legacy_before_failures':base,'lattice_evidence':lattice_ev,'lattice_before_failures':before,'lattice_proposed_failures':audit(new_c,lattice_ev),'legacy_proposed_failures':audit(new_c,ev),'lexical_variants':lexical,'negative_controls':controls,'generic_requests':neg,'same_gate_ids':c['required_hard_gates']==new_c['required_hard_gates'],'evidence_minimums_unchanged':{f:r['min_content_words'] for f,r in p['evidence_requirements'].items()}=={f:r['min_content_words'] for f,r in q['evidence_requirements'].items()}})
print(json.dumps({'baseline_failures':base,'lattice_before_failures':before,'lattice_proposed_failures':audit(new_c,lattice_ev),'lexical_variants':lexical,'negative_control_count':len(controls),'generic_request_count':len(neg),'gate_count':len(c['required_hard_gates'])},ensure_ascii=False,indent=2))
