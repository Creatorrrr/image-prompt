import json,hashlib,subprocess,sys
from pathlib import Path
R=Path('REPOSITORY_ROOT'); O=Path(__file__).parent;A=R/'skills/photo-prompt-image-generator/assets'
IDS='volumetric_occluded_light_shafts patterned_cast_shadow_receiver_continuity phantasmagoria_projected_spectral_sequence lens_ghosting_flare_alignment veiling_flare_contrast_loss_relation diffusion_filter_highlight_halation wet_surface_light_reflection_owner_relation rb_glass_reflection_transmission rb_shared_cast_shadow pc_pc21_owner_relation pc_pc22_owner_relation pc_pc23_owner_relation pc_pc24_owner_relation film_halation_highlight_edge_relation backlit_rim_edge_separation_relation backlit_silhouette_mass_relation golden_hour_low_sun_relation motivated_practical_mixed_interior_relation shallow_depth_focus_falloff_relation rb_optional_lens_falloff mirror_selfie_reflection_device_topology'.split()
sha=lambda b:hashlib.sha256(b).hexdigest()
canon=lambda o:sha(json.dumps(o,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())
def save(name,obj): (O/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
profiles=[];paths=set()
for f in A.glob('photo_prompt_visual_obligations*.json'):
 for i,p in enumerate(json.loads(f.read_text()).get('profiles',[])):
  if p['id'] in IDS:
   profiles.append({'file':str(f.relative_to(R)),'json_pointer':f'/profiles/{i}','profile_id':p['id'],'canonical_sha256':canon(p),'profile':p});paths.add(f)
assert set(IDS)=={r['profile_id'] for r in profiles}
save('source-profile-snapshots.json',profiles)
CIDS=set('underwater_caustics underwater_caustic_light surface_caustic_light prism_flare_light pool_caustic_reflections waterline_caustic_face water_caustic_table_pattern single_flashlight_beam projected_spectral_succession projected_spectral_scale_shift_light_cone patterned_cast_shadow_receiver_continuity pc_pc21_component_1 pc_pc21_component_2 pc_pc21_component_3 pc_pc21_component_4 pc_pc24_component_1 pc_pc24_component_2 pc_pc24_component_3 pc_pc24_component_4'.split())
candidates=[]
for fn in ['photo_prompt_tags.json','photo_prompt_lighting_extension.json','photo_prompt_imaginal_extension.json','photo_prompt_reactorprompt_visual_relations_extension.json','photo_prompt_portrait_composition_extension.json']:
 f=A/fn;d=json.loads(f.read_text());paths.add(f)
 for slot,rows in d.get('slots',{}).items():
  for i,c in enumerate(rows):
   if c['id'] in CIDS or c['id'].startswith('lit_volume_'):
    candidates.append({'file':str(f.relative_to(R)),'json_pointer':f'/slots/{slot}/{i}','slot':slot,'candidate_id':c['id'],'canonical_sha256':canon(c),'candidate':c})
save('source-candidate-snapshots.json',candidates)
for p in ['GOAL_PLAN.md','skills/photo-prompt-image-generator/SKILL.md','skills/photo-prompt-image-generator/scripts/prompt_generator.py','skills/photo-prompt-image-generator/scripts/audit_composed_prompt.py','skills/photo-prompt-image-generator/scripts/visual_profile_contracts.py','skills/photo-prompt-image-generator/assets/photo_prompt_visual_profile_index.json','docs/research-evidence/photo-prompt/lighting-visual-semantics-20260902/source-research.md','docs/research-evidence/photo-prompt/lighting-visual-semantics-20260902/candidate-data-proposal.json','docs/research-evidence/photo-prompt/lighting-visual-semantics-20260902/evidence.jsonl','docs/research-evidence/photo-prompt/reactorprompt-incremental-visual-semantics-20260902/topics/04-lighting-exposure-material-response.md','docs/research-evidence/photo-prompt/imaginal-visual-semantics-20260901/source-research.md','docs/research-evidence/photo-prompt/portrait-composition-20260927/report.md','docs/research-evidence/photo-prompt/realistic-background-20260912/visual-catalog.md','tests/test_photo_receiver_material_response.py','tests/test_photo_reactorprompt_visual_relations.py']:
 paths.add(R/p)
sys.path.insert(0,str(A.parent/'scripts'));import prompt_generator as pg
reg=pg.load_visual_obligation_registry(A/'photo_prompt_visual_obligations.json');idx=pg.load_visual_profile_index(A/'photo_prompt_visual_profile_index.json',reg)
save('compiled-profile-snapshots.json',[p for p in reg['profiles'] if p['id'] in IDS])
save('manifest.json',{'scope':'read-only DATA source-consistency audit; profile canonical hashing uses sorted keys and compact UTF-8 JSON; file hashing uses exact bytes','head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'git_status_before':subprocess.check_output(['git','status','--short'],cwd=R,text=True),'actual_index_loaded':True,'full_registry_profile_count':len(reg['profiles']),'inspected_profile_count':len(profiles),'inspected_candidate_count':len(candidates),'source_files':[{'path':str(f.relative_to(R)),'sha256':sha(f.read_bytes())} for f in sorted(paths)]})
print(json.dumps({'profiles':len(profiles),'candidates':len(candidates),'actual_index_loaded':True,'full_registry_profiles':len(reg['profiles'])}))
