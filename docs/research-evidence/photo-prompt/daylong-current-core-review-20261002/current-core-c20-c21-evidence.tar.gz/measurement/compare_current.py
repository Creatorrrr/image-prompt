#!/usr/bin/env python3
"""Bounded, zero-network helper comparison; never a proposed-index CLI validation."""
from __future__ import annotations
import copy, datetime, hashlib, json, pathlib, socket, subprocess, sys, urllib.request
from unittest.mock import patch
sys.dont_write_bytecode = True
ROOT = pathlib.Path('/workspace/scratch/ce8f20680f5a')
REPO = ROOT/'image-prompt'
BASE = ROOT/'daylong-progress'
OUT = BASE/'current-core-comparisons'
SKILL = REPO/'skills/photo-prompt-image-generator'
sys.path.insert(0, str(SKILL/'scripts'))
import prompt_generator as g
import audit_composed_prompt as audit
import compose_pack_view as views

def digest_bytes(value): return hashlib.sha256(value).hexdigest()
def hash_file(path): return digest_bytes(path.read_bytes())
def canonical(value): return g.canonical_json_sha256(value)
def read(path): return json.loads(path.read_text())
def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n')
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def fail_network(*args, **kwargs): raise AssertionError('ZERO-CALL: embedding/network invocation forbidden')

def freeze_inputs(cycle, expected_manifest):
    authored=BASE/'current-core-inputs'/f'{cycle}-authored'
    manifest_path=next(authored/name for name in ('final_freeze_manifest.json','freeze_manifest.final.json','authoring_freeze_manifest.json') if (authored/name).exists())
    assert hash_file(manifest_path)==expected_manifest, 'author freeze changed'
    manifest=read(manifest_path)
    rows=[]; objects={}
    for item in manifest['cases']:
        cid=item['case_id']; folder=authored/cid
        declared=item.get('files') or {name.split('/',1)[1]:value for name,value in manifest['files'].items() if name.startswith(cid+'/')}
        hashes={name:hash_file(folder/name) for name in declared}
        assert hashes==declared, f'authored bytes changed: {cid}'
        row={'case_id':cid,'input_hashes':hashes}
        try:
            envelope=g.load_request_envelope_arg(str(folder/'request_envelope.json'))
            controls=read(folder/'creative_controls.json')
            core=g.load_authorial_core_arg(str(folder/'authorial_core.json'), request_envelope=envelope, creative_control_snapshot=controls)
            embodiment=read(folder/'embodiment_review.json')
            policy=g.photo_embodiment.build_policy(core,embodiment)
            row.update(status='pass',normalized_core_sha256=core['canonical_sha256'],normalized_envelope_sha256=canonical(envelope),embodiment_policy_sha256=policy['canonical_sha256'])
            objects[cid]=(envelope,controls,core,embodiment)
            write(OUT/cycle/'normalized_inputs'/f'{cid}.json',{'request_envelope':envelope,'creative_controls':controls,'authorial_core':core,'embodiment_review':embodiment})
        except Exception as exc:
            row.update(status='fail',error_type=type(exc).__name__,error=str(exc))
        rows.append(row)
    write(OUT/cycle/'preflight.json',{'utc':now(),'candidate_data_loaded':False,'rows':rows})
    assert len(rows)==16 and len(objects)==16, 'authored preflight incomplete; do not load corpus'
    return authored,objects

def frozen_proposal(cycle):
    if cycle=='c20':
        source=BASE/'rabbit-ear-korean-label-scout/proposal-and-core.json'; original=read(source)
        return {'slot':'species_marker','entry_id':'lagomorph_long_sensory_ears','field':'ko','before':original['before'],'proposal':original['proposal'],'source':str(source),'source_sha256':hash_file(source)}
    source=BASE/'korean-technical-name-scout/source-inventory-and-decisions.json'; original=read(source)['lead']
    return {'slot':'location','entry_id':'lighthouse_lamp_room','field':'aliases','before':original['current_row'],'proposal':dict(original['current_row'],aliases=original['proposal']['aliases']),'source':str(source),'source_sha256':hash_file(source),'historical_source_sha256':original['source_sha256'],'historical_row_sha256':original['source_row_sha256']}

def freeze_measurement(cycle, authored, inputs, expected_manifest):
    proposal=frozen_proposal(cycle)
    source_paths=sorted([p for directory in ('assets','scripts','precore') for p in (SKILL/directory).rglob('*') if p.is_file() and p.suffix in ('.py','.json')])
    criteria={
      'provenance':'Synthetic engineering fixtures authored candidate-free from coordinator envelopes; not actual new user photo messages',
      'scope':'Pre-call helper comparison only. Saved semantic index remains baseline and is unused for ordinary slot-only BM25F retrieval. No proposed-index CLI validity claimed.',
      'benefit':'Require meaningful positive current-consumer benefit: new appropriate positive exposure or another demonstrated usability gain beyond Korean text presence. Rank-only changes are reported separately and are not automatic acceptance.',
      'regressions':'Defer on harmful newly exposed identity/setting, lost relevant sibling/coowner coverage, or no meaningful benefit. Record all candidate inclusion/removal/order/content changes, including non-target slots under the shared cap.',
      'c20':'Sound reaction is distinct from ear-root attachment alone. Review both specific ear-root sibling coverage and costume coexistence; auditory exposure on ear-root-only is not proven relevance or runtime protection. Keep canid and rodent identity separate.',
      'c21':'Preserve studio/workshop/museum/standalone-lens settings. Fresnel apparatus alone must not infer lighthouse. Generic lantern-room overlap is ambiguous, not automatically a wrong identity.',
      'optional':'Every slot selected stays null and adoption remains optional; unchanged baseline with all optional candidates rejected is evidence of contract preservation only, not rendered semantic safety.',
      'fixed_representatives':(['rabbit_sound_ko','ear_root_only_ko','ear_root_coexistence_ko','costume_coexistence_ko'] if cycle=='c20' else ['rotating_optic_keeper_ko','studio_fresnel_fixture_ko','museum_fresnel_display_ko','standalone_fresnel_workbench_ko']),
      'no_tuning':'No wording, query, core, control or criterion tuning after first retrieval; structural preflight failures preserved separately.',
    }
    frozen={'utc_before_retrieval':now(),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip(),'git_status_before':subprocess.check_output(['git','status','--short'],cwd=REPO,text=True),'comparison_script_sha256':hash_file(pathlib.Path(__file__)),'author_manifest_sha256':expected_manifest,'proposal':proposal,'criteria':criteria,'source_runtime_index_hashes':{str(p.relative_to(REPO)):hash_file(p) for p in source_paths},'all_authored_file_hashes':{str(p.relative_to(authored)):hash_file(p) for p in sorted(authored.rglob('*.json'))},'normalized_input_hashes':{cid:canonical({'envelope':e,'controls':c,'core':core,'review':r}) for cid,(e,c,core,r) in inputs.items()}}
    write(OUT/cycle/'freeze-before-retrieval.json',frozen)
    (OUT/cycle/'comparison-script.snapshot.py').write_bytes(pathlib.Path(__file__).read_bytes())
    return frozen

def inventory(pack):
    inventories={}; content={}
    for path in views.inventory_paths(pack):
        found=views.locate(pack,path)
        if found is None: continue
        parent,key=found; rows=parent[key]
        if not isinstance(rows,list):continue
        records=[r for r in rows if isinstance(r,dict) and (r.get('id') or r.get('candidate_id'))]
        inventories[views.pointer(path)]=[str(r.get('id') or r['candidate_id']) for r in records]
        for r in records:
            candidate_id=str(r.get('id') or r['candidate_id'])
            content.setdefault(candidate_id,[]).append({'inventory_path':views.pointer(path),'candidate':r})
    return inventories,content

def delta(before,after):
    result={}
    for path in sorted(set(before)|set(after)):
        b=before.get(path,[]); a=after.get(path,[])
        if b==a:continue
        common=set(b)&set(a)
        result[path]={'before':b,'proposal':a,'included':[v for v in a if v not in b],'removed':[v for v in b if v not in a],'common_order_changed':[v for v in b if v in common]!=[v for v in a if v in common],'positions_changed':{v:{'before':b.index(v),'proposal':a.index(v)} for v in b if v in common and b.index(v)!=a.index(v)}}
    return result

def unchanged_composition(pack,embodiment):
    core=pack['authorial_core']; lock=core['intent_lock']; post=copy.deepcopy(embodiment);post['provenance']='agent_postcomposition'
    composition={'core_retrieval_sha256':pack['core_retrieval']['canonical_sha256'],'pack_id':pack['pack_id'],'prompt_en':core['baseline_prompt_en'],'negative_en':pack['negative_en'],'chosen_candidate_ids':[],'chosen_visual_concept_ids':[],'composer':'agent','candidate_interpretations':[],
     'embodiment_review':{'source_contract_sha256':pack['embodiment_preflight']['canonical_sha256'],'review':post},
     'authorial_core_binding':{'source_authorial_core_sha256':core['canonical_sha256'],'source_intent_lock_sha256':lock['canonical_sha256'],'preserved_anchor_ids':[a['anchor_id'] for a in lock['semantic_anchors']],'preserved_evidence':[],'authorial_decisions':[]},
     'semantic_clarification_decisions':[{'clarification_id':r['id'],'decision':'applied' if r.get('required_in_final_prompt') else 'rejected','rationale':'Preserve the exact frozen requester-owned baseline and all its evidence.','prompt_evidence':lock['semantic_anchors'][0]['prompt_evidence']} for r in pack['semantic_clarification']['candidates']],
     'creative_augmentation_brief':{'decisions':[{'candidate_id':r['id'],'decision':'rejected','rationale':'The exact baseline already preserves the requested meaning.'} for r in pack['creative_augmentation']['candidates']]}}
    obligation=pack.get('semantic_assertion_obligations')
    if obligation:composition['semantic_assertion_evidence']={'source_contract_sha256':obligation['canonical_sha256'],'evidence':{r['assertion_id']:r['frozen_evidence'] for r in obligation['obligations']}}
    return composition

def measure(cycle,inputs,frozen,baseline):
    output=OUT/cycle; proposal=frozen['proposal']; proposed=copy.deepcopy(baseline)
    row=next(r for r in proposed['slots'][proposal['slot']] if r['id']==proposal['entry_id'])
    assert row==proposal['before'], 'current target differs from exact original proposal'
    old=copy.deepcopy(row);row[proposal['field']]=copy.deepcopy(proposal['proposal'][proposal['field']]);assert row==proposal['proposal']
    assert {k:v for k,v in old.items() if k!=proposal['field']}=={k:v for k,v in row.items() if k!=proposal['field']}
    assert proposed[g.SEMANTIC_INDEX_DATA_KEY]==baseline[g.SEMANTIC_INDEX_DATA_KEY]
    states={'baseline':baseline,'proposal':proposed}
    meta={'utc':now(),'dictionary_hashes':{k:g.dictionary_hash(v) for k,v in states.items()},'slot_entries':sum(len(v) for v in baseline['slots'].values()),'slots':len(baseline['slots']),'saved_index_docs':len(baseline[g.SEMANTIC_INDEX_DATA_KEY]['entries']),'saved_index':'Exact baseline copy retained, not refreshed, not used for ordinary retrieval; proposed helper state is not a valid indexed CLI source'}
    write(output/'runtime-state.json',meta)
    results={}
    for cid,(envelope,controls,core,review) in inputs.items():
        records={}; packs={}
        for state,data in states.items():
            pack=g.generate_candidate_pack(data,core,controls,review,seed=20261002)
            packs[state]=pack
            observed={}
            real_retrieve=g.retrieve_core_slots
            def record_retrieval(*args,**kwargs):
                result=real_retrieve(*args,**kwargs); observed['raw_slots']=copy.deepcopy(result[0]); return result
            with patch.object(g,'retrieve_core_slots',side_effect=record_retrieval):
                recomputation=audit.audit_core_retrieval(pack,data)
            independent_slots,independent_binding,contract=g.retrieve_core_slots(data,core,controls)
            # audit compares sets; compare slot insertion order and candidate order explicitly.
            order_equal=list(observed['raw_slots'])==list(independent_slots) and all([r['id'] for r in observed['raw_slots'][s]['candidates']]==[r['id'] for r in independent_slots[s]['candidates']] for s in independent_slots)
            _,picked=g.frozen_core_context(data,core,controls)
            eligible={s:[r['id'] for r in entries if g.core_slot_entry_eligible(data,core,contract,picked,s,r)] for s,entries in data['slots'].items()}
            inventories,content=inventory(pack)
            focus={s:{'text':g.core_slot_focus_text(data,core,s)[0],'fields':g.core_slot_focus_text(data,core,s)[1]} for s in pack['slots']}
            records[state]={'pack_id':pack['pack_id'],'pack_sha256':canonical(pack),'ordinary_slot_order':list(pack['slots']),'raw_ranked_inventories':{s:[r['id'] for r in payload['candidates']] for s,payload in independent_slots.items()},'inventories':inventories,'public_content_by_id':content,'core_retrieval':pack['core_retrieval'],'whole_scene_query':g.authorial_core_retrieval_text(core)[0],'active_focus_queries':focus,'eligible_by_slot':eligible,'eligible_sha256':canonical(eligible),'generation_contract':contract,'audit_core_retrieval':recomputation,'independent_order_recomputation_equal':order_equal,'optional_invariant':pack['core_retrieval']['candidate_adoption']=='optional' and all(p['selected'] is None for p in independent_slots.values()) and all(p.get('selected') is None for p in pack['slots'].values()),'baseline_prompt_unchanged':pack['authorial_core']['baseline_prompt_en']==core['baseline_prompt_en']}
            write(output/'in-progress'/f'{cid}-{state}.json',records[state])
            assert not recomputation and order_equal and records[state]['optional_invariant'] and records[state]['baseline_prompt_unchanged']
            if cid in frozen['criteria']['fixed_representatives']:
                d=output/'representatives'/cid/state
                write(d/'full-pack.json',pack)
                overview=views.build_view(pack);views.verify_view(pack,overview);write(d/'overview.json',overview)
                ids=list(dict.fromkeys(r['id'] for r in overview['candidate_catalog']))
                if ids:
                    detail=views.build_view(pack,ids);views.verify_view(pack,detail);write(d/'detail.json',detail)
                composed=unchanged_composition(pack,review);write(d/'all-optional-rejected-composed.json',composed)
                # Full auditor correctly loads baseline source; only baseline can establish full audit here.
                if state=='baseline':write(d/'all-optional-rejected-full-audit.json',audit.audit_composed_prompt(pack,composed))
                else:write(d/'all-optional-rejected-focused-audit.json',{'source':'detached proposal supplied explicitly for retrieval recomputation','not_full_proposed_source_audit':True,'failures':audit.audit_core_retrieval(pack,data)+audit.audit_authorial_core(pack,composed,composed['prompt_en'])+audit.audit_semantic_assertion_obligations_v6(pack,composed,composed['prompt_en'])+g.photo_embodiment.audit_composed(pack,composed),'baseline_prompt_unchanged':composed['prompt_en']==core['baseline_prompt_en'],'chosen_candidate_ids':composed['chosen_candidate_ids']})
        change=delta(records['baseline']['inventories'],records['proposal']['inventories'])
        b=records['baseline']['public_content_by_id'];a=records['proposal']['public_content_by_id']
        content_change={k:{'baseline':b[k],'proposal':a[k]} for k in sorted(set(b)&set(a)) if b[k]!=a[k]}
        target=f"slot:{proposal['slot']}:{proposal['entry_id']}"
        path=f"/slots/{proposal['slot']}/candidates"
        summary={'raw_ranked_changes':delta(records['baseline']['raw_ranked_inventories'],records['proposal']['raw_ranked_inventories']),'target_raw_ranks':{s:(r['raw_ranked_inventories'].get(proposal['slot'],[]).index(target)+1 if target in r['raw_ranked_inventories'].get(proposal['slot'],[]) else None) for s,r in records.items()},'target_positions':{s:(r['inventories'].get(path,[]).index(target)+1 if target in r['inventories'].get(path,[]) else None) for s,r in records.items()},'ordinary_count':{s:sum(len(p['candidates']) for p in packs[s]['slots'].values()) for s in records},'inventory_changes':change,'content_changes':content_change,'eligible_equal':records['baseline']['eligible_by_slot']==records['proposal']['eligible_by_slot'],'query_bindings_equal':all(records['baseline']['core_retrieval'][key]==records['proposal']['core_retrieval'][key] for key in ('source_authorial_core_sha256','whole_scene_query_sha256','slot_ownership_sha256','slot_applicability_sha256','active_slots'))}
        write(output/'cases'/f'{cid}.json',{'synthetic_fixture':True,'summary':summary,**records});results[cid]=summary
        print(cycle,cid,json.dumps({'target':summary['target_positions'],'changed_paths':list(change),'changed_content_ids':list(content_change)},ensure_ascii=False),flush=True)
    write(output/'comparison-summary.json',{'provenance':frozen['criteria']['provenance'],'state':meta,'cases':results})
    after={name:hash_file(REPO/name) for name in frozen['source_runtime_index_hashes']}
    assert after==frozen['source_runtime_index_hashes'],'source/runtime/index changed while measuring'
    write(output/'completion.json',{'utc':now(),'source_runtime_index_unchanged':True,'all_authored_hashes_unchanged':frozen['all_authored_file_hashes']=={str(p.relative_to(BASE/'current-core-inputs'/f'{cycle}-authored')):hash_file(p) for p in sorted((BASE/'current-core-inputs'/f'{cycle}-authored').rglob('*.json'))},'api_calls':0,'embedding_calls':0,'load_runtime_data_calls_this_process':1,'saved_index_written':False,'repo_git_status_after':subprocess.check_output(['git','status','--short'],cwd=REPO,text=True),'summary_sha256':hash_file(output/'comparison-summary.json')})

if __name__=='__main__':
    # Arguments are cycle:final-author-manifest-hash; all four input types validate before data load.
    ready={}
    for arg in sys.argv[1:]:
        cycle,manifest_hash=arg.split(':');authored,inputs=freeze_inputs(cycle,manifest_hash)
        ready[cycle]=(inputs,freeze_measurement(cycle,authored,inputs,manifest_hash))
    with patch.object(g,'embed_texts_with_gemini',side_effect=fail_network),patch.object(g,'embed_single_semantic_text',side_effect=fail_network),patch.object(socket.socket,'connect',side_effect=fail_network),patch.object(urllib.request,'urlopen',side_effect=fail_network):
        baseline=g.load_runtime_data()
        for cycle,(inputs,frozen) in ready.items():measure(cycle,inputs,frozen,baseline)
