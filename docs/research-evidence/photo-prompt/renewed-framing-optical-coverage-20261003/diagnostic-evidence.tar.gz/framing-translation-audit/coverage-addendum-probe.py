import sys,json,hashlib
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path('/workspace/scratch/ce8f20680f5a'); REPO=ROOT/'image-prompt'; OUT=ROOT/'daylong-progress-20261002/framing-translation-audit'
sys.path.insert(0,str(REPO/'skills/photo-prompt-image-generator/scripts'))
import prompt_generator as pg
import photo_candidate_semantics as cs
BASE=ROOT/'daylong-progress-20261002/blind-scene-query-audit/public-cli-property'
pack=json.loads((BASE/'baseline/blind_scene_006-pack.json').read_text())[0]
core=pack['authorial_core']; controls=pack['creative_controls']
data=pg.load_json(REPO/'skills/photo-prompt-image-generator/assets/photo_prompt_tags.json')
contract,picked=pg.frozen_core_context(data,core,controls)
slot='camera_direction'; query,fields=pg.core_slot_focus_text(data,core,slot)
rows=[]
for e in data['slots'][slot]:
 others={k:v for k,v in picked.items() if k!=slot}
 rows.append({'id':e['id'],'source':e,'semantic_source':cs.semantic_source(e,slot,data['candidate_semantic_policy']), 'eligible_before_ranking':pg.core_slot_entry_eligible(data,core,contract,picked,slot,e),'slot_block_reason':pg.slot_block_reason(data,slot,contract),'entry_block_reason':pg.entry_block_reason(e,slot,contract),'compatible_with_facet_guards':pg.compatible_with_facet_guards(e,others),'compatible_with_slot_context':pg.compatible_with_slot_context(slot,e,others,data),'scoped_domains':sorted({pg.INTENT_SCOPED_ENTRY_DOMAIN_TAGS[t] for t in (pg.entry_tags(e)|pg.entry_kinds(e)) if t in pg.INTENT_SCOPED_ENTRY_DOMAIN_TAGS})})
result={'frozen_core':core,'controls':controls,'contract':contract,'picked':picked,'focus_query':query,'focus_fields':fields,'rows':rows,'previous_returned_camera_direction':pack['slots'].get(slot),'input_sha256':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (BASE/'inputs/blind_scene_006').glob('*.json')}}
(OUT/'coverage-addendum-probe.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'subject_category':contract['subject_category'],'domains':contract['domains'],'eligible_count':sum(r['eligible_before_ranking'] for r in rows),'relevant_rows':[r for r in rows if r['id'] in ['low_ground_angle','worms_eye','extreme_low_angle_under_subject','extreme_low_hero_angle']]},ensure_ascii=False,indent=2))
