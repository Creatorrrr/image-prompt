def load_json(path: str | Path) -> JsonDict:
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"Tag JSON not found: {p}")
    with p.open("r", encoding="utf-8") as f:
        data = json.load(f)
    if p.name == "photo_prompt_tags.json":
        allowed_keys = {
            "candidate_semantic_policy", "version", "description", "facet_vocab", "slots",
            "negative_prompt", "negative_prompt_pools", "coherence_rules", "slot_applicability",
        }
        unknown = set(data) - allowed_keys
        if unknown:
            raise ValueError(f"unsupported photo corpus fields: {sorted(unknown)}")
        coherence = data.get("coherence_rules") or {}
        if not isinstance(coherence, dict) or set(coherence) - {"slot_conflicts", "slot_context_rules"}:
            raise ValueError("unsupported coherence rules")
        candidate_policy = data.get("candidate_semantic_policy") or {}
        photo_candidate_semantics.validate_semantic_policy(candidate_policy, AUTHORIAL_CORE_V3_INTENT_LOCK_DIMENSIONS)
        required_extensions = candidate_policy.get("required_extensions") or []
        missing_extensions = [name for name in required_extensions if not p.with_name(name).is_file()]
        if missing_extensions:
            raise ValueError(f"required candidate extensions are missing: {missing_extensions}")
        for extension_filename in RESEARCH_EXTENSION_FILENAMES:
            extension_path = p.with_name(extension_filename)
            if not extension_path.exists():
                continue
            with extension_path.open("r", encoding="utf-8") as f:
                extension = json.load(f)
            data = merge_research_extension(data, extension)
        validate_character_mechanism_graph(data)
        photo_candidate_semantics.validate_candidate_entries(data, AUTHORIAL_CORE_V3_INTENT_LOCK_DIMENSIONS)
        if data.get("candidate_bundles"):
            registry = load_visual_obligation_registry(default_visual_obligation_registry_path(p))
            photo_candidate_semantics.validate_bundle_references(data, registry.get("profiles") or [])
    return data


def semantic_description_for_entry(entry: Entry) -> str:
    if entry.get("embedding_text"):
        return " ".join(normalize_list(entry.get("embedding_text")))
    if entry.get("en"):
        return str(entry["en"])
    if entry.get("ko"):
        return str(entry["ko"])
    return "photo prompt concept"


def semantic_caption_for_entry(entry: Entry, slot: Optional[str] = None) -> str:
    description = semantic_description_for_entry(entry)
    if slot:
        template = SEMANTIC_SLOT_CAPTION_TEMPLATES.get(
            slot,
            "Photo prompt slot concept for {slot}: {description}. It should retrieve visually compatible photographic details for this slot.",
        )
        return template.format(slot=slot, description=description)
    raise ValueError("slot captions require an authored slot name")


def concept_units(entry: dict[str, Any]) -> list[str]:
    """Preserve authored phrases intact, never infer relations from word order."""
    authored = strings(entry.get("concept_units"))
    if authored:
        return list(dict.fromkeys(authored))
    label = str(entry.get("label_en") or entry.get("en") or "").strip()
    # A short noun/relational label is usable inspiration. Longer source prose
    # needs explicitly authored units instead of a truncation that changes it.
    if label and len(label.split()) <= 24:
        return [label]
    return list(dict.fromkeys(strings(entry.get("keywords")) or strings(entry.get("concept_terms"))))[:12]


def semantic_source(entry: dict[str, Any], slot: str = "", policy: dict[str, Any] | None = None) -> dict[str, Any]:
    units = concept_units(entry)
    if not units:
        return {}
    result: dict[str, Any] = {
        "concept_units": units,
        "relations": copy.deepcopy(entry.get("relations") or []),
        "affected_dimensions": strings(entry.get("affected_dimensions")) or slot_dimensions(slot, policy),
        "adoption": "optional",
    }
    if entry.get("canonical_concept_id"):
        result["canonical_concept_id"] = str(entry["canonical_concept_id"])
    if "affected_properties" in entry:
        result["affected_properties"] = copy.deepcopy(entry["affected_properties"])
    return result


def apply_public_semantics(pack: dict[str, Any], sources: dict[str, dict[str, Any]]) -> None:
    def visit(value: Any) -> None:
        if isinstance(value, list):
            for item in value:
                visit(item)
        elif isinstance(value, dict):
            candidate_id = str(value.get("id") or value.get("candidate_id") or "")
            source = sources.get(candidate_id)
            if source and value.get("content_form") == "unordered_inspiration_terms":
                value.update(copy.deepcopy(source))
                value["semantic_surface_version"] = SURFACE_VERSION
                value["concept_terms"] = list(source["concept_units"])
            for item in value.values():
                visit(item)
    visit(pack)
    pack["candidate_semantic_surface_version"] = SURFACE_VERSION
