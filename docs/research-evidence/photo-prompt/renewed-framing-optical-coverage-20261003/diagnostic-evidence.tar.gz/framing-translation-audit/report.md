# Framing translation and axis consistency audit

Date: 2026-10-03 UTC. Read-only audit of authored DATA and production semantic emission. **Decision: KEEP; zero correction proposals.**

## Scope and result

Reviewed all 141 authored and loaded rows in the requested five slots: shot_scale 9, subject_framing 53, body_framing 19, camera_height 11, camera_direction 49. Compared Korean labels, English labels, authored concept units, embedding descriptions, and the actual semantic-source/public-semantic functions. No clear direction reversal, incompatible crop endpoint, swapped face-direction/body-coverage meaning, or intrinsically contradictory translation met the threshold for correction.

The probe used the real production loader and semantic functions. Each public concept_terms array matched its semantic_source concept_units; none were empty. This is a direct semantic-surface probe, **not** a full CLI retrieval/exposure or image test. It makes no claim about cap/routing/property-guard behavior, vector freshness, retrieval ranking, or generated pixels. No paid calls, images, repository edits, or routing changes were made.

## Close reviews and reasons to keep

1. **Three-quarter coverage versus orientation:** `three_quarter_body_framing`, `regal_three_quarter_framing`, `restrained_three_quarter_face_depth_read`, `eye_level_three_quarter`, `pc_pc07_component_1`, and `pc_px01_component_1` are not interchangeable. The explicitly authored PC07 crop is head to a chosen region above the knees; PX01 explicitly separates crop endpoint from facial direction. The original `concept-catalog.json` and `report.md` already warn against resolving bare “three-quarter” into both axes. The more generic style labels are underspecified, not proven mistranslations. Do not impose one shot glossary.

2. **Body diagonal versus camera roll:** `pc_pc10_component_3` emits “stable environmental reference lines retain the intended level camera roll”; `pc_pc30_component_1` emits camera roll rotating scene references relative to image axes; `pc_px08_component_2` evaluates roll through independent stable lines. This preserves the original PC10/PC30/PX08 authored distinction. PC10's parent label/embedding includes diagonal reclining, but its component's semantic unit keeps the background-level requirement. No axis swap.

3. **Parent Korean labels versus narrow component English:** `pc_pc01_component_1` has an eye-level close-portrait family label but emits the face-and-shoulders crop; `pc_pc01_component_2` separately emits viewpoint near the eye line. PC07 likewise separates knee-up coverage from the below-face viewpoint. This is original authored decomposition, not a missing translation that warrants copying the whole parent concept into every component.

4. **Over-the-shoulder variants:** `over_shoulder_back_seated` English adds “turning back” to a Korean rear/shoulder description; `over_shoulder_hip_line` specifies a three-quarter-back body-contour relationship; companion/observer entries refer to camera/foreground relations. A returned face and a rear camera position can coexist. The explicit English addition is a specificity asymmetry, but the available data do not establish an incompatible owner or a proven mistranslation. Do not normalize these into one generic OTS row.

5. **Scale and cropping:** explicit full-length, knee-up, waist-up, chest-up, face close-up, and detail close-up entries agree across languages. Chest-up embedding text mentions hands, but hands can be raised within that crop; this is not an impossible crop. `hands_and_regalia_visible` adds “near face” in its embedding, a narrower compatible staging, not a reversal. Neither merits a forced data correction.

6. **Camera-height labels in English:** the seven base camera_height rows have English text in their `ko` fields. This is a localization completeness issue, not a contradictory direction or emitted semantic concept. The bilingual research-extension rows retain consistent eye-line/below-face/above-seated-face distinctions. No repair proposed under this audit's strong-correction threshold.

7. **Mixed-axis older style entries:** close broadcast, mirror, POV, long-lens, profile, and view-through-gap entries coexist in camera_direction. Reclassifying that broad slot would be schema/routing work, outside scope, and their Korean/English source meanings are compatible. No metadata changes proposed.

## Provenance and reproducibility

- `authored-row-snapshots.json`: complete selected-slot rows from the base asset and every production-loaded extension contributing to these slots
- `emitted-semantics.json`: every loaded row, actual semantic source, embedding description/caption, and public semantic surface
- `provenance-concept-catalog.json`: original portrait-composition authored owners, axes, and confusion boundaries
- `provenance-candidate-extension.proposed.json`: original proposed rows for the five slots
- `provenance-candidate-source-map.json` and `provenance-sources.json`: original attribution and reference ledger
- `semantic-functions.snapshot.py`: exact production functions used by this audit
- `manifest.json`: source SHA-256 values; `summary.json`: machine-readable counts and conclusion
- `probe.py`: reproducible read-only probe, bytecode writing disabled

No new external photographic factual claim was necessary to make the keep decisions: they rest on internal bilingual consistency and explicit authored owner separation. The original provenance's authoritative source ledger is preserved for reference; it was not represented as a newly reverified external source.
