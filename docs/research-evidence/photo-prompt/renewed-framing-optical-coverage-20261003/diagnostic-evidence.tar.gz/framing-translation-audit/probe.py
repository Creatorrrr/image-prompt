import sys, json, hashlib, inspect, collections, os
from pathlib import Path
sys.dont_write_bytecode = True
ROOT=Path('/workspace/scratch/ce8f20680f5a')
REPO=ROOT/'image-prompt'
SKILL=REPO/'skills/photo-prompt-image-generator'
OUT=ROOT/'daylong-progress-20261002/framing-translation-audit'
SLOTS=['shot_scale','subject_framing','body_framing','camera_height','camera_direction']
sys.path.insert(0,str(SKILL/'scripts'))
import prompt_generator as pg
import photo_candidate_semantics as cs
manifest=[]
def read(p):
 b=p.read_bytes(); manifest.append({'path':str(p.relative_to(REPO)),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)})
 return json.loads(b)
def save(name,data): (OUT/name).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
raw=[]
for p in [SKILL/'assets/photo_prompt_tags.json',*[SKILL/'assets'/n for n in pg.RESEARCH_EXTENSION_FILENAMES]]:
 if not p.exists(): continue
 d=json.loads(p.read_text()); selected={s:d.get('slots',{}).get(s,[]) for s in SLOTS if d.get('slots',{}).get(s)}
 if selected:
  read(p)
  raw.append({'path':str(p.relative_to(REPO)), 'slots':selected})
save('authored-row-snapshots.json',raw)
d=pg.load_json(SKILL/'assets/photo_prompt_tags.json')
rows=[]
for slot in SLOTS:
 for r in d['slots'][slot]:
  source=cs.semantic_source(r,slot,d['candidate_semantic_policy'])
  cid=f"slot:{slot}:{r['id']}"
  pack={'slots':{slot:{'candidates':[{'id':cid,'content_form':'unordered_inspiration_terms'}]}}}
  cs.apply_public_semantics(pack,{cid:source})
  pub=pack['slots'][slot]['candidates'][0]
  assert pub['concept_terms']==source['concept_units']
  rows.append({'slot':slot,'id':r['id'],'authored_row':r,'semantic_source':source,'embedding_description':pg.semantic_description_for_entry(r),'embedding_caption':pg.semantic_caption_for_entry(r,slot),'public_semantics':pub})
save('emitted-semantics.json',rows)
prov=REPO/'docs/research-evidence/photo-prompt/portrait-composition-20260927'
for name in ['concept-catalog.json','candidate-extension.proposed.json','candidate-source-map.json','sources.json']:
 obj=read(prov/name)
 if name=='candidate-extension.proposed.json':obj={s:obj.get('slots',{}).get(s,[]) for s in SLOTS}
 save('provenance-'+name,obj)
code='\n\n'.join(inspect.getsource(f) for f in [pg.load_json,pg.semantic_description_for_entry,pg.semantic_caption_for_entry,cs.concept_units,cs.semantic_source,cs.apply_public_semantics])
(OUT/'semantic-functions.snapshot.py').write_text(code)
for p in [SKILL/'scripts/prompt_generator.py',SKILL/'scripts/photo_candidate_semantics.py']:
 b=p.read_bytes();manifest.append({'path':str(p.relative_to(REPO)),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)})
summary={'scope':SLOTS,'raw_rows':sum(len(rs) for f in raw for rs in f['slots'].values()),'loaded_rows':len(rows),'counts':dict(collections.Counter(r['slot'] for r in rows)),'empty_semantic_sources':[r['id'] for r in rows if not r['semantic_source']],'public_semantics_equality':'all public concept_terms equal actual semantic_source concept_units','method':'production loader, semantic_source, semantic_description_for_entry, semantic_caption_for_entry, and apply_public_semantics, not candidate retrieval or image generation','recommended_corrections':[],'decision':'KEEP'}
save('manifest.json',manifest);save('summary.json',summary); print(json.dumps(summary,indent=2))
