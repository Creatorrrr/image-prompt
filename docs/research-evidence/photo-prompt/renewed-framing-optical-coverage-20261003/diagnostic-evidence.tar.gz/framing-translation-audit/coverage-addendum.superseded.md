# Case006 bounded upward-direction coverage check

2026-10-03 UTC. **Existing DATA coverage confirmed; do not add a case-specific candidate.**

The exact `public-cli-property/inputs/blind_scene_006` request requires a camera below the shelf looking upward toward a toy locomotive, with the ceiling visible and rear carriages smaller. Low physical camera height alone is insufficient, so this review looked specifically for upward-facing source meaning.

## Source pool before ranking

The current merged `camera_direction` corpus contains:

- `worms_eye`: Korean `아래에서 올려다보는 웜즈아이뷰`; English and emitted concept unit `worm’s-eye view from below`. This explicitly expresses looking upward/from below, has no human-only applicability constraint, and is generic-object-capable. Its architecture/dramatic tags do not impose a domain restriction in the current eligibility path.
- `extreme_low_angle_under_subject`: Korean explicitly looks upward from below the subject; English/emitted unit `extreme low-angle view from below the subject`. It passes eligibility despite a `human` descriptive tag; it has no `for_any` human-only restriction.
- `extreme_low_hero_angle`: English/emitted unit `extreme low hero angle`; embedding says `from below the subject`. This is also eligible but adds extreme/hero treatment, so it is not necessarily the preferred restrained choice.
- `low_ground_angle`: eligible, but only says `low ground-level angle`; this row alone would not prove coverage of the requested upward optical direction. It is not the basis for the conclusion.

Production `frozen_core_context` and `core_slot_entry_eligible` were run against the bound core/controls preserved in the case006 baseline public pack. That bound core includes the exact input request and property anchors. Context resolves `subject_category=generic`, `domains=[]`. All four rows above pass pre-ranking eligibility, with null slot and entry block reasons and passing facet/context checks. Current pre-ranking eligible pool: 35 of 49 camera_direction rows.

## Boundary of diagnosis

The historical baseline pack exposes only `strict_top_down_flat_view`, `birds_eye`, `dutch_tilt_dynamic_view`, and `mirror_reflection_camera_view`; it reports candidate_count 28, candidate_limit 4. The current eligibility probe's count is 35, so these are not asserted to be identical runtime snapshots. This addendum establishes **current source coverage and current pre-ranking eligibility using the frozen case core**, not a historical bit-for-bit rank replay. The complete frozen core, controls, current pool and reasons, historical returned rows, and input file hashes are saved in `coverage-addendum-probe.json`.

The upward-facing concept is neither missing nor presently barred by source applicability. Its absence from the shown result belongs to retrieval/exposure/ranking or a historical runtime difference, not a demonstrated DATA gap. This bounded audit does not identify which later runtime stage caused the omission. No routing/configuration change or added candidate is justified by this test.

The current camera_direction focus query contains the Korean visual-priority/style fields (`선반보다 낮은 카메라`, relative locomotive size, ceiling visibility, general_photo, independently authored scene study). That fact is recorded only as diagnostic evidence, not a proposal to rewrite data or route fields.

Artifacts: `coverage-addendum-probe.py`, `coverage-addendum-probe.json`, and this addendum. No repository edits, generated images, external API charges, or index writes.
