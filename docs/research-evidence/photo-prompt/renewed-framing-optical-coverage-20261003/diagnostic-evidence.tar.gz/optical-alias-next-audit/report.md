# Optical/capture alias-scope audit

Decision: **KEEP**. No strong DATA-only alias/context correction established. No repository source, routing metadata, index, or runtime edits were made. No paid calls or images were generated.

## Tilt/shift lead

The broad equipment candidate `lens:tilt_shift` says “a tilt-shift lens” and carries architecture/product tags, without miniature-focus requirements. The separately authored optional editing candidate `pe_miniature_focus_band` is explicitly “miniature-like narrow focus band across a distant scene”; its English and Korean aliases describe the narrow focus band, not the broad lens class. Its two concept units are a sharp narrow band and progressive defocus above/below. The `tilt_shift_overhead_city` composition candidate likewise explicitly names miniature overhead-city composition. These are deliberate narrow variants, not evidence that all tilt/shift requests must be miniature scenes.

Original provenance independently supports this distinction: `docs/research-evidence/photo-prompt/photo-editing-effects-20261001/keyword-matrix.md:297` calls edit_39 “Tilt-shift miniature effect” and explicitly separates actual lens tilt/shift, architectural perspective correction, and physical miniatures. `sources.md:18` makes the same distinction when citing Adobe's blur-gallery controls.

The factual distinction is corroborated by manufacturer documentation: Canon describes tilt-shift lenses as altering perspective and depth of field, with perspective correction for converging building lines and miniature illusion as another use. [Canon Australia, Tilt Shift Lens Definition](https://www.canon.com.au/get-inspired/glossary/tilt-shift-lens), accessed 2026-10-03. Thus a level camera with raised lens shift and consistently sharp building details is an independently valid contrast; its equivalent paraphrase does not rely on subtracting or negating miniature keywords.

## Actual consumer probe

`probe.py` loads the real combined 1,496-profile registry via `load_visual_obligation_registry`, builds the normal in-memory exact lookup, then invokes `resolve_visual_profile_hits` with both user requirement and authorial-core context. It records complete output in `probe.json`.

- Architectural lens-shift prompt: zero hard/exact hits
- Independently phrased same architectural intent: zero hard/exact hits
- Explicit miniature-band effect: zero hard/exact profile hits, consistent with its optional atomic candidate rather than a hard profile
- Broad waterfall long exposure: zero hard/exact hits
- Rear-curtain flash on a stationary studio vase: zero hard/exact hits
- Broad double exposure of one dancer at two positions: zero hard/exact hits
- Exact narrow rear-curtain motion-trace relation, PC29 stationary portrait/moving surroundings relation, and two-scene exposure-overlap relation: each activates only its intended profile as hard eligible

The calls exercise real exact/context resolution. They do not supply vectors or structured BM25F fields and therefore do not claim to test optional semantic ranking, candidate adoption, full prompt construction, or pixel outcomes. No miniature hard profile exists to materialize.

## Adjacent exposure scope

Full authored records and actual `candidate_pack_visual_profile_obligation` output are preserved in `probe.json` for three neighboring profiles. Their materialized requirements and gates retain their authored scope:

- `rear_curtain_flash_motion_trace`: five evidence fields/gates demand continuous ambient trace, single frozen endpoint, visible ambient context, arrival direction, and a coherent exposure. Exact aliases say motion trace/endpoint trail rather than generic rear-curtain flash. Original capture research `capture-elements-visual-semantics-20260902/source-research.md` explicitly authors the end-of-trail relation and deliberately narrow exact terms.
- `pc_pc29_owner_relation`: four components preserve supported stationary subject, resolved face, separate moving peripheral trail, and coherent planes. Original `portrait-composition-20260927/report.md:600-613` explicitly selects stationary-person/moving-surroundings contrast and distinguishes panning. Generic long exposure must not broaden this named construction.
- `pe_double_exposure_overlap_relation`: two components preserve two recognizable overlapping scene layers. The hard aliases explicitly say “recognizable two-scene exposure overlap relation,” not double exposure generally. Original edit_68 (`photo-editing-effects-20261001/keyword-matrix.md:326`) distinguishes scene overlap from simply adding people or motion ghosts. The observed narrowing is deliberate and does not establish an alias defect.

Already-corrected rolling-shutter and split-diopter data were excluded. This KEEP result is confined to the investigated alias/context scopes; it is not a claim that all optics data or all retrieval behavior is correct.
