import sys,json,pathlib
ROOT=pathlib.Path('REPOSITORY_ROOT')
sys.path.insert(0,str(ROOT/'skills/photo-prompt-image-generator/scripts'))
import prompt_generator as pg
A=ROOT/'skills/photo-prompt-image-generator/assets'
OUT=ROOT.parent/'daylong-progress-20261002/optical-alias-next-audit'
r=pg.load_visual_obligation_registry(A/'photo_prompt_visual_obligations.json')
i=pg.build_visual_profile_index_payload(r)
ids=['rear_curtain_flash_motion_trace','pc_pc29_owner_relation','pe_double_exposure_overlap_relation']
profiles={p['id']:p for p in r['profiles'] if p['id'] in ids}
cases={
 'shift_perspective':'Photograph a tall building with a tilt-shift lens, camera level and shift raised so the facade verticals remain parallel. Keep facade details consistently sharp.',
 'shift_perspective_paraphrase':'Use lens shift while keeping the camera level to frame the top of a tall building and preserve upright parallel facade edges with clear architectural detail.',
 'miniature_effect':'Show a city square as a tilt-shift miniature effect: a narrow sharp band across the distant scene, progressively blurred regions above and below it.',
 'slow_shutter_broad':'Use a long exposure of a waterfall, with streaming water blurred against sharp stationary rocks.',
 'rear_curtain_broad':'Use rear-curtain flash for a stationary vase in a dark studio.',
 'double_exposure_broad':'Use double exposure to repeat the same dancer at two positions in one room.',
}
for pid,p in profiles.items():cases['exact_'+pid]=p['activation']['exact_terms'][0]
result={}
for key,q in cases.items():
 rows=[{'source':'user_requirement','text':q},{'source':'authorial_core_scene','text':q}]
 res=pg.resolve_visual_profile_hits(r,rows,visual_profile_index=i,query_text=q,adult_context=True)
 result[key]={'query':q,'resolution':res}
materialized={pid:pg.candidate_pack_visual_profile_obligation(p,r,activation_source='exact_term',source_intent_ids=['audit'],context_text=cases['exact_'+pid],request_text=cases['exact_'+pid]) for pid,p in profiles.items()}
# Keep original full records, rather than judging an isolated evidence sentence.
def walk(v):
 if isinstance(v,dict):
  if v.get('id') in {'pe_miniature_focus_band','tilt_shift','tilt_shift_overhead_city'}:yield v
  for x in v.values():yield from walk(x)
 elif isinstance(v,list):
  for x in v:yield from walk(x)
records=[]
for f in ['photo_prompt_tags.json','photo_prompt_editing_effects_extension.json']:records += [{'file':f,'record':x} for x in walk(json.load(open(A/f)))]
(OUT/'probe.json').write_text(json.dumps({'profile_count':len(r['profiles']),'cases':result,'full_profiles':profiles,'materialized':materialized,'full_candidates':records},ensure_ascii=False,indent=2)+'\n')
for k,v in result.items():print(k,[(h['profile_id'],h['hard_eligible']) for h in v['resolution']['hits']])
