import sys,os,json,hashlib,subprocess,time
from pathlib import Path
OUT=Path(__file__).resolve().parent; ROOT=Path('REPOSITORY_ROOT'); phase=sys.argv[1]
d=OUT/phase; d.mkdir(exist_ok=True)
manifest=json.loads((OUT/'frozen-input-manifest.json').read_text())
assets=ROOT/'skills/photo-prompt-image-generator/assets'; files=[assets/'photo_prompt_visual_obligations.json',assets/'photo_prompt_visual_profile_index.json',ROOT/'skills/photo-prompt-image-generator/scripts/generate_photo_prompt.py',ROOT/'skills/photo-prompt-image-generator/scripts/prompt_generator.py']
meta={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'status':subprocess.check_output(['git','status','--short'],cwd=ROOT,text=True),'hashes':{str(f.relative_to(ROOT)):hashlib.sha256(f.read_bytes()).hexdigest() for f in files},'cases':[]}
# Current source hashes are frozen in this phase's manifest.
for c in manifest:
 case=c['case']; inputs=OUT/'inputs'/case
 for name,h in c['inputs'].items():assert hashlib.sha256((inputs/name).read_bytes()).hexdigest()==h
 command=[sys.executable,str(ROOT/'skills/photo-prompt-image-generator/scripts/generate_photo_prompt.py'),'--seed',str(c['seed'])]
 for arg in ['request-envelope','authorial-core','creative-controls','embodiment-review']:command+=['--'+arg+'-json',str(inputs/(arg+'.json'))]
 command+=['--output-file',str(d/(case+'-pack.json'))]
 start=time.time(); proc=subprocess.run(command,cwd=ROOT,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},capture_output=True,text=True,timeout=240)
 (d/(case+'.stdout')).write_text(proc.stdout); (d/(case+'.stderr')).write_text(proc.stderr)
 row={'case':case,'command':command,'exit_code':proc.returncode,'duration_seconds':time.time()-start}
 meta['cases'].append(row); print(case,'exit',proc.returncode,flush=True)
 if proc.returncode:print(proc.stderr,flush=True)
 else:
  pack=json.loads((d/(case+'-pack.json')).read_text())[0]
  obligation=next(x for x in pack['visual_obligations']['obligations'] if x['id']=='leading_line_target_continuity')
  row['summary']={'core_request':pack['authorial_core']['source_request'],'core_baseline':pack['authorial_core']['baseline_prompt_en'],'composition_instruction':obligation['composition_instruction'],'vector_evidence':obligation['evidence_requirements']['line_continuity_phrase'],'render_gates':obligation['render_gates'],'pack_id':pack.get('pack_id')}
 (d/'run-manifest.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n')
assert all(x['exit_code']==0 for x in meta['cases'])
