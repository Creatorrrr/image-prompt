import json,pathlib
D=pathlib.Path(__file__).parent
def diff(a,b,p=''):
 if type(a)!=type(b):return [(p,a,b)]
 if isinstance(a,dict):return [(p+'/'+k,a.get(k),b.get(k))for k in sorted(a.keys()^b.keys())]+[v for k in sorted(a.keys()&b.keys()) for v in diff(a[k],b[k],p+'/'+k)]
 if isinstance(a,list):
  if len(a)!=len(b):return [(p,a,b)]
  return [v for i,(x,y) in enumerate(zip(a,b)) for v in diff(x,y,p+'/'+str(i))]
 return [] if a==b else [(p,a,b)]
expected={'/0/pack_id','/0/visual_obligations/obligations/0/render_gates/0/description','/0/visual_obligations/obligations/0/render_gates/1/description'}
results=[]
for case in ['continuous','rhythmic']:
 a=json.loads((D/'before'/(case+'-pack.json')).read_text());b=json.loads((D/'after'/(case+'-pack.json')).read_text());ds=diff(a,b)
 assert {p for p,_,_ in ds}==expected,(case,ds)
 assert a[0]['slots']==b[0]['slots']
 assert a[0]['visual_concept_candidates']==b[0]['visual_concept_candidates']
 gates=b[0]['visual_obligations']['obligations'][0]['render_gates'];assert gates[0]['description']=='A physical line or aligned scene edge begins away from the primary subject.';assert gates[1]['description']=='The line remains visibly continuous or rhythmically linked across the intervening frame.'
 rows=[{'path':p,'before':x,'after':y}for p,x,y in ds];(D/('diff-'+case+'.json')).write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
 results.append({'case':case,'complete_pack_differing_leaves':len(ds),'intended_gate_description_changes':2,'derived_pack_id_changes':1,'unexpected_changes':0,'identical_slot_count':len(a[0]['slots']),'identical_slot_candidate_records':sum(len(v.get('candidates',[]))for v in a[0]['slots'].values()),'visual_concept_candidates_identical':True,'visual_concept_candidate_count':len(a[0]['visual_concept_candidates'].get('candidates',[])) if isinstance(a[0]['visual_concept_candidates'],dict) else len(a[0]['visual_concept_candidates'])})
out={'cases':results,'paid_calls':0,'scope':'Complete normal public CLI before/after packs compared recursively, with frozen inputs. No prompt composition, rendered-image generation, reviewer rejection, or aesthetic improvement claim.'};(D/'comparison-summary.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
