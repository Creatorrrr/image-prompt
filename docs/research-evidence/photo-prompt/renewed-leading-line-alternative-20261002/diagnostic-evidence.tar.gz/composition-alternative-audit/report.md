# Composition alternative-consistency audit

Base: `326a9321c93d7fe5b484fb62fff6d3d393ed46c7`. Read-only repository audit; zero paid calls, no fake vectors, no repository edits. One narrowly scoped DATA wording correction recommended; no second correction justified.

## Recommended: preserve the authored rhythmically linked leading-line alternative

Profile: `leading_line_target_continuity` in `skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations.json`.

Existing source allows:
- Definition: “One continuous physical line **or aligned scene edge**…”
- Paraphrase: “a path of **repeated aligned edges** delivers the eye to one subject…”
- Required `line_continuity` group and `line_continuity_phrase` evidence: “the line remains visibly continuous **or rhythmically linked** across the intervening frame”
- Required origin group/evidence: “one physical line **or aligned edge** begins away from the primary subject”

But the two mandatory render descriptions omit those alternatives:
- `vo_composition_line_origin_away`: “A physical line begins away from the primary subject.”
- `vo_composition_line_path_continuous`: “The line remains visibly continuous across the intervening frame.”

This is a source-internal contract wording mismatch, not a proposal to add generic leading-line types. The second branch is already expressly authored, so it should also be express in the judging contract. The current gate can be read to reject a physically separated sequence of aligned edges despite the component evidence permitting a rhythmically linked path. We did not generate an image or establish an actual reviewer rejection; the observed defect is wording divergence propagated to the public obligation.

### Minimal proposed correction

Change only these two render descriptions:
1. “A physical line or aligned scene edge begins away from the primary subject.”
2. “The line remains visibly continuous or rhythmically linked across the intervening frame.”

Keep profile ID, activation, gate IDs/scales/count, component groups, evidence thresholds, target termination, competing-endpoint rejection, and physical scene ownership unchanged. No continuous-versus-discontinuous universal photography rule is proposed. The path must remain one readable scene-owned route terminating at the nominated target. Existing composition instruction “continuously readable” can naturally describe perceptual continuity and need not change. Existing definition and candidate row can remain unchanged for this minimal gate-alignment patch; avoid paying to refresh unaffected candidate vectors.

### Provenance and actual consumer proof

- Existing research provenance: `docs/research-evidence/photo-prompt/composition_visual_semantics_20260902.md`, “Sources and bounded derivations” and implemented profile map; it intentionally names continuous target-bound paths. The same source draws on Gestalt continuity/grouping and Nikon composition guidance. The runtime profile's explicit repeated-edge paraphrase and bilingual component groups establish the permitted alternative more precisely than the summary map.
- `probe.py` loads the current registry using its normal loader and materializes the actual public obligation using `candidate_pack_visual_profile_obligation`.
- `consumer-proof.json` retains the resulting component semantics, evidence requirements, and narrower render gates together, plus source SHA-256 values.
- The exact user-facing profile term routes through `candidate_pack_auto_visual_obligation_matches` (`exact_route_contains_profile=true`).
- The ordinary composition candidate is projected with current public semantics; detail is built and verified (`detail_verified=true`). This confirms consumer propagation, not retrieval rank or final adoption.
- Reproduce: `python EVIDENCE_ROOT/composition-alternative-audit/probe.py`.

## Keep / defer decisions

- Frame-within-frame three-sided enclosure: KEEP. The definition says multiple sides, but original implemented profile map expressly requires a three-sided enclosure. This is deliberately narrow foreground-enclosure style, not a proven accidental closed-border requirement. No fourth side or fully closed border is required.
- Leading-line convergence: no issue found. No mandatory convergence or multiple-line requirement exists in the checked profile; retain endpoint and origin continuity.
- Across-the-table portrait PC03 mandatory table objects: KEEP. Source report PC03 explicitly authors table-object support as c4 and develops a cup-side hand/face example. A broad label alone is insufficient reason to remove it.
- Activity-based environmental portrait PC15 hand action: KEEP. Source report explicitly authors joint face/hand-task framing and a workbench example; do not reinterpret its broad search alias as the complete profile definition.
- Offering gesture PC16 object: KEEP. Source deliberately defines an offered object in c2/c4; c3's “hand or object” nearer-plane alternative does not remove the separately authored offered-object contract.
- Mirror-led portrait PC22 direct body: KEEP. Source c3 explicitly requires partial direct body correspondence and the example has direct back-shoulder plus reflected face.
- Hogarth waving line: DEFER. Definition lists alternative visual carriers, while the gate requires at least two visual systems; this is plausibly a deliberate cross-element authored composition, and stronger provenance is needed before relaxing it.
- Centering, axial symmetry, look/motion room, three-plane depth, primary/secondary hierarchy, peak-action: no high-confidence alternative-collapse correction established. Required secondary elements/planes/cause are part of those deliberately authored relation types.
- Prior third-grid/counterbalance/negative-space/pattern-break boundary repairs: excluded from new correction scope.
- Overhead hand-or-prop: excluded because another active repair owns it.

## Suggested verification for implementer

A focused data regression should load the normal registry and public obligation, verify that both render descriptions retain the same alternatives already present in required component/evidence fields, and assert unchanged gate IDs, number, scales, target gate, and false-substitute gate. Existing exact-route and false-substitute tests should continue to pass. Do not fabricate pixel results or rewrite all profiles to generic photography advice.
