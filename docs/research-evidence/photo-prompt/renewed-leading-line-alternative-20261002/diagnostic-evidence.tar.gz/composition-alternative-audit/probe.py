import hashlib,json,pathlib,subprocess,sys
repo=pathlib.Path('REPOSITORY_ROOT')
sys.path[:0]=[str(repo),str(repo/'skills/photo-prompt-image-generator/scripts')]
import prompt_generator as pg
from tests import photo_prompt_fixtures as fixtures
assets=repo/'skills/photo-prompt-image-generator/assets'
registry=pg.load_visual_obligation_registry(assets/'photo_prompt_visual_obligations.json')
p=next(p for p in registry['profiles'] if p['id']=='leading_line_target_continuity')
obligation=pg.candidate_pack_visual_profile_obligation(p,registry,activation_source='explicit_visual_intent',source_intent_ids=[])
data=pg.load_json(assets/'photo_prompt_tags.json')
row=next(r for r in data['slots']['composition'] if r['id']==p['id'])
candidate,detail=fixtures.project_slot_candidate(data,'composition',row)
text='A photograph using '+p['activation']['exact_terms'][0]
routing=pg.candidate_pack_auto_visual_obligation_matches(registry,[{'source':'concept_lock','text':text,'polarity':'required'}])
paths=['skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations.json','skills/photo-prompt-image-generator/assets/photo_prompt_tags.json','docs/research-evidence/photo-prompt/composition_visual_semantics_20260902.md','docs/research-evidence/photo-prompt/portrait-composition-20260927/report.md']
out={'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'scope':'Actual public slot projection/detail verification and explicit-profile obligation materialization. Not ranking, final adoption, image rendering or image failure proof.','source_hashes':{f:hashlib.sha256((repo/f).read_bytes()).hexdigest() for f in paths},'source_profile':p,'public_obligation':obligation,'public_candidate':candidate,'detail_verified':detail['candidates'][0]['candidate']==candidate,'exact_request':text,'exact_route_contains_profile':p['id'] in routing,'paid_calls':0,'synthetic_vectors':False}
pathlib.Path(__file__).with_name('consumer-proof.json').write_text(json.dumps(out,indent=2,ensure_ascii=False))
print(json.dumps({'base_commit':out['base_commit'],'detail_verified':out['detail_verified'],'exact_route_contains_profile':out['exact_route_contains_profile'],'obligation_keys':list(obligation)}))
