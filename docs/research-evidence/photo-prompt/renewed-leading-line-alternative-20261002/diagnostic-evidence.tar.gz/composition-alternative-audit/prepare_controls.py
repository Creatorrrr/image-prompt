import copy,hashlib,json,pathlib,sys,subprocess
R=pathlib.Path('REPOSITORY_ROOT'); O=pathlib.Path(__file__).parent
sys.path[:0]=[str(R),str(R/'skills/photo-prompt-image-generator/scripts')]
import prompt_generator as pg
from tests import photo_prompt_fixtures as f
import build_visual_profile_index as build
A=R/'skills/photo-prompt-image-generator/assets'
def save(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
reg=pg.load_visual_obligation_registry(A/'photo_prompt_visual_obligations.json'); before=next(p for p in reg['profiles'] if p['id']=='leading_line_target_continuity'); after=copy.deepcopy(before)
after['render_gates'][0]['description']='A physical line or aligned scene edge begins away from the primary subject.'
after['render_gates'][1]['description']='The line remains visibly continuous or rhythmically linked across the intervening frame.'
save(O/'proposal-before-profile.json',before);save(O/'proposal-after-profile.json',after)
save(O/'exact-two-leaf-proposal.json',{'profile_id':before['id'],'source':'skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations.json','changes':[{'path':['render_gates',i,'description'],'gate_id':before['render_gates'][i]['id'],'before':before['render_gates'][i]['description'],'after':after['render_gates'][i]['description']}for i in [0,1]]})
idx=pg.load_json(A/'photo_prompt_visual_profile_index.json'); proposed=copy.deepcopy(reg);proposed['profiles']=[after if p['id']==after['id'] else p for p in proposed['profiles']]
reused=build.reusable_vectors([A/'photo_prompt_visual_profile_index.json'],proposed,provider=idx['provider'],model=idx['embedding_model'],dimensions=idx['embedding_dimensions'])
texts={p['id']:pg.visual_profile_semantic_text(p)for p in reg['profiles']}; altered=[p['id'] for p in proposed['profiles'] if texts[p['id']]!=pg.visual_profile_semantic_text(p)]
save(O/'vector-reuse-proof.json',{'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'index_sha256':sha(A/'photo_prompt_visual_profile_index.json'),'profile_count':len(reg['profiles']),'index_entry_count':len(idx['entries']),'changed_semantic_text_ids':altered,'reusable_vector_count':len(reused),'missing_vector_ids':sorted(set(texts)-set(reused)),'all_existing_vectors_legitimately_reusable':not altered and set(texts)<=set(reused),'semantic_text_before':texts[before['id']],'semantic_text_after':pg.visual_profile_semantic_text(after),'paid_calls':0})
manifest=[]
for name,pathdesc in [('continuous','One continuous brass rail runs from the lower left frame edge across the workbench and ends directly beside the spout of the blue porcelain teapot.'),('rhythmic','A rhythmically linked path of repeated aligned brass edge segments begins at the lower left frame edge, crosses the workbench with regular small gaps, and ends directly beside the spout of the blue porcelain teapot.')]:
 request='Create a still-life photograph using a leading-line target-continuity relation. '+pathdesc+' Keep the teapot spout as the same nominated endpoint and avoid stronger competing endpoints.'
 baseline=pathdesc+' The blue porcelain teapot rests on a dark wooden workbench with its spout forming the primary target anchor. The scene-owned brass route remains clearly readable from its distant origin to that endpoint. Surrounding objects remain darker than the spout and support its focal priority. Soft window daylight reveals the brass surface, blue ceramic glaze, and quiet wood grain while preserving one coherent tabletop perspective. The teapot lid and handle remain subordinate to the spout. A restrained dark wall behind the bench supports the still-life hierarchy without a distracting second focal point. The full origin, intervening route, and target fit inside the horizontal frame. Subtle reflections belong to their respective surfaces, and the supporting shadows consistently follow the window light. All objects rest visibly on the same stable bench surface. The image emphasizes spatial direction and tactile photographic detail.'
 controls=pg.creative_controls.resolve(request,overrides={'sensual':0,'fetish':0,'creativity':1,'surreal':0},seed=709)
 core=f.core(request,interpreted_intent=request,subject='The blue porcelain teapot',setting='a dark wooden workbench',event='brass route leads toward the teapot spout',visual_priorities=('primary target anchor','scene-owned brass route','quiet wood grain'),baseline_prompt_en=baseline,anchor_evidence=('The blue porcelain teapot','primary target anchor','scene-owned brass route'))
 core['creative_controls_sha256']=controls['canonical_sha256'];core['variation_key']='leading-line-alternative-'+name
 envelope=f.envelope(request);review={'contract_version':'photo-embodiment-review/v1','provenance':'agent_prepack','prompt_sha256':hashlib.sha256(baseline.encode()).hexdigest(),'scope':'not_applicable','summary':'Authored still-life scene contains no body or body action; no image assessment is claimed.','checks':{}}
 normalized=pg.normalize_authorial_core(core,request_envelope=pg.normalize_request_envelope(envelope),creative_control_snapshot=controls);pg.photo_embodiment.build_policy(normalized,review)
 d=O/'public-cli/inputs'/name
 for key,value in [('request-envelope',envelope),('authorial-core',core),('creative-controls',controls),('embodiment-review',review)]:save(d/(key+'.json'),value)
 manifest.append({'case':name,'seed':709,'target_profile':before['id'],'inputs':{p.name:sha(p)for p in sorted(d.glob('*.json'))}})
save(O/'public-cli/frozen-input-manifest.json',manifest)
print({'changed_semantic_text_ids':altered,'reusable_vectors':len(reused),'profiles':len(texts),'controls':len(manifest)})
