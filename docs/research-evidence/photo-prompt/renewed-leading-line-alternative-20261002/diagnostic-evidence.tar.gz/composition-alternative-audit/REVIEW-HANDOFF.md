# Two-gate wording consistency proposal

Ready for independent review; no repository source edits or external API calls performed by this scout.

## Exact proposal

`exact-two-leaf-proposal.json` contains before/after values and stable gate IDs. Full exact current profile and proposed profile are in `proposal-before-profile.json` and `proposal-after-profile.json`.

Only proposed changes, both in `leading_line_target_continuity.render_gates`:
- `vo_composition_line_origin_away.description`: “A physical line or aligned scene edge begins away from the primary subject.”
- `vo_composition_line_path_continuous.description`: “The line remains visibly continuous or rhythmically linked across the intervening frame.”

No new alternative is invented: both are already in the mandatory component/evidence wording, and repeated aligned edges also appear in an authored paraphrase. Preserve the target endpoint and physical-scene requirements. This is a wording-consistency correction, not an observed image-review rejection.

## Frozen BEFORE controls

Both normal public CLI runs completed successfully, seed 709:
1. `continuous`: continuous brass rail from lower-left frame edge to blue teapot spout.
2. `rhythmic`: repeated aligned brass edge segments with small regular gaps from the same origin to the same blue teapot spout.

Both explicitly request the profile, remain physical still-life compositions, and materialize the original two narrower gate descriptions. Both retain exactly the nominated teapot-spout endpoint. No final image is generated or judged.

Files:
- `public-cli/inputs/{continuous,rhythmic}/`: frozen request envelope, authorial core, controls, not-applicable body review
- `public-cli/frozen-input-manifest.json`: immutable-input SHA-256s
- `public-cli/before/run-manifest.json`: exact commands, source/index/script hashes, working-tree status, exit codes, and materialized gates
- `public-cli/before/{continuous,rhythmic}-pack.json`: complete public packs
- `public-cli/run_phase.py`: rerun with `after` after the reviewed patch and metadata rebuild; reuses the same frozen inputs

HEAD was 326a9321; these later BEFORE controls use the active overhead-repair working-tree registry/index, intentionally permitted by the parent. Exact registry SHA-256 is `57ddac1664abaab5299f7fe18a172c6de937c16ac64afb004f1e8513d6f379c0`; index SHA-256 is `d3101a45c53f2d898416ddc3dff70e72339eacbb7ef2bb56e429a06051fa913d`. Do not label these packs pristine 326a9321. The earlier `consumer-proof.json` is separately preserved from the initial clean audit.

## Semantic recipe / vector reuse

`prompt_generator.visual_profile_semantic_text` delegates to `photo_visual_retrieval.positive_visual_profile_text`. Its allowlisted positive fields are definition, paraphrases, component groups, and concept terms. Render-gate descriptions are excluded.

`vector-reuse-proof.json` verifies against the real current registry/index:
- 1,496 profiles and 1,496 index entries
- 0 changed semantic texts under the proposed two descriptions
- all 1,496 existing vectors accepted by the normal `build_visual_profile_index.reusable_vectors` function, with matching provider/model/dimensions and exact stored text
- 0 missing vector IDs

Therefore all existing visual-profile vectors can legitimately be reused for a normal registry-metadata index rebuild. The builder calls the embedding API only for pending IDs; pending is empty here. Tags/candidate text are untouched, so this proposal does not call for candidate semantic vectors either. Re-check current hashes if another repair lands before applying; do not substitute a stale whole registry.

`prepare_controls.py` is the reproducible proposal/text-reuse and initial control-freezing script. Do not run it again after patching if the goal is to preserve the existing frozen BEFORE artifacts. Use `public-cli/run_phase.py after` for comparison instead.
