import copy, hashlib, json, pathlib, subprocess, sys
R=pathlib.Path('REPOSITORY_ROOT'); O=pathlib.Path(__file__).parent; P=O.parent/'composition-alternative-audit'
sys.dont_write_bytecode=True
sys.path.insert(0,str(R/'skills/photo-prompt-image-generator/scripts'))
import prompt_generator as pg
import build_visual_profile_index as build
load=lambda p:json.loads(p.read_text())
def save(n,v):(O/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def diffs(a,b,path=()):
 if isinstance(a,dict) and isinstance(b,dict):return sum((diffs(a.get(k),b.get(k),path+(k,)) for k in sorted(set(a)|set(b))),[])
 if isinstance(a,list) and isinstance(b,list) and len(a)==len(b):return sum((diffs(x,y,path+(i,)) for i,(x,y) in enumerate(zip(a,b))),[])
 return [] if a==b else [{'path':list(path),'before':a,'after':b}]
A=R/'skills/photo-prompt-image-generator/assets'; reg=pg.load_visual_obligation_registry(A/'photo_prompt_visual_obligations.json'); idx=load(A/'photo_prompt_visual_profile_index.json')
before=load(P/'proposal-before-profile.json'); after=load(P/'proposal-after-profile.json'); live=next(p for p in reg['profiles'] if p['id']==before['id']); assert live==before
changes=diffs(before,after); assert [d['path'] for d in changes]==[['render_gates',0,'description'],['render_gates',1,'description']]
new=copy.deepcopy(reg);new['profiles']=[after if p['id']==after['id'] else p for p in new['profiles']]
reused=build.reusable_vectors([A/'photo_prompt_visual_profile_index.json'],new,provider=idx['provider'],model=idx['embedding_model'],dimensions=idx['embedding_dimensions'])
assert len(reused)==len(reg['profiles'])==1496
rebuilt=pg.build_visual_profile_index_payload(new,vectors=reused,provider=idx['provider'],model=idx['embedding_model'],dimensions=idx['embedding_dimensions'])
assert rebuilt['entries']==idx['entries']; sidecar_diff=[d['path'] for d in diffs(idx,rebuilt)];assert sidecar_diff==[['registry_sha256']]
b=pg.candidate_pack_visual_profile_obligation(before,reg,activation_source='explicit_visual_intent',source_intent_ids=[])
a=pg.candidate_pack_visual_profile_obligation(after,new,activation_source='explicit_visual_intent',source_intent_ids=[])
assert diffs(b,a)==changes
manifest=load(P/'public-cli/before/run-manifest.json'); controls=[]
for row in manifest['cases']:
 assert row['exit_code']==0
 pack=load(P/'public-cli/before'/f"{row['case']}-pack.json")[0];ob=next(x for x in pack['visual_obligations']['obligations'] if x['id']==before['id']); assert ob['render_gates']==before['render_gates']
 for field in ['component_semantics','composition_instruction','evidence_requirements','reject_substitutes','prompt_binding']: assert ob[field]==b[field]
 controls.append({'case':row['case'],'public_cli_exit':row['exit_code'],'pack_id':row['summary']['pack_id'],'source_request':pack['authorial_core']['source_request'],'before_gates_match':True,'unchanged_contract_fields_match':True})
for c in load(P/'public-cli/frozen-input-manifest.json'):
 for name,sha in c['inputs'].items():assert hashlib.sha256((P/'public-cli/inputs'/c['case']/name).read_bytes()).hexdigest()==sha
hash_matches={name:hashlib.sha256((R/name).read_bytes()).hexdigest()==sha for name,sha in manifest['hashes'].items()};assert all(hash_matches.values())
save('approved-profile.json',after)
save('review-proof.json',{'decision':'approve exact two render-gate descriptions without amendment','live_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'before_head':manifest['head'],'before_source_hashes_match_live':hash_matches,'changes':changes,'all_other_profile_fields_unchanged':True,'actual_consumer_in_memory_diff':changes,'public_cli_before_controls':controls,'semantic_text_changes':[],'reusable_vectors':len(reused),'index_entries_identical':True,'required_generated_sidecar_diff_paths':sidecar_diff,'api_calls':0,'pixel_assessment':False})
print('APPROVED: exact two leaves; 1496 real vectors reused, sidecar registry hash only; BEFORE CLI controls source hashes match live')
