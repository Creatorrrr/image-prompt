# AFTER independent verification

Approved live profile exactly matches `approved-profile.json`. Normal index loader validates its registry binding. Both genuine AFTER public CLI packs exit zero; AFTER manifest source hashes match the live checkout. Their complete authorial cores equal BEFORE, and their target obligation changes only in the two approved gate descriptions. Origin, nominated teapot-spout endpoint, continuous branch, evidence requirements and false-substitute safeguards remain unchanged.

## Actual full-composition results

Authored complete compositions retaining each frozen baseline were passed to the real `audit_composed_prompt.py` CLI:

- Continuous rail: PASS, exit 0, zero failures
- Rhythmic repeated aligned edges: PASS, exit 0, zero failures

Each reports the same three `uncovered_intent` warnings for teapot / primary target anchor / brass route, explicitly noting these meanings are preserved by free description/assertion. These are reported warnings, not a zero-warning result.

The same literal evidence also passes the focused visual-obligation auditor against each genuine BEFORE pack. BEFORE and AFTER acceptance both pass, as expected: this is render-judgment wording consistency, not a demonstrated parser rejection repair. No rendered image, pixel rejection, pixel success, or retrieval rank was measured.

Evidence word counts clear unchanged floors 9/10/10/12: continuous 15/16/11/17; rhythmic 15/26/11/17. The full baseline remains the beginning of each final composed prompt. Both retain the same spout endpoint and lower-left origin; the rhythmic case retains regular gaps rather than being silently converted to an uninterrupted rail.

Three existing composition regressions pass (65.209 seconds): profile completeness/exact routing, false-substitute nonactivation, and composition candidate semantics/conflicts. This is focused existing regression coverage, not the entire test suite.

## Evidence

- `after-evidence/pack-comparison.json`: genuine BEFORE/AFTER equality checks
- `after-evidence/full-composition-summary.json`: commands, outcomes, warnings, word counts, BEFORE/AFTER focused results
- `after-evidence/*-complete-composed.json`: complete authored compositions
- `after-evidence/*-complete-audit.json`: full actual consumer audit results
- `after-evidence/source-verification.json`: live profile/index validation and source hashes
- `regression.stderr`: three-test run result
- `verify_after.py` and `compare_after.py`: reproducible review scripts

No repository edits, API calls or fabricated vectors were used by this review.
