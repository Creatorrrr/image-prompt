# Independent review: approved without amendment

The exact approved full profile is `approved-profile.json`. Only two leaves change:

- `render_gates[0].description`: A physical line or aligned scene edge begins away from the primary subject.
- `render_gates[1].description`: The line remains visibly continuous or rhythmically linked across the intervening frame.

This preserves an existing authored alternative, not a new generic leading-line scope. The current required origin group already permits an aligned edge; the required continuity group and its evidence requirement explicitly permit rhythmic linkage; the positive paraphrase explicitly names repeated aligned edges. The research summary emphasizes a continuous target-bound path but does not override these more specific authored alternatives. An arbitrary dotted pattern, decorative striping, speed graphics, or a route to an empty vanishing point remains insufficient.

The original visibly continuous branch remains verbatim. All other profile fields compare equal, including definition, composition instruction, origin group, nominated primary identity/action endpoint, all four required component groups, component minimum of four, all four evidence fields, word floors 9/10/10/12, target gate, false-substitute gate, activation exclusions, four gate IDs and thumbnail/both/both/native scales. “Continuously readable” in the unchanged composition instruction permits the already-authored perceptually linked route; no runtime rewrite is warranted.

## Independently checked actual consumers

`verify.py` uses the normal registry loader, `candidate_pack_visual_profile_obligation`, `visual_profile_semantic_text` via the real index reuse/build functions, and saved ordinary public CLI outputs. It does not edit the repository or call any API.

Both frozen BEFORE controls exited zero and contain the narrower original render descriptions alongside the existing broader continuity evidence. One control requests an uninterrupted brass rail; the other requests repeated aligned brass edge segments with small regular gaps. Both retain the same teapot-spout target and distant lower-left origin. Their frozen input hashes verify. Every source hash in the BEFORE run manifest matches the live checkout, including runtime and index files. The checkout advanced from the recorded 326a9321 working tree to 1feea7ce (overhead alternative commit), but the recorded consumer sources are identical. This establishes trustworthy BEFORE propagation, not an observed image rejection or a semantic-retrieval rank claim.

In-memory materialization of the approved profile changes exactly the same two public obligation description leaves and no other obligation fields. This proves the existing consumer already passes the data through; no runtime patch is needed. No AFTER public CLI run is claimed in this review.

## Index handling

All 1,496 existing semantic texts remain unchanged and all 1,496 real existing vectors pass the normal reusable-vectors criteria with unchanged provider/model/dimensions. Rebuilding the proposed sidecar in memory gives identical entries, exact lookup, BM25F data and retrieval policy. The only sidecar change required is `registry_sha256`, because registry binding includes these gate descriptions. Reuse the real vectors and regenerate that binding; do not leave the old index file byte-for-byte unchanged or invent vectors. No embedding payment or API call is necessary.

## Concise implementer controls

1. Apply only the two approved descriptions, keeping the complete remaining profile equal to BEFORE.
2. Rebuild the registry-bound index with the existing real vector cache; expect only `registry_sha256` to differ, with every entry/text/vector unchanged.
3. Re-run both frozen ordinary public CLI inputs from `composition-alternative-audit/public-cli/inputs` with seed 709 after the edit. Expect exit zero, the same nominated spout endpoint and original request/baseline, unchanged evidence floors/component groups, and exactly the two description updates in this profile's emitted obligation.
4. Keep exact activation/exclusion regression coverage and assert all gate IDs/scales, target termination, reject-substitutes and continuous-path branch remain. Tests should inspect actual emitted obligation fields rather than only source substrings.
5. Report contract consistency only. Pixel-level success/failure requires separate actual rendered-image evidence, which is absent here.

Machine-checkable findings and source-hash comparison are in `review-proof.json`; reproduce using `PYTHONDONTWRITEBYTECODE=1 python daylong-progress-20261002/leading-line-review/verify.py` before applying the patch.
