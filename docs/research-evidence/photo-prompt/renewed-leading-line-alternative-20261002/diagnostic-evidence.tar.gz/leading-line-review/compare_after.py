import json, pathlib,sys,hashlib
O=pathlib.Path(__file__).parent;D=O.parent/'composition-alternative-audit/public-cli';R=O.parent.parent/'image-prompt';load=lambda p:json.loads(p.read_text());sys.dont_write_bytecode=True
sys.path.insert(0,str(R/'skills/photo-prompt-image-generator/scripts'));import prompt_generator as pg
profile=load(O/'approved-profile.json');reg=pg.load_visual_obligation_registry(R/'skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations.json');assert next(p for p in reg['profiles'] if p['id']==profile['id'])==profile
manifest=load(D/'after/run-manifest.json');assert len(manifest['cases'])==2 and all(c['exit_code']==0 for c in manifest['cases'])
for name,sha in manifest['hashes'].items():assert hashlib.sha256((R/name).read_bytes()).hexdigest()==sha
results=[]
for case in ['continuous','rhythmic']:
 before=load(D/'before'/f'{case}-pack.json')[0];after=load(D/'after'/f'{case}-pack.json')[0]
 b=next(x for x in before['visual_obligations']['obligations'] if x['id']==profile['id']);a=next(x for x in after['visual_obligations']['obligations'] if x['id']==profile['id']);assert a['render_gates']==profile['render_gates']
 b['render_gates']=a['render_gates'];assert b==a
 assert before['authorial_core']==after['authorial_core']
 results.append({'case':case,'genuine_cli_exit':0,'full_authorial_core_unchanged':True,'only_target_obligation_changes':'two approved gate descriptions','live_hashes_match_after_manifest':True})
(O/'after-evidence/pack-comparison.json').write_text(json.dumps(results,indent=2)+'\n');print(results)
