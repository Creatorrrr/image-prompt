#!/usr/bin/env python3
"""Read-only proof of the proposed ghost-ship gate-only DATA change.

No provider requests, repository writes, or persisted index rebuilds. Actual
index builder helpers run only against in-memory before/after registry objects.
Run with PYTHONDONTWRITEBYTECODE=1 to prevent import bytecode writes.
"""
import argparse
import copy
import hashlib
import json
from pathlib import Path
import subprocess
import sys
from unittest.mock import patch

sys.dont_write_bytecode = True
parser = argparse.ArgumentParser()
parser.add_argument('--repo', type=Path, default=Path('REPOSITORY_ROOT'))
parser.add_argument('--output', type=Path, default=Path(__file__).with_name('proof.json'))
args = parser.parse_args()
repo = args.repo.resolve()
out = args.output.resolve()
assert not out.is_relative_to(repo), 'Proof output must remain outside the repository'
scripts = repo / 'skills/photo-prompt-image-generator/scripts'
assets = scripts.parent / 'assets'
sys.path.insert(0, str(scripts))
import prompt_generator as pg
import build_visual_profile_index as builder

PID = 'ghost_ship_former_vessel_breach'
GID = 'vo_legend_ghost_ship_bounded_breach'
OLD = 'One bounded connected region breaks into spectral absence or displacement.'
NEW = 'One bounded connected region breaks into spectral translucency, absence, or displacement.'
registry_path = assets / pg.VISUAL_OBLIGATION_REGISTRY_FILENAME
index_path = assets / pg.VISUAL_PROFILE_INDEX_FILENAME
tracked_inputs = sorted(set([
    registry_path, index_path, assets / 'photo_prompt_tags.json',
    *[assets / name for name in pg.VISUAL_OBLIGATION_EXTENSION_FILENAMES if (assets / name).exists()],
    *[assets / name for name in pg.RESEARCH_EXTENSION_FILENAMES if (assets / name).exists()],
    scripts / 'prompt_generator.py', scripts / 'photo_visual_retrieval.py',
    scripts / 'visual_profile_contracts.py', scripts / 'bm25f_retrieval.py',
    scripts / 'build_visual_profile_index.py',
]))
def sha_file(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def fingerprints():
    return {str(p.relative_to(repo)): sha_file(p) for p in tracked_inputs}
def digest(obj):
    return pg.canonical_json_sha256(obj)
def changes(a, b, path=''):
    if type(a) != type(b):
        return [{'path': path, 'before': a, 'after': b}]
    if isinstance(a, dict):
        assert set(a) == set(b)
        return [d for k in a for d in changes(a[k], b[k], path + '/' + str(k))]
    if isinstance(a, list):
        assert len(a) == len(b)
        return [d for i, (x, y) in enumerate(zip(a,b)) for d in changes(x,y,path+'/'+str(i))]
    return [] if a == b else [{'path': path, 'before': a, 'after': b}]

before_hashes = fingerprints()
provider_calls = []
def forbidden_provider(*a, **kw):
    provider_calls.append(True)
    raise AssertionError('Provider calls are forbidden for this review')
with patch.object(pg, 'embed_texts_with_gemini', forbidden_provider), patch.object(builder, 'embed_texts_with_gemini', forbidden_provider), patch('socket.create_connection', side_effect=AssertionError('Network is forbidden')):
    before = pg.load_visual_obligation_registry(registry_path)
    after = copy.deepcopy(before)
    before_profile = next(p for p in before['profiles'] if p['id'] == PID)
    after_profile = next(p for p in after['profiles'] if p['id'] == PID)
    gate = next(g for g in after_profile['render_gates'] if g['id'] == GID)
    assert gate['description'] == OLD
    gate['description'] = NEW
    assert pg.compile_visual_profile(after_profile) == after_profile
    registry_changes = changes(before, after)
    assert len(registry_changes) == 1
    assert registry_changes[0]['path'].endswith('/render_gates/2/description')

    before_texts = {p['id']: pg.visual_profile_semantic_text(p) for p in before['profiles']}
    after_texts = {p['id']: pg.visual_profile_semantic_text(p) for p in after['profiles']}
    before_fields = pg.visual_profile_bm25f_documents(before)
    after_fields = pg.visual_profile_bm25f_documents(after)
    assert before_texts == after_texts
    assert before_fields == after_fields
    cache = pg.load_json(index_path)
    options = dict(provider=cache['provider'], model=cache['embedding_model'], dimensions=cache['embedding_dimensions'])
    vectors_before = builder.reusable_vectors([index_path], before, **options)
    vectors_after = builder.reusable_vectors([index_path], after, **options)
    assert vectors_before == vectors_after
    assert set(vectors_before) == set(before_texts), 'All existing vectors must be reusable'
    payload_before = pg.build_visual_profile_index_payload(before, vectors=vectors_before, **options)
    payload_after = pg.build_visual_profile_index_payload(after, vectors=vectors_after, **options)
    changed_payload_keys = sorted(k for k in payload_before if payload_before[k] != payload_after[k])
    assert changed_payload_keys == ['registry_sha256']
    assert payload_before['entries'] == payload_after['entries']
    assert payload_before['bm25f'] == payload_after['bm25f']
    assert payload_before['exact_lookup'] == payload_after['exact_lookup']
    pg.validate_visual_profile_index_metadata(payload_before, before, **options)
    pg.validate_visual_profile_index_metadata(payload_after, after, **options)
    try:
        pg.validate_visual_profile_index_metadata(payload_before, after, **options)
    except ValueError as err:
        stale_error = str(err)
        assert 'registry_sha256' in stale_error
    else:
        raise AssertionError('An old source-binding fingerprint must fail after the gate edit')

    # The separate general semantic index consumes the merged tag corpus.
    # Load that real corpus with each hypothetical registry supplied to its
    # validation dependency, then compare actual builder document helpers.
    with patch.object(pg, 'load_visual_obligation_registry', return_value=before):
        corpus_before = pg.load_json(assets / 'photo_prompt_tags.json')
    with patch.object(pg, 'load_visual_obligation_registry', return_value=after):
        corpus_after = pg.load_json(assets / 'photo_prompt_tags.json')
    assert corpus_before == corpus_after
    general_texts_before = {key: pg.semantic_text_for_entry(entry, slot, kind=kind) for key, kind, entry, slot in pg.iter_semantic_entries(corpus_before)}
    general_texts_after = {key: pg.semantic_text_for_entry(entry, slot, kind=kind) for key, kind, entry, slot in pg.iter_semantic_entries(corpus_after)}
    general_fields_before = pg.semantic_bm25f_documents(corpus_before)
    general_fields_after = pg.semantic_bm25f_documents(corpus_after)
    assert general_texts_before == general_texts_after
    assert general_fields_before == general_fields_after

    # Existing intended exact route and nearest-substitute negatives stay equal.
    route_cases = ['former vessel breaking into spectral continuity', 'A foggy abandoned ship with an empty deck', 'A fully translucent boat floating above the sea', 'ordinary shipwreck', 'unrelated crew overlay', 'ship silhouette in clouds']
    route_result = {}
    def resolve(registry, payload, text):
        result = pg.resolve_visual_profile_hits(registry, [dict(source='concept_lock', text=text, polarity='required', priority='critical', mandatory=True), dict(source='authorial_core_interpreted_intent', text=text, polarity='required', priority='critical', mandatory=True)], visual_profile_index=payload, adult_context=True)
        return sorted(h['profile_id'] for h in result['hits'] if h.get('match_basis') == 'exact' and h.get('hard_eligible') is True)
    for text in route_cases:
        old_hits = resolve(before, payload_before, text)
        new_hits = resolve(after, payload_after, text)
        assert old_hits == new_hits
        assert (PID in old_hits) == (text == route_cases[0])
        route_result[text] = old_hits

assert not provider_calls
assert before_hashes == fingerprints(), 'Inputs changed during proof; rerun against a stable snapshot'
report = {
    'verdict': 'PASS: supported gate alignment; unchanged retrieval documents',
    'repo_head': subprocess.check_output(['git','rev-parse','HEAD'], cwd=repo, text=True).strip(),
    'profile_id': PID,
    'gate_id': GID,
    'sole_in_memory_registry_change': registry_changes,
    'actual_helpers': ['load_visual_obligation_registry','compile_visual_profile','visual_profile_semantic_text','visual_profile_bm25f_documents','build_visual_profile_index.reusable_vectors','build_visual_profile_index_payload','validate_visual_profile_index_metadata','load_json','iter_semantic_entries','semantic_text_for_entry','semantic_bm25f_documents','resolve_visual_profile_hits'],
    'visual_profile_index': {
        'profile_count': len(before_texts),
        'vector_texts_equal': True,
        'vector_texts_sha256': digest(before_texts),
        'bm25f_document_fields_equal': True,
        'bm25f_document_fields_sha256': digest(before_fields),
        'complete_bm25f_payload_equal': True,
        'complete_bm25f_payload_sha256': digest(payload_before['bm25f']),
        'cached_vectors_reusable_before': len(vectors_before),
        'cached_vectors_reusable_after': len(vectors_after),
        'cached_vectors_equal': True,
        'entries_including_vectors_equal': True,
        'exact_lookup_equal': True,
        'changed_payload_top_level_keys': changed_payload_keys,
        'registry_sha256_before': payload_before['registry_sha256'],
        'registry_sha256_after': payload_after['registry_sha256'],
        'old_binding_rejected_after_change': stale_error,
        'target_vector_text_sha256': payload_before['entries'][PID]['text_sha256'],
        'target_vector_text': before_texts[PID],
        'target_bm25f_document_fields': before_fields[PID],
    },
    'general_semantic_index': {
        'merged_corpus_equal': True,
        'entry_count': len(general_texts_before),
        'vector_texts_equal': True,
        'vector_texts_sha256': digest(general_texts_before),
        'bm25f_document_fields_equal': True,
        'bm25f_document_fields_sha256': digest(general_fields_before),
    },
    'exact_routing_cases_unchanged': route_result,
    'provider_calls': 0,
    'repository_files_written': [],
    'index_files_regenerated': [],
    'input_files_unchanged_during_proof': True,
    'input_sha256': before_hashes,
    'limitations': ['In-memory DATA and retrieval proof, not a generated-image or aesthetic result.', 'Existing source research establishes maritime identity and cultural motif, not physical supernatural evidence.', 'The visual index registry fingerprint changes despite unchanged documents; the persisted index must be rebound if this proposal is implemented.'],
}
out.parent.mkdir(parents=True, exist_ok=True)
out.write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\n')
print(json.dumps({k: report[k] for k in ('verdict','profile_id','provider_calls','repository_files_written','index_files_regenerated')}, indent=2))
print(f"Visual profiles: {len(before_texts)}; reusable vectors: {len(vectors_after)}; general semantic entries: {len(general_texts_before)}")
print(f"Changed visual index keys: {changed_payload_keys}")
print(f"Proof: {out}")
