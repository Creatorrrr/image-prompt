#!/usr/bin/env python3
"""Verify separate label-only fixture repair without changing fixtures."""
from pathlib import Path
import hashlib,json
P=Path('EVIDENCE_ROOT/ghost-ship-gate-qualification')
O=Path(__file__).resolve().parent
read=lambda n:json.loads((P/n).read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=read('manifest.json')
assert all(sha(P/f)==h for f,h in manifest['input_hashes'].items())
before=read('compositions.json');after=read('revised-compositions.json')
assert len(before)==len(after)==20
suffix=' This scene shows a ghost ship with former-vessel continuity breach.'
changed=[];unchanged=[]
for a,b in zip(before,after):
 assert a['id']==b['id']
 assert {k:v for k,v in a.items() if k!='prompt'}=={k:v for k,v in b.items() if k!='prompt'}
 if a['bindings'] or a['kind']=='missing_binding':
  assert b['prompt']==a['prompt']+suffix
  changed.append(a['id'])
 else:
  assert a==b;unchanged.append(a['id'])
original=read('before/report.json')
original_full=[c for c in original['compositions'] if c['kind']=='positive']
assert len(original_full)==3
assert all(c['status']=='fail' and c['expected']=='pass' for c in original_full)
assert all([f['check'] for f in c['failures']]==['visual_obligation_runtime_expression'] for c in original_full)
revision=read('composition-revision.json')
assert revision['revised_sha256']==sha(P/'revised-compositions.json')
assert revision['original_input_manifest_sha256']==sha(P/'manifest.json')
report=dict(verdict='PASS: separate, explicitly source-guided fixture repair',input_hashes_verified=len(manifest['input_hashes']),original_failures_retained=[c['id'] for c in original_full],changed_prompt_only=changed,unchanged_controls=unchanged,suffix=suffix,revised_compositions_sha256=revision['revised_sha256'],checksums_and_all_nonprompt_fields_unchanged=True,limitation='Revised public audit outcomes and eventual AFTER comparison must be independently completed; this verifies fixture isolation and provenance only.')
(O/'fixture-repair-proof.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
