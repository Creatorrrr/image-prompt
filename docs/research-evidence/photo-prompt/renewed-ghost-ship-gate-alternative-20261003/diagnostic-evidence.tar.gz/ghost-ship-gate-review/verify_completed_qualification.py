#!/usr/bin/env python3
"""Independently check all recorded actual public CLI outcomes after completion."""
from pathlib import Path
import copy, hashlib, json, sys
sys.dont_write_bytecode=True
O=Path(__file__).resolve().parent;Q=O.parent/'ghost-ship-gate-qualification';R=O.parent.parent/'image-prompt'
sys.path.insert(0,str(R/'skills/photo-prompt-image-generator/scripts'));import prompt_generator as pg;import audit_composed_prompt as audit
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
PID='ghost_ship_former_vessel_breach';GID='vo_legend_ghost_ship_bounded_breach';OLD='One bounded connected region breaks into spectral absence or displacement.';NEW='One bounded connected region breaks into spectral translucency, absence, or displacement.'
SUFFIX=' This scene shows a ghost ship with former-vessel continuity breach.'
def diff(a,b,path=''):
 if type(a)!=type(b):return [(path,a,b)]
 if isinstance(a,dict):
  assert set(a)==set(b),(path,'keys')
  return [d for k in sorted(a) for d in diff(a[k],b[k],path+'/'+k)]
 if isinstance(a,list):
  assert len(a)==len(b),(path,'length')
  return [d for i,(x,y)in enumerate(zip(a,b))for d in diff(x,y,path+'/'+str(i))]
 return []if a==b else [(path,a,b)]
def locate(obj,path):
 for s in path.strip('/').split('/'):
  obj=obj[int(s)] if isinstance(obj,list) else obj[s]
 return obj
man=read(Q/'manifest.json');specs=read(Q/'compositions.json');revised_specs=read(Q/'revised-compositions.json');specmap={s['id']:s for s in specs}
assert len(specs)==20 and len(specmap)==20
assert all(sha(Q/f)==h for f,h in man['input_hashes'].items())
assert read(Q/'comparison.json')['status']=='pass'
assert read(Q/'revised-comparison.json')['status']=='pass'
a=read(Q/'before/report.json');b=read(Q/'after/report.json')
assert a.get('finished_at_utc') and b.get('finished_at_utc')
assert len(a['cases'])==len(b['cases'])==5
assert len(a['compositions'])==len(b['compositions'])==20
for arm in ['before','after']:
 assert read(Q/arm/'source-start.json')['source_hashes']==read(Q/arm/'source-end.json')['source_hashes']
packs=[]
for case in man['case_ids']:
 pa=read(Q/'before'/case/'pack.json')[0];pb=read(Q/'after'/case/'pack.json')[0]
 da=diff(pa,pb);is_positive=case in {'translucency','absence','displacement'}
 for path,old,new in da:
  if path=='/pack_id':continue
  assert path.endswith('/description') and old==OLD and new==NEW,(case,path)
  assert locate(pa,path.rsplit('/',1)[0])['id']==GID
  assert locate(pb,path.rsplit('/',1)[0])['id']==GID
 assert bool(da)==is_positive
 for arm,pack in [('before',pa),('after',pb)]:
  assert read(Q/arm/case/'cli.json')['exit_code']==0
  assert pg.candidate_pack_recompute_id(copy.deepcopy(pack))['pack_id']==pack['pack_id']
  assert {p['id']for p in pack.get('visual_obligations',{}).get('obligations',[])}==({PID}if is_positive else set())
 packs.append(dict(case=case,changed_paths=[d[0]for d in da],hard_target=is_positive,negative_identical=not is_positive))
original=[]
for x,y in zip(a['compositions'],b['compositions']):
 assert x==y,(x['id'],'original full report row changed')
 spec=specmap[x['id']]
 expected_original='pass' if spec['kind']=='ordinary_control' else 'fail'
 assert x['status']==expected_original
 if spec['kind']=='positive':assert [f['check']for f in x['failures']]==['visual_obligation_runtime_expression']
 ca=read(Q/'before/compositions'/x['id']/'composed.json');cb=read(Q/'after/compositions'/x['id']/'composed.json')
 assert all(p=='/pack_id'for p,_,_ in diff(ca,cb))
 assert ca['chosen_candidate_ids']==cb['chosen_candidate_ids']==[]
 assert ca['chosen_visual_concept_ids']==cb['chosen_visual_concept_ids']==[]
 original.append(dict(id=x['id'],status=x['status'],original_expected=x['expected']))
ra=read(Q/'revised-before/report.json');rb=read(Q/'revised-after/report.json');assert len(ra)==len(rb)==20 and ra==rb
for revised,orig in zip(revised_specs,specs):
 assert {k:v for k,v in revised.items() if k!='prompt'}=={k:v for k,v in orig.items() if k!='prompt'}
 assert revised['prompt']==orig['prompt']+(''if orig['kind']=='ordinary_control' else SUFFIX)
for row in ra:
 spec=specmap[row['id']]
 assert row['status']==row['expected']==('fail'if spec['kind']=='missing_binding'else'pass')
 assert not any(f['check']=='visual_obligation_runtime_expression' for f in row['failures'])
 if spec['kind']=='missing_binding':
  assert any(f['check']=='visual_obligation_evidence' and (f.get('field')==spec['failure_field'] or spec['failure_field'] in f.get('missing',[])) for f in row['failures'])
 for arm in ['before','after']:
  original_composed=read(Q/arm/'compositions'/row['id']/'composed.json')
  revised_composed=read(Q/('revised-'+arm)/row['id']/'composed.json')
  deltas=diff(original_composed,revised_composed)
  assert {p for p,_,_ in deltas}==({'/prompt_en','/embodiment_review/review/prompt_sha256'} if spec['kind']!='ordinary_control' else set())
  cli=read(Q/('revised-'+arm)/row['id']/'cli.json')
  assert cli['exit_code']==(1 if row['status']=='fail' else 0)
  actual_audit=read(Q/('revised-'+arm)/row['id']/'audit.json')
  assert actual_audit['status']==row['status'] and actual_audit['failures']==row['failures']
 audit_before=read(Q/'revised-before'/row['id']/'audit.json');audit_after=read(Q/'revised-after'/row['id']/'audit.json')
 expected_derived={'/pack_id','/effective_visual_contract_sha256'} if spec['kind']!='ordinary_control' else set()
 assert {p for p,_,_ in diff(audit_before,audit_after)}==expected_derived
 for arm,actual_audit in [('before',audit_before),('after',audit_after)]:
  pack=read(Q/arm/spec['case']/'pack.json')[0]
  composed=read(Q/('revised-'+arm)/row['id']/'composed.json')
  effective,failures=audit.derive_effective_visual_obligation_contract(pack,composed)
  assert not failures
  assert actual_audit['pack_id']==pack['pack_id']
  assert actual_audit['effective_visual_contract_sha256']==audit.effective_visual_obligation_sha256(effective)
assert all(sha(Q/f)==h for f,h in man['input_hashes'].items())
artifact_manifest=read(Q/'artifact-manifest.json');assert all(sha(Q/f)==h for f,h in artifact_manifest.items());report=dict(artifact_manifest_hashes_verified=len(artifact_manifest),status='pass',five_actual_v6_cli_packs=packs,original_composition_count=20,original_failure_outcomes_and_expectations_retained=original,revised_full_passes=sum(x['status']=='pass'for x in ra),revised_missing_binding_failures=sum(x['status']=='fail'for x in ra),all_twenty_revised_audit_outcomes_identical_before_after=True,actual_audit_object_deltas='Only derived pack_id and independently verified effective_visual_contract_sha256 on the 18 target fixtures; no changes on either control',revised_actual_composition_delta='Only existing exact label and necessary prompt checksum on 18 active-profile fixtures; two controls unchanged',all_52_frozen_input_hashes_intact=True,before_and_after_source_hashes_stable_during_run=True,optional_candidate_selections=[],provider_calls_by_review=0,repository_writes_by_review=[],scope='Instruction-contract correction and preserved source-aware synthetic CLI behavior only. No rendered pixels, acceptance improvement, natural-query recall or clean-precore holdout claim.')
(O/'completed-qualification-proof.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
