#!/usr/bin/env python3
"""Independently verify real gate integration; read-only against repository."""
from pathlib import Path
import copy, hashlib, json, subprocess, sys
from unittest.mock import patch
sys.dont_write_bytecode=True
O=Path(__file__).resolve().parent;Q=O.parent/'ghost-ship-gate-qualification';R=O.parent.parent/'image-prompt';S=R/'skills/photo-prompt-image-generator/scripts';A=S.parent/'assets'
sys.path.insert(0,str(S));import prompt_generator as pg
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
git=lambda *args:subprocess.check_output(['git',*args],cwd=R,text=True).strip()
PID='ghost_ship_former_vessel_breach';GID='vo_legend_ghost_ship_bounded_breach'
REG='skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations.json';IDX='skills/photo-prompt-image-generator/assets/photo_prompt_visual_profile_index.json'
manifest=read(Q/'manifest.json');patch_spec=read(Q/'proposal/patch.json')
assert all(sha(Q/f)==h for f,h in manifest['input_hashes'].items())
source_before=read(Q/'source-freeze'/REG);source_after=read(R/REG)
expected=copy.deepcopy(source_before)
profile=next(p for p in expected['profiles'] if p['id']==PID)
gate=next(g for g in profile['render_gates'] if g['id']==GID)
assert gate['description']==patch_spec['before'];gate['description']=patch_spec['after']
assert expected==source_after
changed_sources=sorted(f for f,h in manifest['source_hashes'].items() if sha(R/f)!=h)
assert changed_sources==sorted([REG,IDX]),changed_sources
index_before=read(Q/'source-freeze'/IDX);index_after=read(R/IDX)
changed_keys=sorted(k for k in index_before if index_before[k]!=index_after[k])
assert changed_keys==['registry_sha256']
assert set(index_before)==set(index_after)
assert json.loads(git('show','HEAD:'+REG))==source_before
assert json.loads(git('show','HEAD:'+IDX))==index_before
assert set(git('diff','--name-only').splitlines())=={REG,IDX}
with patch.object(pg,'embed_texts_with_gemini',side_effect=AssertionError('Provider forbidden')),patch('socket.create_connection',side_effect=AssertionError('Network forbidden')):
 actual_registry=pg.load_visual_obligation_registry(R/REG)
 pg.validate_visual_profile_index_metadata(index_after,actual_registry,provider=index_after['provider'],model=index_after['embedding_model'],dimensions=index_after['embedding_dimensions'])
 assert index_after['registry_sha256']==pg.visual_profile_registry_sha256(actual_registry)
 # Restore exactly the one leaf in memory to validate the frozen index too.
 baseline=copy.deepcopy(actual_registry)
 next(g for p in baseline['profiles'] if p['id']==PID for g in p['render_gates'] if g['id']==GID)['description']=patch_spec['before']
 pg.validate_visual_profile_index_metadata(index_before,baseline,provider=index_before['provider'],model=index_before['embedding_model'],dimensions=index_before['embedding_dimensions'])
 assert pg.visual_profile_bm25f_documents(baseline)==pg.visual_profile_bm25f_documents(actual_registry)
 assert all(pg.visual_profile_semantic_text(a)==pg.visual_profile_semantic_text(b) for a,b in zip(baseline['profiles'],actual_registry['profiles']))
assert all(sha(Q/f)==h for f,h in manifest['input_hashes'].items())
report=dict(status='pass',head=git('rev-parse','HEAD'),working_tree=git('status','--porcelain'),source_change='Exactly approved ghost-ship gate description',changed_manifest_sources=changed_sources,changed_index_top_level_keys=changed_keys,index_entries_including_vectors_identical=index_before['entries']==index_after['entries'],bm25f_payload_identical=index_before['bm25f']==index_after['bm25f'],exact_lookup_identical=index_before['exact_lookup']==index_after['exact_lookup'],actual_index_metadata_valid=True,frozen_index_metadata_valid_under_original_leaf=True,profile_count=len(actual_registry['profiles']),frozen_input_hashes_verified=len(manifest['input_hashes']),manifest_source_hashes_verified=len(manifest['source_hashes']),source_after_sha256=sha(R/REG),index_after_sha256=sha(R/IDX),provider_calls=0,repository_writes=[],qualification_outcomes='Pending independent comparison review')
(O/'actual-integration-source-proof.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
