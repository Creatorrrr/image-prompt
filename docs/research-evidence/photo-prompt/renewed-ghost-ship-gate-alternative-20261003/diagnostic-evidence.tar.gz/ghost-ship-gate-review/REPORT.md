# Independent ghost-ship gate DATA review

## Decision: APPROVE the exact one-leaf proposal

Change only `ghost_ship_former_vessel_breach.render_gates[vo_legend_ghost_ship_bounded_breach].description` from “One bounded connected region breaks into spectral absence or displacement.” to “One bounded connected region breaks into spectral translucency, absence, or displacement.”

This repairs a mismatch with the existing authored definition, bounded-spectral-breach component and spectral-breach evidence requirement; all three already permit translucency. The existing subject and action candidates also explicitly describe a bounded translucent region. It adds no new profile, activation alias, retrieval concept, duty, or alternative beyond the authored meaning.

## Support and preserved limits

Reviewed the base profile, its legend extension candidates, `legend-visual-semantics-20260901/source-research.md`, both maritime evidence records in `evidence.jsonl`, and `iteration-record.json`.

- NOAA-derived research supports identifiable vessel use and service residue. The Royal Museums Greenwich-derived research supports the ghost-ship cultural motif. Neither source is treated as proof of supernatural phenomena. The exact translucency choice is an existing authored visual interpretation, not a newly verified empirical finding.
- All five required groups and evidence fields remain: same vessel, substantial opaque physical baseline, bounded spectral breach, former service residue and a present anomaly. The gate still requires one bounded connected region, and all five pixel gates remain required.
- Whole-boat translucency, fog/abandonment, ordinary wreck, empty deck, unrelated exposure and cloud silhouette remain rejected. Ordinary translucent material is not automatically a spectral anomaly. The independent opaque-hull and observable-anomaly gates still apply.
- The original three-image study did not render this ghost-ship profile. This review establishes DATA consistency and retrieval invariance, not ghost-ship image quality or rendered acceptance.

## Deterministic index proof: PASS

`prove_gate_only.py` loads the real compiled registry, applies the proposed edit only to an in-memory copy, and invokes the actual index-builder helpers. Provider functions are blocked, no repository files are written, and no index is persisted or regenerated. Input fingerprints remained unchanged during execution.

- All 1,510 visual-profile semantic texts and BM25F document fields are exactly equal before/after
- All 1,510 stored vectors satisfy the real `reusable_vectors` helper before/after and remain equal
- The complete in-memory visual-index entries, BM25F payload and exact lookup are equal
- The sole changed visual-index top-level field is `registry_sha256`
- All 9,739 separate general-semantic-index embedding texts and BM25F document fields are equal using the actual corpus loader and helper projections
- The intended exact route and six route/control inputs retain identical outcomes

Important implementation consequence: the registry-bound visual index must receive the new source fingerprint if this edit is applied. The old fingerprint correctly fails metadata validation. This needs no new embeddings; every existing vector is reusable. The separate general semantic index has no changed input documents.

Proof: `proof.json`; reproduction: `PYTHONDONTWRITEBYTECODE=1 image-prompt/.venv/bin/python daylong-progress-20261002/ghost-ship-gate-review/prove_gate_only.py` from the workspace root.

The reviewed repository HEAD was `5bf8142304f484138474fff4af9b0660439fa331`, with pre-existing concurrent photo-era/index/slide-test changes. This is not a clean-tree claim; the proof records the exact input hashes and isolates the hypothetical gate delta.

## Independent fixture-repair review: APPROVE with bounded claims

The separate label repair is appropriate for these explicitly source-guided synthetic diagnostics. The existing policy is `label_plus_definition`, and all three original complete positive compositions failed only because the exact accepted safe label was omitted. Adding the already required label to both arms restores the test fixture's existing contract; it is not evidence of improvement from the gate edit.

`review_fixture_repair.py` independently verified all 52 original frozen input hashes, retained original positive failures and their original PASS expectations, and exact differences between original and revised composition specifications:

- Eighteen active-profile prompts append only “This scene shows a ghost ship with former-vessel continuity breach.”
- Every non-prompt fixture field, binding, expected status and case association stays equal
- Both no-target controls are unchanged
- The revised composition hash is frozen and matches `composition-revision.json`
- The repair runner refreshes only the necessary postcomposition prompt checksum and records a separate result set, preserving the original failed artifacts

Proof: `fixture-repair-proof.json`. Final revised CLI results and eventual AFTER comparisons remain the qualification worker's responsibility. They must use the same revised prose/evidence, retain all original failures, require all 15 missing-binding probes to fail, and compare unchanged negatives and retrieval fields. Do not present these source-aware exact-route diagnostics as organic recall, clean pre-core holdouts, or rendered spectral-gate verification.
