from pathlib import Path
import collections,hashlib,json
P=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
comparison=read(P/'comparison.json');revised=read(P/'revised-comparison.json');assert comparison['status']==revised['status']=='pass'
manifest=read(P/'manifest.json');assert all(sha(P/f)==h for f,h in manifest['input_hashes'].items())
for arm in ['before','after']:
 start=read(P/arm/'source-start.json');end=read(P/arm/'source-end.json');assert start['source_hashes']==end['source_hashes']
 r=read(P/arm/'report.json');assert len(r['cases'])==5 and all(x['exit_code']==0 for x in r['cases'])
 rev=read(P/('revised-'+arm)/'report.json');assert len(rev)==20 and all(x['status']==x['expected']for x in rev)
out=dict(status='PASS_BOUNDED_DATA_INSTRUCTION_CORRECTION',actual_public_cli_cases_per_arm=5,full_original_composition_audits_per_arm=20,full_revised_composition_audits_per_arm=20,source_tests=5,positive_and_no_target_scene_passes_per_arm=5,missing_duty_rejections_per_arm=15,original_fixture_label_failures_preserved=True,frozen_original_input_count=len(manifest['input_hashes']),all_frozen_inputs_unchanged=True,all_unrelated_pack_fields_unchanged=True,negative_packs_identical=True,original_and_revised_audit_outcomes_unchanged=True,source_hashes_stable_within_each_arm=True,comparison=comparison,revised_comparison=revised,provider_calls=0,images=0,limits=['Source-guided synthetic exact-route diagnostics, not blind clean-precore or organic recall.','Fix removes an instruction mismatch; unchanged text audits do not prove image quality or rendered acceptance.','Original OR evidence anchors are deliberately unchanged.'])
(P/'FINAL-SUMMARY.json').write_text(json.dumps(out,indent=2)+'\n')
files=[f for f in P.rglob('*')if f.is_file() and f.name not in ['artifact-manifest.json']]
(P/'artifact-manifest.json').write_text(json.dumps({str(f.relative_to(P)):sha(f)for f in sorted(files)},indent=2)+'\n');print(json.dumps(out,indent=2))
