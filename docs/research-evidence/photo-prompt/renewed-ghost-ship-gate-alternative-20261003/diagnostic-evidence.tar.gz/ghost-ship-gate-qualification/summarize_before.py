from pathlib import Path
import collections,hashlib,json
P=Path(__file__).resolve().parent
r=json.loads((P/'before/report.json').read_text());rev=json.loads((P/'revised-before/report.json').read_text());man=json.loads((P/'manifest.json').read_text());a=json.loads((P/'before/source-start.json').read_text());b=json.loads((P/'before/source-end.json').read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert a['source_hashes']==b['source_hashes'];assert all(sha(P/f)==h for f,h in man['input_hashes'].items())
assert len(r['cases'])==5 and all(x['exit_code']==0 for x in r['cases'])
for c in r['cases']:assert ('ghost_ship_former_vessel_breach'in c['hard_profiles'])==(c['id']in ['translucency','absence','displacement'])
assert len(rev)==20 and all(x['status']==x['expected']for x in rev)
out=dict(status='BEFORE_QUALIFIED_NO_PRODUCTION_EDIT',cases=[dict(id=x['id'],exit_code=x['exit_code'],hard_profiles=x['hard_profiles'])for x in r['cases']],initial_composition_status_counts=dict(collections.Counter(x['status']for x in r['compositions'])),revised_composition_status_counts=dict(collections.Counter(x['status']for x in rev)),revised_positive_control_passes=5,missing_binding_rejections=15,frozen_inputs_unchanged=True,source_hashes_unchanged_across_run=True,source_review='../ghost-ship-gate-review/proof.json',after_executed=False,images=0,provider_calls=0)
(P/'BEFORE-SUMMARY.json').write_text(json.dumps(out,indent=2)+'\n')
files=[f for f in P.rglob('*')if f.is_file() and f.name not in ['artifact-manifest-before.json']]
(P/'artifact-manifest-before.json').write_text(json.dumps({str(f.relative_to(P)):sha(f)for f in sorted(files)},indent=2)+'\n')
print(json.dumps(out,indent=2))
