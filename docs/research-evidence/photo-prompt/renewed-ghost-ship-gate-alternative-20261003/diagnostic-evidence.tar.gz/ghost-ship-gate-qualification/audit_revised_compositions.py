"""Preserve original failures; revise only omitted required label, same text both arms."""
from pathlib import Path
import copy,hashlib,json,os,subprocess,sys
P=Path(__file__).resolve().parent;R=P.parent.parent/'image-prompt';S=R/'skills/photo-prompt-image-generator/scripts'
def read(p):return json.loads(p.read_text())
def dump(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def sha(b):return hashlib.sha256(b).hexdigest()
arm=sys.argv[1];assert arm in ['before','after'];out=P/('revised-'+arm);assert not out.exists()
original=read(P/'manifest.json');assert all(sha((P/f).read_bytes())==h for f,h in original['input_hashes'].items())
if arm=='before':
 assert not(P/'revised-compositions.json').exists()
 specs=read(P/'compositions.json')
 for t in specs:
  if t['bindings'] or t['kind']=='missing_binding':t['prompt']+=' This scene shows a ghost ship with former-vessel continuity breach.'
 dump(P/'revised-compositions.json',specs)
 dump(P/'composition-revision.json',dict(reason='Original full composition omitted the existing label_plus_definition required safe label. Append the exact required safe label to active-profile compositions only. No request, baseline core, evidence binding, source, retrieval or gate was changed.',change='This scene shows a ghost ship with former-vessel continuity breach.',revised_sha256=sha((P/'revised-compositions.json').read_bytes()),original_input_manifest_sha256=sha((P/'manifest.json').read_bytes()),original_failures_preserved=True))
else:assert sha((P/'revised-compositions.json').read_bytes())==read(P/'composition-revision.json')['revised_sha256']
specs=read(P/'revised-compositions.json');env={k:v for k,v in os.environ.items()if not any(t in k.upper()for t in ['API_KEY','TOKEN','SECRET','CREDENTIAL'])};env['PYTHONDONTWRITEBYTECODE']='1';report=[]
for t in specs:
 c=read(P/arm/'compositions'/t['id']/'composed.json');c['prompt_en']=t['prompt'];c['embodiment_review']['review']['prompt_sha256']=sha(t['prompt'].encode())
 dest=out/t['id'];dump(dest/'composed.json',c)
 cmd=[str(R/'.venv/bin/python'),str(S/'audit_composed_prompt.py'),'--pack',str(P/arm/t['case']/'pack.json'),'--composed',str(dest/'composed.json')]
 run=subprocess.run(cmd,cwd=R,env=env,capture_output=True,text=True,timeout=600);dump(dest/'cli.json',dict(command=cmd,exit_code=run.returncode,stdout=run.stdout,stderr=run.stderr));a=json.loads(run.stdout);dump(dest/'audit.json',a)
 report.append(dict(id=t['id'],case=t['case'],status=a['status'],expected=t['expected_'+arm],failures=a['failures'],warnings=a.get('warnings',[]),prompt_sha256=sha(t['prompt'].encode()),bindings_sha256=sha(json.dumps(t['bindings'],sort_keys=True).encode())))
 dump(out/'report.json',report);print(t['id'],a['status'],[(f.get('check'),f.get('field'))for f in a['failures']],flush=True)
assert all(x['status']==x['expected']for x in report),[(x['id'],x['status'],x['expected'])for x in report]
assert all(sha((P/f).read_bytes())==h for f,h in original['input_hashes'].items())
if arm=='after':
 before=read(P/'revised-before/report.json');assert before==report,'Full revised audit results differ'
 dump(P/'revised-comparison.json',dict(status='pass',composition_count=len(report),identical_prompt_evidence_results=True,original_public_inputs_unchanged=True))
