# Ghost-ship bounded-translucency gate qualification

## Decision scope

Propose exactly one gate-description change in the base registry profile `ghost_ship_former_vessel_breach`: add the already authored `translucency` branch to `vo_legend_ghost_ship_bounded_breach`. The definition, component, evidence, original absence/displacement alternatives, opaque physical hull, same-vessel identity, service residue, observable present anomaly and all exclusions are unchanged. See `proposal/patch.json`, before/after profiles and profile patch.

This is an instruction-consistency correction. Text audits do not judge whether generated spectral pixels satisfy a gate; no acceptance improvement or image-quality result is claimed. No production source was applied, no index regenerated, and no providers or image renderers called by this worker.

## Provenance

Fixtures are intentionally source-guided synthetic diagnostics, authored after reading the profile and source report. Required `requesting_user` and `agent_prepack` wire enums do not make them actual user requests or blind clean-precore cases. Public CLI inputs use runtime typed subject category `object`, while creative-controls context uses `nonhuman` and `no_people`. No optional candidate is selected or forced exposed.

Original research is frozen under `source-freeze/docs/research-evidence/photo-prompt/legend-visual-semantics-20260901/`. The research supports former-vessel identity and bounded observable breach; translucency itself is explicitly present in the existing authored definition, component and evidence. No external supernatural claim is asserted.

Baseline HEAD is `5bf8142304f484138474fff4af9b0660439fa331`; manifest records concurrent pre-existing photo-era/index/slide-test pending changes. The base registry is unchanged. Full source hashes, frozen source bytes, public inputs and compositions are in `manifest.json` and `source-freeze/`; do not call this a clean working-tree baseline.

## Qualification

- Five source/materializer tests passed in `proposal-tests.log`
- Five candidate-free preflight cases passed
- Five actual normal V6 CLI BEFORE packs succeeded
- Bounded translucency, absence and displacement all hard-activate the target normally
- Opaque abandoned ship and wholly translucent vessel do not activate the target
- Target gates remain the current absence/displacement-only description in all three BEFORE packs
- All optional candidates are rejected in complete compositions
- Fifteen missing-binding probes cover each of five original duties in each positive branch

## Preserved initial composition failure and repair

The initial full positive compositions omitted the profile's required exact safe label, despite retaining its complete component definition. Initial full audits correctly fail `visual_obligation_runtime_expression`. Their full artifacts are preserved under `before/compositions/`, and original frozen public inputs and composition files remain unchanged.

`audit_revised_compositions.py` creates a separate frozen revised composition set, appending only: “This scene shows a ghost ship with former-vessel continuity breach.” It changes neither request nor baseline core, evidence, candidates, target selection, source contract or gate. Postcomposition prompt checksum is necessarily refreshed. The same revised prose/evidence is used for BEFORE and eventual AFTER. Negative no-target scenes are unchanged. Revised audit results are recorded independently, never substituted into the original failures.

## Reproduction and pending AFTER

From repository root:

1. `python ../daylong-progress-20261002/ghost-ship-gate-qualification/test_proposed_gate.py`
2. Existing frozen BEFORE must not be overwritten. Inspect `before/report.json` and `before.log`.
3. `python ../daylong-progress-20261002/ghost-ship-gate-qualification/audit_revised_compositions.py before` runs revised BEFORE once after original replay is complete.
4. Parent independently reviews and applies exactly the one-leaf proposal, updates index binding without changing retrieval document fields/vectors, and creates `AFTER-AUTHORIZED.json` acknowledging readiness.
5. `python ../daylong-progress-20261002/ghost-ship-gate-qualification/qualify.py after`
6. `python ../daylong-progress-20261002/ghost-ship-gate-qualification/compare_after.py`
7. `python ../daylong-progress-20261002/ghost-ship-gate-qualification/audit_revised_compositions.py after`

AFTER source readiness requires base registry equality to original plus precisely the proposed profile. Every other source hash except index must remain equal. Parent publication may change HEAD/status without invalidating identical source bytes. Comparison requires no differences except approved gate descriptions and valid derived pack ID, identical negative packs, unchanged original full-audit outcomes and evidence, and separately identical revised full audits.

Independent index/BM25F source proof is supplied separately under `../ghost-ship-gate-review/`. No source apply is authorized merely by generating these artifacts.

## Completed revised BEFORE result

All five complete revised scenes pass: bounded translucency, absence, displacement, opaque abandoned vessel and wholly translucent no-baseline vessel. All fifteen omitted-binding controls fail for the intended missing duty. No safe-label failures remain in the revised set. Original initial failure artifacts and all 52 original frozen hashes remain intact. See `revised-before/report.json`, `revised-before.log` and `BEFORE-SUMMARY.json`.

Independent review approved the exact gate proposal and exact separate label-only repair in `../ghost-ship-gate-review/REPORT.md`. Actual index helper proof confirms 1,510 visual texts/document fields/cached vectors plus all 9,739 general-index texts/document fields are unchanged. Only the visual-index registry fingerprint needs updating. AFTER has not been executed or source-applied by this worker.

## Completed authorized AFTER and exact comparison

The parent applied exactly the reviewed leaf and refreshed the registry-bound visual-index fingerprint with cached vectors; see `../ghost-ship-gate-integration/verification.json`. AFTER used the same 52 frozen inputs. All five actual public CLI cases succeeded with the same hard activation and candidate routing. The three positive packs differ only at the approved gate description and their valid derived pack ID; both no-target negative packs are identical. No candidate, core, retrieval, evidence, threshold, gate identity/count or other contract field changes. `comparison.json` checks the complete pack objects and unchanged original audit outcomes.

All twenty revised AFTER full-composition audits match revised BEFORE exactly: five complete-scene passes and fifteen missing-binding failures with the same warnings and evidence. `revised-comparison.json` verifies identical prose/evidence/results and preserved original input hashes. All twenty original full-audit outcomes are also unchanged, including the preserved omission failures. Source hashes stayed stable within each arm.

This is a completed bounded instruction-contract correction, not an automated acceptance or image-quality improvement. Zero provider calls and zero rendered images. The source-guided exact-route diagnostic scope remains as disclosed above.
