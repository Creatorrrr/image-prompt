"""Independent source-contract qualification, no production edit or providers."""
import copy,json,sys,unittest
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parent.parent/'image-prompt'
sys.dont_write_bytecode=True
sys.path.insert(0,str(R/'skills/photo-prompt-image-generator/scripts'))
import prompt_generator as pg
PID='ghost_ship_former_vessel_breach';GID='vo_legend_ghost_ship_bounded_breach'
old=json.loads((P/'proposal/before-profile.json').read_text());new=json.loads((P/'proposal/after-profile.json').read_text())
def gate(p):return next(x for x in p['render_gates']if x['id']==GID)
class GateProposal(unittest.TestCase):
 def test_current_branch_contradiction(self):
  self.assertIn('translucency',old['semantics']['definition'])
  c=next(c for c in old['semantics']['component_semantics']['groups']if c['id']=='bounded_spectral_breach')
  self.assertIn('translucent',c['any_terms'][0]);self.assertIn('translucent',old['evidence_requirements']['spectral_breach_phrase']['must_mention_any'][0]);self.assertNotIn('transluc',gate(old)['description'])
 def test_proposal_recovers_all_original_branches(self):
  for branch in ['translucency','absence','displacement']:self.assertIn(branch,gate(new)['description'])
 def test_exact_one_leaf_only(self):
  expected=copy.deepcopy(old);gate(expected)['description']='One bounded connected region breaks into spectral translucency, absence, or displacement.'
  self.assertEqual(expected,new)
 def test_boundary_and_gate_identity_preservation(self):
  for key in ['activation','semantics','composition_instruction','required_evidence_fields','evidence_requirements','reject_substitutes','concept_candidate']:self.assertEqual(old[key],new[key])
  self.assertEqual(len(old['render_gates']),5);self.assertEqual(len(new['render_gates']),5)
  self.assertEqual([(x['id'],x['review_scale'])for x in old['render_gates']],[(x['id'],x['review_scale'])for x in new['render_gates']])
  self.assertIn('fully_translucent_boat',new['reject_substitutes'])
 def test_actual_materializer_preserves_proposal(self):
  reg=pg.load_visual_obligation_registry(R/'skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations.json')
  req=json.loads((P/'inputs/translucency/spec.json').read_text())['request']
  rows=[dict(source='concept_lock',text=req,polarity='required',priority='critical',mandatory=True)]
  self.assertIn(PID,pg.candidate_pack_auto_visual_obligation_matches(reg,rows))
  for p in [old,new]:
   o=pg.candidate_pack_visual_profile_obligation(p,reg,activation_source='explicit_request_semantics',source_intent_ids=['synthetic-source-audit'],request_text=req,context_text=req)
   self.assertEqual(gate(o),gate(p));self.assertEqual(o['evidence_requirements'],p['evidence_requirements'])
if __name__=='__main__':unittest.main(verbosity=2)
