"""Verify actual normal CLI before/after: only approved gate text and derived pack ID."""
import copy,hashlib,json,sys
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parent.parent/'image-prompt';sys.path.insert(0,str(R/'skills/photo-prompt-image-generator/scripts'))
import prompt_generator as pg
PID='ghost_ship_former_vessel_breach';GID='vo_legend_ghost_ship_bounded_breach';OLD='One bounded connected region breaks into spectral absence or displacement.';NEW='One bounded connected region breaks into spectral translucency, absence, or displacement.'
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def diffs(a,b,path=''):
 if type(a)!=type(b):return [path]
 if isinstance(a,dict):return [q for k in a.keys()|b.keys() for q in ([path+'/'+k]if k not in a or k not in b else diffs(a[k],b[k],path+'/'+k))]
 if isinstance(a,list):return [path+'/length']if len(a)!=len(b)else[q for i,(x,y)in enumerate(zip(a,b))for q in diffs(x,y,path+'/'+str(i))]
 return []if a==b else[path]
rows=[];man=read(P/'manifest.json')
for case in man['case_ids']:
 a=read(P/'before'/case/'pack.json')[0];b=read(P/'after'/case/'pack.json')[0]
 delta=diffs(a,b);changes=[]
 for path in delta:
  parts=path.strip('/').split('/');cur=a
  for part in parts[:-1]:cur=cur[int(part)]if isinstance(cur,list)else cur[part]
  key=int(parts[-1])if isinstance(cur,list)else parts[-1]
  if path=='/pack_id':continue
  assert key=='description'and cur.get('id')==GID and cur[key]==OLD,('Unexpected pack difference',case,path)
  other=b
  for part in parts:other=other[int(part)]if isinstance(other,list)else other[part]
  assert other==NEW
  changes.append(path)
 assert bool(changes)==(case in ['translucency','absence','displacement']),(case,changes)
 assert pg.candidate_pack_recompute_id(copy.deepcopy(b))['pack_id']==b['pack_id'],('Invalid derived pack ID',case)
 # Pack ID is content-derived; all other deltas are independently constrained above.
 rows.append(dict(case=case,changed_paths=delta,gate_paths=changes,negative_pack_identical=a==b))
ra=read(P/'before/report.json');rb=read(P/'after/report.json');by={r['id']:r for r in rb['compositions']}
for x in ra['compositions']:
 y=by[x['id']]
 for key in ['status','failures','direct_visual_failures','warnings','target_contract_status','chosen_candidate_ids','chosen_visual_concept_ids','effective_profile_ids','effective_gate_ids']:assert x[key]==y[key],(x['id'],key)
 for f in ['prompt_en','visual_obligation_evidence']:
  ac=read(P/'before/compositions'/x['id']/'composed.json');bc=read(P/'after/compositions'/x['id']/'composed.json');assert ac.get(f)==bc.get(f),(x['id'],f)
assert all(sha(P/f)==h for f,h in man['input_hashes'].items())
report=dict(status='pass',cases=rows,composition_count=len(by),unchanged_composition_outcomes=True,frozen_inputs_unchanged=True,scope='Actual CLI instruction-contract correction only; no improvement in textual audit acceptance or image quality claimed.')
(P/'comparison.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
