from pathlib import Path
P=Path(__file__).resolve().parent
src=(P.parent/'slide-thickness-qualification/qualify.py').read_text()
start=src.index('def preflight():')
functions=src[start:src.index("if __name__=='__main__':")]
a=functions.index('def freeze():');b=functions.index('def state(man):')
functions=functions[:a]+functions[b:]
functions=functions.replace("assert arm=='before','This task stops after BEFORE; no AFTER source/index readiness authorized'", "assert arm in ('before','after'); verify_source_arm(arm, man)")
functions=functions.replace("assert state(man)==dict(head=PIN,status='',source_hashes=man['source_hashes'])", "assert arm=='after' or state(man)['source_hashes']==man['source_hashes']")
functions=functions.replace("expected=t['expected_before']", "expected=t['expected_'+arm]")
functions=functions.replace('Preserve the frozen material scene and decline optional reinterpretation.','Preserve the frozen maritime scene and decline optional reinterpretation.')
functions=functions.replace('The one-object material scene is complete without optional augmentation.','The single-vessel maritime scene is complete without optional augmentation.')
header=src[:src.index('def prepare():')]
header=header.replace("PID='mounted_slide_transparency_object_relation';FIELD='film_edge_density_phrase';PIN='5bf8142304f484138474fff4af9b0660439fa331';SEED=1003", "PID='ghost_ship_former_vessel_breach';FIELD='spectral_breach_phrase';PIN='5bf8142304f484138474fff4af9b0660439fa331';SEED=1003")
header=header.replace("REVIEW=P.parent/'slide-thickness-review'", "REVIEW=P.parent/'ghost-ship-gate-review'")
header=header.replace('A one-object tabletop material study with no living actor, hands, body or bodily mechanism. Support, ownership and crop receive a separate textual coherence review; pixels are not verified.', 'A single-vessel maritime scene without living actors, hands or bodily mechanisms. Vessel continuity, bounded spectral region and water interaction receive textual coherence review; pixels are not verified.')
(P/'qualify.py').write_text(header+(P/'prepare.fragment').read_text()+functions+"\nif __name__=='__main__':\n action=sys.argv[1]\n if action=='prepare':prepare()\n elif action=='preflight':preflight()\n elif action=='freeze':freeze()\n else:run(action)\n")
