#!/usr/bin/env python3
"""Bounded source-aware synthetic V6 BEFORE qualification. Artifact writes only."""
from pathlib import Path
import copy, hashlib, json, os, subprocess, sys, time, traceback
sys.dont_write_bytecode=True
P=Path(__file__).resolve().parent;R=P.parent.parent/'image-prompt';S=R/'skills/photo-prompt-image-generator/scripts';A=S.parent/'assets';PRE=S.parent/'precore'
PID='ghost_ship_former_vessel_breach';FIELD='spectral_breach_phrase';PIN='5bf8142304f484138474fff4af9b0660439fa331';SEED=1003
REVIEW=P.parent/'ghost-ship-gate-review'
def sha(b):return hashlib.sha256(b).hexdigest()
def read(p):return json.loads(p.read_text())
def dump(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def git(*args):return subprocess.check_output(['git',*args],cwd=R,text=True).strip()
def utc():return subprocess.check_output(['date','-u','+%FT%TZ'],text=True).strip()
def modules():
 sys.path.insert(0,str(S));import prompt_generator as g;import audit_composed_prompt as audit
 return g,audit

def anchor(id,src,ev,dim,target=None,prop=None):
 x=dict(anchor_id=id,source_text=src,prompt_evidence=ev,dimension=dim)
 if prop:x.update(target=target,property=prop)
 return x

def embodiment(prompt,phase='agent_prepack'):
 return dict(contract_version='photo-embodiment-review/v1',provenance=phase,prompt_sha256=sha(prompt.encode()),scope='not_applicable',summary='A single-vessel maritime scene without living actors, hands or bodily mechanisms. Vessel continuity, bounded spectral region and water interaction receive textual coherence review; pixels are not verified.',checks={})

def prepare():
 assert not(P/'drafts').exists()
 reg=read(A/'photo_prompt_visual_obligations.json');old=next(x for x in reg['profiles']if x['id']==PID);new=copy.deepcopy(old)
 gate=next(x for x in new['render_gates']if x['id']=='vo_legend_ghost_ship_bounded_breach')
 assert gate['description']=='One bounded connected region breaks into spectral absence or displacement.'
 gate['description']='One bounded connected region breaks into spectral translucency, absence, or displacement.'
 dump(P/'proposal'/'before-profile.json',old);dump(P/'proposal'/'after-profile.json',new)
 dump(P/'proposal'/'patch.json',dict(file='skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations.json',profile_id=PID,gate_id=gate['id'],field='description',before='One bounded connected region breaks into spectral absence or displacement.',after=gate['description']))
 import difflib
 (P/'proposal'/'profile.patch').write_text(''.join(difflib.unified_diff(json.dumps(old,ensure_ascii=False,indent=2).splitlines(True),json.dumps(new,ensure_ascii=False,indent=2).splitlines(True),fromfile='before-profile.json',tofile='after-profile.json')))
 cases=[];templates=[]
 for branch in ['translucency','absence','displacement']:
  state={'translucency':'The bounded mid-hull section stays aligned and present but becomes spectrally translucent, revealing the sea through its connected planks','absence':'The bounded mid-hull section becomes spectrally absent, leaving a localized empty interval between the connected solid bow and stern','displacement':'The bounded mid-hull section becomes spectrally displaced sideways while its rigging retains an identifiable connection to the solid vessel'}[branch]
  ev={
   'vessel_identity_phrase':'One continuous hull rigging and deck arrangement identifies the same vessel across the solid bow, spectral middle and solid stern',
   'physical_hull_phrase':'A substantial connected portion remains opaque solid and water-interacting, with a weight-bearing bow and stern meeting the surrounding sea',
   FIELD:'One bounded connected region becomes translucent absent or spectrally displaced; '+state[0].lower()+state[1:],
   'service_residue_phrase':'Worn rigging cargo fittings or repair marks establish former operation, with abraded pulley fittings and repaired deck planks on this same ship',
   'present_anomaly_phrase':'A witness wake reflection or waterline visibly disagrees at the breach, with the sea contact line interrupted only beside that connected spectral middle'}
  sub='exactly one former working sailing vessel';con='A maritime spectral-continuity photograph';event='one bounded mid-hull region undergoes a spectral breach while the bow and stern remain physically solid';crop='One three-quarter view contains the complete ship, its rigging and the surrounding waterline'
  req='Photograph a former vessel breaking into spectral continuity. Show exactly one former working sailing vessel with a substantial solid bow and stern, connected rigging, worn pulley fittings and repaired deck planks. '+state+'. Show the waterline anomaly tied to that same region. '+crop+'. No people, crew or witness.'
  base=con+' shows '+sub+'. In this frame, '+event+'. '+' '.join(v+'.'for v in ev.values())+' '+crop+'. The vessel floats on a quiet open sea under soft overcast daylight. The remaining opaque portions support the deck and preserve the former working shape, while the local breach and its water interaction stay distinguishable within the same frame.'
  cases.append(dict(id=branch,request=req,baseline=base,subject=sub,concept=con,event=event,crop=crop,setting='a quiet open sea with the complete surrounding waterline visible',evidence=ev,profile=PID,route='exact',language='en',expected_before='pass',expected_after='pass',surface=state,light='Soft overcast daylight makes the solid hull and bounded spectral section readable'))
 for id,con,sub,event,surf in [
 ('abandoned_ship','A documentary maritime photograph','exactly one ordinary abandoned wooden vessel','an intact empty ship rests in calm water beneath light fog','The entire connected hull remains opaque and physically intact with ordinary service wear'),
 ('fully_translucent','A fantasy maritime photograph','exactly one wholly translucent fantasy vessel','the entire ship is evenly transparent from bow to stern','Every part of the hull and rigging is uniformly translucent, leaving no opaque weight-bearing hull region')]:
  crop='One three-quarter view includes the complete vessel and the surrounding calm sea';light='Soft overcast daylight separates the vessel from the distant water'
  req='Photograph '+sub+'. '+event+'. '+surf+'. '+crop+'. No people or crew.'
  base=con+' shows '+sub+'. In this frame, '+event+'. '+surf+'. '+crop+'. '+light+'. The complete outline occupies the center of a single continuous frame, with open water visible on both sides. The camera records this stated vessel condition without additional figures or a second boat.'
  cases.append(dict(id=id,request=req,baseline=base,subject=sub,concept=con,event=event,crop=crop,setting='a quiet open sea with the complete surrounding waterline visible',evidence={},profile=None,route='ordinary_control',language='en',expected_before='pass',expected_after='pass',surface=surf,light=light))
 catalog=read(PRE/'visual_feature_catalog.json');(P/'visual_feature_catalog.snapshot.json').write_bytes((PRE/'visual_feature_catalog.json').read_bytes())
 sys.path.insert(0,str(PRE));import creative_controls
 for c in cases:
  req=c['request'];base=c['baseline'];d=P/'drafts'/c['id']
  aa=[anchor('concept',req,c['concept'],'concept'),anchor('subject',req,c['subject'],'subject'),anchor('event',req,c['event'],'event'),anchor('count',req,c['subject'],'composition','vessel','count'),anchor('crop',req,c['crop'],'framing','photograph','complete_ship_and_waterline'),anchor('surface',req,c['surface'],'material','vessel','physical_spectral_state')]
  aa += [anchor('relation_'+str(i),req,v,'material','vessel',k)for i,(k,v)in enumerate(c['evidence'].items())]
  c['anchors']=aa
  env=dict(contract_version='photo-request-envelope/v1',provenance='requesting_user',request_id='synthetic-ghost-ship-'+c['id'],request_text=req,request_sha256=sha(req.encode()),active_spans=[dict(span_id='scene',start=0,end=len(req),text=req)])
  context=dict(subject_category='nonhuman',no_people=True,explicit_nonsexual=False);overrides=dict(sensual=0,fetish=0,creativity=0,surreal=0)
  ctl=creative_controls.resolve(req,overrides=overrides,context=context,seed=SEED)
  core=dict(contract_version='photo-authorial-core/v3',provenance='agent_prepack',source_request=req,creative_controls_sha256=ctl['canonical_sha256'],interpreted_intent='A source-aware synthetic single-vessel maritime photograph. Preserve the stated physical or spectral condition, complete vessel identity, count and sea relationship. Fictional spectral appearance does not claim that ghosts exist or that an actual historical event occurred.',subject=c['subject'],setting=c['setting'],event=c['event'],visual_priorities=[c['subject'],c['event'],c['surface']],baseline_prompt_en=base,user_definitions=[],interpretation_provenance=[dict(term='synthetic maritime scene request',source_text=req,basis='request_context',resolution='Show '+c['event']+' on '+c['subject']+' with the stated waterline and complete frame.',sources=[])],unresolved_ambiguities=[],user_exclusions=['people','crew'],runtime_forbidden_labels=[],intent_lock=dict(contract_version='photo-intent-lock/v2',priority='requesting_user',semantic_anchors=aa,locked_dimensions=['concept','subject','event'],open_dimensions=['setting','appearance','material','framing','composition','lighting','camera','color','atmosphere','relationship']),semantic_assertions=[dict(assertion_id='primary_subject',dimension='subject',polarity='required',source_span_ids=['scene'],affected_dimensions=['subject'],axes=dict(subject_category='object'),evidence=dict(subject_phrase=c['subject']))],request_lineage=None,style=dict(domain='general_photo',family='maritime vessel study',evidence=['complete vessel outline','readable hull and water interaction']),variation_key='ghost-ship-qualification-'+c['id'])
  selected=[]
  for cat,phrase in [('feature.subject',c['subject']),('feature.situation',c['event']),('feature.texture',c['surface']),('feature.lighting_direction',c['light']),('feature.framing',c['crop'])]:
   # Lighting is supplied as an open-dimension realization and must occur in baseline.
   if phrase not in base:base+=' '+phrase+'.';core['baseline_prompt_en']=base
   selected.append(dict(category_id=cat,basis='request_derived',source_span_ids=['scene'],source_text=None,derivation='A visible realization of the vessel condition and complete maritime scene in the active request.',reason='Preserve this visible aspect of the single-vessel scene.',baseline_evidence=phrase))
  feature=dict(contract_version='photo-precore-feature-selection/v1',request_id=env['request_id'],active_span_ids=['scene'],catalog_path='skills/photo-prompt-image-generator/precore/visual_feature_catalog.json',catalog_schema_version=catalog['schema_version'],catalog_sha256=sha((PRE/'visual_feature_catalog.json').read_bytes()),request_sha256=env['request_sha256'],baseline_prompt_sha256=sha(base.encode()),selected=selected)
  c['baseline']=base
  for n,x in [('envelope',env),('controls',ctl),('context',context),('overrides',overrides),('core',core),('review',embodiment(base)),('feature-selection',feature),('spec',c)]:dump(d/(n+'.json'),x)
  templates.append(dict(id=c['id'],case=c['id'],prompt=base,bindings=c['evidence'],expected_before='pass',expected_after='pass',kind='positive'if c['profile']else'ordinary_control',select_target_if_offered=False))
 for c in cases[:3]:
  for field in c['evidence']:
   ev=copy.deepcopy(c['evidence']);del ev[field]
   templates.append(dict(id=c['id']+'_missing_'+field,case=c['id'],prompt=c['baseline'],bindings=ev,expected_before='fail',expected_after='fail',kind='missing_binding',failure_field=field))
 dump(P/'compositions.draft.json',templates)
 dump(P/'qualification-scope.json',dict(synthetic_source_aware=True,clean_precore=False,organic_user_requests=False,natural_query_recall=False,images=0,provider_calls=0,wire_provenance_note='Required requesting_user and agent_prepack enums are synthetic fixture wire values; these are source-guided diagnostic cases, not actual user scene requests or blind clean-precore evaluation.',selection_policy='Reject all optional slot, creative and visual concept candidates; never force target exposure. Exact positives must obtain target through normal hard matching. Controls must not hard-activate target.',measurement='Gate-instruction consistency and preserved CLI contracts; no acceptance improvement expected because textual audits do not judge rendered spectral pixels. Full compositions deliberately keep unchanged original OR evidence anchors in both arms.',branches=['translucency','absence','displacement'],controls=['ordinary abandoned opaque ship','wholly translucent vessel without opaque baseline','each mandatory binding omitted separately for each positive']))
 print('Prepared',len(cases),'cases and',len(templates),'compositions')

def freeze():
 assert not(P/'manifest.json').exists()
 rows=preflight();assert all(x['status']=='pass'for x in rows)
 for f in(P/'drafts').rglob('*.json'):dump(P/'inputs'/f.relative_to(P/'drafts'),read(f))
 dump(P/'compositions.json',read(P/'compositions.draft.json'))
 files=sorted(set([*A.rglob('*.json'),*S.rglob('*.py'),*PRE.glob('*.*'),S.parent/'SKILL.md',S.parent/'references/composition-contract.md']))
 source_hashes={str(f.relative_to(R)):sha(f.read_bytes())for f in files if f.is_file()}
 for f in [A/'photo_prompt_visual_obligations.json',A/'photo_prompt_visual_profile_index.json',R/'docs/research-evidence/photo-prompt/legend-visual-semantics-20260901/source-research.md',R/'docs/research-evidence/photo-prompt/legend-visual-semantics-20260901/evidence.jsonl']:
  target=P/'source-freeze'/f.relative_to(R);target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(f.read_bytes())
 frozen=[*(P/'inputs').rglob('*.json'),*(P/'source-freeze').rglob('*'),*(P/'proposal').glob('*'),P/'compositions.json',P/'qualification-scope.json',P/'qualify.py',P/'visual_feature_catalog.snapshot.json']
 dump(P/'manifest.json',dict(baseline_head=git('rev-parse','HEAD'),baseline_status=git('status','--porcelain'),case_ids=sorted(d.name for d in(P/'inputs').iterdir()),source_hashes=source_hashes,input_hashes={str(f.relative_to(P)):sha(f.read_bytes())for f in frozen if f.is_file()},frozen_at_utc=utc()))
 print('Frozen',len(rows),'valid cases; qualified working-tree baseline recorded')

def verify_source_arm(arm,man):
 current=read(A/'photo_prompt_visual_obligations.json');old=read(P/'source-freeze'/'skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations.json')
 if arm=='before':assert current==old;return
 assert(P/'AFTER-AUTHORIZED.json').exists(),'Parent must authorize source/index readiness before AFTER'
 expected=copy.deepcopy(old);i=next(i for i,p in enumerate(expected['profiles'])if p['id']==PID);expected['profiles'][i]=read(P/'proposal'/'after-profile.json')
 assert current==expected,'Only the reviewed one-leaf base-registry edit may differ'
 for f,h in man['source_hashes'].items():
  if f.endswith(('photo_prompt_visual_obligations.json','photo_prompt_visual_profile_index.json')):continue
  assert sha((R/f).read_bytes())==h,'Unrelated source drift: '+f
def preflight():
 g,_=modules();out=P/'preflight'/('attempt-%02d'%(len(list((P/'preflight').glob('attempt-*')))+1));out.mkdir(parents=True)
 rows=[]
 for d in sorted((P/'drafts').iterdir()):
  for f in d.glob('*.json'):dump(out/d.name/f.name,read(f))
  row=dict(id=d.name)
  try:
   env=g.load_request_envelope_arg(str(d/'envelope.json'));ctl=read(d/'controls.json');core=g.load_authorial_core_arg(str(d/'core.json'),request_envelope=env,creative_control_snapshot=ctl);policy=g.photo_embodiment.build_policy(core,read(d/'review.json'))
   cmd=[str(R/'.venv/bin/python'),str(S/'validate_precore_feature_selection.py'),'--catalog',str(PRE/'visual_feature_catalog.json'),'--request-envelope',str(d/'envelope.json'),'--authorial-core',str(d/'core.json'),'--embodiment-review',str(d/'review.json'),'--selection',str(d/'feature-selection.json')]
   p=subprocess.run(cmd,cwd=R,capture_output=True,text=True);dump(out/d.name/'feature-cli.json',dict(command=cmd,exit_code=p.returncode,stdout=p.stdout,stderr=p.stderr));assert p.returncode==0,p.stdout+p.stderr
   row.update(status='pass',core_sha256=core['canonical_sha256'],lock_sha256=core['intent_lock']['canonical_sha256'],embodiment_policy=policy)
  except Exception as e:row.update(status='fail',error=str(e),traceback=traceback.format_exc())
  rows.append(row)
 dump(out/'report.json',rows);print(json.dumps([dict(id=x['id'],status=x['status'],error=x.get('error'))for x in rows],indent=2));return rows

def state(man):return dict(head=git('rev-parse','HEAD'),status=git('status','--porcelain'),source_hashes={f:sha((R/f).read_bytes())for f in man['source_hashes']})
def run(arm):
 g,audit=modules();man=read(P/'manifest.json');assert all(sha((P/f).read_bytes())==h for f,h in man['input_hashes'].items()),'Frozen-input drift'
 assert arm in ('before','after'); verify_source_arm(arm, man)
 assert not(P/arm).exists(),'Never overwrite a run';assert arm=='after' or state(man)['source_hashes']==man['source_hashes']
 out=P/arm;out.mkdir();dump(out/'source-start.json',state(man))
 env={k:v for k,v in os.environ.items()if not any(t in k.upper()for t in ['API_KEY','TOKEN','SECRET','CREDENTIAL'])};env['PYTHONDONTWRITEBYTECODE']='1'
 report=dict(arm=arm,started_at_utc=utc(),cases=[],compositions=[],scope='Actual public V6 CLI and complete composed-prompt CLI audits, source-aware synthetic fixtures, local deterministic retrieval only, zero provider calls or images.');packs={}
 for id in man['case_ids']:
  d=P/'inputs'/id;dest=out/id;dest.mkdir();cmd=[str(R/'.venv/bin/python'),str(S/'generate_photo_prompt.py'),'--seed',str(SEED)]
  for a,n in [('request-envelope','envelope'),('authorial-core','core'),('creative-controls','controls'),('embodiment-review','review')]:cmd+=['--'+a+'-json',str(d/(n+'.json'))]
  cmd+=['--output-file',str(dest/'pack.json')];start=time.monotonic();p=subprocess.run(cmd,cwd=R,env=env,capture_output=True,text=True,timeout=600);dump(dest/'cli.json',dict(command=cmd,exit_code=p.returncode,stdout=p.stdout,stderr=p.stderr,seconds=time.monotonic()-start));row=dict(id=id,exit_code=p.returncode,stderr=p.stderr)
  if p.returncode==0:
   pack=read(dest/'pack.json')[0];packs[id]=pack
   row.update(contract_version=pack.get('contract_version'),hard_profiles=[x['id']for x in pack.get('visual_obligations',{}).get('obligations',[])],optional_profiles=[dict(candidate_id=x['id'],profile_id=x.get('opt_in_contract',{}).get('obligation',{}).get('id'))for x in pack.get('visual_concept_candidates',{}).get('candidates',[])],slot_candidate_ids=[x['id']for b in pack['slots'].values()for x in b.get('candidates',[])],core_sha256=pack['authorial_core']['canonical_sha256'],lock_sha256=pack['authorial_core']['intent_lock']['canonical_sha256'],retrieval_sha256=pack['core_retrieval']['canonical_sha256'])
   cv=[str(R/'.venv/bin/python'),str(S/'compose_pack_view.py'),'--pack',str(dest/'pack.json'),'--output',str(dest/'composer-view.json')]
   v=subprocess.run(cv,cwd=R,env=env,capture_output=True,text=True);dump(dest/'view-cli.json',dict(command=cv,exit_code=v.returncode,stdout=v.stdout,stderr=v.stderr))
   candidates=[x for x in pack.get('visual_concept_candidates',{}).get('candidates',[])if x.get('opt_in_contract',{}).get('obligation',{}).get('id')==PID]
   dump(dest/'target-offers.json',candidates)
  report['cases'].append(row);dump(out/'report.json',report);print(arm,id,p.returncode,row.get('hard_profiles'),flush=True)
 for t in read(P/'compositions.json'):
  id=t['id'];case=t['case']
  if case not in packs:report['compositions'].append(dict(id=id,status='not_run_no_pack'));continue
  pack=packs[case];core=pack['authorial_core'];lock=core['intent_lock'];prompt=t['prompt'];spec=read(P/'inputs'/case/'spec.json');chosen=[]
  offers=[x for x in pack.get('visual_concept_candidates',{}).get('candidates',[])if x.get('opt_in_contract',{}).get('obligation',{}).get('id')==PID]
  if t.get('select_target_if_offered'):chosen=[x['id']for x in offers if x.get('applicability',{}).get('status','eligible')=='eligible']
  hard=PID in [x['id']for x in pack.get('visual_obligations',{}).get('obligations',[])];active=hard or bool(chosen)
  composed=dict(core_retrieval_sha256=pack['core_retrieval']['canonical_sha256'],pack_id=pack['pack_id'],prompt_en=prompt,negative_en=pack['negative_en'],chosen_candidate_ids=[],chosen_visual_concept_ids=chosen,composer='agent',candidate_interpretations=[],authorial_core_binding=dict(source_authorial_core_sha256=core['canonical_sha256'],source_intent_lock_sha256=lock['canonical_sha256'],preserved_anchor_ids=[a['anchor_id']for a in lock['semantic_anchors']],preserved_evidence=[],authorial_decisions=[]),semantic_clarification_decisions=[dict(clarification_id=r['id'],decision='applied'if r.get('required_in_final_prompt')else'rejected',rationale='Preserve the frozen maritime scene and decline optional reinterpretation.',prompt_evidence=lock['semantic_anchors'][0]['prompt_evidence'])for r in pack.get('semantic_clarification',{}).get('candidates',[])],creative_augmentation_brief=dict(decisions=[dict(candidate_id=r['id'],decision='rejected',rationale='The single-vessel maritime scene is complete without optional augmentation.')for r in pack.get('creative_augmentation',{}).get('candidates',[])]),embodiment_review=dict(source_contract_sha256=pack['embodiment_preflight']['canonical_sha256'],review=embodiment(prompt,'agent_postcomposition')))
  if active:composed['visual_obligation_evidence']={PID:t['bindings']}
  if pack.get('semantic_assertion_obligations'):
   composed['semantic_assertion_evidence']=dict(source_contract_sha256=pack['semantic_assertion_obligations']['canonical_sha256'],evidence={x['assertion_id']:x['evidence']for x in core['semantic_assertions']if x['polarity']=='required'and x['dimension']!='character_response'})
  dest=out/'compositions'/id;dump(dest/'composed.json',composed);direct=audit.audit_visual_obligations(pack,composed,prompt);effective,ef=audit.derive_effective_visual_obligation_contract(pack,composed)
  cmd=[str(R/'.venv/bin/python'),str(S/'audit_composed_prompt.py'),'--pack',str(out/case/'pack.json'),'--composed',str(dest/'composed.json')];p=subprocess.run(cmd,cwd=R,env=env,capture_output=True,text=True,timeout=600);dump(dest/'cli.json',dict(command=cmd,exit_code=p.returncode,stdout=p.stdout,stderr=p.stderr))
  try:result=json.loads(p.stdout)
  except Exception:result=dict(status='error',failures=[dict(reason=p.stderr)])
  dump(dest/'audit.json',result);dump(dest/'direct-visual.json',dict(failures=direct,effective_contract=effective,effective_contract_failures=ef))
  row=dict(id=id,case=case,kind=t['kind'],status=result['status'],expected=t['expected_'+arm],exit_code=p.returncode,failures=result['failures'],direct_visual_failures=direct,warnings=result.get('warnings',[]),target_contract_status='active'if active else'unavailable'if spec['profile']else'not_requested',chosen_candidate_ids=[],chosen_visual_concept_ids=chosen,effective_profile_ids=[x['id']for x in(effective or{}).get('obligations',[])],effective_gate_ids=(effective or{}).get('required_hard_gates',[]))
  report['compositions'].append(row);dump(out/'report.json',report);print(id,row['status'],row['target_contract_status'],[(f.get('check'),f.get('field'))for f in row['failures']],flush=True)
 reg=g.load_visual_obligation_registry(A/'photo_prompt_visual_obligations.json');profile=next(x for x in reg['profiles']if x['id']==PID);helpers=[]
 for t in read(P/'compositions.json'):
  if not t['bindings']:continue
  phrase=' '.join(t['bindings'].values());vi=dict(contract_version=g.VISUAL_INTENT_CONTRACT_VERSION,provenance='agent_prepack',obligations=[dict(profile_id=PID,source='explicit_user_requirement',scope='request_only',source_text=profile['activation']['exact_terms'][0],bindings=t['bindings'])])
  try:g.normalize_visual_intent(vi,reg);normalized=dict(ok=True)
  except Exception as e:normalized=dict(ok=False,error=str(e))
  helpers.append(dict(id=t['id'],component_match=g.candidate_pack_visual_component_match(profile,phrase),normalized=normalized))
 dump(out/'helper-boundaries.json',helpers);dump(out/'source-end.json',state(man));report['finished_at_utc']=utc();dump(out/'report.json',report)
 print('Finished',arm,'input drift:',any(sha((P/f).read_bytes())!=h for f,h in man['input_hashes'].items()),flush=True)

if __name__=='__main__':
 action=sys.argv[1]
 if action=='prepare':prepare()
 elif action=='preflight':preflight()
 elif action=='freeze':freeze()
 else:run(action)
