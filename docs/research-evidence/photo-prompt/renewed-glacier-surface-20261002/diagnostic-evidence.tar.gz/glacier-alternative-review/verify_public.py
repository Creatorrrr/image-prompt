import json,pathlib,hashlib
O=pathlib.Path(__file__).resolve().parent; P=O.parent/'glacier-surface-alternative-audit/public-cli'; R=pathlib.Path('REPOSITORY_ROOT')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def preserves(a,b):
 if isinstance(a,dict):return isinstance(b,dict) and all(k in b and preserves(v,b[k]) for k,v in a.items())
 if isinstance(a,list):return isinstance(b,list) and len(a)==len(b) and all(preserves(x,y) for x,y in zip(a,b))
 return a==b
f=json.loads((P/'frozen-input-manifest.json').read_text()); m=json.loads((P/'before/run-manifest.json').read_text()); assert len(m['cases'])==len(f)==6
assert m['head']=='dbfd897ce20b5c7c21456af2234ec140e42676a9'; assert m['status']==''
for name,h in m['hashes'].items():assert sha(R/name)==h
out=[]
for case,c in zip(f,m['cases']):
 assert case['case']==c['case']; assert c['exit_code']==0 and c['expected_target_status']
 for name,h in case['inputs'].items():assert sha(P/'inputs'/case['case']/name)==h
 pack=P/'before'/(case['case']+'-pack.json');assert sha(pack)==c['pack_sha256'];p=json.loads(pack.read_text())[0]
 core=json.loads((P/'inputs'/case['case']/'authorial-core.json').read_text());assert preserves(core,p['authorial_core'])
 obs=(p.get('visual_obligations') or {}).get('obligations',[]); targets=[x for x in obs if x['id']=='active_glacier_flow_valley_moraine_system'];assert bool(targets)==bool(case['target_profile'])
 if targets:assert targets[0]['composition_instruction']==json.loads((O.parent/'glacier-surface-alternative-audit/exact-leaves.json').read_text())[0]['before']
 out.append(dict(case=case['case'],pack_sha256=sha(pack),core_preserved=True,target_present=bool(targets)))
res=dict(frozen_source=m['head'],input_manifest_sha256=sha(P/'frozen-input-manifest.json'),run_manifest_sha256=sha(P/'before/run-manifest.json'),source_hashes_verified=True,cases=out)
(O/'public-before-verification.json').write_text(json.dumps(res,indent=2)+'\n');print(json.dumps(res,indent=2))
