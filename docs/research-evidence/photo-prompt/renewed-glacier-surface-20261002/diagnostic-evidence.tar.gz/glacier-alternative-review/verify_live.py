import json,subprocess,hashlib
from pathlib import Path
r=Path('REPOSITORY_ROOT');o=Path(__file__).parent
file='skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations.json'
base=json.loads(subprocess.check_output(['git','show','dbfd897c:'+file],cwd=r));live=json.loads((r/file).read_text())
changes=json.loads((o.parent/'glacier-surface-alternative-audit/exact-leaves.json').read_text())
for c in changes:
 p=next(p for p in base['profiles'] if p['id']==c['profile_id'])
 for k in c['path'][:-1]:p=p[k]
 assert p[c['path'][-1]]==c['before'];p[c['path'][-1]]=c['proposed']
assert base==live
oldpath=o.parent/'glacier-alternative-original-index.json';old=oldpath.read_bytes();idxfile='skills/photo-prompt-image-generator/assets/photo_prompt_visual_profile_index.json'
assert old==subprocess.check_output(['git','show','dbfd897c:'+idxfile],cwd=r)
a=json.loads(old);b=json.loads((r/idxfile).read_text())
def dif(x,y,p=()):
 if type(x)!=type(y):return [p]
 if isinstance(x,dict):
  assert x.keys()==y.keys(),p
  return sum((dif(x[k],y[k],p+(k,)) for k in x),[])
 if isinstance(x,list):
  assert len(x)==len(y),p
  return sum((dif(v,w,p+(i,)) for i,(v,w) in enumerate(zip(x,y))),[])
 return [] if x==y else [p]
diffs=dif(a,b);assert diffs==[('registry_sha256',)],diffs
import sys
sys.path.insert(0,str(r/'skills/photo-prompt-image-generator/scripts'))
import prompt_generator as pg
assert b['registry_sha256']==pg.visual_profile_registry_sha256(pg.load_visual_obligation_registry(r/file))
ext='skills/photo-prompt-image-generator/assets/photo_prompt_natural_environment_extension.json'
assert (r/ext).read_bytes()==subprocess.check_output(['git','show','dbfd897c:'+ext],cwd=r)
result={'base':'dbfd897ce20b5c7c21456af2234ec140e42676a9','exact_approved_registry_changes_only':True,'all_other_profiles_unchanged':True,'narrow_environment_candidate_file_unchanged':True,'original_index_byte_identical_to_base':True,'index_changed_paths':diffs,'original_index_sha256':hashlib.sha256(old).hexdigest(),'live_registry_sha256':b['registry_sha256'],'entry_count':len(b.get('entries',{}))}
(o/'live-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
