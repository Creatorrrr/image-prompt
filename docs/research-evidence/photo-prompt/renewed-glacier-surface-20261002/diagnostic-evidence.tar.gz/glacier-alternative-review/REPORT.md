# Independent glacier composition review

## Source-level decision

Approve the exact one-leaf proposal in `glacier-surface-alternative-audit/exact-leaves.json`, subject to the frozen public BEFORE evidence being complete before application and ordinary post-application replay/index validation. This approval is for authored consistency, not retrieval eligibility or rendered-image quality.

Independently verified source HEAD `dbfd897ce20b5c7c21456af2234ec140e42676a9`. Full profile and approved research-evidence record in scout provenance exactly equal the repository source. The definition requires directional structure generally; component semantics, surface evidence requirement, and native-scale surface-direction render gate explicitly permit crevasses, flow bands, or debris stripes. Existing composition alone adds a universal “continuous crevassed ice” requirement. The proposed composition repeats the gate’s allowed alternatives while preserving continuous ice, wide down-valley/oblique view, U-shaped trough, moraine, terminus meltwater and visible contacts.

## Independent execution

`verify.py` imports and invokes production `candidate_pack_visual_profile_obligation`, which compiles the visual profile before emitting the obligation. Exactly `/composition_instruction` differs in source profile and materialized obligation. All required groups, four-group minimum, evidence requirements, reject substitutes, gate identities/descriptions/scales, runtime expression and prompt binding are unchanged. Exact English and Korean routes still select this profile; broad English/Korean glacier, snowy mountain/frozen lake, isolated cave, and blue-ice texture controls do not newly select it. See `verification.json` for results, source hashes and full materialized before/proposed obligations.

## Corrected scope and provenance bounds

There are SIX crevasse-specific extension candidates, across aesthetic_trend, subject, action, location, surface_material and composition. The audit’s original count of seven was erroneous; scout acknowledged and corrected it. Every one remains unmodified and all six have explicit crevasse language. A chosen crevasse-specific candidate or explicit user crevasse request still commits to crevasses. The five candidate IDs in the research record are not an exhaustive inventory of the six extension records.

The approved research record is `natural_environment_usgs_glacial_landforms`, reviewed 2026-09-01, linked to https://www.usgs.gov/geology-and-ecology-of-national-parks/geology-glacier-national-park. This review establishes exact local provenance identity, not a fresh independent validation of that web page or glacier physics. The alternatives are already explicit in authored source. In particular, no claim that every crevasse follows flow direction is added.

Directional debris stripes do not replace the independently required margin moraine contact. Blank ice lacks directional evidence; an isolated cave, frozen lake, missing moraine, absent terminus/water, or flow-rate/mass-balance inference remains rejected. No eligibility or image-quality gain is claimed. No repository edits, providers, synthetic vectors or rendered images were used.

## Public replay

Independently validated all six frozen public BEFORE packs on dbfd897c against frozen input/output and source SHA256 hashes. All six exited 0; the three complete glacier variants contain the original composition instruction, and all three negative cases omit the glacier profile. Input core content is preserved (production adds canonical IDs, request binding and lock policy metadata). Input manifest SHA256: 09602eb9144d791d41594147dbd9eb6bb83759f85ce3937ffcfa689c59bbe34e. Run manifest SHA256: c6320c8e711b276fb4676c94838302e4d9bcc3a500bd0efc555b2676918fab91. See verify_public.py and public-before-verification.json. The BEFORE precondition is satisfied; the exact one-leaf proposal is approved for application, with post-application replay/index validation still required. No application was performed by this reviewer.

## Applied-change independent acceptance

The live registry equals baseline `dbfd897c` plus exactly the approved composition leaf. All other profiles and the complete natural-environment extension are unchanged. The saved original index is byte-identical to baseline; the live index differs only at `registry_sha256`, correctly recalculated from the production loader. All 1,496 entries, vectors, texts and BM25F data are identical. See `verify_live.py` / `live-verification.json`.

Independently compared all six AFTER packs against frozen BEFORE. Three positives differ only in the approved obligation composition and derived pack ID. The three negative packs are byte-identical. Frozen inputs remain hash-valid; core and slots remain unchanged. See `verify_after.py` / `after-verification.json`.

Independently reran all six AFTER full composition audit commands: all pass, each with three existing uncovered-intent/free-description warnings. Frozen full baseline text remains intact and BEFORE/AFTER composed prompt and evidence strings are identical. Explicit crevasse intent is preserved in the crevasse-positive case. The no-crevasse alternatives retain their branch and complete geometry. No narrow candidate is selected in these fixtures; they therefore do not demonstrate relaxation of a selected crevasse-specific candidate. All six authored narrow candidates remain unchanged and selecting one still commits to its crevasse details. See `verify_compositions.py` / `composition-verification.json` and individual stdout/stderr files.

Both BEFORE and AFTER full-composition audits pass: this is a composition-instruction consistency correction, not a measured change in eligibility, text-audit acceptance or image quality. Applied change approved. Reviewer made no source edits or provider calls. Untracked tests and unrelated query-coverage documentation observed during review are outside this data-leaf review scope.
