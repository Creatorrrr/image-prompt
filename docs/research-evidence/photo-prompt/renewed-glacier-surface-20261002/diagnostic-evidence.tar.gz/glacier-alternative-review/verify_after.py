import json,hashlib,copy
from pathlib import Path
O=Path(__file__).parent;P=O.parent/'glacier-surface-alternative-audit/public-cli'
manifest=json.loads((P/'frozen-input-manifest.json').read_text());m=json.loads((P/'after/run-manifest.json').read_text());assert len(m['cases'])==len(manifest)==6
leaf,=json.loads((P.parent/'exact-leaves.json').read_text());rows=[]
for f,c in zip(manifest,m['cases']):
 name=f['case'];assert name==c['case'] and c['exit_code']==0 and c['expected_target_status']
 for fname,h in f['inputs'].items():assert hashlib.sha256((P/'inputs'/name/fname).read_bytes()).hexdigest()==h
 bp=P/'before'/(name+'-pack.json');ap=P/'after'/(name+'-pack.json');assert hashlib.sha256(ap.read_bytes()).hexdigest()==c['pack_sha256']
 b=json.loads(bp.read_text())[0];a=json.loads(ap.read_text())[0];assert a['authorial_core']==b['authorial_core'] and a['slots']==b['slots']
 bo=(b.get('visual_obligations')or{}).get('obligations',[])
 for ob in bo:
  if ob['id']==leaf['profile_id']:assert ob['composition_instruction']==leaf['before'];ob['composition_instruction']=leaf['proposed']
 b['pack_id']=a['pack_id'];assert a==b,name
 if not f['target_profile']:assert ap.read_bytes()==bp.read_bytes()
 rows.append(dict(case=name,only_approved_obligation_leaf_changed=True,all_other_fields_unchanged_except_pack_id=True,core_and_slots_unchanged=True,negative_pack_byte_identical=ap.read_bytes()==bp.read_bytes() if not f['target_profile'] else None))
(O/'after-verification.json').write_text(json.dumps(rows,indent=2)+'\n');print('PASS six AFTER packs independently verified')
