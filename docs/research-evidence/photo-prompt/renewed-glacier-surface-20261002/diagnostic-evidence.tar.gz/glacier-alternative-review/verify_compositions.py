import json,subprocess,concurrent.futures
from pathlib import Path
O=Path(__file__).parent;P=O.parent/'glacier-surface-alternative-audit/public-cli';summary=json.loads((P/'after-compositions-final/summary.json').read_text());assert len(summary)==6

def check(row):
 name=row['case']; a=json.loads((P/'after-compositions-final'/f'{name}-composed.json').read_text());b=json.loads((P/'before-compositions-final'/f'{name}-composed.json').read_text());pack=json.loads((P/'after'/f'{name}-pack.json').read_text())[0]
 assert a['prompt_en']==b['prompt_en'];assert a['visual_obligation_evidence']==b['visual_obligation_evidence'];assert a['prompt_en'].startswith(pack['authorial_core']['baseline_prompt_en']);assert a['chosen_candidate_ids']==[]
 if name=='glacier-crevasses':assert 'The selected surface evidence is coherent crevasses' in a['prompt_en']
 if name in ['glacier-flow-bands','glacier-debris-stripes']:assert 'without visible crevasses' in a['prompt_en']
 run=subprocess.run(row['command'],capture_output=True,text=True,timeout=180);(O/f'{name}-independent-audit.stdout').write_text(run.stdout);(O/f'{name}-independent-audit.stderr').write_text(run.stderr)
 assert run.returncode==0,(name,run.stdout,run.stderr);res=json.loads(run.stdout);assert res['status']=='pass' and not res['failures']
 return dict(case=name,status=res['status'],warnings=res['warnings'],frozen_baseline_preserved=True,prompt_and_evidence_equal_before=True,no_narrow_candidate_selected=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as ex:rows=list(ex.map(check,summary))
(O/'composition-verification.json').write_text(json.dumps(rows,indent=2)+'\n');print('PASS: six independently rerun full composition audits; frozen baseline and identical before/after prompts/evidence; no narrow candidates selected')
