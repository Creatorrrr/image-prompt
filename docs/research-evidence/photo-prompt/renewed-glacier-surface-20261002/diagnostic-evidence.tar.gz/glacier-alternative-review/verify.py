import copy, hashlib, json, pathlib, subprocess, sys
R=pathlib.Path('REPOSITORY_ROOT'); O=pathlib.Path(__file__).resolve().parent; S=O.parent/'glacier-surface-alternative-audit'
sys.path.insert(0,str(R/'skills/photo-prompt-image-generator/scripts'))
import prompt_generator as pg
asset=R/'skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations.json'
raw=json.loads(asset.read_text()); reg=pg.load_visual_obligation_registry(asset)
pid='active_glacier_flow_valley_moraine_system'
p=next(x for x in reg['profiles'] if x['id']==pid)
leaf,=json.loads((S/'exact-leaves.json').read_text())
assert p['composition_instruction']==leaf['before']
prov=json.loads((S/'source-provenance.json').read_text()); assert prov['profile_before']==p
record=next(json.loads(l) for l in (R/'docs/research-evidence/photo-prompt/research_evidence.jsonl').read_text().splitlines() if json.loads(l).get('id')=='natural_environment_usgs_glacial_landforms'); assert record==prov['research_evidence']
extp=R/'skills/photo-prompt-image-generator/assets/photo_prompt_natural_environment_extension.json'; ext=json.loads(extp.read_text()); candidates={slot:[x for x in rows if 'glacier' in str(x)] for slot,rows in ext['slots'].items()}; candidates={k:v for k,v in candidates.items() if v}; assert candidates==prov['unchanged_narrow_candidates']
assert all('crevass' in json.dumps(x).lower() for rows in candidates.values() for x in rows)
after=copy.deepcopy(reg); pa=next(x for x in after['profiles'] if x['id']==pid); pa['composition_instruction']=leaf['proposed']
def delta(a,b,path=''):
 if isinstance(a,dict) and isinstance(b,dict):
  return sum([delta(a.get(k),b.get(k),path+'/'+k) for k in sorted(a.keys()|b.keys())],[])
 if isinstance(a,list) and isinstance(b,list) and len(a)==len(b):
  return sum([delta(x,y,path+'/'+str(i)) for i,(x,y) in enumerate(zip(a,b))],[])
 return [] if a==b else [path]
assert delta(p,pa)==['/composition_instruction']
ob=pg.candidate_pack_visual_profile_obligation(p,reg,activation_source='independent_review',source_intent_ids=[])
oa=pg.candidate_pack_visual_profile_obligation(pa,after,activation_source='independent_review',source_intent_ids=[])
assert delta(ob,oa)==['/composition_instruction']; assert oa['composition_instruction']==leaf['proposed']
cases=['active glacier flow landform','활동 빙하 유동 지형','glacier','빙하','snowy mountain above a frozen lake','an isolated blue ice cave with no valley or moraine relation','blue ice texture closeup']; routes=[]
for i,t in enumerate(cases):
 rows=[dict(source='concept_lock',text=t,polarity='required',priority='critical',mandatory=True)]
 b=sorted(pg.candidate_pack_auto_visual_obligation_matches(reg,rows)); a=sorted(pg.candidate_pack_auto_visual_obligation_matches(after,rows)); assert a==b; assert (pid in a)==(i<2); routes.append(dict(text=t,before=b,proposed=a))
res=dict(head=subprocess.check_output(['git','-C',str(R),'rev-parse','HEAD'],text=True).strip(),registry_sha256=hashlib.sha256(asset.read_bytes()).hexdigest(),extension_sha256=hashlib.sha256(extp.read_bytes()).hexdigest(),source_provenance_exact_match=True,narrow_candidate_count=sum(map(len,candidates.values())),narrow_candidate_ids=[x['id'] for rows in candidates.values() for x in rows],profile_delta=delta(p,pa),materialized_delta=delta(ob,oa),routes=routes,before=ob,proposed=oa)
(O/'verification.json').write_text(json.dumps(res,ensure_ascii=False,indent=2)+'\n'); print('PASS:',res['head'],'candidate count',res['narrow_candidate_count'],'one-leaf profile/materialized deltas; two exact and five negative routes unchanged')
