import copy,hashlib,json,subprocess,sys
from pathlib import Path
R=Path('REPOSITORY_ROOT');O=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'skills/photo-prompt-image-generator/scripts'))
import prompt_generator as pg
A=R/'skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations.json'
reg=pg.load_visual_obligation_registry(A);pid='active_glacier_flow_valley_moraine_system';p=next(p for p in reg['profiles'] if p['id']==pid)
new='Use a wide down-valley or oblique view that connects the U-shaped trough, continuous ice with crevasses, flow bands, or debris stripes providing a coherent down-valley surface direction, moraine debris, and terminus meltwater without hiding their contacts.'
after=copy.deepcopy(p);after['composition_instruction']=new
assert {k:v for k,v in p.items() if k!='composition_instruction'}=={k:v for k,v in after.items() if k!='composition_instruction'}
b=pg.candidate_pack_visual_profile_obligation(p,reg,activation_source='audit',source_intent_ids=[])
a=pg.candidate_pack_visual_profile_obligation(after,reg,activation_source='audit',source_intent_ids=[])
assert b['composition_instruction']==p['composition_instruction'] and a['composition_instruction']==new
assert {k:v for k,v in b.items() if k!='composition_instruction'}=={k:v for k,v in a.items() if k!='composition_instruction'}
r2=copy.deepcopy(reg);next(q for q in r2['profiles'] if q['id']==pid)['composition_instruction']=new
cases={'exact':'active glacier flow landform','broad':'glacier','broad_ko':'빙하','snowy_lake':'snowy mountain above a frozen blue lake','ice_cave':'an isolated blue ice cave with no valley or moraine relation','blue_ice':'blue ice texture closeup'}
controls={}
for name,text in cases.items():
 rows=[{'source':'concept_lock','text':text,'polarity':'required','priority':'critical','mandatory':True}]
 old=sorted(pg.candidate_pack_auto_visual_obligation_matches(reg,rows));actual=sorted(pg.candidate_pack_auto_visual_obligation_matches(r2,rows));assert old==actual
 assert (pid in actual)==(name=='exact'),(name,actual)
 controls[name]={'text':text,'before':old,'proposed':actual}
def save(n,v): (O/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
save('exact-leaves.json',[{'file':str(A.relative_to(R)),'profile_id':pid,'path':['composition_instruction'],'before':p['composition_instruction'],'proposed':new}])
save('materialization-proof.json',{'head':subprocess.check_output(['git','-C',str(R),'rev-parse','HEAD'],text=True).strip(),'source_sha256':hashlib.sha256(A.read_bytes()).hexdigest(),'before':b,'proposed':a,'unchanged_all_other_profile_fields':True,'unchanged_all_other_obligation_fields':True,'production_route_controls':controls})
source=next(json.loads(l) for l in (R/'docs/research-evidence/photo-prompt/research_evidence.jsonl').read_text().splitlines() if json.loads(l).get('id')=='natural_environment_usgs_glacial_landforms')
ext=json.loads((R/'skills/photo-prompt-image-generator/assets/photo_prompt_natural_environment_extension.json').read_text())
candidates={slot:[row for row in rows if 'glacier' in str(row)]for slot,rows in ext['slots'].items()};candidates={k:v for k,v in candidates.items() if v}
save('source-provenance.json',{'research_evidence':source,'profile_before':p,'unchanged_narrow_candidates':candidates})
print('PASS: one composition leaf survives actual materializer; all other profile/obligation fields unchanged; exact route and five negative controls identical; six crevasse-specific candidates preserved.')
