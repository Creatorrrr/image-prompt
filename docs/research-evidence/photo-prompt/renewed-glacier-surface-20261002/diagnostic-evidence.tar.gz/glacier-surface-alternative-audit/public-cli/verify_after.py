import hashlib,json
from pathlib import Path
D=Path(__file__).resolve().parent
manifest=json.loads((D/'frozen-input-manifest.json').read_text());results=[]
for r in manifest:
 n=r['case'];b=json.loads((D/'before'/f'{n}-pack.json').read_text())[0];a=json.loads((D/'after'/f'{n}-pack.json').read_text())[0]
 diff=json.loads((D/'after'/f'{n}-entire-pack-diff.json').read_text())
 allowed=[[0,'pack_id'],[0,'visual_obligations','obligations',0,'composition_instruction']] if r['target_profile'] else []
 assert [d['path']for d in diff]==allowed,(n,diff)
 for key in a:
  if key not in ['visual_obligations','pack_id']:assert a[key]==b[key],(n,key)
 bc=json.loads((D/'before-compositions-final'/f'{n}-composed.json').read_text());ac=json.loads((D/'after-compositions-final'/f'{n}-composed.json').read_text())
 assert bc['prompt_en']==ac['prompt_en'];assert bc['visual_obligation_evidence']==ac['visual_obligation_evidence'];assert bc['chosen_candidate_ids']==ac['chosen_candidate_ids']==[]
 for phase in ['before','after']:
  audit=json.loads((D/(phase+'-compositions-final')/f'{n}-audit.json').read_text());assert audit['status']=='pass' and not audit['failures'],(n,phase,audit)
 for f,h in r['inputs'].items():assert hashlib.sha256((D/'inputs'/n/f).read_bytes()).hexdigest()==h
 results.append({'case':n,'entire_pack_diff_paths':allowed,'all_other_pack_fields_equal_except_derived_pack_id':True,'identical_composed_prompt_and_evidence':True,'full_before_audit':'pass','full_after_audit':'pass','chosen_candidate_ids':[],'candidate_choice_note':'All optional candidates rejected to retain frozen scene; no narrow crevasse-specific candidate meaning was altered.'})
(D/'candidate-and-contract-invariants.json').write_text(json.dumps({'cases':results,'interpretation':'Composition wording consistency only; same scene/evidence already passes before. No text eligibility or image-quality gain claimed.'},indent=2)+'\n')
print('PASS: six full before/after composed audits; positive semantic changes limited to one composition instruction plus derived pack ID; negatives identical; all frozen inputs/core/candidates unchanged.')
