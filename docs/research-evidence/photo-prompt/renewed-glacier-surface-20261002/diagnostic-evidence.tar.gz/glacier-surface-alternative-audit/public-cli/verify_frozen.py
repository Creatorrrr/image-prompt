import hashlib,json,subprocess
from pathlib import Path
D=Path(__file__).resolve().parent;R=Path('REPOSITORY_ROOT')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
m=json.loads((D/'before/run-manifest.json').read_text());f=json.loads((D/'frozen-input-manifest.json').read_text());assert len(m['cases'])==len(f)==6
known={r['id'] for rows in json.loads((D.parent/'source-provenance.json').read_text())['unchanged_narrow_candidates'].values() for r in rows};assert len(known)==6
rows=[]
for c in m['cases']:
 p=D/'before'/(c['case']+'-pack.json');pack=json.loads(p.read_text())[0]
 original=json.loads((D/'inputs'/c['case']/'authorial-core.json').read_text())
 assert pack['authorial_core']['baseline_prompt_en']==original['baseline_prompt_en']
 exposed=[r for slot in pack['slots'].values() for r in slot.get('candidates',[]) if r.get('entry_id') in known]
 rows.append({'case':c['case'],'pack_sha256':sha(p),'exposed_narrow_candidates':exposed,'candidate_status':'Candidate exposure only; no optional candidate has been selected by this pack-generation run. If selected in later authored composition, preserve its crevasse-specific meaning.'})
for case in f:
 for n,h in case['inputs'].items():assert sha(D/'inputs'/case['case']/n)==h
assert all(sha(R/n)==h for n,h in m['hashes'].items())
assert not subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True)
result={'source_commit':m['head'],'source_hashes':m['hashes'],'frozen_inputs_manifest_sha256':sha(D/'frozen-input-manifest.json'),'run_manifest_sha256':sha(D/'before/run-manifest.json'),'six_narrow_source_candidates':sorted(known),'cases':rows,'no_source_edits':True,'only_pack_generation_not_render_or_composed_prompt_audit':True}
(D/'frozen-verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['source_commit','frozen_inputs_manifest_sha256','run_manifest_sha256']},indent=2))
