import json,hashlib
from pathlib import Path
D=Path(__file__).parent
m=json.loads((D/'before/run-manifest.json').read_text());rows=[]
for c in m['cases']:
 name=c['case'];p=D/'before'/(name+'-pack.json');pack=json.loads(p.read_text())[0];inp=json.loads((D/'inputs'/name/'authorial-core.json').read_text())
 keys=['source_request','baseline_prompt_en','subject','setting','event','visual_priorities','user_exclusions','variation_key']
 assert all(pack['authorial_core'][k]==inp[k]for k in keys)
 row={'case':name,'exit_code':c['exit_code'],'expected_target_status':c['expected_target_status'],'emitted_profile_ids':c['emitted_profile_ids'],'preserved_core_fields':keys,'pack_sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
 target=c['target_profile']
 if target:
  o=next(o for o in pack['visual_obligations']['obligations']if o['id']==target)
  row.update({'composition_instruction':o['composition_instruction'],'render_gates':o['render_gates'],'evidence_requirements':o['evidence_requirements']})
 rows.append(row)
summary={'baseline_commit':m['head'],'source_status_at_start':m['status'],'normal_cli_cases':len(rows),'all_exit_zero':all(r['exit_code']==0 for r in rows),'all_expected_target_status':all(r['expected_target_status']for r in rows),'no_providers_or_fabricated_vectors':True,'cases':rows}
(D/'before-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'cases':len(rows),'all_exit_zero':summary['all_exit_zero'],'all_expected_target_status':summary['all_expected_target_status'],'profiles':{r['case']:r['emitted_profile_ids']for r in rows}},indent=2))
