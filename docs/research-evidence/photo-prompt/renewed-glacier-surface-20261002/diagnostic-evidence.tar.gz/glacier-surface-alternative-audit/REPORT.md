# Glacier directional-surface alternative audit

## Recommendation: one composition leaf

High confidence source-internal consistency correction for `active_glacier_flow_valley_moraine_system`. Exact before/proposed strings are in `exact-leaves.json`. No repository edit was made by this audit. This is a composition alignment, not a retrieval improvement or claim of better rendered glaciers.

Current composition specifies `continuous crevassed ice`. In contrast:
- Definition requires a continuous ice body with directional surface structure
- Directional-surface component expressly permits crevasses, flow bands or debris stripes
- `glacier_flow_surface_phrase` evidence requirement repeats that same alternative
- `vo_natural_glacier_surface_direction` gate expressly permits crevasses, flow bands, or debris stripes

Thus this profile is not globally authored as crevasse-only. The narrow candidates are distinct: all six glacier candidates found in the natural-environment extension explicitly retain crevasses in one or more authored fields. Keep every one of those records unchanged. Selecting one remains a crevasse commitment. This proposal does not authorize a no-crevasse rewrite of those selected candidates or a request explicitly specifying crevasses.

Proposed composition:

Use a wide down-valley or oblique view that connects the U-shaped trough, continuous ice with crevasses, flow bands, or debris stripes providing a coherent down-valley surface direction, moraine debris, and terminus meltwater without hiding their contacts.

The wording repeats the existing render gate's directional requirement. It preserves the wide down-valley/oblique framing, continuous ice, U-shaped valley, moraine, terminus water and visible contacts. No alternative landform, scientific inference or new physical permission is added.

## Actual consumer verification

`probe.py` calls production `candidate_pack_visual_profile_obligation` in `scripts/prompt_generator.py:7337` for the original and in-memory proposed profile. It asserts that only `composition_instruction` changes in both the source profile and emitted obligation. All component groups/cardinality, evidence fields/requirements, gates/IDs/scales, reject substitutes, runtime expression and prompt binding remain byte-equivalent at the parsed-data level. The instruction survives actual compilation; there is no component override discarding it.

The probe also runs production `candidate_pack_auto_visual_obligation_matches` on both registries: exact `active glacier flow landform` route remains selected, while `glacier`, `빙하`, snowy mountain/frozen lake, isolated ice cave and blue ice texture controls do not newly activate the profile. Results are in `materialization-proof.json`. These route tests are not substitute image judgments.

## Frozen semantic controls for future public replay

1. Existing positive: continuous valley glacier with coherent crevasse structure, margin moraine contact and distinct terminus feeding meltwater. Both versions preserve this branch
2. Alternative positive: identical valley/ice/moraine/terminus geometry; coherent down-valley flow bands provide directional evidence without visible crevasses. Definition/component/evidence/gate already permit this; current composition introduces crevasses, proposed composition no longer does
3. Alternative positive: same complete connected system with directional debris stripes as surface evidence; margin moraine still independently required. Same before/proposed distinction
4. Missing directional surface evidence: undifferentiated ice, even with valley/moraine/terminus, remains insufficient for the surface gate
5. Missing margin contact or terminus/meltwater: striped ice alone remains insufficient; existing reject `ice_body_without_moraine_or_terminus` preserved
6. Snowy mountain, frozen lake and isolated blue ice cave remain substitutes, not accepted complete systems
7. Visible surface pattern cannot establish flow rate, age or mass balance; non-inference gate and rejection remain unchanged
8. Selected narrow source: when the authored crevasse-specific glacier subject, action, surface, aesthetic, location or frame candidate is selected, do not delete crevasses under this proposal

These are semantic expectations grounded in authored source, not executed render outcomes or claims of changed eligibility. No fake vectors, paid providers, generated images or fabricated image reviews were used.

## Provenance and bounds

`source-provenance.json` preserves the full original profile, approved research record `natural_environment_usgs_glacial_landforms`, and six unchanged narrow candidates. The record links USGS Geology of Glacier National Park, reviewed 2026-09-01. Its approved abstraction concerns connected ice/surface direction/moraine/terminus and non-inference limitations. The alternative itself is established by the already-authored component/evidence/gate; this audit did not independently re-research glacier physics or assert that all crevasses follow flow direction. No source provenance or physical geometry edits are proposed.

This is separate from pending wetland/dune changes and historical artifact limitations. Nothing here repairs or changes those artifacts. A later accepted application should refresh its derived profile index under the existing real-vector policy and perform the normal public replay before claiming end-to-end acceptance. No fake index was constructed for this audit.

## Completed baseline

Natural-environment unittest suite: 8 tests passed in 94.264 seconds (`baseline-tests.log`). The audit started on `7bc6d8bc` with the pending wetland/dune work present; that separate work was committed as `dbfd897c` during this read-only audit. Glacier proposal remains unapplied. The probe records its observed commit/source hash; final repository status was clean.

## Frozen normal public BEFORE run

Six normal four-input CLI cases completed on clean `dbfd897ce20b5c7c21456af2234ec140e42676a9`. Inputs freeze one common complete glacier geometry and vary only the surface case: crevasses, flow bands without visible crevasses, or debris stripes without visible crevasses. Negative cases cover snowy mountain/frozen lake, isolated blue ice cave and underspecified distant glacier. Every CLI call exited zero; all three complete systems emitted the glacier obligation, and none of the three negatives did. The positive emitted composition still mandates crevassed ice even when the preserved authorial core specifies flow bands/debris stripes without visible crevasses.

`public-cli/before/run-manifest.json` records exact commands, outputs, commit, source hashes and emitted contracts. `before-summary.json` verifies unchanged source request, baseline prompt, subject, setting, event, priorities, exclusions and variation key. `frozen-verification.json` rechecks input/source hashes and records narrow candidate exposure. Candidate exposure is not candidate selection: this run produces candidate packs, not final composed prompts or images. Later authors must preserve any explicitly selected crevasse-specific candidate meaning.

Hashes:
- Frozen input manifest: `09602eb9144d791d41594147dbd9eb6bb83759f85ce3937ffcfa689c59bbe34e`
- BEFORE run manifest: `c6320c8e711b276fb4676c94838302e4d9bcc3a500bd0efc555b2676918fab91`
- Frozen verification: `1e8608d71d2346e27a70c49fa489f395afa5ec1539f18e865a60774f1bcec8ed`

## Applied AFTER and full composed audits

After the parent applied the approved one-leaf correction and refreshed the index registry digest, `public-cli/run_phase.py after` reran the same six frozen inputs. Every CLI call exited zero. Exact recursive entire-pack comparison found:
- Three positive packs: only the composition instruction and derived pack ID changed
- Three negative packs: no changes anywhere
- All original core fields, source/evidence contracts, candidates, runtime label, gates and other pack fields unchanged

`candidate_pack_recompute_id` hashes the pack content, so the positive ID changes are expected consequences of the instruction leaf.

`audit_compositions_final.py before` and `audit_compositions_final.py after` ran the complete production `audit_composed_prompt.py` CLI for all six cases. All twelve audits passed. The exact same baseline-preserving prompts and branch-specific evidence were used before and after, with the required `active valley-glacier landform system` runtime label supplied from the outset. Positive flow-band/debris-stripe prompts explicitly preserve absence of visible crevasses. Every optional candidate was explicitly rejected rather than silently redefining any crevasse-specific candidate. Negative prompts remain frozen non-system scenes.

`verify_after.py` asserts unchanged frozen input hashes, identical before/after composed prompt/evidence, exact permitted pack diff paths, unchanged candidates and complete audit passes. Output: `public-cli/candidate-and-contract-invariants.json`.

This confirms composition wording consistency. The same original scenes/evidence already pass BEFORE; there is no eligibility gain, rendered quality claim or image validation. No source edits were performed by this worker and no providers were called.
