"""Re-execute only modules whose exploratory source snapshot changed."""
from concurrent.futures import ThreadPoolExecutor, as_completed
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

root = Path('/workspace/image-prompt')
scratch = Path('/workspace/upward-verification')
out = scratch / 'final-source-rerun'
out.mkdir(exist_ok=True)
modules = json.loads((scratch / 'rerun-modules.json').read_text())
runner = root / 'docs/research-evidence/photo-prompt/retrieval-runtime-improvement-20261003/run_tests.py'

def run(module):
    started = time.monotonic()
    log = out / (module + '.log')
    with log.open('w') as stream:
        p = subprocess.run([sys.executable, str(runner), '--repo', str(root), '--output', str(out), '--module', module],
                           cwd=root, stdout=stream, stderr=subprocess.STDOUT)
    return {'module': module, 'returncode': p.returncode, 'seconds': round(time.monotonic() - started, 3),
            'log_sha256': hashlib.sha256(log.read_bytes()).hexdigest()}

started = time.monotonic()
results = []
print('Final source rerun modules:', len(modules), flush=True)
with ThreadPoolExecutor(max_workers=4) as pool:
    futures = [pool.submit(run, m) for m in modules]
    for f in as_completed(futures):
        r = f.result()
        results.append(r)
        (out / 'progress.json').write_text(json.dumps(results, indent=2) + '\n')
        print(f"Completed {len(results)}/{len(modules)}: {r['module']} rc={r['returncode']}", flush=True)
(out / 'execution-summary.json').write_text(json.dumps({'module_count': len(modules), 'module_results': results,
    'wall_seconds': round(time.monotonic() - started, 3)}, indent=2) + '\n')
