# Pre-core observation coverage audit

## Decision

**KEEP the current catalog.** The inspected data supports a narrower finding of human-heavy illustrations and incompletely illustrated nonhuman contact/material change. It does not establish that a new category, scene menu, or larger catalog would improve photographic variety or lower overlap.

No repository file was edited. No runtime, authoring, routing, validator, test, or policy change is proposed for immediate adoption. A single conditional DATA-only example is recorded separately as an unqualified hypothesis, not a patch or recommendation to apply.

Any future proposal must first establish both **neutral semantic category fit** and **independent selection benefit**. Test convenience is not a reason to place a concept in the wrong category or change a preservation contract.

## Bounded scope and evidence identity

- Checkout: `REPOSITORY_ROOT`
- Inspected revision: `18a46eb413a40ace4eb7b8913755ff739ac5c3cb`
- Catalog: `skills/photo-prompt-image-generator/precore/visual_feature_catalog.json`
- Catalog SHA-256: `0517ab8503183d5cfa23647aa9158cdf72169ca49a9fd8e72d030a40e77d04c5`
- Primary evidence: complete current catalog, its validator source, current skill's access/selection/ownership instructions, maintenance catalog rules, source-preservation and isolation test source
- Supplemental context: repository `GOAL_PLAN.md` and original catalog design document `docs/analysis/2026-09-24-photo-precore-45-feature-catalog-plan.md`; these are maintenance context, never legal pre-core authoring inputs
- No AGENTS.md was found in the checkout or checked parent locations. Relevant `.agents/skills` entry points to the current photo skill
- `source-audit.json` contains the category inventory, line locations, current-source hashes, counts, exact duplicates, and bounded in-memory structural probes

Scope limitation: an initial broad reference search returned historical artifact filenames, and the historical design document/goal plan included embedded old verification summaries. No named holdout, candidate-pack, image-attempt, or qualification-result artifact was opened. Those embedded historical summaries do not support the coverage conclusions or any quality claim. This auditor has seen maintenance/test context and must not act as a clean independent pre-core author in a subsequent comparison.

No original source conversation was reread. The 45-row source-preservation claim was checked against the current repository's frozen source digest; this is not an independent transcription audit against that conversation.

## Actual categories and examples

The current catalog has **48 categories: 45 preserved source categories and 3 marked additions**. There are **527 source examples and 11 added examples**. All original rows have empty `added_examples`; the 11 added examples belong to Primary Object, In-frame Text, and Format and Aspect Ratio.

Groups are 8 meaning/event, 8 subject/embodiment, 6 place/traces, and 26 delivery/technique. The technique majority is an inventory fact, not measured selection bias. Current instructions already prioritize event, subject, setting, and visible consequence; a technique-majority selection emits a review warning rather than a hard rejection.

### Nonhuman subjects: real illustration gap, no proven generation limit

`feature.subject` (catalog line 139) is English “Subject” but Korean “인물” and its actual examples are explicitly people: person count, age presentation, body proportions, skin, hair, makeup, protagonist/support/background people, and distance between people. `feature.interaction` (163) is Korean “인물 관계” and gives interpersonal looks, conversation, hand-holding, leaning, exchange, and social distance. Pose, Hand Gesture, Gaze, Facial Expression, and Clothing similarly carry person-centered illustrations.

`feature.primary_object` (982) expressly fills the gap between human Subject and supporting Props. Its five examples cover primary object's kind/count, shape/outline, material/surface state, use/function, and size/distance relative to adjacent objects. This already supplies a legitimate object-led axis. It should not be silently repurposed as a living-organism taxonomy.

Animals and plants have no clearly dedicated primary-subject illustration in these rows. Trees/flowers do appear as environment/prop context, which is different from expressing a living nonhuman subject's own visible identity/state. That is a source-visible illustration gap. It does **not** show that a valid animal/botanical baseline cannot be authored: the skill permits independent reasoning and does not require copying an example. Do not rename the original human Subject, force a person into an image, or invent another category solely to reach five selected axes.

### Object-centered scenes: substantial coverage already exists

Primary Object's shape/material/state and inter-object distance combine with Location, Background, Spatial Depth, Atmosphere, and existing photographic dimensions. Props (360) already covers tools, food, instruments, flowers, and supporting objects. A static product/still-life request is not missing a catalog route, and “more actions” would not be an improvement for an intentionally still request.

The original Subject/Props distinction and the added Primary Object's reason should remain intact: primary subject state, supporting object role, and relational event are not interchangeable labels for the same visual decision.

### Action/contact: illustrated narrowly but not absent

Action (184) contains mostly human everyday acts, including working, cooking, opening a door, movement caught mid-action, and secondary hand/hair/clothing movement. Interaction includes exchanging objects and touch. Narrative Context (22) already includes “사건의 원인과 결과” (cause and consequence), and Situation (5) includes actions underway, actions finished, and stationary moments. Motion (690) includes frozen movement, blur, water droplets, and vehicle traces, but belongs to delivery/technique; it should not substitute for the meaning of an event.

What is less explicit is an object's visible contact relation and local material response: an actual contact point, contacting surfaces, and locally compressed/bent shape. This is a difference in illustrative concreteness, not evidence for a missing “contact scene” category. Action, participant relationship, material state, and photographic motion can overlap; selecting them must describe genuinely different observations rather than recounting one decision several times.

### Environmental consequences: already represented

Atmosphere (79) directly covers a wet street after rain, melting snow, dust, smoke, vapor, and visually felt heat/cold. Environmental Details (119) covers water/dust/scratches on surfaces and traces of use. Narrative Clues (938) includes a wet umbrella suggesting rain and physical states suggesting earlier activity. Realism Cues (797) includes gravity, reflections, consistent shadows, material realism, and use traces. Narrative Context already supplies causal context.

Human use/interior detail dominates the specific trace examples, while erosion, flowing material, or deformation are not illustrated explicitly. Nevertheless, adding a general “environment consequence” category would heavily duplicate existing scope. Background scenery is not automatically a causal consequence, and an asserted invisible cause is not itself an observable cue.

### Overlap and catalog size

Five exact example strings occur in two categories: tension, bag, clothing wrinkles, lifted blacks, and deep focus. Their original source membership must be preserved. Exact duplication is not a full semantic-overlap measure, but it shows why adding categories or examples by count is a poor objective. Several neighboring axes also naturally overlap at the concept level, including event/context/clues and focus/lens/depth.

The low-overlap goal is best tested on independent scene decisions and actual observable consequences within the request's open scope. Lexical variation or selecting more category IDs is not scene diversity.

## Actual consumer and validator contract

Current `SKILL.md` lines 23–37, 82–107, and 281–321 establish:

1. Resolve requester meaning first. Choose the whole-image artistic direction before consulting the catalog. Only the exact catalog and named candidate-free controls/procedure are available before the initial core.
2. Choose 5–10 distinct observation categories, counting what the requester already specified. Examples are optional and cannot authorize new people, actions, defects, styles, or recipes.
3. Category selection cannot create requester definitions, hard anchors, assertions, visual intent, or close open dimensions. Preserve all requester requirements regardless of selected-category count.
4. Freeze the independent baseline/core first. Then finish and validate the hash-bound selection record before candidate access. The record is audit evidence only, not generator/retrieval input or a retry obligation.
5. Preserve byte-identical catalog snapshots for historical verification, never as another request's pre-core input.

The validator enforces schema, stable unique category IDs, the 45 original source numbers, marked addition provenance, per-row nonduplicate examples, source/addition nonoverlap, selection count, active-span/provenance fields, literal baseline evidence, hash bindings, and some ownership conflicts. It warns on repeated reasons/evidence and technique majority. It does **not** decide whether a category semantically fits, whether two different phrases express the same visual decision, whether an implied cause is visible, whether authoring really preceded retrieval, or whether a photograph is compelling.

The live CLI rejects catalog bytes that differ from the current canonical file; historical mode is for old-record verification, not permission to substitute experimental input during a live request.

Important maintenance constraint: `tests/test_photo_precore_feature_selection.py:226–265` hashes the entire original-row projection, including original rows' `added_examples`, and asserts exactly 48 rows / exactly the three current additions. Although the schema structurally accepts added examples on original rows, such a change fails this preservation assertion. That may be intentional and must not be bypassed casually.

## Minimal conditional DATA-only hypothesis

Current action remains **KEEP**. If independent evidence later isolates an object-state selection deficiency, inspect this possible single addition to `feature.primary_object.added_examples`:

> 접촉점에서 눌리거나 휘어진 형태와 맞닿은 면

English explanation: shape compressed or bent at the contact point, and the surfaces in contact.

Its only plausible fit here is **the primary object's observable local shape/surface state**. If the actual desired improvement is “what acts on what,” transfer, direction of force, living behavior, or environment-wide consequence, this belongs under an existing event/relationship/place concept instead and must **not** be moved into Primary Object to avoid a digest change. A contact point alone does not prove a specific cause.

Why this is bounded: no complete scene, location, actor, emotion, preset, candidate/profile ID, slot routing, numeric quota, mandatory contact, or subject-type trigger is supplied. It is positive observation language and keeps the existing category's ownership. It could also prove redundant with existing shape/material/state examples; independent benefit is required.

An in-memory structural probe confirms that this hypothetical append is schema-valid and preserves the current original-row digest. An in-memory append to original Action is also schema-valid but changes that digest. These are maintenance compatibility facts only; neither establishes semantic fit or improves a prompt. No proposed catalog file was written and no repository test was altered.

## Independent candidate-free test before adoption

This is a design, not an executed quality test.

1. A separate request designer, without exposure to the proposed wording, candidate assets, prior arms, or outcome files, preregisters fresh requests and review criteria. Cover requested object contact and visible consequence, static/precise objects, living nonhuman subjects, environment-only change, and an ordinary human control. These are evaluation strata only, not authoring menus or runtime routes. Include requests where damage/contact/motion would be wrong and sufficient explicit dimensions to expose quota padding.
2. Compare current A with a semantically reviewed minimal DATA-only B in separate clean contexts. Each author sees only the unchanged allowed skill/procedure, current request and references, bound controls/resolver, and its arm's exact catalog. The author cannot see the audit, proposed target rationale, maintenance references, tests, earlier outputs, other arm, or candidates. First resolve meaning and independently choose whole-image direction, then consult its catalog as the current skill requires.
3. Use an isolated experimental checkout per arm so its allowed canonical catalog is its exact assigned byte sequence. Do not use `--historical-catalog` to disguise an experimental live input. Retain all existing source/ownership/routing contracts. If a data variant requires changing a preservation test, pause for an explicit decision on that maintenance contract instead of weakening it for convenience.
4. Freeze each request envelope, creative controls, baseline/core, embodiment review, selected categories/reasons/evidence, catalog bytes, and hashes before any candidate exposure. A separate auditor may inspect validator code and validate after the core is frozen. Authoring access logs and isolation establish timing; hashes alone do not.
5. Blind review the frozen pre-core outputs against each request: meaning/negation/count/state preserved; coherent visible event or intentionally still state; required contact and consequence legible; agent choices remain optional; no invented human, unexplained cause, extra damage, contact, or motion. Review selection reasons for genuine nonoverlap and appropriate category fit, not merely unique text.
6. Check whether B actually improves a needed selection or visible realization and whether the same cue spreads into unrelated scenes. Compare scenario decisions and unnecessary repeated motifs, not word count, category count, keyword frequency, or cosmetic paraphrase. A broader scene must remain compatible with the actual request. Any category-fit failure, added requester lock, or unwanted scene addition disqualifies the proposal. No demonstrated benefit or only stylistic paraphrase means KEEP.
7. Stop at the frozen pre-core comparison for this hypothesis. No retrieval, image generation, existing holdout/result inspection, or paid calls are needed for this bounded test. It cannot establish rendered-image or downstream qualification uplift. Any later rendering or qualification is a separately authorized stage, with fresh independent material.

## Checks performed and limits

Performed: source inspection; actual-catalog schema validation; original-row digest comparison; category/example inventory; exact duplicate inventory; two in-memory hypothetical schema/digest probes. All were local and candidate-free.

Not run: generator-importing unit suites, registry/index overlap tests, independent authoring comparison, retrieval, images, live/archived qualification, paid services, external agents. Those omitted stages are not claimed to pass. The original catalog bytes and repository sources remain unchanged; preexisting unrelated worktree changes were preserved.
