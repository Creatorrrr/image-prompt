# Supported repair DATA gap review

Decision: **KEEP current DATA; no candidate proposal is frozen.**

This is not a claim that current retrieval or scene fidelity is complete. There is a bounded discovery weakness in the development probes, and the existing rows do not jointly author all repair topology. The evidence does not justify a new low-overlap candidate that is both minimal and honest about what it changes.

## Scope and provenance

- Repository: `REPOSITORY_ROOT`
- Permitted independent research: `daylong-progress-20261002/scene-diversity-research/development-families.md`, Family C only, C1–C3
- Its source S4 supplies only the general observation that visible hand/tool/open-device/loose-part contact can communicate active repair. Its robot/cyberpunk world is not adopted; no source popularity or model-performance claim is made
- Current runtime sources and instructions were inspected. No original research/holdouts, candidate proposals, qualification output, other audit conclusions, generated image attempts, or test fixtures were read
- No repository edit, remote write, provider/API call, runtime change, index regeneration, candidate injection, or retrieval tuning was made
- `inspected-source-rows.json` records exact relevant authored rows and their source-file hashes. `source-manifest.json` binds the current corpus/code used for the source inspection and development diagnostic

## Useful existing DATA and its limits

### Tool operation and contact

- `action:tool_contact_active_process_visible_result` (reactorprompt relations extension): an actor grips a tool in coherent target contact during unfinished work, with an immediate state/material result. Slot effect is `action`. This already covers the broad tool/process/result proposition
- `contact_point:hand_gripping_tool_handle` (research extension): functional full-hand grip around a tool/support handle. Slot effect is `relationship`. This supports grip, not component-to-receiver alignment
- `contact_point:pc_px06_component_2` (portrait-composition extension): nominated hand at a traceable object grip/support point. Explicit effect is `action`; its portrait ownership text must not be discarded when comparing it with a mechanical scene
- `narrative_phase:tool_contact_active_process_phase` and `narrative_phase:visible_mishap_repair_phase`: timing/process refinements. A mishap cannot be inferred merely because repair occurs; extraction is not automatically repair of a newly caused mishap

Together these rows can refine already-authored repair contact. They do not independently specify which loose component mates with which receiver or assign a second independent stabilizing contact.

### Support and photographic readability

- `contact_point:load_bearing_contact_deformation`: a readable force path and receiver deformation. It is not equivalent to all stabilization; a rigid caster mounting plate or a screw need not visibly deform
- `contact_point:pr_object_contact_shadow_support_candidate`: supported object contact and physically coherent local shadow. Useful for support plausibility, not a fastening operation
- `composition:crop_boundary_anchor_integrity`: keeps meaning-bearing anchors and their connections in frame
- `focus:subject_anchor_focus_plane_priority`: jointly readable meaning-bearing anchors and required topology
- `composition:product_surface_support_hierarchy`: product/support/secondary-prop hierarchy, but `for_any: [object]` means it is not an eligible shortcut for these adult-primary development scenes
- `composition:over_the_shoulder_workbench` and `composition:repair_bench_topdown`: particular view options, not proof of a support or fastening relation

A proposed “frame the support, tool tip, receiver and captured small parts together” would be a specific wording of the existing crop/focus/anchor-readable ideas when those elements already exist. If it creates the support, mates the loose part, seats a fastener, or moves scattered pieces into a holder, it changes scene action/relationships, not merely framing.

### Parts, work surfaces and nearby specialized scenes

- `prop:removed_suspect_component_tray` specifically holds only the removed suspect component beside an assessed product and requires `circular_materials` or `reuse_assessment` primary context. It cannot be silently relabeled as washers in a lid or a replacement hinge plate on cloth
- `prop:disassembly_tray_parts_prop` is robot parts, including panels/modules/actuators; a broad repair match is not semantic permission to use it for a book trolley
- `prop:machined_component_tray_prop` is freshly machined components, not removed repair hardware
- `prop:socket_wrench_prop` supplies a human-compatible wrench but does not seat it on a bolt or assign the other hand's role
- `prop:padded_object_support_prop` is a fitted support for a collection object's stable resting geometry, not a generic repair clamp
- `location:community_repair_bench` is explicitly electronics diagnosis. `location:garage_workbench` and `location:maker_space_workbench` provide other locations, not authorization to move a requested library/community-hall scene
- `action:ccx_repair_detached_cuff` explicitly holds a detached cuff edge while adjusting its attachment. This is a close relational analogue, but its cuff/costume meaning and `action`/`appearance` effects prevent treating it as a mechanical fastening synonym
- `action:character_pose_proxemics_scene_action` introduces a second person, panel support and tool handoff under a specific character-scene prerequisite. It does not cover one-person repair by analogy

The generic `prop` ownership list is empty in current DATA. Mere eligibility/exposure of an old prop row does not establish a complete effect declaration suitable for joint bundle adoption.

## Development scene comparison

### C1: trolley caster fastening

The operative scene-authoring relation is a loose caster held against its own mounting plate while the other hand tightens the connecting bolt. Washers are already contained in a nearby lid.

- Broad operation is covered by the tool-contact/process concept
- Support plausibility and visibility are covered by existing support/contact/crop/focus concepts, subject to their actual conditions
- The loose component ↔ mating receiver ↔ fastener continuity is not explicitly encoded by those rows as one atomic relation
- A new row that genuinely creates this state would be a supported-fastening action/relationship mechanism. Specifying different hand roles also affects pose; adding or rearranging a parts holder affects setting/relationships. Calling this only composition/framing would understate its effects
- Repeating that already-authored continuity as a visibility instruction offers high overlap rather than an established new capability

### C2: supported wheel thorn extraction

The wheel is removed and stabilized between the knees; tweezers remove a thorn. The bicycle's empty front-wheel position is a contextual consequence.

- It is not receiver attachment or bolt fastening
- The thorn is the extraction target, not a loose replacement component to seat
- A generalized fastening candidate would be wrong here. A generic stabilized tool operation reduces to existing tool/contact/support concepts plus authorial staging

### C3: hinge support with screw retrieval

The hinge is held steady while a magnetic tool retrieves a screw from a floorboard crack; a replacement hinge plate rests on cloth.

- Tool target is the fallen screw, not the held hinge or its receiver
- Capturing the screw by the magnet is distinct from a screw already installed in the hinge
- A row insisting on one shared tool/support/receiver target would corrupt this scene
- A row wide enough to encompass both this retrieval and C1 fastening loses the distinguishing relation and becomes a general repair/contact restatement

Therefore the Family C cases establish several authorial mechanisms, not one missing joint proposition that should be bundled into a new universal supported-repair candidate. A full scene recipe containing all mechanisms would exceed a minimal atomic addition.

## Current consumer-path diagnostic

`inspect_reachability.py` called the unchanged `retrieve_core_slots` function on three development-only typed field projections transcribed from C1–C3. It loaded the current merged authored slot corpus and quality policy. Zero candidate/index/provider changes were made.

Important limit: these are **lower-level retrieval diagnostics**, not independently pre-core-authored, normalized full request/embodiment/public-pack runs. Their manually bound diagnostic cores intentionally exercise the retrieval function only. They are not public qualification, holdout results, rendering evidence, or proof of full-pipeline behavior.

Observed in this one fixed probe:

- Each input exposed 64 ordinary candidates, reaching the total inventory cap
- `tool_contact_active_process_visible_result`, the examined grip/support contact rows, `crop_boundary_anchor_integrity`, and `subject_anchor_focus_plane_priority` were eligible but not exposed in all three probes
- Contact-point, focus, narrative-phase and procedure-step support inventories were absent after core slots consumed the cap
- The examined repair action/prop alternatives were also not selected into the capped same-slot inventory
- Domain-limited alternatives such as `removed_suspect_component_tray`, `padded_object_support_prop`, detached-cuff repair and the character support scene were ineligible under these projections
- Some semantically inappropriate broad candidates were eligible, including robot disassembly rows. Eligibility is an advisory filter, not a finding that a composer should adopt them

The exact inputs, controls, inventory IDs, targeted eligibility checks and retrieval bindings are saved in `development-reachability.json`. There was one diagnostic execution with no query revision or threshold changes.

This weakens any claim that “the existing relevant combination is currently offered to the consumer for C1–C3.” It does not establish that an additional DATA row will be useful, novel, correctly scoped, exposed, or visually better. Adding aliases or an opt-in row just to place the development wording into the front of the cap would confound DATA novelty with discovery repair.

## Decision rationale

KEEP means do not add a candidate from this audit.

1. Existing DATA covers the genuinely photographic refinement of an already-authored supported repair scene
2. An exact C1 supported-fastening scene mechanism is narrower than the family; C2 and C3 are different directed actions with different targets
3. A broad family row would either repeat existing contact/support vocabulary or combine distinct actions and dependencies into a scene recipe
4. A narrow scene-authoring row could be investigated independently in future, but this audit has not established a low-overlap benefit beyond the frozen core's own support/receiver relationship
5. Non-exposure of useful existing rows is a recorded limitation, not a pretext for a new synonym row, runtime change, or development-targeted retrieval tuning

No candidate row, alias extension, runtime patch, or threshold recommendation is frozen. The known open issue is bounded discovery of relevant existing generic relations, plus the need for authored scene-specific topology. No conclusion is made about rendered quality or holdout performance.
