"""Development-only source/retrieval inspection; not a public generation/audit run.
No provider calls, repository edits, candidate injection, or retrieval tuning.
C1/C2/C3 are transcribed from the allowed development-family research.
"""
import sys,json,hashlib
from pathlib import Path
ROOT=Path('REPOSITORY_ROOT')
OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'skills/photo-prompt-image-generator/scripts'))
import prompt_generator as g
assets=ROOT/'skills/photo-prompt-image-generator/assets'
data=g.load_json(assets/'photo_prompt_tags.json')
data[g.QUALITY_LAYERS_DATA_KEY]=g.load_quality_layers(assets/g.QUALITY_LAYERS_FILENAME)
scenes={
'C1':{'subject':'an adult caretaker','setting':'a library service alcove','event':'a caretaker lays a book trolley on its side, holds the loose caster against its mounting plate with one hand, and tightens a bolt with a short wrench; removed washers lie in a shallow lid beside the trolley','priorities':['the loose caster held against its mounting plate','a short wrench tightening the bolt','removed washers in a shallow lid']},
'C2':{'subject':'an adult','setting':'a street bicycle repair stand','event':'an adult braces a removed wheel between their knees and uses tweezers to pull a small thorn from the tire tread, while the bicycle remains clamped without its front wheel','priorities':['removed wheel braced between the knees','tweezers pulling a small thorn from tire tread','bicycle clamped without its front wheel']},
'C3':{'subject':'an adult technician','setting':'a community hall bench','event':'a technician holds an open folding-chair hinge steady while a magnetic pickup tool lifts a fallen screw from a narrow crack between floorboards; a replacement hinge plate rests on a folded cloth','priorities':['an open folding-chair hinge held steady','a magnetic pickup tool lifting a fallen screw from a narrow crack','a replacement hinge plate resting on a folded cloth']}}
relevant={
'action':['tool_contact_active_process_visible_result','being_disassembled_on_bench','repairing_own_open_panel','ccx_repair_detached_cuff','character_pose_proxemics_scene_action'],
'contact_point':['hand_gripping_tool_handle','load_bearing_contact_deformation','pr_object_contact_shadow_support_candidate','pc_px06_component_2'],
'prop':['socket_wrench_prop','disassembly_tray_parts_prop','machined_component_tray_prop','removed_suspect_component_tray','padded_object_support_prop'],
'location':['garage_workbench','maker_space_workbench','community_repair_bench'],
'composition':['crop_boundary_anchor_integrity','product_surface_support_hierarchy','repair_bench_topdown','over_the_shoulder_workbench'],
'focus':['subject_anchor_focus_plane_priority'],
'narrative_phase':['tool_contact_active_process_phase','visible_mishap_repair_phase'],
'procedure_step':['repair_diagnosis_step']}
source_rows=[]
for file in [assets/'photo_prompt_tags.json',*[assets/name for name in g.RESEARCH_EXTENSION_FILENAMES]]:
 d=json.loads(file.read_text())
 for slot,ids in relevant.items():
  for row in d.get('slots',{}).get(slot,[]):
   if row['id'] in ids: source_rows.append({'path':str(file.relative_to(ROOT)),'slot':slot,'entry':row,'source_file_sha256':hashlib.sha256(file.read_bytes()).hexdigest()})
(OUT/'inspected-source-rows.json').write_text(json.dumps(source_rows,ensure_ascii=False,indent=2)+'\n')
results={}
for key,s in scenes.items():
 request=s['event']
 controls=g.creative_controls.resolve(request,overrides={'sensual':0,'fetish':0,'surreal':0,'creativity':1},context={'subject_category':'human','no_people':False,'explicit_nonsexual':False},seed=0)
 core={'contract_version':'photo-authorial-core/v3','source_request':request,'request_binding':{'active_spans':[{'id':'development_scene','text':request}]},'creative_controls_sha256':controls['canonical_sha256'],'interpreted_intent':'An ordinary adult repair activity with its supported component and active tool relationship visible.','subject':s['subject'],'setting':s['setting'],'event':s['event'],'visual_priorities':s['priorities'],'baseline_prompt_en':f"In {s['setting']}, {s['event']}.",'user_exclusions':[],'user_definitions':[],'semantic_assertions':[],'style':{'domain':'documentary photography','family':'ordinary repair in progress','evidence':[]},'intent_lock':{'contract_version':'photo-intent-lock/v2','locked_dimensions':['concept','subject','event'],'open_dimensions':sorted(g.AUTHORIAL_CORE_V3_INTENT_LOCK_DIMENSIONS-{'concept','subject','event'}),'semantic_anchors':[]}}
 core['intent_lock']['canonical_sha256']=g.canonical_json_sha256(core['intent_lock'])
 core['canonical_sha256']=g.canonical_json_sha256(core)
 slots,binding,contract=g.retrieve_core_slots(data,core,controls)
 _,picked=g.frozen_core_context(data,core,controls)
 checks=[]
 for slot,ids in relevant.items():
  exposed={c['entry_id'] for c in slots.get(slot,{}).get('candidates',[])}
  for row in data['slots'].get(slot,[]):
   if row['id'] in ids:checks.append({'slot':slot,'entry_id':row['id'],'eligible':g.core_slot_entry_eligible(data,core,contract,picked,slot,row),'exposed':row['id'] in exposed,'effect_dimensions':g.photo_candidate_semantics.semantic_source(row,slot,data.get('candidate_semantic_policy')).get('affected_dimensions')})
 results[key]={'diagnostic_only':True,'input':core,'controls':controls,'retrieval_binding':binding,'total_exposed':sum(len(s['candidates']) for s in slots.values()),'inventory':{slot:[c['entry_id'] for c in obj['candidates']] for slot,obj in slots.items()},'examined_rows':checks}
 print(key,'total exposed',results[key]['total_exposed'])
 for slot in relevant:
  print(' ',slot,results[key]['inventory'].get(slot,[]))
 print(' eligible targeted', [f"{r['slot']}:{r['entry_id']}" for r in checks if r['eligible']])
(OUT/'development-reachability.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n')
files=[ROOT/'skills/photo-prompt-image-generator/SKILL.md',ROOT/'skills/photo-prompt-image-generator/references/maintenance.md',ROOT/'skills/photo-prompt-image-generator/references/retrieval-contract.md',ROOT/'skills/photo-prompt-image-generator/scripts/prompt_generator.py',ROOT/'skills/photo-prompt-image-generator/scripts/photo_candidate_semantics.py',assets/'photo_prompt_tags.json',assets/g.QUALITY_LAYERS_FILENAME,*[assets/n for n in g.RESEARCH_EXTENSION_FILENAMES]]
manifest={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
(OUT/'source-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
