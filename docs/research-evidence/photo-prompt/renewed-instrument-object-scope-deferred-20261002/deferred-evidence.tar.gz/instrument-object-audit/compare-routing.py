import sys,json,copy
from pathlib import Path
R=Path('REPOSITORY_ROOT');O=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'skills/photo-prompt-image-generator/scripts'));import prompt_generator as g
reg=g.load_visual_obligation_registry(R/'skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations.json')
terms=['playing a trumpet','playing the trumpet','playing trumpet','trumpet performance','트럼펫 연주','트럼펫을 연주하는','트럼펫을 연주한다']
cases=['trumpet','an unplayed trumpet with no people','holding a trumpet','playing a trumpet','not playing a trumpet','a trumpet is not being played','a trumpet while playing a saxophone','no trumpet performance','트럼펫 제품 사진','트럼펫을 들고 있는 사람','트럼펫을 연주하는 성인','트럼펫을 연주하지 않는 성인','트럼펫 연주 없이','트럼펫 연주 안 함','트럼펫을 연주하는 장면은 제외','트럼펫을 연주하는 것이 아니다']
base=next(p for p in reg['profiles'] if p['id']=='modern_piston_trumpet_three_valve');performance=copy.deepcopy(base);performance['id']='diagnostic_trumpet_performance';performance['activation']['exact_terms']=terms
# This is a routing-only in-memory metadata experiment, not a proposed completed profile or modified repository.
rr={**reg,'profiles':[base,performance]};ii=g.build_visual_profile_index_payload(rr)
out=[]
for text in cases:
 hits=g.resolve_visual_profile_hits(rr,[{'source':'concept_lock','text':text,'polarity':'required'}],visual_profile_index=ii)['hits']
 out.append({'text':text,'hard_ids':[h['profile_id'] for h in hits if h['hard_eligible']],'matched_performance_phrases':[t for t in terms if g.intent_alias_matches(text,t)]})
(O/'split-routing-diagnostic.json').write_text(json.dumps(out,ensure_ascii=False,indent=2));print(json.dumps(out,ensure_ascii=False,indent=2))
# Duplicate noun exact aliases are accepted by the runtime index/resolver.
performance['activation']['exact_terms']=['trumpet'];rr['profiles']=[base,performance];ii=g.build_visual_profile_index_payload(rr)
r=g.resolve_visual_profile_hits(rr,[{'source':'concept_lock','text':'trumpet','polarity':'required'}],visual_profile_index=ii)
(O/'duplicate-noun-routing.json').write_text(json.dumps(r,indent=2))
