# Follow-up comparison and recommendation

## Recommend B: two morphology profiles plus two small performance profiles

A fixes the demonstrated object-only wording but leaves bare nouns, holding, display, instrument-carrying portraits and new object phrasings performance-bound unless more omission cues are continually added. It also creates retain-versus-omit conflict precedence and core-derived exceptions. B expresses the actual semantic distinction directly with two extra profiles and no scene exceptions. That small increase is justified.

The supported compiler/resolver can implement B entirely as DATA. No new code guard is proposed. Complete language-independent action/negation understanding is not available in the present matcher: the scope and limitations below must be accepted explicitly.

## Exact component and identity scope

Keep these two existing IDs as morphology-only:

1. `modern_piston_trumpet_three_valve`
   - Four components: compact folded tubing/forward bell; cup-shaped mouthpiece; three aligned piston valves; saxophone/reed-keywork confound control
   - Remove `lip_valve_relation` / `playing_relation_phrase` / `vo_instrument_trumpet_playing_contact` from this profile
   - Rewrite cup-mouthpiece evidence and gate as visible cup morphology, not contact with lips
   - Rewrite three-valve evidence and gate as visible valve assembly, not fingers above it
   - Remove `mouthpiece_away_from_lips` rejection; retain true object confounds
   - Definition, paraphrases, concept terms and composition become object construction only
2. `alto_tenor_saxophone_reed_conical_body`
   - Four components: curved conical body/bell; reed/ligature mouthpiece; dense keywork; trumpet/cup-valve confound control
   - Remove `embouchure_hand_relation` / `embouchure_phrase` / `vo_instrument_sax_playing_contact`
   - Definition, paraphrases, concept terms and composition become object construction only

Add exactly two companion IDs:

3. `modern_piston_trumpet_lip_valve_playing_relation`
   - One compound authored component, `lip_valve_hand_relation`
   - Evidence field `playing_relation_phrase`
   - Move existing gate ID `vo_instrument_trumpet_playing_contact` here, retaining its coherent relation requirement
   - Concrete positive invariant: the cup mouthpiece meets the lips, right-hand fingers operate the three piston valves, and the left hand supports the valve block/tubing
   - Keep the prior right-operation/left-support correction throughout description, evidence, instruction and gate; never require left-hand valve operation
4. `alto_tenor_saxophone_reed_key_playing_relation`
   - One compound authored component, `reed_embouchure_key_relation`
   - Evidence field `embouchure_phrase`
   - Move existing gate ID `vo_instrument_sax_playing_contact` here
   - Positive invariant: lips seal the reed mouthpiece while both hands contact and operate their key regions

This yields four object gates for bare nouns and the same five total instrument gates across two profiles for explicit performance. It avoids manufacturing extra invariants to satisfy a historical five-per-profile assertion. New profiles must use concrete definitions/paraphrases and genuine performance confounds, rather than cloning irrelevant object confounds merely for count tests.

Existing morphology exact aliases remain intact except move the performance-only aliases listed below to companions. Bare noun substrings still match within those performance phrases, so both profiles activate compositionally without duplicate aliases or cross-profile linkage.

## Exact alias scope

Morphology trumpet keeps: `trumpet`, `modern trumpet`, `piston trumpet`, `three-valve trumpet`, `트럼펫`, `피스톤 트럼펫`, `3밸브 트럼펫`.

Morphology saxophone keeps: `alto saxophone`, `tenor saxophone`, `alto sax`, `tenor sax`, `알토 색소폰`, `테너 색소폰`.

Move from existing profiles to companions: `trumpet performance`, `트럼펫 연주`, `알토 색소폰 연주`, `테너 색소폰 연주`.

Add performance aliases only as noun-bound action phrases, with a bounded explicit matrix:

- For each English trumpet noun above and each English saxophone noun above: `playing {N}`, `playing a {N}`, `playing an {N}`, `playing the {N}`, `plays {N}`, `plays a {N}`, `plays an {N}`, `plays the {N}`, `{N} performance`; omit grammatically wrong a/an variants per noun
- For each Korean noun above: `{N} 연주`, `{N}을 연주하는`, `{N}을 연주한다`
- Do NOT add bare `playing`, `plays`, `performance`, `연주`, generic `musician`, `saxophonist`, or any bare instrument noun as an exact trigger for the performance companions
- Do NOT broaden to generic saxophone, soprano saxophone, rotary trumpets or other instrument families
- Additional lexical aliases can be added only when supported by a concrete request/replay; this is positive action vocabulary rather than an expanding scene-exception list

Noun-bound exact aliases alone are sufficient for initial hard eligibility. A hard_activation policy repeating the same full noun-bound phrases is valid but redundant. Prefer no redundant gate. If a later design deliberately gives the performance profile a broader exact alias, hard_activation must require one of these same instrument-bound positive phrases; never use independent instrument-name AND generic-playing groups, which can attach trumpet performance to “a trumpet while playing a saxophone.”

Natural exact-term duplication across profiles is not globally prohibited: validation checks distinct terms within each profile, whereas glossary aliases have cross-profile ownership. An in-memory duplicate-noun probe also confirms both profiles resolve. Nevertheless avoid duplication because a noun-triggered gated performance profile creates optional performance candidates for every object scene. The proposed phrase-only companion avoids that extra noise.

## Negation: actual tested behavior and blocker

`split-routing-diagnostic.json` uses an in-memory routing-only companion, not an implemented DATA patch. Confirmed:

- Bare trumpet, unplayed trumpet, holding trumpet: existing noun profile only
- Playing a trumpet: noun + performance profiles
- Not playing a trumpet; trumpet is not being played: noun only
- A trumpet while playing a saxophone: trumpet noun only
- 트럼펫 제품 사진; 트럼펫을 들고 있는 사람: noun only
- 트럼펫을 연주하는 성인: noun + performance
- 트럼펫을 연주하지 않는 성인; 트럼펫 연주 없이; 트럼펫을 연주하는 장면은 제외: noun only
- `트럼펫 연주 안 함` incorrectly retains nominal performance
- `트럼펫을 연주하는 것이 아니다` incorrectly retains positive embedded phrase
- `no trumpet performance` negates both the performance phrase and the noun, so neither profile activates. This is existing local noun-negation behavior, not a split-specific regression

Existing `hard_activation` uses exactly the same matcher and cannot repair the missed Korean negation forms. Omitting nominal `{N} 연주` avoids the first failure at the cost of losing currently recognized common nominal performance requests, but does not fix the second. Do not claim complete negation safety or hide this with scene exception lists. A DATA-only split can cleanly improve positive, holding and object semantics while documenting inherited negation limits. If universal Korean negation correctness is a release requirement, that is a separate matcher workstream requiring explicit authorization; neither A nor B satisfies it alone.

## Migration and regression obligations

- Change the historical assertion from “each of ten old profiles has five groups and gates” to explicit expected structure by semantic role: these two object profiles have four; the two companions have one each; remaining profiles unchanged
- Preserve bare noun routing assertions as one morphology profile; migrate explicit-performance route cases to two IDs, not the historical single mixed ID
- Move gate ownership rather than duplicate gate IDs; prove global uniqueness and summed performance gate coverage
- Update profile/candidate binding tests intentionally: props support morphology; actions/contact/body-pose support performance. Existing candidate rows themselves need no text edit for this change
- Research evidence affected-contract references may need the companion IDs because the same verified instrument mechanism now lives there; do not invent new evidence or approvals
- Rebuild visual-profile index and validate its source hash; no semantic candidate index rebuild unless tags change
- Repeat both normal public object CLI probes, then matched EN/KO positive performances, mere holding/display, mixed-instrument ownership, negative performance and post-core discovery tests
- Full performance aliases may be recognized inside a longer hypothetical or negated clause beyond matcher's window; this is an explicit limitation to test, not evidence for expanding negative keyword policies

No source or tests were edited. No APIs were called. Recommendation is an intentional profile-contract migration, not a test-only accommodation.
