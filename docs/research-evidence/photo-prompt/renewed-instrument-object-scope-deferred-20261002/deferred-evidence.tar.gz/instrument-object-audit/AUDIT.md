# Instrument object-only scope audit

## Confirmed result

Both exact requests, “A product still life of an unplayed trumpet on an empty tabletop, no people or hands.” and the equivalent alto-saxophone request, hard-activate their profiles. Both succeed through the normal public `generate_photo_prompt.py` CLI with normalized authorial-core contracts yet emit a contradictory performance obligation. The normalized cores retain `user_exclusions: [people, hands]`.

- Trumpet: all five gates required, including lips meeting cup mouthpiece, valves under right-hand fingers, and coherent lip/right-hand/left-hand playing contact
- Saxophone: all five gates required, including lips on reed mouthpiece and both hands operating keys
- Direct resolver positive performance controls produce the same obligations
- This is prompt/contract evidence, not a claim that a rendered image actually contains a person

See `resolver-evidence.json`, `public-summary.json`, complete `*-public-result.json`, and reproducible `probe.py`. Inputs were source-known diagnostic cores, not blinded generation. Initial negative-prose validation failures are retained as `*-public-error.txt`; corrected positive-geometry baselines subsequently succeeded. No repository source or tests were changed. `manifest.json` captures source hashes and clean git status.

## Actual path and cause

1. Registry `photo_prompt_visual_obligations.json:10079–10168` combines morphology and performance in each profile. Both have bare instrument exact terms, adult requirement false, no hard_activation, and no authored_components.
2. `prompt_generator.py:6308–6455` resolves requester exact terms. `hard_activation_is_supported` in `visual_profile_contracts.py:53–70` returns true with no hard_activation policy. The explicit no-people text does not negate the instrument noun.
3. `candidate_pack_visual_obligations` at 7407 and its call to `candidate_pack_visual_profile_obligation` at 7533 materialize the whole profile and append every gate to required_hard_gates. They pass actual request/core context to the compiler.
4. `visual_profile_contracts.py:73–165` returns the profile unchanged if authored_components is absent. Hence no conditional visibility projection happens today.
5. Public pack preserves these obligations despite its no-people/hands exclusions; no diagnostic injection or explicit visual-intent override was needed.

## Smallest supported DATA correction for the verified explicit object-only case

Use existing authored_components on the two existing profiles, preserving their exact noun routing and default five-component shape. Keep four invariant morphology/confound components and isolate the fifth as performance contact.

- Trumpet: make cup-mouthpiece and three-piston-valve components independently morphological, removing lips/fingers from their match terms, evidence terms, instructions and gates. Keep lip/right-valve/left-support roles only in the playing component.
- Saxophone: body, reed/ligature, keywork and trumpet-confound remain invariant; isolate lip/key operation in the existing embouchure component.
- Apply the existing component applicability schema only to each performance component. `omit_if_any_terms` should express explicit object/nonperformance scope such as unplayed, object-only, instrument only, no people and Korean equivalents. Do not use ambient scene words like tabletop, studio or product as sufficient evidence; these can coexist with performance.
- `retain_if_requested_any_terms` should use explicit playing/performance relations. Do not use bare instrument nouns, hands or broad “played” as retain terms.
- Remove unconditional performance from unprojected definition/paraphrase/concept surfaces, or phrase it as conditional explanatory knowledge rather than a mandatory visual relation. Replace trumpet `mouthpiece_away_from_lips` reject substitute with a genuine morphological confound. Otherwise omission leaves incompatible instructions elsewhere.
- Author components once and remove redundant legacy compatibility surfaces, or regenerate them exactly from components. Compiler rejects conflicting default projections.
- Rebuild generated visual-profile index. Semantic index regeneration is only needed if candidate-tag data changes; this proposal need not change tags.

This retains hard morphology on explicit object-only requests and full performance on explicit playing controls. It is a narrowly authored literal applicability exception, not a new context heuristic in runtime code. It does NOT establish that every bare noun without an object-only cue becomes morphology-only: the existing applicability contract is omission-based, not positive-only activation. If the desired broader semantics are “performance only when explicitly requested,” use separate morphology and performance profiles, with hard_activation on the performance profile. That is a larger DATA migration, not a two-field fix.

## Why activation-only is insufficient

Adding hard_activation requiring playing to the existing mixed profile makes the entire profile optional for a still life, including mouthpiece/valve/keywork morphology. The optional candidate still contains inappropriate performance semantics. Adding `requires_adult_character=true` similarly removes useful object morphology and does not separate action from identity. Neither is a complete correction.

## Applicability limits and risks

- Compiler specializes component groups, required fields, evidence requirements, instructions and pixel gates only. It does not specialize definition, concept terms, runtime expression, reject substitutes or activation.
- The request-retain condition wins over omission. Contradictory inputs containing positive playing plus no people need explicit handling/test expectations; this schema cannot represent negative-precedence overrides.
- Shared matcher is lexical and local. Actual probes: “not playing a trumpet” negates playing, but “not being played” does NOT negate played. “no people or hands” still matches bare hands. Thus broad retain terms are unsafe; see `applicability-matcher-probe.json`.
- Omission context includes authorial core as well as requester text; a core-added object-only cue can omit a performance group unless explicit requester performance retains it. Test both ownership directions.
- Existing five-group/five-gate tests remain correct for unspecialized profiles but object-only specialized projection should have four. Existing exact noun routing can remain unchanged. New split profiles would alter positive match expectations and global fixture inventories.
- Other instrument profiles also mix construction and performance; this audit only proves public-contract failures for the two requested profiles. Do not bulk-edit the rest by analogy.

## Test plan before shipping

1. Existing instrument exact routing / Korean routing, morphology/concept discovery, five-component defaults, dictionary validation, visual registry/index metadata and relevant authored-component suites
2. Both English and Korean unplayed/no-people object requests: intended profile remains hard; morphology fields/gates remain; no performance field/gate, lips/finger instruction or contact reject-substitute in actual projected obligation
3. Explicit playing EN/KO: retain full embouchure, sax keys, trumpet right-hand valves and left support
4. Adult merely holds instrument, instrument beside person, tabletop in performance, museum display, disassembled parts, no-hands detail crop: separate expected scope carefully; avoid overgeneralized scene-term omission
5. Negated retain phrases and contradictory requests; request versus core precedence; no component deletion by composer-supplied flags
6. Normal public CLI replay with source-known normalized inputs and public gate/evidence audit; then complete composed-prompt evidence audit. No pixel-quality claim without separately authorized image generation/review
