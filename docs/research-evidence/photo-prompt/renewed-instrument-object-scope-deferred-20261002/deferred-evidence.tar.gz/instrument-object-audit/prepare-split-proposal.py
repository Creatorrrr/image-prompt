import sys,json,copy,hashlib,shutil,subprocess
from pathlib import Path
R=Path('REPOSITORY_ROOT');O=Path(__file__).resolve().parent/'split-proposal';O.mkdir(exist_ok=True)
S=R/'skills/photo-prompt-image-generator';sys.path.insert(0,str(S/'scripts'))
import prompt_generator as g
import validate_photo_prompt_dictionary as v
from visual_profile_contracts import compile_visual_profile
D=lambda name,obj:(O/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
source=S/'assets/photo_prompt_visual_obligations.json'; original=json.loads(source.read_text());shutil.copyfile(source,O/'original-registry-exact.json')
ids=['modern_piston_trumpet_three_valve','alto_tenor_saxophone_reed_conical_body']; originals={p['id']:copy.deepcopy(p) for p in original['profiles'] if p['id'] in ids};D('original-profiles.json',originals)
proposed=[];mapping=[]
for pid in ids:
 p=copy.deepcopy(originals[pid]);tr=pid==ids[0];old=copy.deepcopy(p)
 performance_id='modern_piston_trumpet_lip_valve_playing_relation' if tr else 'alto_tenor_saxophone_reed_key_playing_relation'
 noun_en=['trumpet','modern trumpet','piston trumpet','three-valve trumpet'] if tr else ['alto saxophone','tenor saxophone','alto sax','tenor sax']
 noun_ko=['트럼펫','피스톤 트럼펫','3밸브 트럼펫'] if tr else ['알토 색소폰','테너 색소폰']
 p['activation']['exact_terms']=noun_en+noun_ko
 groups=old['semantics']['component_semantics']['groups']; fields=old['required_evidence_fields'];components=[]
 for i in [0,1,2,4]:
  group=groups[i];field=fields[i];e=copy.deepcopy(old['evidence_requirements'][field]);gate=copy.deepcopy(old['render_gates'][i]);terms=copy.deepcopy(group['any_terms'])
  if tr and i==1:
   phrase='a cup-shaped mouthpiece is attached to the trumpet leadpipe';terms=[phrase,'트럼펫 리드파이프에 연결된 컵 모양 마우스피스'];e={'min_content_words':7,'must_mention_any':[phrase]};gate['description']='A cup-shaped mouthpiece is visibly attached to the trumpet leadpipe.'
  if tr and i==2:
   phrase='three aligned piston valves form a compact valve block';terms=[phrase,'나란한 세 피스톤 밸브가 이루는 밸브 블록'];e={'min_content_words':7,'must_mention_any':[phrase]};gate['description']='Three aligned piston valves remain individually legible in a compact valve block.'
  components.append({'id':group['id'],'match_terms':terms,'evidence_field':field,'evidence_terms':e['must_mention_any'],'min_content_words':e['min_content_words'],'instruction':'Keep this instrument structure visibly legible: '+e['must_mention_any'][0]+'.','render_gate':gate})
 p['semantics']['definition']=('A modern piston trumpet with compact folded brass tubing, a cup-shaped mouthpiece, three aligned piston valves, tuning slides, and a forward flared bell.' if tr else 'A curved alto or tenor saxophone with a single-reed mouthpiece and ligature, dense linked keywork on a conical metal body, and a flared bell.')
 p['semantics']['paraphrase_examples']=(['컵 모양 마우스피스와 세 피스톤 밸브가 있는 접힌 황동관 악기','a compact folded brass wind instrument with a cup-shaped mouthpiece and aligned piston valves'] if tr else ['싱글 리드와 리가처 및 조밀한 키가 달린 굽은 금속관 악기','a curved conical metal wind instrument with a reed mouthpiece and linked keywork'])
 p['semantics']['contrast_examples']=[s for s in p['semantics']['contrast_examples'] if 'held away from the lips' not in s]
 p['concept_candidate']['concept_terms']=[s for s in p['concept_candidate']['concept_terms'] if 'embouchure' not in s]
 p['reject_substitutes']=[s for s in p['reject_substitutes'] if s!='mouthpiece_away_from_lips']
 for key in ['composition_instruction','required_evidence_fields','evidence_requirements','render_gates']:p.pop(key,None)
 p['semantics'].pop('component_semantics',None);p['authored_components']={'contract_version':'photo-authored-visual-components/v1','components':components}
 p=compile_visual_profile(p);proposed.append(p)
 aliases=[]
 for noun in noun_en:
  article='an' if noun.startswith('alto') else 'a'
  aliases += [f'{verb} {prefix}{noun}' for verb in ['playing','plays'] for prefix in ['',article+' ','the ']]+[f'{noun} performance']
 for noun in noun_ko: aliases += [f'{noun} 연주',f'{noun}을 연주하는',f'{noun}을 연주한다']
 phrase=("the lips meet the cup mouthpiece while right-hand fingers operate the three piston valves and the left hand supports the instrument" if tr else 'the lips seal the reed mouthpiece while both hands operate the saxophone key regions')
 korean=('입술은 컵 마우스피스에 닿고 오른손은 세 피스톤 밸브를 조작하며 왼손은 악기를 지지' if tr else '입술은 리드 마우스피스에 닿고 양손은 색소폰 키를 조작')
 gate=copy.deepcopy(old['render_gates'][3]);field=fields[3]
 perf={'id':performance_id,'category':'instrument_playing_contact_relation','activation':{'exact_terms':aliases,'requires_adult_character':False,'semantic_discovery_requires_component_evidence':True},'semantics':{'definition':('A visible trumpet playing relation couples lip contact at the cup mouthpiece with right-hand operation of three piston valves and left-hand support of the instrument.' if tr else 'A visible alto or tenor saxophone playing relation couples lips sealed around the reed mouthpiece with both hands operating plausible key regions.'),'paraphrase_examples':[korean,('a brass player forms an embouchure while the right fingers actuate valves and the left hand supports the instrument' if tr else 'a reed wind player seals the mouthpiece with the lips and operates keys with both hands')],'contrast_examples':(['an unplayed trumpet resting on a stand','a person merely holding a trumpet away from the mouth','a trumpet held beside someone playing a different instrument'] if tr else ['an unplayed saxophone resting on a stand','a person carrying a saxophone away from the mouth','a saxophone displayed beside someone playing a different instrument'])},'concept_candidate':{'concept_terms':(['trumpet cup mouthpiece lip contact','right-hand piston valve operation','left-hand trumpet support'] if tr else ['saxophone reed mouthpiece lip contact','both hands operating saxophone keys'])},'runtime_expression':{'default_mode':'label_plus_definition','prompt_label_terms':['trumpet playing contact' if tr else 'alto or tenor saxophone playing contact'],'forbidden_prompt_terms':[],'runtime_forbidden_labels':[]},'reject_substitutes':(['mouthpiece_away_from_lips','left_hand_operating_piston_valves_instead_of_right','right_hand_only_supporting_without_valve_operation'] if tr else ['mouthpiece_away_from_lips','hands_detached_from_key_regions','cup_mouthpiece_lip_buzz_instead_of_reed_contact']),'authored_components':{'contract_version':'photo-authored-visual-components/v1','components':[{'id':'lip_valve_hand_relation' if tr else 'reed_embouchure_key_relation','match_terms':[phrase,korean],'evidence_field':field,'evidence_terms':[phrase],'min_content_words':14 if tr else 10,'instruction':'Show the requested instrument performance as one coherent contact relation: '+phrase+'.','render_gate':gate}]}}
 perf=compile_visual_profile(perf);proposed.append(perf)
 mapping.append({'old_profile_id':pid,'morphology_profile_id':pid,'performance_profile_id':performance_id,'moved_component':groups[3]['id'],'new_component':perf['authored_components']['components'][0]['id'],'moved_evidence_field':field,'moved_gate_id':gate['id'],'before_group_count':5,'after_morphology_group_count':4,'after_performance_group_count':1,'bare_noun_expected_profiles':[pid],'explicit_play_expected_profiles':[pid,performance_id]})
D('proposed-full-profiles.json',proposed);D('semantic-migration-map.json',mapping)
registry=copy.deepcopy(original); replacements={p['id']:p for p in proposed};registry['profiles']=[replacements.get(p['id'],p) for p in registry['profiles']]+[p for p in proposed if p['id'] not in ids];D('proposed-main-registry.json',registry)
errors=[];v.validate_visual_obligation_registry(O/'proposed-main-registry.json',errors)
# Source-local exact/lexical indexes only, no embedding vectors, not production refreshed index.
before=g.load_visual_obligation_registry(source);after=copy.deepcopy(before);after['profiles']=[replacements.get(p['id'],p) for p in before['profiles']]+[p for p in proposed if p['id'] not in ids]
indexes={label:g.build_visual_profile_index_payload(reg) for label,reg in [('before',before),('after',after)]}
cases=[]
for noun,ko in [('trumpet','트럼펫'),('alto saxophone','알토 색소폰'),('tenor saxophone','테너 색소폰')]:
 cases += [(f'{noun}:bare',noun),(f'{noun}:object_en',f'A product still life of an unplayed {noun} on an empty tabletop, no people or hands.'),(f'{noun}:object_ko',f'사람 없이 탁자 위에 놓인 {ko} 제품 사진'),(f'{noun}:play_en',f'An adult musician playing {"an" if noun.startswith("alto") else "a"} {noun}.'),(f'{noun}:play_ko',f'성인이 {ko}을 연주하는 모습'),(f'{noun}:hold',f'An adult holding a {noun} beside a wall.'),(f'{noun}:display',f'A {noun} displayed in a museum case.'),(f'{noun}:not_play_en',f'An adult not playing a {noun}.'),(f'{noun}:passive_not_play',f'The {noun} is not being played.'),(f'{noun}:not_play_ko',f'{ko}을 연주하지 않는 성인'),(f'{noun}:nominal_without_ko',f'{ko} 연주 없이 전시'),(f'{noun}:known_nominal_negation_gap',f'{ko} 연주 안 함'),(f'{noun}:known_embedded_negation_gap',f'{ko}을 연주하는 것이 아니다')]
cases += [('mixed_trumpet_display','An unplayed trumpet beside a musician playing an alto saxophone.'),('mixed_sax_display','An unplayed alto saxophone beside a musician playing a trumpet.'),('negative_performance_en','no trumpet performance'),('negative_performance_ko','트럼펫을 연주하는 장면은 제외')]
routes=[]
for label,text in cases:
 row={'case':label,'request':text,'known_matcher_limitation':'known_' in label}
 for version,reg in [('before',before),('after',after)]:
  resolved=g.resolve_visual_profile_hits(reg,[{'source':'concept_lock','text':text,'polarity':'required'}],visual_profile_index=indexes[version]);hard=[h for h in resolved['hits'] if h['hard_eligible']]
  row[version]={'hard_profile_ids':[h['profile_id'] for h in hard],'gates':[gate['id'] for h in hard for p in reg['profiles'] if p['id']==h['profile_id'] for gate in p['render_gates']]}
 routes.append(row)
D('before-after-routing.json',routes)
# Bind extant approved source records without inventing approvals or editing their source claims.
evidence_path=R/'docs/research-evidence/photo-prompt/research_evidence.jsonl';shutil.copyfile(evidence_path,O/'original-research-evidence-exact.jsonl');evidence=[json.loads(x) for x in evidence_path.read_text().splitlines() if x.strip()]
bindings=[]
for m in mapping:
 for e in evidence:
  ref='visual_obligation:'+m['old_profile_id']
  if ref in e.get('affected_contract_ids',[]):bindings.append({'evidence_id':e['id'],'existing_source_url':e.get('source_url'),'old_affected_contract_ids':e['affected_contract_ids'],'proposed_affected_contract_ids':e['affected_contract_ids']+['visual_obligation:'+m['performance_profile_id']],'change_scope':'add companion binding only; no new approval, claims, review date or source text'})
merged={}
for binding in bindings:
 key=binding['evidence_id']
 if key not in merged: merged[key]=binding
 else: merged[key]['proposed_affected_contract_ids']=list(dict.fromkeys(merged[key]['proposed_affected_contract_ids']+binding['proposed_affected_contract_ids']))
D('evidence-binding-proposal.json',list(merged.values()))
D('validation.json',{'registry_schema_errors':errors,'compiled_component_counts':{p['id']:len(p['authored_components']['components']) for p in proposed},'routing_case_count':len(routes),'method':'In-memory exact/lexical resolver indexes from actual source data. No fabricated vectors, production index refresh, normal CLI after-change proof or pixel evidence. Known negative-language failures explicitly retained.','repo_git_status':subprocess.check_output(['git','status','--short'],cwd=R,text=True),'original_sha256':hashlib.sha256(source.read_bytes()).hexdigest()})
print('schema errors:',errors,'cases:',len(routes),'bindings:',len(bindings))
