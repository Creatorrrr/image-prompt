import sys,json,hashlib
from pathlib import Path
R=Path('REPOSITORY_ROOT'); O=Path(__file__).resolve().parent
sys.path[:0]=[str(R),str(R/'skills/photo-prompt-image-generator/scripts')]
import prompt_generator as g
from tests import photo_prompt_fixtures as f
reg=g.load_visual_obligation_registry(R/'skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations.json');idx=g.build_visual_profile_index_payload(reg)
outputs=[]
for noun in ['trumpet','alto saxophone']:
 for mode in ['object']:
  request=(f'A product still life of an unplayed {noun} on an empty tabletop, no people or hands.' if mode=='object' else f'An adult musician playing a {noun}.')
  rows=[{'source':'concept_lock','text':request,'polarity':'required'}]
  hits=g.resolve_visual_profile_hits(reg,rows,visual_profile_index=idx)['hits']
  contract=g.candidate_pack_visual_obligations({g.VISUAL_OBLIGATIONS_DATA_KEY:reg},{'provenance':{'concept_lock':[request]}},{},None)
  out={'request':request,'hits':hits,'contract':contract}; outputs.append(out)
  print(request,[(h['profile_id'],h['hard_eligible']) for h in hits]); print(contract['obligations'][0]['composition_instruction'])
(O/'resolver-evidence.json').write_text(json.dumps(outputs,indent=2))
# Normal public CLI object-only probes; fixture structure is source-known diagnostic input, not blind image evidence.
for noun in ['trumpet','alto saxophone']:
 request=f'A product still life of an unplayed {noun} on an empty tabletop, no people or hands.'
 subject=f'one unplayed {noun}';event='the instrument rests motionless on an empty tabletop'
 baseline=f'A product still life shows {subject}; {event}. The tabletop presents the instrument alone as a self-contained object. A neutral charcoal backdrop isolates the complete instrument silhouette, with generous negative space around its edges. Soft diffused studio illumination creates controlled reflections across the metal without obscuring the physical details. The camera looks diagonally across the tabletop at a moderate height, keeping the complete instrument sharply resolved and the background quiet. The image emphasizes material, construction and the stillness of an unused musical object.'
 raw=f.core(request,interpreted_intent='An object-only product photograph with no people or hands and no performance.',subject=subject,setting='an empty studio tabletop',event=event,visual_priorities=('complete instrument silhouette','controlled reflections across the metal','stillness of an unused musical object'),baseline_prompt_en=baseline,exclusions=('people','hands'))
 (O/(noun.replace(' ','-')+'-raw-core.json')).write_text(json.dumps(raw,indent=2))
 try:
  result=f.run_current(raw)
  (O/(noun.replace(' ','-')+'-public-result.json')).write_text(json.dumps(result,indent=2))
  print('PUBLIC OK',noun,list(result))
 except Exception as e:
  (O/(noun.replace(' ','-')+'-public-error.txt')).write_text(str(e));print('PUBLIC ERROR',noun,str(e)[:1200])
