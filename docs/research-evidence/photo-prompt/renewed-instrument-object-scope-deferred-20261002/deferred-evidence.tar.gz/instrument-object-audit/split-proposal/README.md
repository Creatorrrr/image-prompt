# Review-ready instrument DATA split

## Result

Schema validation succeeded: zero errors. Compiled component counts are 4/1 for trumpet and 4/1 for saxophone. The 43 saved before/after routing results were reviewed without rerunning retrieval: 37 supported cases match the intended scoped expectation; six explicitly marked Korean-negation cases reproduce the known matcher limitation (two forms each across trumpet/alto/tenor). No unexpected failures in this matrix.

English/Korean object requests, bare nouns, holding and museum display retain only morphology. Explicit instrument-bound playing activates morphology plus the correct performance companion. Mixed scenes activate performance only for the played instrument. Supported local negated-playing forms retain morphology without playing. `no trumpet performance` removes both profiles because the existing matcher also negates the noun; this is recorded rather than presented as proof of ideal negation semantics.

## Files to integrate/review

- `proposed-full-profiles.json`: the four complete profiles; integrate ONLY these by ID after review
- `semantic-migration-map.json`: old/new components, fields and gate ownership
- `evidence-binding-proposal.json`: three existing evidence rows, proposed companion-reference additions only; taxonomy row changes are consolidated
- `before-after-routing.json`: 43 resolver/gate comparisons
- `routing-expectation-review.json`: explicit expected IDs, 37 passing supported cases and six acknowledged limitations
- `validation.json`: original zero-error schema result and exact method limitations
- `original-profiles.json`, `original-registry-exact.json`, `original-research-evidence-exact.jsonl`: preserved snapshots

DO NOT overwrite the repository with `proposed-main-registry.json`. It was a temporary schema-validation vehicle and is stale for unrelated lighting changes now committed in 56fa0357. The two original instrument target profiles were checked against current source and remain structurally identical. Original snapshot bytes remain untouched.

## Scope and residual limitations

The proposal moves old playing gate IDs into one-component companions and makes existing mouthpiece/valve gates morphology-only. Trumpet performance evidence explicitly preserves lips on cup, right fingers operating three valves and left hand supporting the instrument. Positive aliases are instrument-bound; no generic scene exceptions or runtime logic are added. No hard_activation field repeats the same exact phrases because that would be redundant.

The six expected limitations are `{instrument} 연주 안 함` and `{instrument}을 연주하는 것이 아니다`. Existing exact matching and hard_activation share the same insufficient negation matcher. This proposal does not claim to fix them. Broader passive, syntactically discontinuous, hypothetical or ownership-ambiguous action descriptions are not comprehensively recognized by bounded literal aliases.

Research binding additions propose no new source claims, approvals or review dates. Existing source evidence and old role-correct profile/candidate contracts are preserved; broader source claims should not be inferred from these reference additions.

Historical tests must intentionally migrate two five-component profiles to four morphology plus one performance companion, preserve global gate uniqueness, and expect two profile IDs for explicit performance. Prop bindings belong to morphology, action/contact/pose bindings to performance; do not change unrelated candidate text just to satisfy old assertions.

## Proof not yet supplied

This is source-local schema/compiler/resolver evidence using in-memory lexical indexes, with no fabricated embedding vectors. It is not a production refreshed visual index, after-change normal-CLI qualification, composed-prompt audit or image-quality evidence. Those remain integration follow-ups. No paid API calls or main repository/test edits were made by this worker. The git-status changes recorded in validation.json were concurrent parent lighting work, not this proposal.
