# Follow-up review: conservative conditional omission (A)

## Recommendation

**Final disposition under the parent’s explicit no-overfit/no-positive-regression criterion: DEFER.** The requested coordinated-play plus background-no-people counterexample is reproduced exactly below. Narrowing to the two observed unplayed phrases would be a limited diagnostic patch, not an approved general fix. Preserve the diagnosis and pursue a separate semantic ownership/request-grounded omission workstream; continue unrelated safe DATA improvements.

**Prefer A over B for a narrowly scoped repair preserving existing positive/default routing, but do not describe A as universally positive-regression-free.** B remains paused: requiring new noun-bound performance aliases loses the existing coordinated-play behavior. Preserve the earlier B review and evidence as an independent record.

The safest DATA-only initial scope is **instrument-qualified unplayed cues**, which already covers both recorded public failing requests. If global no-people cues are included, use only an explicitly reviewed bounded phrase set and accept/document their substring-scoping limitation; broad `no people` is not reliable evidence of global absence. If the release condition is literally no positive regressions across scope/core variants, **defer implementation**: the current compiler cannot meet it through a small cue list alone.

## What A can preserve

Keep the two original profile IDs, all original activation aliases and a default five-component contract. Use the clean four morphology components plus one performance component, co-located under each old profile. Only performance receives applicability. This makes coordinated playing, passive/other playing paraphrases and bare noun default behavior independent of new positive aliases. It also retains gate uniqueness and avoids extra profile identity migrations.

Make all unconditional surfaces morphology-only, including definition, paraphrases, concept terms, reject substitutes and object component instructions. In particular, trumpet cup/valve components must not mention lips/hands, and unconditional `mouthpiece_away_from_lips` must be removed. Performance constraints belong exclusively in the conditional component. Otherwise omitting its gate will not eliminate the original contradiction.

Retain the earlier review's explicit note-appropriate/rest-or-press trumpet wording, minimum valve evidence 10, and morphology-safe reflection control. No unrelated candidate edits, thresholds, runtime code, or aliases are needed.

## Tested bounded cue experiment

`alternative-a-diagnostic.json` and `check-alternative-a.py` use actual existing compiler and intent matcher, unchanged original activation metadata, and these temporary applicability policies:

- Global candidates: `no people`, `사람 없이`
- Trumpet-qualified: `unplayed trumpet`, `연주하지 않는 트럼펫`
- Sax-qualified: `unplayed alto saxophone`, `unplayed tenor saxophone`, `unplayed alto sax`, `unplayed tenor sax`, `연주하지 않는 알토 색소폰`, `연주하지 않는 테너 색소폰`
- Retention: the previously proposed noun-bound positive aliases for the corresponding instrument only

This is a compiler projection diagnostic, not a registry implementation, a production index, or an end-to-end CLI result. Each profile's result is shown if that profile is activated; profiles absent from a request are not thereby claimed to route.

The two actual public requests both say `unplayed <specific instrument>` and `no people or hands`. Both lose just performance, retaining four morphology components. Ordinary coordination “Two adults playing a trumpet and a tenor saxophone” retains five components for both instruments. English mixed “unplayed trumpet … playing an alto saxophone” and its inverse omit only the unplayed instrument's performance. Korean mixed “연주하지 않는 트럼펫 옆에서 알토 색소폰을 연주하는 성인” behaves likewise. Bare nouns and studio/tabletop product context retain the original default. An explicitly playing trumpet plus an unplayed alto does not let the sax cue suppress trumpet performance.

## Verified limits that prevent an unconditional approval

1. **No global scope detection.** “Two adults playing a trumpet and a tenor saxophone, no people in the background” gives five trumpet components but four sax components. `no people` matches a subordinate background constraint; the request-bound retention list catches trumpet but not coordinated sax. Adding coordinated positive aliases is the same combinatorial trap rejected for B.
2. **Omission sees generated context.** The compiler matches omission against all source-row text, including core; retention sees only request/intent source rows. For request “Two adults playing a trumpet and a tenor saxophone,” appending generated core “An unplayed tenor saxophone” drops sax performance. Repeating “playing a tenor saxophone” explicitly protects it. A request-only omission policy cannot be expressed through the existing applicability keys.
3. **Retention wins contradictions.** “An adult playing a trumpet, no people” keeps trumpet performance. This is compiler precedence, not an explicit user decision. Do not claim no-people always wins.
4. **Per-profile rather than per-instance scope.** “An unplayed trumpet beside an adult playing a trumpet” keeps the trumpet performance component, sensibly covering the played instance, but cannot separately bind a gate to each instance through this mechanism alone.
5. **Bounded recall is intentional.** Holding/display/bare instrument scenes without an approved omission cue keep the old default performance. This is not a regression from the old behavior, but A is not a general object/performance semantic separation.

Narrowing global cue to `no people or hands` reduces accidental matches, but cannot prove global scope: a longer sentence can contain the same phrase in a subordinate region. Do not mistake longer literal cues for grammatical understanding.

## Minimal safe direction and decision boundary

For a targeted repair of the two demonstrated public cases, first evaluate A with **only instrument-qualified unplayed phrases** and matching Korean instrument-qualified forms. Exclude generic `unplayed`, `played`, `hands`, `studio`, `tabletop`, `product`, or generic negative cues; do not build separate instrument AND unplayed groups. This avoids cross-instrument suppression and the verified background no-people failure while preserving normal positive/coordination requests. Keep positive retain aliases noun-bound as protection against conflicting generated context, not as mandatory activation gates.

That subset still has the verified generated-core asymmetry for coordinated requests. It therefore merits a source-local proposal and wider post-core audit only if the release owner accepts that bounded residual risk. If no positive regressions is strict, the right next step is a separately scoped design for request-grounded, instrument-bound omission with explicit conflict policy, rather than more DATA keywords.

Before any implementation: decide whether “fix these known explicit-unplayed cases without changing ordinary positive routing” is the accepted scope, or whether “correct global no-people inference and all positive coordination despite generated core” is required. The latter is not established by this DATA-only mechanism. Preserve original five-component defaults and test dynamic four-component projection as an intentional contract; do not make tests pass by discarding demonstrated positive cases.
