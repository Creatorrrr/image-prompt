import sys,json,copy
from pathlib import Path
O=Path(__file__).resolve().parent;R=Path('REPOSITORY_ROOT');sys.path.insert(0,str(R/'skills/photo-prompt-image-generator/scripts'))
import prompt_generator as g
from visual_profile_contracts import compile_visual_profile
p=json.loads((O.parent/'instrument-object-audit/split-proposal/proposed-full-profiles.json').read_text());old=json.loads((O.parent/'instrument-object-audit/split-proposal/original-profiles.json').read_text())
profiles=[]
for m,a in [(p[0],p[1]),(p[2],p[3])]:
 x=copy.deepcopy(m)
 for k in ['composition_instruction','required_evidence_fields','evidence_requirements','render_gates']:x.pop(k,None)
 x['semantics'].pop('component_semantics');x['activation']=copy.deepcopy(old[m['id']]['activation'])
 c=copy.deepcopy(a['authored_components']['components'][0]);en=['trumpet'] if m==p[0] else ['alto saxophone','tenor saxophone','alto sax','tenor sax'];ko=['트럼펫'] if m==p[0] else ['알토 색소폰','테너 색소폰']
 c['applicability']={'omit_if_any_terms':['no people','사람 없이']+['unplayed '+s for s in en]+['연주하지 않는 '+s for s in ko],'retain_if_requested_any_terms':a['activation']['exact_terms']}
 x['authored_components']['components'].append(c);profiles.append(compile_visual_profile(x))
cases=[('public trumpet','A product still life of an unplayed trumpet on an empty tabletop, no people or hands.',''),('public alto','A product still life of an unplayed alto saxophone on an empty tabletop, no people or hands.',''),('Korean object','사람 없이 탁자 위에 놓인 트럼펫 제품 사진',''),('coordination','Two adults playing a trumpet and a tenor saxophone.',''),('mixed trumpet unplayed','An unplayed trumpet beside an adult playing an alto saxophone.',''),('mixed sax unplayed','An unplayed alto saxophone beside an adult playing a trumpet.',''),('Korean mixed','연주하지 않는 트럼펫 옆에서 알토 색소폰을 연주하는 성인',''),('bare','trumpet and alto saxophone',''),('studio positive','An adult playing trumpet in a product studio on a tabletop set.',''),('scoped no people','Two adults playing a trumpet and a tenor saxophone, no people in the background.',''),('two instances','An unplayed trumpet beside an adult playing a trumpet.',''),('contradiction','An adult playing a trumpet, no people.',''),('core false cue coordinated','Two adults playing a trumpet and a tenor saxophone.',' An unplayed tenor saxophone.'),('core false cue explicit','Two adults playing a trumpet and playing a tenor saxophone.',' An unplayed tenor saxophone.'),('object core performance','An unplayed trumpet, no people.',' An adult playing a trumpet.'),('qualified absence different instrument','An adult plays trumpet while an unplayed alto saxophone rests nearby.','')]
out={'scope':'Read-only compiler projection diagnostic; existing original activation aliases restored; no production index or CLI qualification','cues':{x['id']:x['authored_components']['components'][-1]['applicability'] for x in profiles},'rows':[]}
for label,request,core in cases:
 vals={}
 for p in profiles:
  z=compile_visual_profile(p,request_text=request,context_text=request+core,matches=g.intent_alias_matches);vals[p['id']]={'component_count':len(z['render_gates']),'performance_active':any('playing_contact' in v['id'] for v in z['render_gates'])}
 out['rows'].append({'case':label,'request':request,'extra_core_context':core,'projection_if_profile_activated':vals})
(O/'alternative-a-diagnostic.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
for x in out['rows']:print(x['case'],[v['performance_active'] for v in x['projection_if_profile_activated'].values()])
