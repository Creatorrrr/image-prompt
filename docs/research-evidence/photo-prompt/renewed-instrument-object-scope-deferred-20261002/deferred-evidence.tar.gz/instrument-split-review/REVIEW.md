# Independent review: instrument morphology/performance split

## Verdict

**Revise, then accept for implementation and qualification.** The four morphology plus one performance contract is the right DATA-level repair for the demonstrated unplayed-object bug. Do not ship the proposal verbatim or characterize lexical routing checks as production qualification.

Reviewed `instrument-object-audit/split-proposal/proposed-full-profiles.json`, `original-profiles.json`, `semantic-migration-map.json`, saved routing results, source-local resolver code, current instrument candidate data, and `instrument-object-audit/SOLUTION-COMPARISON.md`. No repository edits, production index writes, embedding calls, or image calls were performed. Independent diagnostics are in `independent-checks.json`.

## Required edits before integration

### 1. Preserve note-appropriate trumpet fingering explicitly

The companion correctly retains right-hand operation and left-hand support. However, “right-hand fingers operate the three piston valves,” the paraphrase “actuate valves,” and rejection `right_hand_only_supporting_without_valve_operation` do not explicitly preserve the earlier candidate safeguard allowing fingers to rest on the valves or press a note-appropriate combination. The source candidate `trumpet_lip_valve_action` still contains that safeguard, but selection of that candidate must not be the only way to obtain it. This is an ambiguity/loss of explicit protection, not proof that the proposal necessarily mandates pressing all three valves.

Use this canonical English performance evidence/match phrase:

“the lips meet the trumpet cup mouthpiece while the left hand supports the instrument and the right-hand fingers rest on or press a note-appropriate combination of the three piston valves”

Use Korean equivalent:

“입술은 트럼펫 컵 마우스피스에 닿고 왼손은 악기를 지지하며 오른손 손가락은 세 피스톤 밸브 위에 놓이거나 음에 맞는 조합으로 밸브를 누름”

Apply consistently in the authored component match/evidence terms and instruction; recompile all derived groups, requirements and composition. Update definition and English/Korean paraphrases to the same resting-or-note-appropriate-fingering interpretation. Keep a coherent embouchure/hand relation; never imply a visibly moving valve is required in a still image. Gate description should be: “Cup-mouthpiece embouchure, right-hand fingers resting on or pressing a note-appropriate valve combination, and left-hand support form a coherent playing relation.” Replace the ambiguous rejection with `right_hand_detached_from_valve_fingering_position` (keep left-hand-operation substitution rejected). Keep existing min 14 for the expanded performance evidence; no weakening is needed.

### 2. Remove unnecessary valve evidence threshold relaxation

Restore trumpet morphology `three_piston_valves.min_content_words` and derived `valve_phrase.min_content_words` to **10**, the old value. The split changes ownership and semantics; it need not relax evidence detail. Use a concrete morphology phrase long enough to support the preserved threshold, for example:

“three individually legible aligned piston valves form a compact brass valve block”

Reflect that wording consistently in authored match/evidence terms and instruction, then compile. The Korean match phrase may remain concise; it is an alias, not the English evidence-length contract. No other downward threshold change is present in the target profiles; moving trumpet playing evidence from min 7 to 14 is a strengthening.

### 3. Preserve useful visibility guidance without reintroducing people

The old whole-profile composition instructions included reflection control (both instruments) and shared-frame visibility (especially sax). The proposal replaces them with generated structural sentences and loses these useful photographic constraints. Preserve reflection-control guidance within a morphology authored component instruction, e.g. trumpet tubing/valve or sax keywork: “Control metal reflections so the valve assembly/keywork remains legible.” Add shared-frame contact visibility to performance instruction when appropriate. Do not put mouth/lips/hands, a mandatory medium/three-quarter performer crop, or performance contact back into object morphology. These are instruction refinements, not extra semantic groups.

## Semantic preservation and ownership

- Existing IDs become morphology-only; their nouns, narrow instrument family, object construction and confounds remain. Trumpet cup and valve requirements now describe actual parts rather than requiring a person. This addresses leakage in more than the old playing gate alone.
- Removing `mouthpiece_away_from_lips` from trumpet morphology is necessary; retain it only as a performance confound. Sax reed/ligature/keywork remain morphology. Removing `reed embouchure` from its concept terms is necessary.
- The obsolete mixed trumpet contrast “a generic gold tube held away from the lips” is removed, but `generic_brass_tube` remains rejected; object-confound meaning is not lost.
- Companion components may be compound relations: contact and hand coordination are one coherent performance invariant, rather than fabricated extra components to satisfy a count test.
- The ten old gate IDs should still exist once each across the four profiles, with exactly the two playing-contact IDs transferred to companions. A gate appearing in both an authored component and its compiled mirror is expected, not a cross-profile collision. Tests must inspect one canonical representation per profile.
- No adult-character hard dependency should be invented. Existing narrow scope and `requires_adult_character: false` are retained, allowing requests without explicit age words.
- Evidence reference additions can reuse existing mechanism evidence, but do not establish new research approval or prove every new lexical alias. Keep dates and claims unchanged.

## Routing assessment

The saved 43-case matrix gives useful scoped evidence: 37 supported expected outcomes and six recognized Korean failures. Phrase-only positive aliases are materially safer for mixed instruments than independent instrument AND generic-playing groups. Bare/holding/display requests retain morphology; explicit supported performance gives two profiles, five gates total. Broad noun triggers on performance companions would undo that separation.

Important limitations must remain explicit:

- `{instrument} 연주 안 함` and `{instrument}을 연주하는 것이 아니다` still activate performance. The matcher does not understand those postposed negations. Redundant hard_activation using the same matching function would not fix this.
- `no trumpet performance` suppresses both morphology and performance, an existing noun-negation limitation rather than clean semantic handling of “show instrument without performance.”
- Simple English `not playing a trumpet` works; this does not establish arbitrary English negation safety. Longer/discontinuous/hypothetical clauses and nominal “performance” used to describe a poster are outside the literal matcher's semantic guarantees.
- The initial matrix's mixed-language coverage is incomplete (mixed ownership was English only). The independent diagnostic adds Korean mixed ownership and longer negation/nominal contexts; see its exact observed IDs.
- Positive alias coverage is bounded: coordination, passive voice, synonyms, and Korean future/other inflections may miss the companion. Do not claim a universal EN/KO instrument-action parser or repair misses with unbounded scene exceptions.

This residual limitation is acceptable for a scoped repair of object-versus-explicit-performance ownership if the release owner accepts it. If comprehensive Korean/English negation correctness is a requirement, defer release pending separately authorized matcher work. Do not alter runtime code as part of this DATA proposal.

## Integration and release checks

1. Apply only four profiles by ID to current registry; never overwrite with stale `proposed-main-registry.json`, which predates unrelated lighting work.
2. Compile authored components and validate schema, mirror consistency, global gate uniqueness and unchanged unrelated profiles.
3. Intentionally migrate historical five-per-profile tests to explicit 4/1 mappings; other old profiles remain unchanged. Assert union of gates/evidence across a performed instrument and morphology-only evidence for objects.
4. Preserve candidate data including note-appropriate trumpet action text. Route prop bindings to morphology and action/contact/body-pose bindings to the companion; test actual binding support rather than only copying expected IDs.
5. Test baseline object public CLI failures, EN/KO positive/holding/display/mixed cases, supported negation and documented unsupported examples. Include open/no-depressed-valves plausible trumpet fingering without demanding all valves depressed.
6. Test post-core discovery cannot reintroduce performance in unplayed still lifes. Initial hard routing alone is insufficient because generated candidate text may contain action evidence later.
7. Refresh the actual visual-profile embedding index with current source-hash validation before production claims. No semantic candidate index refresh is needed if candidate data is unchanged. A lexical in-memory payload is not a production index refresh.
8. Repeat public normal-CLI artifact and composed-prompt auditing on the refreshed index. Verify final object prompts/gates contain no mandatory lips/hands, and performances preserve the correct assigned instrument and note-appropriate hands. Image quality, if later tested, requires separate actual image evidence.

## Independent observed results

Merged into the current registry **in memory**, all ten instrument gates have exactly one profile owner; no duplicate gate IDs occur anywhere in that merged registry. All four supplied compiled profiles are exact fixed points under recompilation.

Both tested Korean mixed-instrument sentences route correctly, as do both English mixed display/play sentences. A clause explicitly repeating `plays` for trumpet and tenor sax activates both companions. However, coordinated “playing a trumpet and a tenor saxophone” activates only trumpet performance. Additional verified false-positive performance cases are “An adult is not currently playing a trumpet,” “트럼펫 연주를 하지 않는 성인,” and “A poster advertising a trumpet performance, no people.” These are materially useful release limitations beyond the six saved Korean rows. Update proposal documentation to name them and avoid implying English negation is generally safe. The “pretending to play” example also matches the positive companion, although whether its visible pose should satisfy the same contact relation depends on intended scene semantics; do not label that automatically incorrect.
