#!/usr/bin/env python3
"""Exhaustive frozen pack comparison with only exact source-leaf reversions."""
from pathlib import Path
import copy,hashlib,json,sys
sys.dont_write_bytecode=True
P=Path(__file__).resolve().parent;R=P.parent.parent/'image-prompt';S=R/'skills/photo-prompt-image-generator/scripts';sys.path.insert(0,str(S));import prompt_generator as g
PID='acetate_channeling_shrinkage_relation';CID='acetate_channeling_emulsion_surface';ANCHOR='image distortion follows the network'
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def diff(a,b,path=''):
 if isinstance(a,dict)and isinstance(b,dict):
  out=[]
  for k in sorted(a.keys()|b.keys()):
   if k not in a:out.append(dict(path=path+'/'+k,before_present=False,after=b[k]))
   elif k not in b:out.append(dict(path=path+'/'+k,before=a[k],after_present=False))
   else:out+=diff(a[k],b[k],path+'/'+k)
  return out
 if isinstance(a,list)and isinstance(b,list):
  # IDs align rows without hiding order. List order changes are recorded separately.
  if a and b and all(isinstance(x,dict)and isinstance(x.get('id'),str)for x in a+b):
   am={x['id']:x for x in a};bm={x['id']:x for x in b}
   if len(am)==len(a)and len(bm)==len(b):
    out=diff(am,bm,path+'/@id')
    if [x['id']for x in a]!=[x['id']for x in b]:out.append(dict(path=path+'/@order',before=[x['id']for x in a],after=[x['id']for x in b]))
    return out
  if len(a)==len(b):return[c for i,(x,y)in enumerate(zip(a,b))for c in diff(x,y,path+'/'+str(i))]
 return []if a==b else[dict(path=path,before=a,after=b)]

def reverse_exact_leaves(obj,path='',restorations=None):
 if restorations is None:restorations=[]
 if isinstance(obj,dict):
  if obj.get('id')==PID and 'component_semantics'in obj and 'evidence_requirements'in obj:
   group=next(x for x in obj['component_semantics']['groups']if x['id']=='image_delamination')
   for terms,p in [(group['any_terms'],path+'/component_semantics/groups/@id/image_delamination/any_terms'),(obj['evidence_requirements']['image_delamination_phrase']['must_mention_any'],path+'/evidence_requirements/image_delamination_phrase/must_mention_any')]:
    assert terms==['image distortion or delamination follows the network','image delamination',ANCHOR],(p,terms)
    terms.pop();restorations.append(p)
  for k,v in obj.items():reverse_exact_leaves(v,path+'/'+k,restorations)
 elif isinstance(obj,list):
  for i,x in enumerate(obj):reverse_exact_leaves(x,path+'/'+str(i),restorations)
 return restorations

m=read(P/'manifest.json');before=read(P/'before/report.json');after=read(P/'after/report.json');bcomp={x['id']:x for x in before['compositions']};acomp={x['id']:x for x in after['compositions']}
assert len(after['cases'])==12 and len(acomp)==31 and len(after['visual_intent_cli'])==4
legacy=read(P/'after/component_legacy_en/pack.json')[0]
new_target=next(x for x in legacy['visual_concept_candidates']['candidates']if x['id']=='visual-concept:'+PID)
new_clarification=next(x for x in legacy['semantic_clarification']['candidates']if x['id']=='clarification:visual-profile:'+PID)
comparisons=[]
for id in m['case_ids']:
 b=read(P/'before'/id/'pack.json')[0];a=read(P/'after'/id/'pack.json')[0]
 assert g.candidate_pack_recompute_id(copy.deepcopy(b))['pack_id']==b['pack_id']
 assert g.candidate_pack_recompute_id(copy.deepcopy(a))['pack_id']==a['pack_id']
 raw=diff(b,a);restored=copy.deepcopy(a);restorations=reverse_exact_leaves(restored);restored['pack_id']=b['pack_id'];derived=[]
 if id=='component_distortion_en':
  target=next(x for x in a['visual_concept_candidates']['candidates']if x['id']=='visual-concept:'+PID)
  clarification=next(x for x in a['semantic_clarification']['candidates']if x['id']=='clarification:visual-profile:'+PID)
  assert target==new_target and clarification==new_clarification
  restored['visual_concept_candidates']['candidates']=[x for x in restored['visual_concept_candidates']['candidates']if x['id']!='visual-concept:'+PID]
  restored['semantic_clarification']['candidates']=[x for x in restored['semantic_clarification']['candidates']if x['id']!='clarification:visual-profile:'+PID]
  derived=[dict(kind='source-supported optional target added',candidate=target,exact_template_case='component_legacy_en'),dict(kind='source-supported optional target clarification added',candidate=clarification,exact_template_case='component_legacy_en')]
 reorders=[]
 if any('/visual_concept_candidates/' in path for path in restorations):
  candidates=restored['visual_concept_candidates']['candidates'];before_order=[x['id']for x in candidates]
  g.candidate_pack_shuffle(candidates,seed='1003|0',scope='visual-concepts')
  after_order=[x['id']for x in candidates]
  reorders.append(dict(path='/visual_concept_candidates/candidates',operation='Production content-hash shuffle rerun after reverting only the exact target source arrays',seed='1003|0',scope='visual-concepts',before=before_order,after=after_order,equals_original_before_order=after_order==[x['id']for x in b['visual_concept_candidates']['candidates']]))
  assert reorders[-1]['equals_original_before_order']
 residual=diff(b,restored)
 comparisons.append(dict(case=id,raw_changes=raw,exact_source_leaf_reversions=restorations,verified_derived_additions=derived,verified_content_hash_reordering=reorders,residual_changes=residual,pack_id_recomputed=True,core_retrieval_identical=b['core_retrieval']==a['core_retrieval'],authorial_core_identical=b['authorial_core']==a['authorial_core'],slots_identical=b['slots']==a['slots'],creative_controls_identical=b['creative_controls']==a['creative_controls'],negative_prompt_identical=b['negative_en']==a['negative_en']))
checks=[]
def check(name,ok):checks.append(dict(name=name,passed=bool(ok)))
check('all_frozen_inputs_unchanged',all(sha(P/f)==h for f,h in m['input_hashes'].items()))
check('after_source_state_constant',read(P/'after/source-start.json')==read(P/'after/source-end.json'))
check('all_12_public_V6_packs_succeeded',all(x['exit_code']==0 and x['contract_version']=='photo-candidate-pack/v6'for x in after['cases']))
check('all_30_valid_complete_audits_match_frozen_after_expectations',all(x['status']==x['expected']for x in after['compositions']if x['id']!='component_distortion_en'))
check('exact_EN_KO_distortion_recovered_target_field_only',all(bcomp[x]['status']=='fail'and len(bcomp[x]['failures'])==1 and bcomp[x]['failures'][0]['field']=='image_delamination_phrase'and acomp[x]['status']=='pass'for x in ['distortion_en','distortion_ko']))
check('legacy_OR_delamination_and_supported_component_routes_still_pass',all(bcomp[x]['status']==acomp[x]['status']=='pass'for x in ['legacy_or_en','delamination_en','component_legacy_en','component_source_ko']))
check('five_coherent_material_controls_pass_unchanged',all(bcomp[x]['status']==acomp[x]['status']=='pass'for x in ['paper_cracks','mud_cracks','glass_cracks','digital_warp','flat_scratches']))
check('five_missing_fields_and_nine_wrong_boundaries_remain_rejected',all(bcomp[x]['status']==acomp[x]['status']=='fail'for x in acomp if acomp[x]['kind']in['missing_binding','wrong_boundary_binding']))
check('all_core_query_slots_controls_and_negatives_identical',all(all(x[k]for k in ['core_retrieval_identical','authorial_core_identical','slots_identical','creative_controls_identical','negative_prompt_identical'])for x in comparisons))
check('separate_AND_candidate_never_selected',all(CID not in x['chosen_candidate_ids']for x in after['compositions']))
check('known_old_false_pass_stays_pass',bcomp['limit_old_anchor_digital']['status']==acomp['limit_old_anchor_digital']['status']=='pass')
check('new_anchor_lexical_false_pass_limits_measured',all(bcomp[x]['status']=='fail'and acomp[x]['status']=='pass'for x in ['limit_new_anchor_digital','limit_new_anchor_label','limit_new_anchor_negated']))
check('Korean_only_literal_binding_stays_rejected',bcomp['limit_korean_distortion_literal']['status']==acomp['limit_korean_distortion_literal']['status']=='fail')
check('invalid_explicit_intent_fixtures_retained_and_all_reject_source_binding',all(x['exit_code']==1 and 'source_text must exactly match' in x['stderr']for x in after['visual_intent_cli']))
changes=[dict(id=id,before=bcomp[id]['status'],after=acomp[id]['status'],kind=acomp[id]['kind'],before_failures=bcomp[id]['failures'],after_failures=acomp[id]['failures'])for id in acomp if bcomp[id]['status']!=acomp[id]['status']]
summary=dict(valid_public_V6_cases=12,valid_qualification_compositions=30,invalid_explicit_intent_fixtures=4,ineligible_before_component_composition=1,raw_after_composition_count=31,raw_after_passes=sum(x['status']=='pass'for x in acomp.values()),raw_after_failures=sum(x['status']=='fail'for x in acomp.values()),checks=checks,all_behavior_checks=all(x['passed']for x in checks),status_changes=changes,component_only_adjunct=dict(before_ineligible=True,before_status=bcomp['component_distortion_en']['status'],after_status=acomp['component_distortion_en']['status'],after_selected_visual_concepts=acomp['component_distortion_en']['chosen_visual_concept_ids'],after_effective_profiles=acomp['component_distortion_en']['effective_profile_ids'],after_effective_gates=acomp['component_distortion_en']['effective_gate_ids'],interpretation='AFTER target discovery and genuine opt-in are observed, but this previously ineligible composition remains excluded from the 30 valid paired measurements.'),pack_comparisons=comparisons,residual_pack_change_cases=[x['case']for x in comparisons if x['residual_changes']],strict_two_leaf_projection_equality=not any(x['residual_changes']for x in comparisons),provider_calls_by_qualification=0,images=0,source_mutations_by_qualification=0)
dump(P/'comparison.json',summary)
print(json.dumps({k:v for k,v in summary.items()if k!='pack_comparisons'},ensure_ascii=False,indent=2))
