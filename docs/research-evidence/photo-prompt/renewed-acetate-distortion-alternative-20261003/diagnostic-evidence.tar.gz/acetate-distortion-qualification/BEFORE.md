# Acetate standalone distortion qualification: frozen BEFORE

Baseline: `f4094afc28403c12f7a88f1a4d9f06f66d5757ef`. All inputs were frozen after the sealed independent two-leaf ACCEPT and before any retrieval. Input manifest SHA-256: `44cfe6dc902632271027cb126c8efcc43a767c9305c9de86ef219594cf4e9874`.

## Result

- Actual public V6 CLI: 12/12 completed. Four supplemental explicit-visual-intent runs are invalid qualification evidence because their frozen source_text is not the full governing request span; all outputs are retained.
- Complete composed-prompt audits: 30 interpretable qualification measurements matched their frozen expectations; 1 additional component-only composition is ineligible BEFORE because its target concept is absent yet it supplies target evidence. The raw count is 30/31 frozen-expectation matches (10 passes, 21 failures: 20 expected rejections plus the 1 orphan-evidence expectation miss).
- Exact EN and KO distortion-only requests activate the correct five-gate hard profile, but their complete compositions fail on the missing standalone distortion anchor. Legacy OR and delamination-only controls pass.
- Component-only standalone distortion has no target optional concept BEFORE. Its full composition is rejected for orphan target evidence, contradicting the frozen pass expectation. This is retained as an ineligible authoring fixture BEFORE, not counted as a missing-anchor qualification result. Canonical legacy EN and source-declared KO component wording discover it without hard activation; frozen authorial opt-in promotes all five original gates and their complete compositions pass.
- All five coherent material controls (paper, mud, glass, flat-screen digital warp, flat scratches) pass their ordinary complete compositions without the target profile. Five omitted evidence fields and nine wrong-boundary evidence replacements are rejected on the active legacy-profile route.
- The separate `acetate_channeling_emulsion_surface` AND-delamination slot candidate is unchanged and is never selected. No slot candidates are selected in the suite.

## Boundaries and limits

- This is source-aware synthetic canonical regression qualification. Production wire enums do not make these organic requests, independent pre-core samples, or natural-query recall evidence. Source-supplied EN/KO exact labels and the actual Korean paraphrase are identified in `qualification-scope.json`. English composition evidence is used on the Korean routes. The Korean-only evidence phrase remains a measured rejection.
- The old profile already permits distortion OR delamination. The accepted addition admits a definite distortion spelling; it does not remove a pre-existing forced physical conjunction.
- Anchor-retaining misleading old `image delamination` prose passes the complete lexical audit even when assigned to a digital caption. New-anchor digital/label/negated cases currently fail the absent anchor; their frozen AFTER expectation is a lexical pass, not a desirable semantic behavior. Missing and wrong-boundary probes are deliberately malformed evidence bindings, not coherent newly authored scenes.
- The exact object count, same-film image ownership, connected raised network, complete outer-border crop, and less-damaged comparison are retained in the coherent film scenes. The Korean source paraphrase explicitly includes delamination and is never represented as a distortion-only scene.
- The differential-shrinkage contract is a posed visual relation. This textual work does not establish chemical causes, measured shrinkage rates, capture year, elapsed history, material diagnosis, physical semantics, rendered quality, or image pixels.
- No provider calls, image generation, installs, source/index/test/runtime edits, or publication occurred. Source hashes and clean Git status match at both ends.

## Preparation integrity

- The standalone component-only composition supplied target evidence even when the target optional concept was not discovered. Its frozen BEFORE pass expectation was wrong: the complete audit correctly rejects unselected-profile evidence. That fixture and expectation remain unchanged. Twelve ordinary CLI route measurements and 30 interpretable complete-audit measurements remain; the ineligible component-only composition and four invalid explicit-intent inputs are reported separately.
- Supplemental explicit-visual-intent fixtures use the exact activation label as source_text instead of the full governing source span. The legacy OR and delamination CLI calls reject that source binding. The two standalone distortion calls stop earlier at the expected missing-anchor error, which masks the same source-text defect. All four are invalid as explicit-intent CLI qualification evidence. Their original frozen expectations and failures remain unchanged; no fixture rescue or rerun occurred. The ordinary public V6 and full-composition routes do not use these files and remain independently valid.
- First preflight retained two Korean exclusion-grounding failures: English `people` was not literal in their Korean active source spans. Only the exclusion token changed to source-literal `사람` before retrieval. The original failed drafts and errors remain under `preflight/attempt-01`; subsequent preflights passed all 12.
- Read-only inspection mispaths and missing optional filenames are preserved in `PREPARATION-LOG.md`. Inputs and compositions were never repaired after observing retrieval.

## Next gate

The ordinary V6/full-composition BEFORE suite is complete; its supplemental explicit-intent suite is invalid as disclosed above. AFTER has not run. Wait for coordinator authorization, approved source application, and genuine changed-text vector/generated-index refresh. Recheck runtime/source attribution against the final integration baseline; any intervening runtime change must be disclosed rather than attributed to this DATA patch alone.

## Checks

- PASS: all_frozen_inputs_unchanged
- PASS: source_runtime_unchanged_through_before
- PASS: public_V6_12_of_12_exit_zero
- PASS: supplemental_explicit_intent_defect_retained
- PASS: full_composition_30_valid_expected_outcomes
- PASS: exact_EN_KO_and_both_legacy_routes_hard_activate
- PASS: component_distortion_ineligible_composition_retained
- PASS: component_distortion_before_not_discovered
- PASS: source_legacy_EN_KO_components_opt_in_five_gates
- PASS: coherent_control_routes_exclude_target
- PASS: separate_AND_candidate_always_unselected
- PASS: five_missing_fields_rejected
- PASS: nine_wrong_boundary_bindings_rejected
- PASS: old_anchor_false_pass_retained
- PASS: korean_only_literal_binding_remains_rejected
