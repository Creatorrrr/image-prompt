from pathlib import Path
import copy,json,sys,subprocess,hashlib
sys.dont_write_bytecode=True
P=Path(__file__).resolve().parent;R=P.parent.parent/'image-prompt';S=R/'skills/photo-prompt-image-generator/scripts';sys.path.insert(0,str(S));import prompt_generator as g
read=lambda p:json.loads(p.read_text());dump=lambda p,x:p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
case='component_distortion_en';d=P/'inputs'/case;data=g.load_runtime_data();core=read(P/'after'/case/'pack.json')[0]['authorial_core'];ctl=read(d/'controls.json');rev=read(d/'review.json');old_data=dict(data);old_reg=copy.deepcopy(data[g.VISUAL_OBLIGATIONS_DATA_KEY]);old_reg['profiles']=[read(P/'source-freeze/acetate-distortion-review/compiled-before.json')if x['id']=='acetate_channeling_shrinkage_relation'else x for x in old_reg['profiles']];old_idx=json.loads(subprocess.check_output(['git','show','HEAD:skills/photo-prompt-image-generator/assets/photo_prompt_visual_profile_index.json'],cwd=R));g.validate_visual_profile_index_metadata(old_idx,old_reg);old_data[g.VISUAL_OBLIGATIONS_DATA_KEY]=old_reg;old_data[g.VISUAL_PROFILE_INDEX_DATA_KEY]=old_idx
out={}
for name,selected in [('before',old_data),('after',data)]:
 result=g.prepare_candidate_source(selected,core,ctl,rev,seed=1003);trace=result['semantic_trace'];resolution=g.candidate_pack_resolve_visual_profiles(selected,result,trace,None);ob=g.candidate_pack_visual_obligations(selected,result,trace,None,resolution);vc=g.candidate_pack_visual_concept_candidates(selected,result,trace,None,ob,resolution);clar=g.candidate_pack_semantic_clarification(selected,result,trace,ob,vc,resolution);actual=read(P/name/case/'pack.json')[0]['semantic_clarification'];assert clar==actual,(name,'not exact actual clarification')
 out[name]=dict(resolution=resolution,clarification_ids=[x['id']for x in clar['candidates']],exact_actual_public_clarification_reproduced=True,retrieval_policy=selected[g.VISUAL_PROFILE_INDEX_DATA_KEY]['retrieval_policy'])
assert out['before']['resolution']['query_sha256']==out['after']['resolution']['query_sha256']
out['classification']='Reproduced bounded optional BM25F resolver membership change at unchanged candidate_limit 8. This is an explicitly recorded non-target clarification residual; no general-field exemption or source modification was made.'
dump(P/'clarification-residual-diagnosis.json',out)
for name in ['before','after']:print(name,'BM25F',out[name]['resolution']['bm25f_evaluated'],'embedding',out[name]['resolution']['embedding_evaluated'],'limit',out[name]['retrieval_policy']['candidate_limit'],[(x['profile_id'],x['match_basis'],x['applicability_status'])for x in out[name]['resolution']['hits']])
