"""Independent, provider-free review. Writes only this outside-repository folder."""
from pathlib import Path
import copy
import difflib
import hashlib
import json
import subprocess
import sys

sys.dont_write_bytecode = True
R = Path('REPOSITORY_ROOT')
OUT = Path(__file__).resolve().parent
IN = OUT.parent / 'wear-damage-audit'
A = R / 'skills/photo-prompt-image-generator/assets'
S = A.parent / 'scripts'
PID = 'acetate_channeling_shrinkage_relation'
FIELD = 'image_delamination_phrase'
ANCHOR = 'image distortion follows the network'
HEAD = 'f4094afc28403c12f7a88f1a4d9f06f66d5757ef'
TARGET = 'skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations_photo_era.json'

def sha(b): return hashlib.sha256(b).hexdigest()
def canonical(x): return sha(json.dumps(x, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode())
def dump(name, data): (OUT / name).write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')
def git(*args): return subprocess.check_output(['git', *args], cwd=R, text=True)
def changes(a, b, path=''):
    if isinstance(a, dict) and isinstance(b, dict):
        assert a.keys() == b.keys()
        return [c for k in a for c in changes(a[k], b[k], path + '/' + k)]
    if isinstance(a, list) and isinstance(b, list) and len(a) == len(b):
        return [c for i, (v, w) in enumerate(zip(a, b)) for c in changes(v, w, path + '/' + str(i))]
    return [] if a == b else [{'path': path, 'before': a, 'after': b}]
def caught(fn):
    try: return {'ok': True, 'value': fn()}
    except ValueError as e: return {'ok': False, 'error': str(e)}

assert git('rev-parse', 'HEAD').strip() == HEAD
status_before = git('status', '--short')
assert status_before == ''
input_manifest = Path(sys.argv[1])
assert input_manifest.is_file(), 'Wait for the frozen proposal manifest'
frozen_manifest = json.loads(input_manifest.read_text())
frozen_input_hashes = {str(p.relative_to(IN)): sha(p.read_bytes()) for p in IN.rglob('*') if p.is_file()}
raw_bytes = (R / TARGET).read_bytes()
source_document = json.loads(raw_bytes)
profile_position = next(i for i, p in enumerate(source_document['profiles']) if p['id'] == PID)
old = source_document['profiles'][profile_position]
new = copy.deepcopy(old)
assert old == json.loads((IN / 'before-profile.json').read_text())
new['semantics']['component_semantics']['groups'][3]['any_terms'].append(ANCHOR)
new['evidence_requirements'][FIELD]['must_mention_any'].append(ANCHOR)
assert new == json.loads((IN / 'proposed-profile.json').read_text())
raw_changes = changes(old, new)
assert {c['path'] for c in raw_changes} == {
    '/semantics/component_semantics/groups/3/any_terms',
    '/evidence_requirements/image_delamination_phrase/must_mention_any',
}
original_file = R / 'docs/research-evidence/photo-prompt/photo-era-visual-semantics-20260905/candidate-data-proposal.json'
original = json.loads(original_file.read_text())
original_profile = next(p for p in original['proposed_profiles'] if p['id'] == PID)
original_candidate = next(p for p in original['proposed_candidates'] if p['id'] == 'acetate_channeling_emulsion_surface')
assert original_profile['components'][3] == 'image distortion or delamination follows the network'
assert original_candidate['en'] == 'acetate-film emulsion surface with channeling and delamination'
assert original_candidate['ko'] == '채널링과 박리가 보이는 아세테이트 유제 표면'
candidate_path = A / 'photo_prompt_photo_era_extension.json'
candidate = next(p for rows in json.loads(candidate_path.read_text())['slots'].values() for p in rows if p['id'] == original_candidate['id'])
assert candidate['en'] == original_candidate['en'] and candidate['ko'] == original_candidate['ko']
assert len(old['render_gates']) == 5
assert old['semantics']['component_semantics']['minimum_component_groups'] == 5
assert len(old['required_evidence_fields']) == 5
assert old['render_gates'] == new['render_gates']
assert old['activation'] == new['activation']
assert old['runtime_expression'] == new['runtime_expression']
assert old['composition_instruction'] == new['composition_instruction']
for before_terms, after_terms in [
    (old['semantics']['component_semantics']['groups'][3]['any_terms'], new['semantics']['component_semantics']['groups'][3]['any_terms']),
    (old['evidence_requirements'][FIELD]['must_mention_any'], new['evidence_requirements'][FIELD]['must_mention_any']),
]: assert after_terms == before_terms + [ANCHOR]

runtime_hashes_before = {str(p.relative_to(R)): sha(p.read_bytes()) for p in S.glob('*.py')}
sys.path.insert(0, str(S))
import prompt_generator as pg
import audit_composed_prompt as ac
reg_old = pg.load_visual_obligation_registry(A / 'photo_prompt_visual_obligations.json')
index = pg.load_visual_profile_index(A / 'photo_prompt_visual_profile_index.json', reg_old)
compiled_old = next(p for p in reg_old['profiles'] if p['id'] == PID)
compiled_new = pg.compile_visual_profile(new)
assert compiled_old == old == pg.compile_visual_profile(old)
assert compiled_new == new
assert changes(compiled_old, compiled_new) == raw_changes
reg_new = copy.deepcopy(reg_old)
reg_new['profiles'] = [compiled_new if p['id'] == PID else p for p in reg_old['profiles']]
obligations = [pg.candidate_pack_visual_profile_obligation(p, r, activation_source='independent_review', source_intent_ids=[]) for p, r in [(old, reg_old), (new, reg_new)]]

evidence = {
    'plastic_film_support_phrase': 'A translucent plastic film support presents its intact outer border and attached picture layer.',
    'differential_shrinkage_phrase': 'The support and emulsion shrink at different rates, leaving raised local buckles on the negative.',
    'channel_network_phrase': 'A curving connected channel or wrinkle network travels continuously through the buckled photographic object.',
    FIELD: 'The image distortion follows the network, bending the pictured roofline while the emulsion stays visibly attached.',
    'less_damaged_edge_phrase': 'A less-damaged edge comparison retains flatter readable image detail alongside the wrinkled central area.',
}
def audit(ev, obligation):
    contract = {
        'enabled': True, 'contract_version': pg.VISUAL_OBLIGATIONS_CONTRACT_VERSION,
        'scope': 'request_only', 'strict_gate_set': True, 'obligations': [obligation],
        'required_hard_gates': [g['id'] for g in obligation['render_gates']],
    }
    return ac.audit_visual_obligations({'visual_obligations': contract}, {'visual_obligation_evidence': {PID: ev}}, ' '.join(ev.values()))
def probe(ev, profile, registry, obligation, source_text=None):
    source_text = source_text or old['activation']['exact_terms'][0]
    payload = {'contract_version': pg.VISUAL_INTENT_CONTRACT_VERSION, 'provenance': 'agent_prepack', 'obligations': [{
        'profile_id': PID, 'source': 'explicit_user_requirement', 'scope': 'request_only', 'source_text': source_text, 'bindings': ev,
    }]}
    return {
        'component_match': pg.candidate_pack_visual_component_match(profile, ' '.join(ev.values())),
        'normalized_intent': caught(lambda: pg.normalize_visual_intent(payload, registry)),
        'audit_failures': audit(ev, obligation),
    }
def pair(ev): return [probe(ev, p, r, o) for p, r, o in [(old, reg_old, obligations[0]), (new, reg_new, obligations[1])]]
positive = pair(evidence)
assert positive[0]['component_match'] is None
assert not positive[0]['normalized_intent']['ok']
assert len(positive[0]['audit_failures']) == 1 and positive[0]['audit_failures'][0]['field'] == FIELD
assert positive[1]['component_match'] == 'component_semantics'
assert positive[1]['normalized_intent']['ok'] and not positive[1]['audit_failures']

old_anchors = []
for anchor in old['evidence_requirements'][FIELD]['must_mention_any']:
    ev = {**evidence, FIELD: anchor + ' along the central physical photographic layer'}
    results = pair(ev)
    assert all(x['component_match'] == 'component_semantics' and x['normalized_intent']['ok'] and not x['audit_failures'] for x in results)
    old_anchors.append({'anchor': anchor, 'results': results})
omissions = []
for field in evidence:
    ev = {k: v for k, v in evidence.items() if k != field}
    results = pair(ev)
    assert results[1]['component_match'] is None and results[1]['audit_failures']
    assert any(x.get('field') == field for x in results[1]['audit_failures'])
    omissions.append({'omitted_field': field, 'results': results})
negative_specs = [
    ('paper', 'plastic_film_support_phrase', 'An opaque fiber paper sheet has surface cracks at the corner.'),
    ('mud', 'plastic_film_support_phrase', 'A dried mud bed breaks into raised polygonal clay plates.'),
    ('glass', 'plastic_film_support_phrase', 'A glass pane has radiating fractures around a central impact point.'),
    ('digital_warp', FIELD, 'A digital warp bends the whole JPEG uniformly on a flat screen.'),
    ('water_filter', FIELD, 'A ripple filter undulates a screen image in evenly spaced horizontal bands.'),
    ('scratch', 'channel_network_phrase', 'Straight flat scratches run independently across the photograph.'),
    ('wrong_owner', FIELD, 'A neighboring paper label is bent while the negative image remains flat.'),
    ('no_comparison', 'less_damaged_edge_phrase', 'Uniform damage covers the negative continuously to every outer boundary.'),
    ('no_differential_relation', 'differential_shrinkage_phrase', 'The undifferentiated surface has an arbitrary decorative wrinkle pattern.'),
]
negatives = []
for label, field, text in negative_specs:
    ev = {**evidence, field: text}
    results = pair(ev)
    assert all(x['component_match'] is None and not x['normalized_intent']['ok'] and x['audit_failures'] for x in results)
    assert any(x.get('field') == field for x in results[1]['audit_failures'])
    negatives.append({'label': label, 'field': field, 'text': text, 'results': results})

routes = []
route_texts = old['activation']['exact_terms'] + [
    'old damaged photograph', '낡고 손상된 사진', 'acetate channeling', '아세테이트 채널링',
    'image distortion follows the network', 'digital warp of a JPEG', '디지털 왜곡 필터',
    'dry mud polygon cracks', '건조한 진흙 균열', 'cracked glass', '깨진 유리',
    'flat scratches over a photograph', '평평한 사진 위의 스크래치',
    'This damage proves the photo was captured in 1925', '이 손상은 사진의 정확한 촬영 연도를 증명한다',
    'Diagnose vinegar syndrome from a wrinkle', '주름으로 아세테이트의 화학 열화 원인을 진단한다',
]
for i, text in enumerate(route_texts):
    source_rows = [{'source': 'concept_lock', 'text': text, 'polarity': 'required', 'priority': 'critical', 'mandatory': True}]
    result = [pg.candidate_pack_auto_visual_obligation_matches(r, source_rows) for r in [reg_old, reg_new]]
    assert result[0] == result[1]
    assert (PID in result[0]) == (i < 2)
    routes.append({'text': text, 'before': result[0], 'after': result[1]})
assert pg.visual_profile_exact_term_rows(reg_old) == pg.visual_profile_exact_term_rows(reg_new)
ko_paraphrase = old['semantics']['paraphrase_examples'][0]
ko_paraphrase_result = [pg.candidate_pack_visual_component_match(p, ko_paraphrase) for p in [old, new]]
assert ko_paraphrase_result == ['semantic_paraphrase_example'] * 2
ko_binding = '이어진 망을 따라 필름 이미지가 왜곡되고 유제는 지지체에 붙어 있다'
ko_binding_result = [caught(lambda p=p: pg.validate_visual_intent_binding(obligation_index=0, field=FIELD, phrase=ko_binding, requirement=p['evidence_requirements'][FIELD])) for p in [old, new]]
assert all(not r['ok'] for r in ko_binding_result)

# These intentionally false anchor-preserving cases bound what the lexical probe proves.
semantic_limits = []
for label, phrase in [
    ('old_anchor_digital', 'image delamination is merely printed as a caption on a digital warp'),
    ('new_anchor_digital', 'image distortion follows the network only in a digital simulation on a flat screen'),
    ('new_anchor_wrong_owner', 'image distortion follows the network is text on a nearby label beside the unchanged film'),
    ('new_anchor_negated', 'There is no image distortion follows the network; the photographic layer is flat'),
]:
    result = pair({**evidence, FIELD: phrase})
    semantic_limits.append({'label': label, 'phrase': phrase, 'results': result})
assert not semantic_limits[0]['results'][0]['audit_failures'] and not semantic_limits[0]['results'][1]['audit_failures']
assert not semantic_limits[1]['results'][1]['audit_failures']

texts = [pg.visual_profile_semantic_text(p) for p in [old, new]]
fields = [pg.visual_profile_bm25f_fields(p) for p in [old, new]]
assert texts[0] != texts[1]
assert fields[1]['visual_components'] == fields[0]['visual_components'][:7] + [ANCHOR] + fields[0]['visual_components'][7:] or set(fields[1]['visual_components']) - set(fields[0]['visual_components']) == {ANCHOR}
assert [k for k in fields[0] if fields[0][k] != fields[1][k]] == ['visual_components']
stale = caught(lambda: pg.validate_visual_profile_index_metadata(index, reg_new))
assert not stale['ok'] and 'registry_sha256' in stale['error']
index_impact = {
    'text_before_sha256': sha(texts[0].encode()), 'text_after_sha256': sha(texts[1].encode()),
    'registry_before_sha256': pg.visual_profile_registry_sha256(reg_old), 'registry_after_sha256': pg.visual_profile_registry_sha256(reg_new),
    'positive_field_changes': changes(fields[0], fields[1]), 'exact_lookup_unchanged': True,
    'old_index_rejection': stale, 'candidate_unchanged_sha256': canonical(candidate),
    'required': 'Genuine changed-text vector/index refresh and public before/after qualification after publication pause. Never rebind the old vector to the new digest.',
    'ranking_or_public_pipeline_qualified': False,
}

for name, data in [
    ('raw-before.json', old), ('raw-accepted.json', new),
    ('compiled-before.json', compiled_old), ('compiled-accepted.json', compiled_new),
    ('obligation-before.json', obligations[0]), ('obligation-accepted.json', obligations[1]),
    ('accepted-changed-leaves.json', raw_changes), ('index-consequences.json', index_impact),
    ('source-lineage.json', {'original_profile': original_profile, 'original_candidate': original_candidate, 'current_candidate': candidate}),
]: dump(name, data)
for label, text in zip(['before', 'accepted'], texts): (OUT / ('positive-text-' + label + '.txt')).write_text(text + '\n')
new_document = copy.deepcopy(source_document)
new_document['profiles'][profile_position] = new
proposed_bytes = (json.dumps(new_document, ensure_ascii=False, indent=2) + '\n').encode()
# Whole-file reserialization is permitted only if its complete difference is these four added lines.
assert (json.dumps(source_document, ensure_ascii=False, indent=2) + '\n').encode() == raw_bytes
patch = ''.join(difflib.unified_diff(raw_bytes.decode().splitlines(keepends=True), proposed_bytes.decode().splitlines(keepends=True), fromfile='a/' + TARGET, tofile='b/' + TARGET))
(OUT / 'accepted-two-leaf.patch').write_text(patch)
dump('independent-proof.json', {
    'head': HEAD, 'evidence': evidence, 'distortion_positive_before_after': positive,
    'old_anchor_controls': old_anchors, 'five_component_evidence_omissions': omissions,
    'negative_replacements': negatives, 'exact_route_controls': routes,
    'korean': {'unchanged_authored_paraphrase': ko_paraphrase, 'paraphrase_match_before_after': ko_paraphrase_result, 'unauthored_korean_binding': ko_binding, 'binding_before_after': ko_binding_result},
    'semantic_limit_controls': semantic_limits,
    'limits': 'In-memory literal consumer qualification only. No public CLI, ranking, image generation, pixel review, empirical diagnosis, provider, installation, repository mutation or publication.',
})
assert git('rev-parse', 'HEAD').strip() == HEAD
assert git('status', '--short') == status_before
assert (R / TARGET).read_bytes() == raw_bytes
assert runtime_hashes_before == {str(p.relative_to(R)): sha(p.read_bytes()) for p in S.glob('*.py')}
assert frozen_input_hashes == {str(p.relative_to(IN)): sha(p.read_bytes()) for p in IN.rglob('*') if p.is_file()}
dump('review-input-binding.json', {
    'head': HEAD, 'status_before_and_after': status_before,
    'proposal_manifest': str(input_manifest), 'proposal_manifest_sha256': sha(input_manifest.read_bytes()),
    'input_artifacts': frozen_input_hashes, 'runtime_files': runtime_hashes_before,
    'source_file_sha256': sha(raw_bytes), 'accepted_file_sha256': sha(proposed_bytes),
    'raw_before_sha256': canonical(old), 'raw_accepted_sha256': canonical(new),
    'index_file_sha256': sha((A / 'photo_prompt_visual_profile_index.json').read_bytes()),
    'original_proposal_sha256': sha(original_file.read_bytes()),
})
print(json.dumps({'result': 'ACCEPT_TWO_LEAF_DATA_PROPOSAL', 'leaves': 2, 'distortion_before': 'fails', 'distortion_after': 'passes', 'omissions': len(omissions), 'negative_replacements': len(negatives), 'route_controls': len(routes), 'old_anchor_controls': len(old_anchors), 'index_refresh_required': True}))
