# Independent acetate distortion alternative review

## Decision

**ACCEPT the frozen two-leaf DATA proposal, without revision or repository application.** Add `image distortion follows the network` to the existing component and evidence-anchor arrays for `acetate_channeling_shrinkage_relation`. Preserve every existing anchor, ID, field, minimum, gate, activation term and separate optional candidate.

This repairs **asymmetric literal acceptance of an already-authored alternative**. It does not remove a physical requirement for simultaneous distortion and delamination: the baseline has no such requirement. Its combined OR sentence already truthfully represents a distortion-only scene. The benefit is accepting a definite distortion clause without forcing the composer to repeat the disjunction or use the narrower delamination alias.

Main publication is paused for the separate runtime integration window. This decision authorizes no publication and claims no post-window compatibility. Recheck the final runtime and DATA baseline before subsequent integration.

## Frozen inputs and independent execution

- Reviewed clean repository `f4094afc28403c12f7a88f1a4d9f06f66d5757ef`
- Proposal `wear-damage-audit/artifact-manifest.json` SHA-256 `975b424db6a496577eac9e2c2e4958fce3c757939114d6786a56b684da729ff2`
- Independently verified all 29 proposal artifact hashes and byte counts
- Independently read current source records, original research proposal, evidence ledger, source report, production compiler, discovery helper, visual-intent normalization, composed audit, positive-text projection and index metadata validation
- `reproduce_review.py` reconstructs the proposal from current raw source, verifies equality with the frozen proposal, builds new evidence independently, and runs production consumers in memory
- The script did not import or invoke the proposal author's qualification script or use its test evidence
- Repository HEAD, clean status, exact DATA source bytes, all script hashes and all frozen audit artifacts were unchanged across execution
- `git apply --check` passed for the saved patch; it was not applied

File hashes, complete raw/compiled before and accepted records, complete emitted obligations, source lineage and complete consumer outputs accompany this report. Record hashes use compact sorted-key UTF-8 JSON; file hashes use exact bytes.

## Source authority and selected scope

The original `docs/research-evidence/photo-prompt/photo-era-visual-semantics-20260905/candidate-data-proposal.json`, `/proposed_profiles/16`, explicitly selects five components:

1. `plastic film support`
2. `support and emulsion shrink at different rates`
3. `curving connected channel or wrinkle network`
4. `image distortion or delamination follows the network`
5. `less-damaged edge comparison`

Its native deformation gate requires the image to deform with that network. The current definition and composition retain the same OR. The proposed definite branch is therefore a strict spelling-out of an already-authored alternative, not an inferred expansion from unrelated damaged-material examples.

The original `/proposed_candidates/52` and current `photo_prompt_photo_era_extension.json`, `/slots/surface_material/7`, expressly select `acetate-film emulsion surface with channeling and delamination`. Korean `채널링과 박리가 보이는 아세테이트 유제 표면` also commits to channeling and delamination. That complete current record remains unchanged, canonical hash `c53bbaffd6fc8d2af2fe8a8ca6fd8bf4132174c253949cba361225b6cee44fe7`. Selecting it would still introduce delamination; it must not be used as a distortion-only stand-in.

The source ledger's `cci_plastic_negatives` record calls for film support and image distortion tied to a continuous channel network. It limits identification of specific plastic bases and cautions that not every wrinkle network is acetate channeling. `loc_negative_deterioration` describes deformation/obscuring and requires native-scale review. These are existing repository research records, not fresh scientific verification. No external conservation page was reopened, and this review does not certify a chemical diagnosis.

## Exact accepted patch

File: `skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations_photo_era.json`

Profile: `/profiles/16`, ID `acetate_channeling_shrinkage_relation`

Append the single new string to exactly:

- `/semantics/component_semantics/groups/3/any_terms`
- `/evidence_requirements/image_delamination_phrase/must_mention_any`

Both arrays change from:

```json
["image distortion or delamination follows the network", "image delamination"]
```

to:

```json
["image distortion or delamination follows the network", "image delamination", "image distortion follows the network"]
```

`accepted-two-leaf.patch` has only these two array edits. The complete file reserializes identically before modification; its proposed byte hash is `7421ff9fe26934f2a71a0725b1ae9a17c36467e1612a3330ba91c1da97585378`.

Raw profile hashes:

- Before: `48974fe6ea8781a791e8a85342d0bb39d76ac2dc5f4fdbfb52aba56deca625cb`
- Accepted: `a602d1044b1f90130148870f8d0c57929d7b7c3b6e242d4b9b5db1b6e3102558`

This profile has no `authored_components` source. The production compiler returns the legacy profile unchanged, so raw and compiled profile differences are exactly the same two leaves. Materialized obligation differences are the corresponding component and evidence arrays. The field/group name containing `delamination` is a stable ID; it is not rewritten.

## Required relations and gates stay intact

The minimum remains five required component groups and five distinct literal evidence phrases. All five required field IDs, per-field minimum of two content words, and all gate IDs/scales/descriptions are unchanged.

| Gate | Scale | Preserved visible duty |
|---|---|---|
| `_1` | thumbnail | Visible physical film-support edge |
| `_2` | both | Material continuity of the connected channel network |
| `_3` | native | Image deformation belongs to and follows the network |
| `_4` | native | Less-damaged edge comparison remains |
| `_5` | both | Paper and glass textures do not substitute |

The film substrate, photographic image-layer owner, differential-shrinkage relation, connected network and less-affected comparison are not optionalized. Activation, exclusions, definition, concept terms, runtime expression, composition, reject substitutes and evidence policy are unchanged. The change does not introduce generic damage, scratch, digital-warp or non-film routes.

## Independent consumer results

The new positive clause is:

> The image distortion follows the network, bending the pictured roofline while the emulsion stays visibly attached.

It is paired with independently authored support, differential-shrinkage, connected-network and less-damaged-comparison phrases. The complete input and returned values are in `independent-proof.json`.

| Check | Before | Accepted in memory |
|---|---|---|
| Complete component discovery | No component match | `component_semantics` |
| Normalized visual-intent bindings | Rejects distortion field anchor | Passes |
| Composed visual-obligation audit | One distortion-field anchor failure | No failures |
| Both original anchors | Pass | Pass |
| Each of five omitted duties | Incomplete component/audit | Incomplete component/audit |
| Nine negative replacement scenes | Reject | Reject |
| Nineteen EN/KO exact-route controls | Baseline results | Identical results |

The nine replacements cover paper, dry mud, cracked glass, digital JPEG warp, ripple filter, unrelated flat scratches, deformation belonging to a nearby label, loss of the comparison region, and loss of the differential-shrinkage relation. These fail the targeted field or complete component match. Partial visual-intent bindings remain legal at normalization, as before; missing mandatory duties are caught by the full composed audit. The omission results must not be misreported as normalization rejecting incomplete binding dictionaries.

## English and Korean coverage

Both authored exact terms are preserved and continue to hard-route identically:

- `acetate film channeling and shrinkage relation`
- `아세테이트 필름 채널링 수축 관계`

The complete existing Korean paraphrase still produces `semantic_paraphrase_example`, not hard activation or five independently validated Korean components. It describes the combined wrinkling/delamination manifestation and is not changed. The English definite distortion anchor is the only new lexical branch.

English and Korean generic damage, short acetate labels, digital effects, mud, glass, scratch, capture-date and diagnosis-only requests do not hard-activate this profile in the measured exact-route controls. No broad trigger is added. A Korean-only distortion evidence phrase fails before and after because the current binding tokenizer reports zero content words. Korean-only literal binding support is therefore **not** claimed or added by this English-anchor patch.

## Physical and temporal limits

These consumers validate lexical presence, authored component coverage and literal prompt binding. They do not inspect pixels or establish physical truth. Deliberate anchor-preserving controls show the limit:

- An untouched delamination anchor followed by digital-caption wording passes discovery, binding and audit before and after
- New-anchor wording attached to a digital simulation or nearby printed label passes the same lexical helpers after the proposal
- Negating either the old delamination anchor or new distortion anchor defeats component discovery but still passes literal binding and composed audit

The last result is independently confirmed for the old alias in `supplemental-negation-control.json`; it is an existing difference between negation-aware discovery and literal evidence validation. Adding a supported anchor extends the same weakness to that string. No robust semantic, causal or physical-negative rejection is claimed. Broad runtime repair is outside this DATA patch.

Saved-image review must still establish that the visible film carries the depicted image, its deformation follows the continuous material network, and a less-affected comparison remains. A still image cannot measure actual relative shrinkage rates, establish exact chemical cause, identify every plastic base, or prove capture date, age, original authenticity, storage duration/history or exposure history. The research distinguishes deterioration from capture look and retro simulation; this patch preserves that separation and adds no temporal or diagnostic authority.

## Positive text and index consequences

Only the positive `visual_components` field gains the one definite distortion string. Aliases, definition, paraphrases and support cues remain identical; complete exact lookup remains identical. Nevertheless, positive retrieval text changes:

- Before semantic-text hash, excluding file newline: `bb755256619ed991f2b974a6b1fd856df4db6f7fcd8f150634a79018b20579ea`
- Accepted: `6b35cc8d1d1f101bde6531c4a1346ff842c49d111cc1d64e22be126964720a60`
- Compiled registry before: `f8faefa466cf29431c3d1acd38b72d9dfc0b879618998d972643f6683a00236a`
- Compiled registry accepted: `a3e216f9528a1132e78a591cdb9bd1804c0a628d2e7c68b74510c76aa42e5fcc`

The genuine currently bound visual-profile index rejects the proposed registry with a `registry_sha256` mismatch. Subsequent authorized integration requires a genuine changed-text embedding and generated index/BM25F refresh, plus frozen public before/after qualification. Never relabel the old vector with a new digest. The unchanged optional candidate supplies no candidate semantic-index text change.

No provider calls, installs, vectors, new index, public CLI, retrieval-ranking comparison, generated image, pixel pass or publication were performed. Acceptance is a source and bounded consumer decision; index/public-pipeline and image-quality qualification remain outstanding after the separate runtime window.
