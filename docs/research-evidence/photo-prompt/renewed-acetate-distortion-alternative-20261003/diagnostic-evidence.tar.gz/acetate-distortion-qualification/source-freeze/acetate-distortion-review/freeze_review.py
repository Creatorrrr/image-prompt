"""Read-only final verification; freeze this independent review's artifact hashes."""
from pathlib import Path
import hashlib
import json
import subprocess

O = Path(__file__).resolve().parent
R = O.parent.parent / 'image-prompt'
I = O.parent / 'wear-damage-audit'
EXPECTED = '975b424db6a496577eac9e2c2e4958fce3c757939114d6786a56b684da729ff2'
sha = lambda b: hashlib.sha256(b).hexdigest()
def save(n, d): (O / n).write_text(json.dumps(d, ensure_ascii=False, indent=2) + '\n')
def git(*a): return subprocess.check_output(['git', *a], cwd=R, text=True)
manifest_bytes = (I / 'artifact-manifest.json').read_bytes()
assert sha(manifest_bytes) == EXPECTED
inputs = json.loads(manifest_bytes)
assert len(inputs) == 29
for row in inputs:
    b = (I / row['path']).read_bytes()
    assert sha(b) == row['sha256'] and len(b) == row['bytes']
binding = json.loads((O / 'review-input-binding.json').read_text())
assert git('rev-parse', 'HEAD').strip() == binding['head']
assert git('status', '--short') == binding['status_before_and_after'] == ''
for path, expected in binding['runtime_files'].items():
    assert sha((R / path).read_bytes()) == expected
for path, expected in binding['input_artifacts'].items():
    assert sha((I / path).read_bytes()) == expected
target = 'skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations_photo_era.json'
assert sha((R / target).read_bytes()) == binding['source_file_sha256']
assert sha((R / 'skills/photo-prompt-image-generator/assets/photo_prompt_visual_profile_index.json').read_bytes()) == binding['index_file_sha256']
subprocess.run(['git', 'apply', '--check', str(O / 'accepted-two-leaf.patch')], cwd=R, check=True)
proof = json.loads((O / 'independent-proof.json').read_text())
impact = json.loads((O / 'index-consequences.json').read_text())
save('decision.json', {
    'decision': 'ACCEPT_TWO_LEAF_DATA_PROPOSAL_WITHOUT_REVISION',
    'applied': False, 'published': False, 'main_publication_paused': True,
    'head_reviewed': binding['head'], 'proposal_manifest_sha256': EXPECTED,
    'patch': 'accepted-two-leaf.patch', 'patch_sha256': sha((O / 'accepted-two-leaf.patch').read_bytes()),
    'profile': 'acetate_channeling_shrinkage_relation', 'source_file': target,
    'append_exactly': 'image distortion follows the network',
    'leaf_paths': [r['path'] for r in json.loads((O / 'accepted-changed-leaves.json').read_text())],
    'source_scope': 'Definite spelling of an original OR alternative. Baseline already accepts the truthful combined OR anchor; no physical mandatory conjunction is alleged.',
    'preserve': ['all old anchors', 'all five relations and evidence fields', 'all five gates and scales', 'exact activation and exclusions', 'film substrate and image-layer owner', 'network continuity', 'less-damaged comparison', 'temporal, cause and diagnosis limits', 'narrow channeling-and-delamination candidate'],
    'independent_controls': {
        'old_anchor_positive': len(proof['old_anchor_controls']),
        'omitted_duties': len(proof['five_component_evidence_omissions']),
        'negative_replacements': len(proof['negative_replacements']),
        'exact_routes': len(proof['exact_route_controls']),
        'semantic_limit_controls': len(proof['semantic_limit_controls']) + 1,
    },
    'positive_text_changes': True, 'exact_lookup_unchanged': impact['exact_lookup_unchanged'],
    'required_next': [
        'Honor the separate runtime integration/publication pause.',
        'Recheck against the final runtime and DATA baseline before integration.',
        'After integration is authorized, apply only the frozen two-leaf patch.',
        'Perform genuine changed-text vector and generated visual-profile index/BM25F refresh.',
        'Run frozen public before/after qualification; do not claim ranking or image quality from this review.',
    ],
    'critical_limits': [
        'Anchor-preserving misleading digital/wrong-owner prose passes lexical consumers.',
        'Negation-aware discovery and literal binding/audit differ for both existing and new anchors.',
        'Korean exact trigger and authored paraphrase retained; Korean-only literal bindings remain unsupported in the measured case.',
        'No provider, installation, source/index mutation, public CLI, render, pixel review, empirical diagnosis or publication.',
    ],
})
save('final-verification.json', {
    'head': binding['head'], 'repository_status': '', 'proposal_manifest_sha256': EXPECTED,
    'verified_proposal_artifacts': len(inputs), 'source_runtime_index_unchanged': True,
    'patch_apply_check': 'PASS; check only, never applied',
})
artifacts = [{'path': str(p.relative_to(O)), 'sha256': sha(p.read_bytes()), 'bytes': len(p.read_bytes())} for p in sorted(O.rglob('*')) if p.is_file() and p.name != 'artifact-manifest.json']
save('artifact-manifest.json', artifacts)
print(json.dumps({'decision': 'ACCEPT_TWO_LEAF_DATA_PROPOSAL_WITHOUT_REVISION', 'review_artifacts': len(artifacts), 'manifest_sha256': sha((O / 'artifact-manifest.json').read_bytes())}))
