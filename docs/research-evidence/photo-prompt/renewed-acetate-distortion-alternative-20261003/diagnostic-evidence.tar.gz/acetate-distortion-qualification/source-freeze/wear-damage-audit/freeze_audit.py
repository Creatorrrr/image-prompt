"""Read-only source freeze; writes only beside this script, outside the repository."""
from pathlib import Path
import hashlib,json,subprocess,sys
sys.dont_write_bytecode=True
R=Path('REPOSITORY_ROOT'); O=Path(__file__).resolve().parent
A=R/'skills/photo-prompt-image-generator/assets'; D=R/'docs/research-evidence/photo-prompt'
PROFILE_IDS='pr_surface_wear_contact_owner rb_repair_patch_locality rb_contact_wear_locality costume_ccx_cc32_01 costume_ccx_cc32_02 silver_mirroring_surface_region_relation acetate_channeling_shrinkage_relation barrier_breakthrough_causal_event'.split()
CANDIDATE_IDS='pr_surface_wear_contact_owner_candidate rb_repair_patch_locality_candidate rb_contact_wear_locality_candidate ccx_cc32_01 ccx_cc32_02 silver_mirroring_dense_region_surface acetate_channeling_emulsion_surface bt_breakthrough_barrier_prop lacquered_wood_patina oxidized_copper_patina porcelain_hairline_crack rust_pitting_texture brass_patina_texture localized_heritage_condition_surface localized_service_wear_surface freeze_thaw_polygon_crust_surface replica_round_shield_prop'.split()
sha=lambda b:hashlib.sha256(b).hexdigest()
canon=lambda x:sha(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())
def save(n,x):(O/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def git(*args):return subprocess.check_output(['git',*args],cwd=R,text=True)
def walk(d,p=''):
 if isinstance(d,dict):
  if 'id' in d:yield p,d
  for k,v in d.items():yield from walk(v,p+'/'+str(k))
 elif isinstance(d,list):
  for i,v in enumerate(d):yield from walk(v,p+'/'+str(i))
records=[];paths=set()
for f in sorted(A.glob('*.json')):
 if 'index' in f.name:continue
 d=json.loads(f.read_text())
 for i,p in enumerate(d.get('profiles',[])):
  if p['id'] in PROFILE_IDS:records.append({'kind':'profile','id':p['id'],'file':str(f.relative_to(R)),'pointer':f'/profiles/{i}','canonical_sha256':canon(p),'record':p});paths.add(f)
 for slot,rs in d.get('slots',{}).items():
  for i,p in enumerate(rs):
   if p['id'] in CANDIDATE_IDS:records.append({'kind':'candidate','slot':slot,'id':p['id'],'file':str(f.relative_to(R)),'pointer':f'/slots/{slot}/{i}','canonical_sha256':canon(p),'record':p});paths.add(f)
assert len(records)==25 and set(PROFILE_IDS+CANDIDATE_IDS)=={x['id'] for x in records}
save('source-records.json',records)
source_specs=[
 ('photorealism-elements-20260923/visual-proposals.json',['pr_surface_wear_contact_owner']),
 ('photorealism-elements-20260923/sources.json',['S01','S17']),
 ('realistic-background-20260912/visual-proposals.json',['rb_repair_patch_locality','rb_contact_wear_locality']),
 ('realistic-background-20260912/sources.json',['S10','S11']),
 ('costume-cosplay-20260930/visual-semantics.proposed.json',['CC32']),
 ('costume-cosplay-20260930/sources.json',['S41','S24']),
 ('photo-era-visual-semantics-20260905/candidate-data-proposal.json',['silver_mirroring_surface_region_relation','acetate_channeling_shrinkage_relation','silver_mirroring_dense_region_surface','acetate_channeling_emulsion_surface'])]
orig=[]
for rel,ids in source_specs:
 f=D/rel;paths.add(f);d=json.loads(f.read_text())
 found=[{'pointer':p,'id':r['id'],'canonical_sha256':canon(r),'record':r} for p,r in walk(d) if r['id'] in ids]
 assert set(ids)=={x['id'] for x in found},(rel,ids,found)
 orig.append({'file':str(f.relative_to(R)),'file_sha256':sha(f.read_bytes()),'records':found})
for rel,ids in [
 ('photo-era-visual-semantics-20260905/evidence.jsonl',['cci_photographic_materials','cci_plastic_negatives','loc_negative_deterioration']),
 ('boundary-transition-visual-semantics-20260901/evidence.jsonl',None)]:
 f=D/rel;paths.add(f);rs=[json.loads(l) for l in f.read_text().splitlines() if l.strip()]
 found=[{'line':i+1,'id':r['id'],'canonical_sha256':canon(r),'record':r} for i,r in enumerate(rs) if (r['id'] in ids if ids is not None else 'barrier_breakthrough_causal_event' in json.dumps(r))]
 orig.append({'file':str(f.relative_to(R)),'file_sha256':sha(f.read_bytes()),'records':found})
save('original-research-records.json',orig)
doc_names=['photorealism-elements-20260923/report.md','realistic-background-20260912/report.md','costume-cosplay-20260930/research-report.md','photo-era-visual-semantics-20260905/report-source.md','boundary-transition-visual-semantics-20260901/source-research.md']
(O/'source-documents').mkdir(exist_ok=True)
for rel in doc_names:
 f=D/rel;paths.add(f);(O/'source-documents'/rel.replace('/','__')).write_bytes(f.read_bytes())
# Bind legacy optional rows to their first introduction rather than inventing unsupported research.
historical=[]
for rec in records:
 if Path(rec['file']).name not in ['photo_prompt_tags.json','photo_prompt_research_extension.json','photo_prompt_boundary_transition_extension.json']:continue
 commits=git('log','--format=%H','--reverse','-S','"'+rec['id']+'"','--',rec['file']).splitlines()
 assert commits,rec['id']
 commit=commits[0];b=subprocess.check_output(['git','show',commit+':'+rec['file']],cwd=R);d=json.loads(b)
 found=[(p,r) for p,r in walk(d) if r['id']==rec['id']]
 assert len(found)==1,(rec['id'],found)
 p,r=found[0];historical.append({'id':rec['id'],'commit':commit,'file':rec['file'],'file_sha256':sha(b),'pointer':p,'canonical_sha256':canon(r),'record':r,'current_entire_record_identical':r==rec['record'],'current_en_identical':r.get('en')==rec['record'].get('en')})
save('historical-source-records.json',historical)
sys.path.insert(0,str(A.parent/'scripts'));import prompt_generator as pg
reg=pg.load_visual_obligation_registry(A/'photo_prompt_visual_obligations.json');idx=pg.load_visual_profile_index(A/'photo_prompt_visual_profile_index.json',reg)
profiles=[p for p in reg['profiles'] if p['id'] in PROFILE_IDS]
save('compiled-profiles.json',[{'id':p['id'],'canonical_sha256':canon(p),'profile':p} for p in profiles])
assert all(pid in idx['entries'] for pid in PROFILE_IDS)
save('profile-index-record-hashes.json',[{'pointer':'/entries/'+pid,'id':pid,'canonical_sha256':canon(idx['entries'][pid])} for pid in PROFILE_IDS])
for n in ['photo_prompt_visual_obligations.json','photo_prompt_visual_profile_index.json','photo_prompt_semantic_index.json','photo_prompt_quality_layers.json']:paths.add(A/n)
paths.update(Path(m.__file__) for m in list(sys.modules.values()) if getattr(m,'__file__',None) and str(A.parent/'scripts') in m.__file__)
prior=['object-morphology-review/DECISION.md','glacier-surface-alternative-audit/REPORT.md','receiver-material-review/REVIEW.md','supported-repair-gap-review/review.md','garment-closure-alternative-audit/report.md','textile-next-audit/REPORT.md','liquid-interface-audit/REPORT.md']
save('source-manifest.json',{'head':git('rev-parse','HEAD').strip(),'status_before':git('status','--short'),'scope':'25 full current DATA records: 8 profiles and 17 candidates. Lexical screening is not coverage. No source/index/runtime/test edits. No APIs, installations, publishing, camera metadata work or pixel review.','hash_convention':'Files are exact-byte SHA-256; records are compact sorted-key UTF-8 JSON with ensure_ascii=False.','actual_bound_visual_index_loaded':True,'loaded_registry_profile_count_not_coverage':len(reg['profiles']),'compiled_registry_sha256':canon(reg),'files':[{'path':str(f.relative_to(R)),'sha256':sha(f.read_bytes())} for f in sorted(paths)],'prior_reports_read':[{'path':n,'sha256':sha((O.parent/n).read_bytes())} for n in prior]})
print(json.dumps({'records':len(records),'profiles':len(profiles),'bound_index_loaded':True,'historical_records':len(historical)}))
