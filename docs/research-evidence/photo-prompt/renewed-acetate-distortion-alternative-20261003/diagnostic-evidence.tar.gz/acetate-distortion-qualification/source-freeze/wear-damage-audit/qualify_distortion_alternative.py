"""Freeze and qualify a two-leaf DATA proposal in memory. Never writes repository/index."""
from pathlib import Path
import copy,hashlib,json,subprocess,sys
sys.dont_write_bytecode=True
R=Path('REPOSITORY_ROOT');O=Path(__file__).resolve().parent;A=R/'skills/photo-prompt-image-generator/assets'
sys.path.insert(0,str(A.parent/'scripts'));import prompt_generator as pg;import audit_composed_prompt as ac
sha=lambda b:hashlib.sha256(b).hexdigest()
canon=lambda x:sha(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())
def save(n,x):(O/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def diff(a,b,p=''):
 if type(a)!=type(b):return [{'path':p,'before':a,'proposed':b}]
 if isinstance(a,dict):
  assert a.keys()==b.keys()
  return [v for k in a for v in diff(a[k],b[k],p+'/'+k)]
 if isinstance(a,list):
  if len(a)!=len(b):return [{'path':p,'before':a,'proposed':b}]
  return [v for i in range(len(a)) for v in diff(a[i],b[i],p+'/'+str(i))]
 return [] if a==b else [{'path':p,'before':a,'proposed':b}]
pid='acetate_channeling_shrinkage_relation';field='image_delamination_phrase';anchor='image distortion follows the network'
recs=json.loads((O/'source-records.json').read_text());row=next(x for x in recs if x['id']==pid);before=row['record'];after=copy.deepcopy(before)
current=json.loads((R/row['file']).read_text());actual=next(x for x in current['profiles'] if x['id']==pid)
assert actual==before,'Source record changed; requalify before freezing.'
g=next(x for x in after['semantics']['component_semantics']['groups'] if x['id']=='image_delamination')
assert g['any_terms']==['image distortion or delamination follows the network','image delamination']
assert after['evidence_requirements'][field]['must_mention_any']==g['any_terms']
g['any_terms'].append(anchor);after['evidence_requirements'][field]['must_mention_any'].append(anchor)
leaves=diff(before,after)
assert {x['path'] for x in leaves}=={'/semantics/component_semantics/groups/3/any_terms','/evidence_requirements/image_delamination_phrase/must_mention_any'}
save('before-profile.json',before);save('proposed-profile.json',after)
save('exact-changed-leaves.json',[{'file':row['file'],'profile_id':pid,**x} for x in leaves])
reg=pg.load_visual_obligation_registry(A/'photo_prompt_visual_obligations.json');idx=pg.load_visual_profile_index(A/'photo_prompt_visual_profile_index.json',reg)
rb=next(x for x in reg['profiles'] if x['id']==pid);assert rb==pg.compile_visual_profile(before)
ra=pg.compile_visual_profile(after);reg_after=copy.deepcopy(reg);reg_after['profiles']=[ra if x['id']==pid else x for x in reg_after['profiles']]
ob=pg.candidate_pack_visual_profile_obligation(before,reg,activation_source='audit',source_intent_ids=[])
oa=pg.candidate_pack_visual_profile_obligation(after,reg_after,activation_source='audit',source_intent_ids=[])
obdiff=diff(ob,oa)
assert {x['path'] for x in obdiff}=={'/component_semantics/groups/3/any_terms','/evidence_requirements/image_delamination_phrase/must_mention_any'}
base=next(x for x in json.loads((O/'consumer-proof.json').read_text())['profile_tests'] if x['id']==pid)
def binding(phrase,o):
 try:pg.validate_visual_intent_binding(obligation_index=0,field=field,phrase=phrase,requirement=o['evidence_requirements'][field]);return {'pass':True}
 except ValueError as e:return {'pass':False,'error':str(e)}
def audit(ev,o):
 c=copy.deepcopy(base['contract']);c['obligations']=[o]
 prompt='. '.join(list(ev.values()))
 return ac.audit_visual_obligations({'visual_obligations':c},{'visual_obligation_evidence':{pid:ev}},prompt)
phrase='image distortion follows the network while the physical emulsion remains visibly attached along the wrinkled film'
ev={**base['positive_evidence'],field:phrase}
groups=rb['semantics']['component_semantics']['groups'];full_terms=[x['any_terms'][0] for x in groups];full_terms[3]=phrase
text='; '.join(full_terms)
positive={'phrase':phrase,'evidence':ev,'component_text':text,'before_binding':binding(phrase,ob),'after_binding':binding(phrase,oa),'before_audit':audit(ev,ob),'after_audit':audit(ev,oa),'before_component_match':pg.candidate_pack_visual_component_match(rb,text),'after_component_match':pg.candidate_pack_visual_component_match(ra,text)}
assert not positive['before_binding']['pass'] and positive['after_binding']['pass']
assert positive['before_audit'] and not positive['after_audit']
assert positive['before_component_match']!='component_semantics' and positive['after_component_match']=='component_semantics'
old_branches=[]
for text0 in before['evidence_requirements'][field]['must_mention_any']:
 e={**base['positive_evidence'],field:text0}
 result={'phrase':text0,'before_binding':binding(text0,ob),'after_binding':binding(text0,oa),'before_audit':audit(e,ob),'after_audit':audit(e,oa)}
 assert result['before_binding']['pass'] and result['after_binding']['pass'] and not result['before_audit'] and not result['after_audit']
 old_branches.append(result)
neg=[]
for f in ev:
 e={k:v for k,v in ev.items() if k!=f};bf=audit(e,ob);af=audit(e,oa)
 assert af and any(x.get('field')==f for x in af)
 neg.append({'kind':'omission','field':f,'evidence':e,'before_failures':bf,'after_failures':af})
replacements=[
 ('plastic_film_support_phrase','A dry mud crust has intersecting cracks across opaque clay plates.','nonfilm_mud_cracks'),
 ('plastic_film_support_phrase','A cracked window pane reflects a nearby outdoor landscape.','nonfilm_glass_cracks'),
 ('image_delamination_phrase','A digital warp bends a JPEG image globally with no physical film object present.','digital_warp'),
 ('channel_network_phrase','Flat straight scratches cross the photograph independently of its undistorted image layer.','flat_scratches'),
 ('less_damaged_edge_phrase','Uniform damage covers the entire surface through every edge.','missing_comparison_region'),
 ('image_delamination_phrase','Distortion bends a nearby paper label while the connected film image remains flat.','wrong_image_owner')]
for f,t,label in replacements:
 e={**ev,f:t};bf=audit(e,ob);af=audit(e,oa);assert any(x.get('field')==f for x in af)
 neg.append({'kind':'wrong_neighbor','label':label,'field':f,'evidence':e,'before_failures':bf,'after_failures':af})
om=[]
for i,g in enumerate(groups):
 text0='; '.join(t for j,t in enumerate(full_terms) if j!=i);bm=pg.candidate_pack_visual_component_match(rb,text0);am=pg.candidate_pack_visual_component_match(ra,text0)
 assert bm!='component_semantics' and am!='component_semantics'
 om.append({'omitted_group':g['id'],'text':text0,'before':bm,'proposed':am})
# This probe deliberately exposes the lexical helper's established semantic limit.
anchor_retention=[]
for suffix in ['; this is a rendered digital simulation on a flat image', '; this wording is printed on a paper label beside the film']:
 t='image delamination'+suffix;e={**base['positive_evidence'],field:t}
 bf=audit(e,ob);af=audit(e,oa);assert bf==af
 anchor_retention.append({'phrase':t,'before_failures':bf,'after_failures':af,'interpretation':'Anchor-preserving prose may pass lexical helpers without proving substrate or physical truth. Saved-image gates remain necessary; no semantic understanding or pixel pass is claimed.'})
controls={}
for label,request in {'exact_en':'acetate film channeling and shrinkage relation','exact_ko':'아세테이트 필름 채널링 수축 관계','broad_damage':'old damaged photograph','digital':'digital warp of a JPEG image','mud':'dry mud polygon cracks','glass':'cracked glass','scratch':'flat scratches over a photograph'}.items():
 sr=[{'source':'concept_lock','text':request,'polarity':'required','priority':'critical','mandatory':True}]
 bm=pg.candidate_pack_auto_visual_obligation_matches(reg,sr);am=pg.candidate_pack_auto_visual_obligation_matches(reg_after,sr)
 assert bm==am
 assert (pid in bm)==label.startswith('exact'),(label,bm)
 controls[label]={'request':request,'before':bm,'proposed':am}
tb=pg.visual_profile_semantic_text(rb);ta=pg.visual_profile_semantic_text(ra)
(O/'positive-text-before.txt').write_text(tb+'\n');(O/'positive-text-proposed.txt').write_text(ta+'\n')
assert tb!=ta and anchor in ta
assert pg.visual_profile_exact_term_rows(reg)==pg.visual_profile_exact_term_rows(reg_after)
try:pg.validate_visual_profile_index_metadata(idx,reg_after);raise AssertionError('Changed registry unexpectedly accepted old index')
except ValueError as e:stale_error=str(e)
candidate=next(x for x in recs if x['id']=='acetate_channeling_emulsion_surface')
now=json.loads((R/candidate['file']).read_text());actual_candidate=next(x for rs in now['slots'].values() for x in rs if x['id']==candidate['id']);assert actual_candidate==candidate['record']
index_impact={'before_positive_text_sha256':sha(tb.encode()),'proposed_positive_text_sha256':sha(ta.encode()),'positive_text_changes':True,'exact_lookup_unchanged':True,'before_registry_sha256':pg.visual_profile_registry_sha256(reg),'proposed_registry_sha256':pg.visual_profile_registry_sha256(reg_after),'current_visual_index_sha256':sha((A/'photo_prompt_visual_profile_index.json').read_bytes()),'old_index_rejected_for_proposed_registry':stale_error,'before_bm25f_fields':pg.visual_profile_bm25f_fields(rb),'proposed_bm25f_fields':pg.visual_profile_bm25f_fields(ra),'required_next_step':'After independent acceptance, use the established genuine index/vector refresh and public before/after pipeline. Do not reuse the unchanged vector under a fabricated digest. No index, vectors, public pack or repository mutation were produced by this audit.'}
save('positive-text-index-impact.json',index_impact)
save('proposal-consumer-proof.json',{'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'source_record_sha256':canon(before),'proposed_record_sha256':canon(after),'before_obligation':ob,'proposed_obligation':oa,'exact_obligation_changes':obdiff,'distortion_only_positive':positive,'old_anchor_controls':old_branches,'negative_controls':neg,'component_omission_controls':om,'anchor_retention_limits':anchor_retention,'exact_route_controls':controls,'narrow_candidate_record_unchanged':candidate,'unchanged_invariants':['all other profile leaves','activation and exclusions','five component group IDs and minimum','five evidence field IDs and minima','all gate IDs, scales and text','film support and image-layer ownership','channel network and less-damaged comparison','runtime expression and composition','delamination-specific optional candidate'],'limits':'Two-leaf in-memory source/consumer qualification, not public CLI, ranking or render qualification. Negative helpers measure literal fields/anchors, not physical understanding; the deliberate anchor-retention controls show that limitation.'})
print(json.dumps({'proposal_leaves':len(leaves),'distortion_before':'fails','distortion_after':'passes','preserved_old_anchors':len(old_branches),'negative_evidence_cases':len(neg),'component_omissions':len(om),'exact_route_controls':len(controls),'positive_text_changed':tb!=ta,'old_index_rejected':True}))
