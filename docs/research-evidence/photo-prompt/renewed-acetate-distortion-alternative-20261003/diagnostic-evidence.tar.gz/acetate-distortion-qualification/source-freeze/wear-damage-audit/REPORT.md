# Material wear / damage DATA audit

## Result

**One two-leaf DATA proposal; 24 KEEP records. No implementation.** The bounded selection is 25 complete current records: eight hard profiles and 17 optional candidate rows. All are frozen with exact pointers and canonical record hashes. A loader count of 1,510 profiles is not an audit-coverage claim.

The proposal is confined to `acetate_channeling_shrinkage_relation`: add **`image distortion follows the network`** to the existing `image_delamination` component group's `any_terms` and the matching mandatory evidence field's `must_mention_any`. Both old anchors remain first and unchanged. Full old/new records and exact changed arrays are provided.

## Source authority and concrete failure

The original `photo-era-visual-semantics-20260905/candidate-data-proposal.json` explicitly authors:

- `plastic film support`
- `support and emulsion shrink at different rates`
- `curving connected channel or wrinkle network`
- **`image distortion or delamination follows the network`**
- `less-damaged edge comparison`

The current definition, composition, component and evidence retain the same OR. Its native gate requires the image to deform with the network; it does not mandate delamination. The original evidence record `cci_plastic_negatives` additionally calls for film support and image distortion tied to a continuous channel network. Its recorded limit says not every wrinkle network is acetate channeling, and identifying a specific plastic base can require non-image examinations. This audit neither reopens those external pages nor independently certifies conservation science.

Current literal anchors are the combined OR sentence and `image delamination`. The concrete, source-permitted binding:

> image distortion follows the network while the physical emulsion remains visibly attached along the wrinkled film

fails the unchanged binding validator and composed-evidence helper. A complete five-group description using that same sentence also fails complete component recognition. All three pass after only the two in-memory additions. This is an asymmetric literal-branch gap, **not a claim that the current gate physically requires both symptoms**: the old OR sentence can truthfully describe distortion alone, and the baseline controls record that passing route too. The proposal permits the definite distortion branch without forcing disjunctive symptom wording or invoking the delamination-only alias.

The separate optional candidate `acetate_channeling_emulsion_surface` expressly says **channeling and delamination** in its original proposal and current full record. It is unchanged. Its adoption remains a delamination commitment; do not use it to represent the distortion-only scene.

## Two-leaf qualification

`qualify_distortion_alternative.py` uses current production compilation, materialization, component matching, binding validation, exact-route matching and composed-evidence audit helpers. `proposal-consumer-proof.json` preserves every exact input and returned outcome.

- Distortion-only positive: binding, composed evidence and complete component match fail before and pass after
- Both original anchors continue to pass before and after
- Five evidence omissions and five component omissions remain failures
- Six wrong-neighbor replacements remain failures: non-film mud cracks, cracked window glass, digital JPEG warp, flat unrelated scratches, absent comparison region, and distortion belonging to a nearby paper label
- Seven exact-route controls remain identical, including English/Korean exact requests and generic damaged photo, digital warp, mud, glass and scratches
- Only the two named arrays change in source and emitted obligation; activation, exclusions, five groups, IDs, minima, composition, runtime expression, all gates/scales/text and the narrower candidate remain unchanged

The negative helpers check literals and declared fields; they do not reason about physical ownership. Two deliberate old-anchor-plus-misleading-prose controls pass unchanged before and after. They are included to expose this limit rather than claiming that these tests prove robust semantic rejection. Saved-image inspection of substrate, image-layer continuity, network ownership and comparison region is still necessary. No image was generated or reviewed.

## Wider bounded controls

`probe_consumers.py` loaded the genuine source-bound current visual index and measured:

- Eight exact-request profile positives and all 27 evidence fields pass
- 27 omitted evidence fields, 16 wrong-neighbor replacements and 27 component omissions fail their target complete requirement
- Eleven declared branch controls pass using existing anchors, including fingerprints/abrasion, polishing/scuffs, repair texture difference, print/negative support, acetate wrinkle/distortion/delamination and attached barrier deformation
- Twelve different/generic requests do not hard-activate the tested target profile
- 24 context-helper checks preserve distinct collection documentation, reuse assessment, freeze-thaw and physical-breakthrough prerequisites
- All 17 optional candidates have their actual public semantic-source projections recorded

These are lower-level current-consumer tests. There is no full public CLI, frozen-core or ranking qualification, paid provider, fake vector, rendered-image or end-to-end quality claim.

## KEEP findings and boundaries

### Owner-localized wear and wall repair

Original photorealism research permits wear, fingerprints or dust at a plausible contact site and maintains underlying material response and geometry. Current generic trace wording supports the measured branches; a handled-glass example does not mandate glass or fingerprints everywhere. There is no authority to replace clean surfaces with uniform grunge or substitute metal corrosion for glass handling marks.

The wall-repair profile selects a bounded patch, subtle difference and continuous surrounding joints. Its existing difference anchor accepts a texture transition, so it does not force a second color change. Its paired paint-tone candidate remains deliberately narrower. The handle-wear profile supports polishing or scuffs but still requires localized grip wear, adjacent preservation and a continuous solid handle. Research lists other possible owners, yet its current selected handle manifestation is not silently widened to floors or doors generally.

### Garment fraying and repair traces

Source `CC32` explicitly sets independent request-supported component activation. The current edge-fraying and sewn-patch profiles remain independent: requesting either exact relation does not activate its sibling. A sewn border and overlapping original cloth belong to that selected patch variant; print, hidden repair and adhesive-only alternatives are not newly authored. No actual injury, poverty, violence, date or repair history follows from the surface appearance. Active repair scenes and clothing closures are excluded.

### Photographic material damage

Silver mirroring already supports physical print and negative through its existing generic support anchor while retaining local dense-image-region sheen, surface response and unaffected comparison. Metal picture frames, glass glare, global blue grading and generic vintage noise are different owners/effects. Acetate support/network/comparison and source limitations remain intact in the proposal. A single still image is not a measurement of shrinkage rate, proof of a chemical cause or verification of capture date, authenticity or storage history. Camera metadata and runtime scope were not changed.

### Fracture and physical barrier traces

The breakthrough profile and its original barrier candidate preserve a finite barrier, common force/contact/rupture/aperture axis, passage and localized consequence. The trace vocabulary already includes deformation; it need not mean freely detached rubble. The passing control uses a soft foam ball, a torn paper sheet and attached curling flaps. Bare rubble, an old doorway and unowned cracks remain different scenes. This is a selected depicted event, not documentary proof of prior resistance or a real cause. Individual tearing/deformation phrase failures are recorded but are not bundled into the acetate proposal.

### Patina, corrosion, condition and staged weathering

The five legacy patina/crack textures and the staged replica-shield candidate retain their complete original records. They are optional named material appearances, not new hard all-of damage contracts. Lacquered wood, copper, brass, porcelain and rust-pitting candidates are not collapsed into one generic wear synonym. The shield is inspected only for staged-weathering/replica meaning, not object morphology.

Collection-condition and reuse-assessment rows retain different owners and prerequisites; a selected ordinary-wear-versus-local-failure comparison is not generic ordinary wear. The freeze-thaw row explicitly selects cracks, heave and redistributed grains and remains primary-context limited. All ten inspected historical candidate records are structurally identical to their original introduction. No missing hard contract is invented for these rows, and visible marks do not establish actual age, authenticity, chemical diagnosis, exposure duration or an exact cause.

## Deferred and rejected expansions

- Single wrinkle-network wording is a measured literal-anchor limitation, but this proposal is limited to the existing image-distortion symptom branch
- Individual barrier rupture/deformation alternatives remain measured diagnostics, not a broad new family of synonyms or a causal-gate rewrite
- Removing substrate, locality, clean comparison, visible border or same-owner requirements would broaden semantics and is not supported
- Source research alternatives are not permission to broaden a deliberately selected candidate, such as paint-tone repair, sewn patch or channeling-plus-delamination
- Already-covered morphology, glacier, wet receivers, active-repair proposal and clothing closures were reviewed for boundaries and excluded from modification; prior textile findings were not reopened

## Index consequence and integration gate

The positive profile text changes from adding the component anchor. `positive-text-index-impact.json` includes the exact before/proposed texts, SHA-256 values and BM25F fields. Exact activation lookup is unchanged, while the compiled-registry digest changes. The genuine current index correctly rejects the in-memory proposed registry as stale. No replacement index or vectors were fabricated.

If independently approved after the active publication window, apply only the two exact arrays, use the established genuine visual-profile index refresh, and run the same frozen normal public before/after requests and evidence. Other source and optional-candidate semantics remain unchanged. This audit does not claim that retrieval rankings or final image quality are unchanged or improved.

## Provenance and reproducibility

- `source-records.json`: 25 complete records, pointers and canonical hashes
- `original-research-records.json`: full relevant original proposals and linked research ledger records with source-file hashes
- `historical-source-records.json`: ten original candidate records, commits/file hashes and current equality
- `compiled-profiles.json`, `profile-index-record-hashes.json`: eight actual compiled records and bound-index entry hashes
- `consumer-proof.json`: baseline inputs, complete emitted obligations and positive/negative outputs
- `before-profile.json`, `proposed-profile.json`, `exact-changed-leaves.json`: exact unapplied two-leaf proposal
- `proposal-consumer-proof.json`, `positive-text-index-impact.json`: proposal-specific qualification and stale-index consequence
- `source-manifest.json`, `runtime-manifest.json`, `ending-verification.json`: revision, per-file/runtime/index hashes and ending per-record verification
- `decisions.json`: full per-record decisions; `artifact-manifest.json`: audit-artifact hashes

All writes are outside `image-prompt/`. No repository source, test, runtime, semantic index, API, installation or publication was changed. Baseline and proposal scripts set Python bytecode writes off. The bounded stopping condition is reached: original intent, full records, actual contracts, source-declared alternative, failure reproduction, minimal proposal, wrong-neighbor controls and hash-bound handoff are complete.
