# Harness notes

- The first profile-index hash extraction assumed entries carried their own `id`. Actual entries are a dictionary keyed by profile ID. The extraction was corrected to `/entries/<profile_id>`, asserted all eight entries exist, and the freeze was rerun before consumer qualification. No index was altered
- A read-only inspection attempted integer indexing into that same dictionary and received `KeyError: 0`; it did not affect any consumer result
- Four deliberate single-branch natural phrases fail literal anchors. These are saved as measured outcomes, not harness errors. Only the source-declared acetate distortion branch is proposed; the other expansions are deferred
- Two deliberately misleading phrases retain the old `image delamination` anchor and pass the literal helper. Their unchanged before/after outcomes are recorded to prevent overstating wrong-neighbor rejection as physical-semantic validation
