"""Unchanged local production consumers. No providers, query vectors, or repository writes."""
from pathlib import Path
import copy,hashlib,json,subprocess,sys
sys.dont_write_bytecode=True
R=Path('REPOSITORY_ROOT');O=Path(__file__).resolve().parent;A=R/'skills/photo-prompt-image-generator/assets'
sys.path.insert(0,str(A.parent/'scripts'));import prompt_generator as pg;import audit_composed_prompt as ac
sha=lambda b:hashlib.sha256(b).hexdigest()
canon=lambda x:sha(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())
def save(n,x):(O/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
rows=json.loads((O/'source-records.json').read_text());by={x['id']:x for x in rows}
reg=pg.load_visual_obligation_registry(A/'photo_prompt_visual_obligations.json');idx=pg.load_visual_profile_index(A/'photo_prompt_visual_profile_index.json',reg)
profiles={x['id']:x for x in reg['profiles'] if x['id'] in by and by[x['id']]['kind']=='profile'}
data=pg.load_json(A/'photo_prompt_tags.json');data[pg.QUALITY_LAYERS_DATA_KEY]=pg.load_quality_layers(A/pg.QUALITY_LAYERS_FILENAME)
def resolve(request):
 res={'provenance':{'concept_lock':[request]}}
 sources=pg.candidate_pack_visual_obligation_request_sources(res,{})
 resolution=pg.resolve_visual_profile_hits(reg,sources,visual_profile_index=idx,adult_context=True)
 c=pg.candidate_pack_visual_obligations({pg.VISUAL_OBLIGATIONS_DATA_KEY:reg},res,{},None,visual_profile_resolution=resolution)
 return resolution,c
def binding(field,phrase,req):
 try:pg.validate_visual_intent_binding(obligation_index=0,field=field,phrase=phrase,requirement=req);return {'pass':True}
 except ValueError as e:return {'pass':False,'error':str(e)}
wrong={
 'pr_surface_wear_contact_owner':[('component_2_phrase','Metal corrosion covers a glass rim while fingerprints sit on the untouched wall.','wrong_material_and_contact_owner'),('component_4_phrase','Random grunge overlays erase object boundaries across every surface.','uniform_damage_overlay')],
 'rb_repair_patch_locality':[('component_1_phrase','A repair sticker is attached to a nearby suitcase beside an intact wall.','wrong_patch_owner'),('component_3_phrase','The repaired area interrupts and removes the surrounding masonry connections.','lost_continuity')],
 'rb_contact_wear_locality':[('component_1_phrase','Every wall and handle has identical evenly distributed scratches.','unlocalized_wear'),('component_3_phrase','The handle is broken into disconnected pieces across its former gripping region.','fracture_instead_of_continuous_handle')],
 'costume_ccx_cc32_01':[('component_1_phrase','Gray digital grain covers the whole portrait while the costume edge stays clean.','image_noise_instead_of_edge_fraying'),('component_1_phrase','Loose fibers cover a nearby rug while the costume edge stays smooth.','wrong_fiber_owner')],
 'costume_ccx_cc32_02':[('component_1_phrase','A rectangular repair design is printed flat onto the original cloth.','printed_patch_instead_of_sewn_overlap'),('component_1_phrase','A repair patch is sewn onto the suitcase beside the intact costume.','wrong_patch_owner')],
 'silver_mirroring_surface_region_relation':[('silver_photo_support_phrase','A polished silver metal picture frame surrounds a newly printed color portrait.','metal_frame_instead_of_photographic_support'),('dense_region_sheen_phrase','Blue color grading covers every bright and dark region evenly.','global_grade_instead_of_local_sheen')],
 'acetate_channeling_shrinkage_relation':[('plastic_film_support_phrase','A dry earthen surface carries polygon cracks between rigid clay plates.','wrong_substrate_dry_mud'),('image_delamination_phrase','Decorative water ripples float above a flat undamaged image layer.','unowned_overlay')],
 'barrier_breakthrough_causal_event':[('barrier_phrase','A soft foam ball travels through a wide open preexisting doorway in an undamaged wall.','preexisting_opening'),('rupture_phrase','Old disconnected rubble rests beneath an intact surface with no visible contact relation.','rubble_only_aftermath')]
}
# Specific same-component elaborations satisfy the existing high floors; never lower them.
barrier_suffix={
 'barrier_phrase':'; the intact paper sheet perimeter stays connected to its rigid display frame',
 'force_phrase':' ; a soft foam ball is centered directly inside the freshly torn paper opening',
 'rupture_phrase':' ; attached paper flaps curl outward around the foam ball at the torn opening',
 'crossing_phrase':' ; the visible foam ball spans the near and far faces of the paper sheet',
 'displacement_phrase':' ; attached paper flaps curl along the ball passage while the surrounding sheet stays intact'}
profile_tests=[];positive_by={};contract_by={}
for pid,p in profiles.items():
 request='Photograph the following explicitly selected visible relation: '+p['activation']['exact_terms'][0]
 resolution,contract=resolve(request)
 assert contract and pid in [x['id'] for x in contract['obligations']],(pid,contract)
 obligation=next(x for x in contract['obligations'] if x['id']==pid)
 ev={f:r['must_mention_any'][0]+(barrier_suffix[f] if pid=='barrier_breakthrough_causal_event' else '') for f,r in obligation['evidence_requirements'].items()}
 full_ev={x['id']:{f:r['must_mention_any'][0] for f,r in x['evidence_requirements'].items()} for x in contract['obligations']};full_ev[pid]=ev
 labels=[t for x in contract['obligations'] for t in x.get('runtime_expression',{}).get('prompt_label_terms',[])][:]
 def audit(e):
  all_ev={**full_ev,pid:e};prompt='. '.join(labels+[s for fields in all_ev.values() for s in fields.values()])
  return ac.audit_visual_obligations({'visual_obligations':contract},{'visual_obligation_evidence':all_ev},prompt)
 fs=audit(ev);assert not fs,(pid,fs)
 base_binding=[{'field':f,'phrase':s,'result':binding(f,s,obligation['evidence_requirements'][f])} for f,s in ev.items()]
 assert all(x['result']['pass'] for x in base_binding),(pid,base_binding)
 neg=[]
 for field in ev:
  evidence={f:s for f,s in ev.items() if f!=field};fail=audit(evidence);assert fail
  neg.append({'kind':'omission','field':field,'evidence':evidence,'failures':fail})
 for field,text,label in wrong[pid]:
  evidence={**ev,field:text};fail=audit(evidence);assert any(x.get('field')==field for x in fail),(pid,field,fail)
  neg.append({'kind':'wrong_neighbor','label':label,'field':field,'evidence':evidence,'binding_result':binding(field,text,obligation['evidence_requirements'][field]),'failures':fail})
 groups=p['semantics']['component_semantics']['groups'];terms=[x['any_terms'][0] for x in groups]
 component=[{'kind':'complete','text':'; '.join(terms),'match':pg.candidate_pack_visual_component_match(p,'; '.join(terms))}]
 assert component[0]['match']=='component_semantics',(pid,component)
 for i,g in enumerate(groups):
  text='; '.join(t for j,t in enumerate(terms) if i!=j);m=pg.candidate_pack_visual_component_match(p,text)
  assert m!='component_semantics',(pid,g,m)
  component.append({'kind':'omission','group':g['id'],'text':text,'match':m})
 profile_tests.append({'id':pid,'request':request,'hits':resolution['hits'],'contract':contract,'positive_evidence':ev,'binding_controls':base_binding,'positive_failures':fs,'negative_evidence_controls':neg,'component_controls':component})
 positive_by[pid]=ev;contract_by[pid]=contract
# Separate scene declarations retain existing disjunctive anchors; these are concrete
# source-selected branches, not invented synonyms and not image validation.
branches=[
 ('pr_surface_wear_contact_owner','component_2_phrase',"the selected wear or trace sits at a reachable contact point; faint fingerprints belong only to the handled glass rim",'fingerprint_branch'),
 ('pr_surface_wear_contact_owner','component_2_phrase',"the selected wear or trace sits at a reachable contact point; pale abrasion follows the rubbed wooden handle edge",'abrasion_branch'),
 ('rb_repair_patch_locality','component_2_phrase','the patch differs subtly from the surrounding paint; the distinction is a fine texture transition inside the bounded repair','texture_difference_branch'),
 ('rb_contact_wear_locality','component_1_phrase','wear is localized to the gripping area of the selected handle; local polishing is visible at the touched metal','polishing_branch'),
 ('rb_contact_wear_locality','component_1_phrase','wear is localized to the gripping area of the selected handle; local scuffs remain inside that contact region','scuff_branch'),
 ('silver_mirroring_surface_region_relation','silver_photo_support_phrase','silver photo support is a physical silver-gelatin paper print with a continuous visible edge','print_branch'),
 ('silver_mirroring_surface_region_relation','silver_photo_support_phrase','silver photo support is a physical silver-gelatin negative with a continuous visible edge','negative_branch'),
 ('acetate_channeling_shrinkage_relation','channel_network_phrase','curving connected channel or wrinkle network; here the selected structure is a continuous wrinkle network on the film','wrinkle_branch'),
 ('acetate_channeling_shrinkage_relation','image_delamination_phrase','image distortion or delamination follows the network; here the selected symptom is image distortion with the emulsion visibly attached','distortion_branch_existing_disjunction'),
 ('acetate_channeling_shrinkage_relation','image_delamination_phrase','image delamination follows the connected channels while the surrounding image remains attached','delamination_branch'),
 ('barrier_breakthrough_causal_event','displacement_phrase','debris dust fluid fragments or deformation traces remain localized along the contact-to-passage path; here attached paper flaps deform around the passing foam ball','attached_deformation_branch')]
branch_tests=[]
for pid,field,text,label in branches:
 c=contract_by[pid];ob=next(x for x in c['obligations'] if x['id']==pid);e={**positive_by[pid],field:text}
 labels=ob.get('runtime_expression',{}).get('prompt_label_terms',[]);prompt='. '.join(labels+list(e.values()))
 fs=ac.audit_visual_obligations({'visual_obligations':c},{'visual_obligation_evidence':{pid:e}},prompt)
 result=binding(field,text,ob['evidence_requirements'][field]);assert result['pass'] and not fs,(label,fs,result)
 branch_tests.append({'id':pid,'label':label,'field':field,'evidence':e,'binding_result':result,'audit_failures':fs})
# Measure natural single-branch lexical failures transparently. They alone do not
# prove the compiled OR is an unsupported AND or authorize general synonym expansion.
lexical=[]
for pid,field,text,label in [
 ('acetate_channeling_shrinkage_relation','image_delamination_phrase','image distortion follows the network while the emulsion remains visibly attached','single_distortion_clause'),
 ('acetate_channeling_shrinkage_relation','channel_network_phrase','curving connected wrinkle network follows the physical film surface','single_wrinkle_clause'),
 ('barrier_breakthrough_causal_event','rupture_phrase','fresh tearing radiates from that localized contact point where attached paper flaps curl around the foam ball','single_tearing_clause'),
 ('barrier_breakthrough_causal_event','displacement_phrase','deformation traces remain localized along the contact-to-passage path with attached paper flaps curling around the soft foam ball','single_deformation_clause')]:
 ob=next(x for x in contract_by[pid]['obligations'] if x['id']==pid)
 result=binding(field,text,ob['evidence_requirements'][field]);assert not result['pass']
 lexical.append({'id':pid,'label':label,'field':field,'phrase':text,'result':result,'interpretation':'Literal-anchor sensitivity. Existing source-disjunctive phrasing can represent this branch truthfully; no claim that all listed damage modes are physically required.'})
negative_requests=[
 ('pr_surface_wear_contact_owner','Photograph a clean new product with realistic materials.'),
 ('pr_surface_wear_contact_owner','Photograph rust on nearby metal beside fingerprints on glass.'),
 ('rb_repair_patch_locality','Photograph a wall covered in random digital stains.'),
 ('rb_contact_wear_locality','Photograph floor wear along a doorway route.'),
 ('costume_ccx_cc32_01','Photograph a costume with a repair patch overlaps the original cloth with a visible sewn border.'),
 ('costume_ccx_cc32_02','Photograph a costume where fraying is localized along the selected garment edge while the central fabric stays intact.'),
 ('costume_ccx_cc32_01','Photograph a distressed old costume.'),
 ('costume_ccx_cc32_02','Photograph a distressed old costume.'),
 ('silver_mirroring_surface_region_relation','Photograph a silver picture frame with blue glass glare.'),
 ('acetate_channeling_shrinkage_relation','Photograph dry cracked mud and porcelain hairline cracks.'),
 ('barrier_breakthrough_causal_event','Photograph a soft foam ball passing through a preexisting doorway.'),
 ('barrier_breakthrough_causal_event','Photograph rubble after an unseen event.')]
activation=[]
for pid,request in negative_requests:
 resolution,c=resolve(request);hits=[x for x in resolution['hits'] if x['profile_id']==pid and x.get('hard_eligible')]
 assert not hits,(pid,request,hits)
 activation.append({'target':pid,'request':request,'target_hard_hits':hits,'all_hits':resolution['hits']})
contexts={
 'heritage_object':{'subject':{'en':'a collection object under documentation','tags':['object','heritage_documentation','collection_object'],'kind':['object']}},
 'reuse_object':{'subject':{'en':'a product under reuse assessment','tags':['object','circular_materials','reuse_assessment'],'kind':['object']}},
 'freeze_thaw_environment':{'subject':{'en':'a freeze thaw crust observation','tags':['environment','natural_process','freeze_thaw'],'kind':['environment']}},
 'ordinary_object':{'subject':{'en':'an ordinary intact ceramic object','tags':['object'],'kind':['object']}},
 'ordinary_human':{'subject':{'en':'an adult portrait','tags':['human','adult'],'kind':['human']}},
 'breakthrough_context':{'subject':{'en':'a soft foam ball crossing a torn paper barrier','tags':['object','barrier_breakthrough'],'kind':['object']}}}
context_tests=[]
for cid in ['localized_heritage_condition_surface','localized_service_wear_surface','freeze_thaw_polygon_crust_surface','bt_breakthrough_barrier_prop']:
 row=by[cid];out={k:pg.compatible_with_slot_context(row['slot'],row['record'],v,data) for k,v in contexts.items()}
 assert out[{'localized_heritage_condition_surface':'heritage_object','localized_service_wear_surface':'reuse_object','freeze_thaw_polygon_crust_surface':'freeze_thaw_environment','bt_breakthrough_barrier_prop':'breakthrough_context'}[cid]]
 assert not out['ordinary_object'] and not out['ordinary_human'],(cid,out)
 context_tests.append({'id':cid,'slot':row['slot'],'outcomes':out})
projections=[{'id':row['id'],'source':pg.photo_candidate_semantics.semantic_source(row['record'],row['slot'],data.get('candidate_semantic_policy'))} for row in rows if row['kind']=='candidate']
save('consumer-proof.json',{'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'actual_bound_index_loaded':True,'index_sha256':sha((A/'photo_prompt_visual_profile_index.json').read_bytes()),'scope':'Request-only resolver; obligation compilation; literal evidence and component helpers; separately declared candidate context helper. No full public CLI, end-to-end qualified core, ranking test or pixels.','profile_tests':profile_tests,'source_branch_controls':branch_tests,'single_branch_lexical_diagnostics':lexical,'negative_activation_controls':activation,'context_carriers':contexts,'context_controls':context_tests,'semantic_projections':projections,'counts':{'positive_profiles':len(profile_tests),'positive_evidence_fields':sum(len(x['positive_evidence']) for x in profile_tests),'missing_fields':sum(sum(y['kind']=='omission' for y in x['negative_evidence_controls']) for x in profile_tests),'wrong_neighbors':sum(sum(y['kind']=='wrong_neighbor' for y in x['negative_evidence_controls']) for x in profile_tests),'component_omissions':sum(len(x['component_controls'])-1 for x in profile_tests),'source_branch_passes':len(branch_tests),'measured_lexical_failures':len(lexical),'negative_activation_controls':len(activation),'context_checks':sum(len(x['outcomes']) for x in context_tests)}})
modules=[{'path':str(Path(m.__file__).relative_to(R)),'sha256':sha(Path(m.__file__).read_bytes())} for m in list(sys.modules.values()) if getattr(m,'__file__',None) and str(A.parent/'scripts') in m.__file__]
save('runtime-manifest.json',{'imported_repository_modules':sorted(modules,key=lambda x:x['path']),'merged_data_sha256':canon(data),'compiled_registry_sha256':canon(reg),'actual_index_sha256':sha((A/'photo_prompt_visual_profile_index.json').read_bytes())})
print(json.dumps(json.loads((O/'consumer-proof.json').read_text())['counts']))
