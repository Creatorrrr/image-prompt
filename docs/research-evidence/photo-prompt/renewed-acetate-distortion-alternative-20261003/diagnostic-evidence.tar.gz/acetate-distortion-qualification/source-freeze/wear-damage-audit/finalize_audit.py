"""Record decisions and final read-only provenance after all bounded probes."""
from pathlib import Path
import hashlib,json,subprocess,sys
sys.dont_write_bytecode=True
R=Path('REPOSITORY_ROOT');O=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
canon=lambda x:sha(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())
def save(n,x):(O/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def git(*args):return subprocess.check_output(['git',*args],cwd=R,text=True)
records=json.loads((O/'source-records.json').read_text());manifest=json.loads((O/'source-manifest.json').read_text())
why={
 'pr_surface_wear_contact_owner':'KEEP four selected owner/material/contact/cleanliness relations; wear, fingerprints and dust are source options. The generic trace anchor permits the measured fingerprint and abrasion branches. No compulsory metal corrosion, shiny finish or global grunge is added.',
 'pr_surface_wear_contact_owner_candidate':'KEEP current generic material/contact wording and source owner relation. The original handled-glass example does not turn every selected wear trace into glass fingerprints.',
 'rb_repair_patch_locality':'KEEP deliberately selected wall patch, subtle difference and surrounding wall-joint continuity. The existing difference anchor accepts a texture transition; it does not force an additional color change.',
 'rb_repair_patch_locality_candidate':'KEEP narrower paint-tone candidate as authored. Its optional adoption commits to that tone difference; the profile texture branch is not permission to rewrite this candidate.',
 'rb_contact_wear_locality':'KEEP selected continuous handle/gripping-area contract. Both polishing and scuffs pass with its general local-wear anchor. Original research lists other possible owners, but the current selected manifestation explicitly commits to a handle.',
 'rb_contact_wear_locality_candidate':'KEEP full record, including the broader research owner note and concrete door-pull candidate sentence. That note does not authorize silently replacing an adopted door pull with floor wear.',
 'costume_ccx_cc32_01':'KEEP independent edge-fraying component. Exact fraying does not hard-activate sewn-patch sibling. Source CC32 explicitly says independent request-supported component activation.',
 'costume_ccx_cc32_02':'KEEP independently selected sewn patch overlapping original cloth. Do not loosen to printed rectangular graphics, adhesive-only patches or hidden borders.',
 'ccx_cc32_01':'KEEP garment-edge ownership, intact central fabric and human wearer scope. Wear alone does not establish injury, poverty or an actual violent event.',
 'ccx_cc32_02':'KEEP original-cloth overlap and visible sewn border; this is a repair trace, not a claim of active repair in the frame.',
 'silver_mirroring_surface_region_relation':'KEEP physical photographic substrate, local dense-region sheen, surface reflection, unaffected comparison and image-layer ownership. Existing silver photo support anchor accepts both print and negative branches.',
 'silver_mirroring_dense_region_surface':'KEEP localized photographic-object deterioration; not a silver picture frame, cool color grade or generic vintage overlay.',
 'acetate_channeling_shrinkage_relation':'PROPOSE only the explicitly declared image-distortion branch anchor in the image_delamination component and evidence field. All five groups, minima, substrate/network/comparison, gates and claim boundaries remain unchanged. Single-wrinkle wording is separately deferred.',
 'acetate_channeling_emulsion_surface':'KEEP deliberately narrower channeling AND delamination candidate. It is byte-structure unchanged from snapshot and must not be adopted for a distortion-only scene without delamination.',
 'barrier_breakthrough_causal_event':'KEEP physical finite-barrier/contact/aperture/crossing/local-trace system. Existing OR trace wording admits attached deformation rather than requiring free debris. DEFER unbundling all rupture-mode literal anchors; no broader mechanism or temporal-proof rewrite is proposed.',
 'bt_breakthrough_barrier_prop':'KEEP source-authored intact-versus-breached barrier and finite-thickness context. Original embedding explicitly permits crack network, puncture, shear plug or torn aperture. Primary breakthrough context remains required.',
 'localized_heritage_condition_surface':'KEEP localized wear/lifting/corrosion alternatives and collection-object documentation prerequisites. This optional row has no new hard all-of gate; material condition does not prove an exact cause or date.',
 'localized_service_wear_surface':'KEEP selected comparison between ordinary wear and a localized failure within reuse assessment. Pure ordinary wear is a different observation, not authority to remove this source-authored comparison.',
 'freeze_thaw_polygon_crust_surface':'KEEP selected polygon-crack/heave/fine-grain ensemble and freeze-thaw primary context. Original row is identical; no source-declared independent alternative justifies deleting a component or inferring cycle counts.',
 'replica_round_shield_prop':'KEEP staged weathering and explicit replica identity. Audit concerns weathering only, not already-covered weapon/object morphology. No real combat, authenticity or age claim is added.',
 'lacquered_wood_patina':'KEEP named lacquered-wood patina; no mandatory oxidation/corrosion hard contract exists. Legacy record is unchanged; no speculative chemical diagnosis or general material substitution.',
 'oxidized_copper_patina':'KEEP named copper appearance and original row. No inspected hard contract forces this texture onto brass, wood, skin or the whole image.',
 'porcelain_hairline_crack':'KEEP narrow named porcelain hairline texture; do not turn it into film channeling, structural collapse, actual injury or mandatory shattering.',
 'rust_pitting_texture':'KEEP named rust-pitting texture, including its original robot/scene-anchor embedding context. Do not generalize to all wear or use it as proof that every metal is rusted.',
 'brass_patina_texture':'KEEP brass-specific named texture, distinct from copper, wood and porcelain candidates. This optional row supplies no mandatory repair chronology or chemical analysis.'}
assert set(why)=={x['id'] for x in records}
decisions=[{'id':x['id'],'kind':x['kind'],'decision':'PROPOSE' if x['id']=='acetate_channeling_shrinkage_relation' else 'KEEP','canonical_sha256':x['canonical_sha256'],'reason':why[x['id']]} for x in records]
save('decisions.json',decisions)
checks=[]
for rec in records:
 d=json.loads((R/rec['file']).read_text())
 for key in rec['pointer'].split('/')[1:]:d=d[int(key)] if isinstance(d,list) else d[key]
 pinned=json.loads(subprocess.check_output(['git','show',manifest['head']+':'+rec['file']],cwd=R))
 for key in rec['pointer'].split('/')[1:]:pinned=pinned[int(key)] if isinstance(pinned,list) else pinned[key]
 checks.append({'id':rec['id'],'initial_sha256':rec['canonical_sha256'],'current_sha256':canon(d),'pinned_revision_sha256':canon(pinned),'current_equals_initial':d==rec['record'],'pinned_equals_initial':pinned==rec['record']})
files=[{'path':x['path'],'initial_sha256':x['sha256'],'ending_sha256':sha((R/x['path']).read_bytes()),'unchanged':sha((R/x['path']).read_bytes())==x['sha256']} for x in manifest['files']]
assert all(x['current_equals_initial'] and x['pinned_equals_initial'] for x in checks)
ending={'initial_head':manifest['head'],'ending_head':git('rev-parse','HEAD').strip(),'ending_status':git('status','--short'),'all_25_records_unchanged':True,'record_checks':checks,'file_checks':files,'changed_files':[x for x in files if not x['unchanged']],'scope':'All audit writes are outside the repository. Any unrelated future integration must recheck these hashes.'}
save('ending-verification.json',ending)
save('decision.json',{'decision':'ONE_MINIMAL_DATA_PROPOSAL','audited_current_records':25,'KEEP':24,'PROPOSE':1,'proposal_profile':'acetate_channeling_shrinkage_relation','changed_leaves':2,'new_anchor':'image distortion follows the network','source_application':'not_applied','scope':'Existing explicit distortion-versus-delamination branch only. No lexical synonym expansion, candidate changes, physical-cause inference or runtime change.','review_gate':'Independent DATA review; refreshed genuine visual-profile index because positive text changes; same frozen public before/after request and evidence; normal end-to-end qualification. No rendered-quality claim.','deferred':['Single wrinkle-network wording remains a measured literal-anchor limitation, with no frozen proposal.','Individual barrier tearing/deformation anchor expansions are measured but not bundled into this material-damage proposal.','Underlying conservation diagnosis and actual shrinkage rate cannot be established by these local textual probes.'],'main_revision':manifest['head'],'source_record_sha256':next(x['canonical_sha256'] for x in records if x['id']=='acetate_channeling_shrinkage_relation'),'proposal_record_sha256':canon(json.loads((O/'proposed-profile.json').read_text()))})
save('artifact-manifest.json',[{'path':str(f.relative_to(O)),'sha256':sha(f.read_bytes()),'bytes':f.stat().st_size} for f in sorted(O.rglob('*')) if f.is_file() and f.name!='artifact-manifest.json'])
print(json.dumps({'records_unchanged':len(checks),'source_files_changed':len(ending['changed_files']),'ending_head':ending['ending_head'],'KEEP':24,'PROPOSE':1,'changed_leaves':2}))
