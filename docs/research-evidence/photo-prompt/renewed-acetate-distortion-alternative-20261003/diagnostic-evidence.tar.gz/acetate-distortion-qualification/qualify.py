#!/usr/bin/env python3
"""Source-aware synthetic public-V6 qualification; writes only its artifact folder."""
from pathlib import Path
import copy, hashlib, json, os, subprocess, sys, time, traceback
sys.dont_write_bytecode=True
P=Path(__file__).resolve().parent; R=P.parent.parent/'image-prompt'; S=R/'skills/photo-prompt-image-generator/scripts'; A=S.parent/'assets'
sys.path.insert(0,str(S)); import prompt_generator as g; import audit_composed_prompt as audit
PID='acetate_channeling_shrinkage_relation'; CID='acetate_channeling_emulsion_surface'; FIELD='image_delamination_phrase'
PIN='f4094afc28403c12f7a88f1a4d9f06f66d5757ef'; SEED=1003
REVIEW=P.parent/'acetate-distortion-review'; SOURCE=P.parent/'wear-damage-audit'
def sha(b):return hashlib.sha256(b).hexdigest()
def read(p):return json.loads(p.read_text())
def dump(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def git(*args):return subprocess.check_output(['git',*args],cwd=R,text=True).strip()
def anchor(id,src,ev,dim,target=None,prop=None):
 x=dict(anchor_id=id,source_text=src,prompt_evidence=ev,dimension=dim)
 if prop:x.update(target=target,property=prop)
 return x

def embodiment(prompt,phase='agent_prepack'):
 return dict(contract_version='photo-embodiment-review/v1',provenance=phase,prompt_sha256=sha(prompt.encode()),scope='not_applicable',summary='One unoccupied archival-object or material-study scene. No living actor, body, hands, or bodily action appears. The scene is a textual specification, not verified pixels.',checks={})

def prepare():
 assert git('rev-parse','HEAD')==PIN and not git('status','--porcelain')
 assert not (P/'drafts').exists(),'Do not overwrite prior preparation'
 old=read(SOURCE/'before-profile.json'); accepted=read(REVIEW/'raw-accepted.json')
 ev={
 'plastic_film_support_phrase':'A translucent plastic film support presents its intact outer border and attached picture layer',
 'differential_shrinkage_phrase':'The support and emulsion shrink at different rates, leaving raised local buckles on the negative',
 'channel_network_phrase':'A curving connected channel or wrinkle network travels continuously through the same buckled photographic object',
 FIELD:'The image distortion follows the network, bending the pictured roofline while the emulsion stays visibly attached',
 'less_damaged_edge_phrase':'A less-damaged edge comparison retains flatter readable image detail alongside the wrinkled central area'}
 legacy=copy.deepcopy(ev);legacy[FIELD]='Image distortion or delamination follows the network; this scene realizes the distortion branch through the bent roofline and the attached emulsion'
 dela=copy.deepcopy(ev);dela[FIELD]='Localized image delamination follows the connected raised wrinkles, lifting a visible edge of the picture layer from that same negative'
 counts='exactly one translucent photographic negative'; concept='an archival film-surface study'; event='raised wrinkles bend the pictured roofline'
 framing='One continuous frame includes the entire outer border, connected central wrinkles, and the less-damaged comparison edge'
 scene='An archival film-surface study shows exactly one translucent photographic negative on a stable conservation table. Its raised wrinkles bend the pictured roofline. '
 tail=framing+'. Soft oblique light makes the raised relief and flatter edge legible together, while a plain dark mat separates the single object from its surroundings. The photographic treatment records the specified material relationships as visible form.'
 request_tail='Show exactly one translucent photographic negative, raised wrinkles that bend the pictured roofline, its entire outer border, and a less-damaged comparison edge in one continuous frame. Keep the picture layer visibly attached. No people.'
 cases=[]
 def film_case(id,request,evidence,route='exact',language='en',delam=False):
  local_scene=scene if not delam else scene.replace('Its raised wrinkles bend the pictured roofline.','Its raised wrinkles lift a local edge of the picture layer.')
  base=local_scene+' '.join(x+'.' for x in evidence.values())+' '+tail
  # Source the complete synthetic request honestly, with the known exact label or source components called out below.
  aa=[anchor('concept',request,concept,'concept'),anchor('subject',request,counts,'subject'),anchor('event',request,'raised wrinkles lift a local edge of the picture layer'if delam else event,'event'),anchor('object_count',request,counts,'composition','photographic_object','count'),anchor('crop',request,framing,'framing','photograph','complete_border_and_comparator')]
  for i,(field,phrase) in enumerate(evidence.items()):aa.append(anchor('relation_'+str(i),request,phrase,'material','film_surface',field))
  cases.append(dict(id=id,request=request,baseline=base,anchors=aa,subject=counts,event='raised wrinkles lift a local edge of the picture layer'if delam else event,setting='a stable conservation table with one plain dark mat',evidence=evidence,route=route,language=language,profile=PID,expected_before='fail'if id.startswith('distortion_') else 'pass',expected_after='pass',delamination=delam))
 film_case('distortion_en','Photograph the '+old['activation']['exact_terms'][0]+'. '+request_tail,ev)
 film_case('distortion_ko','아세테이트 필름 채널링 수축 관계를 촬영한다. 반투명 사진 네거티브 한 장만 보여 준다. 이어진 솟은 주름을 따라 지붕선 이미지가 휘어지고 유제는 붙어 있다. 전체 바깥 테두리와 덜 손상된 비교 가장자리를 하나의 연속된 프레임 안에 보여 준다. 사람은 없다.',ev,language='ko')
 film_case('legacy_or_en','Photograph the '+old['activation']['exact_terms'][0]+'. '+request_tail+' Preserve the source relation image distortion or delamination follows the network, choosing its attached distortion branch.',legacy)
 film_case('delamination_en','Photograph the '+old['activation']['exact_terms'][0]+'. Show exactly one translucent photographic negative with localized image delamination along connected raised wrinkles. Keep the entire outer border and less-damaged comparison edge in one continuous frame. No people.',dela,delam=True)
 film_case('component_distortion_en','Photograph one archival negative showing these relations together: '+'. '.join(ev.values())+'. Show the entire outer border in one continuous frame. No people.',ev,route='component')
 film_case('component_legacy_en','Photograph one archival negative showing these relations together: '+'. '.join(legacy.values())+'. Show the entire outer border in one continuous frame. No people.',legacy,route='component')
 # Korean paraphrase is source-declared and explicitly includes delamination; do not relabel it distortion-only.
 film_case('component_source_ko',old['semantics']['paraphrase_examples'][0]+'. 네거티브 한 장의 바깥 테두리와 비교 가장자리를 연속된 하나의 프레임에 보여 준다. 사람은 없다.',dela,route='component',language='ko',delam=True)
 controls=[
 ('paper_cracks','paper-fiber surface study','exactly one opaque paper sheet','polygonal cracks expose rough fiber edges','The fissures belong to the paper surface and its visible cut edge remains flat'),
 ('mud_cracks','dry-clay material study','exactly one shallow clay slab','polygonal cracks separate small clay plates','The fissures cut through dry earth above a solid clay base'),
 ('glass_cracks','fractured-glass material study','exactly one transparent glass pane','radial fractures spread from a central impact','Sharp fracture lines belong to the rigid glass pane and terminate at its visible perimeter'),
 ('digital_warp','digital-screen surface study','exactly one flat display','a software warp bends a pictured roofline','The display glass remains physically flat while evenly spaced digital waves deform only its displayed picture'),
 ('flat_scratches','scratched-film surface study','exactly one flat photographic negative','straight shallow scratches cross its image','Separate straight abrasion lines lie on a flat attached picture layer and never form connected raised wrinkles'),
 ]
 for id,con,sub,action,bound in controls:
  req=f'Photograph a {con}. Show {sub}; {action}. {bound}. Show the entire object perimeter in one continuous frame. No people.'
  base=f'A {con} shows {sub} resting on a stable plain support. In this frame, {action}. {bound}. One continuous frame includes the entire object perimeter and its nearby support. Soft side light separates the material surface from the plain surroundings and makes the requested geometry readable. The tight still-life composition keeps attention on this single object and its actual surface condition.'
  aa=[anchor('concept',con,con,'concept'),anchor('subject',sub,sub,'subject'),anchor('event',action,action,'event'),anchor('boundary',bound,bound,'material','surface','control_boundary'),anchor('object_count',sub,sub,'composition','object','count'),anchor('crop','entire object perimeter in one continuous frame','One continuous frame includes the entire object perimeter','framing','photograph','complete_perimeter')]
  cases.append(dict(id=id,request=req,baseline=base,anchors=aa,subject=sub,event=action,setting='a stable plain support',evidence={},route='ordinary_control',language='en',profile=None,expected_before='pass',expected_after='pass'))
 templates=[]
 for c in cases:
  req=c['request'];d=P/'drafts'/c['id'];base=c['baseline']
  env=dict(contract_version='photo-request-envelope/v1',provenance='requesting_user',request_id='synthetic-acetate-'+c['id'],request_text=req,request_sha256=sha(req.encode()),active_spans=[dict(span_id='scene',start=0,end=len(req),text=req)])
  ctl=g.creative_controls.resolve(req,overrides=dict(sensual=0,fetish=0,creativity=0,surreal=0),context=dict(subject_category='nonhuman',no_people=True,explicit_nonsexual=False),seed=SEED)
  core=dict(contract_version='photo-authorial-core/v3',provenance='agent_prepack',source_request=req,creative_controls_sha256=ctl['canonical_sha256'],interpreted_intent='A source-aware synthetic material photograph preserving the specified one-object count, surface ownership, complete perimeter and visible material state. Chemical cause, measured shrinkage rates and photographic capture date are unestablished by this text-only qualification.',subject=c['subject'],setting=c['setting'],event=c['event'],visual_priorities=[c['subject'],c['event'],'single-frame readable material geometry'],baseline_prompt_en=base,user_definitions=[],interpretation_provenance=[dict(term='synthetic material-state request',source_text=req,basis='request_context',resolution='Show '+c['event']+' on '+c['subject']+' with its stated crop and physical surface relationship.',sources=[])],unresolved_ambiguities=[],user_exclusions=['사람' if c['language']=='ko' else 'people'],runtime_forbidden_labels=[],intent_lock=dict(contract_version='photo-intent-lock/v2',priority='requesting_user',semantic_anchors=c['anchors'],locked_dimensions=['concept','subject','event'],open_dimensions=['setting','appearance','material','framing','composition','lighting','camera','color','atmosphere','relationship']),semantic_assertions=[],request_lineage=None,style=dict(domain='general_photo',family='conservation material still life',evidence=['legible material geometry','complete object perimeter']),variation_key='acetate-qualification-'+c['id'])
  for n,x in [('envelope',env),('controls',ctl),('core',core),('review',embodiment(base)),('spec',c)]:dump(d/(n+'.json'),x)
  if c['route']=='exact':
   vi=dict(contract_version=g.VISUAL_INTENT_CONTRACT_VERSION,provenance='agent_prepack',obligations=[dict(profile_id=PID,source='explicit_user_requirement',scope='request_only',source_text=old['activation']['exact_terms'][c['language']=='ko'],bindings=c['evidence'])]);dump(d/'visual-intent.json',vi)
  templates.append(dict(id=c['id'],case=c['id'],prompt=base,bindings=c['evidence'],expected_before=c['expected_before'],expected_after=c['expected_after'],kind='positive'if c['profile'] else 'ordinary_control',select_target_if_offered=c['route']=='component'))
 # A complete legacy scene retains valid core anchors while deliberately malformed evidence is independently rejected.
 base=next(c['baseline'] for c in cases if c['id']=='legacy_or_en')
 for field in ev:
  probe=copy.deepcopy(legacy);del probe[field]
  templates.append(dict(id='missing_'+field,case='legacy_or_en',prompt=base,bindings=probe,expected_before='fail',expected_after='fail',kind='missing_binding',failure_field=field))
 negatives=[('paper_owner','plastic_film_support_phrase','An opaque paper sheet has surface cracks'),('mud_owner','plastic_film_support_phrase','A dry clay slab has polygonal fissures'),('glass_owner','plastic_film_support_phrase','A rigid transparent glass pane has radial fractures'),('digital_warp',FIELD,'A software warp bends only a flat displayed JPEG'),('flat_scratches','channel_network_phrase','Separate straight abrasion lines cross the flat image'),('wrong_label_owner',FIELD,'A neighboring paper label bends while the negative image remains flat'),('no_edge_comparator','less_damaged_edge_phrase','Uniform severe damage extends over the whole object to every edge'),('no_differential_relation','differential_shrinkage_phrase','Decorative wrinkles have arbitrary geometry with a uniformly flat support'),('disconnected_network','channel_network_phrase','Raised isolated pits are scattered separately over the surface')]
 for name,field,value in negatives:
  probe=copy.deepcopy(legacy);probe[field]=value
  templates.append(dict(id='boundary_'+name,case='legacy_or_en',prompt=base+' '+value+'.',bindings=probe,expected_before='fail',expected_after='fail',kind='wrong_boundary_binding',failure_field=field,contradictory_content=True))
 limits=[('old_anchor_digital','image delamination is merely printed as a caption on a digital warp','pass','pass'),('new_anchor_digital','image distortion follows the network only in a digital simulation on a flat screen','fail','pass'),('new_anchor_label','image distortion follows the network is text on a nearby label beside the unchanged film','fail','pass'),('new_anchor_negated','There is no image distortion follows the network; the photographic layer is flat','fail','pass'),('korean_distortion_literal','이어진 망을 따라 필름 이미지가 왜곡되고 유제는 지지체에 붙어 있다','fail','fail')]
 for name,value,before,after in limits:
  probe=copy.deepcopy(legacy);probe[FIELD]=value
  templates.append(dict(id='limit_'+name,case='legacy_or_en',prompt=base+' '+value+'.',bindings=probe,expected_before=before,expected_after=after,kind='known_lexical_limit',failure_field=FIELD,contradictory_content=True))
 dump(P/'compositions.draft.json',templates)
 dump(P/'qualification-scope.json',dict(synthetic_source_aware=True,clean_precore=False,natural_query_recall=False,images=0,provider_calls=0,source_paths=['wear-damage-audit/artifact-manifest.json','acetate-distortion-review/REVIEW.md'],wire_provenance_note='The actual CLI requires requesting_user and agent_prepack wire enums. All cases here are openly synthetic canonical regression fixtures authored after source inspection; they are not organic user requests or independent pre-core samples.',source_exact_labels=old['activation']['exact_terms'],source_korean_paraphrase=old['semantics']['paraphrase_examples'][0],source_legacy_anchors=old['evidence_requirements'][FIELD]['must_mention_any'],new_anchor='image distortion follows the network',separate_candidate=dict(id=CID,policy='No slot candidate is selected in any composition; this AND-delamination candidate stays unchanged, including on distortion-only scenes.'),composition_selection_policy='Frozen prompts and evidence; select only the target optional visual concept if offered on component-only cases, never any slot candidates. Exact routes are hard obligations. Component eligibility alone is not a hard activation or recall guarantee.',limits=['Lexical helpers can accept label/digital/negated phrases that retain a permitted anchor. Full audit is textual validation, not physical-semantic or rendered-image proof.','Differential shrinkage is retained as a source-contract visual relation; a still prompt cannot establish measured rates, chemical cause, capture year, or elapsed chronology.','The old profile already says distortion OR delamination. This patch makes the standalone distortion literal admissible; it does not remove an old forced conjunction.','Korean exact activation and source-declared paraphrase do not establish arbitrary Korean evidence-anchor acceptance.'],control_layers=['complete coherent material-scene CLI/composition controls','deliberate active-profile missing and wrong-boundary evidence probes','known anchor-retaining adversarial textual limits']))
 print('Prepared',len(cases),'cases and',len(templates),'frozen-composition drafts')

def preflight():
 out=P/'preflight'/('attempt-%02d'%(len(list((P/'preflight').glob('attempt-*')))+1));out.mkdir(parents=True)
 rows=[]
 for d in sorted((P/'drafts').iterdir()):
  for f in d.glob('*.json'):dump(out/d.name/f.name,read(f))
  row=dict(id=d.name)
  try:
   env=g.load_request_envelope_arg(str(d/'envelope.json'));ctl=read(d/'controls.json');core=g.load_authorial_core_arg(str(d/'core.json'),request_envelope=env,creative_control_snapshot=ctl);policy=g.photo_embodiment.build_policy(core,read(d/'review.json'));row.update(status='pass',core_sha256=core['canonical_sha256'],lock_sha256=core['intent_lock']['canonical_sha256'],embodiment_policy=policy)
  except Exception as e:row.update(status='fail',error=str(e),traceback=traceback.format_exc())
  rows.append(row)
 dump(out/'report.json',rows);print(json.dumps([dict(id=x['id'],status=x['status'],error=x.get('error')) for x in rows],indent=2));return rows

def freeze():
 assert not(P/'manifest.json').exists(),'Never overwrite frozen inputs'
 assert(P/'ACCEPT-VERIFIED.json').exists(),'Await independently sealed ACCEPT and coordinator signal'
 rows=preflight();assert all(x['status']=='pass'for x in rows)
 assert git('rev-parse','HEAD')==PIN and not git('status','--porcelain')
 for d in [SOURCE,REVIEW]:
  for f in sorted(d.rglob('*')):
   if f.is_file():out=P/'source-freeze'/d.name/f.relative_to(d);out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(f.read_bytes())
 for f in(P/'drafts').rglob('*.json'):dump(P/'inputs'/f.relative_to(P/'drafts'),read(f))
 dump(P/'compositions.json',read(P/'compositions.draft.json'))
 files=sorted(set([*A.rglob('*.json'),*S.rglob('*.py'),*(S.parent/'precore').glob('*.*')]))
 source_hashes={str(f.relative_to(R)):sha(f.read_bytes())for f in files if f.is_file()}
 frozen=[*(P/'inputs').rglob('*.json'),*(P/'source-freeze').rglob('*'),P/'compositions.json',P/'qualification-scope.json',P/'ACCEPT-VERIFIED.json',P/'qualify.py']
 man=dict(baseline_head=PIN,case_ids=sorted(d.name for d in(P/'inputs').iterdir()),source_hashes=source_hashes,input_hashes={str(f.relative_to(P)):sha(f.read_bytes())for f in frozen if f.is_file()},frozen_at_utc=subprocess.check_output(['date','-u','+%FT%TZ'],text=True).strip())
 dump(P/'manifest.json',man);print('Frozen',len(man['case_ids']),'valid cases; source/runtime fixed')

def state(man):return dict(head=git('rev-parse','HEAD'),status=git('status','--porcelain'),source_hashes={f:sha((R/f).read_bytes())for f in man['source_hashes']})
def run(arm):
 man=read(P/'manifest.json');assert all(sha((P/f).read_bytes())==h for f,h in man['input_hashes'].items()),'Frozen-input drift'
 assert not(P/arm).exists(),'Never overwrite prior run'
 if arm=='before':assert state(man)==dict(head=PIN,status='',source_hashes=man['source_hashes'])
 else:assert(P/'AFTER-AUTHORIZED.json').exists(),'Coordinator must authorize AFTER'
 out=P/arm;out.mkdir();dump(out/'source-start.json',state(man))
 env={k:v for k,v in os.environ.items()if not any(t in k.upper()for t in ['API_KEY','TOKEN','SECRET','CREDENTIAL'])};env['PYTHONDONTWRITEBYTECODE']='1'
 report=dict(arm=arm,cases=[],visual_intent_cli=[],compositions=[],scope='Actual public V6 CLI and complete composed-prompt CLI audits, existing local deterministic retrieval, source-aware synthetic fixtures, no providers or rendered images.');packs={}
 for id in man['case_ids']:
  d=P/'inputs'/id;dest=out/id;dest.mkdir();cmd=[str(R/'.venv/bin/python'),str(S/'generate_photo_prompt.py'),'--seed',str(SEED)]
  for a,n in [('request-envelope','envelope'),('authorial-core','core'),('creative-controls','controls'),('embodiment-review','review')]:cmd+=['--'+a+'-json',str(d/(n+'.json'))]
  cmd+=['--output-file',str(dest/'pack.json')];t=time.monotonic();p=subprocess.run(cmd,cwd=R,env=env,capture_output=True,text=True,timeout=600);dump(dest/'cli.json',dict(command=cmd,exit_code=p.returncode,stdout=p.stdout,stderr=p.stderr,seconds=time.monotonic()-t));row=dict(id=id,exit_code=p.returncode,stderr=p.stderr)
  if p.returncode==0:
   pack=read(dest/'pack.json')[0];packs[id]=pack;vs=pack.get('visual_concept_candidates',{}).get('candidates',[])
   row.update(contract_version=pack.get('contract_version'),hard_profiles=[x['id']for x in pack.get('visual_obligations',{}).get('obligations',[])],optional_profiles=[dict(candidate_id=x['id'],profile_id=x.get('opt_in_contract',{}).get('obligation',{}).get('id'))for x in vs],slot_candidate_ids=[x['id']for b in pack['slots'].values()for x in b.get('candidates',[])],core_sha256=pack['authorial_core']['canonical_sha256'],lock_sha256=pack['authorial_core']['intent_lock']['canonical_sha256'],retrieval_sha256=pack['core_retrieval']['canonical_sha256'])
  report['cases'].append(row);dump(out/'report.json',report);print(arm,id,p.returncode,row.get('hard_profiles'),flush=True)
  if(d/'visual-intent.json').exists():
   cmd2=cmd[:-2]+['--visual-intent-json',str(d/'visual-intent.json'),'--output-file',str(dest/'explicit-intent-pack.json')];p2=subprocess.run(cmd2,cwd=R,env=env,capture_output=True,text=True,timeout=600);dump(dest/'explicit-intent-cli.json',dict(command=cmd2,exit_code=p2.returncode,stdout=p2.stdout,stderr=p2.stderr));report['visual_intent_cli'].append(dict(id=id,exit_code=p2.returncode,stderr=p2.stderr,expected_exit=1 if arm=='before'and id.startswith('distortion_')else 0));dump(out/'report.json',report)
 for t in read(P/'compositions.json'):
  id=t['id'];case=t['case']
  if case not in packs:report['compositions'].append(dict(id=id,status='not_run_no_pack'));continue
  pack=packs[case];core=pack['authorial_core'];lock=core['intent_lock'];prompt=t['prompt'];spec=read(P/'inputs'/case/'spec.json');chosen=[]
  if t.get('select_target_if_offered'):
   chosen=[x['id']for x in pack.get('visual_concept_candidates',{}).get('candidates',[])if x.get('opt_in_contract',{}).get('obligation',{}).get('id')==PID]
  composed=dict(core_retrieval_sha256=pack['core_retrieval']['canonical_sha256'],pack_id=pack['pack_id'],prompt_en=prompt,negative_en=pack['negative_en'],chosen_candidate_ids=[],chosen_visual_concept_ids=chosen,composer='agent',candidate_interpretations=[],authorial_core_binding=dict(source_authorial_core_sha256=core['canonical_sha256'],source_intent_lock_sha256=lock['canonical_sha256'],preserved_anchor_ids=[a['anchor_id']for a in lock['semantic_anchors']],preserved_evidence=[],authorial_decisions=[]),semantic_clarification_decisions=[dict(clarification_id=r['id'],decision='applied'if r.get('required_in_final_prompt')else'rejected',rationale='Preserve the frozen material scene and decline optional reinterpretation.',prompt_evidence=lock['semantic_anchors'][0]['prompt_evidence'])for r in pack.get('semantic_clarification',{}).get('candidates',[])],creative_augmentation_brief=dict(decisions=[dict(candidate_id=r['id'],decision='rejected',rationale='The frozen one-object material scene is complete without optional augmentation.')for r in pack.get('creative_augmentation',{}).get('candidates',[])]),embodiment_review=dict(source_contract_sha256=pack['embodiment_preflight']['canonical_sha256'],review=embodiment(prompt,'agent_postcomposition')))
  if spec['profile']:composed['visual_obligation_evidence']={PID:t['bindings']}
  dest=out/'compositions'/id;dump(dest/'composed.json',composed);direct=audit.audit_visual_obligations(pack,composed,prompt);effective,ef=audit.derive_effective_visual_obligation_contract(pack,composed)
  cmd=[str(R/'.venv/bin/python'),str(S/'audit_composed_prompt.py'),'--pack',str(out/case/'pack.json'),'--composed',str(dest/'composed.json')];p=subprocess.run(cmd,cwd=R,env=env,capture_output=True,text=True,timeout=600);dump(dest/'cli.json',dict(command=cmd,exit_code=p.returncode,stdout=p.stdout,stderr=p.stderr))
  try:result=json.loads(p.stdout)
  except Exception:result=dict(status='error',failures=[dict(reason=p.stderr)])
  dump(dest/'audit.json',result);dump(dest/'direct-visual.json',dict(failures=direct,effective_contract=effective,effective_contract_failures=ef))
  row=dict(id=id,case=case,kind=t['kind'],status=result['status'],expected=t['expected_before'if arm=='before'else'expected_after'],exit_code=p.returncode,failures=result['failures'],direct_visual_failures=direct,warnings=result.get('warnings',[]),chosen_candidate_ids=[],chosen_visual_concept_ids=chosen,effective_profile_ids=[x['id']for x in(effective or{}).get('obligations',[])],effective_gate_ids=(effective or{}).get('required_hard_gates',[]))
  report['compositions'].append(row);dump(out/'report.json',report);print(id,row['status'],[(f.get('check'),f.get('field'))for f in row['failures']],flush=True)
 # Source-aware component/normalization outcomes supplement, never replace, the above public CLI.
 reg=g.load_visual_obligation_registry(A/'photo_prompt_visual_obligations.json');profile=next(x for x in reg['profiles']if x['id']==PID);helpers=[]
 for t in read(P/'compositions.json'):
  if not t['bindings']:continue
  phrase=' '.join(t['bindings'].values());vi=dict(contract_version=g.VISUAL_INTENT_CONTRACT_VERSION,provenance='agent_prepack',obligations=[dict(profile_id=PID,source='explicit_user_requirement',scope='request_only',source_text=profile['activation']['exact_terms'][0],bindings=t['bindings'])])
  try:g.normalize_visual_intent(vi,reg);normalized=dict(ok=True)
  except Exception as e:normalized=dict(ok=False,error=str(e))
  helpers.append(dict(id=t['id'],component_match=g.candidate_pack_visual_component_match(profile,phrase),normalized=normalized))
 dump(out/'helper-boundaries.json',helpers);dump(out/'source-end.json',state(man));dump(out/'report.json',report)
 print('Finished',arm,'input drift:',any(sha((P/f).read_bytes())!=h for f,h in man['input_hashes'].items()),flush=True)
if __name__=='__main__':
 action=sys.argv[1]
 if action=='prepare':prepare()
 elif action=='preflight':preflight()
 elif action=='freeze':freeze()
 else:run(action)
