# Acetate standalone distortion: frozen BEFORE / AFTER qualification

## Decision and scope

**The bounded source correction recovers the intended exact-request compositions without a measured behavioral regression in the valid paired suite.** This is source-aware synthetic canonical qualification, with one explicitly disclosed optional-clarification membership residual. It is not a claim that every pack field is unchanged except the two source arrays.

The same runtime commit `f4094afc28403c12f7a88f1a4d9f06f66d5757ef`, seed, request envelopes, controls, cores, embodiment reviews, composition prompts, evidence, and authorial selection policy were retained. The only source changes admitted into AFTER were the accepted two-leaf profile addition and its regenerated visual-profile index. The qualifier made no source/runtime/test/API changes or publication.

## Valid paired observations

- **12/12 ordinary public V6 CLI cases succeeded in both arms.** Exact EN/KO labels hard-activate the same five-gate profile. All core, intent-lock, retrieval-query, slot-candidate, creative-control, and negative-prompt payloads are unchanged in all 12 cases.
- **30/30 interpretable paired complete-composition audit outcomes matched the frozen AFTER expectations.** BEFORE has 10 passes and 20 expected rejections within these 30; AFTER has 15 passes and 15 expected rejections. The separate component-only adjunct is excluded from these paired counts.
- Exact EN and KO standalone-distortion compositions change from a sole `image_delamination_phrase` anchor failure to a complete audit pass. The original OR relation and the delamination-only branch remain accepted.
- Legacy EN component wording and the source-declared Korean paraphrase remain optional discovery routes. Their real selected concepts preserve all five gates and pass complete audits in both arms. The Korean paraphrase explicitly includes delamination and is not characterized as distortion-only.
- The five coherent non-target scenes, paper cracks, clay cracks, glass fractures, flat-screen digital warp, and flat scratches, retain JSON-identical public packs and pass their complete compositions without the target profile.
- All five omitted relation bindings and nine wrong-owner/network/comparator/physical-boundary bindings remain rejected. These are intentionally malformed evidence probes against a complete active-profile scene, not coherent alternative photographs.
- The separate `acetate_channeling_emulsion_surface` slot candidate still means channeling AND delamination. Its source is unchanged and it is never selected. No slot candidate is selected in any composition.

## Separately reported adjuncts

1. **Component-only standalone distortion:** BEFORE correctly exposes no target concept, and the unchanged adjunct composition is rejected for orphan target evidence. Its frozen BEFORE pass expectation was wrong. AFTER genuinely exposes `visual-concept:acetate_channeling_shrinkage_relation`; the frozen conditional selection policy selects that offered concept; all five original gates become effective; and the unchanged complete composition passes. This is bounded AFTER-only conditional reachability, not a repaired benchmark or a valid BEFORE missing-anchor failure. It remains outside the 30 valid paired cases.
2. **Four supplemental explicit-visual-intent CLI inputs:** all remain invalid qualification evidence because their frozen `source_text` is the exact activation label rather than the full governing request span. BEFORE two fail source binding and the two distortion cases stop earlier at the missing anchor. AFTER all four fail source binding. None is counted as a valid positive/negative route, and no fixture was repaired or rerun with new content.

Raw totals across all 31 complete compositions: BEFORE 10 passes / 21 failures; AFTER 16 passes / 15 failures. The difference includes the one separately ineligible-BEFORE adjunct above.

## Exhaustive source-projection comparison

`comparison.json` records every recursive pack difference, including candidate order, rather than dropping whole fields.

- Four exact-label packs differ only in the two accepted target component/evidence arrays plus their recomputed content IDs.
- Two pre-existing component-discovery packs contain those same two target obligation changes. Their target candidate swaps order with the neighboring sheer-garment candidate because the production non-preferential shuffle hashes complete candidate content. Reverting only the exact two target arrays and re-running the unchanged production shuffle with seed `1003|0` reproduces the original order exactly. No candidate object or broad field is ignored.
- The standalone component case gains the exact target optional candidate and its optional clarification, both byte-for-byte equal to their counterparts on the existing legacy component route. All other optional candidate objects remain unchanged.
- **One residual remains explicitly recorded:** the standalone component route loses the non-required `pfe_volume_contrast` clarification. It already required unavailable adult context, was not an eligible selected concept, and was rejected in the BEFORE composition. The new target enters first in the same BM25F top-8 result; the former eighth result drops out. The unchanged production resolver reproduces both exact public clarification payloads from the frozen core and their original/updated registries and indexes. Its query hash is unchanged, BM25F is enabled, and embedding-query evaluation is disabled. This specific capacity consequence is retained in the diff; `strict_two_leaf_projection_equality` therefore remains false rather than silently exempting `semantic_clarification`.
- Five non-target control packs remain entirely equal as JSON, including their content IDs. All public pack IDs in both arms independently recompute correctly.

No prompt, control, query, object count, crop, slot result, mandatory relation, old anchor, gate, or selected non-target concept changed.

## Known lexical and evidentiary limits

The original profile already describes distortion OR delamination. The patch admits a standalone spelling of the existing distortion branch; it does not remove an old physical conjunction requirement.

The full lexical audit continues to accept misleading old-anchor digital-caption wording. New-anchor digital, nearby-label, and negated phrases change from absent-anchor rejection to acceptance. These are explicitly measured false-pass limits, not semantic improvements. In the negated case, component discovery rejects the phrase while direct normalization and the full literal audit accept it. The Korean-only distortion evidence phrase remains rejected in both arms; English composed evidence on Korean exact/source-paraphrase routes does not establish broad Korean binding support.

The coherent film scenes retain one physical negative, same-object film/image ownership, the connected raised network, complete outer-border crop, and a less-damaged edge comparator. Differential shrinkage is a source-contract posed relation. Neither a textual prompt nor this audit establishes measured shrinkage rates, chemical cause, material diagnosis, capture date, elapsed history, physical realism, natural-query recall, or image quality.

The qualifier made zero provider calls and rendered zero images. The coordinator separately supplied a genuine Gemini embedding refresh: `gemini-embedding-2`, 768 dimensions, one target profile changed, 1,509 other entries and 3,667 exact-lookup rows unchanged. AFTER registry digest: `a3e216f9528a1132e78a591cdb9bd1804c0a628d2e7c68b74510c76aa42e5fcc`. Current public CLI qualification exercises local deterministic BM25F/component routes; a refreshed stored vector is not evidence of query-embedding recall testing.

## Integrity and disposition

All frozen inputs and all 544 BEFORE artifact hashes remain unchanged. Every preparation failure, supplemental error, expectation miss, old output, and raw difference is retained. AFTER source state matches at start/end. The BEFORE Korean exclusion-grounding correction occurred before any retrieval and remains documented with its failed drafts.

Input manifest SHA-256: `44cfe6dc902632271027cb126c8efcc43a767c9305c9de86ef219594cf4e9874`.

Useful artifacts: `BEFORE.md`, `FINAL-SUMMARY.json`, `comparison.json`, `clarification-residual-diagnosis.json`, `before/report.json`, `after/report.json`, and the unmodified `manifest.json`.

Qualification is complete. Main publication remains held for the coordinator. No additional source adjustment or fixture rescue was performed.
