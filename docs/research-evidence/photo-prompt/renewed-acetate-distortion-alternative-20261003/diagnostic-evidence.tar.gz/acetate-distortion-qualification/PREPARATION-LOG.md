# Preparation record

All cases are source-aware synthetic canonical regression fixtures. No retrieval or fixture-based outcome was observed before input freeze.

Read-only inspection attempts retained:
- Initial repository inspection tried `cat package.json`; this Python repository has no package.json. Repository status was clean.
- One subsequent inspection omitted the repository workdir and consequently received missing-path messages for skills, evidence and tests. It was repeated with the correct workdir, before authoring or retrieval.
- An optional read of tests/test_photo_visual_concept_opt_in.py found no such file; the existing visual-obligation test file provided the public composition schema instead.

All preparation preflight attempts, including every failed draft and exact error, are retained under preflight/attempt-* before final freeze. Fixtures will not be repaired after retrieval.

Preflight attempt 01: 10/12 passed; the two Korean requests failed because the English exclusion `people` was not byte-grounded in their Korean source spans. Before any retrieval, changed only those draft exclusions to the literal source token `사람`, preserving requests, baselines, and relationships. The original failed drafts and errors remain in attempt-01.
