from pathlib import Path
import json,hashlib,subprocess,os
P=Path(__file__).resolve().parent;BASE=P.parent/'acetate-distortion-qualification';R=P.parent.parent/'image-prompt';read=lambda p:json.loads(p.read_text())
def hashes(p):
 size=p.stat().st_size;s1=hashlib.sha1(('blob '+str(size)+'\0').encode());s2=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):s1.update(b);s2.update(b)
 return s1.hexdigest(),s2.hexdigest()
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
original=read(BASE/'manifest.json');assert not(P/'manifest.json').exists()
for rel,h in original['input_hashes'].items():assert hashes(BASE/rel)[1]==h,rel
for root in sorted({Path(f).parts[0]for f in original['input_hashes']}):os.symlink(BASE/root,P/root,target_is_directory=(BASE/root).is_dir())
commits={'before':'639d3de32102e330d9ed56b117d2d9352494f5b2','after':'9d0fe0841b6ea5163c99b1f893440f6733a3b2a6'};names={'before':'runtime-original-data','after':'runtime-acetate-data'};arms={}
for arm,rev in commits.items():
 root=P/'snapshots'/names[arm];rows=subprocess.check_output(['git','ls-tree','-r',rev,'--','skills/photo-prompt-image-generator'],cwd=R,text=True).splitlines();tracked={}
 for row in rows:
  metadata,path=row.split('\t',1);mode,kind,blob=metadata.split();assert kind=='blob';actual,h=hashes(root/path);assert actual==blob,(arm,path,'git blob mismatch');tracked[path]=h
 arms[arm]=dict(commit=rev,snapshot=str(root),git_blob_verification_count=len(rows),tracked_sha256=tracked)
a,b=arms['before']['tracked_sha256'],arms['after']['tracked_sha256'];changed=[f for f in sorted(a.keys()|b.keys())if a.get(f)!=b.get(f)]
assert changed==['skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations_photo_era.json','skills/photo-prompt-image-generator/assets/photo_prompt_visual_profile_index.json'],changed
source_hashes={f:a[f]for f in original['source_hashes']};manifest=dict(baseline_head=commits['before'],case_ids=original['case_ids'],source_hashes=source_hashes,input_hashes=original['input_hashes'],original_manifest_sha256=hashes(BASE/'manifest.json')[1],original_root=str(BASE),arms=arms,data_differences=changed,runtime_skill_precore_identical_between_arms=True,fixture_changes=0,added_subject_category_assertions=0,original_artifacts_preserved=True)
dump(P/'manifest.json',manifest);dump(P/'AFTER-AUTHORIZED.json',dict(coordinator_authorized=True,scope='Paired incoming-runtime integration at unchanged frozen inputs; local only, no APIs/installs/source edits/publication.',after_commit=commits['after']))
# Extract the previously frozen run body verbatim, changing only the initial snapshot validation gate.
src=(BASE/'qualify.py').read_text();body=src[src.index('def run(arm):'):src.index("if __name__=='__main__':")]
old="if arm=='before':assert state(man)==dict(head=PIN,status='',source_hashes=man['source_hashes'])";new="if arm=='before':assert state(man)['source_hashes']==man['source_hashes']"
assert old in body;body=body.replace(old,new);(P/'reused_run_body.py').write_text(body)
dump(P/'harness-lineage.json',dict(original_script_sha256=hashes(BASE/'qualify.py')[1],extraction='Only def run(arm), ending before __main__',exact_replacement_before=old,exact_replacement_after=new,reason='Git-archive snapshots have no .git directory. State records the verified pinned revision and file hashes instead of manufacturing Git status. Commands, fixtures, prompts, selection logic, checks, and expected outcomes are unchanged.',run_body_sha256=hashes(P/'reused_run_body.py')[1]))
print('Frozen same inputs and verified',len(a),'+',len(b),'Git blobs; only two DATA files differ')
