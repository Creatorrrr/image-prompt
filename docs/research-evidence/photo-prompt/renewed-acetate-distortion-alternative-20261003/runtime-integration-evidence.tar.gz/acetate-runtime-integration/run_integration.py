#!/usr/bin/env python3
from pathlib import Path
import copy,hashlib,json,os,subprocess,sys,time,traceback
sys.dont_write_bytecode=True
P=Path(__file__).resolve().parent;arm=sys.argv[1];man=json.loads((P/'manifest.json').read_text());assert arm in ['before','after'];info=man['arms'][arm];R=Path(info['snapshot']);S=R/'skills/photo-prompt-image-generator/scripts';A=S.parent/'assets';sys.path.insert(0,str(S));import prompt_generator as g;import audit_composed_prompt as audit
PID='acetate_channeling_shrinkage_relation';CID='acetate_channeling_emulsion_surface';FIELD='image_delamination_phrase';PIN=info['commit'];SEED=1003
sha=lambda b:hashlib.sha256(b).hexdigest()
def read(p):return json.loads(p.read_text())
def dump(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def state(man):return dict(snapshot_commit=PIN,snapshot=str(R),source_hashes={f:sha((R/f).read_bytes())for f in man['source_hashes']})
def embodiment(prompt,phase='agent_prepack'):
 return dict(contract_version='photo-embodiment-review/v1',provenance=phase,prompt_sha256=sha(prompt.encode()),scope='not_applicable',summary='One unoccupied archival-object or material-study scene. No living actor, body, hands, or bodily action appears. The scene is a textual specification, not verified pixels.',checks={})
assert all(sha((R/f).read_bytes())==h for f,h in info['tracked_sha256'].items()),'Snapshot drift before execution'
exec(compile((P/'reused_run_body.py').read_text(),str(P/'reused_run_body.py'),'exec'),globals())
run(arm)
assert all(sha((R/f).read_bytes())==h for f,h in info['tracked_sha256'].items()),'Snapshot drift after execution'
