#!/usr/bin/env python3
from pathlib import Path
import copy,json,hashlib,sys
sys.dont_write_bytecode=True
P=Path(__file__).resolve().parent;Q=P.parent/'acetate-distortion-qualification';S=P/'snapshots/runtime-acetate-data/skills/photo-prompt-image-generator/scripts';sys.path.insert(0,str(S));import prompt_generator as g
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def diff(a,b,path=''):
 if isinstance(a,dict)and isinstance(b,dict):
  out=[]
  for k in sorted(a.keys()|b.keys()):
   if k not in a:out.append(dict(path=path+'/'+k,before_present=False,after=b[k]))
   elif k not in b:out.append(dict(path=path+'/'+k,before=a[k],after_present=False))
   else:out+=diff(a[k],b[k],path+'/'+k)
  return out
 if isinstance(a,list)and isinstance(b,list):
  if a and b and all(isinstance(x,dict)and isinstance(x.get('id'),str)for x in a+b):
   am={x['id']:x for x in a};bm={x['id']:x for x in b}
   if len(am)==len(a)and len(bm)==len(b):
    out=diff(am,bm,path+'/@id')
    if [x['id']for x in a]!=[x['id']for x in b]:out.append(dict(path=path+'/@order',before=[x['id']for x in a],after=[x['id']for x in b]))
    return out
  if len(a)==len(b):return[c for i,(x,y)in enumerate(zip(a,b))for c in diff(x,y,path+'/'+str(i))]
 return []if a==b else[dict(path=path,before=a,after=b)]
def rows_by_id(rows):return {x['id']:x for x in rows}
def candidate_delta(b,a):
 b=rows_by_id(b);a=rows_by_id(a)
 return dict(added=[a[k]for k in sorted(a.keys()-b.keys())],removed=[b[k]for k in sorted(b.keys()-a.keys())],changed=[dict(id=k,changes=diff(b[k],a[k]))for k in sorted(b.keys()&a.keys())if b[k]!=a[k]])
man=read(P/'manifest.json');report={'scope':'Incoming-runtime effects at identical DATA, independently for original DATA and corrected DATA. No new fixture or subject assertion.','arms':{},'input_manifest_sha256':sha(Q/'manifest.json')}
for arm in ['before','after']:
 old_state=read(Q/arm/'source-end.json')['source_hashes'];new_state=read(P/arm/'source-end.json')['source_hashes'];assert old_state.keys()==new_state.keys()
 different=[f for f in old_state if old_state[f]!=new_state[f]];assets=[f for f in old_state if '/assets/'in f];assert all(old_state[f]==new_state[f]for f in assets),arm+' DATA drift between runtimes'
 old_report=read(Q/arm/'report.json');new_report=read(P/arm/'report.json');old_comps={x['id']:x for x in old_report['compositions']};new_comps={x['id']:x for x in new_report['compositions']};cases=[]
 for id in man['case_ids']:
  b=read(Q/arm/id/'pack.json')[0];a=read(P/arm/id/'pack.json')[0];assert g.candidate_pack_recompute_id(copy.deepcopy(a))['pack_id']==a['pack_id'];assert g.candidate_pack_recompute_id(copy.deepcopy(b))['pack_id']==b['pack_id']
  slot_delta={}
  for slot in sorted(b['slots'].keys()|a['slots'].keys()):
   if b['slots'].get(slot)==a['slots'].get(slot):continue
   bc=b['slots'].get(slot,{}).get('candidates',[]);ac=a['slots'].get(slot,{}).get('candidates',[])
   slot_delta[slot]=dict(before_count=len(bc),after_count=len(ac),before_ids=[r['id']for r in bc],after_ids=[r['id']for r in ac],**candidate_delta(bc,ac))
  semantic_delta=candidate_delta(b.get('semantic_clarification',{}).get('candidates',[]),a.get('semantic_clarification',{}).get('candidates',[]));visual_delta=candidate_delta(b.get('visual_concept_candidates',{}).get('candidates',[]),a.get('visual_concept_candidates',{}).get('candidates',[]))
  cases.append(dict(case=id,changed_top_level_fields=[k for k in sorted(b.keys()|a.keys())if b.get(k)!=a.get(k)],full_recursive_diff=diff(b,a),slot_changes=slot_delta,semantic_clarification_changes=semantic_delta,visual_concept_changes=visual_delta,authorial_core_identical=b['authorial_core']==a['authorial_core'],creative_controls_identical=b['creative_controls']==a['creative_controls'],negative_prompt_identical=b['negative_en']==a['negative_en'],authorial_composition_identical=b['authorial_composition']==a['authorial_composition'],visual_hard_contract_identical=b.get('visual_obligations')==a.get('visual_obligations'),core_retrieval_changes=diff(b['core_retrieval'],a['core_retrieval']),before_total_slot_candidates=sum(len(x.get('candidates',[]))for x in b['slots'].values()),after_total_slot_candidates=sum(len(x.get('candidates',[]))for x in a['slots'].values()),before_slot_count=len(b['slots']),after_slot_count=len(a['slots']),typed_subject_assertions_added=False))
 outcomes=[dict(id=k,old_status=old_comps[k]['status'],new_status=new_comps[k]['status'],old_failures=old_comps[k]['failures'],new_failures=new_comps[k]['failures'],failure_details_changed=old_comps[k]['failures']!=new_comps[k]['failures'])for k in new_comps]
 report['arms'][arm]=dict(data_sha256_identical=True,runtime_source_files_changed=different,cases=cases,audit_outcomes=outcomes,audit_status_changes=[x for x in outcomes if x['old_status']!=x['new_status']],input_contracts_preserved=all(all(x[k]for k in ['authorial_core_identical','creative_controls_identical','negative_prompt_identical','authorial_composition_identical','visual_hard_contract_identical'])for x in cases))
report['all_input_contracts_preserved']=all(a['input_contracts_preserved']for a in report['arms'].values());report['any_runtime_audit_status_change']=any(a['audit_status_changes']for a in report['arms'].values());dump(P/'runtime-only-comparison.json',report)
print(json.dumps({k:v for k,v in report.items()if k!='arms'},indent=2))
for arm,a in report['arms'].items():
 print(arm,'runtime source delta',a['runtime_source_files_changed'],'audit changes',a['audit_status_changes'])
 print([(x['case'],x['before_total_slot_candidates'],x['after_total_slot_candidates'],x['before_slot_count'],x['after_slot_count'])for x in a['cases']])
