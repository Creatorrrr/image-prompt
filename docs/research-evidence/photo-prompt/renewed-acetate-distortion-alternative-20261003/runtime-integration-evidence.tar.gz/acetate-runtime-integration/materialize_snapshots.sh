#!/usr/bin/env bash
set -euo pipefail
OUT="$(cd "$(dirname "$0")" && pwd)"
REPO="${1:-$(cd "$OUT/../.." && pwd)/image-prompt}"
A="$OUT/snapshots/runtime-original-data"
B="$OUT/snapshots/runtime-acetate-data"
test ! -e "$A" && test ! -e "$B"
mkdir -p "$A"
git -C "$REPO" archive 639d3de32102e330d9ed56b117d2d9352494f5b2 skills/photo-prompt-image-generator | tar -x -C "$A"
cp -al "$A" "$B"
for path in skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations_photo_era.json skills/photo-prompt-image-generator/assets/photo_prompt_visual_profile_index.json; do
  rm "$B/$path"
  git -C "$REPO" show "9d0fe0841b6ea5163c99b1f893440f6733a3b2a6:$path" > "$B/$path"
done
ln -s "$REPO/.venv" "$A/.venv"
ln -s "$REPO/.venv" "$B/.venv"
printf '%s\n' 'Run prepare_integration.py next to verify every pinned Git blob and freeze the original inputs.'
