# Reproduce the paired incoming-runtime qualification

No provider calls, package installations, new assertions, runtime modifications, or DATA edits are needed. A checkout containing the two pinned commits and its existing `.venv` is required.

## Source and fixture provenance

- A: commit `639d3de32102e330d9ed56b117d2d9352494f5b2`, original DATA
- B: commit `9d0fe0841b6ea5163c99b1f893440f6733a3b2a6`, same runtime plus reviewed acetate DATA and genuine index
- Both snapshots contain only the tracked `skills/photo-prompt-image-generator` tree, verified against all 326 Git blob IDs each
- The B snapshot was made from hardlinks to A, then the two changed DATA-file links were removed and those exact committed B blobs materialized separately. No shared source inode was edited
- Both `.venv` paths are symlinks to the existing checkout interpreter
- `manifest.json` binds the original input hashes and both complete snapshot-file hash sets
- `portable-frozen-inputs/` contains actual copies of every original frozen input with unchanged bytes. The operational root links point to the preserved original qualification folder
- `harness-lineage.json` records the one orchestration change from the original runner: source snapshot verification replaces a Git-working-tree status assumption. All request, selection, composition, audit and expectation logic is unchanged

`prepare_integration.py` and the shell commands in the task transcript show the source materialization. Preserve original evidence; reproduce into a fresh directory rather than overwrite either saved arm.

## Run

With the recorded snapshots, input links and manifest in place, the two independent commands are:

```bash
PYTHONDONTWRITEBYTECODE=1 /path/to/existing/.venv/bin/python run_integration.py before
PYTHONDONTWRITEBYTECODE=1 /path/to/existing/.venv/bin/python run_integration.py after
```

The runner refuses to overwrite an existing output arm. To replay in another directory, materialize the same Git snapshots there, restore the fixture links from `portable-frozen-inputs/`, and update only the filesystem locations in the new replay manifest. Keep commit IDs, file hashes and all fixture bytes identical. The source `manifest.json` remains an immutable record of the qualification paths.

After both arms finish:

```bash
PYTHONDONTWRITEBYTECODE=1 /path/to/existing/.venv/bin/python compare_data_pair.py
PYTHONDONTWRITEBYTECODE=1 /path/to/existing/.venv/bin/python compare_runtime_only.py
```

The second comparison reads the original preserved `acetate-distortion-qualification` sibling outputs; those are included in the earlier acetate evidence archive committed at `62917903`. It separates runtime-induced changes at identical DATA from the new-runtime A/B DATA comparison. It never requires old runtime output bytes to match new runtime output bytes.

The four explicit-intent fixture failures and the BEFORE-only orphan-evidence adjunct are intentional preserved history, not replay blockers or permission to repair fixtures. No typed subject-category assertion may be added.
