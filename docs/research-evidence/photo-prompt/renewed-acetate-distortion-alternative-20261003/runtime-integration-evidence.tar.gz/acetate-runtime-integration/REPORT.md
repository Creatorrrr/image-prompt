# Acetate DATA integration on incoming runtime

**Result: bounded paired integration passed; no substantive selection or complete-audit regression was observed.** The original qualification is preserved in full. This integration neither adds assertions nor repairs old fixtures.

## Pinned arms and integrity

- A: incoming runtime `639d3de32102e330d9ed56b117d2d9352494f5b2` with original DATA
- B: merged `9d0fe0841b6ea5163c99b1f893440f6733a3b2a6`, the same incoming runtime plus the accepted two acetate source leaves and genuine refreshed index
- Isolated Git-archive snapshots verified against 326 tracked blob IDs each. Runtime, skill, and pre-core files are identical between A/B. Only the intended profile-source JSON and generated visual-profile index differ
- All 119 original frozen input hashes, plus all 711 original qualification artifacts, remain unchanged. Portable exact input copies and reproduction instructions are included
- No subject-category assertion was added. The original cores have empty semantic_assertions. Coarse nonhuman creative context was not relabeled object to bypass the new typed-category guard
- Both snapshot states are identical at their respective run start/end; no providers, installations, images, runtime or DATA edits, or publication occurred

## DATA comparison within the new runtime

- All 12 ordinary public V6 CLI cases succeed in each arm
- All 30 valid paired complete-composition expectations hold. A has 10 passes and 20 expected rejections; B has 15 passes and 15 expected rejections
- Exact EN/KO standalone distortion changes from a sole image_delamination_phrase anchor failure to a full composition pass. Legacy OR and delamination, supported EN/KO component opt-ins, all five material controls, five omitted relations, and nine wrong-boundary probes preserve their outcomes
- Five coherent non-target control packs are entirely JSON-identical across A/B. All core/query/slot/control/negative payloads are identical across the DATA pair
- The separate AND-delamination slot candidate remains unchanged and unselected. Every composition still chooses zero slot candidates
- The component-only adjunct remains excluded from the 30 valid paired count. A preserves its orphan-evidence rejection and frozen expectation miss. B genuinely exposes the target, the original conditional policy selects it, all five gates become effective, and the unchanged full composition passes. This is B-only conditional reachability
- Four explicit-intent fixtures remain invalid source_text evidence in each arm. A reproduces the original two early anchor failures plus two source-binding failures; B produces four source-binding failures. None is a valid negative/positive route or repaired fixture
- Raw complete-composition totals, including the adjunct, remain A 10 passes/21 failures and B 16 passes/15 failures

### Exhaustive DATA projections

`comparison.json` retains every recursive pack difference, including candidate order. Only the exact accepted target arrays are reversed for the comparison; content IDs are independently recomputed. Existing target candidate order changes are reproduced with the actual content-hash shuffle after exact source reversion, rather than ignored as a whole field.

The same one bounded residual from the original qualification remains: in the component-only case, the new acetate clarification enters the unchanged top-8 resolver set and displaces non-required pfe_volume_contrast, which required unavailable adult context and was already rejected. Target addition, exact residual content, and list-order consequence remain visible; strict two-leaf-only pack equality stays false. This is not a new integration regression or a blanket clarification exemption.

## Runtime-only comparison at identical DATA

Each new arm was compared separately to its corresponding original f4094afc arm. Every DATA asset hash is identical within those old/new comparisons. The three changed runtime files are audit_composed_prompt.py, photo_contracts.py, and prompt_generator.py; the new skill paragraph documents the optional subject-category handoff. V1–V5 history is preserved by the incoming work, while its separately validated V6 output contract is current. This qualification does not demand obsolete output bytes.

- Zero complete-audit status changes across all 31 recorded compositions in either old/new same-DATA comparison, including the invalid/ineligible history
- Zero visual-concept or semantic-clarification changes from the runtime alone
- Authorial cores, controls, negative prompts, authorial composition contracts, and hard visual contracts are unchanged
- Optional slot retrieval, dependent visual propositions, retrieval bindings, and creative augmentation change; full leaf differences are stored, not excluded
- The total candidate count remains 64 per case. Slots expand from 20–26 to 33–37, reflecting the incoming fair-allocation behavior
- Across the 12 cases, each same-DATA runtime comparison adds 441 candidate appearances and removes 441. These are case-level appearances, not unique global candidates
- 74 retained candidate appearances change eligible→ineligible under authored_property_scope with reason “effect overlaps a protected requester property”. These slots remain unselected in the frozen compositions
- surface_material stays absent in every case because no new typed primary-subject assertion was supplied. Exposure/eligibility changes are not claimed as candidate adoption or image-quality improvements

Exact per-case slot counts (identical metrics for the original-DATA and corrected-DATA runtime comparisons):

| Case | Old slots | New slots | Candidates old/new |
|---|---:|---:|---:|
| component_distortion_en | 21 | 35 | 64/64 |
| component_legacy_en | 21 | 35 | 64/64 |
| component_source_ko | 20 | 37 | 64/64 |
| delamination_en | 20 | 37 | 64/64 |
| digital_warp | 22 | 34 | 64/64 |
| distortion_en | 21 | 35 | 64/64 |
| distortion_ko | 20 | 35 | 64/64 |
| flat_scratches | 23 | 37 | 64/64 |
| glass_cracks | 23 | 33 | 64/64 |
| legacy_or_en | 21 | 35 | 64/64 |
| mud_cracks | 26 | 34 | 64/64 |
| paper_cracks | 26 | 33 | 64/64 |

## Limits

All original limits remain. This is source-aware synthetic canonical testing, not clean pre-core authorship, natural-query recall, physical-semantic validation, or rendered image evidence. The old relation already permits distortion OR delamination. The new literal does not remove an old physical conjunction.

The complete lexical audit retains old-anchor false passes and admits the frozen new-anchor digital/label/negated misleading phrases after the DATA change. Negation-aware discovery and literal evidence acceptance remain different. Korean-only literal evidence remains rejected. English composition evidence on Korean activation routes does not establish broad Korean-language bindings.

One-object ownership, connected raised network, complete border crop, and a less-damaged comparator remain frozen. Differential-shrinkage wording is a posed source relation; measured rates, chemistry, capture date, elapsed history, and diagnosis are unestablished.

No fresh embedding API was called during this integration. B uses the already verified genuine Gemini index; this local public CLI exercise is not a new embedding-query recall experiment.

## Artifacts and disposition

- `SUMMARY.json`: bounded decision, exact counts and integrity
- `comparison.json`: new-runtime A/B DATA differences and all behavior checks
- `runtime-only-comparison.json`: complete old/new same-DATA differences, all candidate and clarification changes, all audit outcomes
- `before/` and `after/`: original CLI commands, output packs, full compositions, stdout/stderr, complete audit results, source start/end states
- `manifest.json`, `harness-lineage.json`, `portable-frozen-inputs/`, `materialize_snapshots.sh`, and `REPRODUCE.md`: reproducible sources and exact inputs

The pair is complete. Main publication remains the coordinator’s responsibility; this worker performed no push.
