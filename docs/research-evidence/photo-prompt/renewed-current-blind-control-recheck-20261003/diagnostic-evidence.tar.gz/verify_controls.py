"""Validate exact frozen controls without generating or repairing any inputs."""
import json,sys,hashlib,subprocess,tarfile
from pathlib import Path
R=Path(__file__).resolve().parents[2]/'image-prompt';O=Path(__file__).resolve().parent;S=O.parent/'blind-scene-query-audit';sys.dont_write_bytecode=True
sys.path.insert(0,str(R/'skills/photo-prompt-image-generator/scripts'))
import prompt_generator as pg
D=pg.load_runtime_data();out={'loader':'load_runtime_data','quality_layers_loaded':pg.QUALITY_LAYERS_DATA_KEY in D,'dictionary_hash':pg.dictionary_hash(D),'loaded_slot_count':len(D['slots']),'loaded_row_count':sum(map(len,D['slots'].values())),'semantic_index_entry_count':len(D[pg.SEMANTIC_INDEX_DATA_KEY]['entries']),'arms':{},'pair_controls':[]}
for arm in ['public-cli','public-cli-property']:
 rows=[]
 for item in json.loads((O/arm/'frozen-input-manifest.json').read_text()):
  P=O/arm/'inputs'/item['case'];hashes={n:hashlib.sha256((P/n).read_bytes()).hexdigest()for n in item['inputs']};assert hashes==item['inputs'];assert all((P/n).read_bytes()==(S/arm/'inputs'/item['case']/n).read_bytes()for n in item['inputs'])
  c=json.loads((P/'creative-controls.json').read_text());e=pg.normalize_request_envelope(json.loads((P/'request-envelope.json').read_text()));core=pg.normalize_authorial_core(json.loads((P/'authorial-core.json').read_text()),request_envelope=e,creative_control_snapshot=c);embodiment=json.loads((P/'embodiment-review.json').read_text());pg.photo_embodiment.build_policy(core,embodiment)
  rows.append({'case':item['case'],'seed':item['seed'],'input_hashes_match_original_manifest':True,'original_bytes_preserved':True,'schema_valid':True,'embodiment_valid':True,'core_canonical_sha256':core['canonical_sha256'],'request_sha256':e['request_sha256'],'controls_canonical_sha256':c['canonical_sha256']})
 out['arms'][arm]=rows
for item in json.loads((O/'public-cli/frozen-input-manifest.json').read_text()):
 n=item['case'];a=json.loads((O/'public-cli/inputs'/n/'authorial-core.json').read_text());b=json.loads((O/'public-cli-property/inputs'/n/'authorial-core.json').read_text());new=b['intent_lock']['semantic_anchors'];old=a['intent_lock']['semantic_anchors'];b['intent_lock']['semantic_anchors']=old
 out['pair_controls'].append({'case':n,'only_added_anchors':a==b and new[:len(old)]==old,'new_anchor_count':len(new)-len(old),'all_other_three_inputs_equal':all((O/'public-cli/inputs'/n/f).read_bytes()==(O/'public-cli-property/inputs'/n/f).read_bytes()for f in ['creative-controls.json','embodiment-review.json','request-envelope.json'])})
P=O/'public-cli-property/inputs/blind_scene_006';core=json.loads((P/'authorial-core.json').read_text());pack=json.loads((O/'public-cli-property/baseline/blind_scene_006-pack.json').read_text())[0];guards=[]
for c in pack['slots']['camera_direction']['candidates']:
 entry=pg.candidate_pack_slot_entry_by_id(D,'camera_direction',c['entry_id']);sem=pg.photo_candidate_semantics.semantic_source(entry,'camera_direction',D.get('candidate_semantic_policy'))
 guards.append({'id':c['id'],'dimensions':sem.get('affected_dimensions',[]),'affected_properties_present':'affected_properties'in sem,'guard_if_called_with_missing_effects':pg.property_effects_allowed(core['intent_lock'],sem.get('affected_dimensions',[]),None),'guard_if_called_with_empty_effects':pg.property_effects_allowed(core['intent_lock'],sem.get('affected_dimensions',[]),[]),'actual_applicability':c['applicability']})
out['train_guard']=guards
# Bind byte-exact frozen input copies back to the repository-published evidence archive.
archive=R/'docs/research-evidence/photo-prompt/renewed-blind-scene-retrieval-20261003/diagnostic-evidence.tar.gz';checks=[]
with tarfile.open(archive)as t:
 for arm in out['arms']:
  for item in json.loads((O/arm/'frozen-input-manifest.json').read_text()):
   for n in item['inputs']:
    rel=f'{arm}/inputs/{item["case"]}/{n}';checks.append(t.extractfile(rel).read()==(O/rel).read_bytes())
out['published_archive_sha256']=hashlib.sha256(archive.read_bytes()).hexdigest();out['all_96_input_bytes_match_published_archive']=len(checks)==96 and all(checks)
(O/'controls-verification.json').write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n');print('Controls valid',sum(len(x)for x in out['arms'].values()),'anchors added',sum(x['new_anchor_count']for x in out['pair_controls']),'quality layers',out['quality_layers_loaded'],'archive match',out['all_96_input_bytes_match_published_archive'])
