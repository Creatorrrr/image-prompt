"""Read-only, two-case producer trace. Uses exact frozen inputs and full runtime loader."""
import sys,json,inspect,hashlib
from pathlib import Path
R=Path(sys.argv[1]);I=Path(sys.argv[2]);O=Path(sys.argv[3]);sys.dont_write_bytecode=True
sys.path.insert(0,str(R/'skills/photo-prompt-image-generator/scripts'))
import prompt_generator as pg
D=pg.load_runtime_data();source,start=inspect.getsourcelines(pg.retrieve_core_slots)
lines={start+i:kind for i,l in enumerate(source) for fragment,kind in [('if (not broad or not focal) and not observed:','gate'),('candidates = []','admission')] if fragment in l}
out={'loader':'load_runtime_data','quality_layers_loaded':pg.QUALITY_LAYERS_DATA_KEY in D,'dictionary_hash':pg.dictionary_hash(D),'cases':[]}
for n,target in [(2,'reflection_logic'),(4,'location')]:
 case=f'blind_scene_{n:03d}';P=I/case;controls=json.loads((P/'creative-controls.json').read_text());envelope=pg.normalize_request_envelope(json.loads((P/'request-envelope.json').read_text()));core=pg.normalize_authorial_core(json.loads((P/'authorial-core.json').read_text()),request_envelope=envelope,creative_control_snapshot=controls)
 stages=[]
 def trace(frame,event,arg):
  if frame.f_code is pg.retrieve_core_slots.__code__ and event=='line' and frame.f_lineno in lines and frame.f_locals.get('slot')==target:
   v=frame.f_locals;row={'phase':lines[frame.f_lineno],'slot':target,'before_total':v['total'],'limit':v['limit'],'remaining_total_cap':pg.CANDIDATE_PACK_TOTAL_CANDIDATE_LIMIT-v['total'],'eligible':len(v['entries']),'broad':v['broad'],'focal':v['focal'],'observed':v['observed']}
   if row['phase']=='admission':row.update({'ranked':v['ranked'],'selected_by_cap':v['ranked'][:min(v['limit'],pg.CANDIDATE_PACK_TOTAL_CANDIDATE_LIMIT-v['total'])]})
   stages.append(row)
  return trace if frame.f_code is pg.retrieve_core_slots.__code__ else None
 sys.settrace(trace)
 try:slots,binding,contract=pg.retrieve_core_slots(D,core,controls)
 finally:sys.settrace(None)
 query,fields=pg.core_slot_focus_text(D,core,target)
 out['cases'].append({'case':case,'slot':target,'query':query,'query_fields':fields,'contract':contract,'binding':binding,'stages':stages,'result':slots.get(target),'total_returned':sum(len(s['candidates'])for s in slots.values())})
 print(case,target,[(s['phase'],s['before_total'],s['eligible'])for s in stages],flush=True)
O.write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n')
