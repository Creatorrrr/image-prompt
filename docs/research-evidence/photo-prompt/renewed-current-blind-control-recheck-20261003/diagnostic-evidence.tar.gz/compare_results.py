import json,hashlib,subprocess,collections,copy
from pathlib import Path
O=Path(__file__).resolve().parent;S=O.parent/'blind-scene-query-audit';R=O.parent.parent/'image-prompt'
def read(p):return json.loads(p.read_text())
def flat(x):return {c['id']:c for v in x['slots'].values()for c in v['candidates']}
def counts(x):return dict(collections.Counter(c['applicability']['status']for c in flat(x).values()))
summary={'qualifying_pin':'6c2cc0f9311ee4c9c6a376781e3ea599d7bb6d14','current_pin':'6b9381a0585049cbaca1522dde405b4e6203b295','arms':{},'current_arm_comparison':[]}
for arm in ['public-cli','public-cli-property']:
 rows=[]
 for item in read(O/arm/'frozen-input-manifest.json'):
  case=item['case'];old=read(S/arm/'baseline'/f'{case}-pack.json')[0];new=read(O/arm/'baseline'/f'{case}-pack.json')[0];a,b=flat(old),flat(new)
  row={'case':case,'old_total':len(a),'new_total':len(b),'old_applicability_counts':counts(old),'new_applicability_counts':counts(new),'old_public_order_contract':old['authorial_composition']['candidate_order'],'new_public_order_contract':new['authorial_composition']['candidate_order'],'slot_sets_equal':set(old['slots'])==set(new['slots']),'baseline_preserved':old['authorial_core']['baseline_prompt_en']==new['authorial_core']['baseline_prompt_en'],'request_core_equal':old['authorial_core']==new['authorial_core'],'added':sorted(set(b)-set(a)),'removed':sorted(set(a)-set(b)),'added_candidates':[b[i]for i in sorted(set(b)-set(a))],'removed_candidates':[a[i]for i in sorted(set(a)-set(b))],'shared_candidate_changes':[{'id':i,'fields':{k:{'old':a[i].get(k),'new':b[i].get(k)}for k in set(a[i])|set(b[i])if a[i].get(k)!=b[i].get(k)}}for i in sorted(set(a)&set(b))if a[i]!=b[i]],'pool_count_changes':[{'slot':s,'old_candidate_count':old['slots'][s]['candidate_count'],'new_candidate_count':new['slots'][s]['candidate_count']}for s in set(old['slots'])&set(new['slots'])if old['slots'][s]['candidate_count']!=new['slots'][s]['candidate_count']]}
  rows.append(row)
 summary['arms'][arm]=rows
for item in read(O/'public-cli/frozen-input-manifest.json'):
 case=item['case'];a=flat(read(O/'public-cli/baseline'/f'{case}-pack.json')[0]);b=flat(read(O/'public-cli-property/baseline'/f'{case}-pack.json')[0]);summary['current_arm_comparison'].append({'case':case,'same_membership':set(a)==set(b),'differences':[{'id':i,'old':a[i]['applicability'],'corrected':b[i]['applicability']}for i in set(a)&set(b)if a[i]['applicability']!=b[i]['applicability']],'other_content_equal':all({k:v for k,v in a[i].items()if k!='applicability'}=={k:v for k,v in b[i].items()if k!='applicability'}for i in set(a)&set(b))})
old_trace=read(O/'producer-traces/qualifying-qualified-trace.json');new_trace=read(O/'producer-traces/qualified-trace.json');tr=[]
for a,b in zip(old_trace,new_trace):
 targets=[]
 for slot,old in a['targets'].items():
  new=b['targets'][slot];fields=['corpus_count','applicability_policy','query','query_fields','slot_block_reason','eligible_count','returned_count'];row={'slot':slot,'old':{k:old[k]for k in fields},'current':{k:new[k]for k in fields}}
  for label,v in [('old',old),('current',new)]:
   st=v['stage'];row[label]['stage']=None if st is None else {'before_total':st['before_total'],'limit':st['limit'],'broad_count':len(st['broad']),'focal_count':len(st['focal']),'observed_count':st['observed_count'],'broad_ranked_ids':[x['document_id']for x in st['broad']],'focal_ranked_ids':[x['document_id']for x in st['focal']]}
  targets.append(row)
 current_pack=read(O/'public-cli-property/baseline'/f'{b["case"]}-pack.json')[0]
 tr.append({'case':a['case'],'old_total':a['returned_total'],'new_total':b['returned_total'],'targets':targets,'new_producer_matches_current_pack_membership':{s:set(v)for s,v in b['production_returned_ids'].items()}=={s:{c['id']for c in v['candidates']}for s,v in current_pack['slots'].items()}})
summary['six_control_traces']=tr
# Summarize meaningful changed target slots already captured within the existing six-case producer trace.
changed=[]
for n,slot in [(10,'light_direction'),(11,'lighting')]:
 case=f'blind_scene_{n:03d}';row={'case':case,'slot':slot}
 for label,trace in [('qualifying',old_trace),('current',new_trace)]:
  c=next(x for x in trace if x['case']==case);stage=next(x for x in c['stages']if x['slot']==slot);row[label]={'stage':stage,'returned_ids':c['production_returned_ids'].get(slot,[])}
 changed.append(row)
summary['changed_cap_slot_traces']=changed
import sys
sys.path.insert(0,str(R/'skills/photo-prompt-image-generator/scripts'))
import prompt_generator as pg
for row in summary['changed_cap_slot_traces']:
 for label in ['qualifying','current']:
  st=row[label]['stage'];b=[x['document_id']for x in st['broad']];f=[x['document_id']for x in st['focal']];common=set(b)&set(f)
  row[label]['fused_intersection_ranked']=[x for x in pg.reciprocal_rank_fusion([b,f],k=30)if x['document_id']in common]
summary['totals']={arm:{'old':sum(r['old_total']for r in rows),'current':sum(r['new_total']for r in rows),'changed_membership_cases':[r['case']for r in rows if r['added']or r['removed']],'shared_candidate_changes':sum(len(r['shared_candidate_changes'])for r in rows),'old_ineligible':sum(r['old_applicability_counts'].get('ineligible',0)for r in rows),'current_ineligible':sum(r['new_applicability_counts'].get('ineligible',0)for r in rows)}for arm,rows in summary['arms'].items()}
(O/'comparison.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n')
print(json.dumps(summary['totals'],indent=2));print('current anchor-arm status changes',sum(len(x['differences'])for x in summary['current_arm_comparison']));print('six producer matches',all(x['new_producer_matches_current_pack_membership']for x in tr))
for r in changed:
 print(r['case'],r['slot'])
 for label in ['qualifying','current']:
  st=r[label]['stage'];print(label,'before',st['before_total'],'cap',st['limit'],'broad',[(i+1,x['document_id'],x['score'])for i,x in enumerate(st['broad'])],'focal',[(i+1,x['document_id'],x['score'])for i,x in enumerate(st['focal'])],'returned',r[label]['returned_ids'])
