import sys,json,hashlib,inspect,copy
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path('WORKSPACE_ROOT');REPO=ROOT/'image-prompt';OUT=Path('EVIDENCE_ROOT/current-blind-control-recheck/producer-traces');BASE=ROOT/'daylong-progress-20261002/blind-scene-query-audit/public-cli-property';P=BASE/'inputs/blind_scene_006';SKILL=REPO/'skills/photo-prompt-image-generator'
sys.path.insert(0,str(SKILL/'scripts'))
import prompt_generator as pg
controls=json.loads((P/'creative-controls.json').read_text());envelope=pg.normalize_request_envelope(json.loads((P/'request-envelope.json').read_text()));core=pg.normalize_authorial_core(json.loads((P/'authorial-core.json').read_text()),request_envelope=envelope,creative_control_snapshot=controls)
old=json.loads((BASE/'baseline/blind_scene_006-pack.json').read_text())[0]
D=pg.load_runtime_data();raw=pg.load_json(SKILL/'assets/photo_prompt_tags.json');out={'comparison':[]}
for label,d,c in [('original_raw_public_core',raw,old['authorial_core']),('runtime_public_core',D,old['authorial_core']),('raw_normalized_input_core',raw,core),('production_runtime_normalized_core',D,core)]:
 contract,picked=pg.frozen_core_context(d,c,controls)
 rows=[]
 for e in d['slots']['camera_direction']:
  rows.append({'id':e['id'],'eligible':pg.core_slot_entry_eligible(d,c,contract,picked,'camera_direction',e),'entry_block_reason':pg.entry_block_reason(e,'camera_direction',contract),'source':e})
 out['comparison'].append({'label':label,'contract':contract,'picked':picked,'rows':rows,'eligible_count':sum(r['eligible'] for r in rows)})
 print(label,contract['subject_category'],sum(r['eligible'] for r in rows),[(r['id'],r['eligible'],r['entry_block_reason']) for r in rows if r['id'] in ['worms_eye','extreme_low_hero_angle','extreme_low_angle_under_subject']],flush=True)
source,start=inspect.getsourcelines(pg.retrieve_core_slots);cutline=start+next(i for i,l in enumerate(source) if 'if (not broad or not focal) and not observed:' in l)
stages=[]
def trace(frame,event,arg):
 if frame.f_code is pg.retrieve_core_slots.__code__ and event=='line' and frame.f_lineno==cutline and frame.f_locals['slot']=='camera_direction':
  v=frame.f_locals;stages.append({k:v[k] for k in ['slot','total','limit','broad','focal','observed']})
 return trace if frame.f_code is pg.retrieve_core_slots.__code__ else None
sys.settrace(trace)
try:slots,binding,contract=pg.retrieve_core_slots(D,core,controls)
finally:sys.settrace(None)
out.update({'normalized_core':core,'controls':controls,'stages':stages,'returned_camera_direction':slots.get('camera_direction'),'saved_camera_direction':old['slots'].get('camera_direction'),'hashes':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [SKILL/'scripts/prompt_generator.py',SKILL/'assets/photo_prompt_tags.json',SKILL/'assets/photo_prompt_quality_layers.json',*P.glob('*.json')]}})
prepared=pg.prepare_candidate_source(D,core,controls,json.loads((P/'embodiment-review.json').read_text()),seed=829)
out['prepared_core_equals_normalized_core']=prepared['provenance']['authorial_core']==core
out['prepared_contract']=prepared['semantic_trace']['generation_contract']
raw_by={r['id']:r for r in out['comparison'][0]['rows']};runtime_by={r['id']:r for r in out['comparison'][3]['rows']}
out['eligibility_differences']=[]
_,picked=pg.frozen_core_context(D,core,controls)
for id in raw_by:
 if raw_by[id]['eligible']!=runtime_by[id]['eligible']:
  e=runtime_by[id]['source']
  out['eligibility_differences'].append({'id':id,'bare_load_json_eligible':raw_by[id]['eligible'],'load_runtime_data_eligible':runtime_by[id]['eligible'],'quality_layer_requirement_sources':pg.quality_layer_primary_context_requirement_sources(D,'camera_direction',e),'raw_context_compatible':pg.compatible_with_slot_context('camera_direction',e,picked,raw),'runtime_context_compatible':pg.compatible_with_slot_context('camera_direction',e,picked,D)})
out['unique_id_counts']={r['label']:len({x['id'] for x in r['rows']}) for r in out['comparison']}
(OUT/'coverage-correction-probe.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print('retrieved',[c['id'] for c in slots['camera_direction']['candidates']]);print('stage',stages)
