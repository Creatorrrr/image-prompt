from pathlib import Path
import json,hashlib,statistics,re
D=Path(__file__).resolve().parent;O=D/'production-integration';before={r['case']:r for r in json.loads((O/'before/results.json').read_text())};after={r['case']:r for r in json.loads((O/'after/results.json').read_text())};assert set(before)==set(after) and len(before)==13
rows=[]
for k,b in before.items():
 a=after[k];bp=json.loads((O/'before'/k/'candidate-pack.json').read_text())[0];ap=json.loads((O/'after'/k/'candidate-pack.json').read_text())[0]
 def ids(pack,field):return [r['id']for r in(pack.get(field)or{}).get('candidates',[])]
 changes={}
 for field in ['visual_concept_candidates','candidate_bundles','semantic_clarification','creative_augmentation']:
  bi,ai=ids(bp,field),ids(ap,field);changes[field]={'added':sorted(set(ai)-set(bi)),'removed':sorted(set(bi)-set(ai)),'order_identical':bi==ai}
 rows.append({'case':k,'cohort':b['cohort'],'before_pass':b['audit_passed'],'after_pass':a['audit_passed'],'before_hard_ids':b['hard_ids'],'after_hard_ids':a['hard_ids'],'before_gates':b['hard_gates'],'after_gates':a['hard_gates'],'ordinary_slots_value_identical':bp['slots']==ap['slots'],'baseline_identical':bp['authorial_core']['baseline_prompt_en']==ap['authorial_core']['baseline_prompt_en'],'optional_exposure_changes':changes})
main=[r for r in rows if r['cohort']in ['original_source_guided_6','fresh_source_unexposed_4']]
# Cohort names are preserved exactly; source-alignment controls have an explicit name.
main=[r for r in rows if not r['case'].startswith('source-guided-')];assert len(main)==10
n=0
for x in json.loads((O/'tests/results.json').read_text()):
 if x['file']!='dictionary-validation':n+=int(re.search(r'Ran (\d+) tests?',(O/'tests'/(x['file']+'.log')).read_text()).group(1))
summary={'actual_installed_runtime':True,'baseline_commit':'112c5a458e482f36ab9229b9d1db67461f8c12d4','main_cases':10,'main_before_pass':sum(r['before_pass']for r in main),'main_after_pass':sum(r['after_pass']for r in main),'supplemental_cases':3,'all_builds_admitted':26,'all_after_audits_pass':all(r['after_pass']for r in rows),'all_baselines_identical':all(r['baseline_identical']for r in rows),'all_ordinary_slots_identical':all(r['ordinary_slots_value_identical']for r in rows),'focused_tests':n,'provider_calls':0,'old_ko_partial_gate_loss':3,'counterfactual_content_checks_rejected':3,'current_boundary_byte_identical_to_prior_opacity':True,'rows':rows};(O/'SUMMARY.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');print({k:v for k,v in summary.items()if k!='rows'})
for r in rows:
 ch={k:v for k,v in r['optional_exposure_changes'].items()if v['added']or v['removed']};
 if ch:print(r['case'],ch)
