# Isolated before/after qualification: Korean portcullis trigger

## Decision and boundary

**The single-field exact-trigger proposal passes bounded isolated qualification on runtime `7e769e3e4a0da7068723830bb0c5c5c2dfd784c8`. Production integration and publication remain held and parent-owned.** No repository file, historical draft/installer, ordinary candidate, bundle, runtime code, provider or image was changed or used.

For the requested original six plus fresh four inputs, the unchanged zero-adoption compositions are **9/10 before → 10/10 after**. All 20 builds admit the exact same frozen inputs. The rescued case is the original Korean fully closed gate. The four source-unexposed, theme-targeted controls pass in both arms; this does not establish naturally sampled accuracy or broader bilingual recall.

**The original Korean half-lowered request loses all three automatic `pf_portcullis` render gates.** Its target becomes optional and stays unselected. Its unchanged scene, state/contact anchors and generic assertions pass, and actual prose substitutions violate its generic requester-preservation contract. That is a narrower hard-activation surface, not unchanged coverage, restored pixel gates, or proof that the loss is harmless in every scene. No fixture-specific alias was added.

## Same-runtime procedure

`run_qualification.py` uses the normal public `generate_candidate_pack` and `audit_composed_prompt` functions invoked by the current CLI, with normal envelope/core/control/embodiment normalization. It does not patch those functions, fabricate hits, mutate public packs, or forge vectors. Both arms use the same interpreter, runtime files, seed **1003**, controls, core and baseline.

The before data is loaded by the normal validated `load_runtime_data`. The after data changes only the merged registry's `pf_portcullis.activation.exact_terms[1]` in memory, using the frozen proposal. Its index is genuinely regenerated in memory by the current index builder functions:

- `reusable_vectors` verifies provider/model/dimensions and complete embedding text against the checked-in cache
- **1,622/1,622** embedding texts and original vectors are unchanged and reused; zero pending/new embedding requests
- `build_visual_profile_index_payload` recomputes registry hash, exact lookup, BM25F documents/statistics, recipe/policy metadata and index payload
- `validate_visual_profile_index_metadata` rejects the old index against the changed registry, then accepts the derived after index
- Exactly one compiled-registry value changes; the other **1,621** profiles are identical. Ordinary dictionary data and all original source hashes are unchanged

No full registry/index copies were written. `derived-index-receipt.json` retains reproducible hashes and cache-validation evidence. `source-mutation-diff.json` proves the exact changed field. The isolated before packs for all original six are **object-for-object identical to their earlier real public-CLI packs**. The after-arm counterfactuals were independently submitted through the public audit CLI.

The original six-request artifact/report remains historical evidence. This addendum qualifies the proposal without rewriting those results or silently upgrading its original freeze status.

## Input provenance and adapters

The supplied fresh-control file SHA-256 is preserved:

`a7d0482ada0850bb16d5360e4e8a8a610060e50f12e4877cb6cdb6f157a46941`

All four request strings and baselines are byte-identical to that file. Their prose author was source-unexposed; the schema adapter was source-exposed and is identified as such. All four adapters passed concrete-word minima and normal normalization on their first attempts, including the grammatical negative passage descriptions; no gate state, request wording, or baseline was rewritten to obtain admission.

One schema ownership refinement is explicit: fresh English closed control `stone_gate_en_02` records its prescribed view facing the gateway under `camera/viewpoint.direction`, instead of `composition`. The original schema-valid attempt remains as `authorial-core.attempt-1.json`; corrected ownership is `attempt-2.json`. Exact source/evidence and baseline/request bytes are unchanged. Both arms use the final pre-retrieval hash. See `fresh-controls/adapter-attempts.json`.

## Main ten-input matrix

| Input | Before hard profile | After hard profile | Audit before → after | After target optional |
|---|---|---|---|---|
| Original KO partly lowered | portcullis | none | pass → pass | yes, unselected |
| Original EN partly lowered | portcullis | portcullis | pass → pass | no; already hard |
| Original KO fully lowered | portcullis, conflicting | none | **fail → pass** | no |
| Original EN fully lowered | none | none | pass → pass | no |
| Complete drawbridge sibling | drawbridge | drawbridge | pass → pass | no |
| Broad-name closed portcullis | none | none | pass → pass | yes, unselected |
| Fresh KO coastal closed gate | none | none | pass → pass | yes, unselected |
| Fresh EN halfway gate over road | none | none | pass → pass | yes, unselected |
| Fresh KO one-third-lowered gate | none | none | pass → pass | no |
| Fresh EN closed courtyard gate | none | none | pass → pass | no |

The removed Korean-closed failures are precisely the incompatible component-3 anchor and the required target clarification. Its threshold contact, fully closed position and closed passage remain verbatim. No optional selection is used to create or repair that failure.

The English partial and drawbridge sibling retain exactly their former third-component duties and three gates. No English trigger, selected-variant definition, evidence requirement or gate is broadened.

## Separately labeled canonical-source controls

Three extra controls were frozen before their own retrieval. They are source-alignment probes, not members of the fresh four, and replace none of the original inputs:

1. New canonical Korean partial phrase: before target optional/non-hard; after hard `pf_portcullis`, with the same complete three-component duty and gates as English; unchanged composition passes both
2. Frozen Korean closed-state substitution: non-hard before/after; unchanged fully closed composition passes both
3. Frozen Korean guide-edge-contact omission: non-hard before/after; target remains optional/unselected, and unchanged composition passes both. Complete contact in its baseline is an agent choice, not falsely marked requester-owned contact

Including these controls, **all 26 builds admitted**, **12/13 before and 13/13 after** unchanged compositions pass. Every failure is retained. No data-specific alias restores the old partial fixture's activation.

## Generic state/contact enforcement after the gate loss

The original Korean partial after-pack has no automatic target profile. Its real composed prompt was changed in three specific ways while the frozen pack/core/binding hashes and selections stayed unchanged. A fresh postcomposition review binds each changed prompt. Supplied evidence spans were updated truthfully to the changed prose; no field/hash was omitted or forged.

| Actual prose change | Actual generic prompt-content failure |
|---|---|
| Replace partial/open state with fully lowered contact and closed passage | `intent_lock_prompt_evidence`: `gate_state`, `passage_result` |
| Replace the open lower passage with a blocking stone wall | `intent_lock_prompt_evidence`: `passage_result` |
| Replace grid edges seated inside guides with grid edges standing clear of guides | `intent_lock_prompt_evidence`: `guided_grid_contact` |

All three public audit CLI runs fail on those actual missing requester-anchor phrases. State/passage cases also reject their now-different typed evidence map; that metadata equality failure is shown separately and **not counted** as the preservation proof. The contact case establishes an actual prompt-content failure independently of the state assertion map.

This qualifies the tested literal source-bound substitutions. It does not establish a general natural-language contradiction detector, occurrence routing, or pixel fidelity. Keeping old anchor prose while adding contradictory prose is outside this claim and remains runtime territory. The lost profile render checklist is not recreated by these generic checks.

See `counterfactuals/results.json` and every preserved composed/audit artifact.

## Exposure, displacement and actual adoption

Every ordinary, bundle, augmentation and optional visual selection is empty. Every composed prompt equals its corresponding input baseline. No candidate displaces authored scene prose.

`pairwise-results.json` records complete before/after differences for ordinary IDs, bundle IDs, optional visual IDs, required/eligible clarification status, and hard gates. Observed differences are limited to:

- Old KO partial gains optional `visual-concept:pf_portcullis`; its target clarification changes required → eligible, and the unrelated `pfe_one_shoulder` clarification is no longer exposed
- Old KO closed loses the required target clarification and hard duty
- New canonical KO partial changes the target from optional to hard; optional `y2kr_checkerboard` and its clarification enter the exposed inventory
- Ordinary candidate IDs and bundle IDs are unchanged in every pair. Other main-input exposures are unchanged

The checkerboard/one-shoulder exposure differences are reported collateral, not adopted content or claimed quality improvements. Every such optional alternative remains declined.

## Integrity, remaining integration work and artifacts

HEAD remained `7e769e3e` throughout the per-case checks and both final receipts; worktree is clean. Original source hashes, fresh request bytes and frozen input hashes still match. The September research drafts/installers are untouched.

The initial palace suite remains six current tests passing. This qualification adds independently stated state-boundary expectations, genuine derived-index validation, 26 actual consumer builds/audits and three actual-prose counterfactual audits. It does **not** claim a complete post-integration production regression suite or a verified main-branch installation. Recheck caches and run the relevant source/index, clarification, selection-to-gate and render-review regressions on the parent's actual integration runtime before acceptance/publication.

Key files:

- `summary.json`: compact final decision and denominators
- `pairwise-results.json`: every admission/duty/optional/displacement/selection delta
- `results.json` plus `../qualification-extra/results.json`: complete actual paired-consumer receipts
- `before/`, `after/` and `../qualification-extra/`: full packs, unchanged compositions and audits
- `counterfactuals/`: truthful changed prompts and independent audit CLI outputs
- `derived-index-receipt.json`, `source-mutation-diff.json`, `final-pin.json`: source/index qualification
- `../fresh-controls/`: unmodified source-unexposed prose and preserved schema adapters
- `../qualification-artifact-manifest.json`: hashes of this qualification extension, separate from the original reviewed artifact manifest
