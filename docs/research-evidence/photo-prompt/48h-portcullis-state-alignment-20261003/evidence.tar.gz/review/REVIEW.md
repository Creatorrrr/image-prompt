# Independent review: portcullis bilingual trigger/state alignment

Reviewed 2026-10-03 against repository `7e769e3e4a0da7068723830bb0c5c5c2dfd784c8`.

## Decision

**Approve the direction of the frozen exact-trigger replacement as a bounded DATA correction, subject to same-runtime integration qualification. Do not mark it installed, accepted, or publication-ready yet.** The unchanged Korean closed-scene failure is a real current-consumer consequence, and the proposed Korean wording describes the intermediate state already selected by the English profile and its third component.

Accepting this direction explicitly accepts a narrower automatic hard-activation surface: **the original Korean half-lowered request also loses its literal exact match.** Its separate half-lowered sentence is not the new whole exact term. Preserving that request's frozen prose and generic assertion duties is necessary, but it does not preserve automatic `pf_portcullis` render gates. This is a genuine coverage tradeoff, not a synonym-only change or proof of unchanged bilingual recall. Do not add that fixture sentence as an alias or change its request to conceal the loss.

Two integration clarifications matter:

1. **The exact-trigger-only proposal needs zero new visual-profile embeddings at this pin.** It still needs a genuine visual-index rebuild and validation. The current report's characterization as a provider-dependent rebuild is too strong for this exact proposal.
2. **Preserve the September research archive.** Its installer could reproduce the old wording if manually rerun, but this review found no active runtime/current maintenance entry point that invokes it. There is no established live-producer defect requiring an edit to the historical installer or its drafts.

## Independently verified evidence

`verify_review.py` reads the pinned checkout and writes only this review directory. It made no provider calls, generated no index, fabricated no vectors/hits, and modified no repository files.

- All **18 source hashes**, **94 archived artifact hashes**, and all six cases' frozen input hashes match their manifests
- The complete frozen proposed profile differs from the current raw profile at exactly `/activation/exact_terms/1`
- All nine frozen literal-control expectations reproduce with the production alias/negation functions
- The real merged-registry resolver with the actual checked-in index reproduces the current hard hits: Korean partial, English partial, Korean closed → `pf_portcullis`; English closed and broad-name closed → none; drawbridge → `pf_drawbridge`
- All six saved composed objects were independently replayed through the actual public `audit_composed_prompt.py` commands. Every complete JSON result equals its archived result: five passes and the same Korean-closed failure
- Checkout HEAD and clean worktree are unchanged

The review did not rerun public generation because valid original packs were already available; it read and hash-verified those packs and independently reran their public audits. It did not produce an after-data public pack. The requests remain source-guided synthetic maintenance probes, not blind or naturally sampled accuracy evidence.

## Causal assessment

The causal claim is supported, with appropriately narrow scope:

1. The historical Korean exact term specifies a gridded gate inside an entrance and its edges seated in vertical guides, then specifies **vertical rather than swinging motion**. It does not specify a partly lowered state
2. A gate lowered fully onto the threshold can satisfy all those mechanism clauses. The frozen Korean closed request makes that endpoint explicit
3. `resolve_visual_profile_hits` (`prompt_generator.py:6329–6474`) grants an exact hit from requester sources. The profile has no additional hard-activation groups; the generic helper returns true when that optional policy is absent (`visual_profile_contracts.py:51–68`)
4. The exact hard hit is projected into `candidate_pack_visual_obligations` (`prompt_generator.py:7428ff`). Its component 3 requires `the gate is partly lowered along those upright grooves`
5. The same active profile creates a non-revisable required clarification (`prompt_generator.py:7880–7950`)
6. The faithful unchanged closed composition supplies its real fully-closed evidence and rejects the incompatible clarification. The auditor rejects exactly the missing partly-lowered component anchor (`audit_composed_prompt.py:1801–1815`) and rejection of required clarification (`:4405–4415`)

This does not depend on optional-candidate adoption: all six compositions select no ordinary candidate, bundle, augmentation or visual concept. The English closed peer uses the identical baseline, has no target hard obligation, and passes. The ordinary partially-lowered location candidate is exposed in both language peers and stays optional, so its mere exposure does not explain the Korean-only audit failure.

The experiment demonstrates a DATA over-activation and faithful-composition blockage. It does not show a photographic improvement, general contradiction handling, natural Korean recall, or post-change performance. The fact that a dishonest composer could append incompatible evidence would not make this a correct contract; the meaningful test preserves the requester scene.

## Source lineage and maintenance

The mismatch is inherited authored scope, not a transcription error:

- `docs/research-evidence/photo-prompt/palace-fortification-20260909/build-research-data.py:63` creates a partly-lowered English scene alongside the broader Korean third gate
- `candidate-drafts.json:321–364` preserves that profile; its bundle proposal also retains the broad third Korean group (`:3787ff`)
- `profile-matrix.md:14` shows the same broad Korean relation
- `install-runtime.py:17,47–59` uses a partly-lowered English operationalization and derives the Korean exact term by joining the draft's three Korean descriptions
- `implementation-report.md:13` declares that all three relations of the **selected variant** are needed for hard activation
- The profile definition, authored component 3, evidence, instruction, gate, ordinary English location candidate and bundle proposition consistently select the intermediate variant

The research profile itself labels the official sources as architectural premises and the wording/gates as proposed operationalizations. This review verifies that repository lineage, not a new independent reading of the external historical sources. The repair therefore aligns the selected authored variant; it should not claim that all portcullises must be partly lowered or that the source publishers required this trigger.

### Historical installer versus live producer

The September implementation report links the installer as that implementation's source. Searches of current scripts/tests/maintenance and tracked Python/Markdown/config entry points found no live invocation of this dated installer or draft builder. Current `references/maintenance.md` instead directs changes to authored registry/dictionary assets, followed by generated-index rebuilding. Merely being executable and capable of overwriting assets does not establish that a historical installer is a canonical live producer.

**Recommended treatment:** keep the old drafts, builder, matrix, installer, old maintenance record and saved run receipts byte-identical. Add a dated reviewed correction record binding the old/current profile hash, exact changed field/value, source lineage, rationale, control outcomes and acceptance boundary. State there that the September installer reproduces its historical installation and is not the producer for the corrected current asset. Do not silently rewrite its historical evidence. No installer edit is required by evidence presently available.

For a registry-only change, the ordinary palace extension and its existing maintenance reference need not change, since that ordinary source is unchanged. If the ordinary extension is separately changed, follow the established immutable-maintenance convention demonstrated by `tests/test_photo_liminal_active_use_korean_data_cleanup.py:60ff` and its `maintenance-binding-plan.json`: preserve the old record/snapshot, create a new reviewed current record, and update the live reference/hash without rewriting the old receipt. A hypothetical future supported producer must consume the corrected current source or dated revision explicitly; do not rerun the old installer as a repair step.

## Paired ordinary/profile consistency

The two paired ordinary rows have different responsibilities:

- `pf_portcullis_location`: English label, `concept_units`, keyword sentence, and embedding description all specify a **partly lowered** gate in vertical side grooves. Its Korean label `수직 격자 낙하문 공간 관계` is a coarse category label that omits this selected state. It is less specific, rather than explicitly asserting a different endpoint
- `pf_portcullis_composition`: the English asks for an oblique view showing grid-edge/guide contact. Neither language imposes partial closure in this standalone composition candidate. Do not add a partly-lowered condition to this row merely because the associated profile has one
- The ordinary bundle's English proposition and component 3 already agree with the profile. No bundle duty needs loosening or broadening

**Recommendation:** the narrow hard-trigger fix may keep both ordinary rows unchanged. This six-case matrix does not establish a separate harmful ordinary-label consequence, and the actual public candidate displays the correct English intermediate-state concept rather than the coarse Korean label. Do not claim this scope completes all Korean/English catalog specificity alignment.

If complete bilingual source/catalog specificity is desired, prepare a separate reviewed Korean **location-label-only** clarification, for example `부분적으로 내려온 수직 격자 낙하문 공간 관계`, preserving its English concept, aliases, effects, other candidate and bundle. That is a justifiable source-clarity change, not a demonstrated rescue in the present experiment. It changes the ordinary semantic document because `semantic_text_for_entry` includes `ko label` (`prompt_generator.py:10480–10510`), unlike exact-only visual aliases. It therefore needs a current maintenance record, ordinary index refresh, any genuinely missing compatible embedding, and bounded retrieval/collateral checks. Do not bundle it into the current single-field acceptance or imply its cost is zero. No such extra proposal was installed or frozen by this review.

The known architectural `setting`-only ordinary effect versus state-in-`event` question remains the already-deferred generic effect/scope issue. Optional exposure and zero adoption in these cases do not justify reopening it as part of this correction.

## Exact-index qualification and cost correction

Production `positive_visual_profile_fields` includes exact terms in the BM25F alias field, but `positive_visual_profile_text` deliberately excludes aliases from dense embedding text (`photo_visual_retrieval.py:30–62`). This review used the actual compiled merged profiles and production `reusable_vectors` function:

- Before and proposed `pf_portcullis` embedding text SHA-256 are identical: `ed4bcfda94a583de416c5ffdc953b724be2c51c1e7fd35ff473ffebb3e4a5181`
- All **1,622 / 1,622** existing visual-profile vectors are reusable under the current provider/model/dimensions and full-text checks
- Missing/new visual embeddings: **0**
- The old index correctly rejects the proposed registry hash

Thus the integration owner can rebuild the genuine sidecar using verified cached vectors only, including the changed exact lookup, BM25F documents/statistics and registry hash. No provider call is necessary for this frozen profile-only replacement at this pin. Do not hand-edit the sidecar or relabel old vectors against changed text. Recompute compatibility on the eventual runtime integration branch; if its recipe or other source state differs, the zero-call conclusion must be rechecked. Batch size 1 remains required for any actually changed semantic text.

BM25F alias changes can affect corpus statistics and optional visual rankings even when dense vectors are unchanged. Unchanged embeddings are not proof of unchanged candidate exposure.

## Required same-runtime before/after evidence

Publication remains held until the integration owner establishes the following on one pinned runtime implementation, holding unrelated DATA, seed, controls and inputs fixed. If a new runtime contract is required, derive any necessary adapter once before either arm, preserve the original artifacts, document every changed field, and bind both arms to the same new input hashes. Never change a state or add the new alias to an original request.

1. **Validate both data states.** Use compatible genuine indexes, source/index hashes, real exact lookup and BM25F checks. Rebuild the after sidecar; demonstrate stale-index rejection. For the profile-only patch, prove all non-target registry profiles, ordinary rows and bundles are identical
2. **Replay all six unchanged original inputs through normal public generation and composed audit in both states.** Do not substitute helper hits, patched public packs, fake vectors, opt-ins or historical-runtime-before/current-runtime-after comparisons
3. **Korean closed negative:** before imports the incompatible hard component and fails as recorded; after contains no automatic `pf_portcullis` hard obligation or required target clarification, preserves full closure/threshold contact/passage closure verbatim, and passes with zero optional adoption. If integrated runtime already prevents the before failure, record that and reassess the incremental DATA claim
4. **Original Korean half-lowered control:** record before hard hit → after no exact hard hit, including loss of all three automatic profile render gates. Require unchanged scene, state/contact anchors, generic assertion contract and successful composition. Add post-change negative mutations removing/replacing the half-lowered state, open passage and guide-contact evidence; assert their generic requester-preservation failures rather than relying on the removed target profile. An unchanged positive alone does not prove preservation enforcement
5. **Canonical Korean positive and its two frozen negatives:** expand the already frozen strings into valid independent envelope/core/control/embodiment artifacts before retrieval, retaining the appropriate source meaning. After: canonical partial gets the same three hard component duties and gates as English and passes; closed-state substitution and guide-contact omission do not hard-activate the target. Preserve those as source-alignment controls, not replacement evidence for the old Korean positive
6. **English and sibling collateral:** English partial retains its target duty and all three gates; English closed and broad-name closed stay non-hard and preserve closure; drawbridge retains exactly its original profile duties. All compatible compositions pass unchanged
7. **Full exposure/adoption accounting:** save ordinary IDs, bundle IDs, optional visual IDs, required clarifications, selections and every displacement/difference for each arm. Distinguish an exposed optional intermediate-state concept from a selected or hard duty. Require zero-adoption preservation first. Any optional-adoption claims need their own real compositions and effect evidence
8. **Regression checks:** add independently stated bilingual state-boundary expectations rather than only looping over current aliases; run the palace suite, current real-index/visual-obligation/clarification checks, and appropriate composed-evidence, selection-to-gate and render-review mutation tests. Broaden only for unresolved integration risk. Preserve existing holdouts. No provider image or pixel claim is necessary for this bounded contract repair

Do not claim general contradiction/quoted-mention/occurrence/owner-path handling. A request containing the new positive exact phrase plus a later contradictory endpoint is a different generic runtime problem, and should not trigger another fixture-specific DATA exception.

## Files

- `independent-checks.json`: pin, integrity results, exact-control replay, current real resolver hits, index compatibility and lineage hashes
- `independent-audit-replays.json`: commands, timings and full-result equality for six actual public audit replays
- `*.audit.stdout.json` / `*.audit.stderr.txt`: independent raw audit outputs
- `verify_review.py`: small reproducible read-only probe and replay script

**Final status:** narrow DATA direction supported; original partial Korean hard-recall tradeoff disclosed; historical lineage preserved; no mandatory ordinary behavior change established; same-runtime integration still required; repository unmodified.
