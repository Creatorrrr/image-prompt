# Final qualification review addendum

2026-10-03. Pinned source: `7e769e3e4a0da7068723830bb0c5c5c2dfd784c8`.

## Verdict

**APPROVE the narrow single-field DATA edit for installation, with explicit acceptance of the old Korean partial request's lost automatic profile gates.** The previously requested same-runtime causal and collateral evidence is now sufficient for this bounded correction. No additional prototype experiment, ordinary-label edit, fixture-specific alias, historical-source rewrite, provider call or runtime change is needed to justify this edit.

This is approval of the exact reviewed change, not a claim that the repository is already modified, an installed CLI artifact is validated, or publication/merge is complete. The integration owner should apply the same field, rebuild/check the real sidecar, run the applicable regression tests and replay against that installed state. If preceding integration changes the runtime, source contracts or index recipe, re-establish the matched before/after comparison there. The parent has separately released its DATA publication hold; this review does not authorize or incorporate PR5/runtime changes.

## Denominators and outcome

Independent recomputation from the raw case results and artifacts confirms:

| Cohort | Inputs | Before pass | After pass | Admitted builds |
| --- | ---: | ---: | ---: | ---: |
| Original source-guided six + four fresh controls | 10 | 9/10 | 10/10 | 20/20 |
| Fresh four alone, included above | 4 | 4/4 | 4/4 | 8/8 |
| Separately frozen canonical positive + two source-alignment negatives | 3 | 3/3 | 3/3 | 6/6 |
| All distinct inputs | 13 | 12/13 | 13/13 | 26/26 |

Do not add the fresh-four subset twice. The three counterfactual mutation audits are separate negative checks, not additional public generation inputs or pass-rate improvements. The sole repaired before failure is the original Korean fully lowered scene. The fresh controls demonstrate preservation on their small theme-targeted set, not a new improvement or population accuracy estimate.

The new qualification invokes the **unmodified public `generate_candidate_pack` and `audit_composed_prompt` functions** after normal input normalization, on the same pinned implementation. It supplies genuinely derived before/after data/index states in memory. It does not run 26 standalone generation CLI processes or install an after registry. Independently, all six regenerated original-before pack **files are byte-identical** to the earlier genuine CLI files, providing an actual consumer-equivalence check for that path.

## What I independently checked

`verify_final_qualification.py` completed successfully with the repository still clean and pinned:

- Checked all frozen input file hashes and all 26 pack/composition hashes against their records
- Compared every composition to both the frozen core baseline and pack baseline; all are exact, with zero ordinary/visual adoption
- Recomputed counts from individual records, and checked each recorded hard-ID/status/failure summary against its actual pack/audit artifact
- Checked all current source-manifest hashes and the previously reviewed historical draft/installer/maintenance-record hashes; none changed
- Verified the fresh author's raw requests and baselines remain exact through the source-aware schema adapter. Its recorded pre-retrieval camera-property refinement changes neither request nor baseline and is shared by both arms
- Independently reconstructed the complete after visual index using the real cache selector and builder. Every resulting registry/exact/BM25F/index digest matches the saved receipt
- Independently regenerated and audited four causal/source-boundary after packs: original Korean closed, original Korean partial, new canonical Korean partial, and new Korean guide-contact omission. Every full pack and full audit result equals its saved artifact
- Independently re-audited all three truthful after-arm mutations. Every complete audit result equals the saved result, including the expected actual-prompt-content anchor failures
- Independently compared actual before/after ordinary, bundle, optional visual and clarification inventories for all 13 inputs

These checks used no provider requests, fabricated vectors, source patches, audit patches or repository writes. The derived index existed only in memory; no large source/index copy was created.

## Meaning and lost-gate tradeoff

The closed Korean request now admits and composes faithfully with no automatic `pf_portcullis` obligation or required target clarification. Its full closure, sill contact and blocked passage remain unchanged. This directly resolves the source inconsistency identified by the first review.

The original Korean half-lowered request now exposes `visual-concept:pf_portcullis` as optional and leaves it unselected. Its original state/contact prose, semantic anchors and assertion contract remain, and composition passes. **All three automatic target render gates are nevertheless gone.** This is accepted narrowing of an overbroad exact alias, not recovered hard recall or equivalent pixel enforcement. The source-faithful new Korean exact phrase independently receives the original three profile gates and component duties, while the closed-state substitution and guide-contact-omission controls do not hard-activate it. The original request was not rewritten or supplemented with a fixture-specific alias.

The three mutations establish more than rejection of modified typed metadata:

1. Fully closing the gate and passage removes `gate_state` and `passage_result` evidence; both fail `intent_lock_prompt_evidence`
2. Blocking the passage beneath the still-hanging gate removes `passage_result`; it fails that same actual-content check
3. Moving grid edges clear of the guide grooves removes `guided_grid_contact`; it fails that same check, with no typed-assertion-equality rejection needed

Each mutant updates the submitted current evidence truthfully to text present in its changed prompt, keeps the original pack/core bindings valid, and has no hard target profile or selected candidate. The first two also receive typed-assertion-equality failures, which are disclosed and are not the basis of the preservation conclusion. These checks prove literal requester-bound enforcement of the tested substitutions. They do not recover profile pixel gates or solve arbitrary semantic contradiction/co-occurrence handling.

## Collateral and source/index consistency

All 13 actual ordinary candidate ID lists and bundle ID lists, including their order, are identical across arms. English partial and the unchanged drawbridge retain their original hard profiles/gates. English closed and broad-name closed remain non-hard. The four fresh scenes retain their pre-existing routing and pass both states.

Optional/clarification collateral is limited but not zero:

- Original Korean partial gains the optional target and loses an unrelated non-required `pfe_one_shoulder` clarification; the target clarification changes from required to optional
- Original Korean closed loses the conflicting target clarification
- The canonical new Korean partial promotes its target from optional to hard and exposes an optional `y2kr_checkerboard` concept/clarification in the freed optional inventory position
- Other reviewed optional/clarification inventories are unchanged

All these optional additions are declined, and no authored scene is displaced. This supports the bounded contract repair; it does not establish aesthetic benefit from the changed optional exposure.

The only merged registry mutation is `/profiles/498/activation/exact_terms/1`; all other 1,621 profiles and ordinary dictionary/bundle data are unchanged. The true after index reconstruction yields:

- Registry: `b242d5fec1cdf78e62103bd83e24fc71728457a8facc225426d860752581484f`
- Exact lookup: `0556b4023ff5254ececc10c418f66dfe9a34a143432c6cf3902da8446cd699cf`
- BM25F: `4ad652adee311dca155b277478585fa25d3c720619711cdee7e8c7b7efd8f87a`
- Canonical index: `deae58c1acdb5fc5639e90e4164e169a588009596eb794dd97e2c31b7fbaf0e1`

All 1,622 complete embedding texts and vector values are reused unchanged. The old index rejects the changed registry, and the genuinely regenerated metadata validates. Thus this exact proposal requires zero provider calls at this pin. The install must retain this source/index pairing; it must not merely change the registry while retaining stale sidecar metadata.

The ordinary-label and historical-source conclusions of `REVIEW.md` stand: keep the paired ordinary rows out of this edit, preserve historical receipts/scripts/drafts, and add dated correction lineage for the current single-field change. No active historical-installer dependency was found. An installed artifact needs normal final verification, not a rewrite of September evidence.

## Evidence files

- `final-independent-checks.json`: all input/artifact verification, independently computed denominators, index reconstruction, four full regenerated pack/audit comparisons, three full mutation-audit comparisons and final clean pin
- `final-exposure-checks.json`: actual inventory comparisons for all 13 input pairs
- `verify_final_qualification.py`: reproducible independent read-only checker
- Original review retained unchanged in `REVIEW.md`

**Bottom line:** the source-faithful, single-field trigger repair is ready to integrate with the lost automatic-gate coverage explicitly accepted and the actual installed artifact retested. No broader recall, rendered-quality or generic contradiction-safety claim is supported.
