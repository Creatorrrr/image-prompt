"""Independent read-only review probes; outputs only in this review directory.
No provider requests, generated indexes, fabricated vectors, or repo writes.
"""
import copy, hashlib, json, os, subprocess, sys, time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path('/workspace/scratch/ce8f20680f5a/image-prompt'); OUT=Path(__file__).resolve().parent; AUDIT=OUT.parent; SKILL=ROOT/'skills/photo-prompt-image-generator'
sys.path.insert(0,str(SKILL/'scripts'))
import prompt_generator as pg
from build_visual_profile_index import reusable_vectors
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(name,data): (OUT/name).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
def diffs(a,b,path=''):
 if type(a)!=type(b): return [path]
 if isinstance(a,dict):
  return [x for k in sorted(a.keys()|b.keys()) for x in ([path+'/'+k] if k not in a or k not in b else diffs(a[k],b[k],path+'/'+k))]
 if isinstance(a,list):
  if len(a)!=len(b): return [path]
  return [x for i,(u,v) in enumerate(zip(a,b)) for x in diffs(u,v,path+'/'+str(i))]
 return [] if a==b else [path]
source_manifest=json.loads((AUDIT/'source-manifest.json').read_text());artifact_manifest=json.loads((AUDIT/'artifact-manifest.json').read_text());frozen=json.loads((AUDIT/'frozen-input-manifest.json').read_text())
checks={'repository_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'git_status_before':subprocess.check_output(['git','status','--short'],cwd=ROOT,text=True),'source_files_checked':len(source_manifest['files']),'source_hash_mismatches':[name for name,h in source_manifest['files'].items() if sha(ROOT/name)!=h],'artifact_files_checked':len(artifact_manifest['files']),'artifact_hash_mismatches':[name for name,v in artifact_manifest['files'].items() if sha(AUDIT/name)!=v['sha256']],'frozen_input_mismatches':[(c['id'],name) for c in frozen['cases'] for name,h in c['files'].items() if sha(AUDIT/c['id']/name)!=h]}
raw=json.loads((SKILL/'assets/photo_prompt_visual_obligations_palace_fortification.json').read_text());old=next(p for p in raw['profiles'] if p['id']=='pf_portcullis');new=json.loads((AUDIT/'proposal/pf_portcullis.proposed.json').read_text())
checks['proposal_changed_paths']=diffs(old,new)
controls=json.loads((AUDIT/'proposal/frozen-controls.json').read_text())['controls'];lexical=[]
for control in controls:
 row={'id':control['id']}
 for key,profile in [('current',old),('proposed',new)]:
  actual=any(pg.intent_alias_matches(control['text'],a) and not pg.intent_term_is_negated(control['text'],a) for a in profile['activation']['exact_terms'])
  row[key+'_unnegated_exact_match']=actual
  assert actual==control[key+'_unnegated_exact_match']
 lexical.append(row)
checks['lexical_controls']=lexical
registry=pg.load_visual_obligation_registry(SKILL/'assets/photo_prompt_visual_obligations.json'); index=pg.load_visual_profile_index(SKILL/'assets/photo_prompt_visual_profile_index.json',registry)
proposed_registry=copy.deepcopy(registry)
current_profile=next(p for p in registry['profiles'] if p['id']=='pf_portcullis')
proposed_profile=next(p for p in proposed_registry['profiles'] if p['id']=='pf_portcullis');proposed_profile['activation']['exact_terms'][1]=new['activation']['exact_terms'][1]
checks['actual_merged_profile_count']=len(registry['profiles'])
checks['target_index_text_matches_current']=index['entries']['pf_portcullis']['text']==pg.visual_profile_semantic_text(current_profile)
checks['proposed_embedding_text_changed']=pg.visual_profile_semantic_text(current_profile)!=pg.visual_profile_semantic_text(proposed_profile)
checks['current_embedding_text_sha256']=hashlib.sha256(pg.visual_profile_semantic_text(current_profile).encode()).hexdigest(); checks['proposed_embedding_text_sha256']=hashlib.sha256(pg.visual_profile_semantic_text(proposed_profile).encode()).hexdigest()
try: pg.validate_visual_profile_index_metadata(index,proposed_registry)
except ValueError as e: checks['stale_index_rejection']=str(e)
else: raise AssertionError('stale index unexpectedly accepted')
reused=reusable_vectors([SKILL/'assets/photo_prompt_visual_profile_index.json'],proposed_registry,provider=index['provider'],model=index['embedding_model'],dimensions=index['embedding_dimensions'])
checks['cache_reuse_count']=len(reused);checks['profiles_requiring_new_embedding']=[p['id'] for p in proposed_registry['profiles'] if p['id'] not in reused]
checks['source_lineage_hashes']={str(p.relative_to(ROOT)):sha(p) for p in [ROOT/'docs/research-evidence/photo-prompt/palace-fortification-20260909/candidate-drafts.json',ROOT/'docs/research-evidence/photo-prompt/palace-fortification-20260909/install-runtime.py',ROOT/'docs/research-evidence/photo-prompt/extension-maintenance/photo_prompt_palace_fortification_extension.json']}
checks['current_resolver']=[]
for control in controls:
 res=pg.resolve_visual_profile_hits(registry,[{'source':'user_requirement','text':control['text'],'polarity':'required','priority':'critical','mandatory':True}],visual_profile_index=index,adult_context=False)
 checks['current_resolver'].append({'case':control['id'],'hard_ids':[h['profile_id'] for h in res['hits'] if h.get('hard_eligible')]})
save('independent-checks.json',checks)
env={k:v for k,v in os.environ.items() if not any(x in k.upper() for x in ['TOKEN','API_KEY','CREDENTIAL'])};env['PYTHONDONTWRITEBYTECODE']='1'
original=json.loads((AUDIT/'composed-audit-results.json').read_text())
def replay(row):
 start=time.time();r=subprocess.run(row['command'],cwd=ROOT,env=env,text=True,capture_output=True,timeout=180)
 (OUT/(row['case']+'.audit.stdout.json')).write_text(r.stdout);(OUT/(row['case']+'.audit.stderr.txt')).write_text(r.stderr)
 result=json.loads(r.stdout);return {'case':row['case'],'command':row['command'],'returncode':r.returncode,'seconds':round(time.time()-start,3),'same_result_as_frozen_audit':result==row['result'],'status':result['status'],'failures':result['failures']}
with ThreadPoolExecutor(max_workers=2) as pool: replays=list(pool.map(replay,original))
save('independent-audit-replays.json',replays)
checks['git_status_after']=subprocess.check_output(['git','status','--short'],cwd=ROOT,text=True);save('independent-checks.json',checks)
print(json.dumps({'hash_mismatches':{k:v for k,v in checks.items() if 'mismatch' in k},'proposed_changed_paths':checks['proposal_changed_paths'],'embedding_refresh':checks['profiles_requiring_new_embedding'],'replays':[{'case':r['case'],'status':r['status'],'same_result':r['same_result_as_frozen_audit']}for r in replays],'git_status':checks['git_status_after']},ensure_ascii=False,indent=2))
