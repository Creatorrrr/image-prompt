"""Independent final qualification checks. Read-only repository; scratch outputs only."""
import copy, hashlib, json, subprocess, sys, time
from pathlib import Path
sys.dont_write_bytecode=True
D=Path(__file__).resolve().parent.parent; O=D/'review'; R=Path('/workspace/scratch/ce8f20680f5a/image-prompt');S=R/'skills/photo-prompt-image-generator';sys.path.insert(0,str(S/'scripts'))
import prompt_generator as g, build_visual_profile_index as b, audit_composed_prompt as a
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
canon=lambda v:json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
cs=lambda v:hashlib.sha256(canon(v)).hexdigest()
def load(p):return json.loads(p.read_text())
def save(n,v):(O/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
checks={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'git_status_before':subprocess.check_output(['git','status','--short'],cwd=R,text=True)}
rows=[]; inputs={};artifact_checks=[]
for folder in ['qualification','qualification-extra']:
 manifest=load(D/folder/'frozen-input-manifest.json')
 for c in manifest['cases']:
  for name,h in c['files'].items():assert sha(Path(c['input_dir'])/name)==h,(c['id'],name)
  inputs[c['id']]=c
 for row in load(D/folder/'results.json'):
  dest=D/folder/row['arm']/row['case'];pack=load(dest/'candidate-pack.json')[0];comp=load(dest/'composed-baseline.json');au=load(dest/'composed-audit.json');core=load(Path(row['input_dir'])/'authorial-core.json')
  assert sha(dest/'candidate-pack.json')==row['pack_sha256']; assert sha(dest/'composed-baseline.json')==row['composed_sha256']; assert comp['prompt_en']==core['baseline_prompt_en']==pack['authorial_core']['baseline_prompt_en'];assert not comp['chosen_candidate_ids'] and not comp['chosen_visual_concept_ids']; assert au['status']==row['audit_status'] and au['failures']==row['failures']; assert [ob['id'] for ob in (pack.get('visual_obligations')or{}).get('obligations',[])]==row['hard_ids']
  artifact_checks.append({'case':row['case'],'arm':row['arm'],'folder':folder,'pack_sha256':row['pack_sha256'],'composed_sha256':row['composed_sha256'],'input_hashes_match':True,'raw_pack_audit_summary_agrees':True,'baseline_exact':True,'zero_adoption':True})
  rows.append(row)
assert len(inputs)==13 and len(rows)==26
counts={}
for label,cohorts in [('main10',{'original_source_guided_6','fresh_source_unexposed_4'}),('fresh4',{'fresh_source_unexposed_4'}),('supplemental3',{'additional_source_guided_positive_1','additional_source_alignment_negative_2'}),('all13',{r['cohort']for r in rows})]:
 selected=[r for r in rows if r['cohort']in cohorts];counts[label]={'unique_inputs':len({r['case']for r in selected}),'builds':len(selected),'admitted':sum(r['admission']=='pass'for r in selected),'before_passes':sum(r['arm']=='before'and r['audit_status']=='pass'for r in selected),'after_passes':sum(r['arm']=='after'and r['audit_status']=='pass'for r in selected)}
checks['counts']=counts; checks['all_26_artifact_checks']=artifact_checks
checks['original_cli_before_byte_identity']={c['id']:(D/c['id']/'candidate-pack.json').read_bytes()==(D/'qualification/before'/c['id']/'candidate-pack.json').read_bytes()for c in load(D/'frozen-input-manifest.json')['cases']}
checks['source_manifest_mismatches']=[name for name,h in load(D/'source-manifest.json')['files'].items()if sha(R/name)!=h]
checks['prior_lineage_hashes_still_equal']={name:sha(R/name)==h for name,h in load(O/'independent-checks.json')['source_lineage_hashes'].items()}
fresh=load(D/'fresh-controls/requests.json')['requests'];checks['fresh_original_request_baseline_exact']={r['request_id']:{'request':load(Path(inputs[r['request_id']]['input_dir'])/'authorial-core.json')['source_request']==r['request_text'],'baseline':load(Path(inputs[r['request_id']]['input_dir'])/'authorial-core.json')['baseline_prompt_en']==r['baseline_prompt_en']}for r in fresh}
before=g.load_runtime_data();reg=copy.deepcopy(before[g.VISUAL_OBLIGATIONS_DATA_KEY]);old_idx=before[g.VISUAL_PROFILE_INDEX_DATA_KEY];edit=load(D/'proposal/proposed-edit.json');p=next(p for p in reg['profiles']if p['id']=='pf_portcullis');assert p['activation']['exact_terms'][1]==edit['old_value'];p['activation']['exact_terms'][1]=edit['new_value']
v=b.reusable_vectors([S/'assets/photo_prompt_visual_profile_index.json'],reg,provider=g.SEMANTIC_PROVIDER,model=g.SEMANTIC_MODEL_ID,dimensions=g.DEFAULT_SEMANTIC_DIMENSIONS);assert len(v)==1622;assert all(old_idx['entries'][p['id']]['text']==g.visual_profile_semantic_text(p)for p in reg['profiles']);assert all(v[k]==old_idx['entries'][k]['vector']for k in v)
idx=b.build_visual_profile_index_payload(reg,vectors=v,provider=g.SEMANTIC_PROVIDER,model=g.SEMANTIC_MODEL_ID,dimensions=g.DEFAULT_SEMANTIC_DIMENSIONS);g.validate_visual_profile_index_metadata(idx,reg)
receipt=load(D/'qualification/derived-index-receipt.json'); checks['index_reconstruction']={'cache_vectors':len(v),'vector_texts_and_values_preserved':True,'registry_sha256':idx['registry_sha256'],'exact_lookup_sha256':cs(idx['exact_lookup']),'bm25f_sha256':cs(idx['bm25f']),'index_canonical_sha256':cs(idx),'receipt_agrees':idx['registry_sha256']==receipt['after_registry_sha256']and cs(idx)==receipt['after_index_canonical_sha256']and cs(idx['exact_lookup'])==receipt['after_exact_lookup_sha256']and cs(idx['bm25f'])==receipt['after_bm25f_sha256'],'provider_calls':0}
after={**before,g.VISUAL_OBLIGATIONS_DATA_KEY:reg,g.VISUAL_PROFILE_INDEX_DATA_KEY:idx};assert g.dictionary_hash(before)==g.dictionary_hash(after)
try:g.validate_visual_profile_index_metadata(old_idx,reg)
except ValueError as ex:checks['stale_index_rejected']=str(ex)
else:raise AssertionError('old index accepted')
save('final-independent-checks.json',checks)
# Regenerate four causal/source-boundary after packs using the real consumer and fresh derived index.
checks['independent_build_and_audit_replays']=[]
for case in ['ko_fully_lowered','ko_partly_lowered','source-guided-new-ko-partial','source-guided-new-ko-missing-guides']:
 c=inputs[case];ip=Path(c['input_dir']);folder='qualification-extra'if c['cohort']=='additional_source_alignment_negative_2'else'qualification';dest=D/folder/'after'/case
 envelope=g.load_request_envelope_arg(str(ip/'request-envelope.json'));controls=load(ip/'creative-controls.json');core=g.load_authorial_core_arg(str(ip/'authorial-core.json'),request_envelope=envelope,creative_control_snapshot=controls);review=load(ip/'embodiment-review.json');pack=g.generate_candidate_pack(after,core,controls,review,seed=1003);saved=load(dest/'candidate-pack.json')[0];assert pack==saved,(case,'pack differs'); comp=load(dest/'composed-baseline.json');audit=a.audit_composed_prompt(pack,comp);assert audit==load(dest/'composed-audit.json')
 checks['independent_build_and_audit_replays'].append({'case':case,'full_pack_equals_saved':True,'full_audit_equals_saved':True,'audit_status':audit['status'],'hard_ids':[x['id']for x in(pack.get('visual_obligations')or{}).get('obligations',[])]});print('Independent build/audit',case,audit['status'],flush=True)
 save('final-independent-checks.json',checks)
checks['counterfactual_replays']=[]
pack=load(D/'qualification/after/ko_partly_lowered/candidate-pack.json')[0];base=load(D/'qualification/after/ko_partly_lowered/composed-baseline.json')
for row in load(D/'qualification/counterfactuals/results.json')['cases']:
 comp=load(D/'qualification/counterfactuals'/(row['case']+'.composed.json'));expected=base['prompt_en']
 for old,new in row['replacements'].items():expected=expected.replace(old,new)
 assert comp['prompt_en']==expected;assert comp['authorial_core_binding']==base['authorial_core_binding'];assert not comp['chosen_candidate_ids']and not comp['chosen_visual_concept_ids'];assert not(pack.get('visual_obligations')or{}).get('obligations')
 for ev in comp.get('semantic_assertion_evidence',{}).get('evidence',{}).values():
  assert all(v in comp['prompt_en']for v in ev.values())
 audit=a.audit_composed_prompt(pack,comp);assert audit==load(D/'qualification/counterfactuals'/(row['case']+'.audit.stdout.json'))
 actual=[f['anchor_id']for f in audit['failures']if f['check']=='intent_lock_prompt_evidence'];assert set(row['expected_changed_anchor_ids'])<=set(actual)
 checks['counterfactual_replays'].append({'case':row['case'],'full_audit_equals_saved':True,'all_current_evidence_literal':True,'actual_content_anchor_failures':actual,'status':audit['status']});print('Counterfactual',row['case'],actual,flush=True)
 save('final-independent-checks.json',checks)
checks['git_status_after']=subprocess.check_output(['git','status','--short'],cwd=R,text=True);checks['final_head']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();save('final-independent-checks.json',checks)
print('FINAL independent verification passed',json.dumps(counts),flush=True)
