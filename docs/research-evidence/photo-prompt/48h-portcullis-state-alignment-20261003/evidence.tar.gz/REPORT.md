# Portcullis bilingual state-boundary audit

## Result

**A narrow DATA proposal is justified by a current public-consumer consequence. It is frozen outside the repository, not installed or accepted.** At pinned HEAD `7e769e3e4a0da7068723830bb0c5c5c2dfd784c8`, all six source-guided maintenance inputs passed prevalidation and the unmodified public generation CLI. Their unchanged, zero-adoption compositions passed **5/6** public composed audits. Only the **Korean fully lowered** request failed: the original Korean mechanism-only trigger imported the profile's **partly-lowered** hard duty into a fully closed scene. The equivalent English closed request passed.

This is not a malformed fixture, a missing guide-contact positive control, an opt-in failure, a stale index, a provider result, or an image-quality result. Public admission did not prevent the conflicting obligation. The composed audit blocked faithful completion because of it. This meets the audit plan's explicit consequence boundary; KEEP/no demonstrated consumer consequence does not describe the observed result.

## Frozen design and actual consumers

Six synthetic maintenance requests were authored from the named source inconsistency, then frozen together before retrieval. They are not naturally sampled requests or held-out accuracy evidence. Two state pairs use byte-identical English baselines and equivalent physical state: the grid inside the entrance, both edges seated in vertical guide grooves, and either an intermediate opening or full contact with the threshold. The Korean fully closed request retains the original three mechanism clauses and explicitly closes the gate. The drawbridge sibling uses its unchanged complete source relation. The broad-name closed control requests only a portcullis and closure, while its detailed realization is agent-authored.

Before execution, every summary was checked with the actual concrete-content-word counter: interpreted intent ≥4, subject ≥2, setting ≥3, event ≥3. Normal request-envelope, core, bound control, and embodiment normalization passed for all six. No fixture repair or state-changing adapter was needed. All closed baselines and composed prompts omit partly-lowered and halfway wording. The body-action review is properly not applicable to these architecture-only scenes.

Actual commands are preserved in `public-generation-results.json` and `composed-audit-results.json`:

- `scripts/generate_photo_prompt.py` with each frozen envelope/core/creative-controls/embodiment review, fixed seed **1003**, and the unchanged checked-in cached indexes
- `scripts/audit_composed_prompt.py` with each actual public pack and unchanged-baseline composed object
- Existing `tests.test_photo_palace_fortification_semantics`: **6 tests passed**

No visual-intent override, selected visual concept, fabricated query vector, fabricated hit, provider call, image, Git write, or production edit was used. Every complete pack, composition, stdout/stderr and input is retained. The repository remained clean. Frozen input file hashes still match, and paired baseline hashes match.

## Six-case result

| Frozen request | Admission | Hard profile | Third-component duty | Unchanged composed audit |
|---|---|---|---|---|
| Korean partly lowered | pass | `pf_portcullis` | partly lowered along upright grooves | pass |
| English partly lowered | pass | `pf_portcullis` | partly lowered along upright grooves | pass |
| Korean fully lowered onto threshold | pass | `pf_portcullis` | **partly lowered along upright grooves** | **fail** |
| English fully lowered onto threshold | pass | none | none | pass |
| Complete raised drawbridge sibling | pass | `pf_drawbridge` | gap separates deck end from outer approach | pass |
| Broad-name fully lowered portcullis | pass | none | none | pass |

The exact `pf_portcullis.component_3` evidence anchor is:

> the gate is partly lowered along those upright grooves

Its instruction is `Preserve this architectural relation: the gate is partly lowered along those upright grooves`. Gate `vo_pf_portcullis_3` requires that visible relation at both thumbnail and native review scales. Both other architectural components, including the **grid edges seated inside the grooves**, were preserved; their evidence passes in the half-lowered controls.

The Korean closed composition retains the real frozen phrase `the gate is fully lowered along those upright grooves onto the threshold` as its third-component evidence, and explicitly rejects the conflicting profile clarification. It does not pretend to apply that clarification. The public audit returns exactly two failures:

1. `visual_obligation_semantic_evidence`, `pf_portcullis`, `component_3_phrase`: the real closed-state phrase lacks the profile-declared partly-lowered anchor
2. `semantic_clarification_required`, `clarification:visual-profile:pf_portcullis`: the imported required clarification cannot be rejected

There are no core-binding, source-span, negative-intent, embodiment, runtime-label, guide-contact, minimum-word, or unrelated composition failures. The requester-owned closed state and passage closure remain preserved, rather than being changed to make the audit pass.

## Exposure, adoption and scene preservation

These dimensions are separate in `matrix-summary.json` and the raw packs:

- No ordinary, bundle, creative-augmentation, or optional visual candidate was selected in any case
- The ordinary `slot:location:pf_portcullis_location` was exposed in all five portcullis packs, including the valid English closed pack. This potentially unsuitable intermediate-state suggestion stays optional and is declined
- Only the broad-name closed control exposed `visual-concept:pf_portcullis` as an optional opt-in concept; leaving it unselected adds no gate and its composition passes
- The drawbridge pack exposed `slot:composition:pf_drawbridge_composition`, activated only `pf_drawbridge`, and passed without selecting that candidate
- Every final prompt is byte-identical to its frozen baseline. No optional choice displaced any authored scene clause
- `exposure-differences.json` records actual KO/EN ordinary and optional candidate set differences. Those are language-query exposure differences, not effects of the uninstalled proposal. No proposal after-pack or improved selection is claimed

## Source cause

`assets/photo_prompt_visual_obligations_palace_fortification.json:781–883` selects the intermediate variant in its English exact trigger, semantic definition, third component, evidence anchor, instruction, and render gate. Its Korean exact trigger instead says the vertical-motion mechanism is legible rather than swinging:

`격자가 출입 개구부 안에 있다; 격자 옆단이 수직 홈에 맞물린다; 문짝 회전이 아닌 상하 이동 구조가 읽힌다`

A fully closed gate can satisfy all three mechanism clauses. The mismatch is inherited authored source semantics, not a demonstrated transcription mistake: `profile-matrix.md:14` and `build-research-data.py:63` contain the broader Korean wording. The research report and English builder candidate describe the partly-lowered variant. The implementation report's rule is to activate only when the selected variant's three relations are specified. Its historical half-lowered arm does not cover this closed-state counterexample. The existing passing exact-term test checks that each authored alias activates; it does not independently compare bilingual state meaning.

The public builder projects that exact activation into both a hard profile obligation and a required clarification. The audited closed English peer and unchanged drawbridge control isolate this DATA mismatch from generic source coverage or architecture admission.

## Frozen proposal and remaining boundary

`proposal/proposed-edit.json` freezes one replacement in `pf_portcullis.activation.exact_terms[1]`:

`격자가 출입 개구부 안에 있다; 격자 옆단이 수직 홈에 맞물린다; 격자가 그 수직 홈을 따라 부분적으로 내려와 있다`

This makes the Korean trigger itself require the intermediate state already selected in English and component 3. The English exact trigger, definition, all component duties/evidence/gates, ordinary entries, bundles, and `pf_drawbridge` remain unchanged. There is no broadening to all portcullis states.

`proposal/pf_portcullis.proposed.json` is the complete proposed single profile. `proposal/frozen-controls.json` preserves the six original requests plus a new canonical Korean intermediate-state positive, its fully-closed state substitution negative, and a guide-contact omission negative. Their recorded checks use the production literal alias comparator only; they are not public candidate trials or image evidence.

Known recall change: the old mechanism-only exact phrase stops exact activation even when a later sentence separately specifies half-lowered state. The half-lowered meaning remains protected by the frozen core/assertion; the newly canonical Korean exact trigger is the narrow positive. This tradeoff is explicit, not concealed as a synonym-only change.

Before integration or acceptance, rebuild and validate the generated visual index using batch size 1, then replay the paired normal consumers on the integrated runtime branch. The actual builder cache-reuse function was checked against the in-memory alias-only proposal: all 1622 profile vectors are reusable, and the target vector text is unchanged because the current recipe excludes exact aliases. A provider call is therefore not needed for this isolated alias edit; the registry hash, exact lookup and BM25F projection still need regeneration. This audit does not generate or install a replacement index. See `proposal/cache-compatibility.json`. General contradictory mentions, occurrence/context routing, or owner/path semantics remain runtime work; no DATA exception is proposed for them. The bounded audit stops here.

## Evidence map

- `frozen-requests.json`, `frozen-input-manifest.json`, `pre-retrieval-input-validation.json`: pre-retrieval input and validity boundary
- Per-case directories: all four frozen inputs, public pack, unchanged composition, generation/audit stdout and stderr
- `matrix-summary.json`: compact admission/hard/optional/adoption/preservation/error matrix
- `public-generation-results.json`, `composed-audit-results.json`: actual commands and complete results
- `source-manifest.json`, `final-integrity.json`, `artifact-manifest.json`: pin, source hashes, preserved inputs, clean worktree and deliverable hashes
- `adapter-notes.json`: one console-only field-name correction (`profile_id` → public obligation `id`); no source, input, pack, or execution correction
- `existing-palace-tests.log`: six current tests pass, with their limited interpretation
- `proposal/`: uninstalled narrow proposal and frozen lexical controls
