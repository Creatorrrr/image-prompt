from pathlib import Path
import ast,copy,json,hashlib,sys,subprocess,time
D=Path(__file__).resolve().parent;P=D.parent;R=P.parent/'image-prompt';O=D/'production-integration';ARM=sys.argv[1];assert ARM in ('before','after');DEST=O/ARM;DEST.mkdir(parents=True,exist_ok=True);sys.dont_write_bytecode=True;sys.path.insert(0,str(R/'skills/photo-prompt-image-generator/scripts'));import prompt_generator as g;import audit_composed_prompt as audit
# Reuse the frozen, reviewed composition factory, without executing its trial setup.
tree=ast.parse((D/'run_qualification.py').read_text());node=next(n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name=='compose');ns={'copy':copy};exec(compile(ast.Module(body=[node],type_ignores=[]),str(D/'run_qualification.py'),'exec'),ns);compose=ns['compose']
def forbidden(*a,**k):raise AssertionError('No provider calls allowed')
g.embed_texts_with_gemini=forbidden
def write(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
sha=lambda b:hashlib.sha256(b).hexdigest();data=g.load_runtime_data();m=json.loads((D/'qualification/frozen-input-manifest.json').read_text());rows=[];pin=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
for case in m['cases']:
 idir=Path(case['input_dir']);t=time.monotonic()
 for name,h in case['files'].items():assert sha((idir/name).read_bytes())==h
 envelope=g.load_request_envelope_arg(str(idir/'request-envelope.json'));controls=json.loads((idir/'creative-controls.json').read_text());core=g.load_authorial_core_arg(str(idir/'authorial-core.json'),request_envelope=envelope,creative_control_snapshot=controls);review=json.loads((idir/'embodiment-review.json').read_text());g.photo_embodiment.build_policy(core,review)
 pack=g.generate_candidate_pack(data,core,controls,review,seed=m['seed']);dest=DEST/case['id'];dest.mkdir(exist_ok=True);write(dest/'candidate-pack.json',[pack]);c=compose(pack,case['state']);write(dest/'composed-baseline.json',c);a=audit.audit_composed_prompt(pack,c);write(dest/'composed-audit.json',a)
 assert c['prompt_en']==core['baseline_prompt_en'];row={'case':case['id'],'cohort':case['cohort'],'arm':ARM,'baseline_commit':pin,'pack_sha256':sha((dest/'candidate-pack.json').read_bytes()),'pack_id':pack['pack_id'],'baseline_unchanged':True,'hard_ids':[x['id']for x in(pack.get('visual_obligations')or{}).get('obligations',[])],'hard_gates':(pack.get('visual_obligations')or{}).get('required_hard_gates',[]),'optional_ids':[x['id']for x in(pack.get('visual_concept_candidates')or{}).get('candidates',[])],'audit_passed':not a['failures'],'failures':a['failures'],'seconds':round(time.monotonic()-t,3)};rows.append(row);write(DEST/'results.json',rows);print(case['id'],ARM,row['audit_passed'],row['hard_ids'],flush=True)
assert len(rows)==13;bad=[x['case']for x in rows if not x['audit_passed']];assert bad==(['ko_fully_lowered']if ARM=='before'else[]),bad
write(DEST/'source-receipt.json',{'head':pin,'provider_calls':0,'consumer':'actual installed public builder/auditor, no mocked source or derived in-memory registry','seed':m['seed'],'source_asset_sha256':{n:sha((R/'skills/photo-prompt-image-generator/assets'/n).read_bytes())for n in ('photo_prompt_visual_obligations_palace_fortification.json','photo_prompt_visual_profile_index.json','photo_prompt_semantic_index.json')},'dictionary_hash':g.dictionary_hash(data),'registry_hash':g.visual_profile_registry_sha256(data[g.VISUAL_OBLIGATIONS_DATA_KEY])})
print('Installed',ARM,'complete',len(rows)-len(bad),'/',len(rows),flush=True)
