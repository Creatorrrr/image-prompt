"""Independent read-only review of the installed patch; writes review receipts only."""
import ast, copy, datetime, hashlib, json, os, re, subprocess, sys
from pathlib import Path
sys.dont_write_bytecode=True
O=Path(__file__).resolve().parent;D=O.parent;R=D.parent.parent/'image-prompt';S=R/'skills/photo-prompt-image-generator';A=S/'assets';BASE='112c5a458e482f36ab9229b9d1db67461f8c12d4'
sys.path.insert(0,str(S/'scripts'))
import prompt_generator as g, build_visual_profile_index as builder, audit_composed_prompt as audit
load=lambda p:json.loads(p.read_text())
sha=lambda b:hashlib.sha256(b).hexdigest()
cs=lambda v:sha(json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())
def git(*args):return subprocess.check_output(['git',*args],cwd=R)
def forbidden(*args,**kwargs):raise AssertionError('Independent review forbids provider calls')
g.embed_texts_with_gemini=builder.embed_texts_with_gemini=forbidden
receipt={'review_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'baseline_commit':BASE,'head':git('rev-parse','HEAD').decode().strip(),'status_before':git('status','--short').decode(),'provider_calls':0}
assert receipt['head']==BASE
source_rel='skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations_palace_fortification.json';index_rel='skills/photo-prompt-image-generator/assets/photo_prompt_visual_profile_index.json';test_rel='tests/test_photo_portcullis_korean_state.py'
assert set(git('diff','--name-only').decode().splitlines())=={source_rel,index_rel}
assert git('ls-files','--others','--exclude-standard').decode().splitlines()==[test_rel]
old= json.loads(git('show',BASE+':'+source_rel));new=load(R/source_rel);edit=load(D/'proposal/proposed-edit.json')
newrow=next(x for x in new['profiles']if x['id']=='pf_portcullis');oldrow=next(x for x in old['profiles']if x['id']=='pf_portcullis');assert oldrow['activation']['exact_terms'][1]==edit['old_value'];assert newrow['activation']['exact_terms'][1]==edit['new_value'];reverted=copy.deepcopy(new);next(x for x in reverted['profiles']if x['id']=='pf_portcullis')['activation']['exact_terms'][1]=edit['old_value'];assert reverted==old
receipt['source_scope']={'changed_profile':'pf_portcullis','sole_changed_field':'activation.exact_terms[1]','all_other_profile_fields_unchanged':True,'ordinary_runtime_history_unchanged':True,'source_sha256':sha((R/source_rel).read_bytes()),'six_method_test_sha256':sha((R/test_rel).read_bytes())}
data=g.load_runtime_data();registry=data[g.VISUAL_OBLIGATIONS_DATA_KEY];index=data[g.VISUAL_PROFILE_INDEX_DATA_KEY];oldindex=json.loads(git('show',BASE+':'+index_rel));oldregistry=copy.deepcopy(registry);next(x for x in oldregistry['profiles']if x['id']=='pf_portcullis')['activation']['exact_terms'][1]=edit['old_value']
g.validate_visual_profile_index_metadata(oldindex,oldregistry)
try:g.validate_visual_profile_index_metadata(oldindex,registry)
except ValueError as ex:stale=str(ex)
else:raise AssertionError('Stale index accepted')
vectors=builder.reusable_vectors([A/'photo_prompt_visual_profile_index.json'],registry,provider=g.SEMANTIC_PROVIDER,model=g.SEMANTIC_MODEL_ID,dimensions=g.DEFAULT_SEMANTIC_DIMENSIONS)
assert len(vectors)==len(registry['profiles'])==1622
assert index['entries']==oldindex['entries']
assert all(index['entries'][p['id']]['text']==g.visual_profile_semantic_text(p)for p in registry['profiles'])
rebuilt=builder.build_visual_profile_index_payload(registry,vectors=vectors,provider=g.SEMANTIC_PROVIDER,model=g.SEMANTIC_MODEL_ID,dimensions=g.DEFAULT_SEMANTIC_DIMENSIONS)
assert rebuilt==index
assert index['exact_lookup']!=oldindex['exact_lookup']and index['bm25f']!=oldindex['bm25f']
receipt['index']={'entries_text_vectors_identical':1622,'full_rebuild_equals_installed':True,'registry_sha256':index['registry_sha256'],'index_file_sha256':sha((A/'photo_prompt_visual_profile_index.json').read_bytes()),'index_canonical_sha256':cs(index),'exact_lookup_sha256':cs(index['exact_lookup']),'bm25f_sha256':cs(index['bm25f']),'old_index_rejection':stale}
receipt['historical_source_hashes_unchanged']={name:sha((R/name).read_bytes())==h for name,h in load(D/'review/independent-checks.json')['source_lineage_hashes'].items()};assert all(receipt['historical_source_hashes_unchanged'].values())
inputs={};seed=None
for folder in ('qualification','qualification-extra'):
 manifest=load(D/folder/'frozen-input-manifest.json');assert seed in (None,manifest['seed']);seed=manifest['seed']
 for c in manifest['cases']:
  assert c['id']not in inputs;inputs[c['id']]=c
  for name,h in c['files'].items():assert sha((Path(c['input_dir'])/name).read_bytes())==h,(c['id'],name)
assert len(inputs)==13
receipt['public_replays']={};packs={};comparisons=[]
for arm in ('before','after'):
 rows=load(O/arm/'results.json');assert len(rows)==13 and {r['case']for r in rows}==set(inputs);sr=load(O/arm/'source-receipt.json');assert sr['head']==BASE and sr['provider_calls']==0 and sr['seed']==seed
 for name,h in sr['source_asset_sha256'].items():assert h==sha(git('show',BASE+':skills/photo-prompt-image-generator/assets/'+name)if arm=='before'else(A/name).read_bytes())
 assert sr['dictionary_hash']==g.dictionary_hash(data)
 arm_receipt=[]
 for row in rows:
  case=row['case'];p=O/arm/case;pack=load(p/'candidate-pack.json')[0];comp=load(p/'composed-baseline.json');saved=load(p/'composed-audit.json');core=load(Path(inputs[case]['input_dir'])/'authorial-core.json');packs[arm,case]=pack
  assert sha((p/'candidate-pack.json').read_bytes())==row['pack_sha256'];assert comp['prompt_en']==core['baseline_prompt_en']==pack['authorial_core']['baseline_prompt_en'];assert not comp['chosen_candidate_ids']and not comp['chosen_visual_concept_ids'];actual=audit.audit_composed_prompt(pack,comp);assert actual==saved,(arm,case,'audit');assert row['audit_passed']==(not actual['failures'])and row['failures']==actual['failures'];hard=[x['id']for x in(pack.get('visual_obligations')or{}).get('obligations',[])];gates=(pack.get('visual_obligations')or{}).get('required_hard_gates',[]);assert hard==row['hard_ids']and gates==row['hard_gates'];assert row['optional_ids']==[x['id']for x in(pack.get('visual_concept_candidates')or{}).get('candidates',[])]
  arm_receipt.append({'case':case,'status':actual['status'],'hard_ids':hard,'hard_gates':gates,'full_audit_independently_equal':True})
 expected=['ko_fully_lowered']if arm=='before'else[];assert [r['case']for r in rows if not r['audit_passed']]==expected
 receipt['public_replays'][arm]={'inputs':13,'passed':sum(r['audit_passed']for r in rows),'failed':expected,'all_frozen_inputs_exact':True,'all_baselines_exact_zero_adoption':True,'source_receipt_verified':True,'cases':arm_receipt}
print('All 26 audits and frozen input/source bindings verified',flush=True)
for case in inputs:
 b=packs['before',case];a=packs['after',case]
 def ids(p,k):return [x['id']for x in(p.get(k)or{}).get('candidates',[])]
 ordinary=lambda p:{k:[x['id']for x in v['candidates']]for k,v in p['slots'].items()}
 assert ordinary(b)==ordinary(a);assert ids(b,'candidate_bundles')==ids(a,'candidate_bundles')
 bclar={x['id']:x for x in(b.get('semantic_clarification')or{}).get('candidates',[])};aclar={x['id']:x for x in(a.get('semantic_clarification')or{}).get('candidates',[])}
 comparisons.append({'case':case,'ordinary_ids_order_exact':True,'bundle_ids_order_exact':True,'optional_added':sorted(set(ids(a,'visual_concept_candidates'))-set(ids(b,'visual_concept_candidates'))),'optional_removed':sorted(set(ids(b,'visual_concept_candidates'))-set(ids(a,'visual_concept_candidates'))),'clarifications_added':sorted(aclar.keys()-bclar.keys()),'clarifications_removed':sorted(bclar.keys()-aclar.keys()),'clarifications_changed':sorted(k for k in aclar.keys()&bclar.keys()if aclar[k]!=bclar[k])})
receipt['collateral']=comparisons
receipt['independent_installed_regeneration']=[]
for case in ['ko_fully_lowered','ko_partly_lowered','source-guided-new-ko-partial','source-guided-new-ko-missing-guides']:
 p=Path(inputs[case]['input_dir']);envelope=g.load_request_envelope_arg(str(p/'request-envelope.json'));controls=load(p/'creative-controls.json');core=g.load_authorial_core_arg(str(p/'authorial-core.json'),request_envelope=envelope,creative_control_snapshot=controls);review=load(p/'embodiment-review.json');rebuilt_pack=g.generate_candidate_pack(data,core,controls,review,seed=seed);assert rebuilt_pack==packs['after',case]
 receipt['independent_installed_regeneration'].append({'case':case,'full_pack_equals_installed_saved_artifact':True});print('Independent full pack equal:',case,flush=True)
receipt['counterfactuals']=[];base=load(O/'after/ko_partly_lowered/composed-baseline.json');pack=packs['after','ko_partly_lowered'];assert not(pack.get('visual_obligations')or{}).get('obligations')
for row in load(O/'counterfactuals/results.json')['cases']:
 comp=load(O/'counterfactuals'/(row['case']+'.composed.json'));expected=base['prompt_en']
 for oldtext,newtext in row['replacements'].items():assert oldtext in expected;expected=expected.replace(oldtext,newtext)
 assert comp['prompt_en']==expected;assert comp['core_retrieval_sha256']==base['core_retrieval_sha256'];assert comp['authorial_core_binding']==base['authorial_core_binding'];assert not comp['chosen_candidate_ids']and not comp['chosen_visual_concept_ids'];assert comp['negative_en']==base['negative_en']
 for ev in comp.get('semantic_assertion_evidence',{}).get('evidence',{}).values():assert all(v in comp['prompt_en']for v in ev.values())
 for dec in comp['semantic_clarification_decisions']:
  if dec['decision']=='applied':assert dec['prompt_evidence']in comp['prompt_en']
 actual=audit.audit_composed_prompt(pack,comp);assert actual==load(O/'counterfactuals'/(row['case']+'.audit.stdout.json'));anchors=[f['anchor_id']for f in actual['failures']if f['check']=='intent_lock_prompt_evidence'];assert set(row['expected_changed_anchor_ids'])<=set(anchors);assert actual['status']=='fail'
 receipt['counterfactuals'].append({'case':row['case'],'status':'fail','actual_content_anchor_failures':anchors,'all_failures':actual['failures'],'full_audit_independently_equal':True,'all_current_evidence_literal_in_modified_prompt':True,'core_bindings_unchanged_and_valid':True})
prev=D.parent/'material-effect-audit/production-integration/current-boundary.pack.json';current=O/'current-boundary.pack.json';assert prev.read_bytes()==current.read_bytes();bd=load(O/'current-boundary-delta.json');assert bd['leaf_diffs']==[] and bd['previous_opacity_pack_sha256']==bd['after_gate_pack_sha256']==sha(current.read_bytes());baseline_rel='skills/subculture-illustration-image-generator/assets/photo_regression_baseline_v9.json';assert(R/baseline_rel).read_bytes()==git('show',BASE+':'+baseline_rel)
receipt['frozen_boundary']={'prior_CT091_and_current_pack_byte_identical':True,'pack_sha256':sha(current.read_bytes()),'leaf_diffs':0,'historical_v9_baseline_unchanged':True,'historical_baseline_still_non_green':True}
testnodes=ast.parse((R/test_rel).read_text());methods=[n.name for n in ast.walk(testnodes)if isinstance(n,ast.FunctionDef)and n.name.startswith('test_')];assert len(methods)==6
results=load(O/'tests/results.json');unit_counts={}
for r in results:
 assert r['returncode']==0
 if r['file'].startswith('test_'):
  txt=(O/'tests'/(r['file']+'.log')).read_text();m=re.search(r'Ran (\d+) tests? in ',txt);assert m and txt.rstrip().endswith('OK');unit_counts[r['file']]=int(m[1])
assert sum(unit_counts.values())==65
receipt['tests']={'six_new_test_methods':methods,'focused_test_counts':unit_counts,'total_focused_tests':65,'dictionary_validation_passed':True,'full_suite_not_claimed':True}
receipt['initial_manifest_failure_preserved']={'initial_case_count':len(load(O/'before-incomplete-manifest-assembly/results.json')),'failure_log_exists':(O/'before.log').exists(),'harness_correction':load(O/'harness-assembly-correction.json')};assert receipt['initial_manifest_failure_preserved']['initial_case_count']==11
receipt['head_after']=git('rev-parse','HEAD').decode().strip();assert receipt['head_after']==BASE;receipt['status_after']=git('status','--short').decode();assert receipt['status_before']==receipt['status_after'];receipt['result']='PASS bounded installed single-field repair; old Korean partial loses all three automatic target render gates'
(O/'independent-installed-verification.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n');print('Independent installed review: PASS',flush=True)
