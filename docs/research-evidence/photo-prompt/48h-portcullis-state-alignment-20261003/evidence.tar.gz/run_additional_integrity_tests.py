from pathlib import Path
import subprocess,json,os,time
D=Path(__file__).resolve().parent;R=D.parent.parent/'image-prompt';O=D/'production-integration/additional-tests';O.mkdir(exist_ok=True);env={k:v for k,v in os.environ.items()if not any(s in k.upper()for s in ['TOKEN','API_KEY','CREDENTIAL'])};env['PYTHONDONTWRITEBYTECODE']='1';rows=[]
for name in ['test_photo_research_integration.py','test_photo_data_semantic_corrections.py','test_photo_semantic_guidance_data.py','test_photo_visual_obligations.py']:
 t=time.monotonic();r=subprocess.run([str(R/'.venv/bin/python'),'-m','unittest','discover','-s','tests','-p',name],cwd=R,env=env,capture_output=True,text=True,timeout=600);(O/(name+'.log')).write_text(r.stdout+r.stderr);rows.append({'file':name,'returncode':r.returncode,'seconds':round(time.monotonic()-t,3)});(O/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,r.returncode,flush=True)
