"""After-arm state/contact replacements in real prose with truthful new evidence.
Frozen core/pack remain unchanged; no metadata field is removed or hash forged.
"""
import copy,hashlib,json,os,subprocess,sys
from pathlib import Path
R=Path('/workspace/scratch/ce8f20680f5a/image-prompt');D=Path(__file__).parent;P=D/'production-integration/after/ko_partly_lowered';O=D/'production-integration/counterfactuals';O.mkdir(exist_ok=True);S=R/'skills/photo-prompt-image-generator'
sha=lambda x:hashlib.sha256(x).hexdigest()
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
pack=json.loads((P/'candidate-pack.json').read_text())[0];base=json.loads((P/'composed-baseline.json').read_text());assert not(pack.get('visual_obligations')or{}).get('obligations')
state='the gate is partly lowered along those upright grooves';passage='Its bottom edge hangs halfway down the entrance, leaving a clear open passage below';guides='the grid edges sit inside vertical guide grooves'
mutants=[('state_and_passage_fully_closed',{state:'the gate is fully lowered along those upright grooves onto the threshold',passage:'Its bottom edge rests on the stone sill, closing the passage completely'},['gate_state','passage_result']),('open_passage_blocked',{passage:'A solid stone blocking wall fills the passage beneath the hanging bottom edge'},['passage_result']),('grid_edges_detached_from_guides',{guides:'the grid edges stand clear of the vertical guide grooves'},['guided_grid_contact'])]
rows=[];env={k:v for k,v in os.environ.items()if not any(t in k.upper()for t in ['TOKEN','API_KEY','CREDENTIAL'])};env['PYTHONDONTWRITEBYTECODE']='1'
for name,replacements,expected in mutants:
 c=copy.deepcopy(base);prompt=c['prompt_en']
 for old,new in replacements.items():assert old in prompt;prompt=prompt.replace(old,new)
 c['prompt_en']=prompt
 # Review follows the actual new prose and remains not applicable to living bodies.
 c['embodiment_review']['review']['prompt_sha256']=sha(prompt.encode())
 c['embodiment_review']['review']['summary']='The changed diagnostic prose still depicts an architectural gate and masonry without a living-body mechanism. The altered gate state, passage or track contact is intentionally evaluated against the original immutable requester contract.'
 # Every supplied current evidence string is literal and truthful about the changed prose.
 for e in c.get('semantic_assertion_evidence',{}).get('evidence',{}).values():
  for k,v in list(e.items()):
   for old,new in replacements.items():v=v.replace(old,new)
   e[k]=v;assert v in prompt
 for dec in c['semantic_clarification_decisions']:
  v=dec.get('prompt_evidence','')
  for old,new in replacements.items():v=v.replace(old,new)
  dec['prompt_evidence']=v
  if dec['decision']=='applied':assert v in prompt
 assert c['authorial_core_binding']==base['authorial_core_binding']
 assert c['core_retrieval_sha256']==base['core_retrieval_sha256']
 assert c['negative_en']==base['negative_en']
 write(O/(name+'.composed.json'),c)
 cmd=[sys.executable,str(S/'scripts/audit_composed_prompt.py'),'--pack',str(P/'candidate-pack.json'),'--composed',str(O/(name+'.composed.json'))]
 r=subprocess.run(cmd,cwd=R,env=env,capture_output=True,text=True,timeout=120);(O/(name+'.audit.stdout.json')).write_text(r.stdout);(O/(name+'.audit.stderr.txt')).write_text(r.stderr);a=json.loads(r.stdout)
 actual=[f for f in a['failures']if f['check']=='intent_lock_prompt_evidence'];missing={x['anchor_id']for x in actual}
 rows.append({'case':name,'replacements':replacements,'command':cmd,'returncode':r.returncode,'status':a['status'],'all_failures':a['failures'],'actual_prompt_content_failures':actual,'expected_changed_anchor_ids':expected,'expected_actual_prompt_failures_observed':set(expected)<=missing,'all_evidence_strings_literal_in_changed_prompt':True,'original_core_and_pack_unchanged':True,'binding_hashes_valid_and_unchanged':True,'metadata_only_rejections_not_counted':True,'automatic_target_profile_absent':True,'newly_adopted_candidates':[]})
 assert a['status']=='fail'and set(expected)<=missing,(name,a)
write(O/'results.json',{'scope':'Three source-guided after-arm counterfactual substitutions. Replacing meaningful state, passage or grid/guide contact is detected from actual prompt content by the generic frozen requester anchors. Any additional typed-evidence equality rejection is reported separately and is not counted as semantic protection.','limitation':'This establishes literal source-bound preservation for the tested substitutions; it is not general semantic contradiction detection or preservation of the removed profile render gates.','cases':rows})
print(json.dumps([{'case':r['case'],'status':r['status'],'actual_content_anchor_failures':[x['anchor_id']for x in r['actual_prompt_content_failures']]}for r in rows],indent=2))
