"""Isolated same-runtime public-build qualification; no production patch or mock.
Normal public generate_candidate_pack and audit_composed_prompt consumers are called
with normal normalized inputs. Only the in-memory registry alias is replaced; its
index is derived by the real builder using fully verified checked-in cached vectors.
"""
import copy,hashlib,json,os,subprocess,sys,time,traceback
from pathlib import Path
R=Path('/workspace/scratch/ce8f20680f5a/image-prompt');D=Path(__file__).parent;Q=D/'qualification';S=R/'skills/photo-prompt-image-generator';sys.dont_write_bytecode=True;sys.path.insert(0,str(S/'scripts'))
import prompt_generator as g,build_visual_profile_index as builder,audit_composed_prompt as audit
PIN='7e769e3e4a0da7068723830bb0c5c5c2dfd784c8'
def head():return subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
def sha(b):return hashlib.sha256(b).hexdigest()
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def canonical(x):return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
assert head()==PIN
# Public offline source loader verifies the existing cached metadata.
t=time.time();before=g.load_runtime_data();registry=copy.deepcopy(before[g.VISUAL_OBLIGATIONS_DATA_KEY]);edit=json.loads((D/'proposal/proposed-edit.json').read_text());p=next(p for p in registry['profiles']if p['id']=='pf_portcullis');assert p['activation']['exact_terms'][1]==edit['old_value'];p['activation']['exact_terms'][1]=edit['new_value']
old_index=before[g.VISUAL_PROFILE_INDEX_DATA_KEY]
try:g.validate_visual_profile_index_metadata(old_index,registry);raise AssertionError('Stale index unexpectedly accepted')
except ValueError as ex:stale_error=str(ex)
vectors=builder.reusable_vectors([S/'assets/photo_prompt_visual_profile_index.json'],registry,provider=g.SEMANTIC_PROVIDER,model=g.SEMANTIC_MODEL_ID,dimensions=g.DEFAULT_SEMANTIC_DIMENSIONS)
assert len(vectors)==len(registry['profiles'])==1622
assert all(old_index['entries'][p['id']]['text']==g.visual_profile_semantic_text(p)for p in registry['profiles'])
assert all(vectors[k]==old_index['entries'][k]['vector']for k in vectors)
index=builder.build_visual_profile_index_payload(registry,vectors=vectors,provider=g.SEMANTIC_PROVIDER,model=g.SEMANTIC_MODEL_ID,dimensions=g.DEFAULT_SEMANTIC_DIMENSIONS)
g.validate_visual_profile_index_metadata(index,registry)
after={**before,g.VISUAL_OBLIGATIONS_DATA_KEY:registry,g.VISUAL_PROFILE_INDEX_DATA_KEY:index}
assert g.dictionary_hash(before)==g.dictionary_hash(after)
write(Q/'derived-index-receipt.json',{'endpoint':'build_visual_profile_index.reusable_vectors + build_visual_profile_index_payload + validate_visual_profile_index_metadata','registry_mutation':'Only pf_portcullis activation.exact_terms[1] replaced by frozen proposal in memory','profile_count':len(registry['profiles']),'cached_vectors_reused':len(vectors),'embedding_texts_unchanged':True,'vectors_byte_values_unchanged':True,'new_vector_count':0,'provider_calls':0,'batch_size':1,'batch_size_note':'No pending text to embed; no batches dispatched. The normal builder defaults to batch size 1.','before_registry_sha256':old_index['registry_sha256'],'after_registry_sha256':index['registry_sha256'],'before_exact_lookup_sha256':sha(canonical(old_index['exact_lookup'])),'after_exact_lookup_sha256':sha(canonical(index['exact_lookup'])),'before_bm25f_sha256':sha(canonical(old_index['bm25f'])),'after_bm25f_sha256':sha(canonical(index['bm25f'])),'before_index_canonical_sha256':sha(canonical(old_index)),'after_index_canonical_sha256':sha(canonical(index)),'stale_metadata_rejected':stale_error,'fresh_metadata_validation':'pass','ordinary_dictionary_hash_unchanged':True,'source_pin':head(),'seconds':round(time.time()-t,3)})
print('Derived index validated; all 1622 original vectors reused; source pin unchanged',flush=True)

def compose(p,state):
 core=p['authorial_core'];lock=core['intent_lock'];b=core['baseline_prompt_en'];review=copy.deepcopy(p['embodiment_preflight']['baseline_review']);review['provenance']='agent_postcomposition';hard=(p.get('visual_obligations')or{}).get('obligations',[])
 conflict=state=='fully_lowered'and any(o['id']=='pf_portcullis'for o in hard)
 c={'core_retrieval_sha256':p['core_retrieval']['canonical_sha256'],'pack_id':p['pack_id'],'prompt_en':b,'negative_en':p['negative_en'],'chosen_candidate_ids':[],'chosen_visual_concept_ids':[],'composer':'agent','embodiment_review':{'source_contract_sha256':p['embodiment_preflight']['canonical_sha256'],'review':review},'candidate_interpretations':[],'authorial_core_binding':{'source_authorial_core_sha256':core['canonical_sha256'],'source_intent_lock_sha256':lock['canonical_sha256'],'preserved_anchor_ids':[a['anchor_id']for a in lock['semantic_anchors']],'preserved_evidence':[],'authorial_decisions':[]},'semantic_clarification_decisions':[],'creative_augmentation_brief':{'decisions':[{'candidate_id':x['id'],'decision':'rejected','rationale':'Preserve the complete frozen architecture and state; decline optional alternatives'}for x in p['creative_augmentation']['candidates']]}}
 for x in p['semantic_clarification']['candidates']:
  bad=conflict and x.get('profile_id')=='pf_portcullis';state_decision='applied'if x.get('required_in_final_prompt')and not bad else'rejected'
  c['semantic_clarification_decisions'].append({'clarification_id':x['id'],'decision':state_decision,'rationale':'The partly lowered profile conflicts with the frozen fully closed gate; retain the closed state and reject the mismatch'if bad else'Preserve all frozen requester meaning and decline optional reinterpretations','prompt_evidence':next(a['prompt_evidence']for a in lock['semantic_anchors']if a['anchor_id']=='gate_state')if x.get('source')=='visual_meaning_registry'else lock['semantic_anchors'][0]['prompt_evidence']})
 a=p.get('semantic_assertion_obligations')
 if a:c['semantic_assertion_evidence']={'source_contract_sha256':a['canonical_sha256'],'evidence':{x['assertion_id']:x['frozen_evidence']for x in a['obligations']}}
 if hard:
  c['visual_obligation_evidence']={}
  for ob in hard:
   ev={}
   for field,req in ob['evidence_requirements'].items():
    found=[s for s in req.get('must_mention_any',[])if s in b]
    if found:ev[field]=found[0]
    elif conflict and ob['id']=='pf_portcullis'and field=='component_3_phrase':ev[field]=next(a['prompt_evidence']for a in lock['semantic_anchors']if a['anchor_id']=='gate_state')
    else:raise ValueError('No literal profile evidence; do not invent state: '+ob['id']+'/'+field)
   c['visual_obligation_evidence'][ob['id']]=ev
 return c

m=json.loads((Q/'frozen-input-manifest.json').read_text());results=[]
for case in m['cases']:
 idir=Path(case['input_dir'])
 for name,h in case['files'].items():assert sha((idir/name).read_bytes())==h,(case['id'],name)
 assert head()==PIN
 for label,data in [('before',before),('after',after)]:
  t=time.time();dest=Q/label/case['id'];dest.mkdir(parents=True,exist_ok=True)
  record={'case':case['id'],'cohort':case['cohort'],'state':case['state'],'language':case['language'],'arm':label,'source_pin':head(),'seed':m['seed'],'consumer':'Unmodified generate_candidate_pack public builder and audit_composed_prompt public audit; same interpreter/source runtime and cached index space','input_dir':str(idir)}
  try:
   envelope=g.load_request_envelope_arg(str(idir/'request-envelope.json'));controls=json.loads((idir/'creative-controls.json').read_text());core=g.load_authorial_core_arg(str(idir/'authorial-core.json'),request_envelope=envelope,creative_control_snapshot=controls);review=json.loads((idir/'embodiment-review.json').read_text());g.photo_embodiment.build_policy(core,review)
   pack=g.generate_candidate_pack(data,core,controls,review,seed=m['seed']);write(dest/'candidate-pack.json',[pack]);record['admission']='pass';record['pack_sha256']=sha((dest/'candidate-pack.json').read_bytes());record['pack_id']=pack['pack_id']
   ob=(pack.get('visual_obligations')or{}).get('obligations',[]);opts=(pack.get('visual_concept_candidates')or{}).get('candidates',[])
   record.update(hard_ids=[x['id']for x in ob],hard_third_components={x['id']:x['evidence_requirements'].get('component_3_phrase')for x in ob},hard_gate_ids=(pack.get('visual_obligations')or{}).get('required_hard_gates',[]),optional_visual_ids=[x['id']for x in opts],ordinary_candidate_ids=[x['id']for slot in pack.get('slots',{}).values()for x in slot.get('candidates',[])],bundle_ids=[x['id']for x in(pack.get('candidate_bundles')or{}).get('candidates',[])],clarifications=[{'id':x['id'],'profile_id':x.get('profile_id'),'required':x.get('required_in_final_prompt'),'status':x.get('applicability',{}).get('status')}for x in pack.get('semantic_clarification',{}).get('candidates',[])])
   c=compose(pack,case['state']);write(dest/'composed-baseline.json',c);a=audit.audit_composed_prompt(pack,c);write(dest/'composed-audit.json',a)
   record.update(audit_status=a['status'],failures=a['failures'],warnings=a['warnings'],baseline_unchanged=c['prompt_en']==core['baseline_prompt_en'],chosen_candidate_ids=[],chosen_visual_concept_ids=[],composed_sha256=sha((dest/'composed-baseline.json').read_bytes()))
   if label=='before'and case['cohort']=='original_source_guided_6':record['identical_to_prior_cli_pack']=json.loads((D/case['id']/'candidate-pack.json').read_text())[0]==pack
  except Exception as ex:
   record.update(error=str(ex),exception=type(ex).__name__,admission=record.get('admission','fail'));(dest/'error.txt').write_text(traceback.format_exc())
  record['seconds']=round(time.time()-t,3);results.append(record);write(Q/'results.json',results)
  print(case['id'],label,'admission',record['admission'],'hard',record.get('hard_ids'),'audit',record.get('audit_status'),'errors',record.get('error'),flush=True)
assert head()==PIN
write(Q/'final-pin.json',{'head':head(),'git_status':subprocess.check_output(['git','status','--short'],cwd=R,text=True),'production_changes':0,'provider_calls':0,'images':0})
