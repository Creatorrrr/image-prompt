"""Materialize the review's two already-frozen source-alignment negatives.
They supplement, never replace, the original6/fresh4/new canonical positive.
"""
import copy,hashlib,json,os,subprocess,sys
from pathlib import Path
R=Path('/workspace/scratch/ce8f20680f5a/image-prompt');D=Path(__file__).parent;Q=D/'qualification-extra';Q.mkdir(exist_ok=True);S=R/'skills/photo-prompt-image-generator';sys.dont_write_bytecode=True;sys.path.insert(0,str(S/'scripts'));import prompt_generator as g
sha=lambda b:hashlib.sha256(b).hexdigest()
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
edit=json.loads((D/'proposal/proposed-edit.json').read_text());controls=json.loads((D/'proposal/frozen-controls.json').read_text())['controls'];cases=[]
for cid,oid,control_id,state in [('source-guided-new-ko-closed','ko_fully_lowered','proposed_ko_closed_variant','fully_lowered'),('source-guided-new-ko-missing-guides','ko_partly_lowered','proposed_ko_missing_guides','partly_lowered')]:
 d=Q/cid;d.mkdir(exist_ok=True);orig=json.loads((D/oid/'authorial-core.json').read_text());core=copy.deepcopy(orig);phrase=next(c['text']for c in controls if c['id']==control_id);raw=orig['source_request'].replace(edit['old_value'],phrase);assert raw!=orig['source_request']
 env={'contract_version':'photo-request-envelope/v1','provenance':'requesting_user','request_id':cid,'request_text':raw,'request_sha256':sha(raw.encode()),'active_spans':[{'span_id':'scene','start':0,'end':len(raw),'text':raw}]};write(d/'request-envelope.json',env);write(d/'creative-context.json',{'subject_category':'nonhuman','no_people':False,'explicit_nonsexual':False})
 p=subprocess.run([sys.executable,str(S/'precore/creative_controls.py'),'--request-envelope-json',str(d/'request-envelope.json'),'--context-json',str(d/'creative-context.json'),'--output',str(d/'creative-controls.json')],cwd=R,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},capture_output=True,text=True);assert p.returncode==0,p.stderr
 (d/'control-resolution.stdout.txt').write_text(p.stdout);cc=json.loads((d/'creative-controls.json').read_text());core['source_request']=raw;core['creative_controls_sha256']=cc['canonical_sha256'];core['variation_key']=cid
 if control_id=='proposed_ko_missing_guides':core['intent_lock']['semantic_anchors']=[a for a in core['intent_lock']['semantic_anchors']if a['anchor_id']!='guided_grid_contact']
 for a in core['intent_lock']['semantic_anchors']:a['source_text']=a['source_text'].replace(edit['old_value'],phrase)
 for a in core['interpretation_provenance']:a['source_text']=raw
 write(d/'authorial-core.json',core);review=json.loads((D/oid/'embodiment-review.json').read_text());write(d/'embodiment-review.json',review)
 envelope=g.load_request_envelope_arg(str(d/'request-envelope.json'));n=g.load_authorial_core_arg(str(d/'authorial-core.json'),request_envelope=envelope,creative_control_snapshot=cc);g.photo_embodiment.build_policy(n,review)
 assert core['baseline_prompt_en']==orig['baseline_prompt_en']
 cases.append({'id':cid,'cohort':'additional_source_alignment_negative_2','state':state,'language':'ko','input_dir':str(d),'files':{p.name:sha(p.read_bytes())for p in d.iterdir()if p.is_file()},'control_origin':control_id,'limitation':'Source-guided canonical-trigger boundary, not fresh source-unexposed evidence. In missing-guides case, complete contact is an unbound baseline choice, not falsely declared requester evidence.'})
write(Q/'frozen-input-manifest.json',{'repository_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'seed':1003,'cases':cases,'purpose':'Two explicit canonical-source negatives required by independent review; kept separate from main10 and positive1.'})
source=(D/'run_qualification.py').read_text();assert "Q=D/'qualification'"in source
(Q/'run.py').write_text(source.replace("D=Path(__file__).parent;Q=D/'qualification'","D=Path(__file__).parent.parent;Q=D/'qualification-extra'"))
print('Frozen two supplemental source-alignment negatives before their retrieval.')
