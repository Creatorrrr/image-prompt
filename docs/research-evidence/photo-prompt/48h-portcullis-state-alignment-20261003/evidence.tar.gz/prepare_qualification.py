import copy,hashlib,json,os,subprocess,sys
from pathlib import Path
R=Path('/workspace/scratch/ce8f20680f5a/image-prompt');D=Path(__file__).parent;S=R/'skills/photo-prompt-image-generator';F=D/'fresh-controls';Q=D/'qualification';Q.mkdir(exist_ok=True);sys.dont_write_bytecode=True;sys.path.insert(0,str(S/'scripts'));import prompt_generator as g
sha=lambda b:hashlib.sha256(b).hexdigest()
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
# A pre-retrieval ownership refinement, never a baseline/request rewrite.
d=F/'stone_gate_en_02';core=json.loads((d/'authorial-core.json').read_text());a=next(a for a in core['intent_lock']['semantic_anchors']if a['anchor_id']=='property_1');assert a['dimension']=='composition';a.update(dimension='camera',target='scene',property='viewpoint.direction')
write(d/'authorial-core.attempt-2.json',core)
ep=g.load_request_envelope_arg(str(d/'request-envelope.json'));cc=json.loads((d/'creative-controls.json').read_text());n=g.load_authorial_core_arg(str(d/'authorial-core.attempt-2.json'),request_envelope=ep,creative_control_snapshot=cc);g.photo_embodiment.build_policy(n,json.loads((d/'embodiment-review.json').read_text()))
write(d/'authorial-core.json',core)
logs=json.loads((F/'adapter-attempts.json').read_text());logs.append({'case':'stone_gate_en_02','attempt':2,'reason':'Pre-retrieval ownership refinement: the prescribed view facing the gateway is a camera viewpoint.direction property, rather than composition. The exact source/evidence and request/baseline bytes are unchanged. Attempt 1 was schema-valid and is retained.','result':{'status':'pass','canonical_core_sha256':n['canonical_sha256']}});write(F/'adapter-attempts.json',logs)
fm=json.loads((F/'frozen-input-manifest.json').read_text());row=next(c for c in fm['cases']if c['id']=='stone_gate_en_02');row['files']={p.name:sha(p.read_bytes())for p in d.iterdir()if p.is_file()};write(F/'frozen-input-manifest.json',fm)
# Named additional source-guided control proves that the new exact Korean trigger
# reaches the public hard contract, rather than merely silencing both old states.
z=Q/'source-guided-new-ko-partial';z.mkdir(exist_ok=True);old=D/'ko_partly_lowered';edit=json.loads((D/'proposal/proposed-edit.json').read_text());orig=json.loads((old/'authorial-core.json').read_text());raw=orig['source_request'].replace(edit['old_value'],edit['new_value']);assert raw!=orig['source_request'];baseline=orig['baseline_prompt_en']
e={'contract_version':'photo-request-envelope/v1','provenance':'requesting_user','request_id':'source-guided-new-ko-partial','request_text':raw,'request_sha256':sha(raw.encode()),'active_spans':[{'span_id':'scene','start':0,'end':len(raw),'text':raw}]};write(z/'request-envelope.json',e);write(z/'creative-context.json',{'subject_category':'nonhuman','no_people':False,'explicit_nonsexual':False})
r=subprocess.run([sys.executable,str(S/'precore/creative_controls.py'),'--request-envelope-json',str(z/'request-envelope.json'),'--context-json',str(z/'creative-context.json'),'--output',str(z/'creative-controls.json')],cwd=R,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},capture_output=True,text=True);assert r.returncode==0,r.stderr
(z/'control-resolution.stdout.txt').write_text(r.stdout);cc=json.loads((z/'creative-controls.json').read_text());core=copy.deepcopy(orig);core['source_request']=raw;core['creative_controls_sha256']=cc['canonical_sha256'];core['variation_key']='source-guided-new-ko-partial'
for a in core['intent_lock']['semantic_anchors']:a['source_text']=a['source_text'].replace(edit['old_value'],edit['new_value'])
for a in core['interpretation_provenance']:a['source_text']=raw
write(z/'authorial-core.json',core);review=json.loads((old/'embodiment-review.json').read_text());write(z/'embodiment-review.json',review)
ep=g.load_request_envelope_arg(str(z/'request-envelope.json'));n=g.load_authorial_core_arg(str(z/'authorial-core.json'),request_envelope=ep,creative_control_snapshot=cc);g.photo_embodiment.build_policy(n,review)
extra={'id':'source-guided-new-ko-partial','state':'partly_lowered','language':'ko','source_guided':True,'purpose':'Additional canonical-trigger positive proves the replacement Korean phrase still activates the intended intermediate-state hard obligation through the public build. Not one of the fresh4 or original6; no original request replaced.','baseline_sha256':sha(baseline.encode()),'files':{p.name:sha(p.read_bytes())for p in z.iterdir()if p.is_file()}}
write(z/'input-manifest.json',extra)
cases=[]
for c in json.loads((D/'frozen-input-manifest.json').read_text())['cases']:cases.append({'id':c['id'],'cohort':'original_source_guided_6','input_dir':str(D/c['id']),'state':c['state'],'language':c['language'],'files':c['files']})
for c in fm['cases']:cases.append({'id':c['id'],'cohort':'fresh_source_unexposed_4','input_dir':str(F/c['id']),'state':c['state'],'language':c['language'],'files':c['files']})
cases.append({'id':extra['id'],'cohort':'additional_source_guided_positive_1','input_dir':str(z),'state':extra['state'],'language':'ko','files':extra['files']})
write(Q/'frozen-input-manifest.json',{'repository_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'seed':1003,'proposal_file_sha256':sha((D/'proposal/proposed-edit.json').read_bytes()),'fresh_request_file_sha256':sha((F/'requests.json').read_bytes()),'cases':cases})
print('All 11 inputs frozen before qualification retrieval; original requests and every baseline unchanged.')
