"""Run unmodified public generation CLI against frozen inputs and cached indexes."""
import hashlib,json,os,subprocess,sys,time
from pathlib import Path
ROOT=Path('/workspace/scratch/ce8f20680f5a/image-prompt');OUT=Path(__file__).parent; SKILL=ROOT/'skills/photo-prompt-image-generator'
sys.dont_write_bytecode=True
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
manifest=json.loads((OUT/'frozen-input-manifest.json').read_text())
env={k:v for k,v in os.environ.items() if not any(t in k.upper() for t in ['TOKEN','API_KEY','CREDENTIAL'])};env['PYTHONDONTWRITEBYTECODE']='1'
rows=[]
for c in manifest['cases']:
 d=OUT/c['id']
 for n,h in c['files'].items():assert sha(d/n)==h,(c['id'],n)
 cmd=[sys.executable,str(SKILL/'scripts/generate_photo_prompt.py'),'--request-envelope-json',str(d/'request-envelope.json'),'--authorial-core-json',str(d/'authorial-core.json'),'--creative-controls-json',str(d/'creative-controls.json'),'--embodiment-review-json',str(d/'embodiment-review.json'),'--seed',str(manifest['seed']),'--output-file',str(d/'candidate-pack.json')]
 started=time.time();r=subprocess.run(cmd,cwd=ROOT,env=env,capture_output=True,text=True,timeout=300)
 (d/'generation.stdout.txt').write_text(r.stdout);(d/'generation.stderr.txt').write_text(r.stderr)
 row={'case':c['id'],'command':cmd,'returncode':r.returncode,'seconds':round(time.time()-started,3),'error':r.stderr,'input_manifest_sha256':sha(OUT/'frozen-input-manifest.json')}
 if r.returncode==0:
  p=json.loads((d/'candidate-pack.json').read_text())[0]
  row.update({'pack_sha256':sha(d/'candidate-pack.json'),'pack_bytes':(d/'candidate-pack.json').stat().st_size,'pack_id':p['pack_id'],'hard_obligations':p.get('visual_obligations'),'optional_visual_candidates':p.get('visual_concept_candidates'),'clarifications':p.get('semantic_clarification'),'ordinary_candidates':{k:[v['id'] for v in x.get('candidates',[])] for k,x in p.get('slots',{}).items()},'optional_bundles':p.get('candidate_bundles')})
 rows.append(row);write(OUT/'public-generation-results.json',rows)
 print(c['id'],r.returncode,'hard',[x.get('profile_id')for x in (row.get('hard_obligations')or{}).get('obligations',[])],'bytes',row.get('pack_bytes'),r.stderr[:250],flush=True)
