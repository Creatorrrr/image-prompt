"""Freeze source-guided synthetic maintenance fixtures before actual retrieval.
Not naturally sampled requests, independent holdouts, or a photographic quality test.
"""
import hashlib,json,os,re,subprocess,sys
from pathlib import Path
ROOT=Path('/workspace/scratch/ce8f20680f5a/image-prompt'); OUT=Path(__file__).parent
SKILL=ROOT/'skills/photo-prompt-image-generator'; sys.dont_write_bytecode=True
sys.path.insert(0,str(SKILL/'scripts')); import prompt_generator as g

def sha(b):return hashlib.sha256(b).hexdigest()
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')

def run(cmd):
 r=subprocess.run(cmd,cwd=ROOT,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},text=True,capture_output=True)
 if r.returncode:raise RuntimeError(r.stderr)
 return r

ko='격자가 출입 개구부 안에 있다; 격자 옆단이 수직 홈에 맞물린다; 문짝 회전이 아닌 상하 이동 구조가 읽힌다'
en='a heavy gridded gate occupies the entrance opening; the grid edges sit inside vertical guide grooves; the gate is partly lowered along those upright grooves'
full_en='a heavy gridded gate occupies the entrance opening; the grid edges sit inside vertical guide grooves; the vertical sliding mechanism is legible rather than a swinging door'
draw='a raised bridge deck hinges at the gate threshold; the tilted deck exposes the ditch beneath it; a gap separates the deck end from the outer approach'
half_state='the gate is partly lowered along those upright grooves'
full_state='the gate is fully lowered along those upright grooves onto the threshold'
half_result='Its bottom edge hangs halfway down the entrance, leaving a clear open passage below'
full_result='Its bottom edge meets the stone sill, closing the passage completely'
head='An architectural photograph studies a fortified stone entrance. Within the opening, a heavy gridded gate occupies the entrance opening; the grid edges sit inside vertical guide grooves; '
tail='. A slightly oblique view keeps both side grooves and the bottom edge visible together. Soft overcast daylight describes the grid thickness and the recessed tracks, while the surrounding masonry remains quiet and subordinate.'
half_base=head+half_state+'. '+half_result+tail
full_base=head+full_state+'. '+full_result+tail
cases=[
 dict(id='ko_partly_lowered',language='ko',state='partly_lowered',request='건축 사진을 만들어 주세요: '+ko+'. 격자는 수직 홈을 따라 절반쯤 내려와 있고, 아래쪽 가장자리 밑에는 열린 통로가 또렷하게 남아 있다.',baseline=half_base,subject_source='격자가 출입 개구부 안에 있다',state_source='격자는 수직 홈을 따라 절반쯤 내려와 있고, 아래쪽 가장자리 밑에는 열린 통로가 또렷하게 남아 있다'),
 dict(id='en_partly_lowered',language='en',state='partly_lowered',request='Make an architectural photograph: '+en+'. The gate slides vertically, rather than swinging. Its bottom edge hangs halfway down the entrance, leaving a clear open passage below.',baseline=half_base,subject_source='a heavy gridded gate',state_source='Its bottom edge hangs halfway down the entrance, leaving a clear open passage below'),
 dict(id='ko_fully_lowered',language='ko',state='fully_lowered',request='건축 사진을 만들어 주세요: '+ko+'. 격자는 수직 홈을 따라 문턱까지 완전히 내려와 있고, 아래쪽 가장자리가 돌 문턱에 닿아 통로를 완전히 닫고 있다.',baseline=full_base,subject_source='격자가 출입 개구부 안에 있다',state_source='격자는 수직 홈을 따라 문턱까지 완전히 내려와 있고, 아래쪽 가장자리가 돌 문턱에 닿아 통로를 완전히 닫고 있다'),
 dict(id='en_fully_lowered',language='en',state='fully_lowered',request='Make an architectural photograph: '+full_en+'. The gate is fully lowered along those upright grooves onto the threshold. Its bottom edge meets the stone sill, closing the passage completely.',baseline=full_base,subject_source='a heavy gridded gate',state_source='The gate is fully lowered along those upright grooves onto the threshold. Its bottom edge meets the stone sill, closing the passage completely'),
 dict(id='en_drawbridge_complete',language='en',state='raised_drawbridge',request='Make an architectural photograph: '+draw+'.',baseline='An architectural photograph studies the approach to a fortified stone entrance. Here, '+draw+'. The bridge hinge, exposed ditch, and separated outer approach appear together in a slightly oblique view. Soft overcast daylight reveals the deck thickness and the stone threshold. The open space below the lifted deck carries the picture, with surrounding masonry providing a quiet structural frame.',subject_source='a raised bridge deck',state_source=draw),
 dict(id='en_broad_name_fully_lowered',language='en',state='fully_lowered',request='Make an architectural photograph of a portcullis fully lowered onto a stone threshold, its bottom edge touching the sill and the passage completely closed.',baseline=full_base,subject_source='a portcullis',state_source='fully lowered onto a stone threshold, its bottom edge touching the sill and the passage completely closed')]
# Freeze all raw requests before constructing controls or cores.
write(OUT/'frozen-requests.json',{'provenance':'Six source-guided synthetic maintenance requests; bilingual pair is two translations of one state, not two independent natural-query samples.','cases':cases})
manifest={'repository_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'seed':1003,'provenance':'Source-guided synthetic maintenance fixtures; every request, state, baseline and contract is frozen before retrieval; not a live requester instruction or natural-query accuracy sample.','cases':[]}
prechecks=[]
for c in cases:
 d=OUT/c['id']; d.mkdir(exist_ok=True); raw=c['request']; b=c['baseline']
 envelope={'contract_version':'photo-request-envelope/v1','provenance':'requesting_user','request_id':'synthetic-portcullis-state-'+c['id'],'request_text':raw,'request_sha256':sha(raw.encode()),'active_spans':[{'span_id':'scene','start':0,'end':len(raw),'text':raw}]}
 write(d/'request-envelope.json',envelope)
 write(d/'creative-context.json',{'subject_category':'nonhuman','no_people':False,'explicit_nonsexual':False})
 cmd=[sys.executable,str(SKILL/'precore/creative_controls.py'),'--request-envelope-json',str(d/'request-envelope.json'),'--context-json',str(d/'creative-context.json'),'--output',str(d/'creative-controls.json')]
 r=run(cmd);(d/'control-resolution.stdout.txt').write_text(r.stdout)
 controls=json.loads((d/'creative-controls.json').read_text())
 bridge=c['state']=='raised_drawbridge'; closed=c['state']=='fully_lowered'
 subject='A raised bridge deck above a ditch' if bridge else 'A heavy gridded entrance gate'
 event='A raised bridge deck pivots at its threshold hinge, exposing the ditch and separating its outer end from the approach' if bridge else ('The gridded entrance gate rests fully lowered on the threshold and closes the passage' if closed else 'The gridded entrance gate remains halfway lowered in its upright grooves with an open passage underneath')
 relation=draw if bridge else (full_state if closed else half_state)
 outcome='a gap separates the deck end from the outer approach' if bridge else (full_result if closed else half_result)
 concept='An architectural photograph'; subject_phrase='a raised bridge deck' if bridge else 'a heavy gridded gate'
 anchors=[{'anchor_id':'architecture','source_text':raw,'dimension':'concept','prompt_evidence':concept}, {'anchor_id':'primary_structure','source_text':c['subject_source'],'dimension':'subject','prompt_evidence':subject_phrase},{'anchor_id':'gate_state','source_text':c['state_source'],'dimension':'event','prompt_evidence':relation},{'anchor_id':'passage_result','source_text':c['state_source'],'dimension':'event','prompt_evidence':outcome}]
 if not bridge and c['id']!='en_broad_name_fully_lowered':
  anchors.append({'anchor_id':'guided_grid_contact','source_text':ko if c['language']=='ko' else (en if not closed else full_en),'dimension':'event','prompt_evidence':'the grid edges sit inside vertical guide grooves'})
 core={'contract_version':'photo-authorial-core/v3','provenance':'agent_prepack','source_request':raw,'creative_controls_sha256':controls['canonical_sha256'],'interpreted_intent':'Preserve the specified entrance mechanism and its exact opening state. The authorial direction uses a quiet oblique architectural view to keep the structural contacts and available passage legible together.','subject':subject,'setting':'A fortified stone entrance and its threshold','event':event,'visual_priorities':[relation,outcome,'Visible structural contacts within the stone entrance'],'baseline_prompt_en':b,'user_definitions':[],'interpretation_provenance':[{'term':'architectural entrance state','source_text':raw,'basis':'request_context','resolution':'Read the complete request as the stated physical entrance mechanism and opening state. '+event+'.','sources':[]}],'unresolved_ambiguities':[],'user_exclusions':[],'runtime_forbidden_labels':[],'intent_lock':{'contract_version':'photo-intent-lock/v2','priority':'requesting_user','semantic_anchors':anchors,'locked_dimensions':['concept','subject','event'],'open_dimensions':['setting','composition','framing','lighting','camera','material','color','atmosphere']},'semantic_assertions':[{'assertion_id':'primary_subject_category','dimension':'subject','polarity':'required','source_span_ids':['scene'],'affected_dimensions':['subject'],'axes':{'subject_category':'object'},'evidence':{'subject_phrase':subject_phrase}},{'assertion_id':'entrance_opening_state','dimension':'event','polarity':'required','source_span_ids':['scene'],'affected_dimensions':['event'],'axes':{'opening_state':c['state']},'evidence':{'state_phrase':relation,'passage_phrase':outcome}}],'request_lineage':None,'style':{'domain':'architectural photography','family':'restrained naturalistic architecture','evidence':['An architectural photograph','Soft overcast daylight']},'variation_key':c['id']}
 review={'contract_version':'photo-embodiment-review/v1','provenance':'agent_prepack','prompt_sha256':sha(b.encode()),'scope':'not_applicable','summary':'The scene contains an architectural entrance mechanism and masonry. No living bodily action requires an embodiment chain; the frozen prompt keeps the relevant supports and structural contacts visible.','checks':{}}
 # Candidate-free schema/content minima check, then normal input normalization.
 counts={f:{'minimum':m,'count':len(g.authorial_request_content_words(core[f]))} for f,m in {'interpreted_intent':4,'subject':2,'setting':3,'event':3}.items()}
 assert all(x['count']>=x['minimum']for x in counts.values())
 assert all(a['source_text'] in raw and a['prompt_evidence'] in b for a in anchors)
 assert (not closed) or ('partly lowered' not in b and 'halfway' not in b)
 write(d/'authorial-core.json',core);write(d/'embodiment-review.json',review)
 ep=g.load_request_envelope_arg(str(d/'request-envelope.json'))
 normalized=g.load_authorial_core_arg(str(d/'authorial-core.json'),request_envelope=ep,creative_control_snapshot=controls)
 policy=g.photo_embodiment.build_policy(normalized,review)
 prechecks.append({'case':c['id'],'schema_summaries':counts,'baseline_english_words':len(re.findall(r"[A-Za-z0-9]+(?:['’\-][A-Za-z0-9]+)*",b)),'input_normalization':'pass','embodiment_binding':'pass','canonical_core_sha256':normalized['canonical_sha256'],'canonical_intent_lock_sha256':normalized['intent_lock']['canonical_sha256'],'state_preserved':True})
 manifest['cases'].append({'id':c['id'],'language':c['language'],'state':c['state'],'baseline_sha256':sha(b.encode()),'files':{p.name:sha(p.read_bytes())for p in sorted(d.iterdir())if p.is_file()}})
write(OUT/'pre-retrieval-input-validation.json',prechecks)
manifest['frozen_requests_sha256']=sha((OUT/'frozen-requests.json').read_bytes())
write(OUT/'frozen-input-manifest.json',manifest)
(OUT/'PROVENANCE.md').write_text('These six requests are source-guided synthetic maintenance fixtures. The Korean full-state request intentionally retains the inherited three mechanism clauses, then explicitly closes the gate. English and Korean paired scenes share byte-identical English baselines and the same state, guide-contact and passage facts. The drawbridge control uses its unchanged complete selected relation. The broad-name control names only the portcullis and closed state; its descriptive baseline is agent-authored. All request envelopes, controls, cores, and embodiment reviews passed candidate-free normal input normalization before any runtime data load or retrieval. Summaries were checked against the concrete-word minima before fixture execution. No opt-in visual intent is supplied, no closed scene contains intermediate-state wording, and no image or provider call is authorized. The request-envelope provenance marker represents the synthetic requester role required by the current schema, not an actual separate user message.\n')
print(json.dumps({'frozen_cases':len(cases),'input_manifest_sha256':sha((OUT/'frozen-input-manifest.json').read_bytes()),'normalization':'all pass','retrieval_calls':0}))
