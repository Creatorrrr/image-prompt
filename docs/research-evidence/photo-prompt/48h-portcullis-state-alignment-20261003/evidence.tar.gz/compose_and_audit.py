"""Write unchanged-baseline zero-adoption compositions and use public composed-audit CLI."""
import copy,hashlib,json,os,subprocess,sys,time
from pathlib import Path
ROOT=Path('/workspace/scratch/ce8f20680f5a/image-prompt');OUT=Path(__file__).parent;SKILL=ROOT/'skills/photo-prompt-image-generator'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
env={k:v for k,v in os.environ.items()if not any(t in k.upper()for t in ['TOKEN','API_KEY','CREDENTIAL'])};env['PYTHONDONTWRITEBYTECODE']='1'
rows=[]
for c in json.loads((OUT/'frozen-input-manifest.json').read_text())['cases']:
 d=OUT/c['id']; f=d/'candidate-pack.json'
 if not f.exists():
  rows.append({'case':c['id'],'composition_status':'not_run_pack_not_admitted'});continue
 p=json.loads(f.read_text())[0];core=p['authorial_core'];lock=core['intent_lock'];b=core['baseline_prompt_en'];review=copy.deepcopy(p['embodiment_preflight']['baseline_review']);review['provenance']='agent_postcomposition'
 hard=(p.get('visual_obligations')or{}).get('obligations',[])
 conflict=c['state']=='fully_lowered' and any(x['id']=='pf_portcullis'for x in hard)
 composed={'core_retrieval_sha256':p['core_retrieval']['canonical_sha256'],'pack_id':p['pack_id'],'prompt_en':b,'negative_en':p['negative_en'],'chosen_candidate_ids':[],'chosen_visual_concept_ids':[],'composer':'agent','embodiment_review':{'source_contract_sha256':p['embodiment_preflight']['canonical_sha256'],'review':review},'candidate_interpretations':[],'authorial_core_binding':{'source_authorial_core_sha256':core['canonical_sha256'],'source_intent_lock_sha256':lock['canonical_sha256'],'preserved_anchor_ids':[x['anchor_id']for x in lock['semantic_anchors']],'preserved_evidence':[],'authorial_decisions':[]},'semantic_clarification_decisions':[],'creative_augmentation_brief':{'decisions':[{'candidate_id':x['id'],'decision':'rejected','rationale':'Retain the complete frozen architectural state and decline optional scene changes'}for x in p['creative_augmentation']['candidates']]}}
 for x in p['semantic_clarification']['candidates']:
  target_conflict=conflict and x.get('profile_id')=='pf_portcullis'
  state='applied' if x.get('required_in_final_prompt') and not target_conflict else 'rejected'
  rationale='Retain the complete frozen requester-owned scene and decline optional reinterpretations'
  if target_conflict:rationale='The profile requires a partly lowered gate but the frozen request requires complete closure onto the sill. Preserve closure and reject this conflicting interpretation.'
  composed['semantic_clarification_decisions'].append({'clarification_id':x['id'],'decision':state,'rationale':rationale,'prompt_evidence':lock['semantic_anchors'][0]['prompt_evidence'] if x.get('source')!='visual_meaning_registry' else next((a['prompt_evidence']for a in lock['semantic_anchors']if a['anchor_id']=='gate_state'),b)})
 contract=p.get('semantic_assertion_obligations')
 if contract:composed['semantic_assertion_evidence']={'source_contract_sha256':contract['canonical_sha256'],'evidence':{x['assertion_id']:x['frozen_evidence']for x in contract['obligations']}}
 if hard:
  evidence={}
  for ob in hard:
   evidence[ob['id']]={}
   for name,req in ob['evidence_requirements'].items():
    phrases=[s for s in req.get('must_mention_any',[])if s in b]
    if phrases:evidence[ob['id']][name]=phrases[0]
    elif conflict and ob['id']=='pf_portcullis' and name=='component_3_phrase':evidence[ob['id']][name]='the gate is fully lowered along those upright grooves onto the threshold'
    else:raise ValueError((c['id'],ob['id'],name,'No real baseline evidence; do not fabricate'))
  composed['visual_obligation_evidence']=evidence
 assert composed['prompt_en']==core['baseline_prompt_en']
 assert not composed['chosen_candidate_ids'] and not composed['chosen_visual_concept_ids']
 write(d/'composed-baseline.json',composed)
 cmd=[sys.executable,str(SKILL/'scripts/audit_composed_prompt.py'),'--pack',str(f),'--composed',str(d/'composed-baseline.json')]
 t=time.time();r=subprocess.run(cmd,cwd=ROOT,env=env,capture_output=True,text=True,timeout=300)
 (d/'composed-audit.stdout.json').write_text(r.stdout);(d/'composed-audit.stderr.txt').write_text(r.stderr)
 result=json.loads(r.stdout)if r.stdout.strip().startswith('{')else None
 row={'case':c['id'],'command':cmd,'returncode':r.returncode,'seconds':round(time.time()-t,3),'error':r.stderr,'result':result,'conflicting_hard_duty':conflict,'baseline_unchanged':True,'chosen_candidate_ids':[],'chosen_visual_concept_ids':[],'composed_sha256':sha(d/'composed-baseline.json'),'pack_sha256':sha(f)}
 rows.append(row);write(OUT/'composed-audit-results.json',rows)
 print(c['id'],r.returncode,'conflicting hard duty',conflict,'failures',(result or{}).get('failures'),flush=True)
