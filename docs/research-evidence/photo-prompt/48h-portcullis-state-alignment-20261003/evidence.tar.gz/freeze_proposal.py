"""Freeze minimal DATA proposal and exact-trigger controls outside production.
This proposal is not installed or index-qualified, and controls are lexical diagnostics.
"""
import copy,hashlib,json,subprocess,sys
from pathlib import Path
ROOT=Path('/workspace/scratch/ce8f20680f5a/image-prompt');OUT=Path(__file__).parent;S=ROOT/'skills/photo-prompt-image-generator';sys.dont_write_bytecode=True
sys.path.insert(0,str(S/'scripts'));import prompt_generator as g
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
source=S/'assets/photo_prompt_visual_obligations_palace_fortification.json';raw=json.loads(source.read_text());profiles={p['id']:p for p in raw['profiles']};p=copy.deepcopy(profiles['pf_portcullis']);old=p['activation']['exact_terms'][1]
new='격자가 출입 개구부 안에 있다; 격자 옆단이 수직 홈에 맞물린다; 격자가 그 수직 홈을 따라 부분적으로 내려와 있다'
p['activation']['exact_terms'][1]=new
prop=OUT/'proposal';prop.mkdir(exist_ok=True)
write(prop/'pf_portcullis.proposed.json',p)
write(prop/'proposed-edit.json',{'status':'frozen_proposal_only_not_installed_not_index_qualified','source_path':str(source.relative_to(ROOT)),'source_sha256':sha(source),'profile_id':'pf_portcullis','operation':'replace_one_exact_term','old_value':old,'new_value':new,'unchanged':['English exact term','selected architectural variant','all three component relations','component evidence requirements','composition instruction','render gates','ordinary candidates and bundles','pf_drawbridge sibling'],'meaning':'The Korean trigger itself now requires the same intermediate state as the existing English trigger and component 3. It is not broadened to fully closed or every portcullis state.','qualification_needed':['Generated visual index rebuild with verified cache compatibility and batch size 1 for any changed embedding text','Paired normal-consumer replay on the integrated runtime branch','Keep contextual contradictions and occurrence-scoped routing in runtime, not DATA exception rules'],'known_recall_change':'The original Korean mechanism-only phrase stops exact activation even when a later sentence adds half-lowered state. The canonical new Korean exact trigger activates the selected variant; original requests retain their frozen state through ordinary core/assertion contracts.'})
requests=json.loads((OUT/'frozen-requests.json').read_text())['cases']
controls=[{'id':c['id'],'text':c['request'],'origin':'unchanged six-request matrix'}for c in requests]
controls+=[{'id':'proposed_ko_exact_partial','text':new,'origin':'new source-faithful exact-trigger control only; no consumer rerun'},{'id':'proposed_ko_closed_variant','text':new.replace('부분적으로 내려와 있다','문턱까지 완전히 내려와 있다'),'origin':'single state substitution negative'},{'id':'proposed_ko_missing_guides','text':'; '.join([new.split('; ')[0],new.split('; ')[2]]),'origin':'guide-contact omission negative'}]
for x in controls:
 for label,prof in [('current',profiles['pf_portcullis']),('proposed',p)]:
  x[label+'_unnegated_exact_match']=any(g.intent_alias_matches(x['text'],a)and not g.intent_term_is_negated(x['text'],a) for a in prof['activation']['exact_terms'])
 x['unchanged_drawbridge_exact_match']=any(g.intent_alias_matches(x['text'],a)and not g.intent_term_is_negated(x['text'],a)for a in profiles['pf_drawbridge']['activation']['exact_terms'])
write(prop/'frozen-controls.json',{'qualification':'Literal alias-matcher diagnostics only; no fabricated vector/hit, public pack, improvement, or pixel claim. Candidate-free controls freeze the intended boundary for runtime integration.','controls':controls})
assert controls[-3]['proposed_unnegated_exact_match']
assert not controls[-2]['proposed_unnegated_exact_match'] and not controls[-1]['proposed_unnegated_exact_match']
assert profiles['pf_portcullis']['activation']['exact_terms'][0]==p['activation']['exact_terms'][0]
assert len(p['activation']['exact_terms'])==2
paths=[S/'SKILL.md',S/'references/maintenance.md',S/'references/composition-contract.md',source,S/'assets/photo_prompt_palace_fortification_extension.json',S/'assets/photo_prompt_visual_profile_index.json',S/'assets/photo_prompt_semantic_index.json',S/'scripts/generate_photo_prompt.py',S/'scripts/prompt_generator.py',S/'scripts/audit_composed_prompt.py',S/'scripts/visual_profile_contracts.py',ROOT/'tests/test_photo_palace_fortification_semantics.py',ROOT/'docs/research-evidence/photo-prompt/palace-fortification-20260909/implementation-report.md',ROOT/'docs/research-evidence/photo-prompt/palace-fortification-20260909/profile-matrix.md',ROOT/'docs/research-evidence/photo-prompt/palace-fortification-20260909/build-research-data.py',ROOT/'docs/research-evidence/photo-prompt/palace-fortification-20260909/research-report.md']
write(OUT/'source-manifest.json',{'repository_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'files':{str(x.relative_to(ROOT)):sha(x)for x in paths},'git_status':subprocess.check_output(['git','status','--short'],cwd=ROOT,text=True),'production_edits':0,'provider_calls':0,'generated_images':0,'cached_indexes_loaded_and_validated_by_normal_cli':True})
print('Proposal frozen outside repository; exact trigger controls',len(controls))
