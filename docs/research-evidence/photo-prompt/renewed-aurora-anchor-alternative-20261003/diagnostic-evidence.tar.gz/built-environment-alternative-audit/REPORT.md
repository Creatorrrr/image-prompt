# Built environment, doorway and transport alternative audit

Decision: KEEP current data in this bounded round. No narrow, source-supported, complete repair is justified by the five newly inspected profiles. Two broader source-scope tensions are recorded below rather than hidden or repaired partially.

## Scope and exclusions

Fresh full-profile review: ed_subway_exit, ed_rain_threshold, household_energy_affordability_coping_relation, occupied_housing_habitability_mitigation_relation, transport_affordability_access_barrier_event. Prior architecture, palace, portal, liminal, submerged-settlement, rover, EVA, microgravity and renewed structure audits were checked as exclusion inventory and were not requalified. Convoy, ghost, aurora and instrument/runtime issues were excluded.

Read every selected definition, activation, runtime expression, authored component, derived composition instruction, evidence anchor, render gate and reject substitute. Inspected the complete directly linked candidate records. The proof uses production candidate_pack_visual_profile_obligation, not assumptions from raw JSON (these profiles have authored_components, so raw top-level evidence/gates are intentionally absent).

## Decisions

1. ed_subway_exit — KEEP. Source definition, four authored duties, candidate and materialized obligation consistently describe alighting through an open train doorway onto the platform. This is a narrow exit event; boarding, a closed door or a standing platform portrait is not an omitted alternative. Runtime labels are optional and cannot add a conflicting geometry requirement.

2. ed_rain_threshold — KEEP. Its allowed receiver remains “a nearby floor mat or stable surface” in definition, authored matching/evidence, composition instruction and render gate. Interior/exterior boundary, hand folding damp umbrella, localized weather wetness and receiving surface remain the four duties. No mat-only forced gate or runtime label was found. The research's illustrative floor mat is an example, not a reason to remove the explicit stable-surface branch.

3. household_energy_affordability_coping_relation — KEEP for this round; record broader source-scope tension. Heating OR cooling, unavailable OR unaffordable service, finite-service OR spent-resource cue, draft OR heat-control measures all survive materialization. Cooling is not narrowed to winter heating. However the high-level definition/proposition says adults consolidate activity OR seal heat transfer, while both exact English activation variants and detailed authored action, candidate action, composition and aftermath require consolidated use AND practical thermal control. This inconsistency exists in the original proposal's meaning versus exact examples as well. It is not an isolated evidence/gate loss. A one-leaf evidence addition would still leave contradictory instruction/gate requirements. No broad change is proposed without an independently reviewed event-scope decision and complete coherent alternatives preserving service constraint and room-wide result.

4. occupied_housing_habitability_mitigation_relation — KEEP for this round; record broader source-scope tension. Definition and original proposal mention cold/damp/leak/ventilation/sanitation, but the detailed traceable source component consistently names leak/dampness/draft throughout match terms, evidence, instruction and gate. Candidate action and prop permit a ventilation problem/aid, which makes the ventilation discrepancy more concrete, but sanitation has no corresponding independently specified observable branch in those narrow duties. A gate-only or evidence-only correction would be incomplete; a ventilation or sanitation branch needs a full authored-component/source decision (physical source/path, living-zone consequence, provisional mitigation and unresolved remainder), not a generic room-condition synonym. Current no-class/health/housing-status inference boundaries remain intact.

5. transport_affordability_access_barrier_event — KEEP. Fare OR access-resource gap and vehicle departure OR gate closure remain explicit across authored evidence, instructions and gates. “Fare-controlled threshold” can include a boarding/payment point; it does not itself demand a fixed railway gate. The source's gate OR boarding-point composition does not justify changing to generic geographic access, a closed route with no resource constraint, ordinary missed timing, or infrastructure breakdown. Runtime definition-only policy does not add a train-only label. Optional candidates favor a departing-vehicle scene but do not narrow the hard profile or authorize activation by themselves.

## Source provenance

- everyday-scene-20260923/report.md: narrow P0 event matrix and boundary/umbrella hand/wet-route ownership discussion (lines 88–89, 107); implementation-coverage.json; complete everyday extension and authored profiles
- poverty-visual-semantics-20260907/report-source.md: housing/energy service constraints and no appearance-classification rule (127–136), transport access distinction (147–154), P0 matrix (259–262)
- Same package candidate-data-proposal.json: original meaning, exact examples, required groups and composition for three profiles; routing-regression-proposal.jsonl preserves narrow exact routes
- Complete linked candidates and semantics in linked-candidate-and-semantics-source.json and linked-candidates-full.json
- Exact source files and hashes copied under source-snapshots/ and manifest.json

Original public sources were not fetched again. Findings concern maintained source-package consistency, not independent empirical housing, thermal-service, transport-policy or historical claims.

## Production materializer proof

probe.py loaded the real registry, compiled authored components and invoked candidate_pack_visual_profile_obligation on raw and loaded profiles. For all five profiles, raw and loaded materialization are identical. Authored instructions, evidence arrays, required groups/fields, runtime expressions and render gates project exactly. Canonical complete evidence validates; component omission tests reject all 23 single-duty omissions. This is a component-matcher test, not a claim that normalize_visual_intent rejects partial input.

consumer-proof.json preserves full raw profiles, compiled profiles, actual materialized obligations, complete bindings and omission outcomes. No runtime/source/index edits, providers or images. Source hashes remained stable during the probe. No normal V6 scene qualification, retrieval improvement, alternate natural-language coverage or pixel/aesthetic result is claimed.
