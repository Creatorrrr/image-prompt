from pathlib import Path
import json,hashlib,sys,subprocess,copy
sys.dont_write_bytecode=True
O=Path(__file__).resolve().parent;R=O.parent.parent/'image-prompt';S=R/'skills/photo-prompt-image-generator/scripts';A=S.parent/'assets';sys.path.insert(0,str(S));import prompt_generator as g
D=lambda p:json.loads(p.read_text());H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def W(n,x):(O/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
ids=['ed_subway_exit','ed_rain_threshold','household_energy_affordability_coping_relation','occupied_housing_habitability_mitigation_relation','transport_affordability_access_barrier_event']
files=[A/'photo_prompt_visual_obligations_everyday_scene.json',A/'photo_prompt_visual_obligations_poverty.json',A/'photo_prompt_everyday_scene_extension.json',A/'photo_prompt_poverty_extension.json',S/'prompt_generator.py',S/'visual_profile_contracts.py',S/'audit_composed_prompt.py',R/'docs/research-evidence/photo-prompt/everyday-scene-20260923/report.md',R/'docs/research-evidence/photo-prompt/everyday-scene-20260923/implementation-coverage.json',R/'docs/research-evidence/photo-prompt/poverty-visual-semantics-20260907/report-source.md',R/'docs/research-evidence/photo-prompt/poverty-visual-semantics-20260907/candidate-data-proposal.json',R/'docs/research-evidence/photo-prompt/poverty-visual-semantics-20260907/routing-regression-proposal.jsonl']
start={str(f.relative_to(R)):H(f)for f in files};raw={};origins={}
for f in files[:2]:
 for i,p in enumerate(D(f)['profiles']):
  if p['id']in ids:raw[p['id']]=p;origins[p['id']]=dict(file=str(f.relative_to(R)),pointer='/profiles/'+str(i))
reg=g.load_visual_obligation_registry(A/'photo_prompt_visual_obligations.json');proof=[]
for id in ids:
 p=next(x for x in reg['profiles']if x['id']==id);mat=g.candidate_pack_visual_profile_obligation(raw[id],reg,activation_source='read_only_source_consistency_audit',source_intent_ids=[])
 assert mat==g.candidate_pack_visual_profile_obligation(p,reg,activation_source='read_only_source_consistency_audit',source_intent_ids=[])
 cs=raw[id]['authored_components']['components'];assert mat['component_semantics']['required_group_ids']==[c['id']for c in cs]
 assert mat['prompt_binding']['required_evidence_fields']==[c['evidence_field']for c in cs]
 assert mat['render_gates']==[c['render_gate']for c in cs]
 assert mat['composition_instruction']==' '.join(c['instruction']for c in cs)
 assert mat['runtime_expression']==raw[id]['runtime_expression']
 assert mat['evidence_requirements']=={c['evidence_field']:dict(min_content_words=c['min_content_words'],must_mention_any=c['evidence_terms'])for c in cs}
 b={c['evidence_field']:c['evidence_terms'][0]for c in cs};g.normalize_visual_intent(dict(contract_version=g.VISUAL_INTENT_CONTRACT_VERSION,provenance='agent_prepack',obligations=[dict(profile_id=id,source='explicit_user_requirement',scope='request_only',source_text=p['activation']['exact_terms'][0],bindings=b)]),reg)
 full=g.candidate_pack_visual_component_match(p,' '.join(b.values()));assert full
 negative={}
 for field in b:
  q=copy.deepcopy(b);del q[field];negative[field]=g.candidate_pack_visual_component_match(p,' '.join(q.values()));assert negative[field]is None
 proof.append(dict(id=id,source=origins[id],raw_full_profile=raw[id],compiled_full_profile=p,actual_materialized_obligation=mat,canonical_complete_bindings=b,normalizer_accepts_supplied_complete_bindings=True,component_match=full,component_omission_results=negative,raw_and_loaded_materialization_identical=True,authored_surface_projection_exact=True))
W('consumer-proof.json',proof)
linked=[]
for f in files[2:4]:
 payload=D(f)
 def walk(x,path=''):
  if isinstance(x,dict):
   if x.get('id')in ids or set(x.get('hard_profile_ids',[]))&set(ids) or any(str(x.get('id','')).startswith(i+'_')for i in ids):linked.append(dict(file=str(f.relative_to(R)),pointer=path,record=x));return
   for k,v in x.items():walk(v,path+'/'+k)
  elif isinstance(x,list):
   for i,v in enumerate(x):walk(v,path+'/'+str(i))
 walk(payload)
W('linked-candidate-and-semantics-source.json',linked)
for f in files:
 dest=O/'source-snapshots'/f.relative_to(R);dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(f.read_bytes())
end={str(f.relative_to(R)):H(f)for f in files};assert start==end
W('manifest.json',dict(head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),status=subprocess.check_output(['git','status','--short'],cwd=R,text=True),source_hashes=start,source_hashes_unchanged=True,profile_ids=ids,provider_calls=0,images=0,normal_cli_packs=0,scope='Read-only source consistency/materializer proof. Not normal V6 scene qualification or image/retrieval evaluation. Original primary websites not re-fetched. No repo edits.'))
print('PASS: five full profiles, exact authored projections through production materializer, complete-binding normalization and 23 omission checks; source hashes unchanged; no provider calls.')
