import copy,hashlib,json,os,subprocess,sys
from pathlib import Path
sys.dont_write_bytecode=True
O=Path(__file__).resolve().parent;B=O.parent/'remaining-structure-audit';R=O.parent.parent/'image-prompt';S=R/'skills/photo-prompt-image-generator/scripts'
read=lambda p:json.loads(p.read_text())
def save(p,x):p.parent.mkdir(exist_ok=True,parents=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
F=B/'public-cli/before-compositions';E=O/'after-compositions';assert not E.exists();E.mkdir();results=[]
for row in read(F/'frozen-composition-manifest.json'):
 name=row['case'];assert sha(F/row['file'])==row['sha256'];c=read(F/row['file']);before=copy.deepcopy(c);pack=read(O/'after'/(name+'-pack.json'))[0];c['pack_id']=pack['pack_id'];assert c['core_retrieval_sha256']==pack['core_retrieval']['canonical_sha256'];assert c['authorial_core_binding']['source_authorial_core_sha256']==pack['authorial_core']['canonical_sha256'];assert c['embodiment_review']['source_contract_sha256']==pack['embodiment_preflight']['canonical_sha256'];assert all(c[k]==v for k,v in before.items()if k!='pack_id')
 save(E/row['file'],c);cmd=[sys.executable,str(S/'audit_composed_prompt.py'),'--pack',str(O/'after'/(name+'-pack.json')),'--composed',str(E/row['file'])];p=subprocess.run(cmd,cwd=R,capture_output=True,text=True,env={k:v for k,v in os.environ.items()if not any(t in k.upper()for t in ['KEY','TOKEN','SECRET','CREDENTIAL'])});save(E/(name+'-cli.json'),dict(command=cmd,exit_code=p.returncode,stdout=p.stdout,stderr=p.stderr));r=json.loads(p.stdout);save(E/(name+'-audit.json'),r);b=read(F/(name+'-audit.json'));results.append(dict(case=name,status_before=b['status'],status_after=r['status'],expected_after=row['expected_after'],matches=r['status']==row['expected_after']and not r['failures'],warnings_identical=b.get('warnings',[])==r.get('warnings',[]),failures_before=b['failures'],failures_after=r['failures'],prompt_and_evidence_identical=True,only_composed_payload_field_changed='pack_id'if c['pack_id']!=before['pack_id']else None));save(E/'summary.json',results);print(name,r['status'],r['failures'],flush=True)
assert all(x['matches']for x in results)
