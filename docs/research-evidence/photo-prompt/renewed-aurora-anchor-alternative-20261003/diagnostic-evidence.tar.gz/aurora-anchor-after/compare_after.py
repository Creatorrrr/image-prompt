import hashlib,json
from pathlib import Path
O=Path(__file__).resolve().parent;B=O.parent/'remaining-structure-audit';D=B/'public-cli';R=O.parent.parent/'image-prompt'
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):p.parent.mkdir(exist_ok=True,parents=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def diff(a,b,p=''):
 if isinstance(a,dict)and isinstance(b,dict):return sum((diff(a.get(k),b.get(k),p+'/'+k)for k in sorted(a.keys()|b.keys())),[])
 if isinstance(a,list)and isinstance(b,list)and len(a)==len(b):return sum((diff(x,y,p+'/'+str(i))for i,(x,y)in enumerate(zip(a,b))),[])
 return []if a==b else[dict(path=p,before=a,after=b)]
def ids(x,p=''):
 if isinstance(x,dict):return{key:val for k,v in x.items()for key,val in ids(v,p+'/'+k).items()}
 if isinstance(x,list):
  d={p:[v['id']for v in x]}if x and all(isinstance(v,dict)and 'id'in v for v in x)else{}
  for i,v in enumerate(x):d.update(ids(v,p+'/'+str(i)))
  return d
 return{}
rows=[]
for x in read(D/'frozen-input-manifest.json'):
 name=x['case'];a=read(D/'before'/(name+'-pack.json'))[0];b=read(O/'after'/(name+'-pack.json'))[0];dd=diff(a,b);save(O/'pack-diffs'/(name+'.json'),dd);seq=diff(ids(a),ids(b));save(O/'sequence-diffs'/(name+'.json'),seq)
 if x['target_profile']:
  expected=['/pack_id','/visual_obligations/obligations/0/composition_instruction','/visual_obligations/obligations/0/render_gates/0/description','/visual_obligations/obligations/0/runtime_expression/prompt_label_terms'];assert sorted(d['path']for d in dd)==sorted(expected),dd
 else:assert not dd
 assert not seq;rows.append(dict(case=name,diff_paths=[d['path']for d in dd],all_ordering_identical=True,entire_pack_identical=not dd,core_identical=a['authorial_core']==b['authorial_core'],retrieval_identical=a['core_retrieval']==b['core_retrieval']))
manifest=read(B/'artifact-manifest.json');integrity={k:sha(B/k)==v for k,v in manifest.items()};assert all(integrity.values());save(O/'frozen-before-integrity.json',integrity)
run=read(O/'after/run-manifest.json');source_unchanged={k:sha(R/k)==v for k,v in run['hashes'].items()};assert all(source_unchanged.values())
save(O/'AFTER-SUMMARY.json',dict(cli_pass=all(x['exit_code']==0 for x in run['cases']),cases=rows,compositions=read(O/'after-compositions/summary.json'),frozen_before_artifact_count=len(integrity),frozen_before_integrity=True,source_stable_through_after=True,provider_calls=0,images=0));print('PASS: exact expected whole-pack deltas, all ID ordering stable, BEFORE artifacts intact')
