"""Read-only review of initial aurora three-leaf proposal."""
from pathlib import Path
import copy,hashlib,json,sys
from unittest.mock import patch
sys.dont_write_bytecode=True
P=Path(__file__).resolve().parent;Q=P.parent/'remaining-structure-audit';R=P.parent.parent/'image-prompt';A=R/'skills/photo-prompt-image-generator/assets';sys.path.insert(0,str(A.parent/'scripts'))
import prompt_generator as pg
import audit_composed_prompt as au
import build_visual_profile_index as builder
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def dump(n,x):(P/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
PID='auroral_arc_curtain_atmosphere';old=read(Q/'profile-before.json');proposed=read(Q/'profile-proposed.json');dump('initial-profile-before.json',old);dump('initial-profile-proposed.json',proposed);dump('initial-exact-leaves.json',read(Q/'exact-leaves.json'))
tracked=[A/'photo_prompt_visual_obligations.json',A/'photo_prompt_visual_profile_index.json',Q/'profile-before.json',Q/'profile-proposed.json'];hashes={str(p):sha(p)for p in tracked}
with patch.object(pg,'embed_texts_with_gemini',side_effect=AssertionError('provider forbidden')),patch.object(builder,'embed_texts_with_gemini',side_effect=AssertionError('provider forbidden')),patch('socket.create_connection',side_effect=AssertionError('network forbidden')):
 reg=pg.load_visual_obligation_registry(A/'photo_prompt_visual_obligations.json');assert next(x for x in reg['profiles']if x['id']==PID)==old
 new=copy.deepcopy(reg);new['profiles'][next(i for i,p in enumerate(new['profiles'])if p['id']==PID)]=proposed
 ot={x['id']:pg.visual_profile_semantic_text(x)for x in reg['profiles']};nt={x['id']:pg.visual_profile_semantic_text(x)for x in new['profiles']};assert ot==nt
 assert pg.visual_profile_bm25f_documents(reg)==pg.visual_profile_bm25f_documents(new)
 cache=pg.load_json(A/'photo_prompt_visual_profile_index.json');kw=dict(provider=cache['provider'],model=cache['embedding_model'],dimensions=cache['embedding_dimensions']);ov=builder.reusable_vectors([A/'photo_prompt_visual_profile_index.json'],reg,**kw);nv=builder.reusable_vectors([A/'photo_prompt_visual_profile_index.json'],new,**kw);assert ov==nv
 exact_same=pg.visual_profile_exact_term_rows(reg)==pg.visual_profile_exact_term_rows(new);assert exact_same
 label=old['runtime_expression']['prompt_label_terms'][0]
 prompt='This frame shows '+label+'. '
 prompt+=' '.join(v['must_mention_any'][0]+'.'for v in old['evidence_requirements'].values())
 label_result={phase:any(au.text_contains_term(prompt,t)for t in p['runtime_expression']['prompt_label_terms'])for phase,p in [('before',old),('initial_proposed',proposed)]};assert label_result=={'before':True,'initial_proposed':False}
 for key in ['activation','semantics','concept_candidate','required_evidence_fields','evidence_requirements','reject_substitutes']:assert old[key]==proposed[key]
 assert old['render_gates'][1:]==proposed['render_gates'][1:]
 assert old['semantics']['component_semantics']['required_group_ids']==['atmospheric_horizon','auroral_arc','curtain_folds','vertical_rays']
assert hashes=={str(p):sha(p)for p in tracked}
dump('initial-proof.json',dict(verdict='HOLD_INITIAL_RUNTIME_LABEL_REPLACEMENT',legacy_horizon_label=label,legacy_horizon_label_acceptance=label_result,actual_consumer='audit_composed_prompt.py:1719 label_plus_definition uses text_contains_term over accepted labels',proposal_position_issue='Above a planetary horizon or atmospheric layer scopes above over the layer; source says upper-atmosphere occurrence and atmospheric anchoring, not mandatory emission above that layer.',composition_and_gate_or_supported=True,all_four_required_groups_and_morphology_preserved=True,activation_aliases_and_evidence_unchanged=True,visual_document_count=len(ot),all_vector_texts_BM25F_fields_unchanged=True,cached_vectors_reusable_count=len(ov),cached_vectors_equal=True,exact_lookup_unchanged=exact_same,source_hashes=hashes,provider_calls=0,source_writes=0))
print('HOLD: old horizon label accepted before and rejected by proposed runtime replacement; other target guards preserved, retrieval fields unchanged.')
