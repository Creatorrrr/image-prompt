"""Read-only independent revised aurora source/index/guard review."""
from pathlib import Path
import copy,hashlib,json,subprocess,sys
from unittest.mock import patch
sys.dont_write_bytecode=True
P=Path(__file__).resolve().parent;Q=P.parent/'remaining-structure-audit';R=P.parent.parent/'image-prompt';A=R/'skills/photo-prompt-image-generator/assets';sys.path.insert(0,str(A.parent/'scripts'))
import prompt_generator as pg
import audit_composed_prompt as au
import build_visual_profile_index as builder
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def dump(n,x):(P/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
PID='auroral_arc_curtain_atmosphere';old=read(Q/'profile-before.json');proposed=read(Q/'profile-proposed.json');dump('revised-profile-before.json',old);dump('revised-profile-proposed.json',proposed);dump('revised-exact-leaves.json',read(Q/'exact-leaves.json'))
expected=copy.deepcopy(old);expected['composition_instruction']='Include a planetary horizon or atmospheric layer and enough sky for the arc, curtain folds, and narrow rays to remain structurally distinct.';expected['render_gates'][0]['description']='A planetary horizon or atmospheric layer anchors the emission above a surface.';expected['runtime_expression']['prompt_label_terms'].append('auroral arcs and ray-filled curtains with an atmospheric anchor');assert proposed==expected
tracked=[A/'photo_prompt_visual_obligations.json',A/'photo_prompt_visual_profile_index.json',A/'photo_prompt_tags.json',Q/'profile-before.json',Q/'profile-proposed.json'];hashes={str(p):sha(p)for p in tracked}
with patch.object(pg,'embed_texts_with_gemini',side_effect=AssertionError('provider forbidden')),patch.object(builder,'embed_texts_with_gemini',side_effect=AssertionError('provider forbidden')),patch('socket.create_connection',side_effect=AssertionError('network forbidden')):
 reg=pg.load_visual_obligation_registry(A/'photo_prompt_visual_obligations.json');assert next(x for x in reg['profiles']if x['id']==PID)==old
 new=copy.deepcopy(reg);new['profiles'][next(i for i,p in enumerate(new['profiles'])if p['id']==PID)]=proposed
 assert pg.compile_visual_profile(proposed)==proposed
 ot={x['id']:pg.visual_profile_semantic_text(x)for x in reg['profiles']};nt={x['id']:pg.visual_profile_semantic_text(x)for x in new['profiles']};assert ot==nt
 assert pg.visual_profile_bm25f_documents(reg)==pg.visual_profile_bm25f_documents(new)
 cache=pg.load_json(A/'photo_prompt_visual_profile_index.json');kw=dict(provider=cache['provider'],model=cache['embedding_model'],dimensions=cache['embedding_dimensions']);ov=builder.reusable_vectors([A/'photo_prompt_visual_profile_index.json'],reg,**kw);nv=builder.reusable_vectors([A/'photo_prompt_visual_profile_index.json'],new,**kw);assert ov==nv and len(ov)==len(ot)
 ob=pg.build_visual_profile_index_payload(reg,vectors=ov,**kw);nb=pg.build_visual_profile_index_payload(new,vectors=nv,**kw)
 delta=[k for k in ob if ob[k]!=nb[k]];assert delta==['registry_sha256'];assert ob['bm25f']==nb['bm25f']and ob['entries']==nb['entries']and ob['exact_lookup']==nb['exact_lookup']
 pg.validate_visual_profile_index_metadata(nb,new,**kw)
 with patch.object(pg,'load_visual_obligation_registry',return_value=reg):c1=pg.load_json(A/'photo_prompt_tags.json')
 with patch.object(pg,'load_visual_obligation_registry',return_value=new):c2=pg.load_json(A/'photo_prompt_tags.json')
 assert c1==c2
 st1={k:pg.semantic_text_for_entry(e,s,kind=t)for k,t,e,s in pg.iter_semantic_entries(c1)};st2={k:pg.semantic_text_for_entry(e,s,kind=t)for k,t,e,s in pg.iter_semantic_entries(c2)};assert st1==st2 and pg.semantic_bm25f_documents(c1)==pg.semantic_bm25f_documents(c2)
 label_results={}
 for label in proposed['runtime_expression']['prompt_label_terms']:
  prompt='This frame shows '+label+'. '
  label_results[label]={phase:any(au.text_contains_term(prompt,t)for t in p['runtime_expression']['prompt_label_terms'])for phase,p in [('before',old),('proposed',proposed)]}
 assert all(label_results[old['runtime_expression']['prompt_label_terms'][0]].values());assert label_results[proposed['runtime_expression']['prompt_label_terms'][1]]=={'before':False,'proposed':True}
 for key in ['activation','semantics','concept_candidate','required_evidence_fields','evidence_requirements','reject_substitutes']:assert old[key]==proposed[key]
 assert old['render_gates'][1:]==proposed['render_gates'][1:]
 assert old['semantics']['component_semantics']['required_group_ids']==['atmospheric_horizon','auroral_arc','curtain_folds','vertical_rays']
 routes=[]
 for text in old['activation']['exact_terms']+['green storm clouds','a colorful nebula','city light pollution','a smooth gradient band with no rays']:
  rows=[dict(source='concept_lock',text=text,polarity='required',priority='critical',mandatory=True)]
  a=pg.candidate_pack_auto_visual_obligation_matches(reg,rows);b=pg.candidate_pack_auto_visual_obligation_matches(new,rows);assert a==b
  routes.append(dict(text=text,target_hard_before=PID in a,target_hard_proposed=PID in b))
 full=' '.join(x['any_terms'][0]for x in old['semantics']['component_semantics']['groups']);component_checks=[]
 for omit in [None]+old['semantics']['component_semantics']['required_group_ids']:
  text=' '.join(x['any_terms'][0]for x in old['semantics']['component_semantics']['groups']if x['id']!=omit)
  a=pg.candidate_pack_visual_component_match(old,text);b=pg.candidate_pack_visual_component_match(proposed,text);assert a==b;assert bool(a)==(omit is None)
  component_checks.append(dict(omitted_group=omit,before=a,proposed=b))
 hcore=read(Q/'public-cli/inputs/horizon-anchor/authorial-core.json');assert 'A dark planetary horizon visibly anchors the emission above the surface.'in hcore['source_request'];assert any('A dark planetary horizon visibly anchors'in x['prompt_evidence']for x in hcore['intent_lock']['semantic_anchors'])
 m=read(Q/'public-cli/frozen-input-manifest.json');assert all(sha(Q/'public-cli/inputs'/row['case']/f)==h for row in m for f,h in row['inputs'].items())
assert hashes=={str(p):sha(p)for p in tracked}
dump('revised-proof.json',dict(verdict='APPROVE_EXACT_REVISED_THREE_FIELD_DATA_CHANGE_PENDING_PUBLIC_QUALIFICATION',source_authorizes_horizon_or_atmospheric_anchor=True,strict_four_group_morphology_unchanged=True,all_thresholds_evidence_aliases_and_rejects_unchanged=True,legacy_runtime_label_and_new_branch_results=label_results,visual_document_count=len(ot),all_visual_vector_texts_BM25F_fields_equal=True,cached_vectors_reusable=len(ov),all_vectors_and_complete_BM25F_and_exact_lookup_equal=True,index_payload_changed_keys=delta,general_document_count=len(st1),all_general_texts_and_BM25F_equal=True,exact_route_results=routes,component_group_omission_results=component_checks,horizon_specific_activation_alias_unchanged=old['activation']['exact_terms'][1],explicit_horizon_requirement_preserved_in_frozen_core=True,frozen_input_hashes_verified=True,target_hashes=hashes,repo_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),repo_status=subprocess.check_output(['git','status','--short'],cwd=R,text=True),concurrency='Current unrelated convoy source/index integration retained. Comparison is target-specific in-memory replacement against stable current input hashes.',provider_calls=0,source_writes=0,limits=['Literal helpers do not establish true atmospheric anchoring in pixels.','Exact horizon alias and core obligation remain unchanged; actual full CLI/composition horizon controls still required.','No broadening to arc-only or morphology-free green emission.']))
print('APPROVE exact revised fields; all 1510 visual and 9739 general retrieval documents unchanged; legacy label and strict component guards preserved.')
