# Independent aurora anchor review

## Decision: APPROVE exact revised proposal; public qualification remains required

The revised proposal resolves the two blocking issues in `INITIAL-REVIEW.md`. It changes only:

1. Composition: retain enough sky for the complete arc/curtain/ray morphology, but allow a planetary horizon OR atmospheric layer
2. Gate `vo_space_aurora_horizon`: accept a planetary horizon OR atmospheric layer anchoring emission above a surface
3. Runtime labels: retain the exact old horizon label and append “auroral arcs and ray-filled curtains with an atmospheric anchor”

The initially proposed replacement label is not approved. Its complete snapshot and failing legacy-label proof remain preserved independently in this review directory, and the author separately retained superseded-v1 artifacts.

## Source supports the revised atmospheric alternative

The original `space-visual-semantics-20260901/source-research.md:78–82` requires planetary horizon/atmosphere, long arc, folded curtains and internal vertical rays. Evidence row `space_noaa_aurora_forms` explicitly authorizes a horizon OR atmospheric anchor. The current definition and exact component/evidence anchor already encode this alternative. The revision makes downstream composition/gate/label consistent with that authored scope; it introduces no new morphology or external scientific claim.

An atmospheric anchor is not generic atmospheric mood, green coloration, a featureless black background, light pollution, nebula or clouds. The revised label correctly avoids saying that emission must lie above the atmospheric layer; the unchanged evidence/gate relation anchors emission above the surface using the layer. All four simultaneous component groups remain mandatory even though the definition alone uses broader arc-or-curtain wording. This proposal does not turn the strict combined long arc, folded curtains and embedded narrow rays profile into an arc-only general aurora profile.

## Independently verified invariants

`prove_revised.py` compares the maintained target against the frozen before profile, then constructs the hypothetical revised registry in memory. Provider/network entrypoints are blocked, no source/index is written, and hashes remain stable through the proof.

- Exact three-field proposal matches the stated changes, with no additional profile edits
- Existing horizon runtime label remains accepted by the real composition-label matcher
- Added atmospheric label was unavailable before and is accepted in the proposed contract
- Activation, explicit horizon-specific alias, required evidence fields/thresholds, four component groups, rejects, and arc/curtain/ray gates remain unchanged
- Real component matcher accepts the complete four-group fixture and rejects each one-group omission identically before/proposed
- Three exact-route aliases and four ordinary near-miss requests retain identical hard-target outcomes
- The frozen horizon control's source request and intent-lock evidence explicitly require a visible dark planetary horizon; the generic OR does not revise that user-owned requirement
- All existing public input hashes verified unchanged

The explicit horizon alias remains `aurora curtains with vertical rays above horizon`. Retaining that alias is not permission to satisfy such a user's explicit horizon request with an atmosphere-only crop. The stable actual CLI/full-composition horizon control must continue to preserve its frozen visible-horizon core. Literal label/helper tests do not prove the presence of a horizon in generated pixels.

## Actual retrieval proof

All 1,510 visual-profile embedding texts and BM25F document fields are identical before/proposed. Every cached vector is reusable and unchanged. Complete visual-index entries, BM25F payload and exact lookup are identical; the sole changed payload key is `registry_sha256`. The separate general corpus's 9,739 embedding documents and BM25F fields are also identical. No fresh embeddings are indicated, but index source binding must be refreshed if the proposal is applied.

Source changes are presently concurrent: convoy's approved additions and index update were already in the current live registry. This review freezes target-specific equality and stable current source fingerprints; it does not claim a clean historical baseline or unchanged whole repository across the broader work. The author's first source-unstable CLI attempt was retained and is being rerun rather than represented as a stable baseline.

## Remaining adoption conditions

The author owns completion of stable BEFORE and eventual authorized AFTER public V6 CLI and full-composition replay. Require preserved original and revised artifacts, complete atmospheric and horizon positives, no-target near misses, all four missing-duty controls, actual legacy-label acceptance, unchanged user horizon requirements, and exact instruction-only pack differences. Do not force optional candidate exposure or claim organic recall. No image-quality or rendered atmospheric-anchor result is established by this review.

## Artifacts and reproduction

- `revised-proof.json`: complete helper/index/guard proof and source fingerprints
- `revised-profile-before.json`, `revised-profile-proposed.json`, `revised-exact-leaves.json`: independently preserved reviewed snapshots
- `initial-proof.json` and `INITIAL-REVIEW.md`: retained initial rejection
- Run `python ../daylong-progress-20261002/aurora-anchor-review/prove_revised.py` from repository root before source integration

Zero provider calls, production edits or persisted index rebuilds by this reviewer.
