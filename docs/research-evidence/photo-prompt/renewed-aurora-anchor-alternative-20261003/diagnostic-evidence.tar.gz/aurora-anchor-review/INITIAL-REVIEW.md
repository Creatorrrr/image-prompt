# Initial aurora anchor proposal: HOLD runtime-label replacement

The composition and horizon-gate OR changes are supported. The exact initial three-leaf proposal should not be applied as written because its runtime-label replacement drops legacy accepted wording and introduces an avoidable positional ambiguity.

## Supported source scope

`space-visual-semantics-20260901/source-research.md:78–82` requires planetary horizon/atmosphere, long arc, folded curtain and internal vertical rays; its NOAA summary describes occurrence in the upper atmosphere. Evidence row `space_noaa_aurora_forms` explicitly says “Reuse arc-curtain-ray morphology with a horizon or atmospheric anchor.” The current definition, atmospheric_horizon component and horizon_phrase already retain that OR. Thus atmospheric anchoring is supported without inventing a visible planetary horizon.

This does not justify generic unanchored green sky, a smooth band, a nebulous cloud, or arc-only morphology. All four required groups, evidence fields and min-content thresholds remain necessary, with the combined long arc, folded curtains and narrow rays. Existing explicit horizon-specific activation wording and user horizon obligations must remain unchanged and be tested as actual horizon scenes.

## Defect 1: lost legacy label acceptance

Initial proposal replaces the sole accepted label:

- Before: auroral arcs and ray-filled curtains above a planetary horizon
- Proposed: auroral arcs and ray-filled curtains above a planetary horizon or atmospheric layer

`audit_composed_prompt.py:1719` requires an accepted label as a literal match under `label_plus_definition`. The old horizon-only label does not contain the longer replacement. `review_initial.py` reproduced actual consumer helper acceptance: before true, proposed false. This is not merely a stylistic concern.

Retain the existing horizon label and add a supported atmospheric-anchor label. Do not force legacy horizon scenes to use an OR label merely to maintain acceptance.

## Defect 2: above-layer wording

The replacement scopes “above” over “atmospheric layer”, whereas the authored component says the layer anchors the emission above the surface. The source summary supports upper-atmosphere occurrence, not a universal emission-above-layer relation. Prefer a label expressing atmospheric anchoring, such as “auroral arcs and ray-filled curtains with an atmospheric anchor”. Keep the actual source-owned anchor duty in evidence/gate unchanged in strength.

## Proven unchanged parts

Actual builder projections for the initial proposal retain all 1,510 vector texts, BM25F document fields, cached vectors and exact lookup. Activation aliases, all four required groups, evidence thresholds and the three morphology gates remain equal. A source-binding fingerprint refresh would still be necessary after an accepted edit. This proof does not approve the initial runtime label simply because retrieval fields are unchanged.

Artifacts: `initial-proof.json`, `initial-profile-before.json`, `initial-profile-proposed.json`, `initial-exact-leaves.json`, `review_initial.py`. They preserve the initially reviewed version even if its author revises the proposal later. No source/provider/index write occurred. Current unrelated convoy integration is present in the live registry/index; target-specific equality and relevant file fingerprints were checked across this proof. This is not a clean-tree or whole-source historical-baseline claim.
