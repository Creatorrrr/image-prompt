import copy,hashlib,json,subprocess,sys,os
from pathlib import Path
sys.dont_write_bytecode=True
D=Path(__file__).resolve().parent;P=D.parent;R=P.parent.parent/'image-prompt';S=R/'skills/photo-prompt-image-generator/scripts';sys.path.insert(0,str(S));import audit_composed_prompt as ac
read=lambda p:json.loads(p.read_text())
def save(p,x):p.parent.mkdir(exist_ok=True,parents=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
E=D/'before-compositions';assert not E.exists();E.mkdir();rows=[]
for row in read(D/'frozen-input-manifest.json'):
 name=row['case'];pack=read(D/'before'/f'{name}-pack.json')[0];core=pack['authorial_core'];lock=core['intent_lock'];baseline=core['baseline_prompt_en'];pid=row['target_profile'];bindings={};prompt=baseline
 if pid:
  ob=next(x for x in pack['visual_obligations']['obligations']if x['id']==pid)
  bindings={k:v['must_mention_any'][0]+'.'for k,v in ob['evidence_requirements'].items()}
  branch='The selected spatial anchor is the faint atmospheric layer below the emission; terrain and the planetary surface horizon stay outside the crop.'if name=='atmospheric-anchor'else'The selected spatial anchor is the visible dark planetary horizon.'
  bindings['horizon_phrase']+=' '+branch
  label='auroral arcs and ray-filled curtains with an atmospheric anchor'if name=='atmospheric-anchor'else'auroral arcs and ray-filled curtains above a planetary horizon'
  prompt+=' The scene presents '+label+'. '+' '.join(bindings.values())
 composed=dict(pack_id=pack['pack_id'],composer='agent',prompt_en=prompt,negative_en=pack['negative_en'],chosen_candidate_ids=[],chosen_visual_concept_ids=[],core_retrieval_sha256=pack['core_retrieval']['canonical_sha256'],authorial_core_binding=dict(source_authorial_core_sha256=core['canonical_sha256'],source_intent_lock_sha256=lock['canonical_sha256'],preserved_anchor_ids=[a['anchor_id']for a in lock['semantic_anchors']],preserved_evidence=[],authorial_decisions=[]))
 if pid:composed['visual_obligation_evidence']={pid:bindings}
 rev=copy.deepcopy(pack['embodiment_preflight']['baseline_review']);rev.update(provenance='agent_postcomposition',prompt_sha256=hashlib.sha256(prompt.encode()).hexdigest(),summary='Source-guided synthetic environment preserves the frozen baseline and selected spatial anchor; no body or image-render judgment.')
 composed['embodiment_review']=dict(source_contract_sha256=pack['embodiment_preflight']['canonical_sha256'],review=rev)
 composed['semantic_clarification_decisions']=[dict(clarification_id=r['id'],decision='applied'if r.get('required_in_final_prompt')else'rejected',rationale='Preserve the frozen environmental core and reject optional reinterpretation.',prompt_evidence=lock['semantic_anchors'][0]['prompt_evidence'])for r in pack.get('semantic_clarification',{}).get('candidates',[])]
 composed['creative_augmentation_brief']=dict(decisions=[dict(candidate_id=r['id'],decision='rejected',rationale='The frozen source-guided environmental scene needs no optional augmentation.')for r in ac.creative_augmentation_candidates_from_pack(pack)])
 if pack.get('semantic_assertion_obligations'):composed['semantic_assertion_evidence']=dict(source_contract_sha256=pack['semantic_assertion_obligations']['canonical_sha256'],evidence={x['assertion_id']:x['evidence']for x in core['semantic_assertions']if x['polarity']=='required'})
 dest=E/(name+'-composed.json');save(dest,composed);rows.append(dict(case=name,file=dest.name,sha256=sha(dest),expected_before='fail'if name=='atmospheric-anchor'else'pass',expected_after='pass',expected_before_failure_check='visual_obligation_runtime_expression'if name=='atmospheric-anchor'else None))
# Freeze complete prompts and exact expectations before any composition audit.
save(E/'frozen-composition-manifest.json',rows)
results=[]
for row in rows:
 cmd=[sys.executable,str(S/'audit_composed_prompt.py'),'--pack',str(D/'before'/(row['case']+'-pack.json')),'--composed',str(E/row['file'])];run=subprocess.run(cmd,cwd=R,capture_output=True,text=True,env={k:v for k,v in os.environ.items()if not any(t in k.upper()for t in ['KEY','SECRET','TOKEN','CREDENTIAL'])});save(E/(row['case']+'-cli.json'),dict(command=cmd,exit_code=run.returncode,stdout=run.stdout,stderr=run.stderr));result=json.loads(run.stdout);save(E/(row['case']+'-audit.json'),result)
 checks=[f['check']for f in result['failures']];expected_checks=[row['expected_before_failure_check']]if row['expected_before_failure_check']else[]
 results.append(dict(case=row['case'],status=result['status'],expected_before=row['expected_before'],expected_after=row['expected_after'],matches=result['status']==row['expected_before']and checks==expected_checks,failures=result['failures'],warnings=result.get('warnings',[])));save(E/'summary.json',results);print(row['case'],result['status'],checks,flush=True)
assert all(x['matches']for x in results),'Preserve unexpected results, do not tune source'
assert all(sha(E/x['file'])==x['sha256']for x in rows)
