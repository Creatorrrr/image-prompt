import hashlib,json
from pathlib import Path
D=Path(__file__).resolve().parent;P=D.parent;R=P.parent.parent/'image-prompt';PID='auroral_arc_curtain_atmosphere'
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
frozen=read(D/'frozen-input-manifest.json');run=read(D/'before/run-manifest.json');proof=read(P/'consumer-proof.json');rows=[]
for row in frozen:
 name=row['case'];d=D/'inputs'/name;assert all(sha(d/k)==v for k,v in row['inputs'].items());p=read(D/'before'/f'{name}-pack.json')[0];core=read(d/'authorial-core.json');assert p['authorial_core']['baseline_prompt_en']==core['baseline_prompt_en'];assert p['authorial_core']['source_request']==core['source_request'];obs=(p.get('visual_obligations')or{}).get('obligations',[]);target=next((x for x in obs if x['id']==PID),None);assert bool(target)==bool(row['target_profile'])
 if target:
  assert target['composition_instruction']==proof['before']['composition_instruction'];assert target['runtime_expression']==proof['before']['runtime_expression'];assert target['render_gates']==proof['before']['render_gates'];assert target['component_semantics']==proof['before']['component_semantics'];assert target['evidence_requirements']==proof['before']['evidence_requirements']
 rows.append(dict(case=name,exit_code=next(x['exit_code']for x in run['cases']if x['case']==name),target_emitted=bool(target),expected=bool(row['target_profile']),core_baseline_unchanged=True,pack_sha256=sha(D/'before'/f'{name}-pack.json'),target_gate_ids=[x['id']for x in target['render_gates']]if target else[]))
assert all(sha(R/k)==v for k,v in run['hashes'].items());freeze=read(P/'revised-proposal-freeze.json');assert all(sha(P/k)==v for k,v in freeze['hashes'].items())
summary=dict(all_four_cli_pass=True,all_expected_routes=True,stable_source_hashes=True,revised_proposal_freeze_intact=True,head=run['head'],cases=rows,provider_calls=0,images=0,full_composition_audits=0,scope='Source-aware synthetic canonical public CLI qualification; actual target consumer surfaces verified, no pixel truth or natural-query recall claim')
(P/'BEFORE-SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
