Pre-retrieval authoring preflight rejected the generic sentence “Do not invent terrain or a planet boundary outside the requested view” as a blanket negative directive. Replaced it before input freezing or retrieval with “The crop ends at the stated visible boundaries.” No observed retrieval result informed this change.

Second prefreeze check rejected a literal anchor typo (complete versus entire); standardized to the existing baseline phrase entire stated luminous structure before retrieval.

Third prefreeze check rejected explicit negative-list syntax in the luminous-cloud near miss. Rephrased both near misses into positive visible geometry (uniform diffuse oval cloud; featureless black to all frame edges), preserving absence of requested morphology/anchors before retrieval.
