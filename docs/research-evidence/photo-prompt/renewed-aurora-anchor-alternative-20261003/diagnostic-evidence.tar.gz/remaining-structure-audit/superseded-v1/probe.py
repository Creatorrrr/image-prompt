import copy,hashlib,json,subprocess,sys
from pathlib import Path
sys.dont_write_bytecode=True
O=Path(__file__).resolve().parent;R=O.parent.parent/'image-prompt';S=R/'skills/photo-prompt-image-generator/scripts';A=S.parent/'assets';sys.path.insert(0,str(S));import prompt_generator as g
PID='auroral_arc_curtain_atmosphere'
def dump(n,x):(O/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def h(x):return hashlib.sha256(x).hexdigest()
def diff(a,b,p=''):
 if isinstance(a,dict)and isinstance(b,dict):return sum((diff(a.get(k),b.get(k),p+'/'+k)for k in sorted(a.keys()|b.keys())),[])
 if isinstance(a,list)and isinstance(b,list)and len(a)==len(b):return sum((diff(x,y,p+'/'+str(i))for i,(x,y)in enumerate(zip(a,b))),[])
 return []if a==b else[dict(path=p,before=a,after=b)]
reg=g.load_visual_obligation_registry(A/'photo_prompt_visual_obligations.json');p=next(x for x in reg['profiles']if x['id']==PID);q=copy.deepcopy(p)
q['composition_instruction']='Include a planetary horizon or atmospheric layer and enough sky for the arc, curtain folds, and narrow rays to remain structurally distinct.'
q['runtime_expression']['prompt_label_terms']=['auroral arcs and ray-filled curtains above a planetary horizon or atmospheric layer']
q['render_gates'][0]['description']='A planetary horizon or atmospheric layer anchors the emission above a surface.'
changes=diff(p,q);assert len(changes)==3
proposal=copy.deepcopy(reg);proposal['profiles'][next(i for i,x in enumerate(reg['profiles'])if x['id']==PID)]=q
before=g.candidate_pack_visual_profile_obligation(p,reg,activation_source='explicit_user_requirement',source_intent_ids=[]);after=g.candidate_pack_visual_profile_obligation(q,proposal,activation_source='explicit_user_requirement',source_intent_ids=[]);assert diff(before,after)==changes
sources=R/'docs/research-evidence/photo-prompt/space-visual-semantics-20260901/evidence.jsonl';e=next(json.loads(l)for l in sources.read_text().splitlines()if json.loads(l)['id']=='space_noaa_aurora_forms');assert e['reuse_note']=='Reuse arc-curtain-ray morphology with a horizon or atmospheric anchor.'
routes={}
for label,text in [('exact_en',p['activation']['exact_terms'][0]),('horizon_specific_alias',p['activation']['exact_terms'][1]),('exact_ko',p['activation']['exact_terms'][2]),('cloud','a luminous green cloud without folded sheets or narrow vertical rays'),('nebula','a colorful nebula in interstellar space'),('missing_anchors','one long luminous arc folded into ray-filled curtains against featureless black space')]:
 rows=[dict(source='concept_lock',text=text,polarity='required',priority='critical',mandatory=True)];a=sorted(g.candidate_pack_auto_visual_obligation_matches(reg,rows));b=sorted(g.candidate_pack_auto_visual_obligation_matches(proposal,rows));assert a==b;assert (PID in a)==(label in ['exact_en','horizon_specific_alias','exact_ko']);routes[label]=dict(text=text,before=a,proposed=b)
oldtext=g.visual_profile_semantic_text(p);newtext=g.visual_profile_semantic_text(q)
dump('exact-leaves.json',changes);dump('profile-before.json',p);dump('profile-proposed.json',q);dump('source-provenance.json',dict(evidence=e,source_document='docs/research-evidence/photo-prompt/space-visual-semantics-20260901/source-research.md:78-82',definition=p['semantics']['definition'],component=p['semantics']['component_semantics']['groups'][0],evidence_requirement=p['evidence_requirements']['horizon_phrase'],original_source_fetched_in_this_audit=False,original_evidence_file_sha256=h(sources.read_bytes())))
dump('consumer-proof.json',dict(before=before,proposed=after,materialized_deltas=diff(before,after),routes=routes,semantic_text_before_sha256=h(oldtext.encode()),semantic_text_after_sha256=h(newtext.encode()),semantic_text_identical=oldtext==newtext,bm25f_identical=g.visual_profile_bm25f_fields(p)==g.visual_profile_bm25f_fields(q),registry_hash_changed=g.visual_profile_registry_sha256(reg)!=g.visual_profile_registry_sha256(proposal),exact_lookup_identical=g.visual_profile_exact_term_rows(reg)==g.visual_profile_exact_term_rows(proposal),semantic_text_before=oldtext,semantic_text_proposed=newtext))
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();status=subprocess.check_output(['git','status','--short'],cwd=R,text=True);raw=json.loads((A/'photo_prompt_visual_obligations.json').read_text());old=json.loads(subprocess.check_output(['git','show','HEAD:skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations.json'],cwd=R));rawdiff=diff(old,raw);dump('source-state.json',dict(head=head,status=status,preexisting_asset_deltas=rawdiff,hashes={str(f.relative_to(R)):h(f.read_bytes())for f in [A/'photo_prompt_visual_obligations.json',A/'photo_prompt_visual_profile_index.json',S/'prompt_generator.py',S/'visual_profile_contracts.py']},target_profile_sha256=h(json.dumps(p,sort_keys=True).encode())))
ids=['karst_closed_depression_losing_stream_resurgence','aeolian_dune_stoss_crest_slipface_transport','einstein_ring_lens_alignment','spacecraft_docking_capture_alignment','planetary_rover_surface_operation','pf_drawbridge','pf_arrow_loop','pf_orangery','opening_hybrid_veranda_architecture','opening_rail_platform_departure']
checks=[]
for id in ids:
 row=next(x for x in reg['profiles']if x['id']==id);mat=g.candidate_pack_visual_profile_obligation(row,reg,activation_source='read_only_audit',source_intent_ids=[]);checks.append(dict(id=id,profile=row,materialized=mat,gate_count=len(mat['render_gates'])))
dump('keep-review-consumers.json',checks)
print('PASS: three exact leaves survive production materializer; routes identical; semantic text identical:',oldtext==newtext)
