# Remaining structural alternatives: read-only audit

## Narrow proposal: preserve the authored auroral atmospheric-anchor alternative

Profile: `auroral_arc_curtain_atmosphere`.

The existing general definition permits emission above a planetary horizon **or atmospheric context**. The mandatory atmospheric component and `horizon_phrase` canonical binding both say `a planetary horizon or atmospheric layer anchors the emission above the surface`. Crucially, the original approved research-evidence record `space_noaa_aurora_forms` independently states: “Reuse arc-curtain-ray morphology with a horizon or atmospheric anchor.” This is a specific authored alternative, not a proposal inferred from general physics.

Three consumer surfaces drop that alternative: general composition, runtime prompt label, and the first required render gate. A gate-only change would be incomplete. The coherent minimum proposed patch restores the same already-authored alternative to those three leaves:

1. Composition: “Include a planetary horizon or atmospheric layer and enough sky for the arc, curtain folds, and narrow rays to remain structurally distinct.”
2. Gate `vo_space_aurora_horizon`: “A planetary horizon or atmospheric layer anchors the emission above a surface.”
3. Runtime label: “auroral arcs and ray-filled curtains above a planetary horizon or atmospheric layer”

`exact-leaves.json` retains before and proposed text. No production change is applied. There is no proposed change to component groups, canonical evidence, minimum counts, gate identities, other gate descriptions, strict combined arc/curtain/ray morphology, exact activation, rejection boundaries, candidate membership or routing policy. The explicitly horizon-specific exact alias and illustrative horizon paraphrases are preserved: an expressly requested horizon is still binding through the requester’s core.

## Actual consumer and index impact

`probe.py` uses the production registry loader, compiler/materializer, hard route matcher, semantic prototype builder, BM25F field builder and exact lookup builder. In-memory proposed data is passed to the same materializer. Assertions establish:

- Exactly three source leaves and exactly those same three materialized leaves differ
- All three exact routes remain active; cloud, nebula and missing-anchor near misses remain inactive, unchanged between current and proposed copies
- Positive embedding text is byte-identical, as are BM25F fields and exact lookup
- Registry hash changes

Thus a future authorized integration needs a genuine registry-bound index metadata refresh with unchanged vectors and BM25F, **not a new embedding request**. No provider call is made here. These are actual consumer tests, not an image-render success claim.

## Four frozen public CLI BEFORE cases

`public-cli/frozen-input-manifest.json` freezes four source-guided canonical fixtures before retrieval, with seed 1003, neutral creative controls, candidate-free authored cores, no-body reviews, and explicit request-bound `environment` subject assertions:

- Atmospheric-anchor positive: broad exact aurora alias, complete arc/curtain/ray morphology, atmospheric layer below the emission, terrain and planetary surface horizon outside the crop
- Existing horizon positive: same strict morphology, visible planetary horizon
- Luminous cloud near miss: a smooth diffuse green cloud above a horizon, lacking the distinctive morphology
- Both anchors absent near miss: arc/curtain/ray-like ribbon against featureless black to all frame boundaries, no planet-relative context and no exact profile alias

Near misses deliberately omit the exact alias; nonactivation does not establish that an explicitly activated profile can omit required duties. All optional candidates remain unselected because this stage measures materialized public packs, not final authored compositions.

Raw CLI commands, stdout/stderr, full packs, source hashes and route observations are retained. This BEFORE suite demonstrates current stricter consumer text reaching actual emitted packs. It does not pretend the image-review gate has been physically evaluated or that text audits enforce pixel truth. No full-composition audit or rendered image is claimed. Inputs use required wire enums but are openly synthetic source-aware diagnostics, not organic requests or independent clean pre-core authoring.

`preflight-note.md` records all corrections rejected before retrieval/input freezing. They are authoring-validation fixes, not post-retrieval tuning.

## Other inspected profiles: KEEP without forced edits

Full compiled profiles and actual materialized consumers are retained in `keep-review-consumers.json` for ten other profiles:

- Karst and aeolian dune: already-reviewed natural-environment neighbors, included only as scope boundaries. Existing canonical alternatives remain; no new proposal
- Einstein ring: thin ring or matched arcs is retained in definition, evidence and gate. KEEP
- Docking: definition distinguishes soft capture/hard mating, while capture binding lists guides/latches/seals/contact indicators and gate mentions guide/latch hardware. This is a possible state/visibility distinction, but this audit does not establish an independently supported complete contact-indicator-only scene that the gate wrongly excludes. KEEP pending stronger source-state proof; do not broaden capture into mere indication or approach
- Rover: measured target appears among canonical result choices, while the gate asks for physical trace or collected result. The original source includes measurement results but does not by itself settle how a still image must visibly establish a fresh measurement. KEEP; do not erase the result-evidence duty or treat an inactive instrument portrait as completed operation
- Drawbridge, arrow loop, orangery: explicitly selected architectural variants with authored scope limitations, not universal architectural definitions. KEEP their narrower structures
- Hybrid veranda and historical rail-platform scene: connected architectural/transport scenes retain their authored conjunctions. No exact alternative-loss proof; KEEP

The aurora definition also says arcs “or” folded curtains, but the original source’s required list, component contract, all evidence and three morphology gates deliberately require the combined arc/curtain/ray instance. This audit does **not** propose weakening those duties.

No general English-disjunction expansion is proposed. A canonical literal containing an OR can still require that exact combined phrase in current lexical auditing; this is a known binding limitation and is not widened here.

## Original source authority and limits

Original research record: `docs/research-evidence/photo-prompt/space-visual-semantics-20260901/evidence.jsonl`, record `space_noaa_aurora_forms`; original source prose lines 78–82. The record points to https://www.swpc.noaa.gov/sites/default/files/images/u2/Aurora.pdf and limits reuse by viewing geometry/emission variation and rejection of generic green skies. This audit inspected and froze the existing repository record; it did not re-fetch the external NOAA document or independently validate auroral physics.

Proposed repair authority is the original authored reuse note plus the existing definition/component/evidence agreement. Existing horizon examples are narrower illustrations rather than an explicit reversal of the atmospheric-anchor alternative. An independent reviewer should assess that interpretation before integration.

## Concurrent ghost correction and repository safety

The audit began on `2c4e06ea9ea5f98f8d82c115a6ee354d5d180766`, with a separately owned pending ghost correction and derived index already present. The only pre-existing primary-registry delta was profile index 245’s gate adding `spectral translucency` alongside absence/displacement. `source-state.json` preserves the exact delta and working tree status. No ghost or convoy work was duplicated. This auditor wrote only outside the repository in its audit-artifact directory and made no provider call, production edit, dependency change, commit or publication.

## Handoff

Independent review should consume the complete three-leaf patch, source provenance, full before/proposed profile snapshots, exact materialized proof, and four frozen public CLI fixtures. If accepted for later integration, refresh only registry binding and prove other index content identical, run the unchanged fixtures AFTER with a separate runner, and retain all full-pack membership/order differences. Stop if any positive meaning or unrelated field unexpectedly changes. No source/index change is authorized by this report itself.
