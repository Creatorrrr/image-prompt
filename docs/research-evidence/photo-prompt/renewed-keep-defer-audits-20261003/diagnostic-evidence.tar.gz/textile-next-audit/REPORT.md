# Textile/material next-pass audit — KEEP

## Result

No high-confidence new candidate/profile data contradiction established. No repository edits, runtime edits, paid calls, fabricated vectors, or relaxed safety boundaries. This is a **source-internal consistency** audit, not independent textile-science certification.

## Scope and actual consumer

Inspected the original authored JSON, not generated semantic/profile indices: all 38 profiles in `photo_prompt_visual_obligations_textile_surface.json` with their matching candidate rows in `photo_prompt_textile_surface_extension.json`; four Y2K profiles/candidate variants (`y2kr_stretch_denim`, `y2kr_satin`, `y2kr_mesh_top`, `y2kr_mesh_dress`); the generic sheer optical-layering profile; and the satin directional-luster profile. Captured exact source files and SHA-256 hashes.

`probe.py` materializes the 44 profiles through the real `prompt_generator.candidate_pack_visual_profile_obligation`, including authored-component compilation, then calls `validate_visual_intent_binding` on each authored evidence alternative and an unrelated negative. Output includes full original profiles, source candidates, materialized obligations and measured controls. There are 69 raw anchor tests: 64 pass directly. Five satin-directional anchors need same-component elaboration to meet the separately authored minimum content-word counts, as explicitly explained by the validator. Those are not textile contradictions and are not recommended for weakening. All 53 unrelated negatives fail.

## Keeps and reasons

1. **Fiber versus surface/weave:** `clothing_ct078_v2` explicitly selects a matte linen-*look* slub variant, not a claim that all linen is matte or slubbed. `clothing_ct085_v1` selects satin-*like* broad highlights, while `clothing_ct085_v2` separately specifies visible float yarns. `y2kr_satin` explicitly rejects inferring silk fiber from sheen. These are internally aligned; no reason to turn appearance into fiber authentication or broaden the deliberate variants.

2. **Transparency versus layering:** `clothing_ct079_v1` explicitly names a separate lining in both candidate and profile; `ct079_v2` explicitly names an opaque panel concealing the lower layer. `y2kr_mesh_dress` explicitly selects an overlay above a separate dress with independent edges. Adding/removing layers would change their authored concepts. Meanwhile the generic `sheer_garment_optical_layering` already preserves the requested body/lower garment/background owner and has passing evidence alternatives for all three; its opaque-lining examples are not the only permitted realization. No remaining universal opaque-lining requirement was found.

3. **Material behavior versus silhouette:** `y2kr_stretch_denim` and its garment-detail counterpart already author the *fitted garment* in the original candidate sentence, concept unit and embedding text, consistently with the profile. Its claim limit explicitly disallows establishing elastane percentage or stretch performance from a photograph. This could be a consciously narrow taxonomy choice, but changing it to a loose/unfitted generic stretch-denim definition would broaden the authored concept without demonstrated contradiction. `y2kr_satin` likewise expressly selects a soft-drape visible variant rather than defining all satin. KEEP.

4. **Crisp versus fluid panels:** `clothing_ct091_v1` selects a crisp sheer panel holding angular folds; `ct091_v2` independently selects a soft translucent panel falling in fluid folds. They are alternatives, and the shared family property is not an all-of obligation. KEEP both, without collapsing them into a universal chiffon/organza/taffeta behavior.

5. **Owner-specific satin luster:** `satin_directional_luster_drape_surface` explicitly requires the luster on a garment throughout candidate/profile/components/gates; background drapery is deliberately a confusion negative. This is not a defect in a generic surface material row and should not be widened to furniture/backgrounds.

## Limits

These tests establish compiled binding behavior and source scope, not generated-image quality or semantic-retrieval ranking. They do not claim universal textile facts. No uncertain physical-textile claim is material to the KEEP decision, so no external factual lookup was needed. Already-repaired basic material slots, wet hair, kebaya cloth, wrap-skirt side and reflection-receiver issues were not reopened.
