import sys,json,hashlib,subprocess
from pathlib import Path
sys.dont_write_bytecode=True
O=Path(__file__).resolve().parent
R=O.parent.parent/'image-prompt'; A=R/'skills/photo-prompt-image-generator/assets'
sys.path.insert(0,str(A.parent/'scripts'))
import prompt_generator as pg
save=lambda n,v:(O/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
files=['photo_prompt_visual_obligations_textile_surface.json','photo_prompt_textile_surface_extension.json','photo_prompt_visual_obligations_y2k.json','photo_prompt_y2k_extension.json','photo_prompt_visual_obligations.json','photo_prompt_visual_obligations_reactorprompt.json']
manifest={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'files':{f:hashlib.sha256((A/f).read_bytes()).hexdigest() for f in files},'provider_calls':0,'factual_basis':'source-internal consistency only; no external textile generalization used'}
raw=json.loads((A/'photo_prompt_visual_obligations.json').read_text()); profiles=[]
for file,ids in [('photo_prompt_visual_obligations_textile_surface.json',None),('photo_prompt_visual_obligations_y2k.json',{'y2kr_stretch_denim','y2kr_satin','y2kr_mesh_top','y2kr_mesh_dress'}),('photo_prompt_visual_obligations.json',{'sheer_garment_optical_layering'}),('photo_prompt_visual_obligations_reactorprompt.json',{'satin_directional_luster_drape_surface'})]:
 for p in json.loads((A/file).read_text())['profiles']:
  if ids is None or p['id'] in ids:profiles.append((file,p))
rows=[]; obligations={}
for file,p in profiles:
 ob=pg.candidate_pack_visual_profile_obligation(p,raw,activation_source='explicit_user_requirement',source_intent_ids=[]); obligations[p['id']]=ob
 for field,req in ob['evidence_requirements'].items():
  for phrase in req.get('must_mention_any',[]):
   try:pg.validate_visual_intent_binding(obligation_index=0,field=field,phrase=phrase,requirement=req);result='pass'
   except ValueError as e:result=str(e)
   rows.append({'profile':p['id'],'source':file,'field':field,'phrase':phrase,'result':result,'kind':'authored_alternative'})
  phrase='the surrounding scene appears ordinary and softly illuminated'
  try:pg.validate_visual_intent_binding(obligation_index=0,field=field,phrase=phrase,requirement=req);result='pass'
  except ValueError as e:result=str(e)
  rows.append({'profile':p['id'],'field':field,'phrase':phrase,'result':result,'kind':'unrelated_negative'})
selected_rows=[]
for file in ['photo_prompt_textile_surface_extension.json','photo_prompt_y2k_extension.json']:
 for slot,entries in json.loads((A/file).read_text())['slots'].items():
  for row in entries:
   if file.endswith('textile_surface_extension.json') or row['id'] in ['y2kr_stretch_denim','y2kr_stretch_denim_garment','y2kr_satin','y2kr_satin_garment','y2kr_mesh_top','y2kr_mesh_dress']:selected_rows.append({'file':file,'slot':slot,'entry':row})
summary={'profile_count':len(profiles),'authored_alternatives_tested':sum(r['kind']=='authored_alternative' for r in rows),'authored_alternative_failures':[r for r in rows if r['kind']=='authored_alternative' and r['result']!='pass'],'unrelated_negatives_tested':sum(r['kind']=='unrelated_negative' for r in rows),'unrelated_negative_false_passes':[r for r in rows if r['kind']=='unrelated_negative' and r['result']=='pass']}
save('source-manifest.json',manifest);save('source-profiles.json',[{'file':f,'profile':p} for f,p in profiles]);save('source-candidates.json',selected_rows);save('materialized-obligations.json',obligations);save('consumer-controls.json',rows);save('summary.json',summary)
print(json.dumps(summary,indent=2))
