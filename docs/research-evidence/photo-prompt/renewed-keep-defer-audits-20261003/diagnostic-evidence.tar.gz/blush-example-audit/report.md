# Blush example DATA audit

## Decision
Final recommendation after independent controls: **DEFER implementation and paid refresh**. If future data hygiene justifies an index refresh, deleting only `cheekbone_temple_blush_drape.semantics.paraphrase_examples[2]` remains preferable to rewriting it. Do not mechanically strip its negative clause, relax exclusions, change four-group requirements, or implement the complete rewrite evaluated here. No repository edit or paid API was performed. Base HEAD confirmed as `4f992caf` (dress correction).

This is dead/incomplete authored-example cleanup, not a newly demonstrated runtime recall improvement. If the acceptance criterion requires a recovered same-query false negative rather than removal of misleading dead data, defer the change instead of claiming that criterion was met.

## Authored provenance
- Introduction found with `git log -S`: commit `401f450e`, `skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations.json`.
- Original research at that commit: `docs/research-evidence/photo-prompt/korean-emotional-photo-semantics-20260902/source-research.md`, line 60. It explicitly defines bilateral high-cheek origin, continuous upward/outward path to both temples, tapered temple ends, and separation from contour/anatomical shading/colored light. This is local authored provenance, not a fresh external-source fact check.
- Original profile definition and component groups encode the same relation. The third paraphrase, “soft tapered edges preserve a blush path instead of a hard contour stripe or lighting gradient,” lacks origin, bilateral placement and temple destination/direction.
- Main already includes `904b5893`, replacing the self-excluding English confound-group term and its evidence with “bilateral cosmetic pigment remains continuous from high cheekbones toward temples with soft tapered edges and a recognizable blush hue.” Thus full English component evidence is already repaired.

## Actual fallback, scope and guards
`prompt_generator.py:7096-7164` (`candidate_pack_visual_component_match`) rejects any matching exclusion first. It next checks minimum four groups and all four required IDs. If that fails, *any entire authored paraphrase substring* can return `semantic_paraphrase_example`, regardless of number of groups matched. The flag `semantic_discovery_requires_component_evidence` does not override that fallback in this function. The caller `candidate_pack_auto_visual_concept_matches` records it as indirect optional eligibility; this does not by itself hard-activate a visual obligation or certify render success.

The two retained authored paraphrases independently match the fallback with zero literal component-group matches. They are relation-level examples, not verbatim full four-group evidence: English includes both cheeks, continuous color and temple thinning; Korean includes bilateral high cheeks, temples and upward/outward pigment path but does not explicitly spell out tapered edges/confound separation. Do not overstate their completeness. Full four-group English and Korean bundles remain separately available and return `component_semantics`.

Exclusions remain `cheekbone anatomy`, `face-lifting claim`, `cast shadow`, `colored lighting`, `contour stripe`. Contrast examples and render gates retain anatomy, contour, light, and apple-blush boundaries. They are not all equivalent lexical exclusions: an apple-only contradiction appended to a complete recognized positive can require interpretation downstream; this audit does not claim universal negation or contradiction understanding.

## Alternatives compared
1. Mechanical trim to “soft tapered edges preserve a blush path”: reject. It newly accepts an incomplete zero-group fragment. This was a diagnostic anti-example, not a proposed fix.
2. Complete positive replacement: source-consistent, frozen in `frozen-proposal.json` before local probes (SHA-256 in adjacent file). However, it newly accepts a new exact paraphrase sentence through zero-group fallback; it does not make the original third-example query eligible. No missing domain concept requires this additional phrase, given the retained relation examples and repaired full bundles. Keep it unimplemented rather than treating new acceptance of our newly authored sentence as recovered coverage.
3. Delete example[2]: preferred minimal cleanup. The original exact phrase contains “contour stripe”, so every text containing that phrase is rejected before fallback, both before and after deletion. Removing it cannot add a lexical optional match, and cannot remove an existing lexical match through this function. This follows from the code ordering, not merely sample tests. Remaining examples satisfy validator's nonempty/distinct requirement (`validate_photo_prompt_dictionary.py:1734-1756`), which sets no minimum of three. No requirement found that every original example must be retained.
4. Defer: appropriate if a nontrivial behavioral improvement is required or independent review judges retrieval disturbance unjustified for dead-example cleanup.

## Diagnostics and limits
`probe.py` is rerunnable, local, read-only to the repository, and makes no API calls. `probe-results.json` records 21 authored-source diagnostic cases across baseline, complete rewrite, deletion and unsafe mechanical trim. These are canonical/source-guided probes, **not independent controls**.

Results:
- Both retained examples: identical optional fallback across variants
- Original incomplete third example: rejected across variants
- Both language full bundles: identical four-group match across variants
- Four isolated component phrases: rejected across safe variants
- Five authored contrast examples: rejected across all variants
- Complete rewrite plus each of five exclusions: rejected across all variants
- Only the complete-rewrite variant accepts the newly authored full sentence
- Only unsafe mechanical trim accepts the edge-only fragment

The profile's retrieval document includes paraphrase examples (`photo_visual_retrieval.py`), so deletion changes semantic-index input. Lexical invariance is not a promise of identical embedding nearest neighbors, semantic retrieval recall/rank, generated prompts, or pixels. Any accepted implementation must follow the repository's index regeneration/validation contract; no paid regeneration is authorized in this audit. Independent controls should be authored without tuning the proposed data and should test realistic full positive descriptions, apple-only blush, lighting/contour/anatomy substitutes, unilateral/incomplete paths, plus existing exact routes. Report lexical and semantic-retrieval outcomes separately.

## Frozen final scope
`frozen-deletion-proposal.json` records the final one-field deletion proposal for independent review. The earlier full-rewrite proposal remains intact as an evaluated alternative; it was not tuned after probes. No independent-review PASS or production qualification is claimed.


## Independent controls and real-index trial (completed after proposal freeze)
A separate worker authored ten controls without inspecting the edit or matcher: three complete natural positives, five adjacent negatives, and two makeup/light owner controls. These are in `independent-controls.json`, distinct from the canonical probes. `real_index_probe.py` compared the actual registry-bound production baseline index against an in-memory deletion registry and freshly built lexical-only index. No reused/generated vectors, query-vector calls, or embedding retrieval were used.

Six canonical cases plus ten blind controls were tested (16 total). All preserve profile-ID sets and applicability/hard/optional flags. Fifteen preserve order. Only the old excluded sentence changes ordering:
- `hogarth_waving_line_of_beauty`: rank 1 → 2 (BM25F 66.613171948574 → 66.612268154043)
- `cr_spatial_gradient`: rank 2 → 1 (66.595424358928 → 66.954237164605)
- Remaining six hit IDs retain order. Blush is absent before and after.

This rank swap does not demonstrate inappropriate new exposure or worsening semantic relevance: the query explicitly mentions a lighting gradient. Corpus-statistic score changes do occur, so claiming unchanged rankings would be false. The full hit outputs and file binding hashes are preserved in `real-index-proof.json`; the compact comparison is in `rank-membership-comparison.json`.

The two retained examples, both complete EN/KO bundles, and the exact Korean route stay stable. All blind controls are also stable. However, blush is absent for all three independent positive descriptions and the makeup-owner positive both before and after deletion. Those are existing natural-language lexical retrieval misses, not a new regression and not evidence that the profile is semantically wrong. The embedding lane was not exercised, so no claim about total production semantic recall is supported.

Final adjudication: no demonstrated coverage/recall gain, no new exposure, one global lexical rank swap. Deletion is plausible hygiene but does not justify a paid refresh or claims of successful corrective behavior. Preserve the trial as **deferred**, and separately investigate naturally phrased positive recall if it becomes in scope. Do not replace deletion with the complete sentence simply to pass an authored query. Public BEFORE envelope generation was not performed because the requested full rank-stability condition did not hold and the trial has been deferred. Existing real bound BEFORE diagnostics are retained.
