import copy,hashlib,json,subprocess,sys
from pathlib import Path
O=Path(__file__).resolve().parent;R=Path('REPOSITORY_ROOT');S=R/'skills/photo-prompt-image-generator'
sys.path.insert(0,str(S/'scripts'))
import prompt_generator as pg
proposal=json.loads((O/'frozen-deletion-proposal.json').read_text())
reg=pg.load_visual_obligation_registry(S/'assets/photo_prompt_visual_obligations.json');index=pg.load_visual_profile_index(S/'assets/photo_prompt_visual_profile_index.json',reg)
pid=proposal['profile_id'];p=next(x for x in reg['profiles'] if x['id']==pid);assert p['semantics']['paraphrase_examples'][2]==proposal['before']
newreg=copy.deepcopy(reg);pn=next(x for x in newreg['profiles'] if x['id']==pid);pn['semantics']['paraphrase_examples'].pop(2);newindex=pg.build_visual_profile_index_payload(newreg)
controls=json.loads((O/'independent-controls.json').read_text());controls=controls.get('cases',controls) if isinstance(controls,dict) else controls
cases=[dict(id='old_authored',text=proposal['before']),*[dict(id=f'retained_example_{i}',text=t) for i,t in enumerate(pn['semantics']['paraphrase_examples'])],*[dict(id=f'full_bundle_{lang}',text='; '.join(g['any_terms'][lang] for g in p['semantics']['component_semantics']['groups'])) for lang in range(2)],dict(id='exact_route',text='드레이핑 블러셔'),*controls]
results=[]
for case in cases:
 name=case.get('id',case.get('name'));text=case['text'];rows=[dict(source='concept_lock',text=text,polarity='required'),dict(source='authorial_core_baseline',text=text,polarity='advisory')];fields=dict(active_request=[text],baseline_prompt=[text]);variants=[]
 for label,r,i,profile in [('actual_bound_baseline',reg,index,p),('proposed_lexical_diagnostic',newreg,newindex,pn)]:
  result=pg.resolve_visual_profile_hits(r,rows,visual_profile_index=i,query_fields=fields,adult_context=True)
  variants.append(dict(lane=label,target_hits=[h for h in result['hits'] if h['profile_id']==pid],resolution=result,applicability=pg.visual_profile_context_applicability(profile,text,has_authorial_core_context=True),component_match=pg.candidate_pack_visual_component_match(profile,text)))
 identity=lambda v:[(i+1,h['profile_id'],h['match_basis'],h['applicability_status'],h['hard_eligible'],h['optional_eligible']) for i,h in enumerate(v['resolution']['hits'])]
 same=identity(variants[0])==identity(variants[1]);results.append(dict(name=name,source_case=case,source_rows=rows,query_fields=fields,variants=variants,ordered_membership_ranks_flags_equal=same))
 print(name,same,[[(h['profile_id'],h['match_basis'],h['optional_eligible']) for h in v['target_hits']] for v in variants],flush=True)
manifest=dict(head=subprocess.check_output(['git','-C',str(R),'rev-parse','HEAD'],text=True).strip(),status=subprocess.check_output(['git','-C',str(R),'status','--short'],text=True),source_hashes={str(f.relative_to(R)):hashlib.sha256(f.read_bytes()).hexdigest() for f in [S/'assets/photo_prompt_visual_obligations.json',S/'assets/photo_prompt_visual_profile_index.json',S/'scripts/prompt_generator.py']},proposed_index_mode='Fresh production lexical-only index; no reused or generated vectors; no embedding lane exercised; not registry-bound production embedding qualification')
(O/'real-index-proof.json').write_text(json.dumps(dict(manifest=manifest,proposal=proposal,cases=results),ensure_ascii=False,indent=2)+'\n')
