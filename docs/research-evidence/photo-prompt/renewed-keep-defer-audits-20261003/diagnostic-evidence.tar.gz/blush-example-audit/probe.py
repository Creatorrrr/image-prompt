"""Read-only authored-source diagnostics; not independent qualification controls."""
import copy, hashlib, json, pathlib, sys
ROOT=pathlib.Path('REPOSITORY_ROOT')
OUT=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'skills/photo-prompt-image-generator/scripts'))
import prompt_generator as pg
p=json.loads((OUT/'baseline-profile.json').read_text())
proposal=json.loads((OUT/'frozen-proposal.json').read_text())
variants={'baseline':p}
rewrite=copy.deepcopy(p);rewrite['semantics']['paraphrase_examples'][2]=proposal['after'];variants['complete_rewrite']=rewrite
drop=copy.deepcopy(p);drop['semantics']['paraphrase_examples'].pop(2);variants['drop_incomplete_example']=drop
mechanical=copy.deepcopy(p);mechanical['semantics']['paraphrase_examples'][2]='soft tapered edges preserve a blush path';variants['UNSAFE_mechanical_trim']=mechanical
cases={f'authored_example_{i}':v for i,v in enumerate(p['semantics']['paraphrase_examples'])}
cases['frozen_complete_rewrite']=proposal['after']
cases['unsafe_trim_fragment']=mechanical['semantics']['paraphrase_examples'][2]
groups=p['semantics']['component_semantics']['groups']
for lang in range(2):cases[f'authored_full_bundle_{lang}']='; '.join(g['any_terms'][lang] for g in groups)
for g in groups:cases[g['id']]=g['any_terms'][0]
for i,t in enumerate(p['semantics']['contrast_examples']):cases[f'authored_contrast_{i}']=t
for i,t in enumerate(p['activation']['exclude_if_any_terms']):cases[f'rewrite_plus_exclusion_{i}']=proposal['after']+'; '+t
rows=[]
for name,text in cases.items():
 rows.append({'case':name,'text':text,'matched_baseline_groups':[g['id'] for g in groups if any(pg.intent_alias_matches(text,t) for t in g['any_terms'])],'results':{n:pg.candidate_pack_visual_component_match(v,text) for n,v in variants.items()}})
result={'classification':'canonical/source-guided diagnostics only; independent controls required','base_commit':proposal['base_commit'],'proposal_sha256':hashlib.sha256((OUT/'frozen-proposal.json').read_bytes()).hexdigest(),'cases':rows}
(OUT/'probe-results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
for row in rows:print(row['case'],row['results'])
