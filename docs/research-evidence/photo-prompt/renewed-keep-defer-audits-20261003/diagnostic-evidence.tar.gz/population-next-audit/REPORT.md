# Population/contact follow-on DATA audit

## Result

**Keep-only: zero leaf proposals.** At initial inspection the repository was clean at `c37e21f6`. This audit made no repository/source edits, paid calls, retrieval calls, or generated images. It wrote evidence only to this sibling audit directory. A final `git status` showed a concurrent change to the main visual-obligations registry; that change is not this audit's work.

## Method and consumer evidence

Compiled all 1,496 profiles using the production `compile_visual_profile` implementation. A lexical triage found 108 composition instructions mentioning hand/hands/person/human/wearer/fingers; this is not a count of defects. Reviewed six full profiles against source/candidate scope, including activation, definition, evidence requirements, render gates, and authored components. Files retain all six complete raw and compiled profiles, plus the full lexical screen.

Called the production `prompt_generator.candidate_pack_visual_profile_obligation` for all six without request-context specialization. `production-materialized-obligations.json` preserves the results. This function calls `compile_visual_profile`, copies the resulting composition instruction, materializes required evidence fields and render gates, and retains the authored relation. This demonstrates what a selected profile emits; it does **not** demonstrate natural-query activation or generated-pixel quality. No new activation claim is made.

## Detailed keeps

### `pr_instant_print_material_object`: keep authored hand-held instance

The candidate's English summary is broadly phrased as a complete physical card with supported contact, which initially suggests a tabletop alternative. The full research source resolves it: `docs/research-evidence/photo-prompt/photorealism-elements-20260923/visual-proposals.json` explicitly requires a card held in a hand and gives the expression “A complete instant print is held by one corner … casting a narrow shadow on the hand.” Current authored component 2 (“card thickness edges and hand support are visible”) accurately preserves that selected instance. The candidate lives in `photo_prompt_photorealism_elements_extension.json`, prop slot, owner “즉석 인화 카드 전체”; its concept units and embedding text also contain hand support. `requires_adult_character: false` does not itself prove a no-human contract. Broadening to tabletop support would change the selected manifestation, not repair a demonstrated collapsed source alternative. A distinct photo-era tabletop print relation exists; it is not proof this narrower leaf must cover it.

### `mep_product_hero`: keep human-model candidate scope

The label “product hero image” looks object-capable in isolation. The actual candidate in `photo_prompt_model_editorial_extension.json` is tagged human/adult/fashion/portrait, restricted by `for_any: [human]`, and scoped to human/portrait/fashion/beauty/commercial primary tags. The profile requires an adult character and exact activation includes supporting human gestures. Source `model-editorial-professional-20260912/report.md` explicitly bounds this research to fashion, portrait, and brand shooting. Therefore removing the human-gesture component is not a justified general product-photo fix. Retrieval into an incompatible still-life would require a separate runtime/candidate-scope diagnosis, not mutation of the selected relation.

### `rb_shared_cast_shadow`: keep selected person-plus-post example

Current full exact term, definition, authored components, and gates expressly bind one person's ground-contact shadow and a nearby post's shadow to one pavement. Source `realistic-background-20260912/visual-proposals.json` requires the person's shadow connection and supplies the person/bollard example. The profile's own claim limit says concrete objects are a selected manifestation, never defaults for a broad realism request. Generalizing person into object would replace an intentional leaf and conflate it with broader light/shadow relations. The production obligation preserves all three owners; this is source-consistent.

### `wearable_protective_armor_system`: keep current bounded worn-system evidence

Full definition, component groups, and candidate concepts consistently concern human-scale wearable geometry, articulated human joints, underlayers, fit, and load distribution. The gate reads “armor worn by a human-scale body,” and attachment evidence connects armor to the wearer. There is no documented stand-only/display-only alternative in this leaf to recover. Bare exact labels such as “plate armor” do not establish that every armor use should be covered by this profile. A display request would need separate scope evidence; no relaxation proposed.

### `revolver_chambered_cylinder_system`: keep; weaker wording is not enough

The definition and all five required evidence fields are object morphology. Composition says hands avoid covering the cylinder boundary; the contact gate prohibits a presenting hand from hiding or merging into the cylinder/trigger area. This is a visibility/non-occlusion constraint, rather than an affirmative requirement that a hand contact be shown. The 2026-09-01 weapon report explicitly says existing hand/object ownership applies “when a person is shown interacting with the object.” Unlike the previously repaired weapon leaves, this full profile does not require a holding hand among its literal evidence fields. No proven no-person rejection or source alternative collapse is established. Earlier prop-contact and object-action audits also retained this weaker case. Rewriting it merely for stylistic consistency would exceed the high-confidence threshold.

### `ground_mortar_tube_bipod_baseplate_system`: keep explicit optional hands

Composition already says “any examining hands.” All required fields and five gates concern the tube, ground-contacting baseplate, connected bipod, sight/adjustment hardware, and confound control. Ground contact is object support, not human contact. This is already consistent with the same 2026-09-01 weapon source and object-only depiction.

## Boundaries and stopping condition

Did not re-propose corrected rapier/compound-bow/halberd/crossbow, light/leading-line, wet-hair, glacier/wetland/dune/cumulonimbus, wrap-skirt, or kebaya work. Instrument still-life, component-query matching, and owner matching remain outside this DATA audit. No phrase exceptions or runtime changes were authored. Stop here: available evidence supports retaining the inspected leaves, not filling the loop with a new patch.
