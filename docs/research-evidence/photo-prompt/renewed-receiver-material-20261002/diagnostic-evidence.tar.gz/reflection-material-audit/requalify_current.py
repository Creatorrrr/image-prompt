import json,hashlib,subprocess,sys,os,shutil
from pathlib import Path
O=Path(__file__).parent;LIVE=Path('REPOSITORY_ROOT');R=O/'current-corpus-snapshot';P=O/'public-cli';D=P/'current-corpus-before';D.mkdir(exist_ok=True);R.mkdir(exist_ok=True)
assert not (D/'run-manifest.json').exists(),'preserve existing evidence'
relfiles=['skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations.json','skills/photo-prompt-image-generator/assets/photo_prompt_visual_profile_index.json','skills/photo-prompt-image-generator/scripts/generate_photo_prompt.py','skills/photo-prompt-image-generator/scripts/prompt_generator.py']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
meta={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=LIVE,text=True).strip(),'status':subprocess.check_output(['git','status','--short'],cwd=LIVE,text=True),'hashes':{f:sha(LIVE/f) for f in relfiles},'execution':'normal public CLI on frozen actual current corpus; existing real index; unchanged immutable inputs; no synthetic vectors or paid calls','cases':[]}
shutil.copytree(LIVE/'skills',R/'skills',dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__'))
for f,h in meta['hashes'].items():assert sha(R/f)==h
sys.path.insert(0,str(R/'skills/photo-prompt-image-generator/scripts'));import prompt_generator as pg
A=R/'skills/photo-prompt-image-generator/assets';reg=pg.load_visual_obligation_registry(A/'photo_prompt_visual_obligations.json');pg.load_visual_profile_index(A/'photo_prompt_visual_profile_index.json',reg)
meta['profile_count']=len(reg['profiles']);assert meta['profile_count']==1496
old=json.loads((O/'baseline-snapshot/skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations.json').read_text());op={p['id']:p for p in old['profiles']}
meta['target_source_unchanged']={p['id']:p==op[p['id']] for p in json.loads((A/'photo_prompt_visual_obligations.json').read_text())['profiles'] if p['id'] in ['hard_light_shadow_edge_relation','soft_light_shadow_edge_relation']};assert all(meta['target_source_unchanged'].values())
(D/'run-manifest.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n')
manifest=json.loads((P/'frozen-input-manifest.json').read_text())
for c in manifest:
 case=c['case'];I=P/'inputs'/case
 for n,h in c['inputs'].items():assert sha(I/n)==h
 cmd=[sys.executable,str(R/'skills/photo-prompt-image-generator/scripts/generate_photo_prompt.py'),'--seed',str(c['seed'])]
 for a in ['request-envelope','authorial-core','creative-controls','embodiment-review']:cmd+=['--'+a+'-json',str(I/(a+'.json'))]
 cmd+=['--output-file',str(D/(case+'-pack.json'))]
 p=subprocess.run(cmd,cwd=R,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},capture_output=True,text=True,timeout=600)
 (D/(case+'.stdout')).write_text(p.stdout);(D/(case+'.stderr')).write_text(p.stderr)
 row={'case':case,'command':cmd,'exit_code':p.returncode,'target_profile':c['target_profile']}
 if p.returncode==0:
  pack=json.loads((D/(case+'-pack.json')).read_text())[0];obs=(pack.get('visual_obligations') or {}).get('obligations',[])
  row['obligation_ids']=[o['id'] for o in obs];row['target_obligation']=next((o for o in obs if o['id']==c['target_profile']),None);row['pack_sha256']=sha(D/(case+'-pack.json'))
 meta['cases'].append(row);(D/'run-manifest.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n');print(case,p.returncode,row.get('obligation_ids'),flush=True)
 if p.returncode:print(p.stderr,flush=True)
assert all(c['exit_code']==0 for c in meta['cases'])
