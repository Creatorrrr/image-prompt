import json,sys
from pathlib import Path
O=Path(__file__).parent;S=O/'baseline-snapshot/skills/photo-prompt-image-generator';sys.path.insert(0,str(S/'scripts'))
import prompt_generator as pg
import audit_composed_prompt as ac
reg=pg.load_visual_obligation_registry(S/'assets/photo_prompt_visual_obligations.json');proposals=json.loads((O/'proposed-profiles.json').read_text());results=[]
for p in proposals:
 pid=p['id'];o=pg.candidate_pack_visual_profile_obligation(p,reg,activation_source='explicit_request_semantics',source_intent_ids=['diagnostic'])
 c={'enabled':True,'contract_version':pg.VISUAL_OBLIGATIONS_CONTRACT_VERSION,'strict_gate_set':True,'obligations':[o],'required_hard_gates':[g['id'] for g in o['render_gates']]}
 for ix,label in [(0,'legacy-glossy'),(1,'diffuse-en'),(2,'diffuse-ko')]:
  ev={f:r['must_mention_any'][0] for f,r in o['evidence_requirements'].items()};ev[pid+'_component_4_phrase']=o['evidence_requirements'][pid+'_component_4_phrase']['must_mention_any'][ix]
  if ix==2: ev[pid+'_component_4_phrase'] += '; the matte receiver preserves its diffuse material appearance'
  failures=ac.audit_visual_obligations({'visual_obligations':c},{'visual_obligation_evidence':{pid:ev}},'. '.join(ev.values()))
  assert not failures,(pid,label,failures)
  groups=p['semantics']['component_semantics']['groups'];terms=[g['any_terms'][0] for g in groups];terms[3]=groups[3]['any_terms'][ix]
  assert pg.candidate_pack_visual_component_match(p,'; '.join(terms))=='component_semantics'
  for field in ev:
   omitted={k:v for k,v in ev.items() if k!=field}
   assert ac.audit_visual_obligations({'visual_obligations':c},{'visual_obligation_evidence':{pid:omitted}},'. '.join(omitted.values()))
  results.append({'profile':pid,'variant':label,'composed_audit_failures':failures,'all_components_match':True,'every_missing_evidence_field_rejected':True})
(O/'proposal-static-validation.json').write_text(json.dumps({'scope':'in-memory proposed profile materialization and evidence audit only; not an index or public-CLI AFTER claim','results':results},ensure_ascii=False,indent=2)+'\n');print('Six proposal variants passed evidence and missing-evidence checks')
