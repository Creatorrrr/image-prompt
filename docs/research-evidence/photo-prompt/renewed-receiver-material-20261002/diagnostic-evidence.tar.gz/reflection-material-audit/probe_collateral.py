import json,sys,hashlib
from pathlib import Path
O=Path(__file__).parent;phase=sys.argv[1];S=O/({'before':'current-corpus-snapshot','after':'after-reviewed-snapshot'}[phase])/'skills/photo-prompt-image-generator';sys.path.insert(0,str(S/'scripts'))
import prompt_generator as pg
I=O/'public-cli/inputs/matte-soft';out=O/'collateral-risk';out.mkdir(exist_ok=True)
env=pg.load_request_envelope_arg(str(I/'request-envelope.json'));ctl=json.loads((I/'creative-controls.json').read_text());core=pg.load_authorial_core_arg(str(I/'authorial-core.json'),request_envelope=env,creative_control_snapshot=ctl);emb=json.loads((I/'embodiment-review.json').read_text())
d=pg.load_runtime_data();r=pg.prepare_candidate_source(d,core,ctl,emb,seed=706);trace=r['semantic_trace'];sources=pg.candidate_pack_visual_obligation_request_sources(r,trace)
resolution=pg.candidate_pack_resolve_visual_profiles(d,r,trace,None)
reg=d[pg.VISUAL_OBLIGATIONS_DATA_KEY];idx=d[pg.VISUAL_PROFILE_INDEX_DATA_KEY];profiles={p['id']:p for p in reg['profiles']}
context=' '.join(str(row.get('text') or '') for row in sources if row.get('polarity')!='excluded');hascore=any(str(row.get('source','')).startswith('authorial_core_') for row in sources)
allowed={pid for pid,p in profiles.items() if pg.visual_profile_context_applicability(p,context,has_authorial_core_context=hascore,require_positive_context_terms=False)[0] and (p['activation'].get('semantic_discovery_requires_component_evidence') is not True or pg.candidate_pack_visual_component_match(p,context) is not None)}
blocked={h['profile_id'] for h in resolution['hits'] if h['match_basis']=='exact'}
fields=pg.authorial_core_bm25f_query_fields(core);ranked=pg.rank_bm25f(idx['bm25f'],fields,limit=1496,allowed_ids=allowed,blocked_ids=blocked)
ids=['y2kr_velour','rb_support_compression'];details={}
for pid in ids:
 p=profiles[pid];hit=next((h for h in resolution['hits'] if h['profile_id']==pid),None);rank=next((i+1 for i,r in enumerate(ranked) if r['document_id']==pid),None)
 details[pid]={'activation':p['activation'],'definition':p['semantics']['definition'],'component_match':pg.candidate_pack_visual_component_match(p,context),'semantically_applicable':pid in allowed,'rank':rank,'rank_row':ranked[rank-1] if rank else None,'actual_resolver_hit':hit,'adult_required':p['activation'].get('requires_adult_character'),'advisory_context_eligible':not p['activation'].get('requires_adult_character') or resolution['adult_context'],'hard_eligible':hit.get('hard_eligible',False) if hit else False,'profile_sha256':hashlib.sha256(json.dumps(p,sort_keys=True).encode()).hexdigest(),'bm25_document':idx['bm25f']['documents'][pid]}
report={'phase':phase,'query_fields':fields,'source_rows':sources,'request':core['source_request'],'baseline':core['baseline_prompt_en'],'embodiment':emb,'resolution':resolution,'retrieval_policy':idx['retrieval_policy'],'bm25_policy':idx['bm25f']['policy'],'details':details,'complete_eligible_ranking':ranked,'bm25_corpus_statistics':{k:idx['bm25f'][k] for k in ['document_count','average_field_lengths','document_frequencies']}}
(out/(phase+'-rank-proof.json')).write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'phase':phase,'resolution':{k:v for k,v in resolution.items() if k!='hits'},'details':{p:{k:v for k,v in x.items() if k not in ['bm25_document','activation','definition']} for p,x in details.items()}},ensure_ascii=False,indent=2))
