# Minimal material-owner proposal

## Scope and status

Proposal only, no repository modifications or paid calls. The current source/index snapshot was frozen with parent confirmation that the capture refresh was ready. The exact HEAD, working-tree state, and SHA256s are in `before-source-manifest.json`. This is the OLD 333-profile corpus, before upstream 840d4b8f integration. Public BEFORE must be requalified against the merged corpus before applying or claiming final validation.

## Proposed leaves

`minimal-field-proposal.json` records exactly six changed leaves for each of `hard_light_shadow_edge_relation` and `soft_light_shadow_edge_relation`:

1. Definition replaces mandatory specular response with material-appropriate response
2. Component 4 match terms add English and Korean diffuse-receiver alternatives, preserving the existing glossy term
3. Concept term 4 describes receiver-dependent response
4. Composition preserves all five relations but explains that existing matte receivers satisfy the surface-response relation without adding gloss or objects
5. Component 4 evidence anchors add the same English/Korean alternatives, preserving the old glossy evidence anchor at index 0
6. Gate 4 evaluates existing receiver response; specular behavior is conditional on material/viewing geometry

`proposed-profiles.json` contains complete source profiles; `compiled-profiles.json` contains their production `compile_visual_profile` output. These profiles currently use legacy directly-authored fields, so no new authored-component mechanism is introduced. IDs, number of gates, review scales, field names, minimum word thresholds, activation, exclusions, and all other shadow/shape/exposure obligations remain identical.

Hard-light gate explicitly avoids treating compact highlights as universal independent of roughness. Soft-light gate still judges a broad reflection when a compatible glossy receiver exists. Both retain the object's requested morphology and material.

## Frozen public CLI cases

`independent-authored-scenes.json` records eight independently written still-life scenes. `public-cli/inputs/` contains their immutable user request envelopes, frozen authorial cores, controls, and not-applicable embodiment reviews. `public-cli/frozen-input-manifest.json` hashes every input.

- matte-hard / matte-soft: dry plaster pear and matte paper, English exact relation requests
- matte-hard-ko / matte-soft-ko: equivalent Korean exact relation requests
- glossy-hard / glossy-soft: glazed ceramic subtype with original compatible highlight geometry
- generic-en / generic-ko: ordinary room-light requests without hard/soft exact relation labels

The normal public CLI runs in `baseline-snapshot`, copied from the real working tree with the genuine matching index. No synthetic vectors/index, mock loader, alternate private pack constructor, or paid provider is used for these CLI runs. Commands, exits and obligations are recorded in `public-cli/before/run-manifest.json`; full packs and stdout/stderr are retained.

## Proposal-only consumer validation

`proposal-static-validation.json` verifies legacy glossy, diffuse-English, and bilingual diffuse evidence against the current materializer and composed-obligation audit for both proposed profiles. The old glossy anchor still passes. Every omitted evidence field fails. Korean discovery terms are checked without requiring an English term; the bilingual prompt-evidence test includes English descriptive content to respect the existing English content-word floor. Pure Korean evidence was rejected by that pre-existing floor and is not claimed to pass. No threshold or runtime change is proposed.

An initial missing-component probe was unsuitable because the production helper accepts some unchanged whole-paraphrase matches before component counting; no claim is made that it rejects all incomplete prose. The required-field audit is the applicable mandatory-contract check here.

## Primary grounding and limits

PBRT §9.2.1 models matte receivers as diffuse; §9.2.2 separates glossy reflectivity and roughness-dependent highlight size: https://www.pbr-book.org/3ed-2018/Materials/Material_Interface_and_Implementations

broncolor distinguishes source hardness by relative size/distance and shadow transitions, not by compulsory receiver gloss: https://broncolor.swiss/news/hard-soft-and-diffused-light-what-is-the-difference

These support changing material-response ownership while retaining the existing lighting geometry. The proposal does not broaden artistic style or demand another object to fill a checklist. It has no actual refreshed index and makes no public CLI AFTER or pixel-quality claim. Following merged-corpus review, actual semantic-vector refresh and normal public AFTER are required if approved.
