import json
from pathlib import Path
O=Path(__file__).parent;C=O/'after-vs-current-corpus-before';s=json.loads((C/'summary.json').read_text());lines=['# Reviewed receiver-material public AFTER','', 'Primary baseline: exact 1496-profile current-corpus BEFORE. The earlier 333-profile baseline is retained separately under `after-vs-before` for provenance only.', '', 'All eight normal public CLI runs exited 0. Original immutable inputs were hash-verified, frozen authorial cores remain identical, applied target profiles exactly match the reviewed records, and the actual index passed the production registry-binding loader.', '', '## Candidate and pack changes','']
for c in s['cases']:
 case=c['case'];d=json.loads((C/(case+'-candidate-differences.json')).read_text());full=json.loads((C/(case+'-full-pack-differences.json')).read_text())
 lines.append(f"- {case}: {c['changed_candidate_collections']} changed candidate collections; {c['added_candidates']} added, {c['removed_candidates']} removed, {c['changed_candidate_records']} changed common records; {len(full)} full-pack changed paths")
 for coll in d['changed_candidate_collections']:
  lines.append('  - '+coll['path']+': added '+str([r['id'] for r in coll.get('added',[])])+', removed '+str([r['id'] for r in coll.get('removed',[])])+', changed '+str([r['id'] for r in coll.get('changed',[])]))
 lines += ['','Changed full-pack paths: '+', '.join('`'+x['path']+'`' for x in full),'']
lines += ['## Evidence inventory','', '- `public-cli/after-reviewed`: actual final packs, stdout/stderr, commands, source/index fingerprints, output hashes and exact reviewed-source equality', '- `after-vs-current-corpus-before`: complete candidate ID/order/count inventory for every collection, complete changed records, and exhaustive whole-pack path differences', '- `after-vs-before`: old corpus provenance comparison; do not attribute its corpus effects to this repair', '', 'No repository edits, paid calls or image generation were performed by this replay. Evidence/full-composition review is owned by the independent reviewer and must be reported at its actual scope.']
(O/'PUBLIC-AFTER-RESULT.md').write_text('\n'.join(lines)+'\n')
print('\n'.join(lines))
