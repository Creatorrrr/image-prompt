import json,sys,hashlib
from pathlib import Path
ROOT=Path('REPOSITORY_ROOT'); A=ROOT/'skills/photo-prompt-image-generator/assets'
sys.path.insert(0,str(A.parent/'scripts'))
import prompt_generator as pg
import audit_composed_prompt as ac
reg=pg.load_visual_obligation_registry(A/'photo_prompt_visual_obligations.json')
idx=pg.load_visual_profile_index(A/'photo_prompt_visual_profile_index.json',reg)
profiles={p['id']:p for p in reg['profiles']}
report={'registry_sha256':hashlib.sha256((A/'photo_prompt_visual_obligations.json').read_bytes()).hexdigest(),'index_sha256':hashlib.sha256((A/'photo_prompt_visual_profile_index.json').read_bytes()).hexdigest(),'cases':[]}
for pid,label in [('hard_light_shadow_edge_relation','crisp cast-shadow geometry'),('soft_light_shadow_edge_relation','large-source soft wrap relation')]:
 request=f'Photograph unglazed chalk-white plaster on matte paper with {label}. Preserve the dry diffuse material response.'
 result={'provenance':{'concept_lock':[request]}}
 sources=pg.candidate_pack_visual_obligation_request_sources(result,{})
 resolution=pg.resolve_visual_profile_hits(reg,sources,visual_profile_index=idx,adult_context=False)
 contract=pg.candidate_pack_visual_obligations({pg.VISUAL_OBLIGATIONS_DATA_KEY:reg},result,{},None,visual_profile_resolution=resolution)
 assert contract and [o['id'] for o in contract['obligations']]==[pid]
 obligation=contract['obligations'][0]
 evidence={f:r['must_mention_any'][0] for f,r in obligation['evidence_requirements'].items()}
 baseline_prompt='. '.join(evidence.values())
 baseline_failures=ac.audit_visual_obligations({'visual_obligations':contract},{'visual_obligation_evidence':{pid:evidence}},baseline_prompt)
 field=pid+'_component_4_phrase'
 evidence[field]='The dry plaster and matte paper retain diffuse brightness variation with no visible specular hotspot'
 prompt='. '.join(evidence.values())
 failures=ac.audit_visual_obligations({'visual_obligations':contract},{'visual_obligation_evidence':{pid:evidence}},prompt)
 report['cases'].append({'profile_id':pid,'request':request,'exact_hits':[h for h in resolution['hits'] if h['match_basis']=='exact'],'contract':contract,'baseline_failures':baseline_failures,'material_correct_evidence':evidence,'material_correct_failures':failures})
assert all(not c['baseline_failures'] for c in report['cases'])
assert all(len(c['material_correct_failures'])==1 and c['material_correct_failures'][0]['field'].endswith('component_4_phrase') for c in report['cases'])
out=Path(__file__).parent/'consumer-proof.json';out.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'actual_index_loaded':True,'cases':[{'id':c['profile_id'],'hard_eligible':c['exact_hits'][0]['hard_eligible'],'hard_gates':len(c['contract']['required_hard_gates']),'baseline_failures':c['baseline_failures'],'material_correct_failures':c['material_correct_failures']} for c in report['cases']]},indent=2))
