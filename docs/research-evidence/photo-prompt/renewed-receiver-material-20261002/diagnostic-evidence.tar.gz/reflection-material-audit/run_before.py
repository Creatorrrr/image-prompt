import json,hashlib,subprocess,sys,os
from pathlib import Path
O=Path(__file__).parent;R=O/'baseline-snapshot';P=O/'public-cli';D=P/'before';D.mkdir(exist_ok=True)
manifest=json.loads((P/'frozen-input-manifest.json').read_text());meta={'baseline_source_manifest':json.loads((O/'before-source-manifest.json').read_text()),'qualification':'OLD CORPUS frozen before upstream 840d4b8f integration; requires requalification after merge','execution':'normal public CLI, real index, no fake vectors or paid provider','cases':[]}
for c in manifest:
 case=c['case'];I=P/'inputs'/case
 for n,h in c['inputs'].items():assert hashlib.sha256((I/n).read_bytes()).hexdigest()==h
 cmd=[sys.executable,str(R/'skills/photo-prompt-image-generator/scripts/generate_photo_prompt.py'),'--seed',str(c['seed'])]
 for a in ['request-envelope','authorial-core','creative-controls','embodiment-review']:cmd+=['--'+a+'-json',str(I/(a+'.json'))]
 cmd+=['--output-file',str(D/(case+'-pack.json'))]
 p=subprocess.run(cmd,cwd=R,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},capture_output=True,text=True,timeout=240)
 (D/(case+'.stdout')).write_text(p.stdout);(D/(case+'.stderr')).write_text(p.stderr)
 row={'case':case,'command':cmd,'exit_code':p.returncode,'target_profile':c['target_profile']}
 if p.returncode==0:
  pack=json.loads((D/(case+'-pack.json')).read_text())[0];obs=(pack.get('visual_obligations') or {}).get('obligations',[])
  row['obligation_ids']=[o['id'] for o in obs];row['target_obligation']=next((o for o in obs if o['id']==c['target_profile']),None)
 meta['cases'].append(row);(D/'run-manifest.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n');print(case,p.returncode,row.get('obligation_ids'),flush=True)
 if p.returncode:print(p.stderr,flush=True)
assert all(c['exit_code']==0 for c in meta['cases'])
