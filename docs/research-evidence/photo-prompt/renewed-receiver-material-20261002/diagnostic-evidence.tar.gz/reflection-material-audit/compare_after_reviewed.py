import json,hashlib,sys
from pathlib import Path
O=Path(__file__).parent;P=O/'public-cli';D=P/'after-reviewed';baseline=sys.argv[1] if len(sys.argv)>1 else 'current-corpus-before';out=O/('after-vs-'+baseline);out.mkdir(exist_ok=True)
manifest=json.loads((P/'frozen-input-manifest.json').read_text());run=json.loads((D/'run-manifest.json').read_text());assert len(run['cases'])==8 and all(c['exit_code']==0 for c in run['cases'])
def collections(v,path=''):
 found={}
 if isinstance(v,dict):
  for k,w in v.items():
   q=path+'/'+k
   if isinstance(w,list) and ('candidate' in k or ('candidate' in path and all(isinstance(r,dict) and 'id' in r for r in w))):found[q]=w
   else:found.update(collections(w,q))
 elif isinstance(v,list):
  for i,w in enumerate(v):found.update(collections(w,path+'/'+str(i)))
 return found
def delta(a,b,path=''):
 if type(a)!=type(b):return [{'path':path,'before':a,'after':b}]
 if isinstance(a,dict):
  changes=[]
  for k in sorted(set(a)|set(b)):
   q=path+'/'+k
   if k not in a:changes.append({'path':q,'added':b[k]})
   elif k not in b:changes.append({'path':q,'removed':a[k]})
   else:changes+=delta(a[k],b[k],q)
  return changes
 if isinstance(a,list):return [] if a==b else [{'path':path,'before':a,'after':b}]
 return [] if a==b else [{'path':path,'before':a,'after':b}]
summaries=[]
for c in manifest:
 case=c['case'];a=json.loads((P/baseline/(case+'-pack.json')).read_text())[0];b=json.loads((D/(case+'-pack.json')).read_text())[0]
 for n,h in c['inputs'].items():assert hashlib.sha256((P/'inputs'/case/n).read_bytes()).hexdigest()==h
 assert a['authorial_core']==b['authorial_core'],case
 ca,cb=collections(a),collections(b);changes=[]
 for path in sorted(set(ca)|set(cb)):
  aa,bb=ca.get(path,[]),cb.get(path,[])
  if aa==bb:continue
  if all(isinstance(r,dict) and 'id' in r for r in aa+bb):
   ma={r['id']:r for r in aa};mb={r['id']:r for r in bb}
   change={'path':path,'old_order':[r['id'] for r in aa],'current_order':[r['id'] for r in bb],'added':[r for r in bb if r['id'] not in ma],'removed':[r for r in aa if r['id'] not in mb],'changed':[{'id':i,'leaves':delta(ma[i],mb[i])} for i in ma.keys()&mb.keys() if ma[i]!=mb[i]]}
  else:change={'path':path,'before':aa,'after':bb}
  changes.append(change)
 gate_equal=a.get('visual_obligations')==b.get('visual_obligations')
 res={'case':case,'qualification':'reviewed lighting AFTER versus '+baseline,'target_profile':c['target_profile'],'full_visual_obligations_equal':gate_equal,'old_obligation_ids':[o['id'] for o in (a.get('visual_obligations') or {}).get('obligations',[])],'current_obligation_ids':[o['id'] for o in (b.get('visual_obligations') or {}).get('obligations',[])],'changed_candidate_collections':changes,'candidate_collection_inventory':{path:{'before_count':len(ca.get(path,[])),'after_count':len(cb.get(path,[])),'before_ids_or_values':[r.get('id',r) if isinstance(r,dict) else r for r in ca.get(path,[])],'after_ids_or_values':[r.get('id',r) if isinstance(r,dict) else r for r in cb.get(path,[])]} for path in sorted(set(ca)|set(cb))}}
 (out/(case+'-candidate-differences.json')).write_text(json.dumps(res,ensure_ascii=False,indent=2)+'\n')
 # Preserve all noncandidate/full-pack changes separately to make comparison exhaustive.
 (out/(case+'-full-pack-differences.json')).write_text(json.dumps(delta(a,b),ensure_ascii=False,indent=2)+'\n')
 summaries.append({k:v for k,v in res.items() if k not in ['changed_candidate_collections','candidate_collection_inventory']}|{'changed_candidate_collections':len(changes),'added_candidates':sum(len(v.get('added',[])) for v in changes),'removed_candidates':sum(len(v.get('removed',[])) for v in changes),'changed_candidate_records':sum(len(v.get('changed',[])) for v in changes)})
assert all(s['full_visual_obligations_equal'] for s in summaries if s['target_profile'] is None)
(out/'summary.json').write_text(json.dumps({'source_manifest':run,'cases':summaries},ensure_ascii=False,indent=2)+'\n');print(json.dumps(summaries,indent=2))
