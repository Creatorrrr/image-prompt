import json,copy,sys,hashlib
from pathlib import Path
O=Path(__file__).parent;S=O/'baseline-snapshot/skills/photo-prompt-image-generator';sys.path.insert(0,str(S/'scripts'))
import prompt_generator as pg
raw=json.loads((S/'assets/photo_prompt_visual_obligations.json').read_text());P={p['id']:p for p in raw['profiles']};out=[];deltas={}
for kind in ['hard','soft']:
 pid=kind+'_light_shadow_edge_relation';p=copy.deepcopy(P[pid]);sem=p['semantics']
 if kind=='hard':
  sem['definition']=sem['definition'].replace('and localized specular response','and material-appropriate surface response')
  en='matte receivers retain diffuse shading while any visible specular response follows the same source and surface roughness'
  ko='무광 수광면은 확산 음영을 유지하고 보이는 정반사 응답은 같은 광원과 표면 거칠기를 따름'
  desc='Matte receivers retain diffuse shading; any visible specular highlights remain source-owned and compatible with receiver roughness and viewing geometry. A glossy surface or compact highlight is not required.'
 else:
  sem['definition']=sem['definition'].replace('broad specular response','material-appropriate surface response')
  en='matte receivers retain diffuse modeling while any visible glossy reflection follows the extended source and receiver geometry'
  ko='무광 수광면은 확산 명암을 유지하고 보이는 광택 반사는 넓은 광원과 수광면 기하를 따름'
  desc='Matte receivers retain diffuse modeling; any visible glossy reflection remains compatible with the extended source and receiver geometry. A glossy surface or visible reflection is not required.'
 group=sem['component_semantics']['groups'][3];group['any_terms'] += [en,ko]
 p['concept_candidate']['concept_terms'][3]=en
 p['composition_instruction']=p['composition_instruction'].replace('and localized specular response','and material-appropriate surface response').replace('broad specular response','material-appropriate surface response')+' Preserve the requested material: diffuse response on matte receivers satisfies the surface-response relation; evaluate specular response only where material and viewing geometry support it, without adding gloss or another object.'
 p['evidence_requirements'][pid+'_component_4_phrase']['must_mention_any'] += [en,ko]
 p['render_gates'][3]['description']=desc
 out.append(p)
 def diff(a,b,path=''):
  if type(a)!=type(b):return [{'path':path,'before':a,'after':b}]
  if isinstance(a,dict):return sum([diff(a[k],b[k],path+'/'+k) for k in a],[])
  if isinstance(a,list):
   if len(a)!=len(b):return [{'path':path,'before':a,'after':b}]
   return sum([diff(x,y,path+'/'+str(i)) for i,(x,y) in enumerate(zip(a,b))],[])
  return [] if a==b else [{'path':path,'before':a,'after':b}]
 deltas[pid]=diff(P[pid],p)
compiled=[pg.compile_visual_profile(p) for p in out]
for p in out:
 old=P[p['id']];assert p['activation']==old['activation'];assert p['required_evidence_fields']==old['required_evidence_fields'];assert p['reject_substitutes']==old['reject_substitutes'];assert len(p['render_gates'])==5
 assert p['evidence_requirements'][p['id']+'_component_4_phrase']['must_mention_any'][0]==old['evidence_requirements'][p['id']+'_component_4_phrase']['must_mention_any'][0]
for name,obj in [('proposed-profiles.json',out),('compiled-profiles.json',compiled),('minimal-field-proposal.json',{'status':'proposal_only_no_repo_changes','source_fingerprint':hashlib.sha256((S/'assets/photo_prompt_visual_obligations.json').read_bytes()).hexdigest(),'profiles':deltas})]:
 (O/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print({k:len(v) for k,v in deltas.items()})
