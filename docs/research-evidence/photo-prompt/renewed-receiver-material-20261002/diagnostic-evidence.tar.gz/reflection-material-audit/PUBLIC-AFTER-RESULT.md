# Reviewed receiver-material public AFTER

Primary baseline: exact 1496-profile current-corpus BEFORE. The earlier 333-profile baseline is retained separately under `after-vs-before` for provenance only.

All eight normal public CLI runs exited 0. Original immutable inputs were hash-verified, frozen authorial cores remain identical, applied target profiles exactly match the reviewed records, and the actual index passed the production registry-binding loader.

## Candidate and pack changes

- matte-hard: 1 changed candidate collections; 0 added, 0 removed, 1 changed common records; 3 full-pack changed paths
  - /semantic_clarification/candidates: added [], removed [], changed ['clarification:visual-profile:hard_light_shadow_edge_relation']

Changed full-pack paths: `/pack_id`, `/semantic_clarification/candidates`, `/visual_obligations/obligations`

- matte-soft: 2 changed candidate collections; 2 added, 2 removed, 1 changed common records; 4 full-pack changed paths
  - /semantic_clarification/candidates: added ['clarification:visual-profile:rb_support_compression'], removed ['clarification:visual-profile:y2kr_velour'], changed ['clarification:visual-profile:soft_light_shadow_edge_relation']
  - /visual_concept_candidates/candidates: added ['visual-concept:rb_support_compression'], removed ['visual-concept:y2kr_velour'], changed []

Changed full-pack paths: `/pack_id`, `/semantic_clarification/candidates`, `/visual_concept_candidates/candidates`, `/visual_obligations/obligations`

- matte-hard-ko: 1 changed candidate collections; 0 added, 0 removed, 1 changed common records; 3 full-pack changed paths
  - /semantic_clarification/candidates: added [], removed [], changed ['clarification:visual-profile:hard_light_shadow_edge_relation']

Changed full-pack paths: `/pack_id`, `/semantic_clarification/candidates`, `/visual_obligations/obligations`

- matte-soft-ko: 1 changed candidate collections; 0 added, 0 removed, 1 changed common records; 3 full-pack changed paths
  - /semantic_clarification/candidates: added [], removed [], changed ['clarification:visual-profile:soft_light_shadow_edge_relation']

Changed full-pack paths: `/pack_id`, `/semantic_clarification/candidates`, `/visual_obligations/obligations`

- glossy-hard: 1 changed candidate collections; 0 added, 0 removed, 1 changed common records; 3 full-pack changed paths
  - /semantic_clarification/candidates: added [], removed [], changed ['clarification:visual-profile:hard_light_shadow_edge_relation']

Changed full-pack paths: `/pack_id`, `/semantic_clarification/candidates`, `/visual_obligations/obligations`

- glossy-soft: 1 changed candidate collections; 0 added, 0 removed, 1 changed common records; 3 full-pack changed paths
  - /semantic_clarification/candidates: added [], removed [], changed ['clarification:visual-profile:soft_light_shadow_edge_relation']

Changed full-pack paths: `/pack_id`, `/semantic_clarification/candidates`, `/visual_obligations/obligations`

- generic-en: 0 changed candidate collections; 0 added, 0 removed, 0 changed common records; 0 full-pack changed paths

Changed full-pack paths: 

- generic-ko: 0 changed candidate collections; 0 added, 0 removed, 0 changed common records; 0 full-pack changed paths

Changed full-pack paths: 

## Evidence inventory

- `public-cli/after-reviewed`: actual final packs, stdout/stderr, commands, source/index fingerprints, output hashes and exact reviewed-source equality
- `after-vs-current-corpus-before`: complete candidate ID/order/count inventory for every collection, complete changed records, and exhaustive whole-pack path differences
- `after-vs-before`: old corpus provenance comparison; do not attribute its corpus effects to this repair

No repository edits, paid calls or image generation were performed by this replay. Evidence/full-composition review is owned by the independent reviewer and must be reported at its actual scope.
