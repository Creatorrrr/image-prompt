# Reflection/material ownership scout

## Result: one shared mandatory-physics defect, affecting two profiles

`hard_light_shadow_edge_relation` and `soft_light_shadow_edge_relation` conflate source angular size/shadow softness with a mandatory glossy receiving material. A matte plaster/paper still life can satisfy either lighting geometry without a visible specular hotspot. The hard profile nevertheless requires compact specular highlights; the soft profile requires broad specular response on compatible glossy surfaces. Neither provides a diffuse-material evidence alternative. The soft phrase's word "compatible" does not make the requirement conditional: its field and render gate remain mandatory, and composition says all five observable relations must coexist.

### Current consumer proof

Run `python EVIDENCE_ROOT/reflection-material-audit/reproduce.py`.

The script loads the full current registry and its actual hash-bound index through the production loader. It creates request-only source rows, calls the current hybrid resolver without any query vectors, projects the resolution through `candidate_pack_visual_obligations`, and executes `audit_visual_obligations`. No fake index, vectors, monkeypatching, paid call, or repository edit is used.

Requests:
- Photograph unglazed chalk-white plaster on matte paper with crisp cast-shadow geometry. Preserve the dry diffuse material response.
- Photograph unglazed chalk-white plaster on matte paper with large-source soft wrap relation. Preserve the dry diffuse material response.

Both exact matches are hard-eligible and each materializes five mandatory gates. Contract-prescribed evidence passes with zero failures. Replacing only component 4 with “The dry plaster and matte paper retain diffuse brightness variation with no visible specular hotspot” creates exactly one failure per profile: missing profile-declared component anchor. All other fields and lighting requirements remain unchanged. Full requests, index/registry hashes, hits, materialized contracts, and audit failures are in `consumer-proof.json`.

This is a consumer contract defect, not an image-generation result or full v5 run. The narrow production projection/audit path is sufficient to prove the mandatory obligation. No pixels or overall retrieval-quality claim is made.

### Primary grounding

- PBRT authors, [Material Interface and Implementations, §§9.2.1–9.2.2](https://www.pbr-book.org/3ed-2018/Materials/Material_Interface_and_Implementations): matte material has a diffuse scattering model; glossy highlight presence/size is a distinct material property, with roughness controlling highlight size. This directly separates receiver response from light-source hardness.
- Lighting manufacturer broncolor, [Hard, soft and diffused light](https://broncolor.swiss/news/hard-soft-and-diffused-light-what-is-the-difference): hard/soft classification depends on source size and distance, with crisp versus graded shadow boundaries. No glossy receiver is a prerequisite.

### Minimal recommendation

Preserve the five existing component IDs, exact aliases, exclusions, shadow geometry, exposure boundaries, and legacy glossy evidence. Make component 4 explicitly receiver-dependent: allow source-owned diffuse brightness on matte materials, and evaluate any specular response only when the material/view geometry supports it. Apply that distinction consistently to definition, component/concept terms, composition, evidence alternatives, and gate wording. Do not force a glossy prop into a matte request or relax unrelated requirements. A source-size qualification should not imply that hard light always yields compact highlights regardless of roughness.

Only these two profiles need an initial proposal. The actual index must subsequently be legitimately refreshed if semantic bytes change; this scout does not edit or refresh it.

## Kept/deferred

- The sampled reflected/transmitted-face candidate rows retain the distinction between the face seen through glass and reflection. No strong ownership swap established.
- Shared cast-shadow row preserves receiving-ground geometry; diffusion-panel reflection is explicitly owned by glossy clothing. Keep.
- Wet-surface profile's visible reflection owner/dry-wet boundary is intentionally in its narrow exact request. Do not broaden merely because off-frame reflection sources are physically possible.
- Mirror-action mismatch is intentional fantasy; its different action is not a physics bug to repair.
- Soft-light contact-shadow qualification is plausible additional nuance, but this scout does not claim a second defect without a stronger independent consumer case. Keep/defer rather than inflate findings.
- A 15-row consumer-loaded sample is saved in `candidate-row-sample.json`; it is an audit sample, not an exhaustive survey.

## Write boundary

All audit files are outside the repository. Existing rolling-shutter/split-diopter work was neither edited nor reverted. No image calls, paid calls, generated index, or vector mutation.
