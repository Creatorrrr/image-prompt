# Current-corpus BEFORE requalification

All eight immutable public input cases completed with exit 0 using an exact frozen copy of the current 1496-profile working tree based on HEAD `2549f45230fe37dbc4224929b0d661ceac8004cc`, including the two pending object-morphology source/index changes. The production index loader accepted the real registry-bound index. Both target lighting source profiles were byte-equivalent as parsed objects to the old baseline. No lighting proposal was applied.

`public-cli/current-corpus-before/run-manifest.json` records exact source/index/script SHA256s, HEAD and dirty state, commands, exit codes, full target obligations, and output hashes. Every input's original hash was verified before execution. `current-corpus-snapshot/` preserves the executed source; old snapshot and BEFORE results remain untouched.

## Hard-contract result

The entire `visual_obligations` object is unchanged for all eight cases, including source bindings, evidence anchors, gate IDs and descriptions. Matte hard/soft requests in English and Korean and glazed ceramic controls activate the expected profile. Both generic controls have no hard visual obligations. The mandatory specular-evidence defect therefore still applies to the current public consumer.

## Corpus candidate differences, separately attributed

Full candidate records and orders are saved for every case under `current-corpus-comparison/*-candidate-differences.json`. Exhaustive full-pack differences are separately saved as `*-full-pack-differences.json`; `summary.json` carries the source manifest and per-case counts.

Only three cases change candidate collections:
- matte-soft: `y2kr_velour` replaces `rb_support_compression` in optional visual concepts and semantic clarification
- matte-soft-ko: `rb_shared_cast_shadow` is added as an optional visual concept and replaces `pe_binary_threshold_relation` in clarification
- generic-ko: optional `sheer_garment_optical_layering` disappears; clarification replaces it with `kuudere_composed_warmth_relation`

All other candidate collections are unchanged. No common candidate record changes internally. These are corpus-expansion effects, not effects of the unapplied lighting proposal. This report makes no claim that incidental optional suggestions are semantically ideal; they do not alter the governing hard contract.

## Boundaries

No repository edits, index rebuilding, fake vectors, provider calls, or pixel generation. This is a current-corpus BEFORE baseline. Approved central integration, legitimate vector refresh, and public AFTER remain separate work.
