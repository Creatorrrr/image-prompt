import json,sys
from pathlib import Path
O=Path(__file__).parent;S=O.parent.parent/'image-prompt/skills/photo-prompt-image-generator';sys.path.insert(0,str(S/'scripts'));import prompt_generator as pg
base=json.loads((O/'source-profiles.json').read_text());after={p['id']:p for p in json.loads((O/'reviewed-profiles.json').read_text())};rows=[]
for b in base:
 p=after[b['id']];pid=p['id'];groups=p['semantics']['component_semantics']['groups']
 cases=[('incomplete-original-'+str(i+1),t) for i,t in enumerate(b['semantics']['paraphrase_examples'])]
 cases += [('complete-'+str(i),'; '.join(g['any_terms'][i] if j==3 else g['any_terms'][0] for j,g in enumerate(groups))) for i in range(4)]
 cases += [('generic','A pear rests on paper under room lighting.'),('generic-ko','배가 종이 위에 놓여 있고 실내 조명이 비춘다.')]
 for label,t in cases:
  src=[{'source':'provenance.concept_lock','text':t}];old=pg.candidate_pack_auto_visual_concept_matches({'profiles':[b]},src);new=pg.candidate_pack_auto_visual_concept_matches({'profiles':[p]},src)
  rows.append({'profile':pid,'case':label,'text':t,'before':old,'after':new})
  assert (pid in new)==label.startswith('complete'),(pid,label,new)
(O/'actual-optional-eligibility-controls.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n');print('18 optional eligibility controls passed')
