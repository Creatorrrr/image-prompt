# Receiver-material DATA review

## Decision

Approve the amended seven-leaf change per target profile in `reviewed-leaf-changes.json`, subject to real index refresh and normal public-CLI before/after verification against the final merged corpus. Do not apply the earlier six-leaf proposal unchanged: it retains incomplete paraphrases that independently qualify for optional discovery. This review does not change the repository.

`reviewed-profiles.json` contains exact complete source profiles, and `compiled-profiles.json` contains production compiler output. The reproducible `review.py` asserts exact old leaf values before amending them, and records current source fingerprint and HEAD. It applies only named leaves, so unrelated upstream additions survive. Both target profiles were byte-structure identical to upstream 840d4b8f at inspection; current source was still the in-progress merge and must be rechecked before application.

## Physical review

Hardness is a property of apparent source extent and shadow transitions, not a demand for specular material. PBRT describes matte material as diffuse and plastic as a diffuse/specular mixture whose roughness controls highlight size. Thus a hard source need not produce a compact visible highlight on a rough receiver, and a diffuse receiver remains valid for either light relation. broncolor ties hard/soft shadow transitions to source size and distance. Source references were opened and checked during this review:

- https://www.pbr-book.org/3ed-2018/Materials/Material_Interface_and_Implementations (sections 9.2.1–9.2.2)
- https://broncolor.swiss/news/hard-soft-and-diffused-light-what-is-the-difference

The amended gate keeps the comparative compactness of compatible hard-light highlights, qualified by roughness, and explicitly retains broad source reflections on compatible glossy soft-light receivers. Existing matte shading is an alternative. No object, gloss finish, prop or material change is demanded. Concept wording is receiver-neutral, rather than replacing compulsory glossy material with compulsory matte material.

The old English glossy component/evidence anchor remains first and unchanged. Diffuse EN/KO and glossy KO are additional alternatives. KO component controls use the KO receiver phrase with the existing English phrases for the other four components; they are not claims of all-Korean five-component coverage. In composed evidence, Korean-only receiver phrases fail the existing English content-word floor; bilingual receiver evidence passes. That limitation is reported rather than changing thresholds or asserting unsupported Korean-only success.

## Why each old paraphrase is substantively incomplete

These judgments concern absent visual relations, not zero literal matches:

- Hard: “one coherent source direction links highlights form shadows and cast shadows” describes coherent direction, but does not specify hard edges/short penumbra, occluder shape correspondence, compact/material-appropriate response, or retained exposure
- Hard: “cast-shadow edges remain crisp with a short visible penumbra” describes edge hardness only; it omits coherent direction, occluder shape correspondence, surface response and retained exposure
- Hard: “shadow shapes correspond to the occluding subject or object geometry” describes shadow shape only; it does not distinguish hard from soft light or supply the other relations
- Soft: “one readable source direction survives instead of becoming flat ambient wash” describes direction, but does not establish broad transitions, progressive form shading, material response or open shaped shadows
- Soft: “cast and form shadow edges cross a broad gradual transition” describes transition width and implicitly some gradual modeling, but not directional ownership, material response or open shadow detail
- Soft: “curved forms move progressively from light through midtone into shadow” describes gradual modeling, but omits directional source ownership, cast-shadow transition, material response and retained shadow detail

All six retain their wording in component groups and existing evidence anchors, so complete descriptions using them still qualify. Whole-profile paraphrases are now complete combinations of all five relations, with each receiver alternative. No runtime function, exact label, required group, minimum count or exclusion changes.

## Measured results

Using current production `candidate_pack_visual_component_match`, `candidate_pack_auto_visual_concept_matches`, `candidate_pack_visual_profile_obligation`, `compile_visual_profile`, and `audit_visual_obligations`:

- 8 complete hard/soft × glossy/diffuse EN/KO receiver cases match component semantics and pass composed evidence (KO evidence with explicit English content-word support)
- 40 leave-one-component-out descriptions reject
- 40 missing-evidence-field cases reject
- 40 exclusion-appended descriptions reject
- 6 old incomplete fragments were optional-eligible before and are ineligible after
- 8 complete positive controls remain optional-eligible; 4 generic EN/KO controls remain ineligible
- All 5 gate IDs and review scales, 5 evidence fields and word floors, minimum 5 components, required group IDs, activation and exclusions, runtime labels, and reject-substitute arrays are unchanged

The optional-eligibility before/after results are complete consumer return values in `actual-optional-eligibility-controls.json`. Detailed positive, omission and exclusion outcomes are in `measured-controls.json`.

## Precision/recall boundary and remaining checks

This intentionally removes eligibility from underspecified but lighting-related fragments. That improves whole-profile precision while reducing partial-cue lexical recall; those fragments alone can no longer nominate the entire five-relation profile. Complete canonical/component descriptions retain recall, and the existing exact EN/KO activation labels are unchanged. No claim is made that arbitrary natural synonyms now match lexically or that semantic recall is unchanged. A real semantic refresh and independently authored public-CLI probes are still necessary. No vectors were manufactured, no paid calls were made, and no public AFTER or pixel-quality result is claimed here.
