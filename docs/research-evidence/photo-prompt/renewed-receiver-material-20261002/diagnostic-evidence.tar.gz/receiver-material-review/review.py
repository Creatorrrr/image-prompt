import json,sys,copy,hashlib,subprocess
from pathlib import Path
O=Path(__file__).resolve().parent; root=O.parent.parent/'image-prompt';S=root/'skills/photo-prompt-image-generator';sys.path.insert(0,str(S/'scripts'))
import prompt_generator as pg
import audit_composed_prompt as ac
src=S/'assets/photo_prompt_visual_obligations.json';raw=json.loads(src.read_text());ids=['hard_light_shadow_edge_relation','soft_light_shadow_edge_relation'];base=[p for p in raw['profiles'] if p['id'] in ids]; old=json.loads((O.parent/'reflection-material-audit/proposed-profiles.json').read_text());old={p['id']:p for p in old};up=json.loads(subprocess.check_output(['git','-C',str(root),'show','840d4b8f:skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations.json']));up={p['id']:p for p in up['profiles']};out=[];deltas={};results=[]
def diff(a,b,path=''):
 if type(a)!=type(b):return [{'path':path,'before':a,'after':b}]
 if isinstance(a,dict):return sum([diff(a[k],b[k],path+'/'+k) for k in a],[])
 if isinstance(a,list):
  if len(a)!=len(b):return [{'path':path,'before':a,'after':b}]
  return sum([diff(x,y,path+'/'+str(i)) for i,(x,y) in enumerate(zip(a,b))],[])
 return [] if a==b else [{'path':path,'before':a,'after':b}]
for b in base:
 pid=b['id'];p=copy.deepcopy(b)
 # Apply only pre-reviewed material leaves, never replace a current profile wholesale.
 changes=json.loads((O.parent/'reflection-material-audit/minimal-field-proposal.json').read_text())['profiles'][pid]
 for change in changes:
  cur=p;parts=change['path'].split('/')[1:]
  for key in parts[:-1]:cur=cur[int(key)] if isinstance(cur,list) else cur[key]
  key=int(parts[-1]) if isinstance(cur,list) else parts[-1]
  assert cur[key]==change['before'],(pid,change['path'],'source drift')
  cur[key]=copy.deepcopy(change['after'])
 groups=p['semantics']['component_semantics']['groups']
 ko='정반사 하이라이트는 비교적 작고 같은 광원 방향에 종속됨' if pid.startswith('hard') else '정반사 응답이 호환되는 광택 표면에서 넓게 퍼짐'
 groups[3]['any_terms'].append(ko);p['evidence_requirements'][pid+'_component_4_phrase']['must_mention_any'].append(ko)
 # Complete paraphrases eliminate fallback acceptance of single relation fragments.
 p['semantics']['paraphrase_examples']=['; '.join(g['any_terms'][ix] if j==3 else g['any_terms'][0] for j,g in enumerate(groups)) for ix in range(4)]
 # Receiver-neutral concept wording must not demand matte material either.
 p['concept_candidate']['concept_terms'][3]='existing receiver material retains diffuse shading or source-owned specular response compatible with its roughness and viewing geometry' if pid.startswith('hard') else 'existing receiver material retains diffuse modeling or glossy reflection compatible with the extended source and receiver geometry'
 # Keep original glossy visual behavior explicit in gate; do not silently relax it.
 p['render_gates'][3]['description']=('Existing matte receivers retain diffuse shading. Where material and viewing geometry support visible specular highlights, they are source-owned and comparatively compact for the same receiver roughness; roughness may broaden them. Preserve the requested material without adding gloss or another object.' if pid.startswith('hard') else 'Existing matte receivers retain diffuse modeling. On compatible glossy receivers, visible specular response reflects the extended source broadly as allowed by receiver and viewing geometry. Preserve the requested material without adding gloss or another object.')
 for key in ['activation','required_evidence_fields','reject_substitutes','runtime_expression']:assert p[key]==b[key]
 assert p['semantics']['component_semantics']['minimum_component_groups']==5
 assert p['semantics']['component_semantics']['required_group_ids']==b['semantics']['component_semantics']['required_group_ids']
 assert [(g['id'],g['review_scale']) for g in p['render_gates']]==[(g['id'],g['review_scale']) for g in b['render_gates']]
 for field,r in p['evidence_requirements'].items():assert r['min_content_words']==b['evidence_requirements'][field]['min_content_words']
 reg={'profiles':[p]};o=pg.candidate_pack_visual_profile_obligation(p,reg,activation_source='explicit_request_semantics',source_intent_ids=['review'])
 c={'enabled':True,'contract_version':pg.VISUAL_OBLIGATIONS_CONTRACT_VERSION,'strict_gate_set':True,'obligations':[o],'required_hard_gates':[g['id'] for g in o['render_gates']]}
 for ix,label in enumerate(['glossy-en','diffuse-en','diffuse-ko','glossy-ko']):
  terms=[g['any_terms'][ix] if j==3 else g['any_terms'][0] for j,g in enumerate(groups)];text='; '.join(terms);match=pg.candidate_pack_visual_component_match(p,text);assert match=='component_semantics'
  omitted=[]
  for j in range(5):
   t='; '.join(v for k,v in enumerate(terms) if k!=j);m=pg.candidate_pack_visual_component_match(p,t);assert m is None,(pid,label,j,m);omitted.append({'omitted_group':j+1,'match':m})
  ev={f:r['must_mention_any'][0] for f,r in o['evidence_requirements'].items()};ev[pid+'_component_4_phrase']=terms[3]
  pure=ac.audit_visual_obligations({'visual_obligations':c},{'visual_obligation_evidence':{pid:ev}},'. '.join(ev.values()))
  if ix in [2,3]:ev[pid+'_component_4_phrase']+='; the existing receiver preserves material and source direction'
  failures=ac.audit_visual_obligations({'visual_obligations':c},{'visual_obligation_evidence':{pid:ev}},'. '.join(ev.values()));assert not failures,(pid,label,failures)
  omitted_ev=[]
  for f in ev:
   e={k:v for k,v in ev.items() if k!=f};fs=ac.audit_visual_obligations({'visual_obligations':c},{'visual_obligation_evidence':{pid:e}},'. '.join(e.values()));assert fs;omitted_ev.append({'field':f,'failures':fs})
  exclusions=[]
  for ex in p['activation']['exclude_if_any_terms']:
   m=pg.candidate_pack_visual_component_match(p,text+'; '+ex);assert m is None;exclusions.append({'exclusion':ex,'match':m})
  results.append({'profile':pid,'variant':label,'complete_match':match,'missing_component_controls':omitted,'evidence_failures':failures,'unaugmented_evidence_failures':pure,'missing_evidence_controls':omitted_ev,'exclusion_controls':exclusions})
 fragments=[]
 for t in b['semantics']['paraphrase_examples']:
  before=pg.candidate_pack_visual_component_match(b,t);after=pg.candidate_pack_visual_component_match(p,t);assert after is None;fragments.append({'text':t,'before':before,'after':after})
 deltas[pid]=diff(b,p);out.append(p)
 results.append({'profile':pid,'old_incomplete_paraphrase_controls':fragments,'upstream_target_identical':b==up[pid]})
manifest={'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'head':subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD'],text=True).strip(),'scope':'In-memory production component/evidence audits only; no public CLI AFTER, vectors, or pixel claim; repository not modified.','profile_count':len(raw['profiles'])}
for name,obj in [('source-manifest.json',manifest),('source-profiles.json',base),('reviewed-profiles.json',out),('compiled-profiles.json',[pg.compile_visual_profile(p) for p in out]),('reviewed-leaf-changes.json',deltas),('measured-controls.json',results)]:
 (O/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'profiles':len(out),'leaves':{k:len(v) for k,v in deltas.items()},'variants':8,'missing_component_rejections':40,'missing_evidence_rejections':40,'exclusion_rejections':40,'old_fragment_rejections':6,'source':manifest}))
