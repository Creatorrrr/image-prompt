import json,sys,copy,hashlib,subprocess
from pathlib import Path
O=Path(__file__).resolve().parent;R=O.parent;W=R.parent;repo=W.parent/'image-prompt';S=repo/'skills/photo-prompt-image-generator';sys.path.insert(0,str(S/'scripts'));import prompt_generator as pg;import audit_composed_prompt as ac
A=S/'assets';registry=pg.load_visual_obligation_registry(A/'photo_prompt_visual_obligations.json');index=pg.load_visual_profile_index(A/'photo_prompt_visual_profile_index.json',registry)
P={p['id']:p for p in json.loads((A/'photo_prompt_visual_obligations.json').read_text())['profiles']}; reviewed=json.loads((R/'reviewed-profiles.json').read_text());assert all(P[p['id']]==p for p in reviewed)
cases=json.loads((W/'reflection-material-audit/independent-authored-scenes.json').read_text());D=W/'reflection-material-audit/public-cli';results=[]
for name,pid,request,subject,event,baseline in cases:
 path=D/'after-reviewed'/f'{name}-pack.json';pack=json.loads(path.read_text())[0];before=json.loads((D/'current-corpus-before'/f'{name}-pack.json').read_text())[0]
 assert pack['authorial_core']['baseline_prompt_en']==baseline==before['authorial_core']['baseline_prompt_en'];assert pack['authorial_core']==before['authorial_core']
 obs=(pack.get('visual_obligations') or {}).get('obligations',[]);assert [o['id'] for o in obs]==([pid] if pid else [])
 ev={};sentences=[]
 if pid:
  o=obs[0];assert len(o['render_gates'])==5;assert list(o['evidence_requirements'])==P[pid]['required_evidence_fields'];assert o['evidence_requirements']==P[pid]['evidence_requirements']
  matte=name.startswith('matte');hard='hard' in name
  details=(['On the existing plaster pear, the upper-left lamp owns the brighter diffuse left side, shaded right side and rightward cast shadow','At the pear body and stem silhouette on the matte sheet, the edge stays narrow','The existing pear body and stem determine the outline cast onto the supporting sheet','The plaster and paper remain dry and diffusely reflecting without a glaze or added object','The pale plaster texture and darker pear contour remain readable'] if matte and hard else
  ['The existing pear remains brighter at upper left and shaded at right under the nearby diffuser','The supporting sheet carries a gently widening shadow transition away from the pear base','The plaster body changes gradually from its illuminated left side through middle values to its shaded right side','The dry plaster and matte paper retain their chalky diffuse appearance without a glaze or added object','The pear right contour and darker surface texture remain legible under gentle room return'] if matte else
  ['The upper-left lamp owns the glazed pear highlight, shaded body and rightward shadow','The pear stem and body cast a crisp narrow-edged shadow on the gray sheet','The glazed pear body and stem determine the shadow outline on the existing supporting sheet','The compact reflected lamp patch stays on the existing ceramic glaze and the paper remains matte','The small reflection and darker ceramic areas retain detail'] if hard else
  ['The nearby upper-left diffuser owns the brighter glaze and shaded right side of the ceramic pear','The cast shadow gradually loses definition away from the existing base contact','The curved ceramic body grades smoothly from its lit left side to the shaded right side','The existing smooth glaze reflects the large diffuser as a broad soft patch while the paper remains diffuse','The broad reflection and darker ceramic regions retain detail and the right contour remains visible'])
  for j,f in enumerate(list(o['evidence_requirements'])):
   anchor=o['evidence_requirements'][f]['must_mention_any'][1 if matte and j==3 else 0]
   text=details[j]+': '+anchor+'.'
   if matte and hard and j==0:text+=' Here highlights denote the brighter diffuse plaster region, with no shiny surface introduced.'
   ev[f]=text;sentences.append(text)
 prompt=baseline+(' '+' '.join(sentences) if sentences else '')
 composed={'pack_id':pack['pack_id'],'composer':'agent','prompt_en':prompt,'negative_en':pack['negative_en'],'chosen_candidate_ids':[],'chosen_visual_concept_ids':[],'core_retrieval_sha256':pack['core_retrieval']['canonical_sha256'],'visual_obligation_evidence':{pid:ev} if pid else {}}
 focused=ac.audit_visual_obligations(pack,composed,prompt);assert not focused,(name,focused)
 mutations=[]
 for f in ev:
  c=copy.deepcopy(composed);del c['visual_obligation_evidence'][pid][f];failure=ac.audit_visual_obligations(pack,c,prompt);assert failure;mutations.append({'field':f,'mutation':'missing_field','failures':failure})
  c=copy.deepcopy(composed);c['prompt_en']=prompt.replace(ev[f],'');failure=ac.audit_visual_obligations(pack,c,c['prompt_en']);assert failure;mutations.append({'field':f,'mutation':'missing_literal','failures':failure})
 full=ac.audit_composed_prompt(pack,composed)
 (O/f'{name}-focused-composed.json').write_text(json.dumps(composed,ensure_ascii=False,indent=2)+'\n');(O/f'{name}-full-audit-diagnostic.json').write_text(json.dumps(full,ensure_ascii=False,indent=2)+'\n');(O/f'{name}-negative-controls.json').write_text(json.dumps(mutations,ensure_ascii=False,indent=2)+'\n')
 results.append({'case':name,'pack_path':str(path),'pack_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'pack_id':pack['pack_id'],'profile_id':pid,'source_request':request,'frozen_core_identical':True,'baseline_verbatim_prefix':prompt.startswith(baseline),'focused_failures':focused,'missing_field_rejections':len(ev),'missing_literal_rejections':len(ev),'full_audit':full,'material_review':'Dry plaster and matte paper retained; appended evidence refers only to original pear, sheet and lighting, with no added glossy object or finish.' if name.startswith('matte') else 'Original glazed ceramic and diffuse sheet retained.' if name.startswith('glossy') else 'Generic scene has no activated visual obligation and no added visual evidence.'})
summary={'exact_reviewed_sources':True,'current_commit':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'real_index_validated':True,'loaded_profile_count':len(registry['profiles']),'source_sha256':hashlib.sha256((A/'photo_prompt_visual_obligations.json').read_bytes()).hexdigest(),'index_sha256':hashlib.sha256((A/'photo_prompt_visual_profile_index.json').read_bytes()).hexdigest(),'focused_passes':len(results),'negative_rejections':sum(x['missing_field_rejections']+x['missing_literal_rejections'] for x in results),'results':results}
(O/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in summary.items() if k!='results'}));print([(r['case'],r['full_audit'].get('passed'),len(r['full_audit'].get('failures',[]))) for r in results])
