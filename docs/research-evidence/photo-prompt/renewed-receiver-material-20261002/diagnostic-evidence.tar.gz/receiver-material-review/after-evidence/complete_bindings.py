import json,sys,copy,hashlib
from pathlib import Path
O=Path(__file__).resolve().parent;W=O.parent.parent;S=W.parent/'image-prompt/skills/photo-prompt-image-generator';sys.path.insert(0,str(S/'scripts'));import audit_composed_prompt as ac
results=[]
for path in sorted(O.glob('*-focused-composed.json')):
 name=path.name.replace('-focused-composed.json','');p=json.loads((W/'reflection-material-audit/public-cli/after-reviewed'/f'{name}-pack.json').read_text())[0];c=json.loads(path.read_text());core=p['authorial_core'];lock=core['intent_lock'];anchors=lock['semantic_anchors'];baseline=core['baseline_prompt_en']
 c['authorial_core_binding']={'source_authorial_core_sha256':core['canonical_sha256'],'source_intent_lock_sha256':lock['canonical_sha256'],'preserved_anchor_ids':[a['anchor_id'] for a in anchors],'preserved_evidence':[baseline.split('. ')[0]+'.'],'authorial_decisions':[]}
 review=copy.deepcopy(p['embodiment_preflight']['baseline_review']);review['provenance']='agent_postcomposition';review['prompt_sha256']=hashlib.sha256(c['prompt_en'].encode()).hexdigest();review['summary']='The composed scene still depicts only the original pear on its supporting paper under studio or room illumination. No person or animal body action has been introduced. This is a text-only scope review, not image validation.'
 c['embodiment_review']={'source_contract_sha256':p['embodiment_preflight']['canonical_sha256'],'review':review}
 c['semantic_clarification_decisions']=[]
 for row in p['semantic_clarification']['candidates']:
  apply=row.get('required_in_final_prompt') is True or row.get('profile_id') in c['visual_obligation_evidence']
  d={'clarification_id':row['id'],'decision':'applied' if apply else 'rejected','rationale':'Preserve the requested pear, supporting paper, material and lighting relation already expressed by the frozen scene.' if apply else 'This optional interpretation is unnecessary for the requested pear still life and would add unrelated scene meaning.'}
  if apply:d['prompt_evidence']=baseline.split('. ')[0]+'.' if row.get('source')=='requester_meaning_bound_by_authorial_core' else list(c['visual_obligation_evidence'][row['profile_id']].values())[0]
  c['semantic_clarification_decisions'].append(d)
 c['creative_augmentation_brief']={'decisions':[{'candidate_id':row['id'],'decision':'rejected','rationale':'Retain the frozen still-life viewpoint, lighting and materials rather than introducing this optional creative variation.'} for row in ac.creative_augmentation_candidates_from_pack(p)]}
 result=ac.audit_composed_prompt(p,c);(O/f'{name}-complete-composed.json').write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n');(O/f'{name}-complete-audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');results.append({'case':name,'status':result['status'],'failures':result['failures'],'warnings':result['warnings']});print(name,result['status'],result['failures'],flush=True)
(O/'full-composition-summary.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n')
