# Receiver-material AFTER verification

## Outcome

Eight of eight complete composed artifacts pass the real `audit_composed_prompt` auditor: four matte hard/soft English/Korean request cases, two glossy hard/soft controls, and two generic English/Korean controls. Six activated cases contain complete five-field scene-specific lighting evidence. All 60 missing-field/missing-literal mutations fail the real visual-obligation auditor. Generic controls retain zero activated visual obligations.

Exact artifacts:

- `*-complete-composed.json`: complete scene-specific prompt, literal visual evidence, exact core/intent/embodiment bindings, required clarification decisions, and explicit rejection of optional creative changes
- `*-complete-audit.json`, `full-composition-summary.json`: full production audit pass results and retained warnings
- `*-focused-composed.json`: earlier focused-only evidence bundles
- `*-negative-controls.json`: 60 individual mutation failures
- `*-full-audit-diagnostic.json`: preserved initial full-audit diagnostics on focused-only bundles, which correctly failed missing composition metadata before complete bindings were authored
- `summary.json`: source/index validation, immutable-core checks, focused results, and initial full-audit diagnostics. Final full-audit success is in `full-composition-summary.json`; earlier diagnostics were not overwritten
- `verify.py`, `complete_bindings.py`: reproducible checks and artifact creation; neither mutates the repository or calls a provider

## Source and index integrity

The current two source profiles exactly equal the reviewed profile records. The production loader successfully validates the actual index against all 1496 loaded registry profiles. Source/index SHA256 fingerprints equal those recorded by the worker's genuine public AFTER replay on HEAD 6adabfe4. This independently verifies the exact data/index pair used for these packs; it does not claim a paid refresh was performed by this reviewer.

Source SHA256: 105b14642c2594427a20c31afe99ca48684ca84e88dc6ffd2af57cedede49f8e

Index SHA256: 1d8beb87f795aaa48792744861372762def2b48114b0eef2c6d6c7db24354921

## Material and scene review

Each complete prompt preserves the entire frozen baseline verbatim, and every AFTER authorial core equals its corresponding current-corpus BEFORE core. Matte scenes still depict a dry plaster pear and matte paper; appended evidence refers only to that pear, paper and existing lighting. It does not introduce glaze, a reflective prop or a glossy finish. The hard-light direction phrase's existing word “highlights” is explicitly interpreted as brighter diffuse plaster, not a newly invented shiny patch. Material-appropriate diffuse evidence satisfies component 4.

Glossy scenes retain the existing ceramic glaze and diffuse paper. Hard-light evidence retains the compact source-owned reflection; soft-light evidence retains the broad diffuser reflection. No original material or scene object is replaced. Generic scenes use their unchanged baseline and supply no activated lighting evidence. The complete compositions select no optional visual concepts or creative candidates; explicit rejection decisions preserve the requested still-life scope.

No rendered images were produced or examined. Full text/contract pass is not a pixel-quality or physical-rendering pass.

## Optional recall and collateral changes

The earlier measured direct-consumer controls remain applicable: six substantively incomplete lighting fragments qualified by the former partial-paraphrase fallback and no longer qualify alone. The loss is intentional partial-cue lexical recall, not proof that semantic recall is globally unchanged. Eight complete component positive controls retain eligibility. Exact labels and activation thresholds remain unchanged.

The genuine eight-scene public comparison does not exhibit lost target lighting activation: all six explicit hard/soft requests retain the expected single target obligation, and both generic packs are fully unchanged. The scope worker's exhaustive comparison finds one incidental optional membership swap in matte-soft English: `y2kr_velour` is replaced by `rb_support_compression`, with corresponding clarification change. This is a ranking/membership delta after refreshed data, not an observed loss of a target profile from the removed partial examples. Its specific causal mechanism was not isolated here. It is not selected in the reviewed composition. Do not describe candidate membership as entirely unchanged.

Primary comparison evidence: `../../reflection-material-audit/after-vs-current-corpus-before/`. The older 333-profile baseline is provenance only and must not be used to attribute merged-corpus differences to this repair.
