# Morphology source DATA qualification

This is a synthetic, source-aware contract qualification. The scene requests are synthetic test data, not messages from the current user. Production wire provenance enums exercise the existing CLI only. Baselines are complete authored photographic scenes; canonical source evidence is confined to explicitly identified composition templates. Reading existing source and audit evidence precedes this qualification, so no fresh blind pre-core authorship or natural-query retrieval gain is claimed.

## Frozen comparisons

- Original operator-free biohybrid request and all five original binding phrases are preserved verbatim from the prior audit. The target is acceptance of the complete independent robot body without adding an unwanted human.
- Three existing operator-present evidence alternatives are separately exercised with the same complete swimming-robot scene and a separately supported adult operator.
- Summoner localized-light, contact-shadow, and displaced-material scenes retain their own request properties. The original localized-light consequence evidence is preserved verbatim.
- The summoner natural-light evidence variant intentionally omits the full source alternatives enumeration. It is expected to remain rejected; changing composition prose alone cannot fix that evidence-field restriction.
- Actor costume, human implant, companion portrait, empty circle, and unrelated teacup are independent actual CLI negatives.
- Original biohybrid cyborg/partial-body/generic-machine/missing-tissue/missing-interface phrases are preserved as full-composition negative evidence attempts. They also receive an honest needs-revision embodiment result because an invalid replacement contradicts the frozen scene. Target evidence-field failures are reported independently of embodiment failure.
- Summoner companion/empty-circle/missing-operator evidence attempts remain negative. Neither empty magic glow nor a pet portrait should become summoning.

## What is measured

Each valid case runs the unchanged public generate_photo_prompt.py CLI with a frozen envelope, core, creative controls, and concrete embodiment review. Each composition runs the unchanged audit_composed_prompt.py CLI against its actual v6 pack. Choosing no optional candidate is permitted and isolates the evidence/composition metadata change. Candidate inventories, core retrieval binding, frozen core/locks, active profile identities, render gates, and rejection boundaries must be preserved before/after.

No vectors are queried from a provider. No runtime, corpus, tests, assertions, indexes, or source registry are edited by this qualification worker. The parent applies the two agreed source leaves only after the valid before evidence is complete. Source SHA records distinguish source registry/index metadata changes from retrieval changes.

## Limits

Summoner composition prose is guidance, not a runtime semantic contradiction checker. The expected improvement is a faithful instruction for the already-permitted localized-light branch, not a pass-rate improvement. The canonical enumeration phrases are deliberately artificial; their acceptance must not be described as natural light-only retrieval or composition success. Pixel anatomy, tissue viability, robot actuation performance, and rendered-light physics are not measured.

Early wire-only failures are retained under revisions with original files and CLI errors. Their corrections concern minimum text lengths, supported enum values, and mandatory concept/subject/event lock bindings, not target evidence assertions or product behavior.
