from pathlib import Path
import json,hashlib
P=Path(__file__).resolve().parent;r=lambda p:json.loads(p.read_text());assert 'Completed before-r4' in (P/'before-r4.log').read_text()
map={'cases':{},'compositions':{}};summ={'cases':[],'compositions':[],'issues':[],'synthetic_only':True,'notes':['All early wire failures remain archived.','Invalid composition controls also fail honest embodiment review; direct binding probes isolate field-level rejections.','Summoner canonical enumeration is not natural light-only evidence.']}
for arm in ['before','before-r4']:
 rep=r(P/arm/'report.json')
 for c in rep['cases']:map['cases'][c['id']]=arm+'/'+c['id']
 for c in rep['compositions']:map['compositions'][c['id']]=arm+'/compositions/'+c['id']
for id,path in map['cases'].items():
 cli=r(P/path/'cli.json');pack=r(P/path/'pack.json')[0];summ['cases'].append({'id':id,'path':path,'exit_code':cli['exit_code'],'obligation_ids':[o['id']for o in pack.get('visual_obligations',{}).get('obligations',[])]})
 if cli['exit_code']:summ['issues'].append(id+': CLI failure')
for t in r(P/'compositions.json'):
 a=r(P/map['compositions'][t['id']]/'audit.json');summ['compositions'].append({'id':t['id'],'status':a['status'],'expected':t['expected_before'],'failures':a['failures']})
 if a['status']!=t['expected_before']:summ['issues'].append(t['id']+': unexpected composition outcome')
manifest=r(P/'manifest.json');assert len(map['cases'])==len(manifest['case_ids']);assert len(map['compositions'])==len(r(P/'compositions.json'));assert all(hashlib.sha256((P/p).read_bytes()).hexdigest()==h for p,h in manifest['input_hashes'].items())
map['final_input_sha256']=manifest['input_hashes'];summ['status']='ready' if not summ['issues'] else 'blocked';summ['input_manifest_sha256']=hashlib.sha256((P/'manifest.json').read_bytes()).hexdigest()
(P/'valid-before-map.json').write_text(json.dumps(map,indent=2)+'\n');(P/'before-summary.json').write_text(json.dumps(summ,ensure_ascii=False,indent=2)+'\n');print(summ['status'],len(summ['cases']),'CLI cases',len(summ['compositions']),'composition cases',summ['issues'])
