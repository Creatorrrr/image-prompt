from pathlib import Path
import json,hashlib,shutil,sys
P=Path(__file__).resolve().parent;R=P.parent.parent/'image-prompt';sys.path.insert(0,str(R/'skills/photo-prompt-image-generator/scripts'));import prompt_generator as g
assert 'Completed before' in (P/'before.log').read_text(), 'Wait for the current arm before revising inputs'
r=P/'revisions/r3-companion-resolution-and-review-ownership';r.mkdir(parents=True)
for name in ['inputs','manifest.json','compositions.json','qualify.py','before.log']:
 s=P/name
 if s.is_dir():shutil.copytree(s,r/name)
 else:shutil.copy2(s,r/name)
changed=[]
for d in sorted((P/'inputs').iterdir()):
 c=json.loads((d/'core.json').read_text());s=json.loads((d/'spec.json').read_text());rv=json.loads((d/'review.json').read_text());dirty=False
 if d.name=='negative_companion':
  c['interpretation_provenance'][0]['resolution']='A quiet still companion portrait of a mage beside a feathered pet';dirty=True
 if d.name.startswith('summoner_'):
  next(a for a in c['intent_lock']['semantic_anchors']if a['anchor_id']=='subject_identity')['prompt_evidence']='fantasy summoner'
  s['anchors']=c['intent_lock']['semantic_anchors'];rv['checks']['support_and_balance']['status']='requester_intended';rv['checks']['support_and_balance']['requester_source_text']='causes a separate feathered creature to emerge from a complete circular threshold above a glazed plinth';dirty=True
 if d.name=='negative_empty_circle':rv['summary']='An architectural still scene of an empty luminous circle above stone has no body or bodily mechanism.';dirty=True
 if dirty:
  changed.append(d.name)
  for n,obj in [('core',c),('spec',s),('review',rv)]:(d/(n+'.json')).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
 issues=[]
 try:
  n=g.normalize_authorial_core(c,request_envelope=g.normalize_request_envelope(json.loads((d/'envelope.json').read_text())),creative_control_snapshot=json.loads((d/'controls.json').read_text()));g.photo_embodiment.build_policy(n,rv)
 except Exception as e:issues.append(dict(case=d.name,error=str(e)))
 assert not issues,issues
m=json.loads((P/'manifest.json').read_text());m['input_revision']='r4: companion resolution length; remove agent-chosen adult from summoner subject lock; mark requested threshold emergence as intentional in embodiment; correct empty-circle review summary. Scene requests, baseline prompts, compositions, original target evidence, and expected outcomes unchanged.';m['input_hashes']={p:hashlib.sha256((P/p).read_bytes()).hexdigest()for p in m['input_hashes']};(P/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');(P/'r4-changed-cases.json').write_text(json.dumps(changed,indent=2)+'\n');print(changed)
f=P/'qualify.py';code=f.read_text();code=code.replace("if case['kind']=='still': return", "if case['kind']=='still': return")
code=code.replace("'summary':'The porcelain still life has no bodily mechanism or acting organism.'", "'summary':('An empty luminous circle above stone has no bodily mechanism.' if case['id']=='negative_empty_circle' else 'The porcelain still life has no bodily mechanism or acting organism.')")
code=code.replace(" if invalid:\n", " if case['kind']=='summoner':\n  checks['support_and_balance']['status']='requester_intended'\n  checks['support_and_balance']['requester_source_text']='causes a separate feathered creature to emerge from a complete circular threshold above a glazed plinth'\n if invalid:\n")
code=code.replace(" for id in man['case_ids']:\n", " for id in man['case_ids']:\n  if os.environ.get('QUAL_CASE_IDS') and id not in os.environ['QUAL_CASE_IDS'].split(','):continue\n")
f.write_text(code)
