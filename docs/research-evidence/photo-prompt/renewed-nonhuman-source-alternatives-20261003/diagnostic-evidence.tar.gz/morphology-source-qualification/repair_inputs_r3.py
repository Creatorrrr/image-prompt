from pathlib import Path
import json,hashlib,shutil,sys
P=Path(__file__).resolve().parent;R=P.parent.parent/'image-prompt';sys.path.insert(0,str(R/'skills/photo-prompt-image-generator/scripts'));import prompt_generator as g
r=P/'revisions/r2-required-dimension-errors';r.mkdir(parents=True)
for name in ['inputs','manifest.json','compositions.json','before','before.log','qualify.py']:
 s=P/name
 if s.is_dir():shutil.copytree(s,r/name)
 else:shutil.copy2(s,r/name)
# Only the failed arm location is retired; artifacts remain byte-for-byte under revisions.
shutil.rmtree(P/'before');(P/'before.log').unlink()
issues=[]
for d in sorted((P/'inputs').iterdir()):
 c=json.loads((d/'core.json').read_text());s=json.loads((d/'spec.json').read_text());q=c['source_request'];b=c['baseline_prompt_en'];anchors=c['intent_lock']['semantic_anchors']
 for a in anchors:
  if a['dimension']=='subject' and 'property'in a:a['dimension']='composition' if a['property']=='participant_count' else 'relationship'
 if d.name.startswith('bio_'):anchors.append(dict(anchor_id='subject_identity',source_text='biohybrid robot',dimension='subject',prompt_evidence='biohybrid robot swims'))
 elif d.name.startswith('summoner_'):
  anchors[0]['prompt_evidence']='summoner causing a distinct entity to arrive';anchors.append(dict(anchor_id='subject_identity',source_text='fantasy summoner',dimension='subject',prompt_evidence='adult fantasy summoner'))
 else:
  anchors[0]['anchor_id']='concept';fragments={
  'negative_actor_costume':('An adult actor','wears a molded robot costume'),
  'negative_cyborg':('An adult human with a mechanical forearm implant','stands in a laboratory'),
  'negative_companion':('An adult mage','poses beside a feathered pet'),
  'negative_empty_circle':('A complete empty glowing circle','stands above a stone plinth'),
  'negative_unrelated_still':('A blue porcelain teacup','steams on a wooden table')}
  subject,event=fragments[d.name];anchors.extend([dict(anchor_id='subject',source_text=subject,dimension='subject',prompt_evidence=subject),dict(anchor_id='event',source_text=event,dimension='event',prompt_evidence=event)])
 lock=c['intent_lock'];lock['locked_dimensions']=list(dict.fromkeys(a['dimension']for a in anchors if 'property'not in a));lock['open_dimensions']=[x for x in ['subject','event','setting','appearance','pose','body_geometry','material','framing','composition','lighting','camera','color','atmosphere','relationship']if x not in lock['locked_dimensions']]
 s['anchors']=anchors
 for name,obj in [('core',c),('spec',s)]: (d/(name+'.json')).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
 try:
  n=g.normalize_authorial_core(c,request_envelope=g.normalize_request_envelope(json.loads((d/'envelope.json').read_text())),creative_control_snapshot=json.loads((d/'controls.json').read_text()));g.photo_embodiment.build_policy(n,json.loads((d/'review.json').read_text()))
 except Exception as e:issues.append(dict(case=d.name,error=str(e)))
print(issues)
m=json.loads((P/'manifest.json').read_text());m['input_revision']='r3 correcting enum/minimum-word/required-dimension wire errors only; original failures preserved';m['input_hashes']={p:hashlib.sha256((P/p).read_bytes()).hexdigest()for p in m['input_hashes']};(P/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');(P/'preflight-r3.json').write_text(json.dumps(issues,indent=2)+'\n')
