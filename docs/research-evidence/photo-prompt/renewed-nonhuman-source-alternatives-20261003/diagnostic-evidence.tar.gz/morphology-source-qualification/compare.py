from pathlib import Path
import json,hashlib,sys
P=Path(__file__).resolve().parent
r=lambda p:json.loads(p.read_text())
def leafdiff(a,b,path=''):
 if type(a)!=type(b):return [dict(path=path,before=a,after=b)]
 if isinstance(a,dict):
  out=[]
  for k in sorted(set(a)|set(b)):
   if k not in a or k not in b:out.append(dict(path=path+'/'+k,before=a.get(k),after=b.get(k)))
   else:out+=leafdiff(a[k],b[k],path+'/'+k)
  return out
 if isinstance(a,list):
  if len(a)!=len(b):return [dict(path=path,before=a,after=b)]
  return sum([leafdiff(x,y,path+'/'+str(i))for i,(x,y)in enumerate(zip(a,b))],[])
 return [] if a==b else [dict(path=path,before=a,after=b)]
before_map=r(P/'valid-before-map.json');after=P/sys.argv[1];manifest=r(P/'manifest.json');issues=[];report={'cases':[],'composition_changes':[],'pack_leaf_changes':{},'limitations':['Synthetic source-aware fixtures, not natural-query gain.','Summoner full alternatives enumeration remains required by evidence schema.','Summoner composition wording change is source consistency, not automatic audit pass-rate uplift.','No rendered images, provider calls, runtime changes, or corpus edits.']}
for id in manifest['case_ids']:
 b=P/before_map['cases'][id];a=after/id;bp=r(b/'pack.json')[0];ap=r(a/'pack.json')[0];checks={k:bp.get(k)==ap.get(k)for k in ['slots','core_retrieval','authorial_core','embodiment_preflight','semantic_clarification','negative_en','negative_intent_guard','intent_preservation']}
 bo=bp.get('visual_obligations',{}).get('obligations',[]);ao=ap.get('visual_obligations',{}).get('obligations',[])
 checks['active_profile_ids']=[o['id']for o in bo]==[o['id']for o in ao];checks['gates_and_rejection_boundaries']=[(o.get('render_gates'),o.get('reject_substitutes'))for o in bo]==[(o.get('render_gates'),o.get('reject_substitutes'))for o in ao]
 report['cases'].append({'id':id,'preservation':checks});report['pack_leaf_changes'][id]=leafdiff(bp,ap)
 for k,v in checks.items():
  if not v:issues.append(id+': changed '+k)
for t in r(P/'compositions.json'):
 id=t['id'];b=r(P/before_map['compositions'][id]/'audit.json');a=r(after/'compositions'/id/'audit.json');report['composition_changes'].append({'id':id,'before':b['status'],'after':a['status'],'expected_before':t['expected_before'],'expected_after':t['expected_after'],'before_failures':b['failures'],'after_failures':a['failures']})
 if b['status']!=t['expected_before'] or a['status']!=t['expected_after']:issues.append(id+': unexpected audit status')
 # Original scene/evidence/prompt bytes must be identical; only per-pack hash links may change.
 bc=r(P/before_map['compositions'][id]/'composed.json');ac=r(after/'compositions'/id/'composed.json')
 if any(bc.get(k)!=ac.get(k)for k in ['prompt_en','visual_obligation_evidence','negative_en','chosen_candidate_ids']):issues.append(id+': composition content changed')
report['issues']=issues;report['status']='pass' if not issues else 'fail';(P/'comparison.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'status':report['status'],'issues':issues,'cases':len(report['cases']),'compositions':len(report['composition_changes'])},indent=2))
