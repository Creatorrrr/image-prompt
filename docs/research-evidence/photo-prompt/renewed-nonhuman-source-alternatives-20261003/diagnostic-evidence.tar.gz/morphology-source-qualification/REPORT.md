# Morphology source correction qualification

## Result

PASS for this bounded DATA change: all 12 frozen actual v6 CLI cases execute successfully in both selected arms, and all 21 full-composition outcomes match the frozen expectations. The only composition status change is the original operator-free biohybrid scene, which changes from one separation-evidence failure to a complete audit pass.

| Case group | BEFORE | AFTER | Interpretation |
|---|---|---|---|
| Original operator-free biohybrid | Fail, separation field only | Pass | Correctly accepts the existing complete independent robot body evidence without adding an operator |
| Three original operator-present alternatives | 3 pass | 3 pass | Existing acceptance preserved |
| Summoner canonical light, shadow, displacement | 3 pass | 3 pass | Composition guidance now matches the already-allowed light alternative |
| Natural summoner light-only binding | Fail | Fail | Evidence schema still requires the full alternatives phrase |
| Actor costume, cyborg, companion, empty circle, unrelated still life | 5 valid packs, 5 composition passes, no target obligations | Same | Wrong-neighbor and unrelated activation boundaries preserved |
| Eight deliberately invalid target compositions | 8 fail | 8 fail | Target evidence failures and additional honest embodiment failures preserved |

Direct binding checks independently isolate field validation: 80 identical field/phrase pairs produce 10 rejections before and 9 after. Exactly one changes: the original operator-free complete-body phrase. No other rejection or acceptance changes.

## Preserved invariants

All 12 case comparisons retain byte-equivalent JSON values for candidate slots, core retrieval, frozen core and intent locks, embodiment preflight, semantic clarification, negative prompt and guard, intent preservation, active profile identities, render gates, and reject-substitute boundaries. Final prompt text, original binding phrases, candidate selections, and negatives are unchanged between arms. Original counterexample request text and the five biohybrid bindings plus summoner light consequence phrase were checked against the prior evidence.

The registry has exactly two changed leaves: profile 96 operator_separation_phrase must_mention_any gains `complete independent robot body`; profile 133 composition_instruction admits local dust, light, shadow, or displaced-object response. Registry SHA-256 is 2decb5051554f021fa25d6d4a0c59b03219e6cdfcfe355861d2399d9d6a5a417. The derived visual-index payload, excluding registry_sha256, is identical. Other runtime source and asset hashes in the frozen manifest are unchanged.

## Limits and preserved failures

This is source-aware synthetic DATA qualification, not blind initial authoring, natural-query retrieval improvement, provider-vector retrieval, or rendered-image verification. Complete independently phrased baselines are frozen, but the test author had read source metadata and the original audit; no claim of fresh source-blind pre-core authorship is made. Production provenance enums serve only the synthetic CLI adapter.

The summoner composition change fixes inconsistent guidance; it does not make a natural light-only phrase pass the current exact evidence schema. Canonical alternatives enumeration was accepted before and after and must not be called a natural-query win. The full composition auditor does not semantically enforce the old contact-shadow/displacement instruction, so this leaf has no automatic pass-rate uplift.

The eight malformed boundary compositions retain both target evidence failures and deliberately honest needs-revision embodiment failures. Their rejection is not attributed solely to the target guard; before-direct-bindings.json and after-direct-bindings.json isolate that guard separately. No pixels, living-tissue viability, robot actuation performance, or rendered-light physics were evaluated.

Early wire/input failures are fully preserved under revisions. Corrections cover setting content length, valid setting enum, required concept/subject/event locks, one companion interpretation minimum, removal of agent-chosen adult wording from a summoner lock, correct intentional-fantasy review status, and the empty-circle review summary. Requested scene text, baseline prompts, target binding phrases, expected outcomes, runtime, corpus, indexes, and tests were not changed to rescue AFTER. No inputs were edited after the parent applied the source leaves.

## Evidence and reproduction

- manifest.json: final frozen input hashes, original HEAD and source hashes, synthetic provenance, exact proposed leaves
- valid-before-map.json: selected immutable BEFORE output paths, including narrow corrected-input replay
- before-summary.json: 12 valid cases and all 21 expected BEFORE outcomes
- after/report.json: all 12 AFTER CLI and 21 full-composition outcomes
- comparison.json: every before/after invariant and every pack leaf difference
- source-and-direct-comparison.json: exact source/index and 80-field comparison
- exact-source-delta.json: the complete two-leaf registry diff against the original clean HEAD
- before-direct-bindings.json / after-direct-bindings.json: independent field-level outcomes
- inputs/: immutable request envelope, core, controls, concrete embodiment review, and case specification
- compositions.json: immutable final text and evidence templates, including original counterexamples and boundaries
- before/, before-r4/, after/: exact CLI commands, outputs, packs, composed artifacts, full audits and warnings
- revisions/: preserved initial failures and prior inputs

To replay the currently applied source with the frozen files, run `.venv/bin/python ../daylong-progress-20261002/morphology-source-qualification/qualify.py after-replay` from the repository, then run `compare.py after-replay`. The runner refuses to overwrite an existing arm and verifies input hashes first. A BEFORE replay requires the original clean source revision, 18a46eb413a40ace4eb7b8913755ff739ac5c3cb, with the same final inputs. No provider or paid calls were used.
