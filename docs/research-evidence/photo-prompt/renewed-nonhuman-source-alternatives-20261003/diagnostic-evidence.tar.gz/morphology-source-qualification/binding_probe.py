from pathlib import Path
import json,sys
P=Path(__file__).resolve().parent;R=P.parent.parent/'image-prompt';sys.path.insert(0,str(R/'skills/photo-prompt-image-generator/scripts'));import prompt_generator as g
profiles={p['id']:p for p in g.load_visual_obligation_registry(R/'skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations.json')['profiles']}
report=[]
for t in json.loads((P/'compositions.json').read_text()):
 c=json.loads((P/'inputs'/t['case']/'spec.json').read_text());profile=c['profile']
 if not profile:continue
 for field,phrase in t['bindings'].items():
  row={'composition_id':t['id'],'profile':profile,'field':field,'phrase':phrase}
  try:g.validate_visual_intent_binding(obligation_index=0,field=field,phrase=phrase,requirement=profiles[profile]['evidence_requirements'][field]);row['pass']=True
  except Exception as e:row.update({'pass':False,'error':str(e)})
  report.append(row)
out=P/(sys.argv[1]+'-direct-bindings.json');assert not out.exists();out.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(len(report),'direct fields,',sum(not r['pass']for r in report),'rejections')
