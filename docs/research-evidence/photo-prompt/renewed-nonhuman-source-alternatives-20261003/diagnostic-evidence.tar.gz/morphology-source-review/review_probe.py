"""Read-only source-review probe: copy proposed leaves in memory; never build an index or call a provider."""
import copy, hashlib, json, subprocess, sys
from pathlib import Path
ROOT=Path('REPOSITORY_ROOT')
OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'skills/photo-prompt-image-generator/scripts'))
import prompt_generator as pg
import audit_composed_prompt as audit
base_path=ROOT/'skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations.json'
before=json.loads(base_path.read_text())
after=copy.deepcopy(before)
leaves=json.loads((OUT.parent/'animal-morphology-audit/proposed-leaves.json').read_text())
for leaf in leaves:
    profile=next(p for p in after['profiles'] if p['id']==leaf['profile_id'])
    parts=leaf['path'].strip('/').split('/')
    obj=profile
    for part in parts[:-1]: obj=obj[part]
    if leaf['operation']=='append': obj[parts[-1]].append(leaf['value'])
    else:
        assert obj[parts[-1]]==leaf['before']
        obj[parts[-1]]=leaf['after']
def profile(reg,pid): return next(p for p in reg['profiles'] if p['id']==pid)
def test(reg,pid,field,phrase):
    req=profile(reg,pid)['evidence_requirements'][field]
    try:
        pg.validate_visual_intent_binding(obligation_index=0,field=field,phrase=phrase,requirement=req)
        ok=True; error=None
    except ValueError as e: ok=False; error=str(e)
    return {'binding_pass':ok,'content_words':len(pg.visual_intent_evidence_tokens(phrase)), 'audit_anchor_match':any(audit.text_contains_term(phrase,a) for a in req['must_mention_any']), 'error':error}
bio='biohybrid_robot_living_synthetic_integration';summon='summoner_distinct_entity_arrival'
bindings={
'independent_robot_phrase':'an intact independent non-humanoid robot',
'living_tissue_phrase':'clearly visible pink living muscle bands',
'synthetic_structure_phrase':'transparent synthetic scaffold with flexible polymer ribs',
'functional_interface_phrase':'contracted tissue bends the scaffold through visible anchors',
'operator_separation_phrase':'complete independent robot body'}
probes=[]
for field,phrase in bindings.items(): probes.append({'case':'biohybrid_operator_free_'+field,'phrase':phrase,'before':test(before,bio,field,phrase),'after':test(after,bio,field,phrase)})
for phrase in profile(before,bio)['evidence_requirements']['operator_separation_phrase']['must_mention_any']:
    phrase+=' beside the workbench'
    probes.append({'case':'biohybrid_existing_separation_anchor','phrase':phrase,'before':test(before,bio,'operator_separation_phrase',phrase),'after':test(after,bio,'operator_separation_phrase',phrase)})
for phrase in ['isolated machine body on a clear platform','a fully synthetic animal-shaped robot body','a sensor backpack on a living animal']:
    probes.append({'case':'biohybrid_noncanonical_control','phrase':phrase,'before':test(before,bio,'operator_separation_phrase',phrase),'after':test(after,bio,'operator_separation_phrase',phrase)})
for phrase in ['dust light shadow or displaced objects respond locally to the arrival','dust light shadow or displaced objects respond locally to the arrival with amber ripples','The newly arriving entity casts a sharply localized amber reflection across the rough threshold floor']:
    probes.append({'case':'summoner_consequence_anchor_limit','phrase':phrase,'before':test(before,summon,'consequence_phrase',phrase),'after':test(after,summon,'consequence_phrase',phrase)})
unchanged={}
for pid in [bio,summon]:
    a=profile(before,pid);b=profile(after,pid)
    unchanged[pid]={k:a[k]==b[k] for k in ['activation','semantics','concept_candidate','runtime_expression','required_evidence_fields','render_gates','reject_substitutes']}
    unchanged[pid]['semantic_text']=pg.visual_profile_semantic_text(a)==pg.visual_profile_semantic_text(b)
    unchanged[pid]['bm25f_fields']=pg.visual_profile_bm25f_fields(a)==pg.visual_profile_bm25f_fields(b)
# The full current composite registry includes all upstream extension profiles.
loaded=pg.load_visual_obligation_registry(base_path)
loaded_after=copy.deepcopy(loaded)
for pid in [bio,summon]:
    i=next(i for i,p in enumerate(loaded_after['profiles']) if p['id']==pid)
    loaded_after['profiles'][i]=profile(after,pid)
assert all(all(v.values()) for v in unchanged.values())
assert all(x['after']['binding_pass'] for x in probes if x['case'].startswith('biohybrid_operator_free_'))
assert not next(x for x in probes if x['case']=='biohybrid_operator_free_operator_separation_phrase')['before']['binding_pass']
result={
'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
'source_worktree_status':subprocess.check_output(['git','status','--short'],cwd=ROOT,text=True).strip(),
'base_registry_blob_baseline':subprocess.check_output(['git','rev-parse','3c3b3a64:skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations.json'],cwd=ROOT,text=True).strip(),
'base_registry_blob_head':subprocess.check_output(['git','rev-parse','HEAD:skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations.json'],cwd=ROOT,text=True).strip(),
'acting_profile_count':len(json.loads((ROOT/'skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations_acting_expression.json').read_text())['profiles']),
'base_profile_count':len(before['profiles']), 'composite_profile_count':len(loaded['profiles']),
'full_composite_registry_hash_before':pg.visual_profile_registry_sha256(loaded),
'full_composite_registry_hash_after_in_memory':pg.visual_profile_registry_sha256(loaded_after),
'exact_lookup_unchanged':pg.visual_profile_exact_term_rows(loaded)==pg.visual_profile_exact_term_rows(loaded_after),
'unchanged_fields':unchanged,'probes':probes,
'paid_calls':0,'source_edits':0,'scope':'In-memory source metadata and evidence-binding checks only; no natural retrieval benchmark, full pack integration, index rebuild, or pixel evaluation.'}
(OUT/'review-probe-results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False,indent=2))
