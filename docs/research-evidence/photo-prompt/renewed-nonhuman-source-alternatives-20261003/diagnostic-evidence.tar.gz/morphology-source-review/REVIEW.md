# Independent source review: biohybrid and summoner DATA leaves

## Verdict

**ACCEPT both exact proposed leaves as bounded source-metadata consistency repairs.** They do not establish better natural retrieval, broader paraphrase support, or pixel quality. No source files were edited and no provider/image/embedding calls were made.

Reviewed `animal-morphology-audit/proposed-leaves.json` against actual source, not the audit conclusion. Repository HEAD is `18a46eb413a40ace4eb7b8913755ff739ac5c3cb`; source worktree was clean. The base visual registry is byte-identical to `3c3b3a64` (both Git blobs `b606beba1217e8de4c3a2667e936036ecf40bb5f`). Current acting-expression extension contains 11 profiles. Base registry contains 333 profiles; current composite loader returns 1,507.

## 1. Biohybrid operator-free alternative: ACCEPT

Leaf: append `complete independent robot body` to `biohybrid_robot_living_synthetic_integration/evidence_requirements/operator_separation_phrase/must_mention_any`.

- The definition requires functional living–synthetic integration, not an in-frame person. Required component groups include independent robot body, and their vocabulary already includes operator-free `independent non-humanoid robot` and `complete manta-shaped machine body` [base registry:19077–19145].
- Existing composition explicitly calls for a complete independent robot, tissue, scaffold and functional interface, without requiring an operator [19177]. In contrast, all three existing separation evidence anchors mention a human/operator/engineer [19218–19224]. This is the actual inconsistency.
- The new phrase expresses that existing independence class in four content words, satisfying the unchanged minimum. It does not add a setting, organism shape, role, count, or special-case narrative. Retaining the existing field name and old alternatives avoids unrelated schema changes.
- All other evidence fields, the living-material/engineered-structure/functional-interface requirements, exact activation/exclusions, five render gates, and cyborg/biomimicry/sensor-animal rejects remain unchanged [19185–19261]. Where a human is present, the independent-body gate still requires separation from that human [19244–19246]. The new phrase is not sufficient by itself to establish the whole profile.
- Candidate inspection: optional concept terms still include `separate human operator` [19153–19163], and `bio_tissue_substrate_surface` is applicable to robot/object candidates [tags:81329]. Neither establishes a universal need for a person. The former remains an optional steering limitation, not fixed by this leaf.

Direct in-memory evidence: four operator-free material/body/interface bindings pass before and after; the proposed separation phrase fails before and passes after. All three old separation alternatives still pass. Three noncanonical controls still fail that field. These are binding checks, not proof that every semantically wrong image or phrase is rejected.

## 2. Summoner local-consequence composition: ACCEPT

Leaf: replace only the composition consequence fragment with `local dust, light, shadow, or displaced-object response`.

- Current definition requires an operator, complete bounded source, separate arriving entity, directional response, and local consequence in one causal event [base registry:25471]. The required `arrival_consequence` component already explicitly allows dust, light, shadow, or displaced objects responding locally to the arrival [25514–25519]. The same category appears in the mandatory evidence anchor [25581–25585].
- Current composition is narrower, naming only contact shadow or displaced material [25548]. The replacement reconciles composition with that existing source contract; it introduces no new consequence category or phrase list.
- Operator, full boundary, emerging entity, directional gesture/gaze and readable cause-and-effect frame remain explicit. Definition, five mandatory components, evidence fields/minima, gates, and companion/empty-circle/corpse/generic-glow rejects are untouched [25476–25527;25549–25620]. A local light response must participate in the arrival event; ordinary spell glow remains disallowed.
- Candidate examples legitimately favor dust/contact shadows: `summoner_practitioner_role_model` [tags:10563], `summoning_distinct_entity_arrival` [29918], `summoned_entity_contact_shadow_forming` [74092], and `summoning_displaced_dust_trace` [94607]. These are compatible examples, not exhaustive restrictions. The bounded anchor also allows local reflections [44833].
- Existing provenance calls Macbeth a historical operator–apparition example, not a universal modern summoner definition (`docs/research-evidence/photo-prompt/fantasy-visual-semantics-20260901/source-research.md`, §3.3). Acceptance rests on the current authored contract, not an assertion that this literary example independently proves every permitted effect.

## Canonical-evidence and result limits

The validator matches declared anchor text and counts unique non-stopword content tokens (`scripts/prompt_generator.py:6729–6790`); composed audit additionally requires literal prompt binding and declared anchors (`scripts/audit_composed_prompt.py:1760–1814`). Therefore:

- New biohybrid alternative only permits its exact canonical phrase, not arbitrary equivalent prose. The other body/material/functional anchors and their word minima still apply.
- Summoner consequence remains the single canonical anchor `dust light shadow or displaced objects respond locally to the arrival`. It has eight content words and needs ten. Adding concrete `amber ripples` makes the binding pass; a sufficiently long natural localized-reflection paraphrase still fails the anchor check. This pre-existing limitation is not repaired or expanded here.
- The in-memory copies preserve exact lookup, positive semantic retrieval text and BM25F fields for both profiles. Thus neither leaf supports a claim of natural retrieval improvement. The full composite registry hash does change, so a later authorized implementation must refresh its hash-bound derived index; these two leaves do not require new vectors because their embedding text is unchanged.
- No index rebuild, full candidate-pack integration, end-to-end generation, or pixel review was performed. Tissue viability/function and magical origin remain beyond what an image independently proves, consistent with the existing source research.

## Artifacts and references

Paths above for `base registry`, `tags`, and `scripts` are relative to `skills/photo-prompt-image-generator/` as `assets/photo_prompt_visual_obligations.json`, `assets/photo_prompt_tags.json`, and `scripts/…` respectively. Line numbers refer to the verified HEAD.

- `review_probe.py`: reproducible, read-only source probe; proposals applied only to deep copies
- `review-probe-results.json`: exact versions/hashes, unchanged-field checks and before/after binding results
- `review-probe.log`: probe output
- Additional reviewed sources: `tests/test_photo_humanlike_semantics.py`, `tests/test_photo_fantasy_visual_semantics.py`, their five-arm fixtures, and `docs/research-evidence/photo-prompt/humanlike-entities-20260831/source-research.md` (Biohybrid robot)

No other exception growth or relaxation is accepted by this review.
