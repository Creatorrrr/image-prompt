import json,sys,hashlib
from pathlib import Path
P=Path(__file__).parent;R=P.parent/'image-prompt';A=R/'skills/photo-prompt-image-generator/assets';sys.path.insert(0,str(A.parent/'scripts'))
import prompt_generator as pg
import build_visual_profile_index as bi
D=P/'nonhuman-source-alternative-validation';D.mkdir(exist_ok=True)
f=A/'photo_prompt_visual_obligations.json';ip=A/'photo_prompt_visual_profile_index.json';before=f.read_text();ibefore=ip.read_text();raw=json.loads(before);old=json.loads(ibefore);text=before
ids=['biohybrid_robot_living_synthetic_integration','summoner_distinct_entity_arrival'];profiles={p['id']:p for p in raw['profiles']}
base=json.load(open(P/'animal-morphology-audit/evidence.json'));assert hashlib.sha256(f.read_bytes()).hexdigest()==base['source_sha256']
(D/'baseline-profiles.json').write_text(json.dumps([profiles[k]for k in ids],ensure_ascii=False,indent=2)+'\n')
(D/'original-index.json').write_text(ibefore)
needle='"separate human operator"\n          ]';assert text.count(needle)==1;text=text.replace(needle,'"separate human operator",\n            "complete independent robot body"\n          ]')
leaves=json.load(open(P/'animal-morphology-audit/proposed-leaves.json'));l=next(x for x in leaves if x['operation']=='replace');assert text.count(l['before'])==1;text=text.replace(l['before'],l['after'])
try:
 f.write_text(text);reg=pg.load_visual_obligation_registry(f);vectors=bi.reusable_vectors([ip],reg,provider=pg.SEMANTIC_PROVIDER,model=pg.SEMANTIC_MODEL_ID,dimensions=pg.DEFAULT_SEMANTIC_DIMENSIONS)
 assert len(vectors)==len(reg['profiles'])==1507,(len(vectors),len(reg['profiles']))
 new=pg.build_visual_profile_index_payload(reg,vectors=vectors);changes=[k for k in old if old[k]!=new[k]];assert changes==['registry_sha256'],changes
 bi.write_payload(ip,new);pg.load_visual_profile_index(ip,reg)
 result={'only_index_change':changes,'unchanged_entries':len(vectors),'all_vectors_texts_bm25f_identical':True,'provider_calls':0,'source_before_sha256':hashlib.sha256(before.encode()).hexdigest(),'source_after_sha256':hashlib.sha256(text.encode()).hexdigest(),'source_profile_ids':ids}
 (D/'index-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
except Exception:
 f.write_text(before);ip.write_text(ibefore);raise
