# Animal and nonhuman morphology DATA audit

## Result

Inspected 13 source profiles and 32 related current candidate records on HEAD `3c3b3a649afc04a5b39abc23a0e57084ba34fec2`. Recommend two bounded DATA corrections for independent review, not immediate integration:

1. `biohybrid_robot_living_synthetic_integration`: admit a complete independent robot-body evidence alternative when no operator is depicted. Its mandatory fifth evidence field currently accepts only phrases asserting a human/operator relation.
2. `summoner_distinct_entity_arrival`: preserve its explicitly authored local-light consequence alternative in the composition instruction instead of demanding contact shadow or displaced material.

The other 11 profiles are KEEP. No source, candidate, index, runtime, test, fixture, or remote write was made. No paid API or image generation was used. Exact records, JSON pointers, source hash, current candidates, counterexamples, materialized obligations, and per-control outcomes are in `evidence.json`. Exact proposed source leaves are in `proposed-leaves.json`.

This is source consistency and consumer-binding evidence. It is not a claim of image-quality improvement, pixel failure, changed natural-language retrieval, or public-CLI before/after success.

## Reproduce

From the workspace containing `image-prompt`:

    PYTHONDONTWRITEBYTECODE=1 image-prompt/.venv/bin/python daylong-progress-20261002/animal-morphology-audit/probe.py

The probe reads the production registry and uses the existing direct matcher, component matcher, obligation materializer, and visual-intent binding validator. The one evidence-array addition is applied only to a deep copy in memory. Every input phrase is held fixed before and after. The script writes only adjacent audit artifacts.

## 1. Biohybrid: robot independence does not require a depicted operator

Source: `skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations.json`, `/profiles/96`, begins at line 19031 in the inspected revision.

Exact source support:

- Definition: “A biohybrid robot functionally integrates living biological material such as cells or contractile muscle with engineered synthetic structures, electrodes, control components, or scaffolds.”
- Required component IDs are `living_biological_component`, `engineered_synthetic_component`, `functional_interface`, and `independent_robot_body`. The last group accepts “independent non-humanoid robot”, “robot remains separate from the operator”, OR “complete manta-shaped machine body”.
- Composition: “Keep the complete independent robot, its living tissue, its engineered scaffold, and the load-bearing interface visible together.”
- Gate `vo_biohybrid_independent_robot_body`: “The complete biohybrid reads as an independent robot body separate from any human operator.” The word “any” is conditional; neither the definition nor required component list requires a person to appear.
- Repository provenance, `docs/research-evidence/photo-prompt/humanlike-entities-20260831/source-research.md:33–38`, identifies the same four elements and rejects cyborg implants and sensor-equipped animals. It does not require an operator in frame.

Conflicting leaf:

`/evidence_requirements/operator_separation_phrase/must_mention_any` contains only:

- “cables end at the robot rather than entering the engineer's body”
- “robot remains separate from the operator”
- “separate human operator”

The field is mandatory. All three alternatives posit a human/operator relation, whereas the same profile's body component and composition permit an independently framed nonhuman machine.

Frozen counterexample request:

> A biohybrid robot swims alone inside a laboratory tank. Living muscle tissue contracts against a synthetic scaffold; only the complete independent machine is in frame, with no person or operator present.

The production direct matcher hard-activates this exact profile. A separate label-free, operator-free probe using the existing four component phrases also passes the production component matcher. The full five-binding diagnostic supplies living muscle, engineered structure, and their functional coupling; exactly the operator-boundary field fails:

> The complete independent robot body occupies the water alone with tissue and scaffold contained within its own outline

Proposed minimal correction:

Append “complete independent robot body” to the existing fifth field's `must_mention_any` array. This is a source-supported evidence alternative, not an activation alias or generic robot definition. Keep all current operator phrases, minima, mandatory fields, activation rules, components, composition, gates, and reject substitutes unchanged. No new obligation is added and no field is removed.

Observed focused controls:

- Operator-free five-field evidence: 4/5 current bindings pass; 5/5 pass after the one in-memory addition using the same evidence
- Three pre-existing operator/cable/separate-human variants: pass before and after
- Embedded cyborg boundary, cropped partial body, generic device boundary: fail before and after
- Synthetic-biomimic text substituted for living-tissue evidence and missing functional-interface text: fail before and after

These are 13 function-level binding checks per variant, not a semantic classifier for every possible cyborg sentence. Full source reject boundaries remain intact.

Counterevidence preserved: the existing five-arm humanlike pixel fixture intentionally depicts an operator and uses an operator facial reference. That is a supported scene variant. It is not proof that a person is mandatory in every independent-robot scene. Current ordinary candidate material rows such as `bio_tissue_membrane_texture` and `bio_tissue_substrate_surface` do not establish an obligatory operator. Removed legacy preset IDs found in archival indexes were not treated as current candidates.

Suggested qualification before integrating:

- Freeze actual public-CLI packs for operator-free robot, operator-present robot, cable-linked separated operator, and explicit no-people request
- Reuse exact authored core, evidence, source intent, and negatives on both sides
- Check a complete composed/runtime audit, distinct-phrase and overlap policy, all other evidence fields, gate order, reject substitutes, candidate membership/order, and unchanged core/locks
- Add missing-living-tissue, missing-interface, cropped-body, human-cyborg, and sensor-backpack-animal controls without lowering any test minima or matching rules
- Rebuild only registry-derived metadata using the project's normal process; inspect semantic text before deciding whether any real vector refresh is necessary

## 2. Summoner: preserve local-light arrival consequence

Source: the same registry, `/profiles/133`, begins at line 25454.

Exact source support:

- Definition requires operator, bounded source, distinct arrival, directional response, and “local consequence” forming one causal event
- Required group `arrival_consequence` explicitly accepts “dust light shadow or displaced objects respond locally to the arrival”
- `/evidence_requirements/consequence_phrase/must_mention_any/0` repeats that exact alternative
- The five existing render gates preserve operator, source, distinct entity, directional relation, and rejection of companion portraits, empty circles, corpse animation, and generic glow

Conflicting leaf:

> Keep the operator, complete source boundary, emerging entity, directional gesture or gaze, and contact shadow or displaced material inside one readable cause-and-effect frame.

The last requirement excludes the profile's own light-only branch. The current production materializer copies it unchanged into the hard obligation.

Frozen counterexample request:

> A fantasy summoner causes a separate feathered creature to emerge from a complete circular threshold above a glazed plinth. Her gesture and gaze point to the arriving creature. Its arrival produces only a localized violet reflection on the plinth; there is no contact shadow or displaced material.

The production direct matcher hard-activates the summoner profile. Existing consequence evidence passes unchanged:

> Dust light shadow or displaced objects respond locally to the arrival as a violet reflection spreading across the adjacent glazed plinth

This source-contract probe intentionally includes the existing literal alternative phrase so the evidence matcher is not the confounder. It is not offered as natural prose retrieval evidence. The localized reflected-light event is tied to the distinct entity's arrival and receiver, not a generic aura or empty spell glow.

Proposed minimal correction:

Replace only “contact shadow or displaced material” with “local dust, light, shadow, or displaced-object response” in the composition instruction. Leave every other leaf unchanged. New full value:

> Keep the operator, complete source boundary, emerging entity, directional gesture or gaze, and local dust, light, shadow, or displaced-object response inside one readable cause-and-effect frame.

Candidate counterevidence: `summoned_entity_contact_shadow_forming` and `summoning_displaced_dust_trace` are intentionally narrow candidate variants, so KEEP both. The broad action/semantic profile admits a localized light consequence; no candidate must be broadened to expose it.

Suggested same-evidence qualification:

- Freeze public-CLI/full-composition cases for local reflected light, contact shadow, displaced dust, and displaced object
- Only the target composition string should change; bindings, gates, reject substitutes, activation, candidate records, and core remain identical
- Negative controls: no living operator, no bounded source, duplicated operator rather than distinct entity, no directional relation, no local consequence, empty circle, unrelated companion, and generic glow alone must remain rejected by the unchanged complete contract
- There is no automatic image-gate result in this audit; use human semantic review to assess the wording, and preserve that evidentiary boundary

## Bounded KEEP list

All locations below are JSON pointers in `photo_prompt_visual_obligations.json`. `evidence.json` includes each full record and related candidate rows, enabling exact component/evidence/gate comparison.

| Profile and source pointer | Decision and exact source boundary | Candidate/gate comparison |
| --- | --- | --- |
| `wyvern_two_leg_wing_tail_topology`, `/profiles/137` | KEEP. Definition explicitly says “A narrow heraldic-fantasy wyvern topology” and “an explicit user definition overrides this default”. Two wings, two weight-bearing hind legs, no separate forelegs, and one long tail are authored together. | `heraldic_wyvern_subject` preserves topology and user override. `wyvern_spreading_wings_two_leg_profile` deliberately exposes both legs and has ground-bearing posture. Full-body and non-overlap requirements support the authored count proof rather than invent a human-contact condition. Do not broaden to generic flying dragons. |
| `griffin_eagle_lion_topology`, `/profiles/138` | KEEP. Eagle head, paired wings and avian forequarters join lion rear anatomy. “avian structure or taloned forefeet” remains an alternative. | `griffin_eagle_lion_subject` and `griffin_turning_eagle_lion_profile` preserve the lion rear and continuous junction. Composition/gates do not force the taloned branch or horse rear. |
| `hippogriff_eagle_horse_topology`, `/profiles/139` | KEEP. Eagle front joins horse barrel, rear hooves, and horse tail; avian or taloned forestructure remains allowed. | `hippogriff_eagle_horse_subject` and its turn action keep the horse rear. Gates distinguish griffin, pegasus, and costume wings without owner changes. |
| `hydra_multi_neck_single_body`, `/profiles/140` | KEEP. “three or more separately rooted, spatially readable necks and heads” belong to a single shared body. | Subject and fanning action preserve three-plus complete neck paths, separate roots, and distinct heads. Full- or upper-body wording retains scale proof. The scale component's feet/shadow/nearby-object wording is an authored grounded diagnostic; this audit does not infer an unsupported flying or arbitrarily cropped variant. |
| `phoenix_rebirth_causal_cycle`, `/profiles/141` | KEEP. Definition permits “an exhausted former body or ash nest” but intentionally requires connected ash-to-feather transition, directional rise, and localized consequence. | Subject, emergence action, trace, composition and gates retain ash-nest/charred/former-state alternatives at their relevant scopes. The `...ash_nest` action/trace may be narrower than the profile. Do not broaden the profile to a generic flaming bird. |
| `familiar_practitioner_reciprocal_bond`, `/profiles/142` | KEEP. “animal-like or spirit helper” plus reciprocal attention, shared signal/medium, and joint task consequence. | Signal alternatives include token, thread, reflection, sound cue, or light path in both component and requirement; composition requires one signal, not physical token contact. `familiar_shared_token_prop` is a legitimate narrower optional prop. Existing black-cat familiar prop does not redefine the profile or satisfy the relation by species alone. |
| `golem_constructed_material_agency`, `/profiles/135` | KEEP. An assembled nonliving body with material continuity, construction evidence, grounded motion, and a task consequence. | Constructed subject, load-moving action and task trace preserve material ownership. Hand/object contact is the nonhuman construct's own action, not an unrelated human requirement. No proposed broadening to inert statues or metal robots. |
| `living_armor_hollow_articulated_agency`, `/profiles/136` | KEEP. A complete moving shell, articulated joints, hollow interior, grounded motion and consequence. | Component “open visor neck gap or gauntlet opening” remains an alternative through composition's “open visor or another empty opening” and gate “At least one opening”. The ground-contact display is an authored narrow staging choice; this audit does not claim an aerial/cropped suit is a required positive. |
| `anthrobot_microscopic_ciliated_biobot`, `/profiles/94` | KEEP. “Human cellular origin does not imply a human face, limbs, humanoid silhouette, metal chassis, or android scale.” | Microscopy, cilia, multicellular texture and motility requirements remain organism-owned. Human-airway-cell origin is not incorrectly used to require a person. The microscope/scale bridge is deliberate source evidence. |
| `human_cellular_chimera_lineage`, `/profiles/93` | KEEP, adjacent confusion control. Definition distinguishes cellular lineage from animal-part patchwork. | Required coherent human body and scientific readout belong to this specifically human profile. Animal-head and fantasy-chimera rejects are intentional distinctions, not missing nonhuman morphology coverage. |
| `continuous_metamorphosis_source_target_bridge`, `/profiles/177` | KEEP. One body has source form, target form, and a continuous anatomical/material/topological bridge with directional residue or trace. | Composition and gates preserve alternatives and same-subject identity. Contact, tension, residue, and motion are not changed to mandatory human contact. Before/after pairs, attached decorations and completed target-only cases remain rejected. |

## Coverage and limitations

Read the repository skill and maintenance guidance. No `AGENTS.md` was found under the inspected workspace; `.agents/skills/photo-prompt-image-generator` points to the read skill. Only current source records and relevant repository provenance were used to decide scope; no external taxonomy claim or current public-web validation is asserted.

The KEEP decisions are bounded source-contract judgments, not proof of all real-world scene coverage. Operator-free and local-light repros isolate actual DATA leaves from retrieval limitations. No alias expansion, new profile, runtime matcher change, threshold change, test weakening, or natural-language paraphrase catalogue is proposed.

Original unmodified fantasy, humanlike and imaginal test suites were run; terminal result is recorded in `existing-tests.log`. They establish current-baseline regression coverage only, not hypothetical post-change completeness.

## Terminal verification

- Original focused suites: 22 tests, 209.372 seconds, OK
- The test process began at the pinned 3c3b3a64 revision before a separately managed upstream merge; checkout ended at `18a46eb413a40ace4eb7b8913755ff739ac5c3cb`. Do not attribute it to a clean single-HEAD/full-regression run. The counterexample probe was not rerun.
- Main registry bytes stayed identical to the frozen source hash; 0 of the 32 captured related candidate rows changed during the audit.
- `verification.json` records that timing and source/candidate comparison. The parent should independently qualify the proposed leaves against its integration baseline.
