"""Read-only DATA contract audit. Writes only adjacent audit artifacts; no APIs."""
from pathlib import Path
import copy, hashlib, json, subprocess, sys
OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[1]/'image-prompt'
ASSETS=ROOT/'skills/photo-prompt-image-generator/assets'
sys.path.insert(0,str(ROOT/'skills/photo-prompt-image-generator/scripts'))
import prompt_generator as pg
IDS=[
'wyvern_two_leg_wing_tail_topology','griffin_eagle_lion_topology',
'hippogriff_eagle_horse_topology','hydra_multi_neck_single_body',
'phoenix_rebirth_causal_cycle','familiar_practitioner_reciprocal_bond',
'golem_constructed_material_agency','living_armor_hollow_articulated_agency',
'summoner_distinct_entity_arrival','biohybrid_robot_living_synthetic_integration',
'anthrobot_microscopic_ciliated_biobot','human_cellular_chimera_lineage',
'continuous_metamorphosis_source_target_bridge']
source=ASSETS/'photo_prompt_visual_obligations.json'
raw=json.loads(source.read_text())
registry=pg.load_visual_obligation_registry(source)
profiles={p['id']:p for p in registry['profiles']}
source_ids={p['id']:i for i,p in enumerate(raw['profiles'])}
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()

def outcome(profile,field,phrase):
 try:
  pg.validate_visual_intent_binding(obligation_index=0,field=field,phrase=phrase,requirement=profile['evidence_requirements'][field])
  return {'pass':True}
 except ValueError as e:return {'pass':False,'error':str(e)}

def materialize(pid,request):
 rows=[{'source':'concept_lock','text':request,'polarity':'required','priority':'critical','mandatory':True}]
 matches=pg.candidate_pack_auto_visual_obligation_matches(registry,rows)
 assert pid in matches,(pid,matches)
 return {'request':request,'hard_matches':matches,'materialized_obligation':pg.candidate_pack_visual_profile_obligation(profiles[pid],registry,activation_source='explicit_request_semantics',source_intent_ids=['audit'],request_text=request,context_text=request)}

pid='biohybrid_robot_living_synthetic_integration'
p=profiles[pid]
q=copy.deepcopy(p)
anchor='complete independent robot body'
q['evidence_requirements']['operator_separation_phrase']['must_mention_any'].append(anchor)
request='A biohybrid robot swims alone inside a laboratory tank. Living muscle tissue contracts against a synthetic scaffold; only the complete independent machine is in frame, with no person or operator present.'
case=materialize(pid,request)
bindings={
'independent_robot_phrase':'An independent non-humanoid robot spreads its flexible fins inside the clear laboratory tank',
'living_tissue_phrase':'Visible living muscle bands remain pink and wet inside the transparent ribbed frame',
'synthetic_structure_phrase':'A transparent synthetic scaffold supports the electrodes and flexible fins around the tissue',
'functional_interface_phrase':'Contracted tissue bends the scaffold along the inner fin while the outer edge remains extended',
'operator_separation_phrase':'The complete independent robot body occupies the water alone with tissue and scaffold contained within its own outline'
}
controls=[{'name':'operator_free_complete_body','field':k,'phrase':v} for k,v in bindings.items()]
controls += [
{'name':'existing_operator_separation','field':'operator_separation_phrase','phrase':'The robot remains separate from the operator across the tank glass and the visible gap'},
{'name':'existing_cable_boundary','field':'operator_separation_phrase','phrase':"The cables end at the robot rather than entering the engineer's body across the visible control desk"},
{'name':'existing_separate_human','field':'operator_separation_phrase','phrase':'A separate human operator stands at the remote control desk behind the tank'},
{'name':'embedded_cyborg_boundary_absent','field':'operator_separation_phrase','phrase':"Living muscles and synthetic wires enter the engineer's forearm through an implant"},
{'name':'partial_body_only','field':'operator_separation_phrase','phrase':'A cropped polymer fin and one rib fill the laboratory photograph'},
{'name':'generic_robot_only','field':'operator_separation_phrase','phrase':'A mechanical device rests beside a laboratory water tank'},
{'name':'synthetic_biomimic_missing_living_tissue','field':'living_tissue_phrase','phrase':'Pink painted molded plastic bands decorate the synthetic chassis'},
{'name':'no_functional_interface','field':'functional_interface_phrase','phrase':'Living tissue lies nearby but never joins the engineered scaffold'}]
for c in controls:
 c['before']=outcome(p,c['field'],c['phrase'])
 c['after_in_memory_only']=outcome(q,c['field'],c['phrase'])
case.update({'bindings':bindings,'controls':controls,'before_failure_fields':[c['field'] for c in controls[:5] if not c['before']['pass']], 'after_failure_fields':[c['field'] for c in controls[:5] if not c['after_in_memory_only']['pass']]})
assert case['before_failure_fields']==['operator_separation_phrase']
assert case['after_failure_fields']==[]
for c in controls[5:8]:assert c['before']['pass'] and c['after_in_memory_only']['pass']
for c in controls[8:]:assert not c['before']['pass'] and not c['after_in_memory_only']['pass']

# Real source classification remains independent of the proposed evidence-only alternative.
component_text='An independent non-humanoid robot contains visible living muscle bands and a synthetic scaffold while contracted tissue bends the scaffold.'
case['component_probe']={'text':component_text,'match':pg.candidate_pack_visual_component_match(p,component_text)}
assert case['component_probe']['match']

summoner_id='summoner_distinct_entity_arrival'
summoner_request='A fantasy summoner causes a separate feathered creature to emerge from a complete circular threshold above a glazed plinth. Her gesture and gaze point to the arriving creature. Its arrival produces only a localized violet reflection on the plinth; there is no contact shadow or displaced material.'
summoner=materialize(summoner_id,summoner_request)
sp=profiles[summoner_id]
summoner['source_alternative']=next(g for g in sp['semantics']['component_semantics']['groups'] if g['id']=='arrival_consequence')
summoner['frozen_consequence_phrase']='Dust light shadow or displaced objects respond locally to the arrival as a violet reflection spreading across the adjacent glazed plinth'
summoner['existing_binding_result']=outcome(sp,'consequence_phrase',summoner['frozen_consequence_phrase'])
assert summoner['existing_binding_result']['pass']
summoner['contradictory_composition_fragment']='contact shadow or displaced material'
assert summoner['contradictory_composition_fragment'] in summoner['materialized_obligation']['composition_instruction']
summoner['proposed_composition']=sp['composition_instruction'].replace('contact shadow or displaced material','local dust, light, shadow, or displaced-object response')

# All inspected source rows, related current candidates, and research-source references.
tags=json.loads((ASSETS/'photo_prompt_tags.json').read_text())
patterns=('wyvern','griffin','hippogriff','hydra','phoenix','familiar','golem','living_armor','summon','bio_tissue','biohybrid','metamorphosis')
candidates=[{'slot':slot,'json_pointer':f'/slots/{slot}/{i}','record':row} for slot,rows in tags['slots'].items() for i,row in enumerate(rows) if any(w in row['id'] for w in patterns)]
evidence={
 'baseline_head':head,'scope':'read-only source-consistency audit; no source edits, paid API calls, index refresh, or pixel claims',
 'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
 'inspected_profiles':[{'profile_id':pid,'json_pointer':f'/profiles/{source_ids[pid]}','source_profile':profiles[pid]} for pid in IDS],
 'related_current_candidates':candidates,
 'biohybrid_operator_free_counterexample':case,
 'summoner_local_light_counterexample':summoner,
 'proposals':[
 {'profile_id':pid,'operation':'append','path':'/evidence_requirements/operator_separation_phrase/must_mention_any','value':anchor},
 {'profile_id':summoner_id,'operation':'replace','path':'/composition_instruction','before':sp['composition_instruction'],'after':summoner['proposed_composition']}],
 'unchanged_fields_in_biohybrid_trial':['activation','semantics','concept_candidate','composition_instruction','required_evidence_fields','render_gates','reject_substitutes','runtime_expression'],
 'limitations':['Function-level binding and materialized-obligation proofs only; no public CLI before/after pack yet','The summoner contradiction is semantic composition wording, not an automatic pixel-gate failure','The proposed source changes are in memory only and are not integrated']}
for field in evidence['unchanged_fields_in_biohybrid_trial']:assert p[field]==q[field]
(OUT/'evidence.json').write_text(json.dumps(evidence,ensure_ascii=False,indent=2)+'\n')
(OUT/'proposed-leaves.json').write_text(json.dumps(evidence['proposals'],ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'inspected_profiles':len(IDS),'related_candidates':len(candidates),'biohybrid_binding_controls':len(controls),'biohybrid_before_failures':case['before_failure_fields'],'biohybrid_after_failures':case['after_failure_fields'],'summoner_binding_pass':summoner['existing_binding_result']['pass'],'head':head},indent=2))
