# Optional owner-context guard audit

## Recommendation

Defer the advisory owner-context repair from this DATA-only lighting change. The existing data contract has no dedicated positive owner-context guard applied to BM25F/embedding discovery that preserves broad natural semantic recall. Keep both activation flags unchanged. This is an advisory retrieval defect with a demonstrated positive-recall tradeoff, not a reason to reject the lighting material-response correction or to retain an unrelated prior rank-eight candidate.

A responsible broader follow-up would separate owner/context suitability for optional discovery from complete-form evidence for exact/hard activation. It needs a runtime/schema design decision and recall qualification, including independent unlabeled textile product scenes, seated support prose, bilingual positives, mixed-owner scenes, and nonhuman body/contact negatives. This audit proposes no implementation, thresholds, phrase exceptions, or new runtime fields.

## Reproducible observations

`reproduce.py` imports the current production consumer, reads genuine runtime data and the existing index, and calls `resolve_visual_profile_hits` with real BM25F. No provider calls, query vectors, replacement vectors, patched functions, index changes, or repository edits occur. The frozen matte-soft input is reused from the earlier actual resolver proof; other prose below is independently authored diagnostic input. These are resolver-level probes, not new complete public-CLI pack qualifications. All eight full resolver results, inputs, compiled profiles, HEAD and file hashes are in `evidence.json`.

Run from the workspace:

    image-prompt/.venv/bin/python daylong-progress-20261002/optional-owner-context-audit/reproduce.py

| Probe | Relevant profile | Current actual hit | Existing component proof | If component-required |
| --- | --- | --- | --- | --- |
| Frozen matte plaster pear | Neither | rb_support_compression optional BM25F | None for either | Blocks false positive |
| Independent unlabeled textile product | y2kr_velour | Optional BM25F | None | Drops relevant positive |
| Explicitly labeled velour swatch | y2kr_velour | Optional BM25F | Literal paraphrase `Velour` | Preserves labeled positive |
| Independent natural seated-support English | rb_support_compression | Optional BM25F | None | Drops relevant positive |
| Independent natural seated-support Korean | rb_support_compression | No top-eight hit | None | Cannot repair current recall gap |
| Nonhuman plaster sphere on hard stone | Neither | rb_support_compression optional BM25F | None | Blocks false positive |
| Verbatim velour definition control | y2kr_velour | Exact, hard eligible | Complete component | Passes |
| Verbatim support definition control | rb_support_compression | Exact, hard eligible | Complete components | Passes |

Independent textile positive, no adult or person: “A folded textile swatch lies on a display table. Closely cropped soft fibers form a dense low nap; stroking the surface reverses the light and dark bands, leaving a subdued broad glow.”

Independent support positive: “An adult sits on a soft upholstered cushion. The seat sinks slightly directly beneath their weight, and trouser folds gather around the point of contact while the fabric stays above the cushion surface.”

Independent negative: “A chalky plaster sphere rests on a smooth stone pedestal. Its rounded body meets the hard base; soft illumination spreads over the matte surface.”

The English support positive preserves body, soft support, localized deformation, and clothing/contact coherence without copying any full stored component or paraphrase. The textile positive preserves short nap, directional shading, and subdued sheen without a product label. Both already make the actual top-eight, so the loss is concrete rather than hypothetical relevance alone. The component switch's rejection follows directly from the production admissibility predicate, without modifying the registry/index to manufacture a result.

## Why the available DATA knobs do not solve this cleanly

1. `activation.context_disambiguation.any_terms` is an existing positive lexical gate for exact matching. However, `resolve_visual_profile_hits` expressly passes `require_positive_context_terms=False` when constructing semantic/BM25F admissible IDs. It therefore cannot serve as a positive owner guard in the affected lane. The evidence includes illustrative in-memory helper calls with `textile` or `cushion` as positive context terms: exact-context checks can reject a missing term while advisory checks still accept the same context. These helper demonstrations are explicitly hypothetical, not index-backed proposed variants.
2. `semantic_discovery_requires_component_evidence=true` uses `candidate_pack_visual_component_match`. For these authored profiles, `compile_visual_profile` projects all authored components into required component groups. Velour has one complete-form phrase; support has three full relational phrases. The helper alternatively accepts literal stored paraphrase examples. Independent relevant prose above fails both paths.
3. `requires_adult_character=true` would suppress person-free product velour and equates an owner relation with adult status. For support, adult presence is not evidence of seated contact, soft support, depression, or matching clothing; a standing adult by unrelated plaster would satisfy that flag. The current source specifies no age restriction. This is not a principled owner guard.
4. `exclude_if_any_terms` is a negative substring-style lexical filter, not owner binding. Adding plaster, paper, sphere, etc. would accumulate scene exceptions and wrongly suppress valid mixed scenes containing those objects alongside a relevant textile/support owner.
5. Broadening component match terms or paraphrases can recover individual examples but changes complete-form classification/hard semantics or creates a phrase catalogue. It does not add relation-aware owner binding. `visual_components`, `claim_limits`, `reject_substitutes`, candidate relation metadata and authored render gates describe meaning/review obligations; none is consulted as a positive owner classifier by this advisory eligibility predicate.

## Actual consumer and schema locations

- `skills/photo-prompt-image-generator/scripts/validate_photo_prompt_dictionary.py:1572–1580`: permitted activation fields; `:1657–1662`: context-disambiguation keys
- `scripts/prompt_generator.py:6196–6250`: shared context applicability; positive terms apply only when `require_positive_context_terms` is true
- `scripts/prompt_generator.py:6494–6514`: semantic admissibility calls positive context check with false, then optional component-proof switch
- `scripts/prompt_generator.py:6520–6527`: BM25F uses that admissible set
- `scripts/prompt_generator.py:7095–7169`: component-group lexical matching and literal paraphrase fallback
- `scripts/visual_profile_contracts.py:71–147`: authored components project to all-required semantic groups
- `scripts/prompt_generator.py:6420–6450,6605–6633`: adult gate and hard/advisory status remain separate; retrieval-only hits cannot impose hard obligations

All shortened `scripts/` paths above are beneath `skills/photo-prompt-image-generator/`.

## Source/provenance check

Current source profiles are in `photo_prompt_visual_obligations_y2k.json` (`y2kr_velour`) and `photo_prompt_visual_obligations_realistic_background.json` (`rb_support_compression`). Both explicitly set adult requirement and discovery component requirement to false.

The realistic-background generator at `docs/research-evidence/photo-prompt/realistic-background-implementation-20260912/build_data.py:111–118` authors these permissive flags deliberately. Its research catalog, `realistic-background-20260912/visual-catalog.md:425–437`, describes body/seat/clothing ownership, seated or leaning visible contact, load-localized compression only on soft material, and labels the relation a design/mechanics hypothesis without direct empirical evidence. It does not establish adult-only ownership.

The Y2K report at `docs/research-evidence/photo-prompt/y2k-style-20260927/report.ko.md:107–118` distinguishes short dense pile from uncut loops and discusses its technical sources. Current velour claim limits and render gate bind the morphology to a selected textile patch/material close-up, not a person or garment wearer. A person-free swatch is therefore an appropriate positive.

No external scientific validation is asserted here; this is source-contract and consumer behavior diagnosis using repository provenance.

## Scope and limitations

The observed pre/post rank-eight swap is retained as documented in `../reflection-material-audit/collateral-risk/REPORT.md`. This audit reproduces the current support-compression false positive, not a new before/after claim. The original lighting collateral analysis established unchanged frozen core, slots and ordered hard IDs. No composed adoption or rendered image is assessed here. The Korean positive already lacks a current top-eight result; it must not be described as a newly introduced loss. No paid embedding lane was exercised, although the same admissibility filter precedes it in source.

Repository baseline: 6adabfe4 plus the parent's pending lighting changes, as hashed in evidence. Only files in this external audit directory were created.
