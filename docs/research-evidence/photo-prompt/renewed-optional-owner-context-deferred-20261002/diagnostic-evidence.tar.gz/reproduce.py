import json, sys, hashlib, copy, subprocess
from pathlib import Path
O=Path(__file__).resolve().parent
R=O.parents[1]/'image-prompt'; S=R/'skills/photo-prompt-image-generator';sys.path.insert(0,str(S/'scripts'))
import prompt_generator as pg
D=pg.load_runtime_data(); reg=D[pg.VISUAL_OBLIGATIONS_DATA_KEY];idx=D[pg.VISUAL_PROFILE_INDEX_DATA_KEY]
P={p['id']:p for p in reg['profiles']}; ids=['y2kr_velour','rb_support_compression']
old=json.loads((O.parent/'reflection-material-audit/collateral-risk/after-rank-proof.json').read_text())
cases=[
 ('matte-soft-frozen',None,False,old['source_rows'],old['query_fields']),
 ('textile-product-independent','y2kr_velour',False,'A folded textile swatch lies on a display table. Closely cropped soft fibers form a dense low nap; stroking the surface reverses the light and dark bands, leaving a subdued broad glow.'),
 ('textile-product-labeled','y2kr_velour',False,'Photograph a folded velour textile swatch on an otherwise empty product table. Its short soft pile changes brightness with the direction of the fibers.'),
 ('seated-support-independent','rb_support_compression',True,'An adult sits on a soft upholstered cushion. The seat sinks slightly directly beneath their weight, and trouser folds gather around the point of contact while the fabric stays above the cushion surface.'),
 ('seated-support-independent-ko','rb_support_compression',True,'성인이 푹신한 방석에 앉아 있다. 체중이 실린 자리만 살짝 눌리고, 바지 주름은 엉덩이와 좌면이 맞닿는 부분을 따라 모인다. 몸과 천이 좌면을 뚫지 않는다.'),
 ('nonhuman-negative',None,False,'A chalky plaster sphere rests on a smooth stone pedestal. Its rounded body meets the hard base; soft illumination spreads over the matte surface.'),
]
for pid in ids: cases.append(('definition-control-'+pid,pid,pid.startswith('rb_'),P[pid]['semantics']['definition']))
results=[]
for case in cases:
 name,target,adult,*rest=case
 if len(rest)==2: sources,fields=rest
 else:
  txt=rest[0]; sources=[{'source':'concept_lock','text':txt,'polarity':'required'},{'source':'authorial_core_baseline','text':txt,'polarity':'advisory'}];fields={'active_request':[txt],'baseline_prompt':[txt]}
 context=' '.join(x['text'] for x in sources)
 result=pg.resolve_visual_profile_hits(reg,sources,visual_profile_index=idx,query_fields=fields,adult_context=adult)
 rows={}
 for pid in ids:
  p=P[pid];component=pg.candidate_pack_visual_component_match(p,context)
  hypothetical=copy.deepcopy(p);hypothetical['activation']['context_disambiguation']={'required_with_authorial_core':True,'any_terms':['textile'] if pid.startswith('y2k') else ['cushion']}
  rows[pid]={'component_match':component,'existing_advisory_context_check':pg.visual_profile_context_applicability(p,context,has_authorial_core_context=True,require_positive_context_terms=False),'component_flag_if_enabled_would_admit':component is not None,'adult_flag_if_enabled_would_admit':adult,'hypothetical_positive_context_exact':pg.visual_profile_context_applicability(hypothetical,context,has_authorial_core_context=True),'hypothetical_positive_context_advisory':pg.visual_profile_context_applicability(hypothetical,context,has_authorial_core_context=True,require_positive_context_terms=False),'actual_hit':next((x for x in result['hits'] if x['profile_id']==pid),None)}
 results.append({'case':name,'relevant_target':target,'adult_context':adult,'source_rows':sources,'query_fields':fields,'details':rows,'resolution':result})
manifest={'head':subprocess.check_output(['git','-C',str(R),'rev-parse','HEAD'],text=True).strip(),'files':{str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [S/'scripts/prompt_generator.py',S/'assets/photo_prompt_visual_obligations_y2k.json',S/'assets/photo_prompt_visual_obligations_realistic_background.json',S/'assets/photo_prompt_visual_profile_index.json']},'compiled_profiles':{p:P[p] for p in ids}}
(O/'evidence.json').write_text(json.dumps({'manifest':manifest,'cases':results},ensure_ascii=False,indent=2)+'\n')
for r in results:
 print(r['case'],{pid:{'component':x['component_match'],'hit':(x['actual_hit'] or {}).get('match_basis'),'optional':(x['actual_hit'] or {}).get('optional_eligible')} for pid,x in r['details'].items()})
