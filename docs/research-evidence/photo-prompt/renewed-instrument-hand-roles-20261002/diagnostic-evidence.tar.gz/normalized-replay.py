#!/usr/bin/env python3
"""Candidate-known diagnostic retrieval probes, not blind generation or pixel evidence."""
import copy,json,hashlib,sys
from pathlib import Path
ROOT=Path(sys.argv[sys.argv.index('--repo')+1]).resolve() if '--repo' in sys.argv else Path.cwd();OUT=Path(__file__).resolve().parent/'normalized';OUT.mkdir(exist_ok=True)
sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'skills/photo-prompt-image-generator/scripts'))
from tests import photo_prompt_fixtures as f
import prompt_generator as g
import audit_composed_prompt as audit
P=OUT.parent
def dump(path,value):path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
inputs=json.loads((P/'frozen-inputs.json').read_text());proposals=json.loads((P/'proposals.json').read_text())['generic']
freeze='--freeze' in sys.argv
for item in inputs:
 name=item['case']; path=OUT/name;path.mkdir(exist_ok=True)
 if freeze:
  old=item['core'];request=old['source_request'];subject=old['subject'];event=old['event'];controls=item['controls']
  baseline=f"In a quiet rehearsal room, {subject} plays music during a brief afternoon practice. {event} A medium three-quarter photograph keeps the face, instrument and both hands legible together, giving the relationship between gesture and sound the frame's emphasis. Soft window light describes the instrument surface and the natural folds of a simple cotton shirt. The softly focused rehearsal-room wall stays subdued behind the player, with restrained color and gentle shadow detail supporting the attentive musical moment."
  priorities=('the face, instrument and both hands legible together','Soft window light describes the instrument surface','the attentive musical moment')
  raw=f.core(request,interpreted_intent='A documentary photograph of the named adult musician playing, with coherent instrument-specific hand roles in a quiet rehearsal room. Hand-role realization, room, framing and light are agent-chosen.',subject=subject,setting='a quiet afternoon rehearsal room',event=event,visual_priorities=priorities,baseline_prompt_en=baseline,locked_dimensions=('concept','subject','event'),open_dimensions=('pose','framing','composition','lighting','camera','color','material','atmosphere','relationship'),anchor_evidence=(subject+' plays music',subject,'plays music during a brief afternoon practice'))
  # Source anchors lock only the original short request, not the authored detailed hand positions.
  raw['intent_lock']['semantic_anchors'][2]['prompt_evidence']='plays music during a brief afternoon practice'
  raw['creative_controls_sha256']=controls['canonical_sha256'];raw['variation_key']='candidate-known-instrument-audit-'+name
  env=f.envelope(request);env['request_id']='instrument-audit-'+name
  dump(path/'request-envelope.raw.json',env);dump(path/'creative-controls.json',controls);dump(path/'authorial-core.raw.json',raw)
 env=g.normalize_request_envelope(json.loads((path/'request-envelope.raw.json').read_text()))
 controls=json.loads((path/'creative-controls.json').read_text());raw=json.loads((path/'authorial-core.raw.json').read_text())
 core=g.normalize_authorial_core(raw,request_envelope=env,creative_control_snapshot=controls)
 assert core['source_request']==item['core']['source_request']
 assert core['event']==item['core']['event']
 dump(path/'request-envelope.normalized.json',env);dump(path/'authorial-core.normalized.json',core)
 item['normalized_core']=core;item['normalized_controls']=controls
# No candidate source is read until all authored cores have been written and normalized.
before=json.loads((P/'effective-runtime-data.json').read_text());after=copy.deepcopy(before)
for rows in after['slots'].values():
 for row in rows:
  if row['id'] in proposals:row.update(proposals[row['id']])
results={}
for label,data in [('before',before),('generic',after)]:
 results[label]={}
 for item in inputs:
  core=item['normalized_core'];controls=item['normalized_controls']
  slots,binding,_=g.retrieve_core_slots(data,core,controls)
  errors=audit.audit_core_retrieval({'slots':slots,'core_retrieval':binding,'authorial_core':core,'creative_controls':controls},data)
  assert errors==[],errors
  results[label][item['case']]={'slots':slots,'binding':binding,'audit_errors':errors}
  dump(OUT/item['case']/(label+'-retrieval.json'),results[label][item['case']])
comparison={}
for item in inputs:
 name=item['case'];b=results['before'][name]['slots'];a=results['generic'][name]['slots'];changes=[]
 for slot in sorted(set(a)|set(b)):
  bi=[r['entry_id'] for r in b.get(slot,{}).get('candidates',[])];ai=[r['entry_id'] for r in a.get(slot,{}).get('candidates',[])]
  if bi!=ai:changes.append({'slot':slot,'before':bi,'after':ai})
 comparison[name]={'before_slot_count':len(b),'after_slot_count':len(a),'all_slot_rank_changes':changes,'target_rows':{label:{slot:[{'rank':i+1,**r} for i,r in enumerate(results[label][name]['slots'].get(slot,{}).get('candidates',[]))] for slot in ['body_pose','action']} for label in ['before','generic']},'audit_errors':[]}
 print(name,'slots',len(a),'rank changes',changes,'pose',[(r['entry_id'],r['label_en']) for r in a.get('body_pose',{}).get('candidates',[])])
dump(OUT/'comparison.json',comparison)
dump(OUT/'provenance.json',{'method':'Candidate-known diagnostic authoring. Original exact five requests and hand-role event descriptions preserved. Fixture helper only supplies envelope/core structure. Raw photographic cores written before runtime corpus load. Normalized by current contract; no claim of blind pre-core authoring, full CLI execution, embodiment audit or pixel quality.','frozen_effective_source':str(P/'effective-runtime-data.json'),'source_sha256':hashlib.sha256((P/'effective-runtime-data.json').read_bytes()).hexdigest(),'all_retrieval_audits_passed':True})
