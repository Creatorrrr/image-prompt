#!/usr/bin/env python3
"""Local, no-network DATA replay. Never writes repository files."""
import copy, hashlib, json, subprocess, sys
from pathlib import Path
ROOT=Path(sys.argv[sys.argv.index('--repo')+1]).resolve() if '--repo' in sys.argv else Path.cwd()
OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'skills/photo-prompt-image-generator/scripts'))
import prompt_generator as g
TAGS=ROOT/'skills/photo-prompt-image-generator/assets/photo_prompt_tags.json'
def dump(name,value): (OUT/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
if '--freeze' in sys.argv:
    cases=[
      ('trumpet','an adult trumpet player','The trumpet player keeps the cup mouthpiece at the lips, the left hand supporting the folded brass tubing and the right hand operating the three piston valves.'),
      ('saxophone','an adult alto saxophone player','The saxophone player seals the reed mouthpiece with the lips while both hands operate separate key clusters.'),
      ('clarinet','an adult clarinet player','The clarinet player seals the reed mouthpiece with the lips while the left hand covers the upper keys and tone holes and the right hand covers the lower keys and tone holes.'),
      ('trombone','an adult trombone player','The trombone player holds the mouthpiece at the lips with the left hand supporting the instrument at the brace and the right hand moving the slide.'),
      ('horn','an adult French horn player','The French horn player keeps the mouthpiece at the lips while the left hand operates the valve levers and the right hand rests inside the bell.')]
    frozen=[]
    for name,subject,event in cases:
      core={'contract_version':'photo-authorial-core/v3','request_binding':{'active_spans':[]},'source_request':subject+' plays music.','subject':subject,'setting':'a rehearsal room','event':event,'visual_priorities':['mouthpiece contact and the two hand roles remain legible'],'user_exclusions':[]}
      controls=g.creative_controls.resolve(core['source_request'],context={'subject_category':'human'},overrides={'sensual':0,'fetish':0},seed=1)
      core['creative_controls_sha256']=controls['canonical_sha256']
      core['canonical_sha256']=g.canonical_json_sha256(core)
      frozen.append({'case':name,'core':core,'controls':controls})
    dump('frozen-inputs.json',frozen)
    raw=json.loads(TAGS.read_text())
    records=[]
    for slot,id in [('body_pose','wind_embouchure_two_hand_key_pose'),('action','trumpet_lip_valve_action')]:
      row=next(r for r in raw['slots'][slot] if r['id']==id)
      records.append({'file':str(TAGS.relative_to(ROOT)),'json_selector':f"slots.{slot}[id={id}]",'slot':slot,'id':id,'old_record':row})
    dump('old-records.json',records)
    dump('baseline-provenance.json',{'git_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'tags_sha256':hashlib.sha256(TAGS.read_bytes()).hexdigest(),'purpose':'Retrieval-level synthetic regression probes, not a complete image-generation request or normalized v3 authorial artifact. No generator or API called.'})
proposals={
 'generic':{
  'wind_embouchure_two_hand_key_pose':{
   'en':'a wind-instrument embouchure pose with each hand in its instrument-specific playing or support role',
   'ko':'관악기 마우스피스에 입술을 대고 각 손을 악기에 맞는 연주·지지 위치에 둔 자세',
   'embedding_text':"the adult player maintains plausible neck and shoulder support while the lips meet the correct mouthpiece and each hand takes the instrument's appropriate playing or support role"},
  'trumpet_lip_valve_action':{
   'en':'playing a trumpet at the cup mouthpiece with left-hand support and right-hand valve fingering',
   'ko':'컵 마우스피스에 입술을 대고 왼손으로 트럼펫을 지지하며 오른손 손가락으로 밸브를 조작하는',
   'embedding_text':"the player's lips meet a trumpet cup mouthpiece while the left hand supports the folded brass tubing and the right-hand fingers rest on or press a note-appropriate combination of the three aligned piston valves"}},
}
proposals['instrument_examples']=copy.deepcopy(proposals['generic'])
proposals['instrument_examples']['wind_embouchure_two_hand_key_pose']['embedding_text']='the adult player keeps the mouthpiece at the lips and relaxed shoulders while each hand takes its instrument-specific role: both hands operate separate key clusters on a saxophone, while the left hand supports a modern piston trumpet and the right-hand fingers operate its valves'
dump('proposals.json',proposals)
original=g.load_json(TAGS)
# Freeze the effective merged slot source as reproducibility evidence; extensions are included.
if '--freeze' in sys.argv: dump('effective-runtime-data.json',original)
else: original=json.loads((OUT/'effective-runtime-data.json').read_text())
frozen=json.loads((OUT/'frozen-inputs.json').read_text())
results={}
for variant in ['before','generic','instrument_examples']:
 data=copy.deepcopy(original)
 if variant!='before':
  for slot,rows in data['slots'].items():
   for row in rows:
    if row['id'] in proposals[variant]: row.update(proposals[variant][row['id']])
 results[variant]={}
 for case in frozen:
  slots,binding,contract=g.retrieve_core_slots(data,case['core'],case['controls'])
  results[variant][case['case']]={'slots':{slot:{'candidate_count':v['candidate_count'],'candidates':[{'rank':i+1,**row} for i,row in enumerate(v['candidates'])]} for slot,v in slots.items()},'binding':binding}
  print(variant,case['case'],[(slot,[r['entry_id'] for r in slots.get(slot,{}).get('candidates',[])]) for slot in ['body_pose','action']])
dump('replay-results.json',results)
