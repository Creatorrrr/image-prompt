# Contract-valid, candidate-known retrieval validation

All five exact original request strings and detailed hand-role event descriptions are preserved. The expanded photographic baselines and complete raw v3 authorial cores were saved before retrieval, with request envelopes and the original resolved controls. These are candidate-known diagnostic probes, not blind authoring evidence.

The fixture helper supplied envelope/core structure; it did not supply the scene prose. Raw cores were normalized by normalize_authorial_core with their normalized request envelope and controls. All five pass. Two setup validation failures were corrected before final freezing: the initial minimal setting had fewer than three content words; the initial intent lock omitted the contract-required concept dimension. Final setting is “a quiet afternoon rehearsal room”; concept, subject and event are locked only to the original request, while pose details remain authored staging. No repository file was modified by this worker.

All ten before/generic retrieve_core_slots results pass audit_core_retrieval with zero errors. Exact full results and bindings are saved per case. all-ranked-candidates.json provides explicit rank numbers for every candidate across every returned slot. comparison.json reports all rank changes.

Results:
- Each scene retrieves 17 slots before and after
- Shared wind pose remains first for trumpet, saxophone, clarinet, trombone and horn
- Its corrected label reaches all five normalized-core candidate outputs
- Trumpet action reaches the trumpet result with the corrected left-support/right-fingering public label
- Trumpet, saxophone, clarinet and horn preserve all candidate ID orders
- Trombone camera_direction alone swaps ranks 1 and 2: pc_px07_component_1 and overhead_social_snapshot_relation. All four candidate IDs remain unchanged

No automatic candidate adoption occurs: retrieve_core_slots marks candidate_adoption optional and leaves slot selected null. This test does not execute composition, so it cannot establish that a composer would make the same downstream selection. Neither image generation nor pixel fidelity was evaluated.

Run ../normalized-replay.py without --freeze to reproduce using saved raw cores and frozen prepatch data. The script imports current repository implementations; baseline audit commit is recorded in the parent provenance. Do not use --freeze unless intentionally replacing the input evidence.
