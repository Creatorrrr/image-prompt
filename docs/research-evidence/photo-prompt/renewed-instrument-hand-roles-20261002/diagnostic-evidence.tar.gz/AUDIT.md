# Instrument hand-role DATA audit

Baseline commit: 9594c556. Scope: read-only repository audit and in-memory source substitutions. No API calls, repository edits, generated indexes, or image generations.

## Recommendation

Apply `proposals.json.generic`, changing only en, ko and embedding_text in the two rows documented in `old-records.json`. Keep IDs, aliases, keywords, tags, weights, activation and all registry fields unchanged. Full old records and exact replacement fields are frozen beside this report.

The generic shared-pose embedding is the minimal choice. It replaces the false universal assertion that both hands operate keys or valves with instrument-appropriate playing/support roles. It adds no instrument names and does not transplant trumpet handedness onto horns or slide trombones. The instrument-example alternative has identical candidate rank outcomes on all five probes, offering no demonstrated benefit for its additional naming and specificity.

The trumpet action change carries correct left-support/right-valve information into the public label. It also replaces ambiguous “pressing three piston valves” with fingering that permits note-appropriate combinations, including resting fingers/open valves. Exact fingering for a specified note remains outside this patch.

## Concrete defect and consumers

`skills/photo-prompt-image-generator/assets/photo_prompt_tags.json`, `slots.body_pose[id=wind_embouchure_two_hand_key_pose]`, says both hands operate keys or valves in both labels and its embedding. Its broad wind tags allow it to appear for multiple instruments.

The trumpet action embedding and trumpet contact row already correctly describe left support and right-hand valve operation. The modern_piston_trumpet_three_valve registry profile's composition instruction and playing-contact gate also describe the correct roles. Therefore no visual profile edit is needed.

`prompt_generator.py:11345` retrieve_core_slots uses the effective merged authored slot corpus and same-slot BM25F/RRF retrieval. `_core_slot_index` builds fields through semantic_bm25f_fields_for_entry (labels plus embedding_text-bearing keywords, among other authored fields). At `:11397` it passes selected rows to candidate_pack_summarize_slot_candidate (`:2135`), which exposes localized en/ko labels. It does not expose the embedding paragraph as public candidate prose. Correcting embedding only would leave the visible contradiction.

Visual-semantic retrieval uses `photo_visual_retrieval.py:30` positive_visual_profile_fields: aliases, definition, paraphrases, component terms, and concept terms. Registry composition/render fields are projected separately into visual obligations by `prompt_generator.py:7371–7393`. The current trumpet profile is internally correct on hand roles.

## Frozen replay and results

Run `python ./replay.py` to replay the frozen effective data. Do not use `--freeze` again; that option intentionally replaces frozen evidence from the current checkout.

`frozen-inputs.json` records the exact five cores and resolved controls. These are synthetic retrieval-level probes passed directly to retrieve_core_slots, not complete normalized v3 generation artifacts or evidence of successful image generation. Each core has a content-derived hash; neither the normal generation CLI nor a paid provider is invoked.

`effective-runtime-data.json` freezes the merged data returned by load_json, including research extensions. `baseline-provenance.json` records HEAD and source-file hash. Code remains imported from the specified checkout, so exact reproduction requires the recorded commit's scripts.

`replay-results.json` records all returned candidates for all 17 retrieved slots in each of 15 runs, including ranks, IDs, both labels, public fields and binding. `rank-comparison.json` compares every retrieved slot, not just target rows.

All candidate ID orders across all 17 slots are identical between baseline, generic correction, and instrument-example correction on all five probes. Shared pose ranks first for trumpet, saxophone, clarinet, trombone and horn. Trumpet action ranks first in trumpet and stays first in the trombone/horn probes; saxophone action stays first in saxophone and clarinet. Therefore the correction demonstrably removes the faulty shared label while retaining retrieval coverage; it does not solve cross-instrument action suggestions. Those remain optional suggestions that the composer must reject where incompatible.

## Boundary caveats

- Clarinet: both hands finger controls, with left above right; right thumb also supports the instrument. The generic pose neither contradicts this nor forces one exclusively passive support hand.
- Slide trombone: left supports the instrument and right moves the slide. The old universal keys/valves pose is wrong here too. Generic replacement accommodates the correct division without requiring nonexistent valves. Original shared-row keyword “keys or valves” remains merely optional lexical recall, not a universal label or asserted mechanism. This minimal patch does not add a dedicated trombone candidate.
- French horn: left fingers operate valve levers; right hand is inside the bell and participates in support/tone. Do not use trumpet's right-valve/left-support arrangement as a universal brass rule. Generic shared wording avoids that mistake.
- Related shared `wind_bell_forward_mouthpiece_back_direction` describes a forward or downward-forward bell. This should not be generalized to horn bell orientation. It is outside these two-row corrections, and the patch makes no claim of comprehensive horn-direction fidelity.
- Existing instrument profiles are narrowly named; no new clarinet/trombone/horn profile, alias routing or forced duty is proposed. Generic instrument retrieval is not proof that the corresponding profile was activated.

## Sources checked

1. Yamaha, How to Play the Trumpet: https://www.yamaha.com/en/musical_instrument_guide/trumpet/play/ — left-hand support, relaxed right-hand placement.
2. Yamaha, Trumpet mechanism: https://www.yamaha.com/en/musical_instrument_guide/trumpet/mechanism/mechanism002.html — left fingers may adjust tuning slides; left support is not necessarily exclusively passive.
3. Yamaha trumpet guide: https://usa.yamaha.com/files/download/brochure/2/2133632/W215R18_trumpets.pdf — right-hand fingers operate valve combinations.
4. Yamaha, Clarinet mechanism: https://www.yamaha.com/en/musical_instrument_guide/clarinet/mechanism/mechanism002.html — left hand uppermost, right below, finger-operated rings/holes.
5. Yamaha, How to Play the Clarinet: https://www.yamaha.com/en/musical_instrument_guide/clarinet/play/ — right-thumb support.
6. Yamaha, Trombone mechanism: https://www.yamaha.com/en/musical_instrument_guide/trombone/mechanism/mechanism002.html — left-hand holding and right-hand slide movement.
7. Yamaha, Horn mechanism: https://www.yamaha.com/en/musical_instrument_guide/horn/mechanism/mechanism002.html — left valve operation, right hand in bell, combined support.

## After applying

Check exact replacement fields and preserved IDs/metadata; rerun the frozen consumer probes against edited effective data and record the same full output. Run existing instrument semantics tests and dictionary validation. Changed labels/embedding inputs require honest semantic-index reconciliation through the authorized builder; unchanged visual registry requires no visual-profile-index change. Do not claim index parity or pixel improvement from this local retrieval audit.
