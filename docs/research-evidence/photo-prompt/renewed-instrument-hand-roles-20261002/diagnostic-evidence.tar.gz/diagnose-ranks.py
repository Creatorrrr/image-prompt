#!/usr/bin/env python3
import copy,json,sys
from pathlib import Path
ROOT=Path(sys.argv[sys.argv.index('--repo')+1]).resolve() if '--repo' in sys.argv else Path.cwd();P=Path(__file__).resolve().parent;N=P/'normalized'
sys.path.insert(0,str(ROOT/'skills/photo-prompt-image-generator/scripts'));import prompt_generator as g
base=json.loads((P/'effective-runtime-data.json').read_text());generic=json.loads((P/'proposals.json').read_text())['generic'];smaller=copy.deepcopy(generic)
smaller['wind_embouchure_two_hand_key_pose'].update(en='a wind-instrument embouchure pose with each hand supporting the instrument or operating its keys or valves',embedding_text="the adult player maintains plausible neck and shoulder support while the lips meet the correct mouthpiece and each hand supports the instrument or operates its actual key or valve system")
(P/'smaller-proposal.json').write_text(json.dumps(smaller,ensure_ascii=False,indent=2)+'\n')
cases={d.name:(json.loads((d/'authorial-core.normalized.json').read_text()),json.loads((d/'creative-controls.json').read_text())) for d in N.iterdir() if d.is_dir()}
results={};traces={};indexes={}
for variant,changes in [('before',{}),('generic',generic),('smaller',smaller)]:
 data=copy.deepcopy(base)
 for rows in data['slots'].values():
  for row in rows:
   if row['id'] in changes:row.update(changes[row['id']])
 results[variant]={}
 for name,(core,controls) in cases.items():
  if variant in ['before','generic']:
   slots=json.loads((N/name/(variant+'-retrieval.json')).read_text())['slots']
  else:slots,_,_=g.retrieve_core_slots(data,core,controls)
  results[variant][name]={slot:[{'rank':i+1,**r} for i,r in enumerate(obj['candidates'])] for slot,obj in slots.items()}
 core,controls=cases['trombone'];slot='camera_direction';contract,picked=g.frozen_core_context(data,core,controls)
 bm=g._core_slot_index(json.dumps(data['slots'],ensure_ascii=False,sort_keys=True,separators=(',',':')));indexes[variant]=bm
 ids=[f"slot:{slot}:{r['id']}" for r in data['slots'][slot] if g.core_slot_entry_eligible(data,core,contract,picked,slot,r)]
 global_query,_=g.authorial_core_retrieval_text(core);query,fields=g.core_slot_focus_text(data,core,slot);limit=g.candidate_pack_slot_limit(slot)
 broad=g.rank_bm25f(bm,{'global_context':global_query},allowed_ids=ids,limit=max(12,limit*6));focal=g.rank_bm25f(bm,{'slot_focus':query},allowed_ids=ids,limit=max(12,limit*6));fused=g.reciprocal_rank_fusion([[r['document_id'] for r in broad],[r['document_id'] for r in focal]],k=30)
 inter={r['document_id'] for r in broad}&{r['document_id'] for r in focal}
 traces[variant]={'global_query':global_query,'focus_query':query,'focus_fields':fields,'broad':broad,'focal':focal,'rrf':[r for r in fused if r['document_id'] in inter],'public':results[variant]['trombone'][slot],'average_field_lengths':bm['average_field_lengths']}
(P/'rank-diagnosis-traces.json').write_text(json.dumps(traces,ensure_ascii=False,indent=2)+'\n')
(P/'smaller-full-ranked-results.json').write_text(json.dumps(results['smaller'],ensure_ascii=False,indent=2)+'\n')
comparison={}
for variant in ['generic','smaller']:
 comparison[variant]={}
 for name,b in results['before'].items():
  a=results[variant][name];diff=[]
  for slot in sorted(set(b)|set(a)):
   bi=[r['entry_id'] for r in b.get(slot,[])];ai=[r['entry_id'] for r in a.get(slot,[])]
   if bi!=ai:diff.append({'slot':slot,'before':bi,'after':ai})
  comparison[variant][name]=diff
(P/'smaller-comparison.json').write_text(json.dumps(comparison,ensure_ascii=False,indent=2)+'\n')
terms={t for v in traces.values() for lane in ['broad','focal'] for row in v[lane] for t in row['matched_terms']}
freqchanges={variant:{t:[indexes['before']['document_frequencies'].get(t,0),bm['document_frequencies'].get(t,0)] for t in sorted(terms) if indexes['before']['document_frequencies'].get(t,0)!=bm['document_frequencies'].get(t,0)} for variant,bm in indexes.items() if variant!='before'}
(P/'rank-diagnosis-frequency-changes.json').write_text(json.dumps(freqchanges,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(comparison,indent=2));print('frequency changes',json.dumps(freqchanges))
for variant,trace in traces.items():
 print(variant)
 for lane in ['broad','focal','rrf']:
  print(lane,[(i+1,r['document_id'],r['score']) for i,r in enumerate(trace[lane]) if any(x in r['document_id'] for x in ['pc_px07_component_1','overhead_social_snapshot_relation'])])
# Counterfactual diagnostic: isolate corpus-statistic effects without changing documents.
core,controls=cases['trombone'];global_query,_=g.authorial_core_retrieval_text(core)
allowed=[doc for doc in indexes['before']['documents'] if doc.startswith('slot:camera_direction:')]
ablations={}
for key in ['document_frequencies','average_field_lengths','hand_only']:
 bm=copy.deepcopy(indexes['before'])
 if key=='hand_only':bm['document_frequencies']['hand']=indexes['generic']['document_frequencies']['hand']
 else:bm[key]=copy.deepcopy(indexes['generic'][key])
 rows=g.rank_bm25f(bm,{'global_context':global_query},allowed_ids=allowed,limit=24)
 ablations[key]=rows[:4]
(P/'rank-diagnosis-statistic-ablations.json').write_text(json.dumps(ablations,ensure_ascii=False,indent=2)+'\n')
print('ablations',json.dumps({k:[(r['document_id'],r['score']) for r in v[:2]] for k,v in ablations.items()}))
