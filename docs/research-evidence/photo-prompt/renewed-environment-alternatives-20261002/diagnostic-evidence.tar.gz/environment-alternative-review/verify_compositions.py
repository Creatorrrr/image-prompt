import json,subprocess,concurrent.futures
from pathlib import Path
p=Path('EVIDENCE_ROOT/environment-contact-alternative-audit/public-cli');o=Path(__file__).parent
summary=json.loads((p/'after-compositions-final/summary.json').read_text())
def check(row):
 name=row['case']; composed=json.loads((p/'after-compositions-final'/f'{name}-composed.json').read_text());pack=json.loads((p/'after'/f'{name}-pack.json').read_text())[0]
 assert pack['authorial_core']['baseline_prompt_en'] in composed['prompt_en']
 initial=json.loads((p/'after-compositions'/f'{name}-composed.json').read_text());assert initial['visual_obligation_evidence']==composed['visual_obligation_evidence']
 proc=subprocess.run(row['command'],capture_output=True,text=True,timeout=180)
 (o/f'{name}-independent-audit.stdout').write_text(proc.stdout);(o/f'{name}-independent-audit.stderr').write_text(proc.stderr)
 assert proc.returncode==0,(name,proc.stdout,proc.stderr)
 result=json.loads(proc.stdout);assert result['status']=='pass' and not result.get('failures')
 return {'case':name,'exit_code':proc.returncode,'status':result['status'],'warnings':result.get('warnings'),'full_frozen_baseline_preserved':True,'initial_evidence_unchanged_in_final':True}
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as e: result=list(e.map(check,summary))
(o/'independent-composition-verification.json').write_text(json.dumps(result,indent=2)+'\n');print('PASS six independently rerun full composition audits')
