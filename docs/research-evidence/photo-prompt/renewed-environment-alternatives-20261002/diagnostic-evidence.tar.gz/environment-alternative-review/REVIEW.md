# Independent review: wetland and dune alternative consistency

Verdict: APPROVE the exact three proposed data leaves at baseline cad6f90549d9fd6348310a71a23025f003fd00d6. No broader generalization is approved. This is composition/render-review instruction alignment with alternatives already authored in the profile, not expanded eligibility, retrieval improvement, or measured image improvement.

## Exact scope

File: skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations.json

1. wetland_hydrology_soil_vegetation_mosaic / composition_instruction:
   Frame a connected wetland surface where shallow water or visibly saturated low ground, water-shaped soil evidence, hydrophytic vegetation, and raised drier patches can all be compared in one view.
2. wetland_hydrology_soil_vegetation_mosaic / render_gates[1].description, gate ID vo_natural_wetland_soil_contact:
   Exposed mud, dark saturated soil, or a soft waterlogged margin remains visible with plausible ground contact.
3. aeolian_dune_stoss_crest_slipface_transport / composition_instruction:
   Use an oblique side view that keeps the gentle stoss slope, crest line, steep lee slip face, and aligned fine sand ripples or short saltation traces on one connected dune body.

The proposal's exact-leaves.json has verified before/after values. review.py independently applies only these values to a deep copy, verifies exactly three registry leaf changes, and verifies the real production materialized obligation changes at exactly the same three leaves. No repository edits were made. independent-proof.json contains full before/after obligations, changed paths, baseline SHA, asset hashes, routing results, and preserved environment candidates.

## Evidence and limits

EPA https://www.epa.gov/wetlands/what-wetland, independently read October 2, 2026, supports wetlands with saturation at or near the soil surface and distinguishes adapted vegetation and soil development. It does not imply every wetland can be diagnosed from one image or justify removing the profile's visible soil, vegetation, or mosaic requirements.

NPS https://www.nps.gov/subjects/geology/aeolian-landforms.htm, independently read October 2, 2026, supports shallow windward stoss, crest, and steep lee geometry. The page's text does not independently establish the detailed ripple-versus-short-saltation-trace alternative. That alternative is already explicit in the approved internal evidence record natural_environment_nps_aeolian_dunes and in the definition, component, evidence phrase, and render gate. The proposed correction reconciles the composition instruction to this authored contract; it is not new geomorphological validation.

Both source records are approved and carry scope limits. Neither change warrants new regulatory, soil-chemistry, wind-speed, or migration-rate inference.

## Consumer verification

candidate_pack_visual_profile_obligation in prompt_generator.py compiles each profile then emits composition_instruction and render_gates. Independent actual calls confirm the proposed text survives compilation. Whole-object diffs prove all other obligation fields unchanged, including components, literal evidence requirements, gate IDs and review scales, runtime expression, activation metadata, and reject substitutes. Registry deep diff proves unrelated profiles are untouched.

Gate IDs feed the effective hard-gate union in audit_composed_prompt.py; image-review validation reads target render gates. This establishes a real downstream composition/review contract effect. It does not establish image correctness. No image was generated and no visual review was fabricated.

## Controls

Executed independently against real baseline and proposed registries:
- Exact wetland and dune route labels still activate their respective profiles (two positive activation controls)
- Ornamental pond with dry-edge reeds; dry meadow with blue reflection; dust cloud without dune geometry; symmetric studio sand pile; flat desert ripple texture: none activates either narrow environment profile (five wrong-scene controls)
- Broad wetland and desert labels do not newly activate narrow profiles (two broad-label controls)
- All nine outputs match baseline exactly

Required semantic scenario matrix, assessed as contract expectations rather than executed image outcomes:
- Wetland standing-water branch: connected shallow water, soil evidence, rooted emergent plants, and higher drier patches remains valid
- Wetland saturation branch: connected saturated dark-soil hollows, rooted water-tolerant plants, higher drier patches, with no standing pool/waterline is no longer contradicted by composition or soil-contact wording
- Dune ripple branch: connected stoss/crest/lee geometry with aligned ripples remains valid
- Dune transport branch: same geometry and aligned short saltation traces without ripple relief is no longer contradicted by composition wording
- Isolated pond, dry meadow/flooded lawn without soil/vegetation structure, dust cloud alone, symmetric sand pile and flat ripple texture remain inadequate; mandatory structure/rejects are unchanged

Baseline scout test log: eight natural-environment tests passed. I verified the log but did not rerun that separate suite. Independent executed controls and full object diff are recorded by this review, not inferred from the scout log. No eligible branch gains are claimed; free-text evidence acceptance and rendered quality were not newly measured.

## Narrow authored choices must survive

Unchanged candidates independently inspected and recorded:
- wetland_hydric_soil_waterline_surface still requires a shallow waterline and rooted emergent vegetation
- shallow_water_patch_mosaic_frame still specifies shallow channels and its selected mosaic frame
- dune_ripple_stoss_slipface_surface still specifies aligned ripples
- dune_stoss_crest_slipface_frame still carries its selected multi-dune/ripple process composition

Selecting an explicit narrow candidate or user-authored waterline/ripple requirement remains binding; this general-profile change cannot excuse removing it. Other environment owners, perspective, frame connectivity, geometry, soil contact, vegetation relation, and raised drier patches are preserved.

Recommended implementation checks: exact three-leaf diff, materialization assertions, positive-alternative wording controls, wrong-scene activation controls, explicit locked narrow-candidate fixtures, and existing natural-environment/schema tests. Public text replay or actual render review may provide additional evidence later but is not claimed here.

## Applied patch and public replay addendum (2026-10-02 23:02 UTC)

APPROVE applied exact patch on baseline 7bc6d8bc759f9c14da95afc8be54bca44caf3830.

Independent live verification (`verify_live.py`, `live-verification.json`) checks the source against Git baseline and the previously approved exact selectors. Exactly three registry leaves changed; every other profile and complete natural-environment candidate extension remain identical. The saved environment-alternative-original-index.json is byte-identical to the baseline Git index. The live index differs only in registry_sha256; its 1,496 entries and all BM25F data are unchanged. The new hash matches the production canonical-registry hash function. Initial reviewer comparison against raw file bytes was corrected to the actual canonical-hash convention; it was not a product defect.

Independent public replay verification (`verify_replay.py`, `independent-replay-verification.json`) checks all six frozen inputs and actual AFTER packs. All six CLI cases exited zero with expected profile presence/absence. Original cad6f905 and requalified 7bc6d8bc BEFORE packs are byte-identical in all six cases. Wetland AFTER packs change only composition, soil-contact gate description, and pack_id; dune AFTER packs change only composition and pack_id. Both negative packs remain identical. Complete authorial cores, slots, candidate collections, gate identity/scales, evidence requirements, geometry, unrelated features, and all other pack fields remain unchanged.

Independent full composition audit rerun (`verify_compositions.py`, `independent-composition-verification.json`, six *-independent-audit.stdout files): all six normal audit_composed_prompt.py CLI calls passed. Each retains three uncovered-intent warnings because the respective baseline intentions are preserved by free description/assertion. These warnings are not silently treated as absent. The complete frozen baseline occurs in every final prompt. Final prompts preserve initial visual evidence exactly. The scout's initial four positive composition failures remain recorded; they omitted mandatory safe profile labels, and adding those labels corrected the audits without mutating core or evidence.

The saturation and saltation prompts explicitly retain the frozen alternative and complete geometry, while including unchanged required OR evidence phrases. No image outcome is asserted. Before/after visual evidence acceptance remains unchanged in the scout's production checks. The demonstrated improvement is removal of contradictory composition/review wording, not new eligibility, retrieval quality, or rendered compliance. Narrow waterline/ripple slot candidates remain binding if explicitly selected; their data are unchanged, and these compositions intentionally select no optional slot candidate.
