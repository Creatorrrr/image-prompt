import copy,json,sys,hashlib,subprocess
from pathlib import Path
root=Path('REPOSITORY_ROOT'); out=Path(__file__).parent
sys.path.insert(0,str(root/'skills/photo-prompt-image-generator/scripts'))
import prompt_generator as pg
asset=root/'skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations.json'
reg=pg.load_visual_obligation_registry(asset); proposed=copy.deepcopy(reg)
changes=json.loads((out.parent/'environment-contact-alternative-audit/exact-leaves.json').read_text())
for c in changes:
 p=next(x for x in proposed['profiles'] if x['id']==c['profile_id'])
 for k in c['path'][:-1]:p=p[k]
 assert p[c['path'][-1]]==c['before'];p[c['path'][-1]]=c['proposed']
def diff(a,b,path=()):
 if type(a)!=type(b):return [path]
 if isinstance(a,dict):
  assert a.keys()==b.keys()
  return sum((diff(a[k],b[k],path+(k,)) for k in a),[])
 if isinstance(a,list):
  assert len(a)==len(b)
  return sum((diff(x,y,path+(i,)) for i,(x,y) in enumerate(zip(a,b))),[])
 return [] if a==b else [path]
diffs=diff(reg,proposed); assert len(diffs)==3
results={}
for c in changes:
 pid=c['profile_id']
 if pid in results:continue
 before=pg.candidate_pack_visual_profile_obligation(next(p for p in reg['profiles'] if p['id']==pid),reg,activation_source='independent-review',source_intent_ids=[])
 after=pg.candidate_pack_visual_profile_obligation(next(p for p in proposed['profiles'] if p['id']==pid),proposed,activation_source='independent-review',source_intent_ids=[])
 assert len(diff(before,after))==sum(x['profile_id']==pid for x in changes)
 results[pid]={'before':before,'after':after,'actual_changed_paths':diff(before,after)}
controls=[]
for text,expected in [('wetland hydrology vegetation mosaic','wetland_hydrology_soil_vegetation_mosaic'),('aeolian dune wind structure','aeolian_dune_stoss_crest_slipface_transport'),('ordinary ornamental pond with reeds along one dry edge',None),('dry meadow with blue reflection',None),('dust cloud without dune geometry',None),('symmetric studio sand pile on a seamless backdrop',None),('flat desert ripple texture',None),('wetland',None),('desert',None)]:
 row=[{'source':'concept_lock','text':text,'polarity':'required','priority':'critical','mandatory':True}]
 a=set(pg.candidate_pack_auto_visual_obligation_matches(reg,row));b=set(pg.candidate_pack_auto_visual_obligation_matches(proposed,row))
 assert a==b
 assert a==({expected} if expected else set()),(text,a)
 controls.append({'text':text,'baseline':sorted(a),'proposed':sorted(b)})
ext=root/'skills/photo-prompt-image-generator/assets/photo_prompt_natural_environment_extension.json'
slots=json.loads(ext.read_text())['slots']
locked=[{'slot':s,**x} for s,rows in slots.items() for x in rows if any(w in str(x.get('id','')) for w in ['wetland','dune'])]
(out/'independent-proof.json').write_text(json.dumps({'head':subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD'],text=True).strip(),'asset_sha256':hashlib.sha256(asset.read_bytes()).hexdigest(),'registry_changed_paths':diffs,'materialization':results,'executed_routing_controls':controls,'unchanged_narrow_candidates':locked,'extension_sha256':hashlib.sha256(ext.read_bytes()).hexdigest()},indent=2,ensure_ascii=False)+'\n')
print('PASS: exact three-leaf deep diff; real obligation output delta exact; nine real routing controls unchanged; narrow candidates recorded unchanged.')
