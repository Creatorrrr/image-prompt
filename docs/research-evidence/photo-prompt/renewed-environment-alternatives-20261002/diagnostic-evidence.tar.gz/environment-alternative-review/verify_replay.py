import json,hashlib
from pathlib import Path
p=Path('EVIDENCE_ROOT/environment-contact-alternative-audit/public-cli');o=Path(__file__).parent
m=json.loads((p/'frozen-input-manifest.json').read_text());after=json.loads((p/'after/run-manifest.json').read_text())
assert len(m)==len(after['cases'])==6
changes=json.loads((p.parent/'exact-leaves.json').read_text())
rows=[]
for c,row in zip(m,after['cases']):
 assert c['case']==row['case'];assert row['exit_code']==0 and row['expected_target_status']
 n=c['case']+'-pack.json';assert (p/'before'/n).read_bytes()==(p/'before-after-wethair'/n).read_bytes()
 b=json.loads((p/'before-after-wethair'/n).read_text())[0];a=json.loads((p/'after'/n).read_text())[0]
 assert b['authorial_core']==a['authorial_core'];assert b['slots']==a['slots']
 bo=b.get('visual_obligations',{}).get('obligations',[]);ao=a.get('visual_obligations',{}).get('obligations',[])
 for change in changes:
  for ob in bo:
   if ob['id']==change['profile_id']:
    obj=ob
    for k in change['path'][:-1]:obj=obj[k]
    assert obj[change['path'][-1]]==change['before'];obj[change['path'][-1]]=change['proposed']
 assert bo==ao,c['case']
 b['pack_id']=a['pack_id'];assert b==a,c['case']
 for name,h in c['inputs'].items():assert hashlib.sha256((p/'inputs'/c['case']/name).read_bytes()).hexdigest()==h
 rows.append({'case':c['case'],'exit_code':0,'original_requalified_before_byte_identical':True,'authorial_core_and_slots_unchanged':True,'actual_obligation_delta_only_approved_leaves':True,'all_other_pack_fields_unchanged_except_pack_id':True,'frozen_inputs_hash_valid':True,'profiles':[x['id'] for x in ao]})
(o/'independent-replay-verification.json').write_text(json.dumps(rows,indent=2)+'\n');print('PASS independent six replay checks')
