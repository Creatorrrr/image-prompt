import hashlib,json,sys
from pathlib import Path
R=Path('REPOSITORY_ROOT');O=Path(__file__).parent/'public-cli'
sys.path[:0]=[str(R),str(R/'skills/photo-prompt-image-generator/scripts')]
import prompt_generator as pg
from tests import photo_prompt_fixtures as f
cases=[
('wetland-saturation','wetland_hydrology_soil_vegetation_mosaic','wetland hydrology vegetation mosaic','A connected saturated-soil wetland mosaic','Visibly saturated dark-soil hollows occupy connected low areas without standing water or an open waterline. Rooted water-tolerant vegetation grows from that wet substrate, alternating with slightly raised drier vegetated patches. Exposed mud and dark saturated soil remain visible between the plants.'),
('wetland-shallow-water','wetland_hydrology_soil_vegetation_mosaic','wetland hydrology vegetation mosaic','A connected shallow-water wetland mosaic','Shallow standing water occupies connected low areas. Exposed muddy water margins and rooted emergent wetland vegetation alternate with slightly raised drier vegetated patches. The wet substrate remains visible around the plant roots and along the shallow waterline.'),
('dune-saltation','aeolian_dune_stoss_crest_slipface_transport','aeolian dune wind structure','One asymmetric wind-built sand dune','A broad gentle stoss slope rises to a narrow continuous crest, immediately followed by a steep smooth lee slip face. Aligned short saltation traces skim coherently across the stoss surface without visible ripple relief. The stoss, crest and lee remain connected parts of the same sand body.'),
('dune-ripples','aeolian_dune_stoss_crest_slipface_transport','aeolian dune wind structure','One asymmetric wind-built sand dune','A broad gentle stoss slope rises to a narrow continuous crest, immediately followed by a steep smooth lee slip face. Fine sand ripples align coherently across the stoss surface. The stoss, crest and lee remain connected parts of the same sand body.'),
('negative-ornamental-pond',None,'ordinary ornamental pond','One small ornamental garden pond','A small isolated circular pond lies within dry clipped lawn. A few decorative reeds occupy one dry edge, while the remaining bank is paved stone. The garden has no connected saturated-soil hollows or alternating wetter and raised vegetated patches.'),
('negative-sand-pile',None,'symmetric studio sand pile','One symmetric studio sand pile','An isolated symmetric cone of loose sand rests on a seamless studio floor. Both sides have matching slopes and meet at a central point. The scene lacks a broad gentle stoss face paired with a steep lee face, and has no coherent grain-transport traces.')]
def save(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
manifest=[]
for name,target,label,subject,scene in cases:
 request='Create a landscape or environmental photograph of '+label+'. '+scene+' Keep the specified surface state and geometry unchanged; include no people.'
 baseline=subject+'. '+scene+' Use an oblique view that keeps the complete selected landform and its surrounding ground visible in one frame. Natural surface colors remain distinct under coherent directional daylight. The foreground connects continuously to the middle distance, with smaller background forms establishing depth without hiding the selected surface. Retain clear local texture and physically plausible ground contact. A restrained horizon and uncluttered sky keep attention on the stated environmental structure. Any cast shadows agree with the illumination and topography. The selected landform remains the sole environmental subject. The photograph should preserve the exact stated surface condition, visible relationships and geometry, with an intentional focal hierarchy and readable material boundaries.'
 controls=pg.creative_controls.resolve(request,overrides={'sensual':0,'fetish':0,'creativity':1,'surreal':0},seed=811)
 core=f.core(request,interpreted_intent=request,subject=subject,setting='the stated environmental scene',event=scene,visual_priorities=('selected landform','coherent directional daylight','physically plausible ground contact'),baseline_prompt_en=baseline,anchor_evidence=(subject,'selected landform','physically plausible ground contact'))
 core['creative_controls_sha256']=controls['canonical_sha256'];core['variation_key']='environment-alternative-'+name
 envelope=f.envelope(request);envelope['request_id']='environment-alternative-'+name
 review={'contract_version':'photo-embodiment-review/v1','provenance':'agent_prepack','prompt_sha256':hashlib.sha256(core['baseline_prompt_en'].encode()).hexdigest(),'scope':'not_applicable','summary':'Authored environment scene contains no body or body action; no rendered image assessment is claimed.','checks':{}}
 norm=pg.normalize_authorial_core(core,request_envelope=pg.normalize_request_envelope(envelope),creative_control_snapshot=controls);pg.photo_embodiment.build_policy(norm,review)
 d=O/'inputs'/name
 for key,v in [('request-envelope',envelope),('authorial-core',core),('creative-controls',controls),('embodiment-review',review)]:save(d/(key+'.json'),v)
 manifest.append({'case':name,'seed':811,'target_profile':target,'inputs':{p.name:sha(p)for p in sorted(d.glob('*.json'))}})
save(O/'frozen-input-manifest.json',manifest)
print('Frozen',len(manifest),'normal public cases')
