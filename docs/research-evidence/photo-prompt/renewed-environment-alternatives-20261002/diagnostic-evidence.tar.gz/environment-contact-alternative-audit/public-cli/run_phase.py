import sys,os,json,hashlib,subprocess,time
from pathlib import Path
OUT=Path(__file__).resolve().parent;ROOT=Path('REPOSITORY_ROOT');phase=sys.argv[1]
d=OUT/phase;d.mkdir(exist_ok=True)
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
manifest=json.loads((OUT/'frozen-input-manifest.json').read_text());assets=ROOT/'skills/photo-prompt-image-generator/assets'
files=[assets/'photo_prompt_visual_obligations.json',assets/'photo_prompt_visual_profile_index.json',ROOT/'skills/photo-prompt-image-generator/scripts/generate_photo_prompt.py',ROOT/'skills/photo-prompt-image-generator/scripts/prompt_generator.py']
meta={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'status':subprocess.check_output(['git','status','--short'],cwd=ROOT,text=True),'hashes':{str(f.relative_to(ROOT)):sha(f) for f in files},'cases':[]}
if phase=='before':assert meta['head'].startswith('cad6f905') and not meta['status']
for c in manifest:
 case=c['case'];inputs=OUT/'inputs'/case
 for name,h in c['inputs'].items():assert sha(inputs/name)==h
 command=[sys.executable,str(ROOT/'skills/photo-prompt-image-generator/scripts/generate_photo_prompt.py'),'--seed',str(c['seed'])]
 for arg in ['request-envelope','authorial-core','creative-controls','embodiment-review']:command+=['--'+arg+'-json',str(inputs/(arg+'.json'))]
 dest=d/(case+'-pack.json');command+=['--output-file',str(dest)]
 start=time.time();proc=subprocess.run(command,cwd=ROOT,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},capture_output=True,text=True,timeout=300)
 (d/(case+'.stdout')).write_text(proc.stdout);(d/(case+'.stderr')).write_text(proc.stderr)
 row={'case':case,'command':command,'exit_code':proc.returncode,'duration_seconds':time.time()-start,'target_profile':c['target_profile']};meta['cases'].append(row)
 print(case,'exit',proc.returncode,flush=True)
 if proc.returncode:print(proc.stderr,flush=True)
 else:
  pack=json.loads(dest.read_text())[0];obligations=(pack.get('visual_obligations')or{}).get('obligations',[])
  row.update({'pack_sha256':sha(dest),'pack_id':pack.get('pack_id'),'emitted_profile_ids':[o['id']for o in obligations],'exact_visual_contract':pack.get('visual_obligations'),'emitted_core':pack.get('authorial_core')})
  target=c['target_profile'];row['expected_target_status']=target in row['emitted_profile_ids'] if target else not ({'wetland_hydrology_soil_vegetation_mosaic','aeolian_dune_stoss_crest_slipface_transport'}&set(row['emitted_profile_ids']))
 (d/'run-manifest.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n')
assert all(x['exit_code']==0 for x in meta['cases'])
assert all(x['expected_target_status'] for x in meta['cases'])
assert all(sha(ROOT/n)==h for n,h in meta['hashes'].items())
print('All cases completed; frozen source hashes unchanged',flush=True)
