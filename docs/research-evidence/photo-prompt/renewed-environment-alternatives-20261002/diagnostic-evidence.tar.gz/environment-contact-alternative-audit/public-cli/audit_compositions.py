import copy,hashlib,json,sys,subprocess
from pathlib import Path
D=Path(__file__).parent;E=D/'after-compositions';E.mkdir(exist_ok=True);R=Path('REPOSITORY_ROOT');S=R/'skills/photo-prompt-image-generator/scripts';sys.path.insert(0,str(S))
import audit_composed_prompt as ac
save=lambda p,x:p.write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
results=[]
for row in json.loads((D/'frozen-input-manifest.json').read_text()):
 name=row['case'];p=json.loads((D/'after'/f'{name}-pack.json').read_text())[0];before=json.loads((D/'before-after-wethair'/f'{name}-pack.json').read_text())[0];core=p['authorial_core'];lock=core['intent_lock'];baseline=core['baseline_prompt_en'];pid=row['target_profile'];evidence={}
 assert baseline==before['authorial_core']['baseline_prompt_en']
 if pid:
  ob=next(x for x in p['visual_obligations']['obligations']if x['id']==pid)
  if name.startswith('wetland'):
   evidence={
    'wetland_water_phrase':'Within this connected wetland mosaic, shallow standing water or visibly saturated ground occupies connected low areas. '+('Here the visibly saturated ground branch is selected; dark soil hollows retain the stated saturation surface condition.'if name=='wetland-saturation'else'Here the shallow standing water branch is selected and linked pools remain visibly shallow.'),
    'wetland_soil_phrase':'Across the same low wetland ground, exposed mud dark saturated soil or a soft waterlogged margin remains visible. '+('Dark saturated soil and exposed mud between the plants carry the soil evidence.'if name=='wetland-saturation'else'Exposed muddy water margins carry the soil evidence beside the shallow waterline.'),
    'wetland_vegetation_phrase':'In this wetland substrate, emergent or water-tolerant plants grow from the saturated substrate rather than beside a dry pond prop. '+('Rooted water-tolerant vegetation occupies the saturated hollows.'if name=='wetland-saturation'else'Rooted emergent vegetation occupies the shallow-water margins.'),
    'wetland_mosaic_phrase':'Across the connected wetland terrain, wetter pools channels or hollows alternate visibly with slightly raised vegetated patches. '+('The wetter hollows and raised drier patches form the specified mosaic.'if name=='wetland-saturation'else'Shallow pools and raised drier patches form the specified mosaic.')}
  else:
   evidence={
    'dune_stoss_phrase':'On this asymmetric sand body, a broad gently rising windward stoss slope forms one side of the dune.',
    'dune_crest_phrase':'Along the same sand body, a narrow continuous crest separates the gentle stoss side from the lee side.',
    'dune_slipface_phrase':'Immediately beyond that connected crest, a visibly steeper smooth slip face descends immediately behind the crest.',
    'dune_transport_phrase':'Across this same dune, fine sand ripples or short saltation traces align coherently across the stoss surface. '+('The selected short saltation traces skim the stoss while its specified smooth surface condition remains intact.'if name=='dune-saltation'else'The selected fine ripple relief remains clearly visible on the stoss face.')}
 prompt=baseline+(' '+' '.join(evidence.values())if evidence else'')
 c={'pack_id':p['pack_id'],'composer':'agent','prompt_en':prompt,'negative_en':p['negative_en'],'chosen_candidate_ids':[],'chosen_visual_concept_ids':[],'core_retrieval_sha256':p['core_retrieval']['canonical_sha256'],'visual_obligation_evidence':{pid:evidence}if pid else{},'authorial_core_binding':{'source_authorial_core_sha256':core['canonical_sha256'],'source_intent_lock_sha256':lock['canonical_sha256'],'preserved_anchor_ids':[a['anchor_id']for a in lock['semantic_anchors']],'preserved_evidence':[a['prompt_evidence']for a in lock['semantic_anchors']],'authorial_decisions':[]}}
 review=copy.deepcopy(p['embodiment_preflight']['baseline_review']);review.update(provenance='agent_postcomposition',prompt_sha256=hashlib.sha256(prompt.encode()).hexdigest(),summary='Text-only environment composition contains no body or body action. Frozen surface state, scene geometry and subject are retained. No pixel verification is claimed.')
 c['embodiment_review']={'source_contract_sha256':p['embodiment_preflight']['canonical_sha256'],'review':review};c['semantic_clarification_decisions']=[]
 for r in p['semantic_clarification']['candidates']:
  apply=r.get('required_in_final_prompt')is True or(pid is not None and r.get('profile_id')==pid)
  q={'clarification_id':r['id'],'decision':'applied'if apply else'rejected','rationale':'Preserve the frozen environmental subject, surface state and connected geometry.'if apply else'This optional interpretation adds unnecessary meaning to the frozen environmental scene.'}
  if apply:q['prompt_evidence']=baseline.split('. ')[0]+'.'if r.get('source')=='requester_meaning_bound_by_authorial_core'else next(iter(evidence.values()),baseline.split('. ')[0]+'.')
  c['semantic_clarification_decisions'].append(q)
 c['creative_augmentation_brief']={'decisions':[{'candidate_id':r['id'],'decision':'rejected','rationale':'Retain the frozen environmental geometry and surface condition without optional additions.'}for r in ac.creative_augmentation_candidates_from_pack(p)]}
 save(E/f'{name}-composed.json',c)
 command=[sys.executable,str(S/'audit_composed_prompt.py'),'--pack',str(D/'after'/f'{name}-pack.json'),'--composed',str(E/f'{name}-composed.json')];run=subprocess.run(command,capture_output=True,text=True)
 (E/f'{name}.stdout').write_text(run.stdout);(E/f'{name}.stderr').write_text(run.stderr)
 result=json.loads(run.stdout);save(E/f'{name}-audit.json',result)
 results.append({'case':name,'command':command,'exit_code':run.returncode,'status':result['status'],'failures':result['failures'],'warnings':result['warnings'],'before_visual_failures':ac.audit_visual_obligations(before,c,prompt),'after_visual_failures':ac.audit_visual_obligations(p,c,prompt),'baseline_preserved':prompt.startswith(baseline),'evidence':evidence})
 print(name,result['status'],result['failures'],flush=True)
 save(E/'summary.json',results)
