import json,hashlib
from pathlib import Path
D=Path(__file__).parent
old='before';new='before-after-wethair'
def diff(a,b,path=()):
 if type(a)!=type(b):return [{'path':list(path),'before':a,'after':b}]
 if isinstance(a,dict):
  z=[]
  for k in sorted(a.keys()|b.keys()):
   if k not in a or k not in b:z.append({'path':list(path+(k,)),'before':a.get(k),'after':b.get(k)})
   else:z.extend(diff(a[k],b[k],path+(k,)))
  return z
 if isinstance(a,list):
  if len(a)!=len(b):return [{'path':list(path),'before':a,'after':b}]
  return [x for i,(v,w)in enumerate(zip(a,b))for x in diff(v,w,path+(i,))]
 return []if a==b else[{'path':list(path),'before':a,'after':b}]
rows=[]
for c in json.loads((D/'frozen-input-manifest.json').read_text()):
 name=c['case']
 for f,h in c['inputs'].items():assert hashlib.sha256((D/'inputs'/name/f).read_bytes()).hexdigest()==h
 a=json.loads((D/old/(name+'-pack.json')).read_text());b=json.loads((D/new/(name+'-pack.json')).read_text());delta=diff(a,b)
 (D/new/(name+'-entire-pack-diff.json')).write_text(json.dumps(delta,indent=2)+'\n')
 core=json.loads((D/'inputs'/name/'authorial-core.json').read_text())
 keys=['source_request','baseline_prompt_en','subject','setting','event','visual_priorities','user_exclusions','variation_key']
 assert all(b[0]['authorial_core'][k]==core[k]for k in keys)
 rows.append({'case':name,'entire_pack_diff_count':len(delta),'diff_paths':[r['path']for r in delta],'visual_contract_identical':a[0].get('visual_obligations')==b[0].get('visual_obligations'),'authorial_core_identical':a[0]['authorial_core']==b[0]['authorial_core'],'all_top_level_fields_equal':[k for k in a[0]if a[0][k]==b[0].get(k)],'input_semantics_preserved':True})
meta={'original_head':json.loads((D/old/'run-manifest.json').read_text())['head'],'requalified_head':json.loads((D/new/'run-manifest.json').read_text())['head'],'cases':rows}
(D/'wethair-requalification-comparison.json').write_text(json.dumps(meta,indent=2)+'\n')
print(json.dumps(meta,indent=2))
