import copy,json,sys,hashlib,subprocess
from pathlib import Path
root=Path('REPOSITORY_ROOT'); out=Path(__file__).parent
sys.path.insert(0,str(root/'skills/photo-prompt-image-generator/scripts'))
import prompt_generator as pg
asset=root/'skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations.json'
reg=pg.load_visual_obligation_registry(asset)
by={p['id']:p for p in reg['profiles']}
patches=[
('wetland_hydrology_soil_vegetation_mosaic',['composition_instruction'],'Frame a connected wetland surface where shallow water or visibly saturated low ground, water-shaped soil evidence, hydrophytic vegetation, and raised drier patches can all be compared in one view.'),
('wetland_hydrology_soil_vegetation_mosaic',['render_gates',1,'description'],'Exposed mud, dark saturated soil, or a soft waterlogged margin remains visible with plausible ground contact.'),
('aeolian_dune_stoss_crest_slipface_transport',['composition_instruction'],'Use an oblique side view that keeps the gentle stoss slope, crest line, steep lee slip face, and aligned fine sand ripples or short saltation traces on one connected dune body.')]
proposed=copy.deepcopy(by); changes=[]
for pid,path,value in patches:
 p=proposed[pid]
 for k in path[:-1]:p=p[k]
 changes.append({'file':str(asset.relative_to(root)),'profile_id':pid,'path':path,'before':p[path[-1]],'proposed':value});p[path[-1]]=value
results={}
for pid in {p[0] for p in patches}:
 before=pg.candidate_pack_visual_profile_obligation(by[pid],reg,activation_source='audit',source_intent_ids=[])
 after=pg.candidate_pack_visual_profile_obligation(proposed[pid],reg,activation_source='audit',source_intent_ids=[])
 assert before['composition_instruction']==by[pid]['composition_instruction']
 assert after['composition_instruction']==proposed[pid]['composition_instruction']
 for k in ['component_semantics','prompt_binding','evidence_requirements','runtime_expression','reject_substitutes']:
  assert before[k]==after[k],(pid,k)
 assert [g['id'] for g in before['render_gates']]==[g['id'] for g in after['render_gates']]
 assert [g['review_scale'] for g in before['render_gates']]==[g['review_scale'] for g in after['render_gates']]
 results[pid]={'before':before,'proposed':after,'preserved':'component semantics, literal evidence requirements, gate IDs/scales, runtime expression, reject substitutes'}
(out/'exact-leaves.json').write_text(json.dumps(changes,indent=2)+'\n')
(out/'materialization-proof.json').write_text(json.dumps({'head':subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD'],text=True).strip(),'asset_sha256':hashlib.sha256(asset.read_bytes()).hexdigest(),'results':results},indent=2)+'\n')
print('PASS: three proposed data leaves survive production materialization; activation/evidence/gate identity safeguards unchanged; no repository mutation')
