# Environment/contact alternative audit

Baseline: cad6f905. Read-only repository audit. No runtime/source changes, new vectors, paid calls, image generation or fabricated render reviews.

## Recommend: three data leaves, two existing profiles

Exact old/new strings and selector paths are in `exact-leaves.json`. Production before/proposed obligations are in `materialization-proof.json`, reproduced by `probe.py`. These are composition/review consistency corrections, **not retrieval or eligibility improvements**.

### 1. Wetland: preserve the already-authored saturation branch

Profile `wetland_hydrology_soil_vegetation_mosaic` explicitly defines shallow inundation **or saturated ground**. Its first component and evidence field say shallow standing water **or visibly saturated ground**; soil component permits exposed mud, dark saturated soil, or a soft waterlogged margin; vegetation permits emergent **or water-tolerant** plants; mosaic permits wetter pools, channels **or hollows**. The first render gate also permits water **or saturation**.

Contradictions: composition requires shallow water and emergent vegetation, and `vo_natural_wetland_soil_contact` requires soil at a water margin. A saturated-soil hollow mosaic with rooted wetland plants and raised drier patches can satisfy the stated definition without a visible standing-water margin.

Proposed two leaves align composition and soil-contact gate with the existing definition/components. No change to activation, evidence, cardinality, render gate IDs/scales, rejects, source provenance, or narrow selected candidates. In particular, `wetland_hydric_soil_waterline_surface` and shallow-channel/mosaic slot manifestations remain waterline-specific when selected.

Provenance: existing approved `natural_environment_epa_wetland_hydrology` record abstracts “inundation or saturation” and distinguishes hydrology, soil evidence and vegetation. Its source https://www.epa.gov/wetlands/what-wetland (read 2026-10-02) describes water covering soil or existing at/near its surface and seasonal variation. This supports the existing OR relation; it does not authorize removal of visible soil/vegetation/mosaic obligations, or inference of legal wetland status from pixels.

### 2. Dune: preserve already-authored transport-trace alternative

Profile `aeolian_dune_stoss_crest_slipface_transport` definition permits ripples **or grain-transport traces**. Component/evidence permits fine sand ripples **or short saltation traces**, and `vo_natural_dune_ripples` gate repeats the alternative. Only composition forces aligned surface ripples. Proposed one-leaf edit repeats the existing choice and leaves all geometry, evidence and rejection requirements intact.

Approved evidence `natural_environment_nps_aeolian_dunes` explicitly abstracts aligned ripples or short grain-transport traces. Its source https://www.nps.gov/subjects/geology/aeolian-landforms.htm (read 2026-10-02) supports the stoss/crest/lee geometry. The current web page's general text is not an independent detailed saltation-vs-ripple validation; the already-authored definition/component/gate and approved research abstraction establish the source-internal contradiction.

## Production consumer

- `scripts/prompt_generator.py:7337-7400`, `candidate_pack_visual_profile_obligation`: compiles a profile then copies composition instructions, component semantics, required evidence and render gates into production obligations
- `scripts/audit_composed_prompt.py:1511-1533`: gates become the strict effective required-hard-gate union; `1912-1937` verifies exact gate membership
- `scripts/audit_image_render_review.py:185-194`: expected render review gates derive from target contract gates
- Neither candidate has authored_components that would overwrite proposed leaves during compilation

`probe.py` calls this real production materializer for baseline and in-memory proposed profiles. It asserts preservation of component semantics, prompt bindings, evidence requirements, runtime expression, rejects, gate IDs and review scales. It confirms all proposed composition/gate descriptions survive materialization. No artificial matcher, fake vectors, fabricated image or simulated visual pass is used.

## Frozen control matrix (semantic expectations, not rendered outcomes)

1. Wetland positive A: shallow standing water occupies connected low ground; dark muddy margins and rooted emergent vegetation alternate with higher drier vegetated patches. Before/proposed: admissible; retains existing branch.
2. Wetland positive B: visibly saturated dark-soil hollows, no standing-water pool or waterline; rooted water-tolerant plants and raised relatively drier vegetated patches show one connected mosaic. Before: definition/evidence/connected-water gate admit branch, but composition/soil gate demand added shallow water. Proposed: no contradiction. Not a claim of changed text audit eligibility.
3. Wetland negative A: isolated ornamental pond with reeds at one dry edge. Before/proposed reject: no connected wetland soil/vegetation/microtopography relation.
4. Wetland negative B: dry meadow or flooded lawn without saturated soil evidence and rooted hydrophytes. Before/proposed reject.
5. Wetland locked narrow control: user explicitly selects shallow-waterline wetland surface. Before/proposed retain that source choice; this change is not permission to remove the waterline.
6. Dune positive A: connected gentle stoss, sharp crest and steep lee face with aligned fine ripples. Before/proposed admissible.
7. Dune positive B: same complete asymmetric dune geometry with visible aligned short saltation traces across the stoss; no ripple relief. Before: all components/evidence/gate admit branch but composition asks for ripples. Proposed: no contradiction.
8. Dune negative A: dust cloud alone without connected stoss/crest/slipface. Before/proposed reject.
9. Dune negative B: symmetric studio sand pile or flat ripple texture without dune geometry. Before/proposed reject.
10. Broad controls: “wetland” or “desert” alone must not newly activate these narrow profiles. Activation untouched.

The positive controls are candidate scene specifications for future normal public replay, not executed prompt/image results. Existing baseline natural-environment tests are logged separately.

## Keep/defer

- Rain-threshold floor mat OR stable surface: authored component, evidence, instruction and gate retain OR; no correction
- Object contact support darkening OR compression: alternatives retained in component and gate; shadow consistency is explicit narrow authored contract, not unrelated ownership
- Handled environmental surface hand OR held tool and reverse/substrate/interior alternatives already consistent; keep
- Shared-wind hair/jacket/leaves and architecture connectivity are intentionally authored narrow selected manifestations; do not generalize or delete scene owners
- Glacier composition narrows directional surface structure to crevassed ice, while components allow flow bands/debris stripes. Plausible lower-priority consistency lead; defer rather than expand this bounded proposal
- Intertidal bands, storm tower/anvil, karst losing stream/resurgence are authored narrow systems; no broader conceptual rewrite
