# Mounted-slide thickness: independent AFTER verification

## Result

The exact accepted DATA-only addition is verified against the frozen BEFORE suite. All 11 actual public V6 generation CLIs succeed and all 24 complete composition audits match frozen AFTER expectations: 15 pass and 9 expected fail. Run: 2026-10-03 08:41:37–08:46:29 UTC. The verification performed zero provider calls and generated zero images.

Exact EN and KO thickness-only cases now pass, as does the already-offered source-paraphrase opt-in that failed BEFORE. Density and the original OR wording still pass. The original relation was already density OR thickness; the change adds one standalone lexical realization to two existing arrays and does not reinterpret the relation as a new alternative.

The component-thickness case has changed reachability: its previously unavailable target is now a real eligible returned visual concept, selected under the unchanged frozen conditional policy, with all five duties bound. BEFORE passed only the baseline without a target contract; AFTER passes with the target active. This is separately reported rather than counted as an ordinary fail-to-pass improvement.

## Complete controls and limits

- All four coherent ordinary controls (empty mount, opaque printed card, digital display, picture-bearing glass) pass and their entire public packs are identical, including IDs, all contents and ordering
- All five missing-binding audits still fail their absent-field/distinct-evidence checks
- All four anchor-free wrong-owner binding audits still fail their intended semantic-evidence field checks
- Density and original combined OR controls retain their pass
- All audit warning payloads remain identical
- The 19 previously active target contracts retain the same five effective gate IDs. The newly reachable component-thickness case now activates those same five gates; the four ordinary controls still have none
- The pre-existing old-density digital-caption false pass remains. Three expected new-anchor limits now also falsely pass: digital-caption text, cardboard-owned thickness, and a negated thickness statement. This expansion is an explicit consequence of accepted literal vocabulary and is not physical-semantic validation

The malformed binding/limit probes retain their original positive scene plus contradictory clause and are not coherent alternative photographs. The four ordinary controls are coherent photographs. Synthetic source-aware requests and English evidence on the Korean exact request do not establish organic-query recall or broad Korean binding support.

## Every public-pack change, including order

All 11 full packs were recursively compared without ignoring fields. Raw path/value diffs are retained under `pack-diffs`; ID sequences at every structured list are separately retained under `sequence-diffs`. Additional identity-keyed comparisons distinguish reordering from changed content and are retained under `keyed-pack-diffs`.

Across all cases, authorial core, creative controls, core retrieval, and slot-candidate membership/order are unchanged.

- Four hard-target cases (thickness EN/KO, density, legacy OR): only pack ID and the accepted two target arrays change
- Legacy component and source-paraphrase cases: only pack ID and the accepted two target arrays change by identity. Their optional target changes position from fourth to third, swapping order with `sheer_garment_optical_layering`; no candidate membership changes
- Component thickness: target visual concept is added in third position, preserving the relative order and contents of every old visual concept; count increases from five to six. Pack ID changes. Its semantic-clarification list adds `mounted_slide_transparency_object_relation` and removes `pr_camcorder_still_temporal_container`; all retained clarification contents and their relative order are unchanged. This optional displacement is disclosed, not silently exempted
- Four ordinary controls: no differences

No changes beyond those above appear in the identity-keyed comparisons, and all raw ordering changes are retained. All optional slot/creative candidates remain rejected. Only genuinely offered eligible target concept IDs are selected on the frozen component/paraphrase routes.

## Source/index and frozen-artifact integrity

An independent current-versus-HEAD structured comparison confirms that only the target source profile changes, its new value equals the reviewed accepted profile exactly, only its index entry changes, all other 1,509 entries are identical, and exact lookup is identical. Index top-level changes are limited to registry hash, BM25F and entries. Provider provenance is supplied by the parent's genuine-vector integration record; this verifier makes no additional provider request.

All 112 frozen input/source-review artifact hashes and all 565 entries in the BEFORE artifact manifest are intact. No frozen BEFORE file was modified. Of the 313 pinned source/runtime/asset/procedure files, precisely the authorized source asset and profile index differ from BEFORE. Their hashes were stable throughout this verification. HEAD remained `5bf8142304f484138474fff4af9b0660439fa331` throughout the run. The parent independently added a new regression test, outside the pinned BEFORE source set; this verifier did not edit source, index, tests or runtime.

This is bounded local deterministic component/BM25F exposure and complete textual audit evidence. It does not measure query embeddings, image quality, physical authenticity, chemical composition or visible chemistry. No extra duty, general runtime change, threshold change, translated binding support, or natural-query recall claim is introduced.

## Reproducible evidence

- `run_after.py`: separate adapted runner using the unchanged frozen manifest and selection policy
- `after/report.json`: all 11 CLI and 24 full audit outcomes; raw commands, packs, views, composed payloads and audit outputs accompany it
- `AFTER-SUMMARY.json`: outcome transitions, all expected results, gate identities, ordering and integrity summary
- `KEYED-PACK-DIFF-SUMMARY.json`: exhaustive identity-keyed pack change paths
- `pack-diffs/`, `sequence-diffs/`, `keyed-pack-diffs/`: exact differences, including original ordering
- `helper-diffs.json`: supplemental direct normalization/component behavior
- `independent-source-index-check.json`, `integrity.json`: independent source/index and frozen-artifact checks

No new changes are requested by this verification.
