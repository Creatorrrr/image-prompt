from compare_after import *
def keyed(x):
 if isinstance(x,dict):return{k:keyed(v)for k,v in x.items()}
 if isinstance(x,list):
  if x and all(isinstance(v,dict)and 'id'in v for v in x)and len({v['id']for v in x})==len(x):return{v['id']:keyed(v)for v in x}
  return[keyed(v)for v in x]
 return x
summary=[]
for case in man['case_ids']:
 old=read(B/'before'/case/'pack.json')[0];new=read(A/case/'pack.json')[0];dd=diff(keyed(old),keyed(new));dump(P/'keyed-pack-diffs'/(case+'.json'),dd)
 summary.append(dict(id=case,changes=[dict(path=x['path'],change=x.get('change','value'))for x in dd]))
dump(P/'KEYED-PACK-DIFF-SUMMARY.json',summary)
print(json.dumps(summary,indent=2))
