#!/usr/bin/env python3
"""Bounded source-aware synthetic V6 BEFORE qualification. Artifact writes only."""
from pathlib import Path
import copy, hashlib, json, os, subprocess, sys, time, traceback
sys.dont_write_bytecode=True
P=Path('EVIDENCE_ROOT/slide-thickness-qualification');R=P.parent.parent/'image-prompt';S=R/'skills/photo-prompt-image-generator/scripts';A=S.parent/'assets';PRE=S.parent/'precore'
PID='mounted_slide_transparency_object_relation';FIELD='film_edge_density_phrase';PIN='5bf8142304f484138474fff4af9b0660439fa331';SEED=1003
REVIEW=P.parent/'slide-thickness-review'
def sha(b):return hashlib.sha256(b).hexdigest()
def read(p):return json.loads(p.read_text())
def dump(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def git(*args):return subprocess.check_output(['git',*args],cwd=R,text=True).strip()
def utc():return subprocess.check_output(['date','-u','+%FT%TZ'],text=True).strip()
def modules():
 sys.path.insert(0,str(S));import prompt_generator as g;import audit_composed_prompt as audit
 return g,audit

def anchor(id,src,ev,dim,target=None,prop=None):
 x=dict(anchor_id=id,source_text=src,prompt_evidence=ev,dimension=dim)
 if prop:x.update(target=target,property=prop)
 return x

def embodiment(prompt,phase='agent_prepack'):
 return dict(contract_version='photo-embodiment-review/v1',provenance=phase,prompt_sha256=sha(prompt.encode()),scope='not_applicable',summary='A one-object tabletop material study with no living actor, hands, body or bodily mechanism. Support, ownership and crop receive a separate textual coherence review; pixels are not verified.',checks={})

def prepare():
 assert git('rev-parse','HEAD')==PIN and not git('status','--porcelain')
 assert not(P/'drafts').exists(),'Preserve earlier preparation'
 integrity={k:sha((REVIEW/k).read_bytes())==v for k,v in read(REVIEW/'artifact-manifest.json').items()}
 assert all(integrity.values())
 decision=read(REVIEW/'decision.json');assert decision['decision']=='accept_exact_two_array_addition_for_later_authorized_integration'
 dump(P/'ACCEPT-VERIFIED.json',dict(at_utc=utc(),decision=decision,artifact_integrity=integrity,review_manifest_sha256=sha((REVIEW/'artifact-manifest.json').read_bytes())))
 old=read(REVIEW/'before-profile.json')
 ev={
 'transparent_film_phrase':'A transparent film frame carries a small shoreline photograph',
 'physical_mount_phrase':'A physical mount made of cardboard surrounds this same film with a complete visible silhouette',
 'transmitted_light_phrase':'Transmitted light passes from a diffuse lamp behind the slide through the image-bearing film',
 'image_in_aperture_phrase':'The image contained within mount aperture stays entirely inside its rectangular opening',
 FIELD:'Film edge thickness is visible as a thin transparent rim at the boundary of this same image-bearing layer'}
 density=copy.deepcopy(ev);density[FIELD]='Film edge density is visible as a narrow darker rim belonging to the same image-bearing film'
 legacy=copy.deepcopy(ev);legacy[FIELD]='Film edge density or thickness is visible at the image-bearing boundary, with the thickness branch realized by its thin transparent rim'
 con='A tabletop transparency study';sub='exactly one cardboard-mounted photographic slide';event='backlight illuminates the contained shoreline photograph'
 crop='One continuous frame includes the complete mount silhouette and the entire aperture'
 tail=crop+'. The slide rests upright in a narrow groove on a plain charcoal support. A shallow camera angle exposes the film rim beside the aperture while keeping the whole rectangular surround visible. The quiet background directs attention to the transparent image and its own edge.'
 common='Show exactly one cardboard-mounted photographic slide with a transparent film frame, backlight passing through its shoreline photograph, and the image contained entirely inside the mount aperture. Keep the complete mount silhouette and entire aperture visible in one continuous frame. Show the thickness of the image-bearing film as a thin transparent edge rather than assigning that thickness to the cardboard mount. No people.'
 cases=[]
 def film(id,req,evidence,route='exact',language='en',before='fail'):
  base=f'{con} shows {sub}; {event}. '+' '.join(v+'.'for v in evidence.values())+' '+tail
  aa=[anchor('concept',req,con,'concept'),anchor('subject',req,sub,'subject'),anchor('event',req,event,'event'),anchor('count',req,sub,'composition','slide','count'),anchor('crop',req,crop,'framing','photograph','complete_mount_and_aperture')]
  aa += [anchor('relation_'+str(i),req,v,'material','slide',k)for i,(k,v)in enumerate(evidence.items())]
  cases.append(dict(id=id,request=req,baseline=base,anchors=aa,subject=sub,concept=con,event=event,crop=crop,setting='a plain charcoal support with a narrow mounting groove',evidence=evidence,profile=PID,route=route,language=language,expected_before=before,expected_after='pass',surface=evidence[FIELD],light=evidence['transmitted_light_phrase']))
 film('thickness_en','Photograph a '+old['activation']['exact_terms'][0]+'. '+common,ev)
 film('thickness_ko','마운트된 사진 슬라이드 투명 원고 객체를 촬영한다. 판지 마운트에 끼워진 사진 슬라이드 한 장만 보여 준다. 투명 필름 안의 해안선 사진으로 뒤쪽 빛이 통과하고, 사진은 마운트 구멍 안에 온전히 들어 있다. 마운트의 완전한 외곽과 구멍 전체를 하나의 연속된 프레임에 담는다. 두께는 판지 테두리가 아니라 사진이 담긴 필름 자체의 얇고 투명한 가장자리로 보여 준다. 사람은 없다.',ev,language='ko')
 film('density_en','Photograph a '+old['activation']['exact_terms'][0]+'. '+common.replace('Show the thickness of the image-bearing film as a thin transparent edge rather than assigning that thickness to the cardboard mount.','Show film edge density as a narrow darker rim on the image-bearing film.'),density,before='pass')
 film('legacy_or_en','Photograph a '+old['activation']['exact_terms'][0]+'. '+common+' Preserve the relation film edge density or thickness, realizing its transparent thin-film thickness branch.',legacy,before='pass')
 film('component_thickness_en','Photograph a single mounted color slide with these relations visible together: '+'. '.join(ev.values())+'. '+common,ev,route='component',before='unavailable_or_fail')
 film('component_legacy_en','Photograph a single mounted color slide with these relations visible together: '+'. '.join(legacy.values())+'. '+common,legacy,route='component',before='unavailable_or_pass')
 film('source_paraphrase_en','Photograph '+old['semantics']['paraphrase_examples'][0]+'. '+common,ev,route='component',before='unavailable_or_fail')
 controls=[
 ('empty_mount','An empty-mount material study','exactly one empty cardboard mount','the bare aperture opens directly onto the background','The thick cardboard edge surrounds an open hole filled only by the distant background','Light from the side reveals the thickness of the cardboard surround'),
 ('printed_card','A printed-card material study','exactly one opaque photographic card','a shoreline photograph covers the card face','The printed image belongs to opaque paper with a thick cut edge','Reflected light illuminates the paper image from the camera side'),
 ('digital_display','A screen material study','exactly one flat digital display','an illuminated screen shows a shoreline photograph inside a simulated rectangular border','The simulated border and photograph are pixels on the flat screen behind smooth cover glass','The display emits light through its smooth glass face'),
 ('glass_support','A glass-picture material study','exactly one picture-bearing glass pane','backlight illuminates a shoreline image on rigid glass','The image belongs to rigid glass with a thick polished perimeter','A diffuse lamp shines through the image-bearing glass from behind'),
 ]
 for id,con,sub,event,surf,light in controls:
  crop='One continuous frame includes the complete object perimeter and its whole image area'if id!='empty_mount'else'One continuous frame includes the complete mount silhouette and its entire empty aperture'
  req=f'Photograph {sub}. {event}. {surf}. {light}. {crop}. No people.'
  base=f'{con} shows {sub} resting upright on a plain charcoal support. In this frame, {event}. {surf}. {light}. {crop}. A shallow camera angle makes the physical edge readable while the quiet background separates the single object from its surroundings. The photograph records this stated support and surface relation as one coherent still life.'
  aa=[anchor('concept',req,con,'concept'),anchor('subject',req,sub,'subject'),anchor('event',req,event,'event'),anchor('material',req,surf,'material','primary_object','physical_support'),anchor('light',req,light,'lighting','primary_object','illumination'),anchor('count',req,sub,'composition','primary_object','count'),anchor('crop',req,crop,'framing','photograph','complete_perimeter')]
  cases.append(dict(id=id,request=req,baseline=base,anchors=aa,subject=sub,concept=con,event=event,crop=crop,setting='a plain charcoal support',evidence={},profile=None,route='ordinary_control',language='en',expected_before='pass',expected_after='pass',surface=surf,light=light))
 catalog=read(PRE/'visual_feature_catalog.json');(P/'visual_feature_catalog.snapshot.json').write_bytes((PRE/'visual_feature_catalog.json').read_bytes())
 # Controls are resolved before core serialization, using the candidate-free resolver.
 sys.path.insert(0,str(PRE));import creative_controls
 templates=[]
 for c in cases:
  req=c['request'];base=c['baseline'];d=P/'drafts'/c['id']
  env=dict(contract_version='photo-request-envelope/v1',provenance='requesting_user',request_id='synthetic-slide-'+c['id'],request_text=req,request_sha256=sha(req.encode()),active_spans=[dict(span_id='scene',start=0,end=len(req),text=req)])
  context=dict(subject_category='nonhuman',no_people=True,explicit_nonsexual=False)
  overrides=dict(sensual=0,fetish=0,creativity=0,surreal=0)
  ctl=creative_controls.resolve(req,overrides=overrides,context=context,seed=SEED)
  core=dict(contract_version='photo-authorial-core/v3',provenance='agent_prepack',source_request=req,creative_controls_sha256=ctl['canonical_sha256'],interpreted_intent='A source-aware synthetic one-object tabletop photograph. Preserve the stated physical support, same-object image ownership, count and complete perimeter. Textual material relationships do not establish chemical composition, manufacture, historical authenticity or successful pixels.',subject=c['subject'],setting=c['setting'],event=c['event'],visual_priorities=[c['subject'],c['event'],c['surface']],baseline_prompt_en=base,user_definitions=[],interpretation_provenance=[dict(term='synthetic material-state request',source_text=req,basis='request_context',resolution='Show '+c['event']+' on '+c['subject']+' with the stated support, edge and crop.',sources=[])],unresolved_ambiguities=[],user_exclusions=['사람'if c['language']=='ko'else'people'],runtime_forbidden_labels=[],intent_lock=dict(contract_version='photo-intent-lock/v2',priority='requesting_user',semantic_anchors=c['anchors'],locked_dimensions=['concept','subject','event'],open_dimensions=['setting','appearance','material','framing','composition','lighting','camera','color','atmosphere','relationship']),semantic_assertions=[dict(assertion_id='primary_subject',dimension='subject',polarity='required',source_span_ids=['scene'],affected_dimensions=['subject'],axes=dict(subject_category='object'),evidence=dict(subject_phrase=c['subject']))],request_lineage=None,style=dict(domain='general_photo',family='tabletop material still life',evidence=['readable physical edges','complete object perimeter']),variation_key='slide-qualification-'+c['id'])
  selected=[]
  for cat,phrase,reason in [('feature.subject',c['subject'],'Keep the sole physical image carrier as the main subject.'),('feature.situation',c['event'],'Show the requested material state in a single exposure.'),('feature.texture',c['surface'],'Keep the stated surface and edge cue on its correct physical owner.'),('feature.lighting_direction',c['light'],'Make the stated transmission, emission or reflection relation readable.'),('feature.framing',c['crop'],'Retain the complete perimeter needed to distinguish the physical carrier.')]:
   selected.append(dict(category_id=cat,basis='request_derived',source_span_ids=['scene'],source_text=None,derivation='A visible realization of the support and scene described in the active request.',reason=reason,baseline_evidence=phrase))
  feature=dict(contract_version='photo-precore-feature-selection/v1',request_id=env['request_id'],active_span_ids=['scene'],catalog_path='skills/photo-prompt-image-generator/precore/visual_feature_catalog.json',catalog_schema_version=catalog['schema_version'],catalog_sha256=sha((PRE/'visual_feature_catalog.json').read_bytes()),request_sha256=env['request_sha256'],baseline_prompt_sha256=sha(base.encode()),selected=selected)
  for n,x in [('envelope',env),('controls',ctl),('context',context),('overrides',overrides),('core',core),('review',embodiment(base)),('feature-selection',feature),('spec',c)]:dump(d/(n+'.json'),x)
  templates.append(dict(id=c['id'],case=c['id'],prompt=base,bindings=c['evidence'],expected_before=c['expected_before'],expected_after=c['expected_after'],kind='positive'if c['profile']else'ordinary_control',select_target_if_offered=c['route']=='component'))
 base=next(c['baseline']for c in cases if c['id']=='legacy_or_en')
 for f in ev:
  probe=copy.deepcopy(legacy);del probe[f]
  templates.append(dict(id='missing_'+f,case='legacy_or_en',prompt=base,bindings=probe,expected_before='fail',expected_after='fail',kind='missing_binding',failure_field=f))
 wrong=[('paper_support','transparent_film_phrase','An opaque paper print carries the image on rough fibers'),('glass_support','transparent_film_phrase','A rigid glass plate carries the picture behind a thick polished edge'),('cardboard_edge',FIELD,'The thick cardboard rim belongs only to the surrounding mount'),('digital_edge',FIELD,'A raised-looking digital bevel is drawn on the flat screen border')]
 for name,f,value in wrong:
  probe=copy.deepcopy(legacy);probe[f]=value
  templates.append(dict(id='boundary_'+name,case='legacy_or_en',prompt=base+' '+value+'.',bindings=probe,expected_before='fail',expected_after='fail',kind='wrong_owner_binding',failure_field=f,contradictory_content=True))
 limits=[('old_anchor_digital','Film edge density is merely caption text on a flat digital display','pass','pass'),('new_anchor_digital','Film edge thickness is merely caption text on a flat digital display','fail','pass'),('new_anchor_cardboard','Film edge thickness is the thickness of the cardboard mount rather than the film','fail','pass'),('new_anchor_negated','There is no film edge thickness visible in this photograph','fail','pass')]
 for name,value,before,after in limits:
  probe=copy.deepcopy(legacy);probe[FIELD]=value
  templates.append(dict(id='limit_'+name,case='legacy_or_en',prompt=base+' '+value+'.',bindings=probe,expected_before=before,expected_after=after,kind='known_lexical_limit',failure_field=FIELD,contradictory_content=True))
 dump(P/'compositions.draft.json',templates)
 dump(P/'qualification-scope.json',dict(synthetic_source_aware=True,clean_precore=False,organic_user_requests=False,natural_query_recall=False,images=0,provider_calls=0,wire_provenance_note='The real CLI requires requesting_user and agent_prepack wire enums. These are openly source-aware synthetic canonical fixtures authored after source inspection, not actual user photographic requests or clean pre-core samples.',source_exact_labels=old['activation']['exact_terms'],source_paraphrase=old['semantics']['paraphrase_examples'][0],source_legacy_anchors=old['evidence_requirements'][FIELD]['must_mention_any'],new_anchor='film edge thickness',duties=list(ev),invented_duties=[],exclusions=['No emulsion-chemistry, visible chemical-layer separation, perforation or sprocket-hole obligation is added.'],selection_policy='Reject every optional slot and creative candidate. On component/source-paraphrase routes only, select the target visual concept if and only if actually offered and eligible, with its full evidence. If absent, record target unavailable and audit the unchanged baseline without target evidence; do not call that a target-contract pass.',limits=['The old combined anchor already expresses OR; this is a definite thickness-only literal branch gap.','Literal helpers and composed auditing cannot establish truth or physical ownership when misleading prose retains an accepted anchor.','English evidence on a Korean exact request is not broad Korean binding support.','Local deterministic component/BM25F exposure is not query-embedding recall or image-quality evidence.'],controls=['four coherent physical empty-mount, printed-card, digital-display and wrong-glass-support photographs','five deliberately omitted relation bindings against a complete active-profile scene','four anchor-free wrong-owner evidence probes','four anchor-retaining literal limits']))
 print('Prepared',len(cases),'cases;',len(templates),'composition templates',flush=True)

def preflight():
 g,_=modules();out=P/'preflight'/('attempt-%02d'%(len(list((P/'preflight').glob('attempt-*')))+1));out.mkdir(parents=True)
 rows=[]
 for d in sorted((P/'drafts').iterdir()):
  for f in d.glob('*.json'):dump(out/d.name/f.name,read(f))
  row=dict(id=d.name)
  try:
   env=g.load_request_envelope_arg(str(d/'envelope.json'));ctl=read(d/'controls.json');core=g.load_authorial_core_arg(str(d/'core.json'),request_envelope=env,creative_control_snapshot=ctl);policy=g.photo_embodiment.build_policy(core,read(d/'review.json'))
   cmd=[str(R/'.venv/bin/python'),str(S/'validate_precore_feature_selection.py'),'--catalog',str(PRE/'visual_feature_catalog.json'),'--request-envelope',str(d/'envelope.json'),'--authorial-core',str(d/'core.json'),'--embodiment-review',str(d/'review.json'),'--selection',str(d/'feature-selection.json')]
   p=subprocess.run(cmd,cwd=R,capture_output=True,text=True);dump(out/d.name/'feature-cli.json',dict(command=cmd,exit_code=p.returncode,stdout=p.stdout,stderr=p.stderr));assert p.returncode==0,p.stdout+p.stderr
   row.update(status='pass',core_sha256=core['canonical_sha256'],lock_sha256=core['intent_lock']['canonical_sha256'],embodiment_policy=policy)
  except Exception as e:row.update(status='fail',error=str(e),traceback=traceback.format_exc())
  rows.append(row)
 dump(out/'report.json',rows);print(json.dumps([dict(id=x['id'],status=x['status'],error=x.get('error'))for x in rows],indent=2));return rows

def freeze():
 assert not(P/'manifest.json').exists(),'Never overwrite frozen inputs'
 assert(P/'ACCEPT-VERIFIED.json').exists()
 rows=preflight();assert all(x['status']=='pass'for x in rows)
 assert git('rev-parse','HEAD')==PIN and not git('status','--porcelain')
 for f in sorted(REVIEW.iterdir()):
  if f.is_file():dest=P/'source-freeze'/'slide-thickness-review'/f.name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(f.read_bytes())
 for f in(P/'drafts').rglob('*.json'):dump(P/'inputs'/f.relative_to(P/'drafts'),read(f))
 dump(P/'compositions.json',read(P/'compositions.draft.json'))
 files=sorted(set([*A.rglob('*.json'),*S.rglob('*.py'),*(S.parent/'precore').glob('*.*'),S.parent/'SKILL.md',S.parent/'references/composition-contract.md']))
 source_hashes={str(f.relative_to(R)):sha(f.read_bytes())for f in files if f.is_file()}
 frozen=[*(P/'inputs').rglob('*.json'),*(P/'source-freeze').rglob('*'),P/'compositions.json',P/'qualification-scope.json',P/'ACCEPT-VERIFIED.json',P/'qualify.py',P/'visual_feature_catalog.snapshot.json']
 dump(P/'manifest.json',dict(baseline_head=PIN,case_ids=sorted(d.name for d in(P/'inputs').iterdir()),source_hashes=source_hashes,input_hashes={str(f.relative_to(P)):sha(f.read_bytes())for f in frozen if f.is_file()},frozen_at_utc=utc()))
 print('Frozen',len(rows),'valid cases before retrieval',flush=True)

def state(man):return dict(head=git('rev-parse','HEAD'),status=git('status','--porcelain'),source_hashes={f:sha((R/f).read_bytes())for f in man['source_hashes']})
def run(arm):
 g,audit=modules();man=read(P/'manifest.json');assert all(sha((P/f).read_bytes())==h for f,h in man['input_hashes'].items()),'Frozen-input drift'
 assert arm=='after'; assert (P.parent/'slide-thickness-index-validation/index-verification.json').exists()
 assert not(OUTPUT/arm).exists(),'Never overwrite a run'; changed=[f for f,h in man['source_hashes'].items() if sha((R/f).read_bytes())!=h]; assert set(changed)=={'skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations_photo_era.json','skills/photo-prompt-image-generator/assets/photo_prompt_visual_profile_index.json'},changed
 out=OUTPUT/arm;out.mkdir();dump(out/'source-start.json',state(man))
 env={k:v for k,v in os.environ.items()if not any(t in k.upper()for t in ['API_KEY','TOKEN','SECRET','CREDENTIAL'])};env['PYTHONDONTWRITEBYTECODE']='1'
 report=dict(arm=arm,started_at_utc=utc(),cases=[],compositions=[],scope='Actual public V6 CLI and complete composed-prompt CLI audits, source-aware synthetic fixtures, local deterministic retrieval only, zero provider calls or images.');packs={}
 for id in man['case_ids']:
  d=P/'inputs'/id;dest=out/id;dest.mkdir();cmd=[str(R/'.venv/bin/python'),str(S/'generate_photo_prompt.py'),'--seed',str(SEED)]
  for a,n in [('request-envelope','envelope'),('authorial-core','core'),('creative-controls','controls'),('embodiment-review','review')]:cmd+=['--'+a+'-json',str(d/(n+'.json'))]
  cmd+=['--output-file',str(dest/'pack.json')];start=time.monotonic();p=subprocess.run(cmd,cwd=R,env=env,capture_output=True,text=True,timeout=600);dump(dest/'cli.json',dict(command=cmd,exit_code=p.returncode,stdout=p.stdout,stderr=p.stderr,seconds=time.monotonic()-start));row=dict(id=id,exit_code=p.returncode,stderr=p.stderr)
  if p.returncode==0:
   pack=read(dest/'pack.json')[0];packs[id]=pack
   row.update(contract_version=pack.get('contract_version'),hard_profiles=[x['id']for x in pack.get('visual_obligations',{}).get('obligations',[])],optional_profiles=[dict(candidate_id=x['id'],profile_id=x.get('opt_in_contract',{}).get('obligation',{}).get('id'))for x in pack.get('visual_concept_candidates',{}).get('candidates',[])],slot_candidate_ids=[x['id']for b in pack['slots'].values()for x in b.get('candidates',[])],core_sha256=pack['authorial_core']['canonical_sha256'],lock_sha256=pack['authorial_core']['intent_lock']['canonical_sha256'],retrieval_sha256=pack['core_retrieval']['canonical_sha256'])
   cv=[str(R/'.venv/bin/python'),str(S/'compose_pack_view.py'),'--pack',str(dest/'pack.json'),'--output',str(dest/'composer-view.json')]
   v=subprocess.run(cv,cwd=R,env=env,capture_output=True,text=True);dump(dest/'view-cli.json',dict(command=cv,exit_code=v.returncode,stdout=v.stdout,stderr=v.stderr))
   candidates=[x for x in pack.get('visual_concept_candidates',{}).get('candidates',[])if x.get('opt_in_contract',{}).get('obligation',{}).get('id')==PID]
   dump(dest/'target-offers.json',candidates)
  report['cases'].append(row);dump(out/'report.json',report);print(arm,id,p.returncode,row.get('hard_profiles'),flush=True)
 for t in read(P/'compositions.json'):
  id=t['id'];case=t['case']
  if case not in packs:report['compositions'].append(dict(id=id,status='not_run_no_pack'));continue
  pack=packs[case];core=pack['authorial_core'];lock=core['intent_lock'];prompt=t['prompt'];spec=read(P/'inputs'/case/'spec.json');chosen=[]
  offers=[x for x in pack.get('visual_concept_candidates',{}).get('candidates',[])if x.get('opt_in_contract',{}).get('obligation',{}).get('id')==PID]
  if t.get('select_target_if_offered'):chosen=[x['id']for x in offers if x.get('applicability',{}).get('status','eligible')=='eligible']
  hard=PID in [x['id']for x in pack.get('visual_obligations',{}).get('obligations',[])];active=hard or bool(chosen)
  composed=dict(core_retrieval_sha256=pack['core_retrieval']['canonical_sha256'],pack_id=pack['pack_id'],prompt_en=prompt,negative_en=pack['negative_en'],chosen_candidate_ids=[],chosen_visual_concept_ids=chosen,composer='agent',candidate_interpretations=[],authorial_core_binding=dict(source_authorial_core_sha256=core['canonical_sha256'],source_intent_lock_sha256=lock['canonical_sha256'],preserved_anchor_ids=[a['anchor_id']for a in lock['semantic_anchors']],preserved_evidence=[],authorial_decisions=[]),semantic_clarification_decisions=[dict(clarification_id=r['id'],decision='applied'if r.get('required_in_final_prompt')else'rejected',rationale='Preserve the frozen material scene and decline optional reinterpretation.',prompt_evidence=lock['semantic_anchors'][0]['prompt_evidence'])for r in pack.get('semantic_clarification',{}).get('candidates',[])],creative_augmentation_brief=dict(decisions=[dict(candidate_id=r['id'],decision='rejected',rationale='The one-object material scene is complete without optional augmentation.')for r in pack.get('creative_augmentation',{}).get('candidates',[])]),embodiment_review=dict(source_contract_sha256=pack['embodiment_preflight']['canonical_sha256'],review=embodiment(prompt,'agent_postcomposition')))
  if active:composed['visual_obligation_evidence']={PID:t['bindings']}
  if pack.get('semantic_assertion_obligations'):
   composed['semantic_assertion_evidence']=dict(source_contract_sha256=pack['semantic_assertion_obligations']['canonical_sha256'],evidence={x['assertion_id']:x['evidence']for x in core['semantic_assertions']if x['polarity']=='required'and x['dimension']!='character_response'})
  dest=out/'compositions'/id;dump(dest/'composed.json',composed);direct=audit.audit_visual_obligations(pack,composed,prompt);effective,ef=audit.derive_effective_visual_obligation_contract(pack,composed)
  cmd=[str(R/'.venv/bin/python'),str(S/'audit_composed_prompt.py'),'--pack',str(out/case/'pack.json'),'--composed',str(dest/'composed.json')];p=subprocess.run(cmd,cwd=R,env=env,capture_output=True,text=True,timeout=600);dump(dest/'cli.json',dict(command=cmd,exit_code=p.returncode,stdout=p.stdout,stderr=p.stderr))
  try:result=json.loads(p.stdout)
  except Exception:result=dict(status='error',failures=[dict(reason=p.stderr)])
  dump(dest/'audit.json',result);dump(dest/'direct-visual.json',dict(failures=direct,effective_contract=effective,effective_contract_failures=ef))
  row=dict(id=id,case=case,kind=t['kind'],status=result['status'],expected=t['expected_after'],exit_code=p.returncode,failures=result['failures'],direct_visual_failures=direct,warnings=result.get('warnings',[]),target_contract_status='active'if active else'unavailable'if spec['profile']else'not_requested',chosen_candidate_ids=[],chosen_visual_concept_ids=chosen,effective_profile_ids=[x['id']for x in(effective or{}).get('obligations',[])],effective_gate_ids=(effective or{}).get('required_hard_gates',[]))
  report['compositions'].append(row);dump(out/'report.json',report);print(id,row['status'],row['target_contract_status'],[(f.get('check'),f.get('field'))for f in row['failures']],flush=True)
 reg=g.load_visual_obligation_registry(A/'photo_prompt_visual_obligations.json');profile=next(x for x in reg['profiles']if x['id']==PID);helpers=[]
 for t in read(P/'compositions.json'):
  if not t['bindings']:continue
  phrase=' '.join(t['bindings'].values());vi=dict(contract_version=g.VISUAL_INTENT_CONTRACT_VERSION,provenance='agent_prepack',obligations=[dict(profile_id=PID,source='explicit_user_requirement',scope='request_only',source_text=profile['activation']['exact_terms'][0],bindings=t['bindings'])])
  try:g.normalize_visual_intent(vi,reg);normalized=dict(ok=True)
  except Exception as e:normalized=dict(ok=False,error=str(e))
  helpers.append(dict(id=t['id'],component_match=g.candidate_pack_visual_component_match(profile,phrase),normalized=normalized))
 dump(out/'helper-boundaries.json',helpers);dump(out/'source-end.json',state(man));report['finished_at_utc']=utc();dump(out/'report.json',report)
 print('Finished',arm,'input drift:',any(sha((P/f).read_bytes())!=h for f,h in man['input_hashes'].items()),flush=True)
OUTPUT=Path('EVIDENCE_ROOT/slide-thickness-after')
if __name__=='__main__':
 action=sys.argv[1]
 if action=='prepare':prepare()
 elif action=='preflight':preflight()
 elif action=='freeze':freeze()
 else:run(action)
