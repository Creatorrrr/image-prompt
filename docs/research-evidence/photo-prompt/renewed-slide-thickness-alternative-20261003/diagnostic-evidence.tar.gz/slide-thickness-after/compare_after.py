#!/usr/bin/env python3
from pathlib import Path
import hashlib,json,collections
P=Path(__file__).resolve().parent;B=P.parent/'slide-thickness-qualification';R=P.parent.parent/'image-prompt';A=P/'after'
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def diff(a,b,path=''):
 if type(a)!=type(b):return [dict(path=path,before=a,after=b)]
 if isinstance(a,dict):
  out=[]
  for k in sorted(a.keys()|b.keys()):
   p=path+'/'+k
   if k not in a:out.append(dict(path=p,change='added',after=b[k]))
   elif k not in b:out.append(dict(path=p,change='removed',before=a[k]))
   else:out+=diff(a[k],b[k],p)
  return out
 if isinstance(a,list):
  if len(a)!=len(b):return [] if a==b else [dict(path=path,change='list_changed',before=a,after=b)]
  return [x for i,(v,w) in enumerate(zip(a,b)) for x in diff(v,w,path+'/'+str(i))]
 return [] if a==b else [dict(path=path,before=a,after=b)]
def sequences(j,p=''):
 out={}
 if isinstance(j,dict):
  for k,v in j.items():out.update(sequences(v,p+'/'+k))
 elif isinstance(j,list):
  if j and all(isinstance(v,dict)and 'id'in v for v in j):out[p]=[v['id']for v in j]
  for i,v in enumerate(j):out.update(sequences(v,p+'/'+str(i)))
 return out
man=read(B/'manifest.json');bm=read(B/'artifact-manifest-before.json');report=read(A/'report.json');before=read(B/'before/report.json')
assert len(report['cases'])==11 and len(report['compositions'])==24
integrity={k:sha(B/k)==h for k,h in bm.items()};frozen={k:sha(B/k)==h for k,h in man['input_hashes'].items()}
rows=[]
for case in man['case_ids']:
 old=read(B/'before'/case/'pack.json')[0];new=read(A/case/'pack.json')[0];dd=diff(old,new);dump(P/'pack-diffs'/(case+'.json'),dd)
 seq1=sequences(old);seq2=sequences(new);changed=[]
 for path in sorted(seq1.keys()|seq2.keys()):
  if seq1.get(path)!=seq2.get(path):changed.append(dict(path=path,before=seq1.get(path),after=seq2.get(path)))
 dump(P/'sequence-diffs'/(case+'.json'),changed)
 def concepts(pack):return[x['id']for x in pack.get('visual_concept_candidates',{}).get('candidates',[])]
 def slots(pack):return{k:[x['id']for x in v.get('candidates',[])]for k,v in pack['slots'].items()}
 rows.append(dict(id=case,differing_top_level_keys=sorted({x['path'].split('/')[1]for x in dd}),raw_diff_count=len(dd),sequence_change_count=len(changed),visual_concept_ids_before=concepts(old),visual_concept_ids_after=concepts(new),slot_candidate_order_identical=slots(old)==slots(new),core_identical=old['authorial_core']==new['authorial_core'],creative_controls_identical=old['creative_controls']==new['creative_controls'],retrieval_identical=old['core_retrieval']==new['core_retrieval']))
oldrows={x['id']:x for x in before['compositions']};outcomes=[]
for row in report['compositions']:
 old=oldrows[row['id']];outcomes.append(dict(id=row['id'],kind=row['kind'],before=old['status'],after=row['status'],expected=row['expected'],expectation_matches=row['status']==row['expected'],route_before=old['target_contract_status'],route_after=row['target_contract_status'],selected_before=old['chosen_visual_concept_ids'],selected_after=row['chosen_visual_concept_ids'],gates_before=old['effective_gate_ids'],gates_after=row['effective_gate_ids'],failures_before=old['failures'],failures_after=row['failures'],warnings_identical=old['warnings']==row['warnings']))
helpers_before=read(B/'before/helper-boundaries.json');helpers_after=read(A/'helper-boundaries.json');dump(P/'helper-diffs.json',diff(helpers_before,helpers_after))
source_start=read(A/'source-start.json');source_end=read(A/'source-end.json');changes=[k for k,h in man['source_hashes'].items()if source_end['source_hashes'][k]!=h]
summary=dict(cli_total=11,cli_pass=sum(x['exit_code']==0 for x in report['cases']),composition_total=24,counts=dict(collections.Counter(x['status']for x in report['compositions'])),expectation_misses=[x for x in outcomes if not x['expectation_matches']],frozen_input_integrity=all(frozen.values()),frozen_input_count=len(frozen),before_artifact_integrity=all(integrity.values()),before_artifact_count=len(integrity),source_changed_files=changes,source_stable_through_run=source_start['source_hashes']==source_end['source_hashes'],head_start=source_start['head'],head_end=source_end['head'],packs=rows,outcomes=outcomes,provider_calls=0,images=0)
dump(P/'AFTER-SUMMARY.json',summary);dump(P/'integrity.json',dict(frozen_inputs=frozen,before_artifacts=integrity));print(json.dumps({k:v for k,v in summary.items()if k not in ['packs','outcomes']},indent=2));print('PACK DIFF KEYS',[(x['id'],x['differing_top_level_keys'],x['sequence_change_count'])for x in rows])
