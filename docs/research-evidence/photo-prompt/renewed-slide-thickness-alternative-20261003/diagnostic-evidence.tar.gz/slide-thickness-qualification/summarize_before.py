from pathlib import Path
from collections import Counter
import hashlib,json
P=Path(__file__).resolve().parent

def read(n):return json.loads((P/n).read_text())
def dump(n,x):(P/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
r=read('before/report.json');m=read('manifest.json');assert r.get('finished_at_utc')
inputs_ok={f:sha(P/f)==v for f,v in m['input_hashes'].items()}
start=read('before/source-start.json');end=read('before/source-end.json')
by={x['id']:x for x in r['compositions']}
checks=[]
for x in r['compositions']:
 exp=x['expected'];actual=x['status'];target=x['target_contract_status']
 if exp.startswith('unavailable_or_'): ok=(target=='unavailable' and actual=='pass')or(target=='active'and actual==exp.removeprefix('unavailable_or_'))
 else:ok=actual==exp
 checks.append(dict(id=x['id'],expected=exp,actual=actual,target_contract_status=target,matches=ok))
summary=dict(head=start['head'],started_at_utc=r['started_at_utc'],finished_at_utc=r['finished_at_utc'],cli_total=len(r['cases']),cli_pass=sum(x['exit_code']==0 for x in r['cases']),composition_total=len(r['compositions']),composition_counts=dict(Counter(x['status']for x in r['compositions'])),expectations=checks,expectation_misses=[x for x in checks if not x['matches']],target_unavailable=[x['id']for x in r['compositions']if x['target_contract_status']=='unavailable'],source_runtime_identical=start==end,frozen_input_count=len(inputs_ok),frozen_input_integrity=all(inputs_ok.values()),source_hash_count=len(m['source_hashes']),no_repo_changes=start['status']==end['status']=='',manifest_sha256=sha(P/'manifest.json'),after_status='not_run_pending_actual_authorized_source_and_genuine_index_readiness')
dump('BEFORE-SUMMARY.json',summary)
coherence=[]
for case in r['cases']:
 s=read('inputs/'+case['id']+'/spec.json');c=read('inputs/'+case['id']+'/core.json');x=by[case['id']]
 coherence.append(dict(id=case['id'],subject=c['subject'],count='exactly one primary object; a slide consists of its film and mount',typed_subject=c['semantic_assertions'],crop=s['crop'],physical_owner=s['surface'],lighting=s['light'],prompt_words=len(c['baseline_prompt_en'].split()),textual_coherence='The actual film edge belongs to the image-bearing film, the cardboard surrounds it, transmission passes through the image, and the image stays in the complete aperture.'if s['profile']else'The control has its independently described support; no target contract or target evidence is forced onto it.',target_contract_status=x['target_contract_status'],image_grounded=False))
dump('coherence-review.json',dict(scope='Agent text review of the frozen primary photographs only. Deliberately contradictory evidence probes are not coherent scenes.',feature_selection_warning=dict(warning='technique_categories_are_majority',cases=11,review='Accepted for this source-aware physical-carrier qualification: the material texture/edge, illumination relation and complete perimeter are the subject of the requested test, not generic decorative camera detail. The baseline retains its object, situation and material ownership.'),cases=coherence))
print(json.dumps(summary,indent=2))
