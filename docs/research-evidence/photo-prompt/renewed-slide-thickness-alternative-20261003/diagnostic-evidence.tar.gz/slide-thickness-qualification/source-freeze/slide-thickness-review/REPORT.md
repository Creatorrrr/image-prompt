# Independent mounted-slide thickness review

## Decision

**ACCEPT the existing exact two-array proposal without revision, for later authorized integration. No repository change was made.**

Append `film edge thickness` after the two existing entries in:

- `mounted_slide_transparency_object_relation.semantics.component_semantics.groups[4].any_terms`, whose group ID remains `film_edge_density`
- `mounted_slide_transparency_object_relation.evidence_requirements.film_edge_density_phrase.must_mention_any`

The accepted arrays are, in order, `film edge density or thickness`, `film edge density`, `film edge thickness`. `accepted-minimal.patch` is the exact two-hunk patch against the currently loaded source. `accepted-json-patch.json` includes old-value tests, the source-file hash, and both append operations. The before/accepted full records and exact leaf changes are frozen separately.

This is acceptance of a source-authorized literal alternative, not implementation, permission to publish, natural-language routing certification, or pixel qualification.

## Original authority and preserved meaning

The original repository research file `docs/research-evidence/photo-prompt/photo-era-visual-semantics-20260905/candidate-data-proposal.json`, `/proposed_profiles/7`, explicitly requires these five components:

1. Transparent film frame
2. Cardboard or plastic mount
3. Transmitted-light viewing
4. Image contained within mount aperture
5. **Film edge density or thickness**

The original Korean source report's mounted-slide section independently names frame-edge density / film thickness. Its original routing proposal describes a cardboard-mounted color slide with transparent film thickness and backlight through an aperture-contained photograph. The current definition, composition instruction, component group, concept terms and paraphrase preserve this same alternative. The six original source documents' byte hashes still match the audit's saved source manifest. The clean proposal's nine artifact hashes also verify.

The required physical support remains transparent photographic film, not paper or glass. The mount remains a physical cardboard/plastic object, and its complete silhouette must be visible. Transmitted light belongs to the image-bearing film, and the image is contained within the mount aperture rather than overlaid on the frame. The added edge cue belongs to that film, not to the thickness of the mount, a neighboring glass cover, an embossed computer border, or a label.

There is **no separately authored emulsion-chemistry, visible emulsion-layer separation, or perforation/sprocket-hole requirement** in this profile's original components, gates or current obligation. The review does not invent such requirements or claim that thickness authenticates chemical composition, age, manufacture or capture provenance. Perforations and an emulsion label alone do not substitute for the required film-edge cue in the literal controls.

This is not a logical repair from AND to OR. The combined old anchor already says OR and remains usable for a thickness scene. The measured gap is narrower: a definite source-permitted thickness observation does not match either old literal phrase without adding the unselected density words.

## Preserved obligations and visibility gates

The current resolver freshly materialized the exact request's actual contract on the current runtime. Comparing that obligation with the proposed in-memory obligation finds only the same two array changes.

Unchanged:

- Five required component group IDs, with `minimum_component_groups = 5`
- Five evidence field IDs, each with `min_content_words = 2`
- Five distinct literal prompt-evidence phrases
- Literal inclusion in the composed prompt and maximum pairwise content-token overlap ratio `0.82`
- Existing filler exclusions, runtime expression, exact aliases and rejected substitutes
- Definition, composition instruction, source ownership, concept terms and optional candidates
- All five gate IDs, their wording, order and review scales

The frozen gates remain:

| Gate | Scale | Authored duty |
|---|---|---|
| `vo_era_mounted_slide_transparency_object_relation_1` | thumbnail | Mount silhouette is complete |
| `vo_era_mounted_slide_transparency_object_relation_2` | both | Film remains translucent |
| `vo_era_mounted_slide_transparency_object_relation_3` | native | Backlight passes through image |
| `vo_era_mounted_slide_transparency_object_relation_4` | native | Aperture contains rather than overlays image |
| `vo_era_mounted_slide_transparency_object_relation_5` | both | Screen and paper substitutes are absent |

No gate independently mandates density in addition to thickness. Composition still requires the five selected components to coexist and remain separately legible at thumbnail and native scales. No gate was weakened, removed or invented.

## Independent reproduction

A new harness, `independent_review.py`, constructed the proposal from the actual current source, loaded the genuine current source-bound visual index, used the actual resolver/materializer and production binding/composed-evidence/component consumers, and recorded every input and output in `consumer-proof.json`.

The complete successful run lasted **2026-10-03 07:22:07–07:22:41 UTC** on **`9d0fe0841b6ea5163c99b1f893440f6733a3b2a6`**. Start/end HEAD, clean status, and hashes of **106 source/runtime/asset files, including all 23 runtime scripts**, were identical. The runtime hashes also equal those in the earlier clean `9d0fe084` proposal run.

Results:

- Both original anchors pass binding, composed evidence and complete component matching before and after
- Bare `film edge thickness` and the longer definite physical-film-edge observation fail before / pass after all three consumers
- Five single-field omissions still fail
- Five one-content-word evidence cases still fail the preserved two-word minimum, both binding and composed auditing
- Five missing literal phrases in the prompt still fail literal inclusion checks
- Five component omissions still fail the complete five-group match
- Twelve anchor-free wrong-support, wrong-owner or digital-overlay replacements still fail their target evidence field
- Reusing one phrase for all five fields still fails the five-distinct-phrase requirement
- Ten hard-route controls are identical: English/Korean exact requests retain the target hit; generic print, paper, glass, digital border, negative strip, saturation, thickness alone and the original non-exact source paraphrase do not hard-activate it
- Five omissions in the redundant contract-level gate list are correctly restored when the effective contract is derived from the unchanged authoritative obligation gates

The last check is gate preservation, not a negative that should fail. The first harness attempt assumed the opposite and stopped at its own assertion. Reading the actual derivation established its intentional behavior; `harness-attempt-01.py` and `diagnostic-log.md` preserve that correction. No runtime fix was made or is implied.

Component matching here is an indirect/optional classification, not a new hard-activation lane. These results do not certify a normal public CLI/frozen-core run or retrieval ranking. The baseline/proposal difference was introduced only in memory, not by monkeypatching production code.

## Limits and misleading-anchor controls

The twelve wrong-support/overlay replacements omit the required literal anchors; their failure is **not proof that these helpers understand physical ownership**. Four explicit misleading-anchor controls document the limit:

- Old density words written on a digital screen pass before and after
- Old density words on a nearby paper label pass before and after
- New thickness words written on a digital screen newly pass after the addition
- New thickness words assigning the thickness to cardboard rather than film newly pass after the addition

Thus the addition modestly enlarges the accepted literal vocabulary, including its known false-statement surface. It does not introduce semantic truth validation. The existing support, transmission, aperture and saved-image gates must still be reviewed on actual pixels. **No images were generated or inspected, and no final image-quality or photographic-authenticity gain is claimed.**

The broad original audit belongs to the distinct historical baseline HEAD `62917903` / runtime `f4094afc`; it was not rerun or relabeled here. The mixed-pin launch's raw JSON was superseded and not retained. Its surviving limitation record was read, but that launch was not used as evidence. This report makes no complete raw-history claim.

## Exact retrieval/index consequences

The accepted component array adds the exact suffix **` | film edge thickness`** to the positive profile text. Only BM25F `visual_components` gains that element; aliases, definition, paraphrases and support cues are unchanged. Exact lookup rows remain byte-equivalent as structured data. The evidence array does not add a separate retrieval field.

| Value | Before | Accepted proposal |
|---|---|---|
| Positive text SHA-256, no trailing newline | `5555dfd99632900bdf1e2e12a5fdf89007a7877d13d21a04133ef46dc578fecb` | `55fde3becad817f7b2f20bc02f3ec85fe519b9b0e972690e43484230233ff861` |
| Registry canonical SHA-256 | `a3e216f9528a1132e78a591cdb9bd1804c0a628d2e7c68b74510c76aa42e5fcc` | `a12208c9f150cf9724f46a174ae1cc55a77c79bd21955745ee75ba457eb91711` |
| Full target profile canonical SHA-256 | `5abc596cbb55a302ba84e92ec9717b881d87e312d949d493e9c97533df3dd955` | `f73ea8877c9836fee03c88a80f246461e0990b3aa4898ebcc3be464aa7296ca9` |

The actual existing visual-profile index SHA-256 remains `373fdd747eed43061a489ae0dd501e078345171a177fa36325f6bb0588137a63`. The production validator rejects it against the accepted in-memory registry with:

> visual profile index registry_sha256 does not match the visual registry; regenerate it with build_visual_profile_index.py

Full before/after positive strings, BM25F fields and hashes are frozen in `positive-text-index-impact.json`. A **genuine authorized visual-profile index refresh** is required after applying this DATA. Reusing/relabeling old vectors or merely changing the stored digest is not valid. No vectors, index or public rankings were produced here.

## Post-run checkout verification

After the completed stable run, the parent added documentation-only commit `5bf8142304f484138474fff4af9b0660439fa331` (acetate README and integration-evidence archive). A final check verified all 106 pinned runtime/source/asset files remain byte-identical, repository status is clean, and `git apply --check` accepts the frozen patch. This later HEAD is recorded in `ending-verification.json`; the completed run remains attributed to `9d0fe084`.

## Integration handoff and stop condition

The exact patch is accepted. Apply it only in the separately authorized integration window, then refresh the genuine index and qualify the same frozen normal public requests/evidence before and after. Source authority, complete contract invariants, independent current-runtime outcomes, explicit limitations, and exact index consequences are now frozen. No repository source, index, runtime, test, provider, installation or publication was changed by this review.

Key artifacts: `accepted-minimal.patch`, `accepted-json-patch.json`, `consumer-proof.json`, `source-authority.json`, `verification-manifest.json`, `positive-text-index-impact.json`, `input-artifact-integrity.json`, `diagnostic-log.md`, and `artifact-manifest.json`.
