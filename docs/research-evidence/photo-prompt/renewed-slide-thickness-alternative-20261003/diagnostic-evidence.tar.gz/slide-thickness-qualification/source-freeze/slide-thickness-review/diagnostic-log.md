# Harness diagnostics

## Attempt 01

The first independent harness stopped at its own assertion for an omitted entry in the redundant contract-level required_hard_gates list. No final runtime claim or consumer proof was written from this incomplete run. The exact first-attempt script is retained as harness-attempt-01.py.

The assertion incorrectly expected audit_visual_obligations to fail when this derived list was shortened. Reading derive_effective_visual_obligation_contract (audit_composed_prompt.py lines 1398–1544 on 9d0fe084) established that it intentionally re-derives the authoritative gate set from the actual obligations. The obligation's complete render_gates remained present. The final harness now checks that each of five omissions in the redundant list is restored from the unchanged obligation. No source or runtime change was made. This is a harness correction, not a discovered loss of a gate.

Observed failure: independent_review.py line 147, AssertionError at the expected visual_obligations_contract failure. No claim of direct pixel review is made.
