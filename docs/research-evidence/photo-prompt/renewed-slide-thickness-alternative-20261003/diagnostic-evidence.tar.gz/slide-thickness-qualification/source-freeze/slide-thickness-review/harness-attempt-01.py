"""Independent, read-only repository review; all writes target this artifact directory."""
import copy, datetime, difflib, hashlib, json, subprocess, sys
from pathlib import Path
sys.dont_write_bytecode = True
ROOT=Path('REPOSITORY_ROOT')
OUT=Path(__file__).resolve().parent
AUDIT=OUT.parent/'image-carrier-audit'
ASSETS=ROOT/'skills/photo-prompt-image-generator/assets'
SCRIPTS=ASSETS.parent/'scripts'
SOURCE=ROOT/'docs/research-evidence/photo-prompt/photo-era-visual-semantics-20260905'
PID='mounted_slide_transparency_object_relation'
FIELD='film_edge_density_phrase'
NEW='film edge thickness'
OLD=['film edge density or thickness','film edge density']
PROFILE_FILE=ASSETS/'photo_prompt_visual_obligations_photo_era.json'
sha=lambda b:hashlib.sha256(b).hexdigest()
canonical=lambda x:sha(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())
read=lambda p:json.loads(p.read_text())
def save(name,value):
 (OUT/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
def git(*args):
 return subprocess.check_output(['git',*args],cwd=ROOT,text=True).strip()
def snapshot():
 files=sorted(set(SCRIPTS.glob('*.py'))|set(ASSETS.glob('*.json'))|set(SOURCE.iterdir()))
 return {'head':git('rev-parse','HEAD'),'status':git('status','--short'),'files':{str(p.relative_to(ROOT)):sha(p.read_bytes()) for p in files if p.is_file()}}
def leaves(a,b,path=''):
 if type(a)!=type(b):return [{'path':path,'before':a,'after':b}]
 if isinstance(a,dict):
  assert a.keys()==b.keys()
  return [d for k in a for d in leaves(a[k],b[k],path+'/'+k)]
 if isinstance(a,list):
  if len(a)!=len(b):return [{'path':path,'before':a,'after':b}]
  return [d for i,(x,y) in enumerate(zip(a,b)) for d in leaves(x,y,path+'/'+str(i))]
 return [] if a==b else [{'path':path,'before':a,'after':b}]
start=datetime.datetime.now(datetime.timezone.utc).isoformat()
initial=snapshot()
assert initial['head']=='9d0fe0841b6ea5163c99b1f893440f6733a3b2a6'
whole=read(PROFILE_FILE)
i=next(i for i,p in enumerate(whole['profiles']) if p['id']==PID)
before=whole['profiles'][i]
assert before==read(AUDIT/'before-profile.json')==read(AUDIT/'clean9d0fe084-proposal/before-profile.json')
after=copy.deepcopy(before)
assert after['semantics']['component_semantics']['groups'][4]['id']=='film_edge_density'
for arr in [after['semantics']['component_semantics']['groups'][4]['any_terms'],after['evidence_requirements'][FIELD]['must_mention_any']]:
 assert arr==OLD
 arr.append(NEW)
assert after==read(AUDIT/'proposed-profile.json')==read(AUDIT/'clean9d0fe084-proposal/proposed-profile.json')
changes=leaves(before,after)
expected_paths=['/semantics/component_semantics/groups/4/any_terms','/evidence_requirements/film_edge_density_phrase/must_mention_any']
assert [x['path'] for x in changes]==expected_paths
save('before-profile.json',before);save('accepted-profile.json',after);save('exact-changed-leaves.json',changes)
proposed_file=copy.deepcopy(whole);proposed_file['profiles'][i]=after
assert leaves(whole,proposed_file)==[{**x,'path':'/profiles/'+str(i)+x['path']} for x in changes]
# Require original source formatting to round-trip before freezing a minimal unified patch.
old_text=PROFILE_FILE.read_text();assert json.dumps(whole,ensure_ascii=False,indent=2)+'\n'==old_text
new_text=json.dumps(proposed_file,ensure_ascii=False,indent=2)+'\n'
rel=str(PROFILE_FILE.relative_to(ROOT))
patch=''.join(difflib.unified_diff(old_text.splitlines(keepends=True),new_text.splitlines(keepends=True),fromfile='a/'+rel,tofile='b/'+rel))
(OUT/'accepted-minimal.patch').write_text(patch)
json_patch=[]
for d in changes:
 path='/profiles/'+str(i)+d['path']
 json_patch.extend([{'op':'test','path':path,'value':d['before']},{'op':'add','path':path+'/-','value':NEW}])
save('accepted-json-patch.json',{'source_file':rel,'before_file_sha256':sha(old_text.encode()),'proposed_file_sha256':sha(new_text.encode()),'profile_id':PID,'operations':json_patch})
# Original authored authority, without importing any external authenticity claim.
proposal=read(SOURCE/'candidate-data-proposal.json')
original=next(p for p in proposal['proposed_profiles'] if p['id']==PID)
assert original['components']==before['concept_candidate']['concept_terms']
assert original['components'][-1]=='film edge density or thickness'
assert original['exact_terms']==before['activation']['exact_terms']
assert original['reject_substitutes']==before['reject_substitutes']
assert [g['description'] for g in before['render_gates']]==['The saved image makes '+g+' clearly verifiable in one frame.' for g in original['render_gates']]
ledger=[json.loads(s) for s in (SOURCE/'evidence.jsonl').read_text().splitlines() if s.strip()]
ledger=[r for r in ledger if r.get('id') in original['source_ids']]
report=(SOURCE/'report-source.md').read_text();section=report.split('#### `'+PID+'`',1)[1].split('\n###',1)[0].strip()
source_files=['candidate-data-proposal.json','evidence.jsonl','report-source.md','routing-regression-proposal.jsonl','implementation-iteration-record.json','iteration-record.json']
audit_manifest=read(AUDIT/'source-manifest.json')
source_hashes={name:sha((SOURCE/name).read_bytes()) for name in source_files}
for name,h in source_hashes.items():
 prev=next(r for r in audit_manifest['files'] if r['path']==str((SOURCE/name).relative_to(ROOT)))
 assert h==prev['sha256']
regressions=[json.loads(s) for s in (SOURCE/'routing-regression-proposal.jsonl').read_text().splitlines() if PID in s]
save('source-authority.json',{'original_record':original,'original_report_section':section,'source_files_sha256':source_hashes,'matching_original_ledger_rows':ledger,'matching_original_routing_proposals':regressions,'authored_duties':['transparent photographic film frame','physical cardboard or plastic mount','transmitted-light viewing through the image','image contained within mount aperture','film-edge density OR film-edge thickness','complete mount silhouette','translucent film','screen and paper substitutes absent'],'not_separately_authored':['emulsion chemistry or visible layer separation','perforations or sprocket holes','manufacture/capture date authenticity','density AND thickness'],'interpretation':'The added words identify the film edge, not mount thickness or nearby glass. No film chemistry or extra perforation requirement is inferred.'})
sys.path.insert(0,str(SCRIPTS))
import prompt_generator as pg
import audit_composed_prompt as ac
registry=pg.load_visual_obligation_registry(ASSETS/'photo_prompt_visual_obligations.json')
index=pg.load_visual_profile_index(ASSETS/'photo_prompt_visual_profile_index.json',registry)
compiled_before=next(p for p in registry['profiles'] if p['id']==PID)
assert compiled_before==pg.compile_visual_profile(before)
compiled_after=pg.compile_visual_profile(after)
proposed_registry=copy.deepcopy(registry)
proposed_registry['profiles']=[compiled_after if p['id']==PID else p for p in registry['profiles']]
source_request={'provenance':{'concept_lock':[before['activation']['exact_terms'][0]]}}
request_rows=pg.candidate_pack_visual_obligation_request_sources(source_request,{})
resolution=pg.resolve_visual_profile_hits(registry,request_rows,visual_profile_index=index,adult_context=True)
contract=pg.candidate_pack_visual_obligations({pg.VISUAL_OBLIGATIONS_DATA_KEY:registry},source_request,{},None,visual_profile_resolution=resolution)
assert [o['id'] for o in contract['obligations']]==[PID]
baseline_obligation=contract['obligations'][0]
# Match the actual activation provenance for an in-memory proposed obligation.
activation=baseline_obligation['activation']
proposed_obligation=pg.candidate_pack_visual_profile_obligation(after,proposed_registry,activation_source=activation['source'],source_intent_ids=activation['source_intent_ids'])
assert [r['path'] for r in leaves(baseline_obligation,proposed_obligation)]==['/component_semantics/groups/4/any_terms','/evidence_requirements/film_edge_density_phrase/must_mention_any']
assert before['required_evidence_fields']==baseline_obligation['prompt_binding']['required_evidence_fields']
assert baseline_obligation['prompt_binding']['minimum_distinct_evidence_phrases']==5
assert all(r['min_content_words']==2 for r in before['evidence_requirements'].values())
assert before['semantics']['component_semantics']['minimum_component_groups']==5
assert before['semantics']['component_semantics']['required_group_ids']==[g['id'] for g in before['semantics']['component_semantics']['groups']]
assert contract['required_hard_gates']==[g['id'] for g in before['render_gates']]
assert [g['review_scale'] for g in before['render_gates']]==['thumbnail','both','native','native','both']
base={f:r['must_mention_any'][0] for f,r in before['evidence_requirements'].items()}
positive={**base,FIELD:'film edge thickness is visible as a thin transparent rim at the image-bearing layer boundary'}
def binding(f,t,o):
 try:
  pg.validate_visual_intent_binding(obligation_index=0,field=f,phrase=t,requirement=o['evidence_requirements'][f]);return {'pass':True}
 except ValueError as e:return {'pass':False,'error':str(e)}
def audit(ev,o,prompt=None,modify_contract=None):
 c=copy.deepcopy(contract);c['obligations']=[copy.deepcopy(o)]
 if modify_contract:modify_contract(c)
 return ac.audit_visual_obligations({'visual_obligations':c},{'visual_obligation_evidence':{PID:ev}},'. '.join(ev.values()) if prompt is None else prompt)
def trial(label,ev):
 return {'label':label,'evidence':ev,'before_failures':audit(ev,baseline_obligation),'accepted_failures':audit(ev,proposed_obligation),'before_component_match':pg.candidate_pack_visual_component_match(compiled_before,'; '.join(ev.values())),'accepted_component_match':pg.candidate_pack_visual_component_match(compiled_after,'; '.join(ev.values()))}
positives=[]
for phrase in OLD+[NEW,positive[FIELD]]:
 ev={**base,FIELD:phrase};r=trial(phrase,ev);r['before_binding']=binding(FIELD,phrase,baseline_obligation);r['accepted_binding']=binding(FIELD,phrase,proposed_obligation)
 if phrase in OLD:
  assert not r['before_failures'] and r['before_binding']['pass'] and r['before_component_match']=='component_semantics'
 else:
  assert r['before_failures'] and not r['before_binding']['pass'] and r['before_component_match'] is None
 assert not r['accepted_failures'] and r['accepted_binding']['pass'] and r['accepted_component_match']=='component_semantics'
 positives.append(r)
controls={'field_omissions':[],'low_content_word_minima':[],'prompt_literal_omissions':[],'component_omissions':[],'gate_omissions':[],'wrong_support_or_overlay':[],'distinct_evidence':[]}
for f in base:
 ev={k:v for k,v in positive.items() if k!=f};r=trial(f,ev);assert any(x.get('field')==f for x in r['accepted_failures']);controls['field_omissions'].append(r)
 ev={**positive,f:'visible'};r=trial(f,ev);r['before_binding']=binding(f,'visible',baseline_obligation);r['accepted_binding']=binding(f,'visible',proposed_obligation)
 assert not r['before_binding']['pass'] and not r['accepted_binding']['pass']
 assert any(x.get('field')==f and x.get('actual_content_words')==1 and x.get('minimum_content_words')==2 for x in r['accepted_failures']);controls['low_content_word_minima'].append(r)
 prompt='. '.join(v for k,v in positive.items() if k!=f)
 r={'omitted_literal_field':f,'evidence':positive,'prompt':prompt,'before_failures':audit(positive,baseline_obligation,prompt),'accepted_failures':audit(positive,proposed_obligation,prompt)}
 assert any(x.get('field')==f and x['check']=='visual_obligation_prompt_binding' for x in r['accepted_failures']);controls['prompt_literal_omissions'].append(r)
for j,g in enumerate(before['semantics']['component_semantics']['groups']):
 texts=list(positive.values());text='; '.join(t for k,t in enumerate(texts) if k!=j)
 r={'omitted_group':g['id'],'text':text,'before':pg.candidate_pack_visual_component_match(compiled_before,text),'accepted':pg.candidate_pack_visual_component_match(compiled_after,text)}
 assert r['before'] is None and r['accepted'] is None;controls['component_omissions'].append(r)
for j,gate in enumerate(before['render_gates']):
 r={'omitted_gate':gate,'before_failures':audit(positive,baseline_obligation,modify_contract=lambda c:c['required_hard_gates'].pop(j)),'accepted_failures':audit(positive,proposed_obligation,modify_contract=lambda c:c['required_hard_gates'].pop(j))}
 assert any(x['check']=='visual_obligations_contract' and 'required_hard_gates' in x['reason'] for x in r['accepted_failures']);controls['gate_omissions'].append(r)
wrong=[
 ('opaque_paper','transparent_film_phrase','An opaque paper photograph fills a stiff holder.'),
 ('glass_plate','transparent_film_phrase','A glass plate bears the image inside a rigid wood holder.'),
 ('digital_frame','physical_mount_phrase','A software overlay draws a rectangular slide-shaped border.'),
 ('detached_mount','physical_mount_phrase','A printed rectangle floats beside the transparency.'),
 ('reflected_light','transmitted_light_phrase','Front-side glare reflects off the opaque photograph.'),
 ('image_overlay','image_in_aperture_phrase','The image floats over the frame and background.'),
 ('digital_depth_overlay',FIELD,'An embossed digital border surrounds the on-screen photograph.'),
 ('thick_mount',FIELD,'The cardboard rim is thick while the film edge remains hidden.'),
 ('nearby_glass',FIELD,'Thickness belongs to a glass cover beside the image-bearing film.'),
 ('perforations_alone',FIELD,'Sprocket perforations run along the strip as small regular holes.'),
 ('emulsion_label_alone',FIELD,'A paper caption names the emulsion chemistry and nothing about its rim.'),
 ('wrong_edge_owner',FIELD,'The wooden frame presents a thick ledge beneath the image.')]
for label,f,t in wrong:
 ev={**positive,f:t};r=trial(label,ev);r['field']=f;r['before_binding']=binding(f,t,baseline_obligation);r['accepted_binding']=binding(f,t,proposed_obligation)
 assert any(x.get('field')==f for x in r['accepted_failures']) and not r['accepted_binding']['pass'];controls['wrong_support_or_overlay'].append(r)
# Same literal cannot satisfy five independent fields, even though some old anchor words remain.
ev={f:positive[FIELD] for f in base};r=trial('same_phrase_for_every_field',ev)
assert any(x['check']=='visual_obligation_distinct_evidence' and x.get('minimum')==5 and x.get('actual')==1 for x in r['accepted_failures'])
controls['distinct_evidence'].append(r)
# Explicitly retain evidence that these are lexical gates rather than truth validators.
limits=[]
for t in ['film edge density is only a digital label on a flat computer screen','film edge density is written on a paper label beside the photographic object','film edge thickness is only a digital label on a flat computer screen','film edge thickness belongs to the cardboard mount rather than the film']:
 r=trial(t,{**base,FIELD:t});assert not r['accepted_failures'];limits.append(r)
assert not limits[0]['before_failures'] and not limits[1]['before_failures'] and limits[2]['before_failures'] and limits[3]['before_failures']
routes=[]
for label,text in [('exact_en',before['activation']['exact_terms'][0]),('exact_ko',before['activation']['exact_terms'][1]),('generic','vintage photographic print'),('paper','an opaque paper snapshot pasted onto a frame'),('glass','a glass plate transparency in a holder'),('digital','a photograph with a digital slide border'),('negative','a film negative strip'),('saturated','a saturated color image'),('thickness_alone','film edge thickness'),('complete_source_paraphrase',before['semantics']['paraphrase_examples'][0])]:
 ss=[{'source':'concept_lock','text':text,'polarity':'required','priority':'critical','mandatory':True}]
 b=pg.candidate_pack_auto_visual_obligation_matches(registry,ss);a=pg.candidate_pack_auto_visual_obligation_matches(proposed_registry,ss)
 assert a==b and ((PID in a)==label.startswith('exact'))
 routes.append({'label':label,'request':text,'before':b,'accepted':a})
texts=[pg.visual_profile_semantic_text(p) for p in [compiled_before,compiled_after]]
for name,t in zip(['before','accepted'],texts):(OUT/('positive-text-'+name+'.txt')).write_text(t+'\n')
fields=[pg.visual_profile_bm25f_fields(p) for p in [compiled_before,compiled_after]]
assert leaves(fields[0],fields[1])==[{'path':'/visual_components','before':fields[0]['visual_components'],'after':fields[0]['visual_components']+[NEW]}]
assert pg.visual_profile_exact_term_rows(registry)==pg.visual_profile_exact_term_rows(proposed_registry)
try:
 pg.validate_visual_profile_index_metadata(index,proposed_registry)
 raise AssertionError('Changed registry accepted the stale index')
except ValueError as e:stale_error=str(e)
previous_impact=read(AUDIT/'clean9d0fe084-proposal/positive-text-index-impact.json')
impact={'before_text':texts[0],'accepted_text':texts[1],'before_text_sha256':sha(texts[0].encode()),'accepted_text_sha256':sha(texts[1].encode()),'before_bm25f_fields':fields[0],'accepted_bm25f_fields':fields[1],'before_registry_sha256':pg.visual_profile_registry_sha256(registry),'accepted_registry_sha256':pg.visual_profile_registry_sha256(proposed_registry),'actual_visual_index_sha256':sha((ASSETS/'photo_prompt_visual_profile_index.json').read_bytes()),'exact_lookup_rows_unchanged':True,'old_index_rejected':stale_error,'genuine_index_refresh_required':True,'vectors_or_index_generated':False}
for ours,theirs in [('before_text_sha256','before_text_sha256'),('accepted_text_sha256','proposed_text_sha256'),('before_registry_sha256','before_registry_sha256'),('accepted_registry_sha256','proposed_registry_sha256'),('actual_visual_index_sha256','current_visual_index_sha256')]:assert impact[ours]==previous_impact[theirs]
save('positive-text-index-impact.json',impact)
save('consumer-proof.json',{'head':initial['head'],'original_resolver':resolution,'before_contract':contract,'accepted_obligation':proposed_obligation,'exact_obligation_changes':leaves(baseline_obligation,proposed_obligation),'positives':positives,'negative_controls':controls,'lexical_semantic_limits':limits,'exact_hard_route_controls':routes,'limits':['In-memory helper and composed-evidence qualification, not normal public CLI/frozen-core/ranking qualification.','No images generated or viewed; no photographic truth or image-quality claim.','Literal negatives fail absent anchors; anchors retained in false statements can pass.','Broad historical audit baseline uses a distinct older runtime; missing mixed-pin raw history is not reconstructed.']})
ending=snapshot();assert initial==ending,'Runtime/source/index/HEAD/status changed during independent probe'
manifest={'started_at_utc':start,'finished_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'initial':initial,'ending':ending,'stable':True,'source_profile_sha256':canonical(before),'accepted_profile_sha256':canonical(after),'historical_baseline_head':'62917903e482a5a224c789b976d93871b19d16b7','historical_baseline_runtime':'f4094afc','proposal_runtime':'9d0fe0841b6ea5163c99b1f893440f6733a3b2a6','original_clean_proposal_runtime_files_match':all(initial['files'][p]==h for p,h in read(AUDIT/'clean9d0fe084-proposal/proposal-runtime-manifest.json')['files'].items())}
assert manifest['original_clean_proposal_runtime_files_match']
save('verification-manifest.json',manifest)
summary={'decision':'accept_exact_two_array_addition_for_later_authorized_integration','changed_arrays':len(changes),'positive_cases':len(positives),'negative_controls':{k:len(v) for k,v in controls.items()},'known_lexical_limits':len(limits),'exact_hard_route_controls':len(routes),'runtime_stable':True,'unchanged_repo_status':ending['status'],'positive_text_changed':True,'actual_index_stale_for_accepted_proposal':True}
save('decision.json',summary)
print(json.dumps(summary))
