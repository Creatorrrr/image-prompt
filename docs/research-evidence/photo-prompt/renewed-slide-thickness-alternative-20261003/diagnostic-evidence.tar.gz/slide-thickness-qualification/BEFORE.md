# Mounted-slide film-edge thickness: frozen BEFORE qualification

## Result and stopping point

**BEFORE is complete on `5bf8142304f484138474fff4af9b0660439fa331`. The two exact EN/KO thickness-only scenes and a genuinely offered source-paraphrase opt-in reproduce the single intended `film_edge_density_phrase` anchor failure in the full composed-prompt CLI.** The original density and OR formulations remain valid. No source or index change has been made; AFTER is not run and is held for actual authorized source integration and a genuine registry-bound index refresh.

The bounded source-aware suite contains **11 public V6 CLI requests and 24 full composition audits**. All 11 generation CLIs succeed. All 24 outcomes match the expectations and conditional selection policy frozen before retrieval: 9 textual passes and 15 expected failures. Those nine passes include one unavailable-target baseline and one deliberately misleading old-anchor sentence; they are not nine physical target-contract successes.

This is source-aware synthetic canonical qualification, not organic requester traffic, clean pre-core authoring, a natural-query recall benchmark, or rendered-image validation. The real CLI's `requesting_user` and `agent_prepack` wire enums do not change that provenance. No images were generated or inspected, no provider was called, and no runtime, source, index, test, dependency, or publication was modified.

## Freeze, current workflow and source authority

The sealed independent acceptance was verified against all 18 review artifact hashes before freezing. The accepted proposal appends `film edge thickness` to exactly two arrays: the existing `film_edge_density` component group's `any_terms`, and `film_edge_density_phrase.must_mention_any`. The two old entries remain unchanged and first. The original authored fifth relation is already **film edge density OR thickness**; this qualification measures the standalone thickness spelling, not an AND-to-OR repair.

At **2026-10-03 07:33:28 UTC**, the exact envelopes, controls, cores, baseline reviews, neutral feature selections, evidence maps, final prompts, conditional selection policy, BEFORE/AFTER expectations and source review were frozen. Retrieval ran afterward, **07:33:30–07:38:19 UTC**. Every new core has a required, request-bound `subject` assertion with `axes.subject_category = object` and a literal phrase naming its actual primary subject. No technical subject-category alias was inserted into a request or baseline to steer routing.

Each baseline is 96–143 words. All 11 input and feature-selection preflights pass. Their retained `technique_categories_are_majority` warnings were reviewed: material edge/texture, lighting relation and full perimeter are the subject of this physical-carrier qualification, alongside the subject and situation, rather than decorative camera additions. Full audits retain informational `uncovered_intent` warnings explicitly reporting that the intended content was preserved by free description/assertion. Those warnings are not suppressed or counted as failures.

Only the five source-supported duties are used:

1. Transparent photographic film frame
2. Physical cardboard/plastic mount
3. Transmitted-light viewing through the image-bearing film
4. Image contained within the mount aperture
5. Film-edge density or thickness, with the selected branch owned by the same film

There is no additional emulsion-chemistry, visible chemical-layer separation, perforation, sprocket-hole, age, manufacture or photographic-authenticity obligation.

## Actual public V6 routes and complete compositions

| Frozen case | Actual BEFORE target route | Complete composition |
|---|---|---|
| Exact English thickness-only | Hard target contract | Fails only `film_edge_density_phrase` component anchor |
| Exact Korean thickness-only, English composed evidence | Hard target contract | Same sole anchor failure |
| Exact English density | Hard target contract | Pass |
| Exact English original OR, explicitly choosing the thin-film branch | Hard target contract | Pass |
| Legacy component-only wording | Actual eligible target visual concept, selected | Pass with all five effective gates |
| Original source-declared English paraphrase plus thickness-only evidence | Actual eligible target visual concept, selected | Same sole anchor failure with all five effective gates |
| Thickness-only component wording | Target unavailable | Unchanged baseline passes without target selection or target evidence; **not a target-contract pass** |
| Empty physical cardboard mount | No target hard/selected contract | Pass; the opening exposes the background and the visible thick edge belongs to cardboard |
| Opaque printed photographic card | No target hard/selected contract | Pass; the image belongs to reflective paper |
| Digital display with simulated border | No target hard/selected contract | Pass; the border and photograph are screen pixels |
| Picture-bearing rigid glass | No target hard/selected contract | Pass; the image and thick polished edge belong to glass |

Every selected concept ID was genuinely present and eligible in that case's actual public pack. Complete offered target records are saved as `target-offers.json`; raw composer views and full packs remain unchanged. No optional slot or creative candidate was adopted. No orphan target evidence was inserted for the unavailable component-only case. The old source paraphrase is tested exactly as sourced and is not described as an exact hard activation alias.

All 19 active-contract composition audits retain the exact five original effective gate IDs. The four coherent non-target photographs and the unavailable-target baseline have no target gates. The gates were inspected as contracts; no claim is made that pixels passed them.

## Ownership, count and crop

The target scenes show exactly one cardboard-mounted slide, consisting of one physical mount and its contained image-bearing film. A complete mount silhouette and entire aperture remain in one frame. Backlight passes through that film's shoreline image; the photograph stays within the aperture. The thin transparent edge is explicitly the film's own boundary, distinct from the surrounding cardboard's thickness. A shallow viewpoint and stable narrow groove make the specified relationships textually coherent without inventing hands, living actors or another photograph.

The source duties remain separately legible in prose and are bound to the same physical object. The four coherent controls each preserve their own single-object count, full perimeter and support relation. `coherence-review.json` records the manual textual check for every primary photograph. This review is not a material measurement, optical simulation, chemical identification or image inspection.

## Missing bindings, wrong owners and literal limits

Five single-field omissions each fail the complete audit, including their specific absent evidence field and the five-distinct-evidence requirement. These are missing **bindings against a complete active-profile scene**, not five newly authored photographs with the visual relationship physically removed.

Four additional anchor-free wrong-owner bindings remain rejected: opaque paper as the film support, rigid glass as the film support, cardboard-mount thickness as the film edge cue, and a digital screen bevel as the film edge cue. The contradictory added clauses and the intact positive core are deliberately retained; these are malformed binding probes, not coherent alternative pictures. Their failure proves the stated lexical constraints, not general physical ownership understanding.

The frozen literal-limit probes make the boundary explicit:

- `Film edge density is merely caption text on a flat digital display` passes direct normalization, component matching and the **full composition audit** before the change. This is a known false pass.
- The analogous new `Film edge thickness` digital-caption wording fails only the missing literal anchor before the change.
- `Film edge thickness is the thickness of the cardboard mount rather than the film` also fails only that missing anchor before the change.
- `There is no film edge thickness visible in this photograph` likewise fails only that missing anchor before the change.

AFTER expectations for these last three probes are frozen as literal false-pass limits, based on the accepted vocabulary change; **they have not been measured by this BEFORE run**. Their future acceptance would not be a physical-semantic improvement. Direct normalization/component helpers are supplemental only; no extra explicit-visual-intent CLI adjunct was run.

## Integrity and continuation

- All **112 frozen input/source-review artifacts** retain their original byte hashes
- All **313 pinned source/runtime/asset/procedure files** are byte-identical at start and finish
- HEAD is unchanged at `5bf8142304f484138474fff4af9b0660439fa331`; repository status is clean throughout
- The sole execution attempt, all first expected failures, CLI commands/stdout/stderr, full public packs, complete composed payloads, audits, helper outcomes, warnings and review integrity records are retained
- No frozen request, baseline, expectation or evidence was altered after retrieval
- No unmeasured retrieval rank, query-embedding recall or image-quality conclusion is drawn

Input manifest SHA-256: `57b13356fe03ba4924aeb92344052fb10fd8f248ed15234f8329ab7de6c9ce67`.

AFTER must use these same frozen inputs, seed, prompts, evidence and conditional selection policy after the exact two-array change and genuine index refresh are actually ready. If the previously unavailable target becomes offered, select only the real returned eligible ID and include its frozen full evidence; preserve that reachability change as a separate observation. Compare all public pack differences without silently exempting changed optional membership or ordering. Do not modify or overwrite the frozen BEFORE harness or artifacts; an authorized AFTER runner can be a separate file reading this unchanged manifest. The current runner intentionally permits only BEFORE.

Key artifacts: `BEFORE-SUMMARY.json`, `manifest.json`, `qualification-scope.json`, `compositions.json`, `before/report.json`, `before/helper-boundaries.json`, `coherence-review.json`, `ACCEPT-VERIFIED.json`, and `artifact-manifest-before.json`.
