"""Finalize evidence only, preserving frozen old and separately pinned new runtime runs."""
from pathlib import Path
import hashlib,json,subprocess
R=Path('REPOSITORY_ROOT');O=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
canon=lambda x:sha(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())
def save(n,x):(O/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
rows=json.loads((O/'source-records.json').read_text());before=json.loads((O/'source-manifest.json').read_text());old_runtime=json.loads((O/'runtime-manifest.json').read_text());proposal=json.loads((O/'proposal-consumer-proof.json').read_text());new_runtime=json.loads((O/'proposal-runtime-manifest.json').read_text())
def get_pointer(d,p):
 for k in p.strip('/').split('/'):d=d[int(k)] if isinstance(d,list) else d[k]
 return d
verified=[]
for r in rows:
 p=R/r['file'];current=get_pointer(json.loads(p.read_text()),r['pointer']);h=canon(current);assert h==r['canonical_sha256'];verified.append({'id':r['id'],'file':r['file'],'pointer':r['pointer'],'canonical_sha256':h,'unchanged':True})
files=[{'path':x['path'],'before_sha256':x['sha256'],'current_sha256':sha((R/x['path']).read_bytes()),'unchanged':sha((R/x['path']).read_bytes())==x['sha256']} for x in before['files']];assert all(r['unchanged'] for r in files)
new_scripts={str(p.relative_to(R)):sha(p.read_bytes()) for p in (R/'skills/photo-prompt-image-generator/scripts').glob('*.py')};assert new_scripts==new_runtime['files']
changes=[{'path':x['path'],'old_sha256':x['sha256'],'new_sha256':new_scripts[x['path']]} for x in old_runtime['files'] if x['sha256']!=new_scripts[x['path']]]
notes={
'daguerreotype_reflective_cased_plate_object':('KEEP','Silvered plate support, surface-owned angular response, fine non-paper image detail, complete depth and protective topology remain five co-owned requirements. Existing protective-case anchor represents the selected structure; this is not permission for ordinary mirrors, tintypes or paper.'),
'calotype_salted_paper_fiber_image_relation':('KEEP','Original matte support and image-in-fiber relation survive unchanged, with cross-region fibers, photographic detail and complete paper edge. Canvas texture, global blur and digital overlay are substitutes, not missing alternatives.'),
'wet_collodion_glass_plate_coating_trace':('DEFER','Source components explicitly permit uneven coating and chemistry spots, but original/current gates still say streak and pinholes belong to emulsion. Isolated branch phrases fail literal consumers. Resolving both source-gate interpretations requires separate review; no gate or chemistry scope change is proposed.'),
'albumen_card_mount_print_material_relation':('DEFER','Source explicitly permits microscopic fiber through the albumen layer, while native gate wording names fine crackle; the historical implementation review did evaluate crackle-or-fiber visibility. Isolated fiber and smooth-surface phrases fail literals. Do not silently broaden the crackle-specific surface candidate or rewrite visibility/gates; defer a separately reviewed consistency proposal.'),
'cyanotype_contact_print_prussian_blue_relation':('KEEP','Selected contact-print signature deliberately requires paper boundary, blue field, contacted silhouettes, opacity-owned tonal differences and physically plausible overlap. Blueprint, blue grading and vector silhouettes do not replace the process-owned structure.'),
'autochrome_glass_transparency_color_screen':('KEEP','Glass/transmission, material-owned screen, restrained color and continuous luminance remain intact. Existing transmitted-light anchor works. Backlit-only literal sensitivity is recorded, not grounds to remove glass/screen/ownership evidence or claim authenticated Autochrome chemistry.'),
'integral_instant_print_object_relation':('KEEP','Whole print, asymmetric margin, depth, contained image and localized material trace remain the selected variant. Existing object-depth anchor represents thickness without requiring a cast shadow. Isolated thickness and handling wording are measured lexical limitations; no new aliases or wear profile are bundled.'),
'mounted_slide_transparency_object_relation':('PROPOSE_TWO_ARRAY_ADDITION','Append film edge thickness to component group film_edge_density.any_terms and evidence field film_edge_density_phrase.must_mention_any. Source/current definition explicitly declare density OR thickness, gates do not mandate density, and the concrete thickness-only binding fails before/passes after without changing any owner or gate.')}
decisions=[]
for r in rows:
 if r['kind']=='profile':status,reason=notes[r['id']]
 else:
  status='KEEP';reason='Original id, English and Korean candidate text are unchanged. It remains an optional material/process/context atom rather than inheriting all hard-profile fields or asserting capture date/authenticity. Full current projection and exact-trigger check are saved.'
 decisions.append({'id':r['id'],'kind':r['kind'],'decision':status,'reason':reason,'canonical_sha256':r['canonical_sha256'],'source_file':r['file'],'source_pointer':r['pointer']})
save('decisions.json',decisions)
save('ending-verification.json',{'baseline_head':before['head'],'baseline_runtime':'f4094afc','proposal_head':new_runtime['head'],'ending_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'ending_git_status':subprocess.check_output(['git','status','--short'],cwd=R,text=True),'record_verification':verified,'source_and_index_files':files,'authorized_parent_runtime_integration_files':changes,'runtime_changes_owned_by_this_audit':False,'proposal_runtime_stable_during_and_after_run':True,'scope_sources_unchanged':True,'proposal_applied':False})
save('decision.json',{'decision':'REVIEW_ONE_MINIMAL_DATA_PROPOSAL','audited_records':19,'profiles':8,'candidates':11,'keep_records':sum(x['decision']=='KEEP' for x in decisions),'defer_records':sum(x['decision']=='DEFER' for x in decisions),'proposal_records':1,'changed_arrays':2,'target':'mounted_slide_transparency_object_relation','new_anchor':'film edge thickness','baseline_head':before['head'],'baseline_runtime':'f4094afc','proposal_head':new_runtime['head'],'source_record_sha256':proposal['source_record_sha256'],'proposed_record_sha256':proposal['proposed_record_sha256'],'implementation_authorized':False,'source_and_index_unchanged':True,'no_public_cli_or_pixels':True,'next_step':'Independent exact-source review; do not implement during unrelated publication work. An accepted proposal requires genuine visual-profile index refresh and frozen normal public before/after qualification.'})
manifest={str(p.relative_to(O)):sha(p.read_bytes()) for p in sorted(O.rglob('*')) if p.is_file() and p.name!='artifact-manifest.json'};save('artifact-manifest.json',manifest)
print(json.dumps({'decisions':len(decisions),'keeps':sum(x['decision']=='KEEP' for x in decisions),'defers':sum(x['decision']=='DEFER' for x in decisions),'proposal':1,'unchanged_source_records':len(verified),'parent_runtime_changed_files':len(changes),'ending_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()}))
