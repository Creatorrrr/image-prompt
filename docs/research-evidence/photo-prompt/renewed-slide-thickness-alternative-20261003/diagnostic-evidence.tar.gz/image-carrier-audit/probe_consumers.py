"""Genuine current local consumers, with no providers/vectors/repository writes."""
from pathlib import Path
import copy,hashlib,json,subprocess,sys
sys.dont_write_bytecode=True
R=Path('REPOSITORY_ROOT');O=Path(__file__).resolve().parent;A=R/'skills/photo-prompt-image-generator/assets'
sys.path.insert(0,str(A.parent/'scripts'));import prompt_generator as pg;import audit_composed_prompt as ac
sha=lambda b:hashlib.sha256(b).hexdigest()
canon=lambda x:sha(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())
def save(n,x):(O/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
rows=json.loads((O/'source-records.json').read_text());by={x['id']:x for x in rows}
reg=pg.load_visual_obligation_registry(A/'photo_prompt_visual_obligations.json');idx=pg.load_visual_profile_index(A/'photo_prompt_visual_profile_index.json',reg)
ps={p['id']:p for p in reg['profiles'] if p['id'] in by and by[p['id']]['kind']=='profile'}
data=pg.load_json(A/'photo_prompt_tags.json');data[pg.QUALITY_LAYERS_DATA_KEY]=pg.load_quality_layers(A/pg.QUALITY_LAYERS_FILENAME)
def resolve(t):
 res={'provenance':{'concept_lock':[t]}};ss=pg.candidate_pack_visual_obligation_request_sources(res,{})
 hits=pg.resolve_visual_profile_hits(reg,ss,visual_profile_index=idx,adult_context=True)
 c=pg.candidate_pack_visual_obligations({pg.VISUAL_OBLIGATIONS_DATA_KEY:reg},res,{},None,visual_profile_resolution=hits)
 return hits,c
def binding(f,t,req):
 try:pg.validate_visual_intent_binding(obligation_index=0,field=f,phrase=t,requirement=req);return {'pass':True}
 except ValueError as e:return {'pass':False,'error':str(e)}
wrong={
'daguerreotype_reflective_cased_plate_object':[('silvered_metal_plate_phrase','A sepia paper portrait sits inside a wooden frame.','wrong_paper_support'),('angle_dependent_reflection_phrase','A simulated glare gradient floats across the entire screen.','digital_glare_overlay')],
'calotype_salted_paper_fiber_image_relation':[('matte_paper_phrase','A woven canvas carries thick oil paint depicting the portrait.','canvas_instead_of_paper'),('cross_region_fibers_phrase','A digital linen overlay crosses the entire image and surrounding background.','digital_texture_overlay')],
'wet_collodion_glass_plate_coating_trace':[('glass_plate_support_phrase','A flexible film strip carries perforations along both sides.','film_instead_of_glass'),('pour_edge_phrase','A simulated vignette shades all four edges equally.','digital_vignette_overlay')],
'albumen_card_mount_print_material_relation':[('thin_print_thick_card_phrase','A painted illustration lies directly on a single uncoated cardboard sheet.','missing_layered_support'),('albumen_gloss_phrase','A brown color filter grades the entire digital image uniformly.','digital_color_grade')],
'cyanotype_contact_print_prussian_blue_relation':[('paper_boundary_phrase','A blue screen fills the frame from corner to corner.','screen_instead_of_paper'),('contact_silhouette_phrase','White vector leaf cutouts are composited over a flat blue digital background.','digital_silhouette_overlay')],
'autochrome_glass_transparency_color_screen':[('glass_transparency_phrase','An opaque paper photograph sits in a plastic picture frame.','paper_instead_of_glass'),('starch_mosaic_phrase','A regular digital RGB subpixel grid covers a computer display.','digital_pixel_grid')],
'integral_instant_print_object_relation':[('complete_print_phrase','A smartphone display shows a square image with a white UI frame.','screen_instead_of_physical_print'),('image_inside_object_phrase','A white border graphic floats over the portrait and background.','digital_frame_overlay')],
'mounted_slide_transparency_object_relation':[('transparent_film_phrase','An opaque paper snapshot is pasted onto the cardboard aperture.','paper_instead_of_film'),('film_edge_density_phrase','A digital embossed border is drawn around the displayed photograph.','digital_depth_overlay')]}
profile_tests=[];contracts={};base_evidence={}
for pid,p in ps.items():
 request='Photograph this explicitly selected visible relation: '+p['activation']['exact_terms'][0]
 hits,c=resolve(request);assert c and pid in [o['id'] for o in c['obligations']]
 ob=next(o for o in c['obligations'] if o['id']==pid)
 ev={f:r['must_mention_any'][0] for f,r in ob['evidence_requirements'].items()}
 full_ev={o['id']:{f:r['must_mention_any'][0] for f,r in o['evidence_requirements'].items()} for o in c['obligations']}
 def audit(e):
  es={**full_ev,pid:e};text='. '.join(t for oe in es.values() for t in oe.values())
  return ac.audit_visual_obligations({'visual_obligations':c},{'visual_obligation_evidence':es},text)
 fs=audit(ev);assert not fs,(pid,fs)
 bindings=[{'field':f,'phrase':t,'result':binding(f,t,ob['evidence_requirements'][f])} for f,t in ev.items()];assert all(r['result']['pass'] for r in bindings)
 negatives=[]
 for f in ev:
  e={k:t for k,t in ev.items() if k!=f};fail=audit(e);assert any(x.get('field')==f for x in fail)
  negatives.append({'kind':'omission','field':f,'evidence':e,'failures':fail})
 for f,t,label in wrong[pid]:
  e={**ev,f:t};fail=audit(e);assert any(x.get('field')==f for x in fail),(pid,f,fail)
  negatives.append({'kind':'wrong_neighbor','label':label,'field':f,'evidence':e,'binding':binding(f,t,ob['evidence_requirements'][f]),'failures':fail})
 groups=p['semantics']['component_semantics']['groups'];terms=[g['any_terms'][0] for g in groups]
 components=[{'kind':'complete','text':'; '.join(terms),'match':pg.candidate_pack_visual_component_match(p,'; '.join(terms))}];assert components[0]['match']=='component_semantics'
 for i,g in enumerate(groups):
  t='; '.join(s for j,s in enumerate(terms) if i!=j);m=pg.candidate_pack_visual_component_match(p,t);assert m!='component_semantics'
  components.append({'kind':'omission','group':g['id'],'text':t,'match':m})
 profile_tests.append({'id':pid,'request':request,'hits':hits['hits'],'contract':c,'positive_evidence':ev,'binding_controls':bindings,'positive_failures':fs,'negative_evidence_controls':negatives,'component_controls':components})
 contracts[pid]=c;base_evidence[pid]=ev
# Measure branch wording against the actual contract; record passing generic owner anchors separately.
branch_specs=[
('daguerreotype_reflective_cased_plate_object','protective_case_topology_phrase','protective case topology; the plate is recessed behind its protective glass and mat','case_owner_existing_anchor'),
('wet_collodion_glass_plate_coating_trace','coherent_flow_streak_phrase','one uneven coating zone is bounded to the hand-poured emulsion on the glass plate','uneven_coating_only'),
('wet_collodion_glass_plate_coating_trace','localized_pinholes_phrase','isolated chemistry spots owned by the plate remain confined to its image-bearing emulsion','chemistry_spots_only'),
('albumen_card_mount_print_material_relation','fine_overall_crackle_phrase','microscopic paper fiber visible through the albumen layer remains confined to the mounted photographic sheet','paper_fiber_only'),
('albumen_card_mount_print_material_relation','albumen_gloss_phrase','smooth albumen surface covers the thin photographic paper layer','smooth_surface_only'),
('autochrome_glass_transparency_color_screen','transmitted_light_phrase','transmitted light passes through the image-bearing glass plate','transmission_existing_anchor'),
('autochrome_glass_transparency_color_screen','transmitted_light_phrase','backlit viewing reveals the fine color screen within the image-bearing glass','backlit_only'),
('integral_instant_print_object_relation','object_depth_phrase','object depth is visible through the thin raised print edge against the table','depth_existing_anchor'),
('integral_instant_print_object_relation','object_depth_phrase','print thickness is visible along the raised edge of the physical card','print_thickness_only'),
('integral_instant_print_object_relation','localized_development_trace_phrase','localized handling trace remains confined to one corner of the physical print','handling_only'),
('mounted_slide_transparency_object_relation','physical_mount_phrase','physical mount is molded from plastic around the transparent photograph','plastic_existing_anchor'),
('mounted_slide_transparency_object_relation','physical_mount_phrase','plastic mount surrounds the transparent photograph with a continuous outer boundary','plastic_only'),
('mounted_slide_transparency_object_relation','film_edge_density_phrase','film edge thickness is visible as a thin transparent rim inside the physical mount aperture','film_thickness_only'),
('mounted_slide_transparency_object_relation','film_edge_density_phrase','film edge density is visible along the same transparent rim within the physical mount','film_density_existing_anchor')]
branches=[]
for pid,f,t,label in branch_specs:
 p=ps[pid];c=copy.deepcopy(contracts[pid]);ob=next(o for o in c['obligations'] if o['id']==pid);c['obligations']=[ob];e={**base_evidence[pid],f:t}
 gs=p['semantics']['component_semantics']['groups'];i=list(ob['evidence_requirements']).index(f);terms=[g['any_terms'][0] for g in gs];terms[i]=t;text='; '.join(terms)
 fs=ac.audit_visual_obligations({'visual_obligations':c},{'visual_obligation_evidence':{pid:e}},'. '.join(e.values()))
 branches.append({'id':pid,'field':f,'label':label,'phrase':t,'evidence':e,'binding':binding(f,t,ob['evidence_requirements'][f]),'audit_failures':fs,'component_text':text,'component_match':pg.candidate_pack_visual_component_match(p,text)})
# Record all original combined OR anchors as truthfully usable but disjunctive routes.
old_ors=[]
for pid,p in ps.items():
 for f,req in p['evidence_requirements'].items():
  if ' or ' in req['must_mention_any'][0]:
   t=req['must_mention_any'][0];result=binding(f,t,req);assert result['pass'];old_ors.append({'id':pid,'field':f,'phrase':t,'binding':result})
activation=[]
for pid,p in ps.items():
 for label,t in [('exact_ko',p['activation']['exact_terms'][1]),('generic_contrast','Photograph '+p['reject_substitutes'][0]+'.')]:
  h,c=resolve(t);target=[x for x in h['hits'] if x['profile_id']==pid and x.get('hard_eligible')]
  assert bool(target)==(label=='exact_ko'),(pid,label,target)
  activation.append({'id':pid,'label':label,'request':t,'target_hard_hits':target,'all_hits':h['hits']})
projection=[]
for row in rows:
 if row['kind']!='candidate':continue
 src=pg.photo_candidate_semantics.semantic_source(row['record'],row['slot'],data.get('candidate_semantic_policy'))
 ss=[{'source':'concept_lock','text':row['record']['en'],'polarity':'required','priority':'critical','mandatory':True}]
 target=pg.candidate_pack_auto_visual_obligation_matches(reg,ss)
 projection.append({'id':row['id'],'slot':row['slot'],'source':src,'candidate_en_request_exact_matches':target})
# Explicit anchor-retention limits, not semantic rejection claims.
limits=[];pid='mounted_slide_transparency_object_relation';c=copy.deepcopy(contracts[pid]);ob=next(x for x in c['obligations'] if x['id']==pid);c['obligations']=[ob];f='film_edge_density_phrase'
for t in ['film edge density is only a digital label on a flat computer screen','film edge density is written on a paper label beside the photographic object']:
 e={**base_evidence[pid],f:t};fs=ac.audit_visual_obligations({'visual_obligations':c},{'visual_obligation_evidence':{pid:e}},'. '.join(e.values()));assert not fs
 limits.append({'phrase':t,'failures':fs,'interpretation':'Literal anchor passes; physical support and same-object ownership are not established. Saved-image gates remain necessary.'})
counts={'profiles':len(profile_tests),'positive_evidence_fields':40,'evidence_omissions':40,'wrong_neighbor_controls':16,'component_omissions':40,'branch_diagnostics':len(branches),'branch_passes':sum(x['binding']['pass'] for x in branches),'branch_failures':sum(not x['binding']['pass'] for x in branches),'old_disjunction_anchors':len(old_ors),'activation_controls':len(activation),'candidate_projections':len(projection),'anchor_retention_limit_controls':len(limits)}
save('consumer-proof.json',{'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'actual_bound_index_loaded':True,'index_sha256':sha((A/'photo_prompt_visual_profile_index.json').read_bytes()),'scope':'Current source-bound request resolver, obligation compilation, field binding, composed-evidence and component helpers. Not public CLI/frozen-core/ranking/pixel qualification.','profile_tests':profile_tests,'branch_diagnostics':branches,'old_disjunction_controls':old_ors,'activation_controls':activation,'candidate_projections':projection,'anchor_retention_limits':limits,'counts':counts})
print(json.dumps(counts))
