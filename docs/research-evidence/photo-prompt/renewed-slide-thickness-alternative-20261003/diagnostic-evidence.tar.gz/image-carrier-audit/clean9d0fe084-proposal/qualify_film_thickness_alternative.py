"""Qualify one exact two-array DATA proposal in memory. No repo/index writes."""
from pathlib import Path
import copy,hashlib,json,subprocess,sys,datetime
sys.dont_write_bytecode=True
R=Path('REPOSITORY_ROOT');O=Path(__file__).resolve().parent;A=R/'skills/photo-prompt-image-generator/assets'
run_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
run_start=datetime.datetime.now(datetime.timezone.utc).isoformat()
run_files={str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (A.parent/'scripts').glob('*.py')}
sys.path.insert(0,str(A.parent/'scripts'));import prompt_generator as pg;import audit_composed_prompt as ac
sha=lambda b:hashlib.sha256(b).hexdigest()
canon=lambda x:sha(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())
def save(n,x):(O/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def diff(a,b,p=''):
 if type(a)!=type(b):return [{'path':p,'before':a,'proposed':b}]
 if isinstance(a,dict):
  assert a.keys()==b.keys();return [r for k in a for r in diff(a[k],b[k],p+'/'+k)]
 if isinstance(a,list):
  if len(a)!=len(b):return [{'path':p,'before':a,'proposed':b}]
  return [r for i in range(len(a)) for r in diff(a[i],b[i],p+'/'+str(i))]
 return [] if a==b else [{'path':p,'before':a,'proposed':b}]
pid='mounted_slide_transparency_object_relation';f='film_edge_density_phrase';anchor='film edge thickness'
rows=json.loads((O/'source-records.json').read_text());row=next(r for r in rows if r['id']==pid);before=row['record'];after=copy.deepcopy(before)
actual=next(p for p in json.loads((R/row['file']).read_text())['profiles'] if p['id']==pid);assert actual==before
old=['film edge density or thickness','film edge density'];g=after['semantics']['component_semantics']['groups'][4];assert g['id']=='film_edge_density' and g['any_terms']==old and after['evidence_requirements'][f]['must_mention_any']==old
g['any_terms'].append(anchor);after['evidence_requirements'][f]['must_mention_any'].append(anchor)
changes=diff(before,after);assert {r['path'] for r in changes}=={'/semantics/component_semantics/groups/4/any_terms','/evidence_requirements/film_edge_density_phrase/must_mention_any'}
save('before-profile.json',before);save('proposed-profile.json',after);save('exact-changed-leaves.json',[{'file':row['file'],'profile_id':pid,**r} for r in changes])
reg=pg.load_visual_obligation_registry(A/'photo_prompt_visual_obligations.json');idx=pg.load_visual_profile_index(A/'photo_prompt_visual_profile_index.json',reg)
rb=next(p for p in reg['profiles'] if p['id']==pid);ra=pg.compile_visual_profile(after);assert rb==pg.compile_visual_profile(before)
newreg=copy.deepcopy(reg);newreg['profiles']=[ra if p['id']==pid else p for p in newreg['profiles']]
ob=pg.candidate_pack_visual_profile_obligation(before,reg,activation_source='audit',source_intent_ids=[]);oa=pg.candidate_pack_visual_profile_obligation(after,newreg,activation_source='audit',source_intent_ids=[])
odiff=diff(ob,oa);assert {r['path'] for r in odiff}=={'/component_semantics/groups/4/any_terms','/evidence_requirements/film_edge_density_phrase/must_mention_any'}
base={ff:r['must_mention_any'][0] for ff,r in ob['evidence_requirements'].items()}
request={'provenance':{'concept_lock':[before['activation']['exact_terms'][0]]}}
request_sources=pg.candidate_pack_visual_obligation_request_sources(request,{})
resolution=pg.resolve_visual_profile_hits(reg,request_sources,visual_profile_index=idx,adult_context=True)
base_contract=pg.candidate_pack_visual_obligations({pg.VISUAL_OBLIGATIONS_DATA_KEY:reg},request,{},None,visual_profile_resolution=resolution)
assert pid in [x['id'] for x in base_contract['obligations']]
def bind(field,t,o):
 try:pg.validate_visual_intent_binding(obligation_index=0,field=field,phrase=t,requirement=o['evidence_requirements'][field]);return {'pass':True}
 except ValueError as e:return {'pass':False,'error':str(e)}
def audit(ev,o):
 # This is the same production evidence auditor, with the genuine materialized obligation.
 contract=copy.deepcopy(base_contract);contract['obligations']=[o]
 return ac.audit_visual_obligations({'visual_obligations':contract},{'visual_obligation_evidence':{pid:ev}},'. '.join(ev.values()))
def check(t):
 ev={**base,f:t};terms=[g['any_terms'][0] for g in rb['semantics']['component_semantics']['groups']];terms[4]=t;txt='; '.join(terms)
 return {'phrase':t,'evidence':ev,'component_text':txt,'before_binding':bind(f,t,ob),'proposed_binding':bind(f,t,oa),'before_failures':audit(ev,ob),'proposed_failures':audit(ev,oa),'before_component_match':pg.candidate_pack_visual_component_match(rb,txt),'proposed_component_match':pg.candidate_pack_visual_component_match(ra,txt)}
positive=check('film edge thickness is visible as a thin transparent rim at the image-bearing layer boundary')
assert not positive['before_binding']['pass'] and positive['proposed_binding']['pass'];assert positive['before_failures'] and not positive['proposed_failures'];assert positive['before_component_match']!='component_semantics' and positive['proposed_component_match']=='component_semantics'
old_controls=[check(t) for t in old];assert all(r['before_binding']['pass'] and r['proposed_binding']['pass'] and not r['before_failures'] and not r['proposed_failures'] for r in old_controls)
neg=[]
for ff in base:
 ev={k:v for k,v in positive['evidence'].items() if k!=ff};bf=audit(ev,ob);af=audit(ev,oa);assert any(x.get('field')==ff for x in af)
 neg.append({'kind':'omission','field':ff,'evidence':ev,'before_failures':bf,'proposed_failures':af})
for ff,t,label in [
('transparent_film_phrase','An opaque paper snapshot is pasted onto the cardboard aperture.','wrong_paper_support'),
('transparent_film_phrase','A rigid image-bearing glass plate sits inside a wooden holder.','glass_instead_of_film'),
('physical_mount_phrase','A software window draws a thin rectangular frame around the photograph.','digital_mount'),
('transmitted_light_phrase','Front-side glare reflects from an opaque photograph.','reflected_light_instead_of_transmission'),
('image_in_aperture_phrase','The photograph floats over both the surrounding frame and background.','image_not_contained'),
(f,'A digital embossed border is drawn around the displayed photograph.','digital_depth_overlay'),
(f,'The cardboard rim is thick while the image-bearing film cannot be seen at its edge.','mount_thickness_wrong_owner'),
(f,'Thickness belongs to a nearby glass cover beside the image-bearing transparency.','neighboring_glass_wrong_owner')]:
 ev={**positive['evidence'],ff:t};bf=audit(ev,ob);af=audit(ev,oa);assert any(x.get('field')==ff for x in af)
 neg.append({'kind':'wrong_neighbor','label':label,'field':ff,'evidence':ev,'before_binding':bind(ff,t,ob),'proposed_binding':bind(ff,t,oa),'before_failures':bf,'proposed_failures':af})
components=[];terms=positive['component_text'].split('; ')
for i,g in enumerate(rb['semantics']['component_semantics']['groups']):
 text='; '.join(t for j,t in enumerate(terms) if i!=j);bm=pg.candidate_pack_visual_component_match(rb,text);am=pg.candidate_pack_visual_component_match(ra,text);assert bm!='component_semantics' and am!='component_semantics'
 components.append({'omitted_group':g['id'],'text':text,'before':bm,'proposed':am})
limits=[]
for t in ['film edge density is only a digital label on a flat computer screen','film edge density is written on a paper label beside the photographic object','film edge thickness is only a digital label on a flat computer screen']:
 r=check(t);limits.append(r)
# Old anchors retain their known limits; new anchor does not claim semantic validation.
assert not limits[0]['before_failures'] and not limits[0]['proposed_failures'];assert not limits[1]['before_failures'] and not limits[1]['proposed_failures'];assert limits[2]['before_failures'] and not limits[2]['proposed_failures']
routes={}
for label,request in {'exact_en':'mounted photographic slide transparency object','exact_ko':'마운트된 사진 슬라이드 투명 원고 객체','generic':'vintage photographic print','paper':'an opaque paper snapshot pasted onto a frame','glass':'a glass plate transparency in a holder','digital':'a photograph with a digital slide border','negative':'a film negative strip','saturated':'a saturated color image'}.items():
 ss=[{'source':'concept_lock','text':request,'polarity':'required','priority':'critical','mandatory':True}];b=pg.candidate_pack_auto_visual_obligation_matches(reg,ss);a=pg.candidate_pack_auto_visual_obligation_matches(newreg,ss);assert a==b;assert (pid in b)==label.startswith('exact');routes[label]={'request':request,'before':b,'proposed':a}
tb=pg.visual_profile_semantic_text(rb);ta=pg.visual_profile_semantic_text(ra);assert tb!=ta and anchor in ta
(O/'positive-text-before.txt').write_text(tb+'\n');(O/'positive-text-proposed.txt').write_text(ta+'\n')
assert pg.visual_profile_exact_term_rows(reg)==pg.visual_profile_exact_term_rows(newreg)
try:pg.validate_visual_profile_index_metadata(idx,newreg);raise AssertionError('Old index accepted changed registry')
except ValueError as e:stale=str(e)
save('positive-text-index-impact.json',{'before_text_sha256':sha(tb.encode()),'proposed_text_sha256':sha(ta.encode()),'positive_text_changed':True,'exact_lookup_unchanged':True,'before_registry_sha256':pg.visual_profile_registry_sha256(reg),'proposed_registry_sha256':pg.visual_profile_registry_sha256(newreg),'current_visual_index_sha256':sha((A/'photo_prompt_visual_profile_index.json').read_bytes()),'old_index_rejected_for_proposed_registry':stale,'before_bm25f_fields':pg.visual_profile_bm25f_fields(rb),'proposed_bm25f_fields':pg.visual_profile_bm25f_fields(ra),'required_next_step':'Independent source review; authorized isolated application after publication hold; genuine visual-profile index refresh; frozen normal public before/after qualification. No vector fabrication or old-vector/digest relabeling.'})
end_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
end_files={str(p.relative_to(R)):sha(p.read_bytes()) for p in (A.parent/'scripts').glob('*.py')}
assert end_head==run_head and run_files==end_files,'Runtime changed during probe; rerun under stable pin'
save('proposal-runtime-manifest.json',{'head':run_head,'started_at_utc':run_start,'finished_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'runtime_unchanged_during_run':True,'files':run_files,'source_record_sha256':canon(before),'actual_visual_index_sha256':sha((A/'photo_prompt_visual_profile_index.json').read_bytes()),'registry_sha256':pg.visual_profile_registry_sha256(reg),'baseline_resolver_hits':resolution['hits']})
save('proposal-consumer-proof.json',{'head':run_head,'source_record_sha256':canon(before),'proposed_record_sha256':canon(after),'before_obligation':ob,'proposed_obligation':oa,'exact_obligation_changes':odiff,'film_thickness_positive':positive,'old_anchor_controls':old_controls,'negative_controls':neg,'component_omission_controls':components,'anchor_retention_limits':limits,'exact_route_controls':routes,'unchanged_invariants':['all other profile leaves','all component/evidence IDs and minima','five-group requirement','all original anchors in original order','all render-gate IDs, scales, wording','activation and exclusions','physical film support, transmission and mount ownership','image-within-aperture topology','all optional candidates','runtime code, source and indexes'],'limits':'Local in-memory DATA consumer qualification only. No normal public CLI/frozen-core/ranking/pixel qualification. Literal helpers do not prove physical truth or ownership; deliberate old/new anchor-retention tests expose this.'})
print(json.dumps({'changed_arrays':len(changes),'thickness_only':'fails_before_passes_proposed','old_anchors_preserved':len(old_controls),'negative_evidence_controls':len(neg),'component_omissions':len(components),'exact_route_controls':len(routes),'positive_text_changed':True,'stale_index_rejected':True}))
