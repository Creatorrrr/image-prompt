# Physical image-carrier and printing-process DATA audit

## Result

**One minimal two-array proposal; 16 KEEP records; two DEFER records. No implementation.** The bounded scope is 19 complete current records: eight hard process/carrier profiles and 11 optional candidate atoms. Original research proposals, compiled components, literal evidence requirements, composition, native/thumbnail gates, same-object ownership and candidate scope were compared. The 1,510-profile loader count is not audit coverage.

The proposal only appends **`film edge thickness`** to `mounted_slide_transparency_object_relation`'s existing `film_edge_density` component `any_terms` and matching `film_edge_density_phrase.must_mention_any`. Both existing anchors remain first, unchanged. No gate, owner, minimum, exact alias, candidate, source, runtime or index is changed.

## Source authority and concrete gap

The original `photo-era-visual-semantics-20260905/candidate-data-proposal.json` explicitly selects these five mounted-slide components:

1. transparent film frame
2. cardboard or plastic mount
3. transmitted-light viewing
4. image contained within mount aperture
5. **film edge density or thickness**

The original source report separately describes frame-edge density / film thickness. The current definition, composition and first component/evidence anchor preserve that OR. The current native gates require film translucency, image transmission and containment within the aperture; none mandates a visible density difference in addition to thickness. Its existing English paraphrase also explicitly names transparent film thickness.

Current literals are only `film edge density or thickness` and `film edge density`. This definite branch is blocked:

> film edge thickness is visible as a thin transparent rim at the image-bearing layer boundary

It fails field binding, the actual composed-evidence auditor and complete five-group component matching. Adding the proposed anchor to the two arrays makes all three pass. The other four fields still declare the same physical film, actual mount, transmitted light and image-within-aperture relation. No unrelated plate, glass cover or thick mount substitutes for the film edge.

This is an asymmetric literal branch gap, **not an assertion that the existing OR logically requires both density and thickness**. The old combined sentence can truthfully represent a thickness-only scene and continues to pass. The new anchor allows a definite source-permitted observation without mentioning the unselected density alternative. This audit uses the repository's explicit authored scope; it does not newly certify process chemistry, material composition or photographic authenticity.

## Pinned runs and controls

### Broad baseline: local 62917903, runtime f4094afc

`consumer-proof.json` is the completed pre-integration baseline. `source-manifest.json` pins HEAD `62917903e482a5a224c789b976d93871b19d16b7`; `runtime-manifest.json` hashes all 23 scripts and verifies their equality to `f4094afc`. The actual current source-bound visual index was loaded successfully.

- Eight exact English requests materialize the complete target obligations
- All 40 positive evidence fields pass
- 40 single-field omissions, 16 wrong-support / digital-overlay replacements and 40 component omissions fail their target requirement
- Eight exact Korean requests retain target hard hits, while eight generic contrast requests do not hard-activate the target
- Fourteen branch diagnostics yield five passes through existing anchors and nine single-branch literal failures
- All ten original disjunctive anchors remain valid
- Eleven optional candidate semantic-source projections are saved; their individual English atoms do not independently exact-trigger any hard profile

These are current local resolver/helper checks, not complete public CLI or ranking qualification.

### Authoritative proposal: clean 9d0fe084

During the audit the parent independently integrated authorized runtime changes and the already pending acetate fix. The proposal was therefore separately rerun on HEAD `9d0fe0841b6ea5163c99b1f893440f6733a3b2a6`, from 07:07:35 to 07:08:03 UTC. `clean9d0fe084-proposal/proposal-runtime-manifest.json` captures all runtime file hashes before import and verifies unchanged HEAD/hashes afterward. The current resolver freshly materialized the contract on that runtime. The authoritative proposal proof is `clean9d0fe084-proposal/proposal-consumer-proof.json`; root copies are identical convenience artifacts.

- Concrete thickness-only binding, composed evidence and complete component match fail before / pass after
- Both original anchors pass before and after
- Five evidence omissions and five component omissions remain failures
- Eight wrong-neighbor substitutions remain failures: opaque paper support, glass instead of film, digital mount, reflected glare instead of transmission, uncontained image, digital embossed border, thick cardboard rim, neighboring thick glass cover
- Eight exact-route controls remain identical: English/Korean exact requests plus generic vintage print, paper, glass, digital border, negative strip and saturated image controls
- Source and emitted obligation differ only in the two named arrays
- All five group IDs, evidence IDs/minima, old anchors, exact routes, exclusions, instructions, gates/scales, physical ownership and optional candidates remain unchanged

A launch that straddled integration is invalid for pin-specific conclusions. Its raw JSON was superseded before the later request to preserve it arrived. `invalid-mixed-pin-launch.json` records this limitation and its observed stdout without reconstructing missing raw evidence. It is excluded from the findings above. There is no claim of one homogeneous runtime across the broad baseline and proposal run.

## Per-family decisions

### KEEP: reflective metal, image-in-paper and cyanotype carriers

The daguerreotype profile retains silvered plate support, surface-owned angular/tonal response, fine non-paper image detail, full boundary/depth and protective topology. Its existing protective-case anchor can express the selected physical structure. A mirror, tintype, silver picture frame or sepia print is not interchangeable with that structure.

The calotype/salted-paper profile deliberately ties the image to actual upper paper fibers across both light and dark areas, while preserving photographic continuity and the paper edge. Canvas, a global texture overlay or blur is not an undeclared alternative.

The cyanotype profile deliberately selects a contact-print signature: visible paper, a blue image field, contacted silhouettes, opacity-owned tonal steps and plausible overlap. Broad blue monochrome appearance or a cyanotype-inspired digital treatment does not automatically promise this entire contract.

### KEEP: Autochrome and integral instant-print scope

Autochrome's glass/transmission and material-owned fine screen remain separate from pixel grids, colored grain and paper printing. Existing `transmitted light` evidence works. A definite backlit-only sentence fails the literal anchor, but this audit does not bundle another lexical expansion or reduce the native screen/ownership requirements.

The integral instant-print contract selects a complete physical object, asymmetric margin, depth, image containment and a localized material trace. Existing `object depth` represents visible thickness without requiring a cast shadow. Definite `print thickness` and handling-only phrasing have measured lexical limitations; they do not justify universal damage requirements, broad brand aliases or removal of the material-object evidence. Their expansion is deferred rather than bundled with the mounted-slide proposal.

### DEFER: wet-collodion and albumen gate consistency

Wet-collodion's authored components permit a flow streak **or** uneven coating and pinholes **or** chemistry spots. The isolated uneven-coating and chemistry-spot branches fail literal consumers. Original and current render-gate wording still names “streak and pinholes” on the emulsion. A source-gate consistency review is needed before representing an anchor-only addition as fully qualified. No new chemical phenomenon, globally damaged glass or owner relaxation is proposed.

Albumen's authored component permits overall fine crackle **or** microscopic paper fiber through its image-bearing layer; its fine-crackle gate is less explicit about the alternative. The historical implementation review did evaluate crackle-or-fiber visibility and recorded that arm as failing the material visibility gate, not passing. Both fiber-only and smooth-surface sentences fail current literal anchors. The audit defers a separately reviewed repair rather than silently altering that native visibility interpretation or broadening the crackle-specific optional surface candidate. Paper/mount layering, image-layer surface response, detail and complete perimeter stay required.

### KEEP: all 11 optional candidate atoms

The current optional rows preserve their original IDs and English/Korean visible claims. Source proposal `slot` and `lane` fields were mapped into the current containing slot and tags; those schema differences are preserved in `source-current-comparison.json` rather than misreported as record equality. Weight, keywords and embedding text are frozen in full.

They name a cased plate, salted-paper print, glass negative, mounted albumen print, backlit transparency, contact-print context, mounted-slide context, silvered-copper surface, collodion pour-edge surface, Autochrome screen surface and instant-print layered border. They do not automatically inherit the complete hard contracts. In particular a general glass negative is not forced to be wet collodion, and a general backlit transparency is not forced to be Autochrome. Historical year ranges in compatibility keywords do not authenticate capture date, original equipment, chemical composition or historical provenance.

## Scope and honest limits

The initial wear/damage report and its full selected record list were read before freezing this scope; the selected IDs have zero overlap. Acetate, silver mirroring, chromogenic fading, material wear/fracture and every prior wear/damage record are excluded. Albumen and collodion are inspected here only as image-layer/support contracts, not as newly audited deterioration families. No generic vintage alias, exact-age claim or authenticity inference is added.

Literal helper negatives are not physical-semantic rejection guarantees. Two deliberately misleading old-anchor sentences pass unchanged; a misleading new-anchor sentence also passes after the addition. Those controls explicitly show that words alone do not prove support or ownership. Saved-image inspection still has to verify the actual film edge, image-bearing layer, mount aperture and transmitted light. No image was generated or inspected, no public frozen-core/ranking result was produced, and no final image-quality improvement is claimed.

## Index consequence and handoff

The component anchor changes the profile's positive retrieval text and BM25F fields. The exact lookup rows remain unchanged, but the registry digest changes; the actual current visual index correctly rejects the proposed registry as stale. `positive-text-index-impact.json` records exact before/after texts, hashes, BM25F values and rejection. No replacement vectors/index were generated or relabeled.

If independently accepted, apply only the two frozen arrays after the unrelated publication work, refresh the genuine visual-profile index through the existing authorized procedure, and qualify the same frozen normal public requests/evidence before and after. The audit itself grants no implementation or publication authority.

## Artifacts

- `source-records.json`: 19 complete current records, exact pointers and hashes
- `original-research-records.json`: the matching 19 original proposals and eight linked evidence-ledger rows
- `source-current-comparison.json`: complete scope and original/current contract comparisons
- `compiled-profiles.json`, `profile-index-record-hashes.json`: eight actual compiled profiles and bound-index entry hashes
- `consumer-proof.json`: broad old-runtime controls with every input and result
- `clean9d0fe084-proposal/`: authoritative proposal, consumer proof, stable runtime pin, exact changes and index consequences
- `decisions.json`: one decision per audited record
- `ending-verification.json`: unchanged selected records/source/index hashes and separately identified parent runtime changes
- `diagnostic-log.md`, `invalid-mixed-pin-launch.json`: failed harness attempts and mixed-pin artifact limits
- `artifact-manifest.json`: full evidence-artifact hashes

All audit writes are outside `image-prompt/`. No source, test, runtime, index, API, installation or publication was changed by this audit. The bounded stop condition is reached: original intent and full records frozen, actual contracts compared, a permitted alternative reproduced, two-array proposal qualified, controls/limits recorded and hash-bound handoff prepared.
