"""Read-only repository audit; only writes evidence next to this script."""
from pathlib import Path
import hashlib,json,subprocess,sys
sys.dont_write_bytecode=True
R=Path('REPOSITORY_ROOT');O=Path(__file__).resolve().parent;A=R/'skills/photo-prompt-image-generator/assets';D=R/'docs/research-evidence/photo-prompt/photo-era-visual-semantics-20260905'
PIDS='daguerreotype_reflective_cased_plate_object calotype_salted_paper_fiber_image_relation wet_collodion_glass_plate_coating_trace albumen_card_mount_print_material_relation cyanotype_contact_print_prussian_blue_relation autochrome_glass_transparency_color_screen integral_instant_print_object_relation mounted_slide_transparency_object_relation'.split()
CIDS='cased_photographic_plate_object salted_paper_print_object glass_plate_negative_object mounted_albumen_card_print backlit_color_transparency_object silvered_copper_photographic_plate collodion_glass_pour_edge_surface autochrome_starch_mosaic_glass_surface instant_print_layered_border_surface mounted_slide_backlight_context contact_print_object_silhouette_context'.split()
sha=lambda b:hashlib.sha256(b).hexdigest()
canon=lambda x:sha(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())
def save(n,x):(O/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def git(*a):return subprocess.check_output(['git',*a],cwd=R,text=True).strip()
def walk(d,p=''):
 if isinstance(d,dict):
  if 'id' in d:yield p,d
  for k,v in d.items():yield from walk(v,p+'/'+str(k))
 elif isinstance(d,list):
  for i,v in enumerate(d):yield from walk(v,p+'/'+str(i))
paths=set();records=[]
for f in sorted(A.glob('*.json')):
 if 'index' in f.name:continue
 d=json.loads(f.read_text())
 for i,p in enumerate(d.get('profiles',[])):
  if p['id'] in PIDS:records.append({'kind':'profile','id':p['id'],'file':str(f.relative_to(R)),'pointer':f'/profiles/{i}','canonical_sha256':canon(p),'record':p});paths.add(f)
 for slot,rs in d.get('slots',{}).items():
  for i,p in enumerate(rs):
   if p['id'] in CIDS:records.append({'kind':'candidate','slot':slot,'id':p['id'],'file':str(f.relative_to(R)),'pointer':f'/slots/{slot}/{i}','canonical_sha256':canon(p),'record':p});paths.add(f)
assert len(records)==19 and {x['id'] for x in records}==set(PIDS+CIDS)
prior=json.loads((O.parent/'wear-damage-audit/source-records.json').read_text());assert not set(PIDS+CIDS)&{x['id'] for x in prior}
save('source-records.json',records)
f=D/'candidate-data-proposal.json';d=json.loads(f.read_text());paths.add(f)
original=[{'id':r['id'],'pointer':p,'canonical_sha256':canon(r),'record':r} for p,r in walk(d) if r['id'] in set(PIDS+CIDS)]
assert len(original)==19 and {x['id'] for x in original}==set(PIDS+CIDS)
source_ids=set(s for r in original if r['id'] in PIDS for s in r['record']['source_ids'])
ef=D/'evidence.jsonl';paths.add(ef);er=[{'line':i+1,'id':r['id'],'canonical_sha256':canon(r),'record':r} for i,l in enumerate(ef.read_text().splitlines()) if l.strip() for r in [json.loads(l)] if r['id'] in source_ids]
save('original-research-records.json',{'proposal_file':str(f.relative_to(R)),'proposal_file_sha256':sha(f.read_bytes()),'records':original,'evidence_file':str(ef.relative_to(R)),'evidence_file_sha256':sha(ef.read_bytes()),'evidence_records':er,'missing_source_ids':sorted(source_ids-{r['id'] for r in er})})
for name in ['report-source.md','implementation-iteration-record.json','iteration-record.json','routing-regression-proposal.jsonl']:
 f=D/name;paths.add(f);(O/'source-documents'/name).write_bytes(f.read_bytes())
sys.path.insert(0,str(A.parent/'scripts'));import prompt_generator as pg
reg=pg.load_visual_obligation_registry(A/'photo_prompt_visual_obligations.json');idx=pg.load_visual_profile_index(A/'photo_prompt_visual_profile_index.json',reg)
profiles=[p for p in reg['profiles'] if p['id'] in PIDS];assert len(profiles)==8
save('compiled-profiles.json',[{'id':p['id'],'canonical_sha256':canon(p),'profile':p} for p in profiles])
save('profile-index-record-hashes.json',[{'pointer':'/entries/'+p,'id':p,'canonical_sha256':canon(idx['entries'][p])} for p in PIDS])
comparison=[];ob={x['id']:x['record'] for x in original}
for r in records:
 p=r['record'];q=ob[r['id']]
 if r['kind']=='profile':
  comparison.append({'id':p['id'],'original_components':q['components'],'current_components':[x['any_terms'][0] for x in p['semantics']['component_semantics']['groups']],'components_identical':q['components']==[x['any_terms'][0] for x in p['semantics']['component_semantics']['groups']],'exact_terms_identical':q['exact_terms']==p['activation']['exact_terms'],'reject_substitutes_identical':q['reject_substitutes']==p['reject_substitutes'],'original_render_gates':q['render_gates'],'current_render_gates':p['render_gates']})
 else:comparison.append({'id':p['id'],'original_record':q,'current_record':p,'identical_keys':[k for k in q if q[k]==p.get(k)],'different_keys':[k for k in q if q[k]!=p.get(k)]})
save('source-current-comparison.json',comparison)
for n in ['photo_prompt_visual_obligations.json','photo_prompt_visual_profile_index.json','photo_prompt_semantic_index.json','photo_prompt_quality_layers.json']:paths.add(A/n)
scripts=sorted((A.parent/'scripts').glob('*.py'));runtime=[{'path':str(f.relative_to(R)),'sha256':sha(f.read_bytes()),'identical_to_f4094afc':f.read_bytes()==subprocess.check_output(['git','show','f4094afc:'+str(f.relative_to(R))],cwd=R)} for f in scripts];assert all(r['identical_to_f4094afc'] for r in runtime)
save('runtime-manifest.json',{'runtime_baseline':'f4094afc','script_file_count':len(runtime),'files':runtime,'compiled_registry_sha256':canon(reg),'registry_index_binding_sha256':pg.visual_profile_registry_sha256(reg),'actual_index_sha256':sha((A/'photo_prompt_visual_profile_index.json').read_bytes())})
save('source-manifest.json',{'head':git('rev-parse','HEAD'),'status_before':git('status','--short'),'scope':'19 complete current DATA records: 8 hard carrier/process profiles and 11 optional candidate rows; no prior wear/damage overlap. No source/index/runtime/test changes, APIs, installs, publication or image generation.','hash_convention':'File bytes SHA-256. Record compact sorted-key UTF-8 JSON ensure_ascii=False SHA-256.','actual_bound_visual_index_loaded':True,'loaded_registry_profile_count_not_coverage':len(reg['profiles']),'files':[{'path':str(f.relative_to(R)),'sha256':sha(f.read_bytes())} for f in sorted(paths)],'prior_reports_read':[{'path':'wear-damage-audit/REPORT.md','sha256':sha((O.parent/'wear-damage-audit/REPORT.md').read_bytes())}],'excluded_prior_record_ids':[r['id'] for r in prior]})
print(json.dumps({'records':len(records),'profiles':len(profiles),'original_records':len(original),'source_ledger_rows':len(er),'runtime_files_equal_f4094afc':len(runtime),'bound_index_loaded':True}))
