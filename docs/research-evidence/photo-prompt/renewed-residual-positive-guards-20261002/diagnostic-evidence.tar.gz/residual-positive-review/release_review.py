import sys,json,pathlib,copy,hashlib,subprocess,re
D=pathlib.Path(__file__).parent
R=D.parents[1]/'image-prompt'
A=D.parent/'positive-alternative-guard-audit'
sys.path.insert(0,str(R/'skills/photo-prompt-image-generator/scripts'))
import prompt_generator as pg
after=pg.load_visual_obligation_registry(R/'skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations.json')
before=copy.deepcopy(after)
proposal=json.loads((D/'exact-approved-three-leaf-proposal.json').read_text())
def pointer(p,path):
 keys=re.findall(r'[^.\[\]]+',path)
 for k in keys[:-1]: p=p[int(k)] if isinstance(p,list) else p[k]
 return p,int(keys[-1]) if isinstance(p,list) else keys[-1]
for x in proposal:
 p=next(p for p in before['profiles'] if p['id']==x['profile_id']);container,key=pointer(p,x['leaf']);assert container[key]==x['new'];container[key]=x['old']
# Verify source files are EXACTLY HEAD plus the three approved leaves.
for file in set(x['file'] for x in proposal):
 head=json.loads(subprocess.check_output(['git','show','HEAD:'+file],cwd=R,text=True))
 expected=copy.deepcopy(head)
 for x in proposal:
  if x['file']!=file:continue
  p=next(p for p in expected['profiles'] if p['id']==x['profile_id']);container,key=pointer(p,x['leaf']);assert container[key]==x['old'];container[key]=x['new']
 assert expected==json.loads((R/file).read_text()),file
def diffs(a,b,path=''):
 if type(a)!=type(b):return [path]
 if isinstance(a,dict):return [q for k in a.keys()|b.keys() for q in (diffs(a.get(k),b.get(k),path+'.'+k))]
 if isinstance(a,list):
  assert len(a)==len(b)
  return [q for i,(x,y) in enumerate(zip(a,b)) for q in diffs(x,y,path+f'[{i}]')]
 return [] if a==b else [path]
changes=diffs(before,after);assert len(changes)==3,changes
indexpath='skills/photo-prompt-image-generator/assets/photo_prompt_visual_profile_index.json'
idx0=json.loads(subprocess.check_output(['git','show','HEAD:'+indexpath],cwd=R,text=True))
pg.validate_visual_profile_index_metadata(idx0,before)
idx1=pg.load_visual_profile_index(R/indexpath,after)
vector_changed=[pid for pid in idx1['entries'] if idx0['entries'][pid].get('vector')!=idx1['entries'][pid].get('vector')]
assert set(vector_changed)=={x['profile_id'] for x in proposal}
assert len(idx1['entries'])==1496

B={p['id']:p for p in before['profiles']};P={p['id']:p for p in after['profiles']}
proof=json.loads((A/'consumer-proof.json').read_text())
contexts={x['id']:x['positive_context'] for x in proof['defects']}
results=[]
def measure(pid,text,kind,reg=after,index=idx1,adult=True,exact=False):
 p=next(p for p in reg['profiles'] if p['id']==pid)
 text=(p['activation']['exact_terms'][0]+'. '+text) if exact else text
 rows=[{'source':'authorial_core_interpreted_intent','text':text,'polarity':'required'}]
 if exact:rows.insert(0,{'source':'concept_lock','text':text,'polarity':'required'})
 res=pg.resolve_visual_profile_hits(reg,rows,visual_profile_index=index,adult_context=adult,query_fields={'interpreted_intent':text})
 hit=next((h for h in res['hits'] if h['profile_id']==pid),None)
 app=pg.visual_profile_context_applicability(p,text,has_authorial_core_context=True,require_positive_context_terms=False)
 component=pg.candidate_pack_visual_component_match(p,text)
 groups=p['semantics']['component_semantics']['groups']
 matched=[g['id'] for g in groups if any(pg.intent_alias_matches(text,t) for t in g['any_terms'])]
 row={'profile_id':pid,'kind':kind,'text':text,'adult_context':adult,'component_match':component,'matched_group_ids':matched,'applicability':list(app),'target_resolver_hit':hit}
 results.append(row);return row
for x in proposal:
 pid=x['profile_id'];p=P[pid];new=contexts[pid].replace(x['old'],x['new']);old=contexts[pid]
 for exact in [False,True]:
  baseline=measure(pid,old,'old_positive_'+('exact' if exact else 'semantic'),before,idx0,exact=exact)
  assert baseline['component_match'] is None and not baseline['applicability'][0]
  row=measure(pid,new,'amended_positive_'+('exact' if exact else 'semantic'),exact=exact)
  assert row['component_match']=='component_semantics' and row['applicability'][0]
  assert row['target_resolver_hit'] and row['target_resolver_hit']['hard_eligible']==exact
  assert exact or row['target_resolver_hit']['optional_eligible']
 # Every activation/context exclusion appended to the full otherwise-positive request.
 for path,guards in [('activation',p['activation'].get('exclude_if_any_terms',[])),('context',p['activation'].get('context_disambiguation',{}).get('exclude_if_any_terms',[]))]:
  for guard in guards:
   for exact in [False,True]:
    row=measure(pid,new+'. '+guard,path+'_guard_'+('exact' if exact else 'semantic'),exact=exact)
    assert not row['applicability'][0]
    assert not row['target_resolver_hit'] or not (row['target_resolver_hit']['hard_eligible'] or row['target_resolver_hit']['optional_eligible'])
    if path=='activation':assert row['component_match'] is None
 # Old user-authored negated confounds remain explicitly unresolved.
 row=measure(pid,old,'user_negated_confound_unchanged',exact=True)
 assert not row['applicability'][0] and not row['target_resolver_hit']['hard_eligible']
 # Required-group omissions use component bundles, not exact label or full paraphrase shortcut.
 groups=p['semantics']['component_semantics']['groups']
 base=[g['any_terms'][0] for g in groups]
 if pid=='human_ghost_identity_breach':base[3]=x['new']
 if pid=='west_african_grand_boubou_volume_system':base[4]=x['new']
 for i,g in enumerate(groups):
  if g['id'] not in p['semantics']['component_semantics']['required_group_ids']:continue
  row=measure(pid,'; '.join(t for j,t in enumerate(base) if j!=i),'missing_required_'+g['id'])
  assert row['component_match'] is None
  assert not row['target_resolver_hit'] or not row['target_resolver_hit']['optional_eligible']
 if pid!='material_replacement_deferral_repair_cycle':
  row=measure(pid,x['new'],'replacement_leaf_alone')
  assert row['component_match'] is None
 else:
  row=measure(pid,new,'adult_gate_exact',adult=False,exact=True)
  assert row['target_resolver_hit']['applicability_status']=='requires_existing_adult_context'
  assert not row['target_resolver_hit']['hard_eligible'] and not row['target_resolver_hit']['optional_eligible']
  # Original proposal compared in a separate copy, without changing approved experiment.
  original=copy.deepcopy(after);q=next(q for q in original['profiles'] if q['id']==pid)
  q['semantics']['paraphrase_examples'][0]=json.loads((A/'exact-three-leaf-proposal.json').read_text())[-1]['new']
  row=measure(pid,q['semantics']['paraphrase_examples'][0],'original_proposal_paraphrase_fallback',reg=original,index=pg.build_visual_profile_index_payload(original))
  assert row['component_match']=='semantic_paraphrase_example' and len(row['matched_group_ids'])==4
source_snapshot={pid:B[pid] for pid in contexts}

report={'all_pass':True,'checks':len(results),'profile_count':len(before['profiles']),'review_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'changed_paths':changes,'actual_refreshed_index_valid':True,'vector_changed_ids':vector_changed,'unchanged_vector_count':1496-len(vector_changed),'notes':['Full registry and actual metadata-validated refreshed index; lexical BM25F query lane only, no query vectors or provider calls','Exact guard/context negatives append each guard to a full otherwise-positive bundle','Context exclusions belong to shared resolver applicability; the component helper alone does not check them','Only in-memory registry amendments; repository unchanged'],'results':results}
(D/'release-measured-controls.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'all_pass':True,'checks':len(results),'profile_count':len(before['profiles']),'changes':changes}))

# Same exact fixed query already routes on baseline: do not claim a routing improvement.
comparison=[]
for x in proposal:
 pid=x['profile_id'];fixed=contexts[pid].replace(x['old'],x['new'])
 for exact in [False,True]:
  old=measure(pid,fixed,'identical_fixed_query_before',before,idx0,exact=exact)
  new=measure(pid,fixed,'identical_fixed_query_after',after,idx1,exact=exact)
  keys=['hard_eligible','optional_eligible','match_basis','applicability_status']
  assert old['component_match']==new['component_match']=='component_semantics'
  assert all(old['target_resolver_hit'][k]==new['target_resolver_hit'][k] for k in keys)
  comparison.append({'profile_id':pid,'exact_request':exact,'before':old,'after':new})
(D/'release-identical-query-controls.json').write_text(json.dumps({'all_pass':True,'pairs':len(comparison),'claim':'Source wording consistency only; fixed queries already routed before','results':comparison},ensure_ascii=False,indent=2)+'\n')
print('PASS six identical-query baseline/current pairs; no routing-improvement claim')
