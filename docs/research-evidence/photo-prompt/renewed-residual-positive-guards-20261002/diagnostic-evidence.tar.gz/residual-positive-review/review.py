import sys,json,pathlib,copy,hashlib,subprocess,re
D=pathlib.Path(__file__).parent
R=D.parents[1]/'image-prompt'
A=D.parent/'positive-alternative-guard-audit'
sys.path.insert(0,str(R/'skills/photo-prompt-image-generator/scripts'))
import prompt_generator as pg
before=pg.load_visual_obligation_registry(R/'skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations.json')
after=copy.deepcopy(before)
proposal=json.loads((A/'exact-three-leaf-proposal.json').read_text())
proposal[-1]['new']=proposal[-1]['new'].replace('continued functional maintenance of the essential item','continued maintenance of the essential item')
def pointer(p,path):
 keys=re.findall(r'[^.\[\]]+',path)
 for k in keys[:-1]: p=p[int(k)] if isinstance(p,list) else p[k]
 return p,int(keys[-1]) if isinstance(p,list) else keys[-1]
for x in proposal:
 p=next(p for p in after['profiles'] if p['id']==x['profile_id']);container,key=pointer(p,x['leaf']);assert container[key]==x['old'];container[key]=x['new']
 f=R/x['file'];x['review_source_sha256']=hashlib.sha256(f.read_bytes()).hexdigest()
 x['review_note']='Approved as proposed' if x!=proposal[-1] else 'Amended to preserve the existing complete care_and_maintenance_evidence component phrase'
(D/'exact-approved-three-leaf-proposal.json').write_text(json.dumps(proposal,indent=2,ensure_ascii=False)+'\n')
def diffs(a,b,path=''):
 if type(a)!=type(b):return [path]
 if isinstance(a,dict):return [q for k in a.keys()|b.keys() for q in (diffs(a.get(k),b.get(k),path+'.'+k))]
 if isinstance(a,list):
  assert len(a)==len(b)
  return [q for i,(x,y) in enumerate(zip(a,b)) for q in diffs(x,y,path+f'[{i}]')]
 return [] if a==b else [path]
changes=diffs(before,after);assert len(changes)==3,changes
idx0=pg.build_visual_profile_index_payload(before);idx1=pg.build_visual_profile_index_payload(after)
B={p['id']:p for p in before['profiles']};P={p['id']:p for p in after['profiles']}
proof=json.loads((A/'consumer-proof.json').read_text())
contexts={x['id']:x['positive_context'] for x in proof['defects']}
results=[]
def measure(pid,text,kind,reg=after,index=idx1,adult=True,exact=False):
 p=next(p for p in reg['profiles'] if p['id']==pid)
 text=(p['activation']['exact_terms'][0]+'. '+text) if exact else text
 rows=[{'source':'authorial_core_interpreted_intent','text':text,'polarity':'required'}]
 if exact:rows.insert(0,{'source':'concept_lock','text':text,'polarity':'required'})
 res=pg.resolve_visual_profile_hits(reg,rows,visual_profile_index=index,adult_context=adult,query_fields={'interpreted_intent':text})
 hit=next((h for h in res['hits'] if h['profile_id']==pid),None)
 app=pg.visual_profile_context_applicability(p,text,has_authorial_core_context=True,require_positive_context_terms=False)
 component=pg.candidate_pack_visual_component_match(p,text)
 groups=p['semantics']['component_semantics']['groups']
 matched=[g['id'] for g in groups if any(pg.intent_alias_matches(text,t) for t in g['any_terms'])]
 row={'profile_id':pid,'kind':kind,'text':text,'adult_context':adult,'component_match':component,'matched_group_ids':matched,'applicability':list(app),'target_resolver_hit':hit}
 results.append(row);return row
for x in proposal:
 pid=x['profile_id'];p=P[pid];new=contexts[pid].replace(x['old'],x['new']);old=contexts[pid]
 for exact in [False,True]:
  baseline=measure(pid,old,'old_positive_'+('exact' if exact else 'semantic'),before,idx0,exact=exact)
  assert baseline['component_match'] is None and not baseline['applicability'][0]
  row=measure(pid,new,'amended_positive_'+('exact' if exact else 'semantic'),exact=exact)
  assert row['component_match']=='component_semantics' and row['applicability'][0]
  assert row['target_resolver_hit'] and row['target_resolver_hit']['hard_eligible']==exact
  assert exact or row['target_resolver_hit']['optional_eligible']
 # Every activation/context exclusion appended to the full otherwise-positive request.
 for path,guards in [('activation',p['activation'].get('exclude_if_any_terms',[])),('context',p['activation'].get('context_disambiguation',{}).get('exclude_if_any_terms',[]))]:
  for guard in guards:
   for exact in [False,True]:
    row=measure(pid,new+'. '+guard,path+'_guard_'+('exact' if exact else 'semantic'),exact=exact)
    assert not row['applicability'][0]
    assert not row['target_resolver_hit'] or not (row['target_resolver_hit']['hard_eligible'] or row['target_resolver_hit']['optional_eligible'])
    if path=='activation':assert row['component_match'] is None
 # Old user-authored negated confounds remain explicitly unresolved.
 row=measure(pid,old,'user_negated_confound_unchanged',exact=True)
 assert not row['applicability'][0] and not row['target_resolver_hit']['hard_eligible']
 # Required-group omissions use component bundles, not exact label or full paraphrase shortcut.
 groups=p['semantics']['component_semantics']['groups']
 base=[g['any_terms'][0] for g in groups]
 if pid=='human_ghost_identity_breach':base[3]=x['new']
 if pid=='west_african_grand_boubou_volume_system':base[4]=x['new']
 for i,g in enumerate(groups):
  if g['id'] not in p['semantics']['component_semantics']['required_group_ids']:continue
  row=measure(pid,'; '.join(t for j,t in enumerate(base) if j!=i),'missing_required_'+g['id'])
  assert row['component_match'] is None
  assert not row['target_resolver_hit'] or not row['target_resolver_hit']['optional_eligible']
 if pid!='material_replacement_deferral_repair_cycle':
  row=measure(pid,x['new'],'replacement_leaf_alone')
  assert row['component_match'] is None
 else:
  row=measure(pid,new,'adult_gate_exact',adult=False,exact=True)
  assert row['target_resolver_hit']['applicability_status']=='requires_existing_adult_context'
  assert not row['target_resolver_hit']['hard_eligible'] and not row['target_resolver_hit']['optional_eligible']
  # Original proposal compared in a separate copy, without changing approved experiment.
  original=copy.deepcopy(after);q=next(q for q in original['profiles'] if q['id']==pid)
  q['semantics']['paraphrase_examples'][0]=json.loads((A/'exact-three-leaf-proposal.json').read_text())[-1]['new']
  row=measure(pid,q['semantics']['paraphrase_examples'][0],'original_proposal_paraphrase_fallback',reg=original,index=pg.build_visual_profile_index_payload(original))
  assert row['component_match']=='semantic_paraphrase_example' and len(row['matched_group_ids'])==4
source_snapshot={pid:B[pid] for pid in contexts}
(D/'current-full-profiles.json').write_text(json.dumps(source_snapshot,ensure_ascii=False,indent=2)+'\n')
report={'all_pass':True,'checks':len(results),'profile_count':len(before['profiles']),'review_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'changed_paths':changes,'notes':['Full registry and real deterministic BM25F resolver, no external provider calls or vectors','Exact guard/context negatives append each guard to a full otherwise-positive bundle','Context exclusions belong to shared resolver applicability; the component helper alone does not check them','Only in-memory registry amendments; repository unchanged'],'results':results}
(D/'measured-controls.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'all_pass':True,'checks':len(results),'profile_count':len(before['profiles']),'changes':changes}))
