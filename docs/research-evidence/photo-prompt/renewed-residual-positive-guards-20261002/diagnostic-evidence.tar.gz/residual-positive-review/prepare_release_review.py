from pathlib import Path
D=Path(__file__).parent
s=(D/'review.py').read_text()
a=s.index('before=pg.load_visual');b=s.index('def diffs(')
s=s[:a]+'''after=pg.load_visual_obligation_registry(R/'skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations.json')
before=copy.deepcopy(after)
proposal=json.loads((D/'exact-approved-three-leaf-proposal.json').read_text())
def pointer(p,path):
 keys=re.findall(r'[^.\\[\\]]+',path)
 for k in keys[:-1]: p=p[int(k)] if isinstance(p,list) else p[k]
 return p,int(keys[-1]) if isinstance(p,list) else keys[-1]
for x in proposal:
 p=next(p for p in before['profiles'] if p['id']==x['profile_id']);container,key=pointer(p,x['leaf']);assert container[key]==x['new'];container[key]=x['old']
# Verify source files are EXACTLY HEAD plus the three approved leaves.
for file in set(x['file'] for x in proposal):
 head=json.loads(subprocess.check_output(['git','show','HEAD:'+file],cwd=R,text=True))
 expected=copy.deepcopy(head)
 for x in proposal:
  if x['file']!=file:continue
  p=next(p for p in expected['profiles'] if p['id']==x['profile_id']);container,key=pointer(p,x['leaf']);assert container[key]==x['old'];container[key]=x['new']
 assert expected==json.loads((R/file).read_text()),file
''' +s[b:]
s=s.replace('idx0=pg.build_visual_profile_index_payload(before);idx1=pg.build_visual_profile_index_payload(after)', '''indexpath='skills/photo-prompt-image-generator/assets/photo_prompt_visual_profile_index.json'
idx0=json.loads(subprocess.check_output(['git','show','HEAD:'+indexpath],cwd=R,text=True))
pg.validate_visual_profile_index_metadata(idx0,before)
idx1=pg.load_visual_profile_index(R/indexpath,after)
vector_changed=[pid for pid in idx1['entries'] if idx0['entries'][pid].get('vector')!=idx1['entries'][pid].get('vector')]
assert set(vector_changed)=={x['profile_id'] for x in proposal}
assert len(idx1['entries'])==1496
''')
s=s.replace("(D/'current-full-profiles.json').write_text(json.dumps(source_snapshot,ensure_ascii=False,indent=2)+'\\n')",'')
s=s.replace("'changed_paths':changes", "'changed_paths':changes,'actual_refreshed_index_valid':True,'vector_changed_ids':vector_changed,'unchanged_vector_count':1496-len(vector_changed)")
s=s.replace("'Full registry and real deterministic BM25F resolver, no external provider calls or vectors'", "'Full registry and actual metadata-validated refreshed index; lexical BM25F query lane only, no query vectors or provider calls'")
s=s.replace("(D/'measured-controls.json')", "(D/'release-measured-controls.json')")
s += '''
# Same exact fixed query already routes on baseline: do not claim a routing improvement.
comparison=[]
for x in proposal:
 pid=x['profile_id'];fixed=contexts[pid].replace(x['old'],x['new'])
 for exact in [False,True]:
  old=measure(pid,fixed,'identical_fixed_query_before',before,idx0,exact=exact)
  new=measure(pid,fixed,'identical_fixed_query_after',after,idx1,exact=exact)
  keys=['hard_eligible','optional_eligible','match_basis','applicability_status']
  assert old['component_match']==new['component_match']=='component_semantics'
  assert all(old['target_resolver_hit'][k]==new['target_resolver_hit'][k] for k in keys)
  comparison.append({'profile_id':pid,'exact_request':exact,'before':old,'after':new})
(D/'release-identical-query-controls.json').write_text(json.dumps({'all_pass':True,'pairs':len(comparison),'claim':'Source wording consistency only; fixed queries already routed before','results':comparison},ensure_ascii=False,indent=2)+'\\n')
print('PASS six identical-query baseline/current pairs; no routing-improvement claim')
'''
(D/'release_review.py').write_text(s)
