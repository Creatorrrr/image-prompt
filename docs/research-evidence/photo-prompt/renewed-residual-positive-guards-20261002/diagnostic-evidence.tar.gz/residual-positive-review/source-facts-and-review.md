# Independent residual positive-leaf review

Measured result: all 115 controls passed against the full current 1,496-profile registry. Exactly three leaf differences were asserted.

Decision: approve the ghost and boubou replacements exactly as proposed; approve the repair paraphrase with one local amendment. No repository files were edited by this review.

## Exact approved proposal

See `exact-approved-three-leaf-proposal.json` for original/new values, source paths, original proposal hashes and current reviewed-source hashes. The source hash of the main asset may differ because the separately pending leading-line descriptions are already in the worktree. Original target leaf values were asserted against the actual current full registry before amendment.

1. Ghost: `장면 기하가 일관되게 유지되고 생전 인물과 연결된 불가능한 현현 및 국소 결과가 함께 읽힘`
2. Boubou: `the selected regional boubou form retains its own cut layering and ornament`
3. Repair paraphrase: replace only `continued maintenance rather than neglect or decorative distressing` with `continued maintenance of the essential item` in the existing full paraphrase. The original proposal inserted `functional` between `continued` and `maintenance`; the amendment deliberately preserves the complete existing care component's contiguous positive phrase.

## Meaning and source facts

### Ghost

- Current full definition: a disembodied presence continuous with a formerly living person, identified through a former-identity anchor and coherent impossible presence or agency. The positive replacement means consistent scene geometry, a formerly living identity-linked impossible manifestation, and localized consequence readable together.
- This asserts neither solid anatomy nor decay, and does not prescribe a new mechanism. An apparent physical consequence is already an allowed profile relation and does not imply a corporeal body.
- `semantics.component_semantics` still has three mandatory groups: former identity, ontological breach, and localized agency/consequence. Capture-confound control is an additional group, not a new required fourth relation. The unchanged render gates and reject substitutes continue to prohibit blur/fog/holography alone and solid corporeal revenants.
- Repository provenance: `docs/research-evidence/photo-prompt/imaginal-visual-semantics-20260901/source-research.md`, line 40 explicitly routes apparition/phantom/specter/ghost to the existing prior-identity + existence-breach + localized-result contract; lines 15–19 identify the separate coherent-rule, anchor and capture-confound dimensions; line 174 again requires comparison with the existing identity-linked ghost contract. The similarly named humanlike-entities research file is not the ghost source and was not used as evidence for this proposal.

### Grand boubou

- Current definition allows regional and gendered variation and already requires the selected expansive outer garment, broad sleeve apertures, focused ornament and coordinated inner layer in this narrow runtime profile.
- “The selected regional ... form” is a bounded depicted garment, not a universal taxonomy. “Its own cut layering and ornament” carries the existing regional-form coherence boundary. It neither declares all boubous identical nor defines all relationships to agbada, dashiki or caftan. Their existing named guards remain exact and unchanged.
- Four required groups remain exactly four: expansive body, broad sleeve openings, neck/center focus, coordinated inner layer. Variation boundary remains additional. The positive regional phrase alone does not provide those four groups.
- Repository provenance: `docs/research-evidence/photo-prompt/traditional-clothing-20260831/source-research.md`, line 42 records this specific construction and confusion boundary, citing British Museum object https://www.britishmuseum.org/collection/object/E_Af1934-0307-206 . Lines 7–15 separate topology, wearing/layering mechanism, qualified regional/form context, and textile construction; lines 68–81 separate depicted garment facts from wearer-identity inference and limit exact profiles to connected construction. The source link is recorded provenance, not a new live verification claim.

### Essential-item repair/replacement deferral

- Current definition requires an essential item with localized functional wear, replacement unavailable, active repair, continuing care, and return to use. It explicitly rejects appearance or broad poverty labels as proof.
- The amended full paraphrase retains all five observable relations and the unmistakably adult actor, and it now also preserves all five literal component matches. No inference about income, class, health or poverty is introduced. Claim limits and all evidence floors remain untouched.
- Repository provenance: `docs/research-evidence/photo-prompt/poverty-visual-semantics-20260907/report-source.md`, section 1 requires observable need → resource/access constraint → same adult action → immediate result and says isolated worn clothing is insufficient; section 2 excludes inferring actual people's income, health or housing state from images; section 3.5, lines 119–124, differentiates inability to afford replacement from elective thrift/hobby/vintage fashion and explicitly requires replacement need → resource constraint → localized repair → continued use.
- Existing concept terms, authored instruction, render description and composition instruction still include their original contrast wording, as this task permits only three semantic-positive leaves. This review does not claim to repair all downstream textual consumers.

## Runtime checks and limits

`review.py` imports the actual current production consumers, loads every profile and builds genuine deterministic lexical indexes in memory. `measured-controls.json` records complete text, component match, matched group IDs, shared context applicability and full-registry target resolver hits. No synthetic vectors, embedding/provider calls, image calls, threshold edits or runtime-code edits occur.

Controls distinguish lexical-only semantic discovery from explicitly requested exact-label behavior. The exact-label tests include an authorial-core context row so context-disambiguation exclusions are actually active. That is their production activation condition; the helper by itself only enforces activation exclusions, not context-disambiguation exclusions. Component and resolver results are recorded separately rather than overstating the helper's guards.

Positive tests compare old self-rejecting text with the fixed source text. Counterexamples append every activation and contextual exclusion to a full otherwise-valid positive description, in both lexical-only and exact-request lanes. Missing-required-group tests verify unchanged conjunctions without adding an exact label or a full-paraphrase shortcut. New optional ghost/boubou leaf phrases alone are insufficient. Repair's adult gate is tested separately.

The old user-authored negated-confound wording is a deliberately separate unresolved category: literal guards still reject it. This is a source-positive wording correction, not a general negation fix. These measurements establish deterministic consumer behavior, not provider retrieval parity, image quality, pixel qualification or release adoption. Final integration still requires its normal real refreshed index.
