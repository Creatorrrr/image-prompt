# Independent applied-source and refreshed-index review

Result: 115/115 replay controls and all six identical-query before/after pairs passed; the three current regression tests passed.

Scope: source-wording consistency. The fixed positive queries already routed under the preceding source/index state; replacing the source's own self-excluding examples does not establish identical-query routing improvement.

The original proposal review and `measured-controls.json` are preserved unchanged. New evidence uses `release-` filenames.

## Verified boundaries

- Baseline commit: 99ebda65 (leading-path render-gate change already committed).
- Both source JSON files equal baseline plus exactly the three approved leaf replacements. The full structural equality assertion also proves that all activation/context guards, other alternatives, required-group lists, thresholds, adult constraints, definitions, claim limits and render gates are unchanged.
- Before probes reconstruct the prior registry by reverting only those three leaves in memory, and use the actual HEAD index. After probes use the current registry and actual refreshed index. Both indexes pass the production metadata validation.
- Exactly three stored profile vectors differ, precisely the three amended profiles. The other 1,493 stored vectors compare equal. This is an artifact comparison, not a claim about provider execution provenance.
- The resolver tests exercise genuine BM25F against the actual stored refreshed index, with no query vectors supplied. This does not claim to measure embedding ranking. The diagnostic comparison to the rejected original repair wording remains an explicitly in-memory lexical-only profile experiment.
- Exact request tests include authorial-core context. Contextual guards are conditional on that production context and are not misrepresented as standalone component-helper exclusions.
- Old self-excluding wording and user-authored negated confounds remain separate negative controls.

## Evidence files

- `release-measured-controls.json`: replay of the original 115 controls using actual baseline/refreshed index artifacts, except the explicitly labeled in-memory original-proposal diagnostic
- `release-identical-query-controls.json`: six identical-fixed-query before/after pairs, three profiles in exact and lexical-semantic lanes
- `release-regression.log`: independent run of the three tests in the current `test_photo_residual_positive_guards.py`
- `release_review.py`, `release-run.log`: reproducible execution and result

No source edits, provider/API calls, synthetic vectors, public CLI execution, composition run or pixel review were performed by this independent review. No public CLI/composition/pixel proof is claimed.
