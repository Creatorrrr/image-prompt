import sys,json,pathlib,re,copy
R=pathlib.Path('REPOSITORY_ROOT');sys.path.insert(0,str(R/'skills/photo-prompt-image-generator/scripts'))
import prompt_generator as pg
reg=pg.load_visual_obligation_registry(R/'skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations.json')
hits=[];count=0
for p in reg['profiles']:
 a=p.get('activation',{}); exclusions=[('activation.exclude_if_any_terms',v) for v in a.get('exclude_if_any_terms',[])]+[('activation.context_disambiguation.exclude_if_any_terms',v) for v in a.get('context_disambiguation',{}).get('exclude_if_any_terms',[])]
 groups=p.get('semantics',{}).get('component_semantics',{}).get('groups',[])
 base=[next((t for t in g['any_terms'] if not re.search('[가-힣]',t)),g['any_terms'][0]) for g in groups]
 variants=[]
 for i,g in enumerate(groups):
  for j,t in enumerate(g['any_terms']):
   count+=1
   if any(pg.intent_alias_matches(t,e) for _,e in exclusions):
    terms=base.copy();terms[i]=t;variants.append((f'semantics.component_semantics.groups[{i}].any_terms[{j}]',t,'; '.join(terms)))
 for j,t in enumerate(p.get('semantics',{}).get('paraphrase_examples',[])):
  count+=1
  if any(pg.intent_alias_matches(t,e) for _,e in exclusions):variants.append((f'semantics.paraphrase_examples[{j}]',t,t))
 for leaf,t,context in variants:
  matched=[{'leaf':l,'term':e} for l,e in exclusions if pg.intent_alias_matches(context,e)]
  hits.append({'id':p['id'],'leaf':leaf,'text':t,'context':context,'matched_exclusions':matched,'applicability':pg.visual_profile_context_applicability(p,context,has_authorial_core_context=True),'component_match':pg.candidate_pack_visual_component_match(p,context)})
pathlib.Path(__file__).with_name('raw-hits.json').write_text(json.dumps(hits,ensure_ascii=False,indent=2))
print('profiles',len(reg['profiles']),'leaves',count,'hits',len(hits)); print(json.dumps(hits,ensure_ascii=False,indent=2))
