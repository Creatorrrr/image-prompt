exec(open(__file__.replace('prepare_proposal.py','probe.py')).read().split('hits=[];count=0')[0])
import hashlib,subprocess
D=pathlib.Path(__file__).parent
proof=json.loads((D/'consumer-proof.json').read_text())
replacements={
'human_ghost_identity_breach':'장면 기하가 일관되게 유지되고 생전 인물과 연결된 불가능한 현현 및 국소 결과가 함께 읽힘',
'west_african_grand_boubou_volume_system':'the selected regional boubou form retains its own cut layering and ornament',
'material_replacement_deferral_repair_cycle':proof['defects'][2]['original_leaf_text'].replace('continued maintenance rather than neglect or decorative distressing','continued functional maintenance of the essential item')}
proposal=[];baseline=[];controls=[]
for d in proof['defects']:
 p=next(p for p in reg['profiles'] if p['id']==d['id']);baseline.append(p)
 proposal.append({'profile_id':p['id'],'file':d['source'][0]['file'],'source_sha256':d['source'][0]['sha256'],'profile_array_index':d['source'][0]['profile_array_index'],'leaf':d['leaf'],'old':d['original_leaf_text'],'new':replacements[p['id']]})
 controls.append({'id':p['id']+'__source_generated_positive','profile_id':p['id'],'kind':'source_generated_positive','before':d['positive_context'],'after':d['positive_context'].replace(d['original_leaf_text'],replacements[p['id']]),'expected_before_component':None,'expected_after_component_nonnull':True,'expected_after_applicability':True})
 for guard in p['activation'].get('exclude_if_any_terms',[]):
  controls.append({'id':p['id']+'__guard__'+guard,'profile_id':p['id'],'kind':'unchanged_guard_counterexample','text':p['activation']['exact_terms'][0]+'. '+guard,'expected_component':None,'expected_applicability':False,'expected_reason':'request_exclusion'})
 controls.append({'id':p['id']+'__old_positive_negation_remains_unresolved','profile_id':p['id'],'kind':'unresolved_user_authored_negation','text':d['positive_context'],'expected_applicability':False,'expected_reason':'request_exclusion'})
meta={'commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'frozen_before_proposal_evaluation':True,'controls':controls}
(D/'frozen-baseline-profiles.json').write_text(json.dumps(baseline,indent=2,ensure_ascii=False));(D/'frozen-controls.json').write_text(json.dumps(meta,indent=2,ensure_ascii=False));(D/'exact-three-leaf-proposal.json').write_text(json.dumps(proposal,indent=2,ensure_ascii=False))
print('Frozen',len(baseline),'profiles;',len(controls),'controls; proposal contains',len(proposal),'source leaves')
