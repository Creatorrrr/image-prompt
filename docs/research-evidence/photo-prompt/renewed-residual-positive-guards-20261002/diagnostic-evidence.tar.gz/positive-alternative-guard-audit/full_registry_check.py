exec(open(__file__.replace('full_registry_check.py','probe.py')).read().split('hits=[];count=0')[0])
f=pathlib.Path(__file__).with_name('consumer-proof.json');proof=json.loads(f.read_text());index=pg.build_visual_profile_index_payload(reg)
for d in proof['defects']:
 rows=[{'source':'concept_lock','text':d['public_exact_request'],'polarity':'required'}]
 res=pg.resolve_visual_profile_hits(reg,rows,visual_profile_index=index,adult_context=True)
 d['full_registry_actual_resolver']=[h for h in res['hits'] if h['profile_id']==d['id']]
 print(d['id'],d['full_registry_actual_resolver'])
f.write_text(json.dumps(proof,indent=2,ensure_ascii=False))
