import sys,json,pathlib,hashlib,subprocess
D=pathlib.Path(__file__).parent;R=D.parents[1]/'image-prompt';sys.path.insert(0,str(R/'skills/photo-prompt-image-generator/scripts'))
import prompt_generator as pg
assets=R/'skills/photo-prompt-image-generator/assets';reg=pg.load_visual_obligation_registry(assets/'photo_prompt_visual_obligations.json');ip=assets/pg.VISUAL_PROFILE_INDEX_FILENAME;index=pg.load_visual_profile_index(ip,reg)
before=json.loads((D/'genuine-index-before-full-resolver.json').read_text());results=[]
print('AFTER validated genuine index loaded',len(index['entries']),flush=True)
for i,c in enumerate(before['results']):
 res=pg.resolve_visual_profile_hits(reg,c['source_rows'],visual_profile_index=index,adult_context=c['adult_context'],query_fields={'interpreted_intent':c['text']})
 results.append({**c,'full_resolver_result':res})
 if (i+1)%20==0:print('resolved',i+1,flush=True)
manifest={'commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'index_sha256':hashlib.sha256(ip.read_bytes()).hexdigest(),'index_entry_count':len(index['entries']),'metadata_validation':'normal load_visual_profile_index PASS','query_embeddings_used':False,'provider_calls':0}
(D/'genuine-index-after-full-resolver.json').write_text(json.dumps({'manifest':manifest,'results':results},indent=2,ensure_ascii=False))
def target(r):return next((h for h in r['full_resolver_result']['hits'] if h['profile_id']==r['profile_id']),None)
def eligibility(h):return None if h is None else {k:h.get(k) for k in ['match_basis','applicability_status','applicability_reason','hard_eligible','optional_eligible']}
changes=[]
for a,b in zip(before['results'],results):
 assert a['text']==b['text'] and a['source_rows']==b['source_rows']
 ah=a['full_resolver_result']['hits'];bh=b['full_resolver_result']['hits'];at=target(a);bt=target(b)
 changes.append({'profile_id':a['profile_id'],'kind':a['kind'],'target_eligibility_identical':eligibility(at)==eligibility(bt),'target_before':at,'target_after':bt,'complete_hits_identical':ah==bh,'hit_ids_order_identical':[x['profile_id'] for x in ah]==[x['profile_id'] for x in bh],'complete_resolver_identical':a['full_resolver_result']==b['full_resolver_result'],'before_hit_ids':[x['profile_id'] for x in ah],'after_hit_ids':[x['profile_id'] for x in bh]})
summary={'query_count':len(changes),'target_eligibility_changes':sum(not c['target_eligibility_identical'] for c in changes),'hit_id_order_changes':sum(not c['hit_ids_order_identical'] for c in changes),'complete_hits_changes':sum(not c['complete_hits_identical'] for c in changes),'complete_resolver_changes':sum(not c['complete_resolver_identical'] for c in changes),'rows':changes}
(D/'genuine-index-identical-query-comparison.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False));print(json.dumps({k:v for k,v in summary.items() if k!='rows'}),flush=True)
