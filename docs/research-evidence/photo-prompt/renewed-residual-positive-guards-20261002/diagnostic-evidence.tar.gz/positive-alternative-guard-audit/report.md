# Positive alternative self-rejection audit

Commit: `1feea7ceb7ec55b34aaf0c521a0c56714dcfa2e7`. Read-only repository audit; no provider calls, generated vectors, or repository edits.

## Result

Three high-confidence defects, each reproduced in the full 1,496-profile production registry using `resolve_visual_profile_hits`, plus the shared applicability and component consumers. All three return `request_exclusion`, no component match, and an explicit positive canonical-name request returns `context_mismatch`, `hard_eligible=false`, `optional_eligible=false`. Exact original text, source-file SHA256, array indexes, full positive bundles, and return values are in `consumer-proof.json`.

1. `human_ghost_identity_breach`
   - Source: `skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations.json`, profiles[83], `semantics.component_semantics.groups[3].any_terms[1]`
   - Original: `장면 기하가 유지되고 단순 블러 안개 홀로그램 노출 효과가 아님`
   - Guard: `activation.exclude_if_any_terms` → `홀로그램`
   - The whole available Korean bundle expresses former-person identity, coherent impossible presence, localized agency, and maintained scene geometry. The final clause explicitly says the appearance is not a hologram. Adding this affirmative confound-control component suppresses the otherwise supported ghost. This is not a negative ghost example.

2. `west_african_grand_boubou_volume_system`
   - Same source, profiles[91], `semantics.component_semantics.groups[4].any_terms[1]`
   - Original: `boubou is not automatically agbada dashiki or caftan`
   - Guards: `activation.exclude_if_any_terms` → `agbada`, `caftan`
   - A complete four-required-component bundle establishes expansive outer body, broad sleeve apertures, neckline/center embroidery, and coordinated inner layer. Adding its own second variation-boundary alternative removes eligibility. The boundary preserves naming distinctions; it does not depict the excluded garment. Keep those distinctions and their exclusions.

3. `material_replacement_deferral_repair_cycle`
   - Source: `skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations_poverty.json`, profiles[7], `semantics.paraphrase_examples[0]`
   - Original: “A same-frame photographic relation connects one essential daily-use item has localized functional wear while its broader structure remains cared for, the worn item remains the only serviceable example and a new replacement is visibly unavailable in context, an unmistakably adult user performs a material-appropriate repair directly on the worn functional area, clean tools aligned patches and prior careful mends show continued maintenance rather than neglect or decorative distressing, and the repaired item visibly returns to its ordinary practical use with the new mend still readable.”
   - Guard: `activation.exclude_if_any_terms` → `decorative distressing`
   - This is the full five-relation positive paraphrase, not the separate contrast example. It describes actual repair and expressly rejects decorative distressing. The first component bundle was corrected elsewhere, but this positive paraphrase remains self-blocking. The loader enriches this source profile with component semantics; the production loaded profile was used in all consumer probes.

## Cause and repair boundary

Both applicability and component consumers check literal aliases in exclusion lists before positive evidence. Negated confounds inside positive descriptions therefore cause rejection. In-memory removal of only each conflicting exclusion restores component_semantics and exact required eligibility for every demonstrated text. That is a causal diagnostic, not a recommended guard removal. A narrow positive-source-leaf rewording is safer than broadening these profiles, deleting exclusions, translating bundles, or changing runtime negation behavior. Preserve provenance and test excluded real confounds after any proposed edit. No repair was made here.

## Coverage and limits

- Loaded all 1,496 profiles; scanned 9,989 component-alternative and paraphrase leaves against their own activation and context-disambiguation exclusions with the production alias matcher
- For colliding alternatives, assembled complete positive bundles; explicitly verified the complete available Korean ghost bundle
- Five raw lexical overlaps exist in `raw-hits.json`; only the three fully established cases above are surfaced as findings
- Did not count standalone contrast_examples, missing lexical matches, or absent translations as defects
- Full registry resolver checks use its genuine locally built lexical index; no synthetic vectors, provider access, retrieval ranking claims, final prompt-adoption claims, or image-quality claims

Reproduce from the task workspace:

    python daylong-progress-20261002/positive-alternative-guard-audit/probe.py
    python daylong-progress-20261002/positive-alternative-guard-audit/verify.py
    python daylong-progress-20261002/positive-alternative-guard-audit/full_registry_check.py
