exec(open(__file__.replace('check_proposal.py','probe.py')).read().split('hits=[];count=0')[0])
D=pathlib.Path(__file__).parent;before={p['id']:p for p in json.loads((D/'frozen-baseline-profiles.json').read_text())};after=copy.deepcopy(before)
proposal=json.loads((D/'exact-three-leaf-proposal.json').read_text())
for x in proposal:
 p=after[x['profile_id']]
 if x['profile_id']=='human_ghost_identity_breach':p['semantics']['component_semantics']['groups'][3]['any_terms'][1]=x['new']
 elif x['profile_id']=='west_african_grand_boubou_volume_system':p['semantics']['component_semantics']['groups'][4]['any_terms'][1]=x['new']
 else:p['semantics']['paraphrase_examples'][0]=x['new']
results=[]
for c in json.loads((D/'frozen-controls.json').read_text())['controls']:
 p=after[c['profile_id']];t=c.get('after',c.get('text'));match=pg.candidate_pack_visual_component_match(p,t);app=pg.visual_profile_context_applicability(p,t,has_authorial_core_context=True,require_positive_context_terms=False)
 ok=(match is not None and app[0]) if c['kind']=='source_generated_positive' else (app== (False,'request_exclusion'))
 if c['kind']=='unchanged_guard_counterexample':ok=ok and match is None
 results.append({'id':c['id'],'component':match,'applicability':app,'pass':ok})
assert all(x['pass'] for x in results),results
assert all(before[k]['activation']==after[k]['activation'] for k in before)
(D/'proposal-control-results.json').write_text(json.dumps({'all_pass':True,'count':len(results),'guards_unchanged':True,'note':'In-memory exact-three-leaf experiment only; no source writes.','results':results},indent=2,ensure_ascii=False));print('PASS',len(results),'controls; activation guards identical')
