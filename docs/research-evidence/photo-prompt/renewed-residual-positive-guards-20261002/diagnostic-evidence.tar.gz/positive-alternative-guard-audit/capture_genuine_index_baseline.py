import sys,json,pathlib,hashlib,subprocess,time
D=pathlib.Path(__file__).parent;R=D.parents[1]/'image-prompt';sys.path.insert(0,str(R/'skills/photo-prompt-image-generator/scripts'))
import prompt_generator as pg
assets=R/'skills/photo-prompt-image-generator/assets';reg=pg.load_visual_obligation_registry(assets/'photo_prompt_visual_obligations.json');ip=assets/pg.VISUAL_PROFILE_INDEX_FILENAME;index=pg.load_visual_profile_index(ip,reg)
controls=json.loads((D.parent/'residual-positive-review/measured-controls.json').read_text())['results']
proposal=json.loads((D.parent/'residual-positive-review/exact-approved-three-leaf-proposal.json').read_text())
manifest={'commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'profile_count':len(reg['profiles']),'index_entry_count':len(index['entries']),'index_sha256':hashlib.sha256(ip.read_bytes()).hexdigest(),'metadata_validation':'load_visual_profile_index(ip,reg), default genuine provider/model/dimensions; PASS','query_embeddings_used':False,'approved_proposal_sha256':hashlib.sha256((D.parent/'residual-positive-review/exact-approved-three-leaf-proposal.json').read_bytes()).hexdigest(),'query_comparison':'These exact 115 query texts are frozen and must be replayed identically after application; source-derived old/new pairs are separately labeled, not identical-query improvements.','controls':controls}
(D/'genuine-index-frozen-query-baseline.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False));print('BASELINE CAPTURED: source and validated genuine index loaded into process memory; frozen115query file saved; safe for parent to apply source.',flush=True)
results=[]
for i,c in enumerate(controls):
 text=c['text'];kind=c['kind'];exact=kind.endswith('_exact') or kind=='user_negated_confound_unchanged'
 rows=[{'source':'authorial_core_interpreted_intent','text':text,'polarity':'required'}]
 if exact:rows.insert(0,{'source':'concept_lock','text':text,'polarity':'required'})
 res=pg.resolve_visual_profile_hits(reg,rows,visual_profile_index=index,adult_context=c['adult_context'],query_fields={'interpreted_intent':text})
 results.append({'profile_id':c['profile_id'],'kind':kind,'text':text,'source_rows':rows,'adult_context':c['adult_context'],'full_resolver_result':res})
 if (i+1)%20==0:print('resolved',i+1,flush=True)
(D/'genuine-index-before-full-resolver.json').write_text(json.dumps({'manifest':{k:v for k,v in manifest.items() if k!='controls'},'results':results},indent=2,ensure_ascii=False));print('COMPLETE',len(results),flush=True)
