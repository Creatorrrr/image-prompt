# Three-leaf source-only proposal

Status: proposed, not applied. Frozen source commit 1feea7ce. Exact files, source hashes, old/new values and JSON paths are in `exact-three-leaf-proposal.json`. Baseline profiles and 31 controls were written before running `check_proposal.py`; all 31 controls passed the in-memory experiment. No repository edits or external calls.

## Exact replacements

1. human_ghost_identity_breach, semantics.component_semantics.groups[3].any_terms[1]:

장면 기하가 일관되게 유지되고 생전 인물과 연결된 불가능한 현현 및 국소 결과가 함께 읽힘

English meaning: Scene geometry stays consistent, and an impossible manifestation connected to the formerly living person and its localized consequence are readable together. This positively summarizes the existing conjunction. It asserts fictional identity continuity, not a solid body, bodily decay, or a new material mechanism. The existing definition, three mandatory groups, English alternative, Korean identity/presence/agency terms, contrasts, and all hologram/data/software exclusions remain unchanged. Avoid inserting a new exact activation alias into this replacement.

2. west_african_grand_boubou_volume_system, semantics.component_semantics.groups[4].any_terms[1]:

the selected regional boubou form retains its own cut layering and ornament

The selected regional form is the existing variation boundary; layering is already mandatory through coordinated_inner_layer. It preserves cut/layer/ornament coherence without asserting a universal relationship between regional names. Required expansive outer construction, broad sleeve apertures, embroidery focus, and coordinated inner garment remain untouched. All distinctions and guards for agbada, dashiki, kaftan/caftan, and generic costumes remain untouched. Provenance: traditional-clothing-20260831/source-research.md, Grand boubou row and runtime-scope section; source cites the British Museum object E_Af1934-0307-206. No new taxonomy claim requiring new external research was introduced.

3. material_replacement_deferral_repair_cycle, semantics.paraphrase_examples[0]:

A same-frame photographic relation connects one essential daily-use item has localized functional wear while its broader structure remains cared for, the worn item remains the only serviceable example and a new replacement is visibly unavailable in context, an unmistakably adult user performs a material-appropriate repair directly on the worn functional area, clean tools aligned patches and prior careful mends show continued functional maintenance of the essential item, and the repaired item visibly returns to its ordinary practical use with the new mend still readable.

Only replace “continued maintenance rather than neglect or decorative distressing” with “continued functional maintenance of the essential item”. Retain all five relations: localized functional wear, unavailable replacement, adult material-appropriate repair, visible ongoing care, and return to actual use. No poverty classification from wear is introduced. Adult requirement, all contrast exclusions, component thresholds, claim limits, concept terms, and source evidence stay untouched. Provenance: poverty-visual-semantics-20260907/report-source.md sections 1–2 and current profile definition/claim limits. This is a wording repair, not a change to poverty/access classification.

## Frozen checks and counterexamples

`frozen-controls.json` contains 31 controls:
- Three full source-generated positive bundles/descriptions, expected self-rejection before and eligibility after the exact source replacement
- Every current activation exclusion for these three profiles (25 counterexamples total), combined with the canonical positive profile request, expected to remain excluded
- Three original negated-confound descriptions, expected to remain excluded under unchanged runtime behavior

Examples: a ghost request depicting 홀로그램; a boubou request actually specifying agbada or caftan; an essential-item-repair request specifying decorative distressing or slow fashion hobby. Do not soften these guards merely to make the old positive texts pass.

The experiment retains the full baseline profile object and modifies only the three proposed values. Guards are exactly identical, and no group IDs, minimum counts, existing non-target alternatives, adult requirements, or numeric evidence floors change. The repair paraphrase is accepted as a semantic_paraphrase_example after replacement, whereas both component bundles remain component_semantics. Literal consumer eligibility is the measured outcome; this is not ranking, image-generation, or final-adoption evidence.

## Explicit limitation

This repairs DATA-GENERATED positive wording only. Unresolved user-authored negation handling is deliberately unchanged: a person typing the original “not hologram / not agbada or caftan / rather than decorative distressing” wording still hits existing literal guards. The frozen unresolved controls demonstrate that limitation rather than claiming a global negation fix. Do not translate other Korean phrases or alter provenance to widen this patch.
