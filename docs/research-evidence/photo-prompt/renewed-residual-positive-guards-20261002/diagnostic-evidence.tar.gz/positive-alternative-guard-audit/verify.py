exec(open(__file__.replace('verify.py','probe.py')).read().split('hits=[];count=0')[0])
import hashlib,subprocess
out=[]
ids=['human_ghost_identity_breach','west_african_grand_boubou_volume_system','material_replacement_deferral_repair_cycle']
raw=json.load(open(pathlib.Path(__file__).with_name('raw-hits.json')))
for pid in ids:
 p=next(p for p in reg['profiles'] if p['id']==pid);h=next(h for h in raw if h['id']==pid)
 ctx=h['context']
 if pid=='human_ghost_identity_breach':
  gs=p['semantics']['component_semantics']['groups'];ctx='; '.join(next(t for t in g['any_terms'] if re.search('[가-힣]',t)) for g in gs)
 diagnostic=copy.deepcopy(p);bad=[x['term'] for x in h['matched_exclusions']];diagnostic['activation']['exclude_if_any_terms']=[x for x in diagnostic['activation'].get('exclude_if_any_terms',[]) if x not in bad]
 rows=[{'source':'concept_lock','text':p['activation']['exact_terms'][0]+'. '+ctx,'polarity':'required'}]
 mini={**reg,'profiles':[p]};mini_diag={**reg,'profiles':[diagnostic]}
 def extract(r):return [{'profile_id':x['profile_id'],'hard_eligible':x['hard_eligible'],'optional_eligible':x['optional_eligible'],'status':x['applicability_status'],'reason':x.get('applicability_reason')} for x in r['hits']]
 origin=[]
 for f in (R/'skills/photo-prompt-image-generator/assets').glob('photo_prompt_visual_obligations*.json'):
  try:ps=json.loads(f.read_text()).get('profiles',[])
  except:continue
  for j,q in enumerate(ps):
   if q.get('id')==pid:origin.append({'file':str(f.relative_to(R)),'profile_array_index':j,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()})
 out.append({'id':pid,'source':origin,'leaf':h['leaf'],'original_leaf_text':h['text'],'positive_context':ctx,'blocked_by':h['matched_exclusions'],'actual_component_match':pg.candidate_pack_visual_component_match(p,ctx),'diagnostic_only_without_conflicting_guard_component_match':pg.candidate_pack_visual_component_match(diagnostic,ctx),'actual_applicability':pg.visual_profile_context_applicability(p,ctx,has_authorial_core_context=True,require_positive_context_terms=False),'public_exact_request':rows[0]['text'],'actual_resolver':extract(pg.resolve_visual_profile_hits(mini,rows,adult_context=True)),'diagnostic_only_without_conflicting_guard_resolver':extract(pg.resolve_visual_profile_hits(mini_diag,rows,adult_context=True))})
result={'commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'scope':'Real consumers; profile-restricted registries retaining production schema; no embeddings, no provider calls, no repo edits. Removing conflicting guards only in memory demonstrates cause, not a recommended repair.','defects':out}
pathlib.Path(__file__).with_name('consumer-proof.json').write_text(json.dumps(result,indent=2,ensure_ascii=False));print(json.dumps(result,indent=2,ensure_ascii=False))
