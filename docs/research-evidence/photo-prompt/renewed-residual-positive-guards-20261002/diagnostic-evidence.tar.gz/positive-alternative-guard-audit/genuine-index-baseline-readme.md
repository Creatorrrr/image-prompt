# Genuine-index pre-application baseline

Captured registry and genuine 1,496-entry on-disk index at 99ebda65, before central source application. Normal load_visual_profile_index metadata validation passed. No query embeddings or provider calls. All 115 reviewer query texts were replayed against this baseline and full resolver results were saved; earlier lexical-only diagnostics were preserved.

Files: genuine-index-frozen-query-baseline.json (exact query controls and manifest), genuine-index-before-full-resolver.json (full production resolver returns), genuine-index-before-target-summary.json (compact target hits).

Important: all three approved new positive texts ALREADY route against the old source/index (semantic BM25F optional, explicit exact required), while all three original texts fail. This is correction of source-generated positive wording, not improved routing of an identical query. Compare both old and amended query texts unchanged when running the post-application index. The changed source-generated before/after bundle comparison must be labeled separately.

All 84 activation/context guard-lane tests remain noneligible in this baseline. The three old user-authored negated-confound controls also remain rejected. These are explicit unchanged-runtime limitations, not claims that negation handling was fixed.
