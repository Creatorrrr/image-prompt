# Natural-environment residual contract audit

Baseline: `ef0ea3f6a396d06bad42b92bfe7915f71089a5a5`. Read-only repository audit; no runtime changes, paid APIs, or repository edits.

## Recommend exactly one composition leaf

Profile `cumulonimbus_tower_anvil_precipitation_outflow`, `composition_instruction`:

- Before: `Use a wide vertical frame that preserves the low dark base, full convective tower, flattened fibrous anvil, and a descending precipitation shaft in one connected cloud system.`
- Proposed: `Use a wide vertical frame that preserves the low dark base, full convective tower, flattened fibrous or striated anvil, and a descending precipitation shaft in one connected cloud system.`

The existing anvil component and `anvil_top_phrase` evidence both say `the upper cloud spreads into a flattened fibrous or striated anvil`. Gate `vo_natural_cumulonimbus_anvil` likewise permits `flattened fibrous or striated anvil`. The general composition drops the striated alternative. This is an authored-contract mismatch, not a claim that we independently validated storm physics. The original provenance record `natural_environment_wmo_cumulonimbus_structure` explicitly abstracts “fibrous or striated anvil”; its linked source is https://cloudatlas.wmo.int/en/cumulonimbus-cb.html. The source has not been independently re-fetched in this audit.

## Full-profile and selected-candidate distinction

All four component groups, minimum group count, required evidence, all five render gates, definitions, exact activation terms, label mode, forbidden terms, rejects, and seven cumulonimbus extension candidates are captured in `source-provenance.json`. Specific subject/action/composition choices intentionally require fibrous anvil and sometimes rain/outflow. They must remain unchanged. A general profile materialized without selecting those candidates should not inherit their narrower fibrous requirement. `convective_storm_structure_aesthetic.embedding_text` itself also permits fibrous or striated.

The source profile's runtime expression is `label_plus_definition`, label `mature tower-anvil cumulonimbus structure`, with empty forbidden lists. There are no authored components or profile-level conditional override fields. Production `load_visual_obligation_registry` loads extensions without replacing duplicate profile IDs, then calls `compile_visual_profile`; compilation returns this profile unchanged because `authored_components` is absent. The production materializer calls the same compiler. The probe verifies that the composition change actually survives materialization and that all other obligation fields are identical.

## Keep decisions

- Old-growth forest: composition retains all four mandatory structural elements
- Intertidal: upper/lower/middle order retained; “dry” versus “comparatively dry” is not strong enough to establish an alternative-exclusion defect
- Karst: spring outlet versus spring/cave-mouth outlet may describe the same resurgence endpoint, so no high-confidence leaf change recommended
- Alpine treeline: treeless alpine ground retains meadow/tundra/exposed-ground choices
- Cumulonimbus precipitation: existing precipitation wording can encompass the authored precipitation/virga shaft; avoid adding a second speculative edit
- Prior wetland, dune, glacier fixes were inspected only to delimit scope, not proposed again

## Reproduction and limits

Run `PYTHONDONTWRITEBYTECODE=1 python probe.py`. It uses the actual production loader, materializer, and route matcher, with a copied in-memory proposed registry. Result: one profile leaf and one materialized leaf differ; two exact and five negative routes unchanged. This is a contract/materialization proof, not evidence of image generation success or striated-only literal-evidence acceptance.

`source-guided-test-plan.json` and `public-cli/inputs/` hold six diagnostic fixtures: fibrous, striated-only, explicitly fibrous, broad cloud, missing base, missing shaft. They are source-guided diagnostics, not independent creative-user tests. The partial negatives omit the exact profile alias, so nonactivation checks do not claim that an explicitly activated profile can omit mandatory components. Existing broad disjunctive evidence literals remain untouched; no runtime/evidence-matching repair is part of this leaf.

The normal CLI runner freezes input hashes, validates tracked working-tree cleanliness for BEFORE while recording untracked files, checks baseline commit, and hashes source registry/index/CLI/materializer/compiler/candidate extension. It runs without paid APIs. BEFORE manifest and logs live under `public-cli/before/`. Run AFTER with identical frozen inputs only after the reviewed data leaf and derived index update; do not rerun preparation to change the inputs.

### BEFORE completed

All six normal CLI cases exited 0. Three positives emit the target profile; broad cloud and both partial-structure negatives do not. Source hashes remained unchanged. `public-cli/verify_before.py` independently checks frozen hashes, frozen core baselines, target emission, and the narrower composition versus alternative-bearing evidence in each positive. All checks pass. No image was generated or visually assessed.

### AFTER normal CLI completed

All six AFTER cases exited 0 using the exact frozen input files. `public-cli/compare_after.py` verified source deltas restricted to registry and derived index, identical six authorial cores, identical route IDs, and exactly the target composition leaf changed in the three positives. Negative obligations are unchanged. This does not claim improved natural recall or changed evidence acceptance.

### Full composition comparison completed

All twelve BEFORE/AFTER full-composition audits pass with no failures. `public-cli/compare_compositions.py` verifies identical prompt text and literal evidence between phases, empty selected candidate/concept lists, and unchanged warnings. Each case retains three `uncovered_intent` warnings stating its core anchors were preserved by free description/assertion. The striated positive deliberately preserves the existing disjunctive evidence literal and then specifies the striated branch; no claim of striated-only evidence acceptance is made. Exact warning objects are retained in `public-cli/composition-comparison.json`, and individual audit stdout/stderr and JSON remain in each phase's composition directory.

Final boundary checks: all three negative pack files are byte-for-byte identical BEFORE versus AFTER, not merely route-equivalent. All seven cumulonimbus-tagged authored extension candidates exactly match the saved BEFORE provenance (and the entire extension source hash is unchanged). The strengthened `public-cli/compare_after.py` asserts both properties. Source-guided diagnostics and unchanged disjunctive evidence remain the explicit limits of this qualification.
