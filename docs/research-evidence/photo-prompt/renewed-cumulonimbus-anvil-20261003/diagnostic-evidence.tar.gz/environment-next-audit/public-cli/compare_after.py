#!/usr/bin/env python3
import hashlib,json
from pathlib import Path
O=Path(__file__).resolve().parent
B=json.loads((O/'before/run-manifest.json').read_text());A=json.loads((O/'after/run-manifest.json').read_text())
source_changes=[k for k,v in B['hashes'].items() if A['hashes'].get(k)!=v]
assert set(source_changes)=={'skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations.json','skills/photo-prompt-image-generator/assets/photo_prompt_visual_profile_index.json'}, source_changes
pid='cumulonimbus_tower_anvil_precipitation_outflow'
old='Use a wide vertical frame that preserves the low dark base, full convective tower, flattened fibrous anvil, and a descending precipitation shaft in one connected cloud system.'
new=old.replace('flattened fibrous anvil','flattened fibrous or striated anvil')
results=[]
for row in json.loads((O/'frozen-input-manifest.json').read_text()):
 name=row['case'];i=O/'inputs'/name
 for f,h in row['inputs'].items():assert hashlib.sha256((i/f).read_bytes()).hexdigest()==h
 b=json.loads((O/'before'/f'{name}-pack.json').read_text())[0];a=json.loads((O/'after'/f'{name}-pack.json').read_text())[0]
 assert a['authorial_core']==b['authorial_core']
 if row['target_profile'] is None:assert (O/'before'/f'{name}-pack.json').read_bytes()==(O/'after'/f'{name}-pack.json').read_bytes()
 bo=(b.get('visual_obligations') or {}).get('obligations',[]);ao=(a.get('visual_obligations') or {}).get('obligations',[])
 assert [x['id'] for x in ao]==[x['id'] for x in bo]
 changes=[]
 for x,y in zip(bo,ao):
  if x['id']==pid:
   assert x['composition_instruction']==old and y['composition_instruction']==new
   assert {k:v for k,v in x.items() if k!='composition_instruction'}=={k:v for k,v in y.items() if k!='composition_instruction'}
   changes.append(pid+'/composition_instruction')
  else:assert x==y
 results.append(dict(case=name,inputs_frozen=True,authorial_core_identical=True,obligation_changes=changes,negative_pack_byte_identical=(row['target_profile'] is None)))
extension=json.loads((Path('REPOSITORY_ROOT')/'skills/photo-prompt-image-generator/assets/photo_prompt_natural_environment_extension.json').read_text())
current={slot:[x for x in rows if 'cumulonimbus' in json.dumps(x).lower()] for slot,rows in extension['slots'].items()}
current={k:v for k,v in current.items() if v}
prior=json.loads((O.parent/'source-provenance.json').read_text())['unchanged_selected_candidates']
assert current==prior and sum(map(len,current.values()))==7
(O/'after/comparison.json').write_text(json.dumps(dict(source_changes=source_changes,seven_narrow_candidates_identical=True,results=results),indent=2)+'\n')
print('PASS: source deltas restricted to registry/index; all six frozen cores identical; only target composition changes in three positives')
