#!/usr/bin/env python3
import hashlib,json
from pathlib import Path
O=Path(__file__).resolve().parent
manifest=json.loads((O/'frozen-input-manifest.json').read_text())
run=json.loads((O/'before/run-manifest.json').read_text())
pid='cumulonimbus_tower_anvil_precipitation_outflow'
assert run['head']=='ef0ea3f6a396d06bad42b92bfe7915f71089a5a5'
results=[]
for c in manifest:
 d=O/'inputs'/c['case']
 for name,h in c['inputs'].items():assert hashlib.sha256((d/name).read_bytes()).hexdigest()==h
 core=json.loads((d/'authorial-core.json').read_text()); pack=json.loads((O/'before'/(c['case']+'-pack.json')).read_text())[0]
 assert pack['authorial_core']['baseline_prompt_en']==core['baseline_prompt_en']
 obs=(pack.get('visual_obligations') or {}).get('obligations',[]);target=next((x for x in obs if x['id']==pid),None)
 assert bool(target)==bool(c['target_profile'])
 if target:
  assert 'flattened fibrous anvil' in target['composition_instruction']
  assert 'flattened fibrous or striated anvil' in target['evidence_requirements']['anvil_top_phrase']['must_mention_any'][0]
 results.append(dict(case=c['case'],input_hashes_verified=True,baseline_unchanged=True,target_emitted=bool(target),narrow_composition_emitted=bool(target)))
(O/'before/verification.json').write_text(json.dumps(results,indent=2)+'\n')
print('PASS: six frozen input sets and baselines; three exact-profile positives carry narrower composition; three negatives do not activate profile')
