#!/usr/bin/env python3
import json
from pathlib import Path
O=Path(__file__).resolve().parent
results=[]
for row in json.loads((O/'frozen-input-manifest.json').read_text()):
 n=row['case'];bd=O/'before-compositions-final';ad=O/'after-compositions-final'
 b=json.loads((bd/f'{n}-composed.json').read_text());a=json.loads((ad/f'{n}-composed.json').read_text())
 assert b['prompt_en']==a['prompt_en']
 assert b['visual_obligation_evidence']==a['visual_obligation_evidence']
 assert b['chosen_candidate_ids']==a['chosen_candidate_ids']==[]
 assert b['chosen_visual_concept_ids']==a['chosen_visual_concept_ids']==[]
 br=json.loads((bd/f'{n}-audit.json').read_text());ar=json.loads((ad/f'{n}-audit.json').read_text())
 assert br['status']==ar['status']=='pass'
 assert br['failures']==ar['failures']==[]
 assert br['warnings']==ar['warnings']
 results.append(dict(case=n,prompt_and_evidence_identical=True,no_candidate_selected=True,before_status=br['status'],after_status=ar['status'],before_failures=br['failures'],after_failures=ar['failures'],before_warnings=br['warnings'],after_warnings=ar['warnings']))
(O/'composition-comparison.json').write_text(json.dumps(results,indent=2)+'\n')
print('PASS: six fixed-prompt/fixed-evidence composition replays; both phases pass with no failures and identical retained warnings')
