import copy,hashlib,json,sys,subprocess
from pathlib import Path
D=Path(__file__).parent;phase=sys.argv[1] if len(sys.argv)>1 else 'after';E=D/(phase+'-compositions-final');E.mkdir(exist_ok=True);R=Path('REPOSITORY_ROOT');S=R/'skills/photo-prompt-image-generator/scripts';sys.path.insert(0,str(S))
import audit_composed_prompt as ac
save=lambda p,x:p.write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
results=[]
for row in json.loads((D/'frozen-input-manifest.json').read_text()):
 name=row['case'];p=json.loads((D/phase/f'{name}-pack.json').read_text())[0];before=json.loads((D/'before'/f'{name}-pack.json').read_text())[0];core=p['authorial_core'];lock=core['intent_lock'];baseline=core['baseline_prompt_en'];pid=row['target_profile'];evidence={}
 assert baseline==before['authorial_core']['baseline_prompt_en']
 if pid:
  ob=next(x for x in p['visual_obligations']['obligations']if x['id']==pid)
  branch={
   'storm-fibrous':'The selected anvil texture is fibrous.',
   'storm-striated':'The selected anvil texture is striated, with no visible fibrous texture.',
   'storm-explicit-fibrous':'The explicitly requested and selected anvil texture remains fibrous.'}[name]
  evidence={
   'storm_base_phrase':'At the bottom of this vertically connected cloud structure, a broad dark cloud base sits low above the landscape or horizon. Here the horizon gives the low base a readable reference.',
   'convective_tower_phrase':'Above that same connected dark base, a massive cauliflower-textured tower rises continuously from the same cloud base.',
   'anvil_top_phrase':'For the upper cloud structure, the upper cloud spreads into a flattened fibrous or striated anvil. '+branch,
   'precipitation_shaft_phrase':'Below the same connected cloud system, a rain hail or virga shaft visibly descends from beneath the storm body. The selected descending shaft is rain.'}


 prompt=baseline+(' The scene renders '+ob['runtime_expression']['prompt_label_terms'][0]+'. '+' '.join(evidence.values())if evidence else'')
 c={'pack_id':p['pack_id'],'composer':'agent','prompt_en':prompt,'negative_en':p['negative_en'],'chosen_candidate_ids':[],'chosen_visual_concept_ids':[],'core_retrieval_sha256':p['core_retrieval']['canonical_sha256'],'visual_obligation_evidence':{pid:evidence}if pid else{},'authorial_core_binding':{'source_authorial_core_sha256':core['canonical_sha256'],'source_intent_lock_sha256':lock['canonical_sha256'],'preserved_anchor_ids':[a['anchor_id']for a in lock['semantic_anchors']],'preserved_evidence':[a['prompt_evidence']for a in lock['semantic_anchors']],'authorial_decisions':[]}}
 review=copy.deepcopy(p['embodiment_preflight']['baseline_review']);review.update(provenance='agent_postcomposition',prompt_sha256=hashlib.sha256(prompt.encode()).hexdigest(),summary='Text-only environment composition contains no body or body action. Frozen cloud texture, scene geometry and subject are retained. No pixel verification is claimed.')
 c['embodiment_review']={'source_contract_sha256':p['embodiment_preflight']['canonical_sha256'],'review':review};c['semantic_clarification_decisions']=[]
 for r in p['semantic_clarification']['candidates']:
  apply=r.get('required_in_final_prompt')is True or(pid is not None and r.get('profile_id')==pid)
  q={'clarification_id':r['id'],'decision':'applied'if apply else'rejected','rationale':'Preserve the frozen environmental subject, cloud texture and connected geometry.'if apply else'This optional interpretation adds unnecessary meaning to the frozen environmental scene.'}
  if apply:q['prompt_evidence']=baseline.split('. ')[0]+'.'if r.get('source')=='requester_meaning_bound_by_authorial_core'else next(iter(evidence.values()),baseline.split('. ')[0]+'.')
  c['semantic_clarification_decisions'].append(q)
 c['creative_augmentation_brief']={'decisions':[{'candidate_id':r['id'],'decision':'rejected','rationale':'Retain the frozen environmental geometry and cloud texture without optional additions.'}for r in ac.creative_augmentation_candidates_from_pack(p)]}
 save(E/f'{name}-composed.json',c)
 command=[sys.executable,str(S/'audit_composed_prompt.py'),'--pack',str(D/phase/f'{name}-pack.json'),'--composed',str(E/f'{name}-composed.json')];run=subprocess.run(command,capture_output=True,text=True)
 (E/f'{name}.stdout').write_text(run.stdout);(E/f'{name}.stderr').write_text(run.stderr)
 result=json.loads(run.stdout);save(E/f'{name}-audit.json',result)
 results.append({'case':name,'command':command,'exit_code':run.returncode,'status':result['status'],'failures':result['failures'],'warnings':result['warnings'],'before_visual_failures':ac.audit_visual_obligations(before,c,prompt),'after_visual_failures':ac.audit_visual_obligations(p,c,prompt),'baseline_preserved':prompt.startswith(baseline),'evidence':evidence})
 print(name,result['status'],result['failures'],flush=True)
 save(E/'summary.json',results)
