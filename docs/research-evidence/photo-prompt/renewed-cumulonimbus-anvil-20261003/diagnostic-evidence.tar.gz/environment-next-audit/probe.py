#!/usr/bin/env python3
"""Read-only, no-API production profile materialization and routing probe."""
import copy
import hashlib
import json
import subprocess
import sys
from pathlib import Path

R = Path('REPOSITORY_ROOT')
O = Path(__file__).resolve().parent
sys.path.insert(0, str(R / 'skills/photo-prompt-image-generator/scripts'))
import prompt_generator as pg

A = R / 'skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations.json'
E = R / 'skills/photo-prompt-image-generator/assets/photo_prompt_natural_environment_extension.json'
P = R / 'docs/research-evidence/photo-prompt/research_evidence.jsonl'
pid = 'cumulonimbus_tower_anvil_precipitation_outflow'
reg = pg.load_visual_obligation_registry(A)
p = next(x for x in reg['profiles'] if x['id'] == pid)
old = 'Use a wide vertical frame that preserves the low dark base, full convective tower, flattened fibrous anvil, and a descending precipitation shaft in one connected cloud system.'
new = 'Use a wide vertical frame that preserves the low dark base, full convective tower, flattened fibrous or striated anvil, and a descending precipitation shaft in one connected cloud system.'
assert p['composition_instruction'] == old, 'Source changed; reassess rather than silently rebaseline'
terms = p['semantics']['component_semantics']['groups'][2]['any_terms']
assert terms == ['the upper cloud spreads into a flattened fibrous or striated anvil']
assert p['evidence_requirements']['anvil_top_phrase']['must_mention_any'] == terms
assert next(x for x in p['render_gates'] if x['id'] == 'vo_natural_cumulonimbus_anvil')['description'] == 'The upper cloud visibly spreads into a flattened fibrous or striated anvil.'
after = copy.deepcopy(reg)
pa = next(x for x in after['profiles'] if x['id'] == pid)
pa['composition_instruction'] = new

def delta(a,b,path=''):
    if isinstance(a,dict) and isinstance(b,dict):
        return sum((delta(a.get(k),b.get(k),path+'/'+k) for k in sorted(a.keys()|b.keys())),[])
    if isinstance(a,list) and isinstance(b,list) and len(a)==len(b):
        return sum((delta(x,y,path+'/'+str(i)) for i,(x,y) in enumerate(zip(a,b))),[])
    return [] if a==b else [path]

assert delta(p,pa)==['/composition_instruction']
b = pg.candidate_pack_visual_profile_obligation(p,reg,activation_source='audit',source_intent_ids=[])
a = pg.candidate_pack_visual_profile_obligation(pa,after,activation_source='audit',source_intent_ids=[])
assert delta(b,a)==['/composition_instruction']
assert b['composition_instruction']==old and a['composition_instruction']==new
cases = {'exact_en':'cumulonimbus convective storm structure','exact_ko':'적란운 대류 폭풍 구조',
         'broad_storm':'storm','broad_ko':'폭풍','broad_cloud':'cloud',
         'dark_overcast':'dark overcast with a lightning graphic and smoke',
         'smoke':'an isolated smoke plume with no connected cloud base or precipitation'}
controls = {}
for name,text in cases.items():
    rows = [dict(source='concept_lock',text=text,polarity='required',priority='critical',mandatory=True)]
    before = sorted(pg.candidate_pack_auto_visual_obligation_matches(reg,rows))
    proposed = sorted(pg.candidate_pack_auto_visual_obligation_matches(after,rows))
    assert before==proposed
    assert (pid in proposed)==name.startswith('exact_'),(name,proposed)
    controls[name]=dict(text=text,before=before,proposed=proposed)
source=next(json.loads(l) for l in P.read_text().splitlines() if json.loads(l).get('id')=='natural_environment_wmo_cumulonimbus_structure')
ext=json.loads(E.read_text())
candidates={slot:[x for x in rows if 'cumulonimbus' in json.dumps(x).lower()] for slot,rows in ext['slots'].items()}
candidates={k:v for k,v in candidates.items() if v}
assert len([x for rows in candidates.values() for x in rows]) == 7
assert all(x['id'] in {z['id'] for rows in ext['slots'].values() for z in rows} for rows in candidates.values() for x in rows)

def save(name,obj):
    (O/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
save('exact-leaves.json',[dict(file=str(A.relative_to(R)),profile_id=pid,path=['composition_instruction'],before=old,proposed=new)])
save('source-provenance.json',dict(profile_before=p,research_evidence=source,unchanged_selected_candidates=candidates,
    audit_scope_profiles=[x for x in reg['profiles'] if x.get('category','').startswith('natural_environment')]))
save('materialization-proof.json',dict(head=subprocess.check_output(['git','-C',str(R),'rev-parse','HEAD'],text=True).strip(),
    file_hashes={str(x.relative_to(R)):hashlib.sha256(x.read_bytes()).hexdigest() for x in [A,E,P]},
    profile_delta=delta(p,pa),materialized_delta=delta(b,a),before=b,proposed=a,production_route_controls=controls,
    no_selected_candidates=True,scope='Actual production profile materializer and routing helpers, not end-to-end generated image validation'))
print('PASS: one composition leaf, actual production materialization, two exact and five negative route controls unchanged; seven selected candidates untouched')
