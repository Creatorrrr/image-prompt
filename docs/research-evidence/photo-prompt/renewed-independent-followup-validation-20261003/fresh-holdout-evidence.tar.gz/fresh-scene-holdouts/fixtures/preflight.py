from pathlib import Path
import json,hashlib,sys,subprocess,traceback
sys.dont_write_bytecode=True
O=Path(__file__).resolve().parent;B=O.parent;R=B.parent.parent/'image-prompt';S=R/'skills/photo-prompt-image-generator/scripts';PRE=S.parent/'precore';sys.path.insert(0,str(S));import prompt_generator as g
D=lambda p:json.loads(p.read_text());H=lambda b:hashlib.sha256(b).hexdigest()
def W(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
assert H((B/'author/fresh_scene_holdouts.json').read_bytes())=='1381bd8b008e7226d6fedd6d0ff799d507b14183c04334d5b8773891ac935278';source={x['case_id']:x for x in D(B/'author/fresh_scene_holdouts.json')};em=D(B/'envelopes/manifest.json')
trial=O/'preflight'/('attempt-%02d'%(len(list((O/'preflight').glob('attempt-*')))+1));trial.mkdir(parents=True);rows=[]
for id,original in source.items():
 d=O/id;row=dict(id=id,request_unchanged=False,initial_scene_unchanged=False)
 for f in d.glob('*.json'):(trial/id).mkdir(exist_ok=True);(trial/id/f.name).write_bytes(f.read_bytes())
 try:
  assert H((d/'envelope.json').read_bytes())==em[id+'.json'];core=D(d/'core.json');assert core['baseline_prompt_en']==original['initial_scene_prompt_en'];assert core['source_request']==original['requester_text_ko'];row.update(request_unchanged=True,initial_scene_unchanged=True)
  env=g.load_request_envelope_arg(str(d/'envelope.json'));ctl=D(d/'controls.json');normalized=g.load_authorial_core_arg(str(d/'core.json'),request_envelope=env,creative_control_snapshot=ctl);policy=g.photo_embodiment.build_policy(normalized,D(d/'review.json'))
  cmd=[str(R/'.venv/bin/python'),str(S/'validate_precore_feature_selection.py'),'--catalog',str(PRE/'visual_feature_catalog.json'),'--request-envelope',str(d/'envelope.json'),'--authorial-core',str(d/'core.json'),'--embodiment-review',str(d/'review.json'),'--selection',str(d/'feature-selection.json')];proc=subprocess.run(cmd,cwd=R,capture_output=True,text=True);row.update(feature_command=cmd,feature_exit_code=proc.returncode,feature_stdout=proc.stdout,feature_stderr=proc.stderr);assert proc.returncode==0,proc.stdout+proc.stderr
  row.update(status='ready',core_sha256=normalized['canonical_sha256'],intent_lock_sha256=normalized['intent_lock']['canonical_sha256'],subject_type=g.authored_subject_category(normalized['semantic_assertions'],ctl['context']));W(trial/id/'normalized-core.json',normalized);W(trial/id/'embodiment-policy.json',policy)
 except Exception as e:row.update(status='blocked',error=str(e),traceback=traceback.format_exc(),blanket_directive_hits=g.find_blanket_negative_directives(original['initial_scene_prompt_en']))
 rows.append(row)
W(trial/'report.json',rows);W(O/'PREFLIGHT-LATEST.json',dict(attempt=str(trial.relative_to(O)),denominator=8,rows=rows));print(json.dumps([{'id':x['id'],'status':x['status'],'error':x.get('error')}for x in rows],ensure_ascii=False,indent=2))
