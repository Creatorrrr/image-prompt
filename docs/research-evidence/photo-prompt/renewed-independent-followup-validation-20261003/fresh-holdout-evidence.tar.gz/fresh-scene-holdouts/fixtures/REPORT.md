# Fresh-scene holdout metadata readiness

Eight original synthetic requests and independently authored scene texts are preserved byte-for-byte. Four metadata bundles pass current preflight; four remain blocked by the current core validator. The denominator is eight, not four.

Ready: fresh_scene_01, fresh_scene_02, fresh_scene_06, fresh_scene_07
Blocked: fresh_scene_03, fresh_scene_04, fresh_scene_05, fresh_scene_08

No candidate-pack query or retrieval has run. Retrieval may later run only the genuinely ready cases, with all eight cases and their exclusions reported. These rejections are fixture/protocol limitations, not demonstrated DATA regressions.

## Exact blocked clauses and interpretation

-03: “No person or hand needs to appear” is permissive nonrequirement, not an affirmative prohibition on people. The surface-form validator nonetheless rejects it
-04: “No mechanic is required” likewise says a mechanic is unnecessary, not forbidden. The validator rejects this wording
-05: “Avoid crowding the scene with other birds, feeders, or ornamental objects that distract from this small physical action” is an author-written avoidance directive. It is not present as a requester exclusion in the Korean fixture
-08: “No pedestrians are present” describes the chosen empty scene; the Korean request explicitly asks for an empty outdoor stairway. The validator still rejects this instruction-shaped sentence

The validator behavior is recorded unchanged. No source edit, prompt rewrite, negative-clause deletion, added requester exclusion, or validator relaxation was used to pass these cases.

## Bookkeeping and ownership

Each bundle contains the unchanged coordinator envelope, unchanged initial_scene_prompt_en text, V3 core, typed required primary-subject assertion, intent lock, creative controls/context, embodiment review and five-category feature-selection record. The author's complete initial relation list and open choices remain separate in author-assessment.json. They do not automatically become requester-owned locks.

Required core anchors cite exact Korean request substrings; the required subject assertion uses the active fixture span and a literal baseline subject phrase. Extra baseline staging remains editable through open dimensions. All core user_exclusions lists are empty. Coarse no-people context is used only for the Korean requests explicitly specifying a people-free/empty environment, not the author-only optional absence in03/04. The two objects author's bucket is typed more precisely as food (pear) and object (bicycle) under the current schema; birds/snails are animal, built scenes environment.

Creative-axis zero overrides are fixed experimental settings, not requester-stated preferences. Every requesting_user wire enum is simulation only: these are not actual user messages and provide no external authority.

The initial scene author was candidate-unexposed. Taxonomy/schema bookkeeping happened afterward by a worker with earlier candidate exposure. Therefore full pre-core process adherence, clean end-to-end authoring, and organic-user provenance are expressly NOT claimed. Only initial-author candidate non-exposure is claimed.

## Preserved scaffolding corrections

preflight/attempt-01 retains the first metadata: four otherwise eligible cores failed because interpretation resolution was shorter than the schema minimum. Their unchanged scenes were not altered; the metadata resolution was expanded to “The requested primary subject is …”.

preflight/attempt-02 retains the next metadata: style needed two evidence phrases rather than one. A second existing literal scene excerpt was recorded as metadata. No new scene or style instruction was introduced.

preflight/attempt-03 records the final four-ready/four-blocked result. Exact full rejected metadata and diagnostics remain available in every attempt directory. No retrieval feedback informed any correction.

manifest.json freezes all resulting metadata, source author/envelope hashes, preflight results and schema/catalog hashes before retrieval. No providers, images, candidate-pack queries or repository source mutations.
