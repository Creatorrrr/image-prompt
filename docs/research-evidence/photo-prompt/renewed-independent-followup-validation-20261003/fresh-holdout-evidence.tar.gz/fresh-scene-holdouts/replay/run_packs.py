from common import *
import sys,time
m,a=verify();assert not(P/'freeze-receipt.json').exists(),'Do not rerun frozen replay'
dump(P/'freeze-receipt.json',dict(fixtures_manifest_sha256=RECEIPT,author_sha256=m['author_sha256'],envelope_manifest_sha256=m['envelope_manifest_sha256'],frozen_fixture_files=len(m['input_hashes']),snapshot_files_per_arm=len(a['factual_hashes']),ready=m['ready_case_ids'],blocked=m['blocked_case_ids'],denominator=8,seed=1003,fixtures_and_arms_verified=True,provider_credentials_removed_from_subprocess_environment=True))
report=dict(denominator=8,ready_case_ids=m['ready_case_ids'],blocked_case_ids=m['blocked_case_ids'],arms={})
for arm in ['factual','counterfactual']:
 root=ARMS/arm;s=root/'skills/photo-prompt-image-generator/scripts';out=P/arm;out.mkdir(exist_ok=True)
 cmd=[PYTHON,str(P/'preflight_arm.py'),arm];p=subprocess.run(cmd,cwd=root,env=environment(),capture_output=True,text=True);dump(out/'preflight-cli.json',dict(command=cmd,exit_code=p.returncode,stdout=p.stdout,stderr=p.stderr));assert p.returncode==0,p.stdout+p.stderr
 rows=[];report['arms'][arm]=rows;dump(P/'pack-report.json',report)
 for case in sorted(m['ready_case_ids']+m['blocked_case_ids']):
  if case in m['blocked_case_ids']:
   row=dict(id=case,status='blocked_pre_retrieval',retrieval_executed=False,error=next(x['error']for x in read(out/'preflight.json')['rows']if x['id']==case));rows.append(row);dump(P/'pack-report.json',report);continue
  verify();d=F/case;dest=out/case;dest.mkdir();cmd=[PYTHON,str(s/'generate_photo_prompt.py'),'--seed','1003']
  for opt,name in [('request-envelope','envelope'),('authorial-core','core'),('creative-controls','controls'),('embodiment-review','review')]:cmd+=['--'+opt+'-json',str(d/(name+'.json'))]
  cmd+=['--output-file',str(dest/'pack.json')];start=time.monotonic();p=subprocess.run(cmd,cwd=root,env=environment(),capture_output=True,text=True,timeout=600);dump(dest/'cli.json',dict(command=cmd,exit_code=p.returncode,stdout=p.stdout,stderr=p.stderr,seconds=time.monotonic()-start))
  row=dict(id=case,status='generated'if p.returncode==0 else'cli_failed',exit_code=p.returncode,retrieval_executed=True)
  if p.returncode==0:
   pack=read(dest/'pack.json')[0];core=pack['authorial_core'];assert core['baseline_prompt_en']==read(d/'core.json')['baseline_prompt_en']
   row.update(pack_id=pack['pack_id'],core_sha256=core['canonical_sha256'],intent_lock_sha256=core['intent_lock']['canonical_sha256'],hard_profiles=[x['id']for x in pack.get('visual_obligations',{}).get('obligations',[])],slot_candidate_count=sum(len(x.get('candidates',[]))for x in pack['slots'].values()),optional_visual_count=len(pack.get('visual_concept_candidates',{}).get('candidates',[])),required_clarifications=[x for x in pack.get('semantic_clarification',{}).get('candidates',[])if x.get('required_in_final_prompt')])
  rows.append(row);dump(P/'pack-report.json',report);print(arm,case,row['status'],row.get('hard_profiles'),flush=True)
 verify()
report['frozen_hashes_verified_after']=True;dump(P/'pack-report.json',report);print('Both arms complete; all8 accounted for; frozen hashes intact',flush=True)
