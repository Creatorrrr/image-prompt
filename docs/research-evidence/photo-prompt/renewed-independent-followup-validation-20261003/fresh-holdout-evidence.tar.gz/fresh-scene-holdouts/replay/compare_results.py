"""Exhaustive frozen-input arm comparison without collapsing blocked cases."""
from common import *
import sys
sys.dont_write_bytecode=True
sys.path.insert(0,str(ARMS/'factual/skills/photo-prompt-image-generator/scripts'));import prompt_generator as pg
m,a=verify();assert read(P/'pack-report.json')['frozen_hashes_verified_after'];assert(P/'baseline-audit-complete.json').exists()
TARGETS={'mounted_slide_transparency_object_relation','ghost_ship_former_vessel_breach','biaoju_guarded_cargo_departure','auroral_arc_curtain_atmosphere','oneiric_dream_logic_discontinuity'}
def leaves(x):
 if isinstance(x,dict):return sum(leaves(v)for v in x.values())
 if isinstance(x,list):return sum(leaves(v)for v in x)
 return 1

def diff(x,y,path=''):
 if type(x)!=type(y):return [dict(path=path,factual=x,counterfactual=y)]
 if isinstance(x,dict):return [z for k in sorted(x.keys()|y.keys())for z in ([dict(path=path+'/'+k,factual=x.get(k),counterfactual=y.get(k))]if k not in x or k not in y else diff(x[k],y[k],path+'/'+k))]
 if isinstance(x,list):
  out=[dict(path=path+'/length',factual=len(x),counterfactual=len(y))]if len(x)!=len(y)else[]
  return out+[z for i,(a,b)in enumerate(zip(x,y))for z in diff(a,b,path+'/'+str(i))]
 return []if x==y else[dict(path=path,factual=x,counterfactual=y)]
def candidates(pack):
 out={}
 for slot,data in pack['slots'].items():out['slots/'+slot]=[dict(id=x['id'],applicability=x.get('applicability'),eligibility=x.get('eligibility'))for x in data.get('candidates',[])]
 for key in ['visual_concept_candidates','semantic_clarification','creative_augmentation']:
  out[key]=[dict(id=x['id'],applicability=x.get('applicability'),eligibility=x.get('eligibility'),profile_id=x.get('opt_in_contract',{}).get('obligation',{}).get('id'))for x in pack.get(key,{}).get('candidates',[])]
 return out

rows=[];bya={arm:{x['id']:x for x in read(P/arm/'preflight.json')['rows']}for arm in ['factual','counterfactual']}
for case in sorted(m['ready_case_ids']+m['blocked_case_ids']):
 if case in m['blocked_case_ids']:
  f=bya['factual'][case];c=bya['counterfactual'][case];assert f['status']==c['status']=='blocked';assert f['error']==c['error'];rows.append(dict(id=case,status='blocked_in_both',retrieval_executed=False,baseline_audit_executed=False,identical_preflight_error=f['error'],stage='authorial_core_preflight',DATA25_29_effect='none_observed_same_current_runtime_rejection'));continue
 fpath=P/'factual'/case/'pack.json';cpath=P/'counterfactual'/case/'pack.json';f=read(fpath)[0];c=read(cpath)[0];delta=diff(f,c);dump(P/'comparisons'/case/'all-pack-leaf-deltas.json',delta)
 fc=candidates(f);cc=candidates(c);dump(P/'comparisons'/case/'candidate-ids-order-eligibility.json',dict(factual=fc,counterfactual=cc,identical=fc==cc))
 assert pg.candidate_pack_recompute_id(json.loads(json.dumps(f)))['pack_id']==f['pack_id'];assert pg.candidate_pack_recompute_id(json.loads(json.dumps(c)))['pack_id']==c['pack_id']
 fco=read(P/'factual'/case/'baseline-composition/composed.json');cco=read(P/'counterfactual'/case/'baseline-composition/composed.json');fa=read(P/'factual'/case/'baseline-composition/audit.json');ca=read(P/'counterfactual'/case/'baseline-composition/audit.json')
 assert fco['prompt_en']==cco['prompt_en']==read(F/case/'core.json')['baseline_prompt_en'];assert fco['chosen_candidate_ids']==cco['chosen_candidate_ids']==[]and fco['chosen_visual_concept_ids']==cco['chosen_visual_concept_ids']==[]
 hard=[x['id']for x in f.get('visual_obligations',{}).get('obligations',[])];offered=[x.get('opt_in_contract',{}).get('obligation',{}).get('id')for x in f.get('visual_concept_candidates',{}).get('candidates',[])]
 rows.append(dict(id=case,status='generated_in_both',retrieval_executed=True,pack_leaf_count=leaves(f),changed_pack_leaf_count=len(delta),complete_packs_identical=f==c,raw_pack_bytes_identical=sha(fpath)==sha(cpath),factual_pack_sha256=sha(fpath),counterfactual_pack_sha256=sha(cpath),candidate_ID_order_eligibility_identical=fc==cc,core_identical=f['authorial_core']==c['authorial_core'],core_sha256=f['authorial_core']['canonical_sha256'],hard_obligations_identical=f.get('visual_obligations')==c.get('visual_obligations'),hard_profile_ids=hard,DATA25_29_hard_targets=sorted(TARGETS&set(hard)),DATA25_29_optional_visual_targets=sorted(TARGETS&set(offered)),baseline_audit_executed=True,baseline_compositions_identical=fco==cco,baseline_audits_identical=fa==ca,baseline_status_factual=fa['status'],baseline_status_counterfactual=ca['status'],baseline_failures=fa['failures'],baseline_warnings=fa.get('warnings',[]),optional_adoptions=0,DATA25_29_effect='none_observed_identical_complete_packs'if not delta else'observed_pack_delta_requires_analysis'))
verify();report=dict(denominator=8,generated_scene_count=4,blocked_scene_count=4,actual_public_pack_runs=8,baseline_full_composition_audits=8,rows=rows,observed_DATA25_29_pack_effect_cases=sum(x.get('changed_pack_leaf_count',0)>0 for x in rows),all_frozen_fixture_author_envelope_and_arm_hashes_unchanged=True,initial_author_candidate_unexposed=True,full_precore_process_adherence=False,metadata_worker_prior_candidate_exposure=True,organic_user_traffic=False,provider_calls=0,images=0,scope='Five accepted DATA25-29 corrections only under the same pinned current upstream runtime; no runtime-efficacy or rendered-quality claim.')
dump(P/'comparison.json',report);print(json.dumps({k:v for k,v in report.items()if k!='rows'},indent=2))
