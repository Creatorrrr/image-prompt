from pathlib import Path
import hashlib,json,os,subprocess
P=Path(__file__).resolve().parent;B=P.parent;F=B/'fixtures';ARMS=B/'arms';R=B.parent.parent/'image-prompt';PYTHON=str(R/'.venv/bin/python');RECEIPT='fd59bcc79b6379fc875400627ac9637b65c1588619788fb9662f62cfbacae235'
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def environment():
 env={k:v for k,v in os.environ.items()if not any(t in k.upper()for t in ['API_KEY','TOKEN','SECRET','CREDENTIAL'])};env['PYTHONDONTWRITEBYTECODE']='1';return env

def verify():
 assert sha(F/'manifest.json')==RECEIPT,'Freeze receipt drift';m=read(F/'manifest.json');a=read(ARMS/'snapshot-manifest.json')
 assert sha(B/'author/fresh_scene_holdouts.json')==m['author_sha256']=='1381bd8b008e7226d6fedd6d0ff799d507b14183c04334d5b8773891ac935278'
 assert sha(B/'envelopes/manifest.json')==m['envelope_manifest_sha256']
 assert all(sha(F/f)==h for f,h in m['input_hashes'].items())
 assert all(sha(B/'envelopes'/f)==h for f,h in m['envelope_hashes'].items())
 for arm in ['factual','counterfactual']:
  assert all(sha(ARMS/arm/f)==h for f,h in a[arm+'_hashes'].items()),arm+' snapshot drift'
  assert all(sha(ARMS/arm/f)==h for f,h in m['schema_hashes'].items()),arm+' metadata schema mismatch'
  assert not(ARMS/arm/'.env').exists()
 source={x['case_id']:x for x in read(B/'author/fresh_scene_holdouts.json')}
 for case in source:
  core=read(F/case/'core.json');assert core['baseline_prompt_en']==source[case]['initial_scene_prompt_en'];assert core['source_request']==source[case]['requester_text_ko'];assert sha(F/case/'envelope.json')==m['envelope_hashes'][case+'.json']
 return m,a
