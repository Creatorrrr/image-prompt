# Fresh-author scene holdout replay: no observed DATA25–29 output effect

## Result and denominator

Eight independently authored synthetic scene texts were retained unchanged. Four reached retrieval in both isolated arms; four were identically blocked before retrieval. The denominator remains eight.

- Ready scenes 01, 02, 06, 07: all eight actual public CLI runs succeeded (four scenes × two arms)
- Their complete packs are byte-identical across arms, covering 16,113 scalar leaves plus identical container structure
- Every candidate ID/order/applicability, retrieval field, normalized core, intent lock, hard obligation and valid derived pack ID is unchanged
- All four unchanged baseline compositions pass full composed-prompt CLI audit in both arms, with zero optional slot/visual/creative adoptions
- Each baseline audit retains the same three uncovered-intent warnings; they are not zero-warning results
- Blocked scenes 03, 04, 05, 08 reproduce exactly the same core preflight error in both arms and do not run retrieval or composition audit

None of the five corrected profiles is hard-active or offered as an optional visual target in the four generated cases. No DATA25–29 pack or baseline-acceptance effect is observed in this sample. This does not show that those corrections improve broad scenes, nor that they are unnecessary in their targeted relations. The two object-category scenes both remain blocked, so there is no admitted object-scene retrieval coverage here.

## Arm construction and scope

Factual source is pin `31dbed9f`; counterfactual preserves the identical current upstream runtime/data while reverting only the five accepted DATA25–29 target records to their exact pre-DATA25 versions. Old slide/convoy vectors match their old text exactly; the other 1,562 vector entries and all general semantic data remain identical. See `../arms/README.md`, `snapshot-manifest.json` and `exact-delta-proof.json`.

Both arms run their own unchanged public `generate_photo_prompt.py` with the same seed 1003, same frozen inputs and same existing Python interpreter. Provider credentials were removed from subprocess environments; snapshots contain no `.env`. No provider calls or rendered images occurred. This is a test of the five DATA changes under the same current runtime, not a comparison or validation of a new runtime generation.

## Frozen-input checks

Before any query, verified final metadata receipt SHA-256 `fd59bcc79b6379fc875400627ac9637b65c1588619788fb9662f62cfbacae235`, all 314 sealed fixture-file hashes, author scene-file SHA-256 `1381bd8b008e7226d6fedd6d0ff799d507b14183c04334d5b8773891ac935278`, the coordinator envelope manifest and all eight envelope hashes, plus each arm's 202 selected file hashes and the metadata schema/catalog hashes. Checks repeat before each run and after each arm. All remain intact.

The replay reruns candidate-free preflight through each arm's own `load_request_envelope_arg`, `load_authorial_core_arg` and embodiment policy, with corpus loading/retrieval blocked during that preflight. All four admitted normalized core/lock hashes match the frozen qualifier output. No fixture text, metadata, validator, source profile or snapshot was changed.

The initial author was candidate-unexposed. Subsequent metadata scaffolding used current taxonomy/schema knowledge from a worker with prior candidate exposure. Required simulation wire enums do not establish actual user provenance. This is not organic traffic or a clean end-to-end pre-core experiment. Only the initial author's candidate non-exposure is claimed; preserved metadata attempts and their limitations remain in `../fixtures/`.

## Blocked cases are findings, not exclusions hidden from the denominator

03: “No person or hand needs to appear” is permissive nonrequirement; current validator nevertheless rejects its surface form.

04: “No mechanic is required” likewise states nonrequirement and is rejected.

05: The author's “Avoid crowding…” sentence is an avoidance directive not supplied as a Korean requester exclusion.

08: “No pedestrians are present” describes the chosen empty scene and aligns with an empty-stairway request, but the current validator rejects that wording.

Their error strings match exactly across both arms. These are shared fixture/protocol admission limits, not demonstrated DATA25–29 regressions. No deletion, rewrite, new exclusion, or validator relaxation was used to admit them.

## Baseline-composition policy

The author's initial English prose is unchanged, byte-for-byte. Optional slot candidates, visual concepts, clarifications and creative additions are rejected. The mandatory requester-meaning clarification is marked applied only after verifying each frozen meaning component already occurs in that unchanged baseline; literal baseline evidence is supplied. Required typed subject assertion evidence and existing textual embodiment review are preserved; only postcomposition provenance is recorded for the unchanged prompt.

No profile evidence is manufactured from retrieved candidates. These cases have no hard visual profile obligations. The baseline audits establish text/contract compatibility only, not pixel correctness, aesthetics, photographic plausibility, or quality improvement.

## Evidence

- `freeze-receipt.json`: pre-query hash receipt and denominator
- `factual/preflight.json`, `counterfactual/preflight.json`: all eight per-arm admissions/rejections
- `pack-report.json`: actual eight successful public pack runs and explicit blocked rows
- Per-case `cli.json`, `pack.json`, `baseline-composition/{composed.json,cli.json,audit.json}`
- `comparisons/<case>/all-pack-leaf-deltas.json`: empty for all four generated cases
- `comparisons/<case>/candidate-ids-order-eligibility.json`: explicit unchanged candidate sequences/statuses
- `comparison.json`: exhaustive results, baseline failures/warnings and DATA-target exposure
- `common.py`, `preflight_arm.py`, `run_packs.py`, `audit_baselines.py`, `compare_results.py`: reproducible read-only replay logic

Do not overwrite the preserved run. Any future experiment needs a separately frozen design and must report these blocked cases and provenance limits rather than recasting this as eight successful holdouts.
