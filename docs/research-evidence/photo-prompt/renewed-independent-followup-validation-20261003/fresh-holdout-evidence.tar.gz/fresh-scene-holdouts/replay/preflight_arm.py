from common import *
import sys,traceback
from unittest.mock import patch
sys.dont_write_bytecode=True
arm=sys.argv[1];m,a=verify();root=ARMS/arm;s=root/'skills/photo-prompt-image-generator/scripts';sys.path.insert(0,str(s));import prompt_generator as g
expected={x['id']:x for x in read(F/'PREFLIGHT-LATEST.json')['rows']};rows=[]
with patch.object(g,'load_runtime_data',side_effect=AssertionError('No runtime corpus loading in preflight')),patch.object(g,'resolve_visual_profile_hits',side_effect=AssertionError('No retrieval in preflight')):
 for case in sorted(expected):
  d=F/case;row=dict(id=case,arm=arm,expected=expected[case]['status'])
  try:
   env=g.load_request_envelope_arg(str(d/'envelope.json'));ctl=read(d/'controls.json');core=g.load_authorial_core_arg(str(d/'core.json'),request_envelope=env,creative_control_snapshot=ctl);policy=g.photo_embodiment.build_policy(core,read(d/'review.json'))
   cmd=[PYTHON,str(s/'validate_precore_feature_selection.py'),'--catalog',str(root/'skills/photo-prompt-image-generator/precore/visual_feature_catalog.json'),'--request-envelope',str(d/'envelope.json'),'--authorial-core',str(d/'core.json'),'--embodiment-review',str(d/'review.json'),'--selection',str(d/'feature-selection.json')]
   p=subprocess.run(cmd,cwd=root,env=environment(),capture_output=True,text=True);row['feature_validation']=dict(command=cmd,exit_code=p.returncode,stdout=p.stdout,stderr=p.stderr);assert p.returncode==0,p.stdout+p.stderr
   row.update(status='ready',core_sha256=core['canonical_sha256'],intent_lock_sha256=core['intent_lock']['canonical_sha256'],subject_type=g.authored_subject_category(core['semantic_assertions'],ctl['context']))
   assert row['core_sha256']==expected[case]['core_sha256']and row['intent_lock_sha256']==expected[case]['intent_lock_sha256']
  except Exception as e:
   row.update(status='blocked',error=str(e),traceback=traceback.format_exc())
  assert row['status']==row['expected'],row
  if row['status']=='blocked':assert row['error']==expected[case]['error'],row
  rows.append(row)
verify();dump(P/arm/'preflight.json',dict(denominator=8,rows=rows,blocked_remain_reported=True,retrieval_calls=0));print(arm,'preflight: 4 ready,4 identical blocked',flush=True)
