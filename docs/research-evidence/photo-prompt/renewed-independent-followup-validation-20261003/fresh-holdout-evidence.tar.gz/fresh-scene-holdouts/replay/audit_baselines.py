"""Audit unchanged initial scene prose with all optional adoptions rejected."""
from common import *
import copy
m,a=verify();reports={};assert read(P/'pack-report.json').get('frozen_hashes_verified_after')
for arm in ['factual','counterfactual']:
 root=ARMS/arm;s=root/'skills/photo-prompt-image-generator/scripts';rows=[];reports[arm]=rows
 for case in sorted(m['ready_case_ids']+m['blocked_case_ids']):
  if case in m['blocked_case_ids']:
   rows.append(dict(id=case,status='blocked_pre_retrieval',baseline_audit_executed=False));continue
  dest=P/arm/case;pack=read(dest/'pack.json')[0];core=pack['authorial_core'];lock=core['intent_lock'];prompt=core['baseline_prompt_en'];assert prompt==read(F/case/'core.json')['baseline_prompt_en']
  decisions=[]
  for c in pack.get('semantic_clarification',{}).get('candidates',[]):
   if c.get('required_in_final_prompt'):
    assert c['source']=='requester_meaning_bound_by_authorial_core',('Unexpected required clarification',case,c)
    assert all(x.lower()in prompt.lower()for x in c['meaning_components']),(case,'required meaning absent')
    decisions.append(dict(clarification_id=c['id'],decision='applied',rationale='The unchanged initial scene already contains the frozen requester-owned meaning.',prompt_evidence=prompt))
   else:decisions.append(dict(clarification_id=c['id'],decision='rejected',rationale='Baseline-preservation check rejects all optional reinterpretation and adoption.'))
  review=copy.deepcopy(read(F/case/'review.json'));review['provenance']='agent_postcomposition';assert review['prompt_sha256']==hashlib.sha256(prompt.encode()).hexdigest()
  composed=dict(core_retrieval_sha256=pack['core_retrieval']['canonical_sha256'],pack_id=pack['pack_id'],prompt_en=prompt,negative_en=pack['negative_en'],chosen_candidate_ids=[],chosen_visual_concept_ids=[],composer='agent',candidate_interpretations=[],authorial_core_binding=dict(source_authorial_core_sha256=core['canonical_sha256'],source_intent_lock_sha256=lock['canonical_sha256'],preserved_anchor_ids=[x['anchor_id']for x in lock['semantic_anchors']],preserved_evidence=[],authorial_decisions=[]),semantic_clarification_decisions=decisions,creative_augmentation_brief=dict(decisions=[dict(candidate_id=x['id'],decision='rejected',rationale='The frozen baseline is evaluated without optional augmentation.')for x in pack.get('creative_augmentation',{}).get('candidates',[])]),embodiment_review=dict(source_contract_sha256=pack['embodiment_preflight']['canonical_sha256'],review=review))
  if pack.get('semantic_assertion_obligations'):composed['semantic_assertion_evidence']=dict(source_contract_sha256=pack['semantic_assertion_obligations']['canonical_sha256'],evidence={x['assertion_id']:x['evidence']for x in core['semantic_assertions']if x['polarity']=='required'and x['dimension']!='character_response'})
  # No canonical profile evidence is manufactured from retrieved candidates.
  out=dest/'baseline-composition';assert not out.exists();dump(out/'composed.json',composed)
  cmd=[PYTHON,str(s/'audit_composed_prompt.py'),'--pack',str(dest/'pack.json'),'--composed',str(out/'composed.json')];proc=subprocess.run(cmd,cwd=root,env=environment(),capture_output=True,text=True,timeout=600);dump(out/'cli.json',dict(command=cmd,exit_code=proc.returncode,stdout=proc.stdout,stderr=proc.stderr))
  result=json.loads(proc.stdout);dump(out/'audit.json',result)
  rows.append(dict(id=case,status=result['status'],baseline_audit_executed=True,prompt_sha256=hashlib.sha256(prompt.encode()).hexdigest(),failures=result['failures'],warnings=result.get('warnings',[]),optional_candidates_adopted=0))
  dump(P/'baseline-audit-report.json',reports);print(arm,case,result['status'],[(x.get('check'),x.get('reason'))for x in result['failures']],flush=True)
 verify()
dump(P/'baseline-audit-report.json',reports);dump(P/'baseline-audit-complete.json',dict(all8_accounted_for=True,baseline_text_unchanged=True,optional_adoptions=0,frozen_hashes_verified=True))
