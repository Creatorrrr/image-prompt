"""Create independent current/counterfactual trees; never run holdout retrieval."""
from pathlib import Path
import copy,hashlib,json,os,shutil,subprocess,sys,tarfile
from unittest.mock import patch
sys.dont_write_bytecode=True
P=Path(__file__).resolve().parent;R=P.parents[2]/'image-prompt';PIN='31dbed9f0d22af97025cebcbceffc07b4250de35';OLD='5bf8142304f484138474fff4af9b0660439fa331';SKILL='skills/photo-prompt-image-generator';ASSET=SKILL+'/assets/';FACT=P/'factual';COUNTER=P/'counterfactual';CACHE=P/'cache';CACHE.mkdir(exist_ok=True)
def git(*a,binary=False):return subprocess.check_output(['git',*a],cwd=R,**({}if binary else{'text':True}))
def js(ref,path):return json.loads(git('show',ref+':'+path))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def digest(x):return hashlib.sha256(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def dump(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
assert git('rev-parse','HEAD').strip()==PIN and not git('status','--porcelain').strip();assert not FACT.exists()and not COUNTER.exists(),'Never overwrite an arm'
semantic=js(PIN,ASSET+'photo_prompt_semantic_index.json');active_shards={ASSET+x['path']for x in semantic['shards']}
tracked=git('ls-tree','-r','--name-only',PIN,SKILL,'docs/research-evidence/photo-prompt/extension-maintenance').splitlines()
selected=[x for x in tracked if '/photo_prompt_semantic_index_shards/'not in x or x in active_shards]
assert active_shards<=set(selected)
FACT.mkdir();proc=subprocess.Popen(['git','archive',PIN,'--',*selected],cwd=R,stdout=subprocess.PIPE)
with tarfile.open(fileobj=proc.stdout,mode='r|')as tf:
 for member in tf:
  if not member.isfile():continue
  assert member.name in selected and '..'not in Path(member.name).parts
  dest=FACT/member.name;dest.parent.mkdir(parents=True,exist_ok=True)
  with tf.extractfile(member)as src,dest.open('wb')as out:shutil.copyfileobj(src,out)
assert proc.wait()==0
factual_hashes={x:sha(FACT/x)for x in selected};assert len(factual_hashes)==len(selected)
shutil.copytree(FACT,COUNTER)
base=ASSET+'photo_prompt_visual_obligations.json';era=ASSET+'photo_prompt_visual_obligations_photo_era.json';idxpath=ASSET+'photo_prompt_visual_profile_index.json'
specs=[('mounted_slide_transparency_object_relation',era),('ghost_ship_former_vessel_breach',base),('biaoju_guarded_cargo_departure',base),('auroral_arc_curtain_atmosphere',base),('oneiric_dream_logic_discontinuity',base)]
source_changes=[]
for rel in [base,era]:
 current=json.loads((COUNTER/rel).read_text());older=js(OLD,rel);old_profiles={p['id']:p for p in older['profiles']}
 for pid,path in specs:
  if path!=rel:continue
  i=next(i for i,p in enumerate(current['profiles'])if p['id']==pid);before=copy.deepcopy(current['profiles'][i]);assert before!=old_profiles[pid]
  current['profiles'][i]=copy.deepcopy(old_profiles[pid]);source_changes.append(dict(profile_id=pid,source_file=rel,factual_record_sha256=digest(before),counterfactual_record_sha256=digest(old_profiles[pid])))
 dump(COUNTER/rel,current)
# Keep one historical exact vector cache outside both runtime trees. Current cache takes
# precedence for every matching current semantic document; only old-text targets fall back.
(CACHE/'pre-data25-visual-index.json').write_bytes(git('show',OLD+':'+idxpath,binary=True))
sys.path.insert(0,str(FACT/SKILL/'scripts'));import prompt_generator as pg;import build_visual_profile_index as builder
with patch.object(pg,'embed_texts_with_gemini',side_effect=AssertionError('provider forbidden')),patch.object(builder,'embed_texts_with_gemini',side_effect=AssertionError('provider forbidden')),patch('socket.create_connection',side_effect=AssertionError('network forbidden')):
 fr=pg.load_visual_obligation_registry(FACT/base);cr=pg.load_visual_obligation_registry(COUNTER/base)
 fm={p['id']:p for p in fr['profiles']};cm={p['id']:p for p in cr['profiles']};assert fm.keys()==cm.keys()
 changed_profiles=sorted(pid for pid in fm if fm[pid]!=cm[pid]);assert changed_profiles==sorted(pid for pid,_ in specs)
 fi=pg.load_visual_profile_index(FACT/idxpath,fr);opts=dict(provider=fi['provider'],model=fi['embedding_model'],dimensions=fi['embedding_dimensions'])
 vectors=builder.reusable_vectors([CACHE/'pre-data25-visual-index.json',FACT/idxpath],cr,**opts);assert set(vectors)==set(cm)
 ci=pg.build_visual_profile_index_payload(cr,vectors=vectors,**opts);pg.validate_visual_profile_index_metadata(ci,cr,**opts)
 oldcache=json.loads((CACHE/'pre-data25-visual-index.json').read_text());text_changed=sorted(pid for pid in fm if pg.visual_profile_semantic_text(fm[pid])!=pg.visual_profile_semantic_text(cm[pid]));assert text_changed==['biaoju_guarded_cargo_departure','mounted_slide_transparency_object_relation']
 for pid in cm:
  wanted=oldcache['entries'][pid]if pid in text_changed else fi['entries'][pid]
  assert ci['entries'][pid]==wanted,(pid,'exact cached text/hash/vector not preserved')
 dump(COUNTER/idxpath,ci)
 # Upstream religion data, all unrelated profile records, all other assets and runtime
 # remain unchanged. Only global retrieval statistics legitimately rebuild for 2 docs.
 assert fi['exact_lookup']==ci['exact_lookup']
 bmchanged=sorted(pid for pid in fi['bm25f']['documents']if fi['bm25f']['documents'][pid]!=ci['bm25f']['documents'][pid]);assert bmchanged==text_changed
 for registry,tree in [(fr,FACT),(cr,COUNTER)]:
  loaded=pg.load_visual_profile_index(tree/idxpath,registry);assert len(loaded['entries'])==len(cm)
changed_files=[x for x in selected if sha(FACT/x)!=sha(COUNTER/x)];assert sorted(changed_files)==sorted([base,era,idxpath])
runtime=[x for x in selected if x.startswith(SKILL+'/scripts/')or x.startswith(SKILL+'/precore/')];assert all(sha(FACT/x)==sha(COUNTER/x)for x in runtime)
assert factual_hashes=={x:sha(FACT/x)for x in selected}
assert git('rev-parse','HEAD').strip()==PIN and not git('status','--porcelain').strip()
dump(P/'snapshot-manifest.json',dict(pin=PIN,counterfactual_target_origin=OLD,selected_file_count=len(selected),omitted_inactive_historical_shard_files=len(tracked)-len(selected),active_semantic_shards=sorted(active_shards),factual_hashes=factual_hashes,counterfactual_hashes={x:sha(COUNTER/x)for x in selected},changed_files=changed_files,source_profile_changes=source_changes,changed_profile_ids=changed_profiles,unchanged_profile_count=len(cm)-len(specs),total_profiles=len(cm),runtime_file_count=len(runtime),all_runtime_files_identical=True,changed_embedding_document_ids=text_changed,changed_BM25F_document_ids=bmchanged,all_other_index_entries_identical=True,exact_lookup_identical=True,general_semantic_index_and_active_shards_identical=True,old_vector_cache_sha256=sha(CACHE/'pre-data25-visual-index.json'),provider_calls=0,retrieval_calls=0,holdout_texts_accessed=False,live_checkout_unchanged=True))
print('Snapshot arms created:',len(selected),'files each;',len(cm),'profiles; exactly five source-record changes and two exact historical vectors.')
