"""Non-retrieval runtime loading and exact source/index metadata validation."""
from pathlib import Path
import hashlib,json,sys
from unittest.mock import patch
sys.dont_write_bytecode=True
P=Path(__file__).resolve().parent;arm=sys.argv[1];assert arm in ['factual','counterfactual'];root=P/arm;skill=root/'skills/photo-prompt-image-generator';sys.path.insert(0,str(skill/'scripts'))
import prompt_generator as pg
assert Path(pg.__file__).resolve().is_relative_to(root)
with patch.object(pg,'embed_texts_with_gemini',side_effect=AssertionError('provider forbidden')),patch.object(pg,'resolve_visual_profile_hits',side_effect=AssertionError('retrieval forbidden before fixture freeze')),patch.object(pg,'generate_candidate_pack',side_effect=AssertionError('generation forbidden before fixture freeze')),patch('socket.create_connection',side_effect=AssertionError('network forbidden')):
 data=pg.load_runtime_data();reg=data[pg.VISUAL_OBLIGATIONS_DATA_KEY];idx=data[pg.VISUAL_PROFILE_INDEX_DATA_KEY];sem=data[pg.SEMANTIC_INDEX_DATA_KEY]
 pg.validate_visual_profile_index_metadata(idx,reg,provider=idx['provider'],model=idx['embedding_model'],dimensions=idx['embedding_dimensions'])
 pg.validate_semantic_index_metadata(sem,data)
 vec={pid:r['vector']for pid,r in idx['entries'].items()}
 reconstructed=pg.build_visual_profile_index_payload(reg,vectors=vec,provider=idx['provider'],model=idx['embedding_model'],dimensions=idx['embedding_dimensions']);assert reconstructed==idx
 for p in reg['profiles']:
  pid=p['id'];t=pg.visual_profile_semantic_text(p);e=idx['entries'][pid];assert e['text']==t and e['text_sha256']==hashlib.sha256(t.encode()).hexdigest();assert len(e['vector'])==idx['embedding_dimensions']
 report=dict(arm=arm,status='PASS_NON_RETRIEVAL_METADATA_VALIDATION',module_path=str(Path(pg.__file__).resolve()),profiles=len(reg['profiles']),general_semantic_entries=len(sem['entries']),visual_index_exact_reconstruction=True,all_visual_text_hash_dimensions_valid=True,runtime_load_and_both_index_metadata_valid=True,query_retrieval_calls=0,provider_calls=0,holdout_inputs_loaded=False,python=sys.version,python_executable=sys.executable)
(P/(arm+'-metadata.json')).write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
