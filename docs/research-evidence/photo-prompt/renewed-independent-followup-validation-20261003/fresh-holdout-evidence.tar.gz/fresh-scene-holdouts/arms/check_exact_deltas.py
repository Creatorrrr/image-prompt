from pathlib import Path
import hashlib,json,subprocess
P=Path(__file__).resolve().parent;R=P.parents[2]/'image-prompt';M=json.loads((P/'snapshot-manifest.json').read_text());BASE='skills/photo-prompt-image-generator/assets/'
def git_json(ref,path):return json.loads(subprocess.check_output(['git','show',ref+':'+path],cwd=R,text=True))
def by(x,pid):return next(p for p in x['profiles']if p['id']==pid)
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def diff(a,b,p=''):
 if type(a)!=type(b):return [dict(path=p,factual=a,counterfactual=b)]
 if isinstance(a,dict):return [v for k in sorted(a.keys()|b.keys())for v in ([dict(path=p+'/'+k,factual=a.get(k),counterfactual=b.get(k))]if k not in a or k not in b else diff(a[k],b[k],p+'/'+k))]
 if isinstance(a,list):
  if len(a)!=len(b):return []if a==b else[dict(path=p,factual=a,counterfactual=b)]
  return [v for i,(x,y)in enumerate(zip(a,b))for v in diff(x,y,p+'/'+str(i))]
 return []if a==b else[dict(path=p,factual=a,counterfactual=b)]
specs=[('2c4e06ea','mounted_slide_transparency_object_relation','photo_prompt_visual_obligations_photo_era.json'),('280ea12d','ghost_ship_former_vessel_breach','photo_prompt_visual_obligations.json'),('53de5652','biaoju_guarded_cargo_departure','photo_prompt_visual_obligations.json'),('120f07d0','auroral_arc_curtain_atmosphere','photo_prompt_visual_obligations.json'),('31dbed9f','oneiric_dream_logic_discontinuity','photo_prompt_visual_obligations.json')]
rows=[]
for ref,pid,file in specs:
 rel=BASE+file;f=by(read(P/'factual'/rel),pid);c=by(read(P/'counterfactual'/rel),pid);published=by(git_json(ref,rel),pid);parent=by(git_json(ref+'^',rel),pid)
 assert f==published and c==parent and c==by(git_json(M['counterfactual_target_origin'],rel),pid)
 rows.append(dict(profile_id=pid,accepted_publication=ref,factual_equals_accepted_publication=True,counterfactual_equals_publication_parent_and_pre_DATA25=True,exact_removed_correction=diff(f,c)))
for arm in ['factual','counterfactual']:assert all(sha(P/arm/f)==h for f,h in M[arm+'_hashes'].items())
assert read(P/'factual-metadata.json')['status']==read(P/'counterfactual-metadata.json')['status']=='PASS_NON_RETRIEVAL_METADATA_VALIDATION'
report=dict(status='PASS_EXACT_ACCEPTED_CORRECTIONS_ONLY',profiles=rows,other_1559_profiles_identical=True,all_runtime_files_identical=True,only_three_asset_files_differ=M['changed_files'],snapshot_hashes_stable_after_validation=True,holdout_retrieval_executed=False,author_inputs_accessed=False)
(P/'exact-delta-proof.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items()if k!='profiles'},indent=2))
