# Fresh holdout snapshot arms: READY, retrieval not started

Factual pin: `31dbed9f0d22af97025cebcbceffc07b4250de35`.
Counterfactual target-record origin: `5bf8142304f484138474fff4af9b0660439fa331`.

## Isolated runtime roots

- `factual/`: current pinned skill/data
- `counterfactual/`: identical current runtime and upstream data with only DATA25–29's five target profile corrections removed

Each arm contains 202 tracked files (about 140 MB), including the complete current photo skill runtime/precore/references/assets, extension-maintenance records, and all 16 actively referenced general semantic shards. Only 208 inactive historical shard files and unrelated repository/report archives are omitted. These are independent file copies, not symlinks or hardlinks to the live checkout; they are not git worktrees.

The live checkout was clean and remained unchanged. No credentials or `.env` were copied. The existing interpreter `REPOSITORY_ROOT/.venv/bin/python` (Python 3.12.14) was used identically for both arms; its environment is not duplicated inside the snapshots.

## Exact counterfactual

Only these current records are replaced with their exact pre-DATA25 versions:

- `mounted_slide_transparency_object_relation` (photo-era registry)
- `ghost_ship_former_vessel_breach`
- `biaoju_guarded_cargo_departure`
- `auroral_arc_curtain_atmosphere`
- `oneiric_dream_logic_discontinuity`

`check_exact_deltas.py` proves that factual records equal each accepted publication, and counterfactual records equal both the relevant publication parent and pre-DATA25 pin. Thus the rollback removes exactly the accepted corrections, with no independent upstream edits removed from inside a target record.

All other 1,559 compiled profiles, every unrelated asset, all 27 script/precore runtime files, and current religion/iconography authored semantics remain identical. The only differing files between arms are the two affected registry files and the bound visual index. Both arms have 1,564 visual profiles and 9,819 general semantic entries. Current independent upstream runtime and extensions are preserved; this counterfactual is not a historical whole-product checkout.

## Cached-vector-only index construction

Counterfactual visual index is reconstructed with actual current builder helpers and exact cached vectors. The only changed embedding documents and BM25F documents are the old mounted-slide and convoy texts. Their entries (text, hash, vector) exactly match the pre-DATA25 cached index; all 1,562 remaining entries exactly match the current factual index. All vectors were available, so no provider call occurred. Exact-lookup rows are identical. The general index and active shards are byte-identical between arms.

`cache/pre-data25-visual-index.json` preserves vector provenance outside both runtime trees. Global visual BM25F statistics and registry fingerprint are legitimately rebuilt to reflect the two old documents; no stale source binding or vector-for-wrong-text substitution is used.

## Validation completed without querying candidates

Both arms passed:

- Supported public `generate_photo_prompt.py --help` import/argument validation
- Full dictionary/source metadata CLI validator
- Actual `load_runtime_data()` and both visual/general index metadata validation
- Exact reconstruction of the complete visual index from its own source/vectors
- Every visual semantic text/hash/vector-dimension check
- Snapshot hash stability after validation

Query retrieval, candidate-pack generation, provider entrypoints and network connection were explicitly blocked in the validation loader. No holdout text or author file was opened. No query, retrieval, composed holdout audit, rendering or publication has run.

Public CLI generation is intentionally not yet smoke-tested with a scene because holdouts must first be frozen. The parser, imports, data loading and metadata path are verified; end-to-end scene generation belongs to the later authorized fixture runner. That runner should invoke each arm's own script by absolute path, use the same external interpreter and seed, and verify `snapshot-manifest.json` before/after each arm. Do not assume `.venv` or `.git` exists inside an arm.

## Evidence and handoff

- `snapshot-manifest.json`: every selected source file hash in each arm, exact five IDs and two old-vector IDs
- `exact-delta-proof.json`: complete exact five-profile differences and publication-parent identity proof
- `factual-metadata.json`, `counterfactual-metadata.json`: validated counts and runtime module paths
- `*-cli-help-cli.json`, `*-dictionary-cli.json`, `*-metadata-cli.json`: actual commands/results
- `prepare_arms.py`, `validate_arm.py`, `check_exact_deltas.py`: reproducible preparation/checks
- `readiness.json`: explicit retrieval hold

Wait for frozen fresh inputs and parent fixture-runner assignment before running retrieval. Do not disclose either arm's candidate data, correction details or expected outcomes to the unexposed author.
