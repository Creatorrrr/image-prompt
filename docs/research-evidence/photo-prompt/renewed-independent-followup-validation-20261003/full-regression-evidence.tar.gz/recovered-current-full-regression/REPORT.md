# Recovered current DATA28 isolated full regression

Pinned snapshot: 120f07d025340bd067097f947ca23d4dd828e7cf. Future main changes are outside this result.

Every discovered module completed: 149 modules, 1302 test methods, 1297 successful methods, 5 unsuccessful methods. Unittest aggregate: 10 assertion/subtest failures, 1 errors, 0 skips, 0 expected failures and 0 unexpected successes. Exactly 1302 discovered IDs reconcile with 1302 executed IDs as multisets. No excluded module, missing ID or test rerun.

Compared with historical 1284 tests / 1279 successful methods / 5 unsuccessful methods: 0 new failure identities, 0 resolved historical identities; every retained normalized trace identical: True. Exact additions and removals are in discovery-delta.json. Historical baseline was extracted from the checked-in retrieval-runtime-improvement-20261003 test-summary and its selected raw module records, rather than assuming older 1241-suite membership.

The suite remains red: the historical missing-asset failures are still present. Historical missing-asset identities are not waived: Korean emotional has absent external references (3 subtests); makeup has zero frozen cores instead of five and missing shared/source_observation.json (1 failure, 1 error); poverty has missing rendered-result files (3 subtests); rare-photo has missing request-envelope artifacts (3 subtests). Full current tracebacks and normalized comparisons are in historical-comparison.json. Any new or changed trace requires separate diagnosis; the summary never counts it as historical solely from similar totals.

Started 2026-10-03T09:16:14.192903+00:00; finished 2026-10-03T10:22:54.313144+00:00. Summed module wall time 3998.7s. The prior inspected module-isolated method was reused on a detached exact-commit worktree with its own local files and the existing interpreter. No package installations, source edits, test rewrites, synthesized missing assets, provider calls or image generation. Provider/API/auth secret environment variables were removed; four main provider keys were explicitly absent. Every actual command, cwd, timestamp, exit, test-file hash and output hash is retained.

Tracked snapshot sources preserved: True. Snapshot HEAD unchanged: True. Final snapshot status clean: True. Only the temporary .venv symlink was removed; its existing target is untouched. Raw evidence remains under this durable regression directory.

Key artifacts: summary.json, module-suite-results.json, module-reconciliation.json, discovered-test-ids.json, executed-test-ids.json, discovery-delta.json, historical-comparison.json, historical-1284/, all module-logs/, setup.log, launcher timestamps/exit, cleanup.json and snapshot-status-final.txt.

## Separate current-checkout availability check

At 2026-10-03 10:24:15 UTC the live checkout remained at `31dbed9f0d22af97025cebcbceffc07b4250de35` throughout a read-only availability check. All ten per-case failed-path checks (eight unique paths, including one shared external reference) remain absent in both the immutable snapshot and live checkout. The makeup frozen-core glob finds zero of the required five cores in both. Three additional downstream rare-photo core dependencies also remain absent. The four relevant test source files and four fixture manifests are byte-identical across the two pins.

This check only establishes path availability at that moment. It does not execute the live suite or extend the pinned full-suite result to newer main. See `live-asset-availability.json` for exact path classifications and hashes. No files were downloaded, synthesized or changed.
