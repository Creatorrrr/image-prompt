import collections, datetime, hashlib, json, os, pathlib, re, subprocess, time
OUT = pathlib.Path(__file__).resolve().parent
ROOT = OUT / 'snapshot'
PIN = '120f07d025340bd067097f947ca23d4dd828e7cf'
PYTHON = str(ROOT / '.venv/bin/python')

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def dump(name, value):
    path = OUT / name
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')
    temporary.replace(path)

env = os.environ.copy()
removed_names = sorted(k for k in env if re.search(r'(?:API_?KEY|TOKEN|SECRET|PASSWORD|CREDENTIAL|AUTH|PRIVATE_KEY)', k, re.I) or k in ('GOOGLE_APPLICATION_CREDENTIALS','AWS_ACCESS_KEY_ID','AWS_SECRET_ACCESS_KEY'))
for key in removed_names:
    env.pop(key)
for key in ('GEMINI_API_KEY','GOOGLE_API_KEY','OPENAI_API_KEY','ANTHROPIC_API_KEY'):
    env.pop(key, None)
env['PYTHONDONTWRITEBYTECODE'] = '1'
head = subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
assert head == PIN, head
assert (ROOT/'.venv').is_symlink() and (ROOT/'.venv/bin/python').is_file()
(OUT/'commit.txt').write_text(head+'\n')
(OUT/'snapshot-status-before.txt').write_text(subprocess.check_output(['git','status','--porcelain=v1'],cwd=ROOT,text=True))
files = sorted((ROOT/'tests').glob('test*.py'))
manifest = {'commit':head,'started_utc':now(),'strategy':'Sequential fresh subprocess per original discovery-pattern module, no exclusions; snapshot-relative existing environment supplied before discovery and testing. No monolithic attempt.','environment':{'removed_variable_names':removed_names,'always_absent_provider_keys':['GEMINI_API_KEY','GOOGLE_API_KEY','OPENAI_API_KEY','ANTHROPIC_API_KEY'],'PYTHONDONTWRITEBYTECODE':'1','venv_target':str((ROOT/'.venv').resolve()),'installations':False},'test_files':[str(f.relative_to(ROOT)) for f in files],'results':[]}
# Complete original unittest discovery, without executing tests, preserves every ID occurrence.
inventory_code = '''import collections,json,pathlib,unittest
loader=unittest.TestLoader()
suite=loader.discover("tests",pattern="test*.py")
def flatten(item):
 if isinstance(item,unittest.TestSuite):
  for child in item: yield from flatten(child)
 else: yield item.id()
ids=list(flatten(suite))
pathlib.Path(OUTFILE).write_text(json.dumps(ids,indent=2)+"\\n")
pathlib.Path(METAFILE).write_text(json.dumps({"count":len(ids),"module_counts":dict(sorted(collections.Counter(i.split(".")[0] for i in ids).items())),"loader_errors":loader.errors},indent=2)+"\\n")
print("Discovered",len(ids),"test IDs;",len(loader.errors),"loader errors")
'''.replace('OUTFILE',repr(str(OUT/'discovered-test-ids.json'))).replace('METAFILE',repr(str(OUT/'discovery-details.json')))
cmd=[PYTHON,'-c',inventory_code]
t0=time.monotonic(); start=now()
with (OUT/'discovery.log').open('w') as log:
    discovery=subprocess.run(cmd,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT)
manifest['discovery']={'command':cmd,'cwd':str(ROOT),'started_utc':start,'finished_utc':now(),'seconds':time.monotonic()-t0,'exit_code':discovery.returncode}
dump('module-suite-progress.json',manifest)
if discovery.returncode:
    raise SystemExit('Discovery failed; retained exact command and log')
meta=json.loads((OUT/'discovery-details.json').read_text())
if meta['loader_errors']:
    raise SystemExit('Discovery has loader errors; preserved inventory and details')
assert set(meta['module_counts']) == {f.stem for f in files}, 'Discovery module set mismatch'
print(f"Pinned {head}; discovered {meta['count']} tests across {len(files)} modules",flush=True)
logs=OUT/'module-logs'; logs.mkdir(exist_ok=True)
for i,file in enumerate(files):
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==PIN
    cmd=[PYTHON,'-m','unittest','discover','-s','tests','-p',file.name,'-v']
    start=now(); t0=time.monotonic()
    log_path=logs/(file.stem+'.log')
    with log_path.open('w') as log:
        process=subprocess.run(cmd,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT)
    text=log_path.read_text()
    labels=re.findall(r'^(?:FAIL|ERROR): (.+)$',text,re.M)
    ran=re.search(r'^Ran (\d+) tests?',text,re.M)
    result={'test_file':str(file.relative_to(ROOT)),'sha256':hashlib.sha256(file.read_bytes()).hexdigest(),'command':cmd,'cwd':str(ROOT),'started_utc':start,'finished_utc':now(),'exit_code':process.returncode,'seconds':time.monotonic()-t0,'log':str(log_path.relative_to(OUT)),'log_sha256':hashlib.sha256(log_path.read_bytes()).hexdigest(),'reported_tests':int(ran[1]) if ran else None,'failure_error_labels':labels}
    manifest['results'].append(result)
    dump('module-suite-progress.json',manifest)
    print(f"{i+1}/{len(files)} {file.name}: exit {process.returncode}, {result['reported_tests']} tests, {result['seconds']:.2f}s",flush=True)
    if labels:
        print(json.dumps({'module':file.name,'failure_error_labels':labels},ensure_ascii=False),flush=True)
manifest['finished_utc']=now()
manifest['tracked_diff_exit_code']=subprocess.run(['git','diff','--exit-code','HEAD'],cwd=ROOT,stdout=(OUT/'tracked-diff-after.log').open('w'),stderr=subprocess.STDOUT).returncode
dump('module-suite-results.json',manifest)
(OUT/'snapshot-status-after.txt').write_text(subprocess.check_output(['git','status','--porcelain=v1'],cwd=ROOT,text=True))
print('All module subprocesses finished',flush=True)
