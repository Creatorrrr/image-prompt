#!/usr/bin/env bash
set -u
cd EVIDENCE_ROOT/recovered-current-full-regression
printf '%s\n' 'PYTHONDONTWRITEBYTECODE=1 ./snapshot/.venv/bin/python run-module-suite.py > module-runner.log 2>&1' > launcher-command.txt
date -u +%Y-%m-%dT%H:%M:%SZ > launcher-start-time.txt
PYTHONDONTWRITEBYTECODE=1 ./snapshot/.venv/bin/python run-module-suite.py > module-runner.log 2>&1
status=$?
printf '%s\n' "$status" > launcher.exit
date -u +%Y-%m-%dT%H:%M:%SZ > launcher-end-time.txt
exit "$status"
