import collections,datetime,hashlib,json,pathlib,re,subprocess
P=pathlib.Path(__file__).resolve().parent;R=P/'snapshot';PIN='120f07d025340bd067097f947ca23d4dd828e7cf';H=P/'historical-1284'
def read(p):return json.loads(p.read_text())
def save(n,x):(P/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def normalize_id(s):return s.removeprefix('tests.')
def normalize_trace(s):
 for root in [str(R),'/workspace/image-prompt']:s=s.replace(root,'<SNAPSHOT>')
 return s.strip()
def parse_log(text):
 ids=re.findall(r'^test\S+ \(([^)]+)\) \.\.\.',text,re.M)
 finals=list(re.finditer(r'^Ran (\d+) tests? in ([0-9.]+)s\s*\n\s*\n(OK(?: \([^\n]*\))?|FAILED \([^\n]+\))\s*$',text,re.M));assert len(finals)==1, len(finals)
 m=finals[0];counts=dict(tests=int(m[1]),failures=0,errors=0,skipped=0,expected_failures=0,unexpected_successes=0)
 for field,label in [('failures','failures'),('errors','errors'),('skipped','skipped'),('expected_failures','expected failures'),('unexpected_successes','unexpected successes')]:
  x=re.search(re.escape(label)+r'=(\d+)',m[3]);counts[field]=int(x[1])if x else 0
 fails=[]
 for block in text.split('='*70+'\n')[1:]:
  x=re.match(r'(FAIL|ERROR): (.*?)\n'+'-'*70+r'\n(.*)',block,re.S);assert x,block[:200]
  label=x[2];y=re.match(r'\S+ \(([^)]+)\)(.*)',label);assert y,label
  trace=re.split(r'\n'+'-'*70+r'\nRan \d+ tests?',x[3])[0].strip();fails.append(dict(kind=x[1],id=normalize_id(y[1]+y[2]),method_id=normalize_id(y[1]),label=label,traceback=trace))
 return ids,counts,fails
run=read(P/'module-suite-results.json');discovered=read(P/'discovered-test-ids.json');assert run['commit']==PIN
assert collections.Counter(run['test_files'])==collections.Counter(x['test_file']for x in run['results'])
executed=[];totals=collections.Counter();modules=[];current_failures=[]
for r in run['results']:
 assert sha(P/r['log'])==r['log_sha256'];assert sha(R/r['test_file'])==r['sha256'];ids,counts,failures=parse_log((P/r['log']).read_text());expected=[x for x in discovered if x.split('.')[0]==pathlib.Path(r['test_file']).stem];assert collections.Counter(ids)==collections.Counter(expected);assert len(ids)==counts['tests'];assert r['exit_code']==(1 if counts['failures']or counts['errors']or counts['unexpected_successes']else 0)
 modules.append(dict(**r,totals=counts,exact_discovered_ids_covered=True));executed+=ids;totals.update(counts);current_failures += [dict(**x,log=r['log'])for x in failures]
assert collections.Counter(discovered)==collections.Counter(executed);assert len(executed)==totals['tests'];save('executed-test-ids.json',executed);save('module-reconciliation.json',modules)
hist=read(H/'test-summary.json');historical={('FAIL'if k=='failures'else'ERROR',normalize_id(x['id'])):x for k in ['failures','errors']for x in hist[k]};current={(x['kind'],x['id']):x for x in current_failures};assert len(current)==len(current_failures)
new=[dict(kind=k[0],id=k[1],traceback=current[k]['traceback'])for k in current.keys()-historical.keys()];resolved=[dict(kind=k[0],id=k[1])for k in historical.keys()-current.keys()];comparisons=[]
for k in current.keys()&historical.keys():
 a=normalize_trace(historical[k]['traceback']);b=normalize_trace(current[k]['traceback']);comparisons.append(dict(kind=k[0],id=k[1],trace_identical_after_snapshot_root_normalization=a==b,historical_trace_sha256=hashlib.sha256(a.encode()).hexdigest(),current_trace_sha256=hashlib.sha256(b.encode()).hexdigest()))
comparison=dict(historical_tests=1284,historical_successful_methods=1279,historical_unsuccessful_methods=5,historical_failure_records=10,historical_error_records=1,new_failures=new,resolved_failures=resolved,retained=comparisons,current_failures=current_failures);save('historical-comparison.json',comparison)
assert run['tracked_diff_exit_code']==0;assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==PIN
cleanup=dict(action='Remove only temporary snapshot .venv symlink',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),target=str((R/'.venv').resolve()))
if (R/'.venv').is_symlink():(R/'.venv').unlink();cleanup['removed']=True
else:cleanup['removed']=False
save('cleanup.json',cleanup);status=subprocess.check_output(['git','status','--porcelain=v1'],cwd=R,text=True);(P/'snapshot-status-final.txt').write_text(status)
failed_methods=sorted({x['method_id']for x in current_failures});summary=dict(commit=PIN,scope='Immutable detached snapshot; all original discovered modules in fresh sequential subprocesses, no exclusions or reruns',totals=dict(totals),module_count=len(modules),passed_modules=sum(x['exit_code']==0 for x in modules),failed_modules=sum(x['exit_code']!=0 for x in modules),discovered_ids=len(discovered),executed_ids=len(executed),exact_id_multiset_match=True,duplicate_ids=[k for k,n in collections.Counter(executed).items()if n>1],unsuccessful_method_ids=failed_methods,unsuccessful_methods=len(failed_methods),successful_methods=totals['tests']-len(failed_methods)-totals['skipped']-totals['expected_failures']-totals['unexpected_successes'],new_failure_count=len(new),resolved_failure_count=len(resolved),historical_traces_identical=all(x['trace_identical_after_snapshot_root_normalization']for x in comparisons),discovery_errors=read(P/'discovery-details.json')['loader_errors'],started_utc=run['started_utc'],finished_utc=run['finished_utc'],module_wall_seconds=sum(x['seconds']for x in modules),snapshot_head_unchanged=True,snapshot_final_status_clean=not status,tracked_sources_preserved=True,provider_calls=0,images=0,skips_explicitly_reported=totals['skipped'],test_restarts=0)
save('summary.json',summary)
report=f'''# Recovered current DATA28 isolated full regression

Pinned snapshot: {PIN}. Future main changes are outside this result.

Every discovered module completed: {summary['module_count']} modules, {totals['tests']} test methods, {summary['successful_methods']} successful methods, {len(failed_methods)} unsuccessful methods. Unittest aggregate: {totals['failures']} assertion/subtest failures, {totals['errors']} errors, {totals['skipped']} skips, {totals['expected_failures']} expected failures and {totals['unexpected_successes']} unexpected successes. Exactly {len(discovered)} discovered IDs reconcile with {len(executed)} executed IDs as multisets. No excluded module, missing ID or test rerun.

Compared with historical 1284 tests / 1279 successful methods / 5 unsuccessful methods: {len(new)} new failure identities, {len(resolved)} resolved historical identities; every retained normalized trace identical: {summary['historical_traces_identical']}. Exact additions and removals are in discovery-delta.json. Historical baseline was extracted from the checked-in retrieval-runtime-improvement-20261003 test-summary and its selected raw module records, rather than assuming older 1241-suite membership.

The suite remains red: the historical missing-asset failures are still present. Historical missing-asset identities are not waived: Korean emotional has absent external references (3 subtests); makeup has zero frozen cores instead of five and missing shared/source_observation.json (1 failure, 1 error); poverty has missing rendered-result files (3 subtests); rare-photo has missing request-envelope artifacts (3 subtests). Full current tracebacks and normalized comparisons are in historical-comparison.json. Any new or changed trace requires separate diagnosis; the summary never counts it as historical solely from similar totals.

Started {run['started_utc']}; finished {run['finished_utc']}. Summed module wall time {summary['module_wall_seconds']:.1f}s. The prior inspected module-isolated method was reused on a detached exact-commit worktree with its own local files and the existing interpreter. No package installations, source edits, test rewrites, synthesized missing assets, provider calls or image generation. Provider/API/auth secret environment variables were removed; four main provider keys were explicitly absent. Every actual command, cwd, timestamp, exit, test-file hash and output hash is retained.

Tracked snapshot sources preserved: True. Snapshot HEAD unchanged: True. Final snapshot status clean: {not status}. Only the temporary .venv symlink was removed; its existing target is untouched. Raw evidence remains under this durable regression directory.

Key artifacts: summary.json, module-suite-results.json, module-reconciliation.json, discovered-test-ids.json, executed-test-ids.json, discovery-delta.json, historical-comparison.json, historical-1284/, all module-logs/, setup.log, launcher timestamps/exit, cleanup.json and snapshot-status-final.txt.
'''
(P/'REPORT.md').write_text(report);print(json.dumps(summary,indent=2));assert not status,status
