import collections,hashlib,json,tarfile
from pathlib import Path
P=Path(__file__).resolve().parent;ROOT=P/'snapshot';E=ROOT/'docs/research-evidence/photo-prompt/retrieval-runtime-improvement-20261003';summary=json.loads((E/'test-summary.json').read_text());H=P/'historical-1284';H.mkdir(exist_ok=True)
(H/'test-summary.json').write_bytes((E/'test-summary.json').read_bytes());ids=[];files=[]
with tarfile.open(E/'diagnostic-evidence.tar.gz','r:gz')as t:
 for module,name in sorted(summary['selected_logs'].items()):
  raw=t.extractfile(name).read();j=json.loads(raw);ids.extend(j['executed_ids']);files.append(dict(module=module,archive_member=name,sha256=hashlib.sha256(raw).hexdigest(),tests_run=j['tests_run']))
  if j['failures']or j['errors']:(H/(module+'.json')).write_bytes(raw)
assert len(ids)==1284 and len(set(ids))==1284
assert sum(x['tests_run']for x in files)==1284
(H/'executed-test-ids.json').write_text(json.dumps(ids,indent=2)+'\n');(H/'selected-record-manifest.json').write_text(json.dumps(dict(archive_sha256=hashlib.sha256((E/'diagnostic-evidence.tar.gz').read_bytes()).hexdigest(),records=files),indent=2)+'\n')
old=collections.Counter(x.removeprefix('tests.')for x in ids);current=collections.Counter(json.loads((P/'discovered-test-ids.json').read_text()));added=list((current-old).elements());removed=list((old-current).elements());delta=dict(historical_count=len(ids),current_count=sum(current.values()),added_ids=added,removed_ids=removed,added_module_counts=dict(collections.Counter(x.split('.')[0]for x in added)))
(P/'discovery-delta.json').write_text(json.dumps(delta,indent=2)+'\n');print(json.dumps(delta,indent=2))
