import datetime,hashlib,json,subprocess
from pathlib import Path
P=Path(__file__).resolve().parent;S=P/'snapshot';L=P.parent.parent/'image-prompt'
def head(r):return subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def readrows(root,name):return[json.loads(l)for l in(root/'tests/fixtures/photo_prompt'/name).read_text().splitlines()if l.strip()]
live_start=head(L);rows=[]
def add(kind,label,raw,observed=True):
 p=Path(raw);sp=p if p.is_absolute()else S/p;lp=p if p.is_absolute()else L/p
 rows.append(dict(kind=kind,label=label,path=raw,path_is_absolute=p.is_absolute(),snapshot_is_file=sp.is_file(),live_is_file=lp.is_file(),snapshot_exists=sp.exists(),live_exists=lp.exists(),reached_by_observed_failure=observed))
for x in readrows(S,'korean_emotional_photo_three_arm_pixel_cases_v1.jsonl'):add('korean_external_reference',x['arm_id'],x['reference']['path'])
add('makeup_source_observation','shared source observation','artifacts/photo-runs/20260831-makeup-reference-five-arm-v1/shared/source_observation.json')
for x in readrows(S,'poverty_visual_semantics_three_arm_pixel_cases_v1.jsonl'):add('poverty_render_result',x['arm_id'],x['result_path'])
for x in readrows(S,'rare_photo_three_arm_pixel_test_cases_v1.jsonl'):
 add('rare_request_envelope',x['arm_id'],x['request_envelope_path'])
 add('rare_authorial_core_downstream',x['arm_id'],x['authorial_core_path'],False)
pattern='artifacts/photo-runs/20260831-makeup-reference-five-arm-v1/arms/arm-*/authorial_core.json'
glob=dict(pattern=pattern,required_count=5,snapshot_matches=sorted(str(p.relative_to(S))for p in S.glob(pattern)),live_matches=sorted(str(p.relative_to(L))for p in L.glob(pattern)))
fixture_names=['korean_emotional_photo_three_arm_pixel_cases_v1.jsonl','makeup_reference_balance_cases_v1.jsonl','poverty_visual_semantics_three_arm_pixel_cases_v1.jsonl','rare_photo_three_arm_pixel_test_cases_v1.jsonl'];test_names=['test_photo_korean_emotional_visual_semantics.py','test_photo_makeup_reference_balance.py','test_photo_poverty_visual_semantics.py','test_photo_rare_photo_visual_semantics.py'];source_comparisons=[]
for rel in ['tests/'+x for x in test_names]+['tests/fixtures/photo_prompt/'+x for x in fixture_names]:
 a=S/rel;b=L/rel;source_comparisons.append(dict(path=rel,snapshot_sha256=sha(a),live_sha256=sha(b)if b.is_file()else None,identical=b.is_file()and a.read_bytes()==b.read_bytes()))
end=head(L);summary=dict(checked_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),snapshot_pin=head(S),live_head_start=live_start,live_head_end=end,live_head_stable=live_start==end,scope='Read-only availability check of exact snapshot failure paths mapped to current checkout; no live tests run, no contents synthesized or downloaded',paths=rows,makeup_core_glob=glob,test_and_fixture_source_comparisons=source_comparisons,observed_failure_path_count=sum(x['reached_by_observed_failure']for x in rows),observed_failure_paths_available_in_snapshot=sum(x['snapshot_is_file']for x in rows if x['reached_by_observed_failure']),observed_failure_paths_available_in_live=sum(x['live_is_file']for x in rows if x['reached_by_observed_failure']))
(P/'live-asset-availability.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({k:v for k,v in summary.items()if k not in ['paths','test_and_fixture_source_comparisons']},indent=2));print('source comparisons',[(x['path'],x['identical'])for x in source_comparisons])
