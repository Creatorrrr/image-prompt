from pathlib import Path
p=Path(__file__).resolve().parent
ns={'__file__':str(p/'finalize.py')};exec((p/'finalize.py').read_text().split("run=read(P/'module-suite-results.json')")[0],ns)
read=ns['read'];run=read(p/'module-suite-progress.json');hist=read(p/'historical-1284/test-summary.json');old={(('FAIL'if k=='failures'else'ERROR'),ns['normalize_id'](x['id'])):x for k in ['failures','errors']for x in hist[k]};bad=[];retained=[]
for row in run['results']:
 if not row['exit_code']:continue
 _,_,failures=ns['parse_log']((p/row['log']).read_text())
 for f in failures:
  k=(f['kind'],f['id']);same=k in old and ns['normalize_trace'](f['traceback'])==ns['normalize_trace'](old[k]['traceback'])
  (retained if same else bad).append(dict(kind=f['kind'],id=f['id'],historical_trace_identical=same,log=row['log'],**({'traceback':f['traceback']}if not same else{})))
summary=dict(completed_modules=len(run['results']),total_modules=len(run['test_files']),completed_tests=sum(x['reported_tests']or 0 for x in run['results']),historical_records_retained=retained,new_or_changed_failures=bad)
ns['save']('progress-review.json',summary);print(ns['json'].dumps(summary,indent=2))
