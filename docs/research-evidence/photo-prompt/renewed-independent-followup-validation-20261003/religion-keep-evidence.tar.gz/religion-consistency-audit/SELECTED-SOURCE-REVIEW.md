# Selected source and alternative checks

This audit reviews independent upstream religion/iconography work. It does not reattribute its 54 profiles, sources, candidate authoring, embeddings or historical image attempts to the maintenance loop.

## Preserve selected variants

- ri_body_mandorla is explicitly the selected almond-shaped full-body enclosure, distinct from ri_head_halo. The local National Gallery object scope does not authorize loosening all aureoles into generic glow or head-only circles
- ri_chakra_blue12 versus ri_chakra_white2 and ri_durga_eight versus ri_durga_four are documented selected forms. Different counts and relations are not interchangeable lexical alternatives
- ri_centaur_rimmer_form retains original truncated sculpture arms; ri_naga_seven_hood preserves the selected fragment condition. The generic per-gate requirement for all required parts does not require reconstructing missing original anatomy. Required fragment/truncation states remain explicit
- ri_buraq_golconda is the selected independent riderless composite form; a ridden Buraq from another tradition or object would need a different selected scope
- Actor-relative hands, feet, attributes and ownership in Nataraja and Ganesha remain exact. No viewer-relative reversal or generic attribute substitution is justified

## Apparent alternatives that do not justify a leaf repair

ri_sanshin_old_tiger: overview says “beside or against,” but the same definition declares the selected complete form to be sitting leaning against a separate tiger. The source unit's Korean observable component also describes the tiger against which the figure leans. Exact activation selects that complete relation, not a generic Sanshin name. Retain the narrow selected variant; a beside-only alternative would need a distinct source/selection decision and complete multi-surface review, not an evidence synonym.

ri_eleousa_contact: overview permits cheek or neck contact. The detailed component says the face rises toward the Virgin's neck-and-cheek region; the contact component says the two faces retain close selected contact. It does not say that the face must contact both anatomical surfaces simultaneously. Preserve contact rather than replacing the documented separate-face ri_virgin_hybrid_variant with it. Both derive from the local museum contrast, whose limitations remain recorded; no extra universal Eleousa rule is inferred.

ri_stupa_path: “outside and around” is relative to the central stupa structure, not a requirement that the path lie outside the surrounding railing. Source and selected relation retain central structure, railing and circulation. No unsupported gate-side alternative repair.

ri_siren_human_bird retains human head OR upper body throughout the English canonical branch. ri_tsukumogami_object_body retains face OR limbs. Neither requires every alternative at once. ri_meso_horn_crown and ri_daoist_robe_xuanwu correctly keep horn tiers on the crown and snake/tortoise motifs on cloth rather than changing wearer anatomy.

## Limits kept intact

ri_odin_attributes requires a readable chosen represented eye state and two separate ravens; it does not license inferring an absent eye from occlusion. ri_sema_motion_evidence explicitly treats turning as a still-frame suggestion, not proof of continuous rotation. Represented deities, garments and attributes do not establish any real person's faith, identity, consent, efficacy or hidden history.

All54 linked research units are marked CURATORIAL_DESCRIPTION, with reference-pixel inspection not performed. The linked source-use records include52 PAGE_TEXT_RETURNED and5 SEARCH_EXCERPT_ONLY entries (source use counts, not distinct webpages). The excerpt-only links concern ri_cham_mask_performer, ri_tsukumogami_object_body, ri_hyakki_scroll and ri_babayaga_hut. Preserve those access limitations and defer stronger primary-reference/pixel claims. This audit did not fetch primary webpages/images or upgrade source status.

The upstream integration's own RESULTS.md records six historical native-image attempts and failed pixel outcomes, and expressly does not generalize success to all54 profiles/80 candidates. Those failures remain upstream history; this consistency audit does not rerun or convert them to passes.
