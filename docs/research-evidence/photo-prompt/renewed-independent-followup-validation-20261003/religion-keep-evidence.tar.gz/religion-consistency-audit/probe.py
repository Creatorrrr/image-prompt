from pathlib import Path
import json,sys,hashlib,subprocess
sys.dont_write_bytecode=True
O=Path(__file__).resolve().parent;R=O.parent.parent/'image-prompt';S=R/'skills/photo-prompt-image-generator/scripts';A=S.parent/'assets';sys.path.insert(0,str(S));import prompt_generator as g
D=lambda p:json.loads(p.read_text());H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def W(n,x):(O/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
rawpath=A/'photo_prompt_visual_obligations_religion_iconography.json';extension=A/'photo_prompt_religion_iconography_extension.json';raw=D(rawpath);ids={x['id']for x in raw['profiles']};assert len(ids)==54
research=R/'docs/research-evidence/photo-prompt/religion-myth-iconography-20261003';integration=R/'docs/research-evidence/photo-prompt/religion-myth-integration-20261003';units={x['unit_id']:x for x in D(research/'SEMANTIC-UNITS.json')['units']};sources={x['source_id']:x for x in D(research/'SOURCES.json')['sources']};mapping=[x for x in D(integration/'MAINTENANCE.json')['mappings']if x.get('profile_id')in ids];assert len(mapping)==54;mapping={x['profile_id']:x for x in mapping}
files=[rawpath,extension,S/'prompt_generator.py',S/'visual_profile_contracts.py',S/'audit_composed_prompt.py',research/'SEMANTIC-UNITS.json',research/'SOURCES.json',research/'VARIANT-RELATIONS.json',research/'RESEARCH.md',integration/'MAINTENANCE.json',integration/'INTEGRATION.md',integration/'RESULTS.md'];start={str(f.relative_to(R)):H(f)for f in files}
reg=g.load_visual_obligation_registry(A/'photo_prompt_visual_obligations.json');byid={x['id']:x for x in reg['profiles']};records=[];omissions=[];exact=[]
for p in raw['profiles']:
 id=p['id'];loaded=byid[id];mat=g.candidate_pack_visual_profile_obligation(p,reg,activation_source='read_only_upstream_audit',source_intent_ids=[]);mat2=g.candidate_pack_visual_profile_obligation(loaded,reg,activation_source='read_only_upstream_audit',source_intent_ids=[]);assert mat==mat2
 cs=p['authored_components']['components'];assert len(cs)==len(mat['render_gates'])==len(mat['prompt_binding']['required_evidence_fields'])
 assert mat['render_gates']==[x['render_gate']for x in cs];assert mat['composition_instruction']==' '.join(x['instruction']for x in cs);assert mat['runtime_expression']==p['runtime_expression'];assert mat['runtime_expression']['default_mode']=='definition_with_optional_label'and not mat['runtime_expression']['prompt_label_terms']
 assert mat['component_semantics']['required_group_ids']==[x['id']for x in cs]and mat['component_semantics']['minimum_component_groups']==len(cs)
 for c in cs:
  assert c['evidence_terms']==[c['match_terms'][0]]
  assert mat['evidence_requirements'][c['evidence_field']]==dict(min_content_words=c['min_content_words'],must_mention_any=c['evidence_terms'])
  assert c['evidence_terms'][0]in c['instruction']and c['evidence_terms'][0]in c['render_gate']['description']
  g.validate_visual_intent_binding(obligation_index=0,field=c['evidence_field'],phrase=c['evidence_terms'][0],requirement=mat['evidence_requirements'][c['evidence_field']])
 complete='; '.join(c['match_terms'][0]for c in cs);full=g.candidate_pack_visual_component_match(loaded,complete);assert full
 for c in cs:
  omitted='; '.join(x['match_terms'][0]for x in cs if x['id']!=c['id']);hit=g.candidate_pack_visual_component_match(loaded,omitted);omissions.append(dict(profile=id,omitted_group=c['id'],match=hit));assert hit is None
 rows=[dict(source='concept_lock',text=p['activation']['exact_terms'][0],polarity='required',priority='critical',mandatory=True)];routes=sorted(g.candidate_pack_auto_visual_obligation_matches(reg,rows));assert id in routes;exact.append(dict(id=id,complete_exact_routes=routes))
 u=units[mapping[id]['research_unit_id']];assert u['description_en']in p['semantics']['definition']
 records.append(dict(id=id,source_pointer='/profiles/'+str(len(records)),raw_profile=p,compiled_profile=loaded,actual_materialized=mat,source_mapping=mapping[id],source_unit=u,sources=[sources[s]for s in mapping[id]['source_ids']],all_authored_surfaces_match=True,complete_component_match=full))
assert len(omissions)==157
W('full-profile-source-consumer-inventory.json',records);W('component-omission-proof.json',omissions);W('exact-route-proof.json',exact)
variants=D(research/'VARIANT-RELATIONS.json')['pairs'];unitsids={x['source_unit']['unit_id']for x in records};W('relevant-variant-relations.json',[x for x in variants if x['unit_a']in unitsids or x['unit_b']in unitsids])
cids={x['source_mapping']['candidate_id']for x in records};cand=[]
for slot,rows in D(extension)['slots'].items():
 for c in rows:
  if c['id']in cids:cand.append(dict(slot=slot,record=c))
assert len(cand)==54;W('selected-profile-candidates.json',cand)
for f in files:
 dst=O/'source-snapshots'/f.relative_to(R);dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(f.read_bytes())
assert start=={str(f.relative_to(R)):H(f)for f in files}
W('SUMMARY.json',dict(decision='KEEP_ALL54_WITH_EXPLICIT_SOURCE_LIMITS',upstream_credit='Independent religion/iconography upstream integration; none of these54 profiles are additions from this maintenance loop.',profile_count=54,component_count=157,full_materializations_verified=54,canonical_bindings_accepted=157,omitted_component_fixtures_rejected=157,source_units_mapped=54,candidate_records_preserved=54,runtime_optional_empty_labels_all54=True,source_hashes=start,source_hashes_unchanged=True,head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),status=subprocess.check_output(['git','status','--short'],cwd=R,text=True),provider_calls=0,images=0,source_edits=0,publication=0,limits=['Source/consumer consistency only; primary museum pages and images not independently re-reviewed','No new normal-V6/image/retrieval quality evaluation','Canonical English evidence is distinct from multilingual discovery wording','Existing upstream reported image failures remain unchanged']))
print('PASS: all54 upstream profiles map to source units and preserve157 component duties through actual materialization;157 positive bindings and157 omission rejections; zero source/provider/image operations.')
