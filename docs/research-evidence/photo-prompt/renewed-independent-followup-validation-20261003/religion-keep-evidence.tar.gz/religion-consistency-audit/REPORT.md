# Religion/iconography source-consumer consistency audit

Decision: KEEP all54 newly integrated profiles. No source/API/runtime changes, new images, or publication. These54 profiles are independent upstream religion/iconography work, not additions made by this maintenance loop.

## Scope

Only photo_prompt_visual_obligations_religion_iconography.json's54 profiles and their directly mapped source units/candidates were audited. The other26 upstream candidate-only units, prior12 existing-owner updates, older profiles and oneiric work were not broadened or requalified.

The full source definition, variant scope, all authored components, canonical evidence, composition, runtime policy, pixel-gate text, exclusions and linked research records are preserved in full-profile-source-consumer-inventory.json. This review compares maintained source intent to actual production consumption; it does not independently authenticate religious history or museum imagery.

## Reproducible consumer findings

probe.py invokes the real registry loader and candidate_pack_visual_profile_obligation for each raw and compiled profile:
-54 raw/compiled materializations identical
-157 authored components preserved exactly in required groups, evidence fields, composition instructions and render gates
-157 canonical evidence phrases accepted by validate_visual_intent_binding
-157 controlled single-component omissions rejected by candidate_pack_visual_component_match
-54 complete exact requests resolve only their respective profile
-All54 runtime expressions use definition_with_optional_label with empty label lists; no runtime label forces another owner, actor or variant
-All54 profiles map to one maintained research unit and one composition candidate
-Source hashes unchanged during the audit; clean checkout recorded at completion

This is helper/materializer evidence, not54 normal-V6 full-scene qualifications. Component omission rejection is not a claim that normalize_visual_intent rejects missing input bindings. Canonical English evidence remains distinct from multilingual/optional discovery wording.

## Source decisions

Selected complete forms intentionally preserve counts, actor-relative sides, attribute owners and artifact condition. Chola/Cambodian forms, twelve-arm/two-hand forms, head halos/full-body mandorlas and different centaur junctions must not be merged simply because their names overlap. Horns on crowns and imagery on robes remain separate from wearer anatomy. Truncated sculptures and surviving fragments retain their original stated condition instead of inventing unseen anatomy.

Detailed inspection found no justified dropped-alternative leaf:
- Sanshin's broad overview “beside or against” is narrowed explicitly by its selected complete form and exact route to sitting leaning against a separate tiger; a beside-only form needs a distinct selection decision
- Eleousa's upward face direction toward neck/cheek does not require contact with both simultaneously; its close-contact form remains separate from the explicitly non-neck-clinging documented hybrid
- Stupa path “outside” is relative to the central structure, not necessarily outside its railing
- Siren human head OR upper body and animated-object face OR limbs survive canonical evidence and gates
- Odin's readable selected eye state and Sema's suggested turning posture do not certify concealed eye anatomy or continuous motion

See SELECTED-SOURCE-REVIEW.md for the full decisions and source-specific boundaries. No iconographic specificity was weakened to turn an apparent mismatch into a pass.

## Provenance limits

All54 source units are CURATORIAL_DESCRIPTION; direct reference-pixel inspection is not claimed. Linked source-use rows include52 PAGE_TEXT_RETURNED and5 SEARCH_EXCERPT_ONLY records. Excerpt-only links affect ri_cham_mask_performer, ri_tsukumogami_object_body, ri_hyakki_scroll and ri_babayaga_hut. Those access limitations remain; stronger primary-reference/pixel verification is deferred, not presumed complete.

The original research contains pre-integration research status fields; the separate MAINTENANCE mapping documents actual upstream integration. Research JSON is provenance, not runtime activation. All retained cultural/faith/identity/efficacy boundaries continue to apply to represented forms rather than real people.

Upstream RESULTS.md preserves six historical native-image attempts and failed pixel outcomes; this audit neither reruns those images nor upgrades them. No new provider calls, images, retrieval-quality claim, complete normal-CLI qualification or aesthetic evaluation.

Artifacts: SUMMARY.json, full-profile-source-consumer-inventory.json, component-omission-proof.json, exact-route-proof.json, relevant-variant-relations.json, selected-profile-candidates.json, source-snapshots/, probe.py and artifact-manifest.json.
