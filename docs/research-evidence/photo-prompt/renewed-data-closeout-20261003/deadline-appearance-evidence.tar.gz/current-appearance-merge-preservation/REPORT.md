# Appearance upstream preservation: NO LOSS

Read-only comparison of `37bc654e6116131cd3fb7030a41ae203082480e1` against `dee9f95896cf1e8eaa60d4cb02925b19f5c91374`, completed at approximately 2026-10-03 13:40 UTC. Prior `8077d510`→`37bc654e` has no skills/tests tree differences. Current checkout remained at dee9f958 with a clean working tree. No provider calls, production changes, full snapshots, retrieval, or tests.

## DATA-loop preservation

All **53 complete authored records** from the existing ledger are identical: 51 profiles plus two instrument slot rows. This includes all nested fields, arrays, their order, legacy alternatives, thresholds, labels and gate descriptions. All 51 profile index entries, target BM25F documents and exact lookup rows remain identical. Both slot index entries and their BM25F documents remain identical.

The independent appearance integration adds 46 profiles (1576→1622), changes 36 existing profiles, and removes none. There is zero changed-record overlap with the 51 DATA-loop profiles. This upstream work is not counted among the loop's 29 cycles / 56 edit events / 53 distinct records or its costs.

## Stored index comparison

- Visual: 46 new entries; 36 changed existing semantic texts and exactly the same 36 changed vectors. The other 1540 existing complete entries are identical.
- General: 45 new entries (9831→9876); 35 changed existing texts and exactly the same 35 changed vectors. The other 9796 existing complete entries are identical.
- No changed text reused its old vector, and no unchanged text changed vectors.
- All current stored vectors have 768 finite components. Both pins' active general shard SHA256 values, counts, unique entry membership and manifest membership validate.

This checks stored index text/vector changes and target preservation. It does not independently establish provider provenance from numerical vectors or freshly materialize the entire current semantic corpus. Global BM25F statistics and retrieval behavior may change as the independent corpus grows. No ranking, full-pack, pixel, or generalization claim is made.

## Runtime and historical test scope

The photo generator differs by exactly two appearance-extension registration lines; removing them yields the old file bytes. Separate current boundary V9 / illustration validator and new test additions are recorded in `integration-context.json`.

The two existing historical tests (`test_photo_liminal_active_use_korean_data_cleanup.py`, `test_photo_scene_data_cleanup.py`) only add the newly registered appearance extension to their historical-loader exclusion sets. Assertions and expected values are unchanged; exact diff is preserved. This source review is not a test pass.

The earlier fcb/8077 bounded tests, historical full-suite failures, and independent upstream successes retain their own original source/environment pins. This new read-only preservation proof does not upgrade any of them to a dee9f958 full-suite result.

## Evidence

- `source-proof.json`: all 53 exact per-record hash comparisons and full upstream profile delta IDs
- `index-proof.json`: changed text/vector IDs, added/removed IDs and target index invariants
- `integration-context.json`, `historical-test-diff.patch`: source scope and ending checkout state
- `check.py`, `check.log`: reproduced immutable Git-blob comparison, without a full snapshot or provider

The requested audit is complete before the 13:49 cutoff; no unfinished audit remains.
