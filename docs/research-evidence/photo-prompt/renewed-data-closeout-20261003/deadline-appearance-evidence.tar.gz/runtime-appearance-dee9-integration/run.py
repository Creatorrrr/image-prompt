import datetime,hashlib,json,os,re,subprocess,sys,time,collections
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parent.parent/'image-prompt';PIN='dee9f95896cf1e8eaa60d4cb02925b19f5c91374';PY=R/'.venv/bin/python'
names=['test_photo_slide_thickness_alternative.py','test_photo_ghost_ship_gate_alternative.py','test_photo_convoy_route_alternative.py','test_photo_aurora_anchor_alternative.py','test_photo_oneiric_anchor_alternative.py','test_photo_current_boundary.py','test_photo_current_boundary_snapshot.py','test_photo_camera_owned_clauses.py','test_photo_slang_boundary_history.py','test_photo_slang_visual_alternatives.py','test_photo_subculture_appearance_alternatives.py','test_photo_subculture_appearance_boundary_history.py','test_photo_liminal_active_use_korean_data_cleanup.py','test_photo_scene_data_cleanup.py']
def head():return subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(n,x):(P/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
assert head()==PIN;assert all((R/'tests'/n).is_file()for n in names)
paths=sorted(set([*(R/'skills/photo-prompt-image-generator/scripts').rglob('*.py'),*(R/'skills/photo-prompt-image-generator/assets').rglob('*.json'),*(R/'skills/photo-prompt-image-generator/precore').glob('*.*'),*(R/'tests').glob('*.py'),R/'skills/photo-prompt-image-generator/SKILL.md']))
source={str(p.relative_to(R)):sha(p)for p in paths if p.is_file()};dump('source-start.json',dict(head=head(),status=subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True),hashes=source))
env=os.environ.copy();removed=[k for k in env if re.search(r'(?:API_?KEY|TOKEN|SECRET|PASSWORD|CREDENTIAL|AUTH|PRIVATE_KEY)',k,re.I)]
for k in removed+['GEMINI_API_KEY','GOOGLE_API_KEY','OPENAI_API_KEY','ANTHROPIC_API_KEY']:env.pop(k,None)
env['PYTHONDONTWRITEBYTECODE']='1';report=dict(pin=PIN,started_utc=utc(),removed_environment_names=removed,provider_keys_absent=True,modules=[],scope='Bounded fourteen-module integration verification on live pin, not full suite')
for name in names:
 assert head()==PIN
 cmd=[str(PY),'-m','unittest','discover','-s','tests','-p',name,'-v'];start=time.monotonic();run=subprocess.run(cmd,cwd=R,env=env,capture_output=True,text=True);(P/(name+'.stdout')).write_text(run.stdout);(P/(name+'.stderr')).write_text(run.stderr);out=run.stdout+run.stderr;ids=re.findall(r'^test\S+ \(([^)]+)\) \.\.\.',out,re.M);match=re.search(r'^Ran (\d+) tests?',out,re.M);n=int(match[1])if match else None;assert len(ids)==n,(name,n,len(ids));labels=re.findall(r'^(FAIL|ERROR): (.+)$',out,re.M);row=dict(module=name,command=cmd,cwd=str(R),exit_code=run.returncode,tests=n,executed_ids=ids,seconds=time.monotonic()-start,failures=labels,stdout_sha256=sha(P/(name+'.stdout')),stderr_sha256=sha(P/(name+'.stderr')));report['modules'].append(row);dump('progress.json',report);print(name,run.returncode,n,labels,flush=True)
end={str(p.relative_to(R)):sha(p)for p in paths if p.is_file()};dump('source-end.json',dict(head=head(),status=subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True),hashes=end));report.update(finished_utc=utc(),source_hashes_preserved=end==source,source_file_count=len(source),head_preserved=head()==PIN,total_tests=sum(x['tests']for x in report['modules']),all_pass=all(x['exit_code']==0 for x in report['modules']),provider_calls=0,images=0);dump('summary.json',report);assert end==source and head()==PIN
print('Finished',report['total_tests'],'tests; all pass',report['all_pass'],'source preserved',report['source_hashes_preserved'],flush=True)
