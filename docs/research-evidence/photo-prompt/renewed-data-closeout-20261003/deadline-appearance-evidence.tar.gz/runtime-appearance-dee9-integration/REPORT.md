# Bounded appearance/runtime integration verification

Live pin: `dee9f95896cf1e8eaa60d4cb02925b19f5c91374`. No worktree snapshot was created.

## Result

All **96 methods pass** across fourteen selected modules with zero failures, errors or skips. This comprises the prior 63-method check, eight methods in the two new appearance modules, and 25 methods in the two changed historical cleanup modules.

The actual default current photo-boundary validator also **passes V9**, preserving the original four frozen inputs and complete historical lineage. Pack ID: `efdad53981af8456`. Output SHA-256: `5776db59f7c06fb0ba590b7365309f044f4aa1f93594e3ad466aa90d8b1539df`. No fixture, historical baseline or expected result was rewritten.

## Exact modules

- test_photo_slide_thickness_alternative.py: 4 passed
- test_photo_ghost_ship_gate_alternative.py: 3 passed
- test_photo_convoy_route_alternative.py: 4 passed
- test_photo_aurora_anchor_alternative.py: 3 passed
- test_photo_oneiric_anchor_alternative.py: 4 passed
- test_photo_current_boundary.py: 9 passed
- test_photo_current_boundary_snapshot.py: 6 passed
- test_photo_camera_owned_clauses.py: 18 passed
- test_photo_slang_boundary_history.py: 2 passed
- test_photo_slang_visual_alternatives.py: 10 passed
- test_photo_subculture_appearance_alternatives.py: 6 passed
- test_photo_subculture_appearance_boundary_history.py: 2 passed
- test_photo_liminal_active_use_korean_data_cleanup.py: 9 passed
- test_photo_scene_data_cleanup.py: 16 passed

## Source preservation and reviewed diff

All 526 recorded photo-runtime, asset, pre-core, test and skill hashes remain unchanged. HEAD stayed at the exact pin; working tree was clean before and after. The separate V9 replay also preserved all recorded historical-boundary assets, the validator, and frozen inputs. Replay output existed only in the validator’s temporary directory.

The scoped upstream diff from 8077d510 confirms exactly two additions in prompt_generator.py, registering the visual-obligation and research extensions. The two historical cleanup changes add the new extension to existing exclusion lists used solely for frozen historical comparisons. Exact diff preserved in upstream-scoped-diff.txt.

Both prior bounded evidence sets are intact: 23 fcb artifacts and 31 slang artifacts verified against their manifests.

Started 2026-10-03T13:39:18.269456+00:00; finished 2026-10-03T13:41:10.275711+00:00. Actual commands, test IDs, durations and stdout/stderr hashes are in summary.json. Provider/API/auth credential variables were removed. Existing interpreter only; no provider calls, image calls, installation, source changes, test rewrites or reruns.

## Scope

This is the requested bounded integration check plus actual V9 replay, not a current full-suite result. Previous upstream all-pass or ignored-asset restoration reports are not assumed to apply here. No full suite or asset availability check was performed in this task.
