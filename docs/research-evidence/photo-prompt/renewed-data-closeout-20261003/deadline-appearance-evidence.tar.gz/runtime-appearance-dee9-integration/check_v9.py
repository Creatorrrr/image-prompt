import datetime,hashlib,json,os,re,subprocess,sys,time
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parent.parent/'image-prompt';I=R/'skills/subculture-illustration-image-generator';PIN='dee9f95896cf1e8eaa60d4cb02925b19f5c91374'
for k in list(os.environ):
 if re.search(r'(?:API_?KEY|TOKEN|SECRET|PASSWORD|CREDENTIAL|AUTH|PRIVATE_KEY)',k,re.I):os.environ.pop(k)
os.environ['PYTHONDONTWRITEBYTECODE']='1';sys.dont_write_bytecode=True
head=lambda:subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert head()==PIN
baseline=json.loads((I/'assets/photo_regression_baseline_v9.json').read_text());files=[*(I/'assets').glob('photo_regression_baseline_v*.json'),I/'assets/universal_scene_baseline_v1.json',I/'scripts/validate_illustration_assets.py',*[R/x for x in baseline['frozen_inputs']]];before={str(p.relative_to(R)):sha(p)for p in files};sys.path.insert(0,str(I/'scripts'));import validate_illustration_assets as v
started=datetime.datetime.now(datetime.timezone.utc).isoformat();t=time.monotonic();result=v.validate_photo_regression_baseline(I/'assets');after={str(p.relative_to(R)):sha(p)for p in files};assert before==after;assert head()==PIN;assert result['status']=='pass'and result['schema']=='photo_regression_baseline/v9';out=dict(pin=PIN,started_utc=started,seconds=time.monotonic()-t,result=result,all_frozen_input_and_lineage_hashes_preserved=True,hashes=before,default_selected_version=9,provider_calls=0,images=0,scope='Actual default current-boundary V9 replay; original four frozen inputs unchanged; output generated only in validator temporary directory');(P/'v9-replay.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
