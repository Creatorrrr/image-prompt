from pathlib import Path
import json,sys,hashlib
sys.dont_write_bytecode=True
O=Path(__file__).resolve().parent;R=O.parent.parent/'image-prompt';sys.path.insert(0,str(R/'skills/photo-prompt-image-generator/scripts'));import prompt_generator as g
D=lambda p:json.loads(p.read_text())
def W(n,v):(O/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
profiles=D(O/'compiled-scoped-profiles.json');rows=[];complete=[]
for p in profiles:
 for c in p.get('authored_components',{}).get('components',[]):
  phrase=c['instruction'];req=p['evidence_requirements'][c['evidence_field']]
  try:g.validate_visual_intent_binding(obligation_index=0,field=c['evidence_field'],phrase=phrase,requirement=req);ok=True;error=None
  except Exception as e:ok=False;error=str(e)
  rows.append(dict(profile_id=p['id'],component=c['id'],field=c['evidence_field'],authored_positive_phrase=phrase,accepted=ok,error=error))
 groups=p['semantics'].get('component_semantics',{}).get('groups',[])
 if groups:
  text='; '.join(z['any_terms'][0]for z in groups);complete.append(dict(profile_id=p['id'],text=text,match=g.candidate_pack_visual_component_match(p,text)))
delta=D(O/'delta-source-profiles.json');d=next(x for x in delta if x['profile_id']=='composite_overwhelmed_expression');p=next(x for x in profiles if x['id']==d['profile_id']);old=g.compile_visual_profile(d['previous']);review=dict(profile_id=p['id'],previous_definition=old['semantics']['definition'],previous_definition_component_match=g.candidate_pack_visual_component_match(old,old['semantics']['definition']),current_definition=p['semantics']['definition'],current_definition_component_match=g.candidate_pack_visual_component_match(p,p['semantics']['definition']),semantic_discovery_requires_component_evidence=p['activation'].get('semantic_discovery_requires_component_evidence',False),current_paraphrases=[dict(text=t,match=g.candidate_pack_visual_component_match(p,t))for t in p['semantics']['paraphrase_examples']],decision='KEEP within negation/self-exclusion scope: no own alias negated or excluded; prose definition need not be a complete component alias fixture; all explicit paraphrases pass.')
W('positive-evidence-bindings.json',rows);W('complete-component-positive-controls.json',complete);W('changed-definition-review.json',review);print('binding phrases',len(rows),'accepted',sum(r['accepted']for r in rows),'complete controls',len(complete),'matched',sum(bool(r['match'])for r in complete));print(json.dumps(review,ensure_ascii=False,indent=2))
