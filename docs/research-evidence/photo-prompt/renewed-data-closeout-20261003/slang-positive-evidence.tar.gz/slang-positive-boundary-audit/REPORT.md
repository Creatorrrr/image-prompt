# KEEP: bounded slang positive-boundary audit

Pinned current source: 8077d5108cbf67a1b0b276056ed330e2bcba6e8e; comparison base fcb7f889. Scope is exactly12new and19changed existing visual profiles from the independent slang integration. No source patch is supported by the requested self-exclusion/negated-alias boundary audit.

## Results
- 650 authored positive description/paraphrase/component/evidence/instruction occurrences,424 unique profile/text pairs;429 occurrences are new text relative to the corresponding old profile.
- All157 authored paraphrase occurrences accepted by the actual current production component/paraphrase discovery helper.
- Zero positive own-alias negations and zero exclusion hits. Existing exclusion lists on soft_full_figure_volume and bust_prominence_relation remain intact and do not collide with their positive fields.
- All31 complete positive component controls accepted. Individual component phrases are not required to activate a complete profile.
- All56 authored component instruction phrases pass the production evidence-binding validator with their actual compiled requirements. This is positive phrase acceptance, not a renewed render-gate or vector-integrity audit.
- All83 explicit negative controls, one per actual current exact alias, are recognized as negated, rejected by alias matching, and cannot hard-activate their own profile. ASCII aliases use `without <alias>`; non-ASCII aliases use `<alias> 제외`.
- Contrastive/absence-bearing positive fields are preserved; no negative or variant definition is rewritten merely for containing contrastive language.

## Explicit non-defect / limit
Thirteen prose definitions do not match the complete component/paraphrase helper. Twelve definitions are unchanged from base; ten of those already match an exact hard route. The changed composite_overwhelmed_expression definition no longer directly matches this lexical helper, whereas its old definition matched an old authored paraphrase. That is a documented lexical-surface change, not an observed self-exclusion or negated-alias failure: no own alias is negated/excluded; all four current authored paraphrases pass, its complete component control passes, and this profile does not require component evidence for semantic discovery. Both previous and current prose definitions yield no exact-only resolver hit. All three unchanged exact aliases retain hard eligibility under an explicitly supplied adult context in both profile versions. No global retrieval or full public-CLI failure is established. KEEP within this bounded task; do not report every prose definition as positively activating or claim unchanged lexical coverage.

## Method and provenance
Uses current production intent_term_is_negated, intent_alias_matches, candidate_pack_visual_component_match, resolve_visual_profile_hits and validate_visual_intent_binding. Resolver registry is projected to the31audited profiles with adult_context=True, so no cross-profile ranking, BM25F/embedding or full runtime qualification claim. Previous profiles are compiled with the same current production compiler solely for before/after interpretation; the old runtime itself is not replayed.

Source hashes remained unchanged through sealing. Only selected before/after profiles, small production script snapshots and hashes were saved; no large source/index snapshot was copied. Zero source edits, provider calls, CLI matrix, image generation, fullsuite or publication. Candidate vector/source integrity,63focused tests and V8 were not repeated or counted. The prior54religion-profile audit is distinct and receives no credit here.
