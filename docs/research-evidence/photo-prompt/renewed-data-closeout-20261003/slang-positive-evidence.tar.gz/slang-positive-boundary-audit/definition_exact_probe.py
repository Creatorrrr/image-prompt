from pathlib import Path
import json,sys
sys.dont_write_bytecode=True
O=Path(__file__).resolve().parent;R=O.parent.parent/'image-prompt';sys.path.insert(0,str(R/'skills/photo-prompt-image-generator/scripts'));import prompt_generator as g
D=lambda n:json.loads((O/n).read_text());delta=next(x for x in D('delta-source-profiles.json')if x['profile_id']=='composite_overwhelmed_expression');out=[]
for label,raw in [('previous',delta['previous']),('current',delta['current'])]:
 p=g.compile_visual_profile(raw);reg={'profiles':[p]};text=p['semantics']['definition'];res=g.resolve_visual_profile_hits(reg,[dict(source='concept_lock',text=text,polarity='required',priority='critical',mandatory=True)],adult_context=True)
 out.append(dict(version=label,text=text,exact_terms=p['activation']['exact_terms'],hits=res['hits'],bm25f_evaluated=res['bm25f_evaluated'],embedding_evaluated=res['embedding_evaluated'],positive_exact_alias_controls=[dict(alias=a,hits=g.resolve_visual_profile_hits(reg,[dict(source='concept_lock',text=a,polarity='required',priority='critical',mandatory=True)],adult_context=True)['hits'])for a in p['activation']['exact_terms']]))
(O/'changed-definition-exact-review.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps(out,ensure_ascii=False,indent=2))
