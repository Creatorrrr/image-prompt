from pathlib import Path
import sys,json,hashlib,subprocess,re,copy
sys.dont_write_bytecode=True
O=Path(__file__).resolve().parent;R=O.parent.parent/'image-prompt';S=R/'skills/photo-prompt-image-generator/scripts';A=S.parent/'assets';sys.path.insert(0,str(S));import prompt_generator as g
D=lambda p:json.loads(p.read_text());H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def W(n,v):(O/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
base='fcb7f889';head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();files=[f for f in subprocess.check_output(['git','diff','--name-only',base+'..'+head,'--','skills/photo-prompt-image-generator/assets'],cwd=R,text=True).splitlines()if 'visual_obligations' in f];delta=[]
for f in files:
 cur=D(R/f);out=subprocess.run(['git','show',base+':'+f],cwd=R,text=True,capture_output=True);prev=json.loads(out.stdout)if out.returncode==0 else {};old={p['id']:p for p in prev.get('profiles',[])}
 for p in cur.get('profiles',[]):
  if p['id']not in old or p!=old[p['id']]:delta.append(dict(profile_id=p['id'],source=f,change='changed'if p['id']in old else'new',previous=old.get(p['id']),current=p))
assert len(delta)==31 and sum(x['change']=='new'for x in delta)==12
hashpaths=[R/f for f in files]+[S/'prompt_generator.py',S/'visual_profile_contracts.py'];start={str(p.relative_to(R)):H(p)for p in hashpaths};reg=g.load_visual_obligation_registry(A/'photo_prompt_visual_obligations.json');ids={x['profile_id']for x in delta};reg['profiles']=[p for p in reg['profiles']if p['id']in ids];by={p['id']:p for p in reg['profiles']};index=g.build_visual_profile_index_payload(reg);prevby={x['profile_id']:g.compile_visual_profile(x['previous'])for x in delta if x['previous']};oldreg={**reg,'profiles':list(prevby.values())};oldindex=g.build_visual_profile_index_payload(oldreg)
W('delta-source-profiles.json',delta);W('compiled-scoped-profiles.json',reg['profiles']);W('source-pin.json',dict(base=base,head=head,source_hashes=start,profiles=sorted(ids),new_profiles=[x['profile_id']for x in delta if x['change']=='new']))
for p in [S/'prompt_generator.py',S/'visual_profile_contracts.py']:(O/p.name).write_bytes(p.read_bytes())
def aliases(p):
 return list(dict.fromkeys(p['activation'].get('exact_terms',[])+p.get('concept_candidate',{}).get('concept_terms',[])+p['semantics'].get('paraphrase_examples',[])+[t for z in p['semantics'].get('component_semantics',{}).get('groups',[])for t in z['any_terms']]))
def cases(p):
 s=p['semantics'];out=[('semantics.definition',s['definition'],'description')]
 for k in ['paraphrase_examples','visual_components']:
  out +=[(f'semantics.{k}/{i}',v,'paraphrase'if k=='paraphrase_examples'else'component')for i,v in enumerate(s.get(k,[]))]
 for z in p.get('authored_components',{}).get('components',[]):
  for k in ['match_terms','evidence_terms']:
   out +=[(f'authored_components/{z["id"]}/{k}/{i}',v,'component')for i,v in enumerate(z.get(k,[]))]
  out.append((f'authored_components/{z["id"]}/instruction',z['instruction'],'instruction'))
 return out
def resolve(p,text,registry,index):
 return [h for h in g.resolve_visual_profile_hits(registry,[dict(source='concept_lock',text=text,polarity='required',priority='critical',mandatory=True)],visual_profile_index=index,adult_context=True)['hits']if h['profile_id']==p['id']]
rows=[];controls=[]
for d in delta:
 p=by[d['profile_id']];aa=aliases(p);oldp=prevby.get(p['id']);oldtexts={t for _,t,_ in cases(oldp)}if oldp else set()
 for field,text,kind in cases(p):
  neg=[a for a in aa if g.intent_term_is_negated(text,a)];excl=[a for a in p['activation'].get('exclude_if_any_terms',[])if g.intent_alias_matches(text,a)];match=g.candidate_pack_visual_component_match(p,text)
  row=dict(profile_id=p['id'],profile_change=d['change'],field=field,kind=kind,text=text,new_text=text not in oldtexts,component_helper_match=match,negated_source_aliases=neg,exclusion_hits=excl,matching_aliases=[a for a in aa if g.intent_alias_matches(text,a)])
  if kind in ('description','paraphrase') or neg or excl:
   row['resolver_hits']=resolve(p,text,reg,index)
   if oldp:row['previous_profile_component_match']=g.candidate_pack_visual_component_match(oldp,text)
  rows.append(row)
 for a in p['activation'].get('exact_terms',[]):
  text=('without '+a)if a.isascii()else(a+' 제외')
  hits=resolve(p,text,reg,index);oldhits=resolve(oldp,text,oldreg,oldindex)if oldp else[]
  controls.append(dict(profile_id=p['id'],alias=a,text=text,alias_negated=g.intent_term_is_negated(text,a),alias_matches=g.intent_alias_matches(text,a),hits=hits,hard_eligible=any(h['hard_eligible']for h in hits),previous_hits=oldhits,previous_hard_eligible=any(h['hard_eligible']for h in oldhits)))
 print(p['id'],flush=True)
W('positive-probes.json',rows);W('negative-controls.json',controls);suspects=[x for x in rows if x['negated_source_aliases']or x['exclusion_hits']];W('suspects.json',suspects)
summary=dict(base=base,head=head,profiles=31,new_profiles=12,changed_profiles=19,positive_occurrences=len(rows),unique_profile_texts=len({(r['profile_id'],r['text'])for r in rows}),new_positive_occurrences=sum(r['new_text']for r in rows),paraphrase_occurrences=sum(r['kind']=='paraphrase'for r in rows),paraphrase_unmatched=[r for r in rows if r['kind']=='paraphrase'and not r['component_helper_match']],description_unmatched=[r for r in rows if r['kind']=='description'and not r['component_helper_match']],suspect_occurrences=len(suspects),negative_controls=len(controls),negative_control_hard_hits=[r for r in controls if r['hard_eligible']],source_hashes_unchanged=start=={str(p.relative_to(R)):H(p)for p in hashpaths},provider_calls=0,source_edits=0,cli_matrix=0,fullsuite=0,limits=['31-profile scoped registry; actual production helpers; no full public CLI or global retrieval/ranking qualification','Single component/evidence strings need not establish complete profile; do not count incomplete component matches as failures','Source integrity/63focused tests/V8 not repeated'])
W('SUMMARY.json',summary);print(json.dumps({k:v for k,v in summary.items()if k not in ['paraphrase_unmatched','description_unmatched','negative_control_hard_hits']},indent=2));print('unmatched para',len(summary['paraphrase_unmatched']),'desc',len(summary['description_unmatched']),'negative hard hits',len(summary['negative_control_hard_hits']))
