# Slang upstream merge preservation: NO LOSS

Compared immutable `fcb7f88920fbca0e65b892d2774faa84e74a7cb2` against `382656d817f48ac664fe6ccd8688663b1f96bca0`. Observed checkout is `8077d5108cbf67a1b0b276056ed330e2bcba6e8e`; its skills/tests tree has no delta from 382656d8. This is read-only record/index comparison, not a full regression or retrieval run. No provider calls, source edits, snapshots, image generation, or artifact recovery.

## Accepted DATA records

All **53 distinct complete authored records** from the ledger are identical across pins: 51 profiles and two instrument slot rows. Equality includes all nested objects, arrays and their order, so original alternatives, evidence thresholds, composition text, gates and legacy labels are preserved. Per-record source locations and canonical SHA256 pairs are in `source-proof.json`.

Upstream adds 12 profiles (1564→1576) and modifies 19 pre-existing profiles, with no removals. None overlaps the 51 DATA-loop profiles. The two instrument entries in `photo_prompt_tags.json` are unchanged. The independent upstream work is not another DATA-loop correction or cost.

## Stored semantic indexes

- Visual index: 12 added entries, 19 changed existing semantic texts, exactly the same 19 vectors changed. The other 1545 existing complete entries are identical. All 51 target entries, their per-document BM25F fields, and exact lookup rows remain identical.
- General index: 12 added entries (9819→9831), 22 changed existing texts, exactly the same 22 vectors changed. The other 9797 existing complete entries are identical, including both target slot entries and their `bm25f_document` fields.
- No changed text reuses its old vector. No unchanged text has a changed vector. Every post-merge stored vector has 768 finite values.
- Both arms' 16 active general shard byte hashes, declared entry counts, unique membership, and manifest entry order membership validate. These checks read only active shards from Git blobs.

Exact affected IDs are in `index-proof.json`. Changed numerical vectors alone do not independently establish provider provenance. This audit compares stored text/vector binding, not a fresh embedding computation or a complete semantic-text materialization. Corpus-wide BM25F statistics legitimately change and candidate ranks/packs are not claimed unchanged.

## Runtime and historical evidence boundaries

The only photo-generator runtime delta is two extension registration lines in `prompt_generator.py`. Removing those two lines produces exactly the earlier fcb file bytes. Separate illustration validation/current-boundary V8 and test changes are listed in `integration-context.json`; this is not an assertion that all runtime/tests are unchanged. Earlier V1–V7 report boundaries must retain their original pins.

The upstream final regression record has **1354 distinct selected successful IDs**, matching its 1354-test claim across 155 modules. It also retains 1382 actual executions including initially failed modules and selective rechecks. Its reported green result required restoring existing ignored historical artifacts in its own worktree.

**All 24 paths in upstream `IGNORED-TEST-DEPENDENCIES.json` are absent in this checkout.** Therefore its successful run does not establish that this checkout can reproduce green. No tests were run here, and the old pinned failures must not be retroactively replaced. No permanent-loss claim is made.

The 12:25 UTC closeout remains a historical fcb checkpoint. Its 1564/9819 corpus counts, 51-method bounded check, and old 120f07d0 full-regression result should not be silently relabeled as current 1576/9831 validation.

## Reproduction and audit limits

`check.py` reads both pinned trees and the existing ledger, writes only this external report directory, and recomputes complete-record and index comparisons. The final successful run is `check.log`. Initial scratch execution incorrectly assumed general BM25F documents lived in the root manifest, producing a KeyError; the checker was corrected to use each entry's `bm25f_document`. No product source or evidence was altered to fix that checker assumption.

`integration-context.json` records production/test changed paths, two-line registration equality, exact reported upstream test IDs, and current local artifact presence. No full source snapshot is duplicated.
