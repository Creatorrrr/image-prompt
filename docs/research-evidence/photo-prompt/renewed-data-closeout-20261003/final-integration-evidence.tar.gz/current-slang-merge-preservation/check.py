from pathlib import Path
import json,subprocess,hashlib,math
P=Path(__file__).resolve().parent;R=P.parent.parent/'image-prompt';A='skills/photo-prompt-image-generator/assets/';OLD='fcb7f889';NEW='382656d8'
def git(*a):return subprocess.check_output(['git',*a],cwd=R)
def js(ref,p):return json.loads(git('show',ref+':'+p))
def digest(v):return hashlib.sha256(json.dumps(v,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()
def profiles(ref):
 out={};paths={}
 for f in git('ls-tree','-r','--name-only',ref,A).decode().splitlines():
  if Path(f).name.startswith('photo_prompt_visual_obligations') and f.endswith('.json'):
   for p in js(ref,f).get('profiles',[]):
    assert p['id'] not in out,p['id'];out[p['id']]=p;paths[p['id']]=f
 return out,paths
def delta(a,b):return {'before_count':len(a),'after_count':len(b),'added':sorted(b.keys()-a.keys()),'removed':sorted(a.keys()-b.keys()),'changed_existing':sorted(k for k in a.keys()&b.keys() if a[k]!=b[k])}
old,op=profiles(OLD);new,np=profiles(NEW);ledger=json.loads((P.parent/'ledger.json').read_text());keys=sorted({k for c in ledger['cycles'] for k in c['record_keys']});tags0=js(OLD,A+'photo_prompt_tags.json');tags1=js(NEW,A+'photo_prompt_tags.json');rows=[]
for k in keys:
 parts=k.split(':');pid=parts[-1]
 if parts[0]=='profile': a,b=old[pid],new[pid];path=np[pid]
 else:a=next(v for v in tags0['slots'][parts[1]] if v['id']==pid);b=next(v for v in tags1['slots'][parts[1]] if v['id']==pid);path=A+'photo_prompt_tags.json'
 rows.append({'key':k,'source_file':path,'complete_record_equal':a==b,'before_sha256':digest(a),'after_sha256':digest(b)})
report={'before':git('rev-parse',OLD).decode().strip(),'after':git('rev-parse',NEW).decode().strip(),'observed_checkout':git('rev-parse','HEAD').decode().strip(),'source_records':rows,'all_53_complete_records_preserved':all(x['complete_record_equal'] for x in rows),'profile_source_delta':delta(old,new),'provider_calls':0}
(P/'source-proof.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='source_records'},indent=2),flush=True)
v0=js(OLD,A+'photo_prompt_visual_profile_index.json');v1=js(NEW,A+'photo_prompt_visual_profile_index.json')
def entry_analysis(a,b):
 common=a.keys()&b.keys();textchange=sorted(k for k in common if a[k]['text']!=b[k]['text']);vecchange=sorted(k for k in common if a[k]['vector']!=b[k]['vector']);return {**delta(a,b),'changed_text_ids':textchange,'changed_vector_ids':vecchange,'changed_text_reused_vector_ids':sorted(set(textchange)-set(vecchange)),'unchanged_text_changed_vector_ids':sorted(set(vecchange)-set(textchange)),'after_vectors_finite_768d':all(len(e['vector'])==768 and all(math.isfinite(x) for x in e['vector']) for e in b.values())}
vi=entry_analysis(v0['entries'],v1['entries']);vi['target_entries_unchanged']=all(v0['entries'][k.split(':')[1]]==v1['entries'][k.split(':')[1]] for k in keys if k.startswith('profile:'));vi['target_bm25f_docs_unchanged']=all(v0['bm25f']['documents'][k.split(':')[1]]==v1['bm25f']['documents'][k.split(':')[1]] for k in keys if k.startswith('profile:'));vi['target_exact_lookup_unchanged']=all([e for e in v0['exact_lookup'] if e['profile_id']==k.split(':')[1]]==[e for e in v1['exact_lookup'] if e['profile_id']==k.split(':')[1]] for k in keys if k.startswith('profile:'))
def general(ref):
 m=js(ref,A+'photo_prompt_semantic_index.json');es={}
 for s in m['shards']:
  raw=git('show',ref+':'+A+s['path']);assert hashlib.sha256(raw).hexdigest()==s['sha256'];j=json.loads(raw);assert len(j['entries'])==s['entry_count'];assert not es.keys()&j['entries'].keys();es.update(j['entries'])
 assert len(es)==m['entry_count'];assert set(es)==set(m['entry_order']);return m,es
m0,g0=general(OLD);m1,g1=general(NEW);gi=entry_analysis(g0,g1);gi['target_slot_entries_unchanged']=all(g0[k]==g1[k] for k in keys if k.startswith('slot:'));gi['target_slot_bm25f_unchanged']=all(g0[k]['bm25f_document']==g1[k]['bm25f_document'] for k in keys if k.startswith('slot:'))
result={'visual':vi,'general':gi,'limits':['Exact source record and stored index field comparison, not retrieval or whole-suite execution.','Changed vectors are not independent provider-provenance proof. Global BM25F statistics can change with corpus additions.'],'provider_calls':0}
(P/'index-proof.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,indent=2),flush=True)
