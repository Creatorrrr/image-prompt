# Lighting-source geometry and reflection consistency audit

## Decision: KEEP; stop this category

Eight current profiles were inspected against their full local authored source and actual compiled/materialized consumer contracts. No narrowly justified additive correction was found. There are zero source changes, provider calls, image generations, or publications from this audit.

Pin: `31dbed9f0d22af97025cebcbceffc07b4250de35` at inspection start. `SUMMARY.json` records the actual execution HEAD and hashes of every relevant source/runtime file; those hashes remained unchanged during proof execution. Any concurrent documentation publication is separate work.

### Scope and exclusions

Included: negative fill, loop, butterfly, split, volumetric occluded shafts, wet-surface reflection ownership, glass reflection/transmission, aligned mirror action mismatch. These are eight profiles, below the requested twelve-profile cap.

Excluded: camera-direction metadata and broad/short camera-relative face orientation, matte/gloss hard/soft corrections, Fresnel, bloom/halation, other capture-physics repairs. Initial inventory showed already corrected Rembrandt shadow-side ownership and clamshell conditional catchlight applicability; these were excluded from the eight-profile audit and receive no new credit here. No generic expansion of anatomical or material owners was attempted.

## Full-source decisions

1. `negative_fill_shadow_deepening_relation`: KEEP. Dark flag, wall, or unlit surface alternatives survive in component and evidence wording. Local modeled shadow explicitly allows cheek, jaw, object, or material; composition and gates keep the owner generic and preserve nearby absorber, reduced bounce, retained detail, and stable key/exposure. The Korean capture-elements source identifies subtraction of bounce, not a mandatory human portrait. Portrait exact alias does not narrow the generic definition or consumer fields. The optional label is only “negative fill.”

2. `loop_face_light_pattern`: KEEP. Definition, paraphrases, source proposal, evidence and gates all select the same elevated/off-axis source, downward-lateral detached nose shadow, modeled cheeks, and readable far eye. Source research §4.3 deliberately distinguishes detached loop shadow from joined Rembrandt shadow. No authored eye-visibility exception or different owner was found. Camera-direction metadata was not evaluated.

3. `butterfly_face_light_pattern`: KEEP. The original structured proposal explicitly includes upper catchlights in both definition and component 4. Current composition, anchors, gates and optional labels preserve that selected five-duty variant. A general photography argument that butterfly lighting could exist with closed eyes does not authorize an exception to this authored variant. Distinction from clamshell lower return remains deliberate.

4. `split_face_light_pattern`: KEEP. Original/current selected geometry is lateral source, central facial division, decisively lit/shadowed halves, and readable shadow-side structure. The current positive boundary phrase and gate express the same modeled face rather than silhouette. Source wording does not license replacing the face with another object or deleting shadow structure.

5. `volumetric_occluded_light_shafts`: KEEP. Original proposal explicitly contains window/cloud/foliage/architecture/gobo occlusion, haze/dust/mist/atmosphere, and subject/floor/wall/atmospheric-layer termination alternatives. Every alternative survives in current component anchors and corresponding gates. High-level “receiving surfaces” is broader shorthand than detailed component 5; the detailed atmospheric-layer branch is present, not lost. Source research records a prior volumetric pixel failure; this text audit does not overturn it.

6. `wet_surface_light_reflection_owner_relation`: KEEP with source-selection caveat. Original Korean source §5.4 allows an in-frame OR reasonably traceable real light/object owner and multiple wet states/interruption causes. The current profile consistently selects an in-frame visible owner in definition, component, evidence, and gate; changing only an evidence branch would be a partial repair. Wet-state and interruption alternatives remain expressible under generic anchors. Runtime labels mention a sign/light variant, but mode is `definition_with_optional_label`, so the label is not required by the runtime audit. A visible object owner is not forced to become a luminous sign. The earlier source’s wider off-frame option alone does not justify broadening this selected current contract.

7. `rb_glass_reflection_transmission`: KEEP. Original research proposal’s candidate expression selects opposite-facade reflection and visible interior. The current definition and exact activation explicitly select that manifestation, and the profile’s claim limits explicitly say concrete objects are a selected manifestation, never broad-realism defaults. All three authored components compile unchanged: frame/glass plane, matching opposite facade, readable interior through another glass region. Runtime labels are empty. Replacing the facade with any owner would broaden the selected variant.

8. `mirror_reflection_action_mismatch`: KEEP. Original imaginal source §3.8 explicitly requires a real person and matching aligned reflection, then one action/gaze/temporal-phase mismatch with other geometry normal. Current anchors retain gaze and action-phase alternatives; composition’s gesture/phase shorthand and required “aligned mirror reflection with one independent action” label do not assign a second actor or forbid gaze. Face/clothing/body alignment agrees with the original person-based selected source; generic “subject” in the English definition does not authorize an object-only variant. Shared prop/contact/room-event comparison remains supported.

## Actual consumer proof

Reproduce read-only proof with `.venv/bin/python ../daylong-progress-20261002/lighting-reflection-consistency-audit/probe.py` from the repository. This writes only into the audit directory.

- Eight raw-profile and loaded/compiled-profile calls to `candidate_pack_visual_profile_obligation` agree exactly
- Composition, component semantics, required fields, evidence requirements, runtime expressions, all render gates and reject substitutes are compared field-for-field
- All eight complete component fixtures return `component_semantics`
- 38 canonical evidence anchors were tested with the actual `validate_visual_intent_binding`
- Six bare anchors fail existing minimum-content-word requirements: four negative-fill fields and two mirror fields. Exact diagnostics remain in `binding-probes.json`. Bare anchors are not necessarily complete evidence sentences
- Appending existing source composition wording to each anchor yields 38/38 valid single-field bindings. These are deliberately a narrow binding-expressibility probe, not coherent full-composition fixtures; repeated composition text would not establish pairwise evidence independence or full audit success
- 38 component-omission probes: 28 return no match; 10 return `semantic_paraphrase_example`, five each for butterfly and volumetric. The original profiles include single-component paraphrases, so omission still satisfies that independent advisory fallback. This is not hard activation, not all-duty evidence acceptance, and not a new DATA regression. No claim that all omissions are rejected is made

## Provenance and limitations

Local original research files and selected full source/runtime snapshots are preserved under `source-snapshots/`. `profiles-and-materialization.json` records full raw, compiled, and emitted profiles without reducing them to English OR matching. `SUMMARY.json` includes source hashes. Primary external pages and images were not re-fetched; this is an internal source/consumer audit, not independent optical validation. No candidate-pack query, retrieval ranking benchmark, normal V6 composition audit, runtime change, image-quality improvement, or end-to-end quality gain is claimed.

The category is closed with KEEP. No proposal or qualification freeze is needed.

Final check: concurrent HEAD advanced to `bcb671ba488a31f4e84e5e0d8b0a740e4dd9c706`; all selected source/runtime hashes still match. Exact concurrent changed paths are in `FINAL-PIN-CHECK.json`; no claim of an unchanged repository commit is made. The runtime-label audit source is also snapshotted.
