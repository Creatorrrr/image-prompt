from pathlib import Path
import json,sys,hashlib,subprocess
sys.dont_write_bytecode=True
O=Path(__file__).resolve().parent;R=O.parent.parent/'image-prompt';S=R/'skills/photo-prompt-image-generator/scripts';A=S.parent/'assets';sys.path.insert(0,str(S));import prompt_generator as g
D=lambda p:json.loads(p.read_text());H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def W(n,x):(O/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
ids=['negative_fill_shadow_deepening_relation','loop_face_light_pattern','butterfly_face_light_pattern','split_face_light_pattern','volumetric_occluded_light_shafts','wet_surface_light_reflection_owner_relation','rb_glass_reflection_transmission','mirror_reflection_action_mismatch']
reg=g.load_visual_obligation_registry(A/'photo_prompt_visual_obligations.json');by={p['id']:p for p in reg['profiles']};raw={}
for f in A.glob('photo_prompt_visual_obligations*.json'):
 for p in D(f).get('profiles',[]):
  if p['id']in ids:raw[p['id']]=(f,p)
research=['lighting-visual-semantics-20260902/source-research.md','lighting-visual-semantics-20260902/candidate-data-proposal.json','lighting-visual-semantics-20260902/evidence.jsonl','capture-elements-visual-semantics-20260902/source-research.md','imaginal-visual-semantics-20260901/source-research.md','imaginal-visual-semantics-20260901/evidence.jsonl','korean-emotional-place-visual-semantics-20260902/source-research.md','korean-emotional-place-visual-semantics-20260902/candidate-data-proposal.json','realistic-background-20260912/visual-proposals.json','realistic-background-20260912/sources.json']
files=list({f for f,p in raw.values()})+[S/'prompt_generator.py',S/'visual_profile_contracts.py']+[R/'docs/research-evidence/photo-prompt'/f for f in research];hashes={str(p.relative_to(R)):H(p)for p in files};records=[];bindings=[];omissions=[]
for id in ids:
 f,p=raw[id];c=by[id];m=g.candidate_pack_visual_profile_obligation(p,reg,activation_source='read_only_consistency_audit',source_intent_ids=[]);m2=g.candidate_pack_visual_profile_obligation(c,reg,activation_source='read_only_consistency_audit',source_intent_ids=[]);assert m==m2
 for k in ['composition_instruction','evidence_requirements','runtime_expression','render_gates','reject_substitutes']:assert m[k]==c[k]
 assert m['prompt_binding']['required_evidence_fields']==c['required_evidence_fields'];assert m['component_semantics']==c['semantics']['component_semantics']
 groups=m['component_semantics']['groups'];complete='; '.join(x['any_terms'][0] for x in groups)
 for x in groups:
  t='; '.join(y['any_terms'][0]for y in groups if y['id']!=x['id']);omissions.append(dict(profile=id,omitted=x['id'],text=t,result=g.candidate_pack_visual_component_match(c,t)))
 for field,req in m['evidence_requirements'].items():
  for anchor in req.get('must_mention_any',[]):
   try:g.validate_visual_intent_binding(obligation_index=0,field=field,phrase=anchor,requirement=req);error=None
   except ValueError as e:error=str(e)
   expanded=anchor+'; '+m['composition_instruction']
   g.validate_visual_intent_binding(obligation_index=0,field=field,phrase=expanded,requirement=req)
   bindings.append(dict(profile=id,field=field,anchor=anchor,bare_anchor_error=error,source_instruction_expanded_phrase=expanded,expanded_binding_pass=True))
 records.append(dict(id=id,source_file=str(f.relative_to(R)),raw_profile=p,compiled_profile=c,materialized=m,all_surfaces_preserved=True,complete_components_result=g.candidate_pack_visual_component_match(c,complete)))
for f in files:
 p=O/'source-snapshots'/f.relative_to(R);p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(f.read_bytes())
assert hashes=={str(p.relative_to(R)):H(p)for p in files}
W('profiles-and-materialization.json',records);W('binding-probes.json',bindings);W('component-omission-probes.json',omissions)
W('SUMMARY.json',dict(decision='KEEP',profiles=ids,profile_count=len(ids),materializations_equal=len(records),binding_probes=len(bindings),bare_anchor_minimum_errors=sum(bool(x['bare_anchor_error'])for x in bindings),source_instruction_expanded_bindings_pass=sum(x['expanded_binding_pass']for x in bindings),omission_probes=len(omissions),omission_no_match=sum(x['result']is None for x in omissions),omission_paraphrase_fallback=sum(x['result']=='semantic_paraphrase_example'for x in omissions),source_hashes=hashes,source_unchanged=True,head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),source_edits=0,provider_calls=0,images=0))
print(json.dumps(D(O/'SUMMARY.json'),indent=2))
