# Completed full-registry supplement: KEEP

The already-running full-registry diagnostic completed every requested row: 772 authored positives (497 unique profile/text pairs) and54 exact-alias negative controls across only the54 new profiles. The full-registry outputs are exactly identical to the earlier scoped outputs for each audited own-profile record. There are zero unmatched discovery-helper positives, zero negated own aliases, zero exclusion hits,108 hard-eligible complete positives, and54/54 negative controls blocked.

The process then exited1 at its final live-file hash assertion: the parent had merged bcb671ba -> fcb7f889 during execution. All matrices were written before that assertion. Python had already imported the pinned bcb helpers and loaded the registry/index into memory. This is a completed pinned-source matrix with an expected checkout-drift assertion, not a successful unchanged-live-checkout run. FULL-REGISTRY-SUMMARY.json records this boundary explicitly.

The four directly audited functions (intent_term_is_negated, intent_alias_matches, candidate_pack_visual_component_match, resolve_visual_profile_hits) are AST-identical between the saved bcb source and merged fcb. This limited comparison is not a rerun or broader merged-runtime qualification.

No source change is proposed. Contrastive/variant definitions and deliberate negatives stay intact. The original scoped report and its sealed manifest are unchanged. This supplement replaces only its then-current statement that the full-registry run was still pending. Scope remains helper diagnostics of these54 profiles; no public-CLI, global ranking, BM25F/embedding, new native scene, image, provider, or publication evidence. The earlier component/evidence/gate audit was neither repeated nor counted.
