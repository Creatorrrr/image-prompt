from pathlib import Path
import sys,json,hashlib,subprocess,re
sys.dont_write_bytecode=True
O=Path(__file__).resolve().parent; R=O/'pinned-source'; S=R/'skills/photo-prompt-image-generator/scripts'; A=S.parent/'assets';sys.path.insert(0,str(S));import prompt_generator as g
D=lambda p:json.loads(p.read_text());H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def W(n,x):(O/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
paths=[A/'photo_prompt_visual_obligations_religion_iconography.json',A/'photo_prompt_religion_iconography_extension.json',S/'prompt_generator.py'];start={str(p.relative_to(R)):H(p)for p in paths};head=D(O/'pinned-source-manifest.json')['commit']
raw=D(paths[0]);reg=g.load_visual_obligation_registry(A/'photo_prompt_visual_obligations.json');reg['profiles']=[p for p in reg['profiles'] if p['id'] in {r['id'] for r in raw['profiles']}];by={p['id']:p for p in reg['profiles']};index=g.build_visual_profile_index_payload(reg)
mappings={m['profile_id']:m for m in D(R/'docs/research-evidence/photo-prompt/religion-myth-integration-20261003/MAINTENANCE.json')['mappings']}; ext={c['id']:c for rows in D(paths[1])['slots'].values()for c in rows}
rows=[];controls=[];alias_suppressions=[]
for rawp in raw['profiles']:
 pid=rawp['id'];p=by[pid];c=ext[mappings[pid]['candidate_id']];cases=[(f'semantics.paraphrase_examples/{i}',s)for i,s in enumerate(p['semantics']['paraphrase_examples'])]+[(f'candidate/{key}',c[key])for key in ('en','ko')]+[(f'candidate/paraphrases/{i}',s)for i,s in enumerate(c.get('paraphrases',[]))]
 aliases=list(dict.fromkeys(p['activation']['exact_terms']+p['semantics']['paraphrase_examples']+p['concept_candidate']['concept_terms']+[s for group in p['semantics']['component_semantics']['groups']for s in group['any_terms']]))
 for source,text in cases:
  source_rows=[dict(source='concept_lock',text=text,polarity='required',priority='critical',mandatory=True)]
  own=[h for h in g.resolve_visual_profile_hits(reg,source_rows,visual_profile_index=index,adult_context=True)['hits']if h['profile_id']==pid]
  neg=[a for a in aliases if g.intent_term_is_negated(text,a)]
  excl=[a for a in p['activation'].get('exclude_if_any_terms',[])if g.intent_alias_matches(text,a)]
  match=g.candidate_pack_visual_component_match(p,text)
  row=dict(profile_id=pid,source=source,text=text,component_helper_match=match,exact_only_resolver_hits=own,negated_source_aliases=neg,exclusion_hits=excl,matching_aliases=[a for a in aliases if g.intent_alias_matches(text,a)])
  rows.append(row)
  if neg or excl:alias_suppressions.append(row)
 for a in p['activation']['exact_terms']:
  text='without '+a
  source_rows=[dict(source='concept_lock',text=text,polarity='required',priority='critical',mandatory=True)]
  own=[h for h in g.resolve_visual_profile_hits(reg,source_rows,visual_profile_index=index,adult_context=True)['hits']if h['profile_id']==pid]
  controls.append(dict(profile_id=pid,text=text,exact_alias=a,alias_negated=g.intent_term_is_negated(text,a),alias_matches=g.intent_alias_matches(text,a),hard_eligible=any(h['hard_eligible']for h in own),hits=own))
W('scoped-positive-probes.json',rows);W('scoped-alias-suppressions.json',alias_suppressions);W('scoped-negative-controls.json',controls)
assert start=={str(p.relative_to(R)):H(p)for p in paths}
summary=dict(head=head,profiles=len(raw['profiles']),positive_occurrences=len(rows),positive_unique_texts=len({(x['profile_id'],x['text'])for x in rows}),helper_unmatched=[dict(profile_id=x['profile_id'],source=x['source'],text=x['text'])for x in rows if not x['component_helper_match']],alias_suppression_count=len(alias_suppressions),exclusion_count=sum(bool(x['exclusion_hits'])for x in rows),negative_controls=len(controls),negative_controls_passed=sum(x['alias_negated']and not x['alias_matches']and not x['hard_eligible']for x in controls),source_hashes=start,source_unchanged=True,source_edits=0,provider_calls=0,images=0,publication=0,limits=['Resolver registry is projected to these54 profiles; no global retrieval or cross-profile ranking claim','Production helper diagnostics; not full public-CLI or retrieval/image quality evidence','Only 54 new religion/iconography profiles and mapped candidate positives; preexisting profiles and deliberate contrast examples are outside audit','Prior component/evidence/gate audit was not repeated or counted'])
W('SCOPED-SUMMARY.json',summary);print(json.dumps(summary,ensure_ascii=False,indent=2))
