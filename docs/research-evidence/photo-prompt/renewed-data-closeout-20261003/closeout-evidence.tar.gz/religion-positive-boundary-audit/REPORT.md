# KEEP: 54 new religion/iconography positive boundaries

Pinned source: bcb671ba488a31f4e84e5e0d8b0a740e4dd9c706. No proposal or source edit is justified by this bounded audit.

## Evidence
- 54 new profiles only, with their mapped candidate captions/paraphrases: 772 authored positive occurrences, 497 unique profile/text pairs.
- All 772 remain accepted by the actual production `candidate_pack_visual_component_match` helper (component semantics or authored paraphrase match).
- Zero own-alias negations across their actual exact, paraphrase, concept and component aliases; zero exclusion hits. None of the54 declares `exclude_if_any_terms`.
- Actual production `resolve_visual_profile_hits`, using a registry projection limited to these54, preserves hard exact eligibility on 108 positive occurrences. Other positive examples are discovery surfaces, not complete hard-activation instructions; lack of exact hard activation is expected.
- All54 explicit `without <complete exact alias>` controls are recognized as negated, rejected by `intent_alias_matches`, and cannot hard-activate their own profile.
- 15 definition/paraphrase examples with contrastive, absence or uncertainty wording are explicitly retained in `preserved-contrastive-positives.json`. They have no actual own-alias negations. Selected variant distinctions such as Pholos without the usual human abdomen, unoccupied Bodhi throne, unverified continuous Sema rotation, and avoiding invented performance/flaying remain intact.

## Scope and limitations
Production Python helper diagnostics only. The resolver was projected to the54 audited profiles to bound execution; no global retrieval, ranking, BM25F/embedding, full public-CLI, new native-scene, provider or image qualification claim. All positive occurrences are recorded, including repeated text in distinct authored fields; 772 must not be represented as772 unique tests. Deliberate contrast examples and reject substitutes were preserved, not reclassified as positives.

The prior54-profile component/evidence/gate consistency audit was not repeated and receives no new credit. Existing upstream qualifications and image failures remain unchanged.

A separate full-registry run began on bcb and was still running when this scoped result was sealed. Its output, if completed later, must be separately labeled; it is not evidence for the present KEEP decision. The live checkout has moved to fcb7f889 during execution; these results use an immutable bcb source snapshot. Parent reports corpus/index inputs byte-identical after merge; this report does not independently qualify the merged runtime.

Zero source edits, provider calls, images or publication. Source snapshot hashes and rerunnable script are stored beside this report. Snapshot dependency files beyond these54 are runtime support, not additional audit scope.
