from pathlib import Path
import json,re,sys
sys.dont_write_bytecode=True
O=Path(__file__).resolve().parent;R=O.parent.parent/'image-prompt';S=R/'skills/photo-prompt-image-generator/scripts';sys.path.insert(0,str(S));import prompt_generator as g
reg=g.load_visual_obligation_registry(S.parent/'assets/photo_prompt_visual_obligations.json')
pattern=r'\b(machine|mechanical|industrial|manufacturing|loom|weaving|kiln|pottery|lathe|workshop|assembly|repair|forging|welding|motor|pulley|gears|gear|clockwork|rotating|winch|lever|pump|piston)\b'
rows=[]
for p in reg['profiles']:
 text=p.get('semantics',{}).get('definition',''); hits=re.findall(pattern,text,re.I)
 if hits or p['id']in ['aircraft_pilot_operation','rail_driver_operation','technical_overload_progressive_failure']:
  id=p['id']
  if id=='opening_disc_gramophone_listening':decision='fresh full-profile KEEP'
  elif id=='fine_watchmaking_mechanical_finishing':decision='prior reviewed boundary cross-check only; no fresh coverage credit'
  elif id in ['aircraft_pilot_operation','rail_driver_operation']:decision='excluded previously repaired professional operation profiles'
  elif id=='technical_overload_progressive_failure':decision='excluded previously kept technical overload'
  elif id=='ground_mortar_tube_bipod_baseplate_system':decision='excluded weapon'
  elif id in ['vibraphone_metal_bars_motor_pedal','xylophone_wooden_bar_resonator','modern_piston_trumpet_three_valve']:decision='excluded instrument performance'
  elif id=='alchemist_material_transmutation_process':decision='excluded explicitly magical transformation'
  else:decision='outside ordinary mechanical-process scope: matched word does not establish process profile'
  rows.append(dict(id=id,definition=text,search_hits=hits,decision=decision))
(O/'bounded-inventory.json').write_text(json.dumps(dict(compiled_registry_count=len(reg['profiles']),search_pattern=pattern,explicit_additional_role_checks=['aircraft_pilot_operation','rail_driver_operation','technical_overload_progressive_failure'],method='Read-only bounded lexical triage plus manual ID and full-profile review; search hits are not defect claims.',fresh_profile_count=1,prior_boundary_crosscheck_count=1,rows=rows),ensure_ascii=False,indent=2)+'\n')
print(len(rows),'triaged profiles')
