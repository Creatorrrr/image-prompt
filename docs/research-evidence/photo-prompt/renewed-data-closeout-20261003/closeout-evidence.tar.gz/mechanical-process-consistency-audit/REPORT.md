# Mechanical-process consistency: KEEP and stop

## Result and coverage

One genuinely fresh profile, `opening_disc_gramophone_listening`, is KEEP. The watchmaking profile is a previously reviewed boundary cross-check only, not new coverage. No source-supported factual or consumer inconsistency was established, so no correction is proposed.

The inventory is bounded and reproducible, not an exhaustive claim about all mechanical meaning in the registry. `inventory.py` queries the actual compiled registry, logs its count and keyword triage, and adds the explicit aircraft/rail/technical-overload exclusions. `bounded-inventory.json` preserves each triaged definition and disposition. Repaired aircraft/rail operations, instruments, weapons, magical transformations, and previously kept technical overload are excluded. Generic repair patches, social repair, biological manufacture contrasts, adaptive industrial reuse, and rotating clothing do not become mechanical-process profiles merely because they share a word. The requested maximum of eight was a cap, not a quota.

## Fresh gramophone source and all-field review

Original source: `korean-opening-era-20260907/report-source.md` §4.8; structured proposal `disc_gramophone_listening` and its four `opening_disc_gramophone_listening_*` components in `candidate-data-proposal.json`; source ledger S16–S18 in `evidence.jsonl`.

The source separates disc and cylinder media; requires connection of the record-reading mechanism and sound path to the horn; and expressly warns that a hand-driven Zonophone’s operation cannot be generalized to every spring-driven gramophone. The four scene relations are marked `researcher_designed_visual_control`, with `source_model_required` historical scope. They are authored staging, not a claim that all gramophones or listening postures must look this way.

The complete current profile preserves:

- Centered flat disc on turntable
- Connected soundbox and acoustic path to a horn
- Listener leaning toward the machine with hands away from the record
- Machine and listener visible together beside the table

These relations agree across definition, exact terms, full paraphrase, concept terms, authored match/evidence terms, composition instructions, all four gates and the compiled/materialized contract. Runtime expression is definition with optional label, with an empty label list; it introduces no alternative device or action owner. Rejections distinguish a cylinder placed on a disc, modern LP substitution, and universal continuous-crank assumptions. Hands away from the record does not assert that nobody can touch a crank or other machine control; it protects the selected listening relation.

No external factual adjudication was needed: no new claim of gear ratios, playback speed, motor type, exact year, national adoption, restored finish, or audible music is made. The source ledger’s museum collection records support device examples with explicitly limited provenance, not a universal device operation claim. Primary sites/images were not re-fetched, and no new engineering fact is asserted beyond this local authored-source comparison.

## Prior watchmaking boundary cross-check

Parent confirmed this profile was previously kept/deferred. It receives no fresh audit credit. The source `luxury_visual_semantics_20260901.md` §7 explicitly selects a connected mechanical movement, time/regulation function, differentiated finishing, and assembly/adjustment work point; its photographic instruction calls for separation of brushed, polished and chamfered surfaces. The corresponding source ledger entry `luxury_watchmaking_fhh_finish_function` describes the FHH manifesto as a normative industry document, not an image-recognition or performance standard.

The current function branch retains display OR winding/regulation; the assembly branch retains adjustment OR assembly work point. A broader list of possible finishing methods in the high-level definition does not justify deleting the detailed brushed/polished selected composition or inventing arbitrary mechanisms. No distinct factual error was found. This preserves the earlier KEEP/defer boundary rather than reopening it.

## Reproducible actual-consumer evidence

`probe.py` imports the current repository consumer and calls `candidate_pack_visual_profile_obligation` on raw and compiled inputs. Full results are saved in `profiles-and-materialization.json`.

Fresh gramophone:
- Raw and compiled materializations exactly equal
- Four canonical evidence bindings pass `validate_visual_intent_binding` without added words
- Complete component fixture matches
- All four one-component omission fixtures return no match
- All emitted operative fields equal compiled source: component semantics, required evidence fields, composition, evidence requirements, runtime expression, gates and reject substitutes

The separate prior watchmaking cross-check contributes eight anchor probes and four omissions: all eight source-expanded single-field bindings pass; two bare anchors fail existing minimum-content-word constraints and their exact diagnostics remain in `binding-probes.json`; all four omission fixtures reject. These counts must not be added to fresh coverage. Expansion appends existing source composition text and proves only single-field text expressibility, not a full composed-prompt audit or independent evidence phrases.

`SUMMARY.json` mechanically reports the two probed profiles together, but the coverage distinction above and in `bounded-inventory.json` is authoritative: fresh 1, prior cross-check 1. No candidate-pack query, public CLI replay, or image test was run.

## Existing failures and limits

Original `implementation-and-render-validation.md` reports the 1935-style café/newspaper/gramophone image at 4/7 and overall FAIL: newspaper hand contact, listening gaze, and needle near the label rather than the outer groove were deficient. Target candidate exposure was also reported as zero. This source-consistency KEEP does not override any of those outcomes or establish retrieval, pixel, or runtime quality improvement.

All source/runtime files used for the proof are snapshotted and hashed. The artifacts record the actual HEAD. No repository source changes, provider calls, image calls, or publication were performed. This category is closed.
