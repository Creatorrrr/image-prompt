from pathlib import Path
import json, hashlib, subprocess, re, collections
from decimal import Decimal as D
root=Path(__file__).resolve().parents[1]; repo=root.parent/'image-prompt'
ledger=json.loads((root/'ledger.json').read_text()); draft=(root/'renewed-closeout-draft.md').read_text(); checkpoint=json.loads((root/'current-checkpoint.json').read_text())
def git(*a):return subprocess.check_output(['git',*a],cwd=repo,text=True).strip()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
counts=collections.Counter(k for c in ledger['cycles'] for k in c['record_keys']); evidence=[]
draft_rows=re.findall(r'^(\d+)\. .*?: (\d+)개 레코드 편집 — \[커밋\]\(https://github.com/Creatorrrr/image-prompt/commit/([a-f0-9]+)\)',draft,re.M)
for c in ledger['cycles']:
 pub=c.get('publication_commit',c['commit']); full=git('rev-parse',pub)
 paths=git('show','--format=','--name-only',c['commit']).splitlines()
 reports=[p for p in paths if '/renewed-' in p and p.endswith('README.md') and 'deferred' not in p]
 assert len(reports)==1,(c['cycle'],reports)
 n,row_count,link=draft_rows[c['cycle']-1]
 assert int(n)==c['cycle'] and int(row_count)==c['accepted_rows'] and link==full
 assert len(c['record_keys'])==c['accepted_rows']
 evidence.append({'cycle':c['cycle'],'record_keys':c['record_keys'],'accepted_rows':c['accepted_rows'],'publication_commit':full,'report':reports[0],'report_sha256':sha(repo/reports[0]),'publication_reachable_from_head':subprocess.run(['git','merge-base','--is-ancestor',full,'HEAD'],cwd=repo).returncode==0})
a=ledger['embedding_attempts']; new=sum(D(str(x['conservative_upper_usd'])) for x in a); prior=D(str(ledger['prior_conservative_spend_usd'])); total=prior+new; t=ledger['transport_retry_uncertainty'];reserve=D(str(t['historical_recorded_request_estimate_usd']))*4; plan=total+reserve; room=D(str(ledger['project_budget_usd']))-plan
assert new==D(str(ledger['new_spend_usd'])) and total==D(str(t['current_recorded_request_estimate_usd'])) and reserve==D(str(t['additional_historical_transport_reserve_usd'])) and plan==D(str(t['current_planning_envelope_usd'])) and room==D(str(t['current_planning_room_usd']))
assert len(evidence)==29 and sum(counts.values())==56 and len(counts)==53
assert [checkpoint[k] for k in ['accepted_cycles','row_edit_events','distinct_records']]==[29,56,53]
proof={'scope':'Read-only arithmetic/report/publication mapping; no provider calls or tests. Original evidence is not rerun.','observed_head':git('rev-parse','HEAD'),'inputs':{n:sha(root/n) for n in ['ledger.json','renewed-closeout-draft.md','current-checkpoint.json']},'cycles':len(evidence),'edit_events':sum(counts.values()),'unique_records':len(counts),'repeat_records':{k:v for k,v in counts.items() if v>1},'record_types':dict(collections.Counter(k.split(':')[0] for k in counts)),'cost':{'reserved_attempt_entries':len(a),'statuses':dict(collections.Counter(x['status'] for x in a)),'increment_usd':str(new),'prior_estimate_usd':str(prior),'recorded_estimate_usd':str(total),'additional_historical_transport_reserve_usd':str(reserve),'planning_envelope_usd':str(plan),'planning_room_usd':str(room),'invoice_or_account_total':False},'all_draft_cycle_rows_and_commit_links_match':True,'reports':evidence}
(root/'closeout-accounting-review/proof.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in proof.items() if k not in ['reports','inputs']},ensure_ascii=False,indent=2))
