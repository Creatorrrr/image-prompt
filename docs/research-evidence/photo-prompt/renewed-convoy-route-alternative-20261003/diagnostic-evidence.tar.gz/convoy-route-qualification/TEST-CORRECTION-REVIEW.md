# Independent review of the missing-duty test correction

Verdict: approve the corrected new test as an accurate component-matcher test. It repairs an invalid test assumption; it does not relax source/runtime behavior or the final composed-evidence contract.

The original draft incorrectly expected normalize_visual_intent to reject partial bindings. Source inspection confirms that normalize_visual_intent rejects unknown keys but then iterates only raw_bindings.items(), validating each supplied field through validate_visual_intent_binding. It intentionally performs no completeness rejection at this input-normalization layer. The original draft and failing focused-run log are preserved under ../convoy-route-regression-validation/.

candidate_pack_visual_component_match collects matched groups and requires both minimum_component_groups and required_group_ids before returning component_semantics. The corrected test removes each of the five duty phrases in turn and asserts the matcher returns None on each resulting fixture. This accurately verifies that these bounded component-only phrases cannot satisfy the profile after any duty is omitted. The separate positive test verifies complete generic and legacy routes do match, preventing a vacuous always-false test.

This test is not a replacement for composed-evidence completeness validation and should not be described as proof that normalization rejects partial input. The matcher also supports a separate source-paraphrase fallback; this controlled phrase-deletion test is not a claim that every conceivable incomplete paraphrase is ineligible.

Completeness of an activated profile is independently enforced by audit_composed_prompt.audit_visual_obligations, which reads required_evidence_fields and records missing evidence. All five omitted-binding full normal CLI composition controls fail both BEFORE and AFTER. The three wrong-route controls also continue to fail. Those eight full audit negatives, unchanged five-duty profile structure, and unchanged runtime support the correction without weakening the integration contract.

Independent rerun: python -m unittest discover -s tests -p test_photo_convoy_route_alternative.py -v; four tests passed. Parent will rerun the broader focused set. No source/runtime edits were performed for this review.
