from fixture_common import *
r=D(P/'after/report.json');assert r.get('finished_at_utc');rows={x['id']:x for x in r['compositions']};assert len(rows)==14
for id in ['pack_animal_en','handcart_en','legacy_mule_cart_en','pack_animal_ko_request']:
 assert rows[id]['status']=='pass'and rows[id]['target_contract_status']=='active'
assert rows['merchant_caravan_control']['status']=='pass'and rows['merchant_caravan_control']['target_contract_status']=='not_requested'
assert rows['component_pack_en']['status']=='fail'and rows['component_pack_en']['target_contract_status']=='active'
assert all(x['status']=='fail'for x in rows.values()if x['kind']in ['missing_binding','wrong_binding_control'])
assert not any(f.get('field')=='departure_route_phrase'for f in rows['component_pack_en']['failures'])
supp=D(P/'after-only-component/report.json')['compositions'][0];assert supp['status']=='pass'and supp['target_contract_status']=='active'
compare=D(P/'comparison/summary.json');assert len(compare)==6
assert all(x['authorial_core_equal']and x['core_retrieval_equal']and x['embodiment_equal']and x['slot_candidate_orders_equal']and x['ghost_related_diffs']==0 for x in compare)
assert all(not x['identity_aligned'][key]['common_changed']for x in compare for key in ['semantic_clarification','visual_concept_candidates'])
start=D(P/'after/source-start.json');end=D(P/'after/source-end.json');m=D(P/'manifest.json');index=D(P.parent/'convoy-route-index-validation/index-verification.json')
out=dict(decision='QUALIFIED_EXACT_EN_TWO_ARRAY_ADDITION_WITH_SCOPED_LIMITS',after_normal_v6_cli_generations=6,paired_full_composition_audits=14,primary_exact_routes_fail_to_pass=3,legacy_remains_pass=True,ordinary_control_remains_pass=True,all_eight_negative_binding_controls_remain_fail=True,component_main_result='BEFORE target unavailable; AFTER eligible and selected, but frozen unexpanded composition fails four unchanged minima plus runtime label. This is a retained scaffold limitation, not a paired success or data regression.',component_after_only_coherent_audit='pass; supplementary only, not paired gain',full_pack_diff_summary=compare,unexpected_ghost_pack_drift=False,after_source_hashes_stable=start['source_hashes']==end['source_hashes'],frozen_before_inputs_unchanged=all(H((P/f).read_bytes())==h for f,h in m['input_hashes'].items()),frozen_r2_compositions_unchanged=H((P/'compositions-r2.json').read_bytes())==D(P/'repair-r2-manifest.json')['compositions_sha256'],runtime_files_changed=[k for k,v in m['source_hashes'].items()if '/scripts/'in k and end['source_hashes'][k]!=v],index_ready_evidence=index,provider_calls_this_worker=0,embedding_calls_parent=1,images=0,scope='Source-guided synthetic text-contract expressibility; no organic/clean-precore/retrieval-quality/pixel/aesthetic claim. KO request with English evidence is not Korean binding support.')
assert out['after_source_hashes_stable']and out['frozen_before_inputs_unchanged']and out['frozen_r2_compositions_unchanged']and not out['runtime_files_changed']
W(P/'AFTER-SUMMARY.json',out);print(json.dumps({k:v for k,v in out.items()if k not in ['full_pack_diff_summary','index_ready_evidence']},indent=2))
