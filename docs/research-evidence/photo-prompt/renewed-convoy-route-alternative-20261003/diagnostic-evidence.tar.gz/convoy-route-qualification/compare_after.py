from fixture_common import *
from collections import Counter

def diff(a,b,path=''):
 if type(a)!=type(b):return [dict(path=path,before=a,after=b)]
 if isinstance(a,dict):
  out=[]
  for k in sorted(a.keys()|b.keys()):
   if k not in a or k not in b:out.append(dict(path=path+'/'+k,before=a.get(k),after=b.get(k)))
   else:out+=diff(a[k],b[k],path+'/'+k)
  return out
 if isinstance(a,list):
  out=[]
  for i in range(max(len(a),len(b))):
   if i>=len(a)or i>=len(b):out.append(dict(path=path+'/'+str(i),before=a[i]if i<len(a)else None,after=b[i]if i<len(b)else None))
   else:out+=diff(a[i],b[i],path+'/'+str(i))
  return out
 return []if a==b else[dict(path=path,before=a,after=b)]

def all_lists(x,path=''):
 out={}
 if isinstance(x,dict):
  for k,v in x.items():out.update(all_lists(v,path+'/'+k))
 elif isinstance(x,list):
  if all(isinstance(i,dict)and'id'in i for i in x)and x:out[path]=[i['id']for i in x]
  elif all(isinstance(i,str)for i in x)and x:out[path]=x
  for i,v in enumerate(x):out.update(all_lists(v,path+'/'+str(i)))
 return out
summary=[]
for id in D(P/'manifest.json')['case_ids']:
 if not (P/'after'/id/'pack.json').exists():continue
 a=D(P/'before'/id/'pack.json')[0];b=D(P/'after'/id/'pack.json')[0];dd=diff(a,b);W(P/'comparison'/id/'full-pack-diff.json',dd)
 al=all_lists(a);bl=all_lists(b);order=[dict(path=k,before=al.get(k),after=bl.get(k))for k in sorted(al.keys()|bl.keys())if al.get(k)!=bl.get(k)];W(P/'comparison'/id/'all-list-order-diff.json',order)
 ghosts=[d for d in dd if 'ghost_ship' in json.dumps(d,ensure_ascii=False)];W(P/'comparison'/id/'ghost-diff.json',ghosts)
 item=dict(id=id,full_leaf_changes=len(dd),top_level_counts=dict(Counter(d['path'].split('/')[1]for d in dd)),all_list_order_changes=len(order),ghost_related_diffs=len(ghosts),authorial_core_equal=a['authorial_core']==b['authorial_core'],core_retrieval_equal=a['core_retrieval']==b['core_retrieval'],embodiment_equal=a['embodiment_preflight']==b['embodiment_preflight'],slot_candidate_orders_equal={k:[r['id']for r in v.get('candidates',[])]for k,v in a['slots'].items()}=={k:[r['id']for r in v.get('candidates',[])]for k,v in b['slots'].items()},visual_concept_order_before=[r['id']for r in a['visual_concept_candidates'].get('candidates',[])],visual_concept_order_after=[r['id']for r in b['visual_concept_candidates'].get('candidates',[])])
 aligned={}
 for key in ['semantic_clarification','visual_concept_candidates']:
  aa={r['id']:r for r in a[key].get('candidates',[])};bb={r['id']:r for r in b[key].get('candidates',[])}
  aligned[key]=dict(added=sorted(bb.keys()-aa.keys()),removed=sorted(aa.keys()-bb.keys()),common_changed={k:diff(aa[k],bb[k]) for k in sorted(aa.keys()&bb.keys()) if aa[k]!=bb[k]})
 item['identity_aligned']=aligned
 summary.append(item)
W(P/'comparison/summary.json',summary);print(json.dumps(summary,indent=2))
