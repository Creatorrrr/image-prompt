from fixture_common import *
import os
import prompt_generator as g
rows=[]
for d in sorted((P/'inputs').iterdir()):
 row=dict(id=d.name)
 try:
  env=g.load_request_envelope_arg(str(d/'envelope.json'));ctl=D(d/'controls.json');core=g.load_authorial_core_arg(str(d/'core.json'),request_envelope=env,creative_control_snapshot=ctl);g.photo_embodiment.build_policy(core,D(d/'review.json'))
  cmd=[str(R/'.venv/bin/python'),str(S/'validate_precore_feature_selection.py'),'--catalog',str(PRE/'visual_feature_catalog.json'),'--request-envelope',str(d/'envelope.json'),'--authorial-core',str(d/'core.json'),'--embodiment-review',str(d/'review.json'),'--selection',str(d/'feature-selection.json')]
  p=subprocess.run(cmd,cwd=R,capture_output=True,text=True);row.update(exit_code=p.returncode,stdout=p.stdout,stderr=p.stderr);assert p.returncode==0
  row['status']='pass'
 except Exception as e:row.update(status='fail',error=str(e))
 rows.append(row)
W(P/'preflight.json',rows);print(json.dumps(rows,indent=2));assert all(x['status']=='pass'for x in rows)
assert not(P/'manifest.json').exists()
files=[*A.rglob('*.json'),*S.rglob('*.py'),*PRE.glob('*.*')];hashes={str(f.relative_to(R)):H(f.read_bytes())for f in files if f.is_file()}
state=dict(head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),status=subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True).strip(),source_hashes=hashes)
for f in [A/'photo_prompt_visual_obligations.json',R/'docs/research-evidence/photo-prompt/wuxia-20260901/source-research.md',S/'prompt_generator.py',S/'audit_composed_prompt.py']:
 dest=P/'source-freeze'/f.relative_to(R);dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(f.read_bytes())
frozen=[*P.glob('*.py'),*P.glob('*.json'),*P.glob('*.md'),*(P/'inputs').rglob('*.json'),*(P/'source-freeze').rglob('*')]
W(P/'manifest.json',dict(baseline_head=state['head'],source_state=state,case_ids=sorted(d.name for d in(P/'inputs').iterdir()),source_hashes=hashes,input_hashes={str(f.relative_to(P)):H(f.read_bytes())for f in frozen if f.is_file()},frozen_at_utc=subprocess.check_output(['date','-u','+%FT%TZ'],text=True).strip()))
