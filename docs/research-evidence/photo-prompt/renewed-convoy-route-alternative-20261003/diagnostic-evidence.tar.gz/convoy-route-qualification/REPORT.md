# Convoy route BEFORE qualification

Recommend the exact EN two-array additive proposal for parent review, subject to the explicit source-inconsistency interpretation in REVIEW-ADDENDUM.md. No repo source or index edits were made by this worker.

## Verified result

Six normal V6 CLI packs generated successfully. Fourteen complete composed-prompt CLI audits used these unchanged packs after a frozen composition-only scaffold repair:

- Pack-mule, handcart, and Korean exact request with English evidence: fail solely on departure_route_phrase’s missing accepted anchor
- Legacy mule-drawn cart with visible wheels, hooves and brake handles: passes active target contract
- Ordinary unarmed merchant scene: passes with no target contract
- Component-only pack-mule scene: target unavailable, ordinary unchanged composition passes; this is NOT a target-contract pass
- Five omitted-duty controls: all fail
- Three wrong/absent route-binding controls: all fail

The original fixture metadata had a generic fail expectation for the component case. The target was not offered, so its audit pass is classified unavailable under the already frozen selection policy, not as acceptance of the target contract. Do not treat raw status alone as the target result.

## Artifact provenance

manifest.json froze requests, V3 cores, embodiment reviews, five-category feature selections, proposed profile and initial compositions before CLI execution. The original run is retained in before/. Its legacy control failed because the bare source anchors had too few content words and the final prompt omitted the required runtime label. repair-r2-manifest.json froze a composition-only repair before further audits: concrete same-duty elaborations and the safe runtime label. All original inputs, requests, cores, selected candidates and generated packs remain unchanged. Corrected results are before-r2/report.json and BEFORE-SUMMARY.json. No outcome-dependent source or proposal editing occurred.

Original frozen input hashes and revised composition hash match; saved packs are byte-identical across arms. Convoy profile remains identical to its frozen source. Parent concurrently applied an unrelated ghost-ship render-gate change, changing the root registry and index source binding during saved-pack audits. Whole repository/source pin was therefore not unchanged. See ../ghost-ship-gate-integration/verification.json.

## Integration handoff

Apply only the two additions in proposal-diff.json, preserving legacy strings, word thresholds, activation, all five duties, render gates, exclusions, and the cart-specific optional candidate. proposed-profile.json is the desired profile, but prefer merging its exact leaf additions rather than replacing a concurrent file. planned_test_photo_convoy_route_alternative.py is an unexecuted post-integration test draft.

The added component term changes this profile’s retrieval text; parent must verify index text/vector readiness before any AFTER claim. Do not assume the existing index is ready. No provider calls were made here. For AFTER, preserve compositions-r2.json, V3 cores and requests, regenerate normal CLI packs from the integrated ready state, reject all optional slots, and only select the target concept on the component route if offered and eligible.

This is source-guided synthetic text-contract expressibility evidence. It is not clean pre-core sampling, organic recall, query-embedding performance, image verification or aesthetic validation. Korean evidence binding remains unqualified. No images or provider calls.
