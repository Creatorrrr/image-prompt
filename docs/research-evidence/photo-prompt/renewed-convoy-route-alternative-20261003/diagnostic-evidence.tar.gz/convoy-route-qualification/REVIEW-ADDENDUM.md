# Source conflict explicitly qualified

Original source-research.md section 6, lines 185–195, itself lists the conjunction “Wheels, hooves, handles, and body directions” as its fourth required component. Its second required component explicitly allows cart, pack animal, or coherent transport unit. Thus this proposal reconciles an internal inconsistency in the source package; it is not an assertion that the original research never required the conjunction or that the data mistranscribed it.

The proposed interpretation gives effect to the expressly allowed alternative transport owners while retaining the complete origin–load–escort–route event and the maintained generic render gate. Legacy conjunction remains fully valid for a mule-drawn cart with wheels, hooves and brake handles. Since institutional source evidence does not establish one canonical arrangement, additive generic transport contact points is a narrowly justified interpretation, with no changes to the source references or optional cart candidate.

The freeze occurred before this clarifying addendum. No frozen input or profile proposal changed, and no outcome-dependent fixture revision was made. Parent should include this nuance in the adoption decision and any source research follow-up.
