from fixture_common import *
import copy
c=copy.deepcopy(next(x for x in D(P/'compositions-r2.json')if x['id']=='component_pack_en'));c['id']='component_pack_en_after_only_coherent';c['expected_before']='not_applicable_after_only';c['expected_after']='pass'
suffix={'bureau_origin_phrase':' with the open threshold and adjacent road visible together','loaded_cargo_phrase':' with tied panniers visibly attached to this chosen single mule','escort_distribution_phrase':' keeping each adult outside the sealed load with clear protective spacing','biaoju_confound_phrase':' as shown by the shared load ownership and armed protective positions'}
for f,extra in suffix.items():c['bindings'][f]+=extra
c['prompt']+=' This is a biaoju guarded cargo departure from loading yard to road. '+'. '.join(v for k,v in c['bindings'].items()if k in suffix)+'.'
W(P/'after-only-component-composition.json',[c]);W(P/'after-only-component-manifest.json',dict(scope='Separately authorized AFTER-only scaffold-complete target opt-in qualification. Not a paired BEFORE/AFTER benefit. Original frozen component failure is retained.',composition_sha256=H((P/'after-only-component-composition.json').read_bytes()),pack_sha256=H((P/'after/component_pack_en/pack.json').read_bytes()),frozen_at_utc=subprocess.check_output(['date','-u','+%FT%TZ'],text=True).strip()))
s=(P/'run_r2.py').read_text().replace("assert arm=='before-r2'","assert arm=='after-only-component'").replace("assert state(man)['source_hashes']==man['source_hashes']","assert H((P/'after-only-component-composition.json').read_bytes())==D(P/'after-only-component-manifest.json')['composition_sha256']")
s=s.replace("for id in man['case_ids']:","for id in ['component_pack_en']:").replace("P/'before'/id/'pack.json'","P/'after'/id/'pack.json'").replace("read(P/'compositions-r2.json')","read(P/'after-only-component-composition.json')").replace("expected=t['expected_before']","expected=t['expected_after']")
(P/'run_supplement.py').write_text(s)
