# Convoy route paired qualification

The exact two-array EN addition is qualified for source-contract consistency. This does not establish overall retrieval or image quality improvement.

## Main results

After independent approval and verified real-vector/index readiness, six normal V6 CLI packs were regenerated from unchanged frozen requests, V3 cores, controls and embodiment reviews. All fourteen complete composed-prompt CLI audits replayed compositions-r2.json unchanged.

- Pack mule, handcart, Korean exact request with English bindings: fail→pass; each BEFORE failure was only the route anchor
- Legacy mule-drawn cart with wheels, hooves and handles: pass→pass
- Ordinary unarmed merchant control: pass→pass without target activation
- All five omitted-duty and three incorrect-route binding controls: fail→fail
- Component-only case: BEFORE target unavailable; AFTER target offered eligible and selected, but frozen composition fails four existing word minima and required runtime label. This is an acknowledged scaffold limitation, not a paired benefit or data regression. Route evidence itself now passes

A separately authorized, separately frozen AFTER-only coherent component composition supplies the same pre-existing duties with adequate evidence and safe label. Its complete CLI audit passes. This supplementary result is not counted as a paired gain; the original frozen failure is retained.

## Full pack and order comparison

comparison/ contains complete recursive leaf diffs, all-list order diffs, identity-aligned candidate comparisons, and ghost-specific checks for all six packs.

- Four exact/legacy packs: exactly three leaf differences each (pack ID and the two intended profile arrays). Optional visual-concept and clarification orders are unchanged
- Ordinary merchant pack: no structural differences
- Component-only pack: target added at visual-concept position 2 and rb_support_compression removed from the capped list; matching clarification added/removed. Other common candidates are byte-equivalent JSON objects
- Frozen authorial cores, core retrieval, embodiment, slot candidate orders all match across six packs
- No ghost-related pack difference was found

The displaced offer was previously marked eligible. Its mandatory contents are seated body on soft cushion, local cushion depression beneath load, and clothing folds at seated contact. This exact frozen request instead has four standing adults with both feet on the road, one grounded mule and no seat/cushion. Adding the displaced relation would introduce unsupported seating and conflict with the standing-body description. This scene-specific inspection does not justify a general relevance or retrieval-gain claim. Full prior offer and assessment are retained in comparison/displaced-offer-review.json.

## Integrity and boundaries

Original frozen BEFORE files and compositions-r2 hashes remain unchanged. Saved BEFORE packs remain unchanged. AFTER source hashes were stable from start to end, and no runtime Python file differs from the original freeze. The unrelated published ghost gate change is already recorded in BEFORE provenance; it introduces no pack drift here.

Parent refreshed one genuine embedding after independent review. index-verification.json confirms only the convoy entry changed, 1509 entries and 3667 exact lookup rows remained unchanged, and all other vectors/texts were identical. This worker made no provider calls and generated no images.

The source internally conflicts: original component 2 allows cart OR pack animal OR coherent transport, while component 4 lists wheels, hooves and handles conjunctively. The accepted addition reconciles those alternatives with the maintained generic transport-contact render gate while preserving the legacy branch. It is not claimed to correct a transcription error.

REVIEW-CONSUMER-CORRECTION.md corrects the original helper-name typo without altering the frozen review. The actual helper is prompt_generator.validate_visual_intent_binding.

These are source-guided synthetic text-contract results, not organic query recall, clean pre-core evaluation, embedding retrieval quality, pixel verification, historical authenticity or aesthetic judgment. Korean request coverage uses English bindings and does not qualify Korean bindings.

## New test correction caveat

The initial unexecuted test draft wrongly assumed normalize_visual_intent rejects missing bindings; it validates supplied bindings and permits partial input. Parent retained the initial failing run and draft, then changed only the missing-duty test to use the actual component matcher. Independent review and a four-test rerun approve this consumer-correct assertion. It is not a claim that normalization rejects partial input; final completeness remains independently demonstrated by all five omitted-binding full CLI audit failures. See TEST-CORRECTION-REVIEW.md for source-level reasoning and fallback limits.
