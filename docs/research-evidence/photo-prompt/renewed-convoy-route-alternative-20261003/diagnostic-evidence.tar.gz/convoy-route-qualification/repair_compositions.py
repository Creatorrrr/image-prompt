from fixture_common import *
import os,time
suffix={'bureau_origin_phrase':' with the open threshold and adjacent road visible together','loaded_cargo_phrase':' with tied panniers or boxes visibly attached to this chosen single unit','escort_distribution_phrase':' keeping each adult outside the sealed load with clear protective spacing','biaoju_confound_phrase':' as shown by the shared load ownership and armed protective positions'}
rows=D(P/'compositions.json')
for t in rows:
 if t['kind']=='ordinary_control' or t['case']=='component_pack_en':continue
 for f,extra in suffix.items():
  if f in t['bindings']:t['bindings'][f]+=extra
 t['prompt']+=' This is a biaoju guarded cargo departure from loading yard to road. '+'. '.join(v for k,v in t['bindings'].items()if k in suffix)+'.'
W(P/'compositions-r2.json',rows)
W(P/'repair-r2-manifest.json',dict(scope='Composition-only scaffold repair. Existing source-guided baselines, cores, requests, selections and CLI packs untouched. Add safe runtime label and concrete same-duty evidence elaborations to meet fixed content minima. Preserve r1 results.',frozen_at_utc=subprocess.check_output(['date','-u','+%FT%TZ'],text=True).strip(),compositions_sha256=H((P/'compositions-r2.json').read_bytes()),pack_hashes={d.name:H((d/'pack.json').read_bytes())for d in(P/'before').iterdir()if d.is_dir()and(d/'pack.json').exists()}))
# Use identical normal CLI-produced packs. No hidden/helper substitute for composed audits.
src=(P/'run.py').read_text();a=src.index(' for id in man[\'case_ids\']:');b=src.index(' for t in read(P/\'compositions.json\'):',a)
src=src[:a]+''' for id in man['case_ids']:
  packs[id]=read(P/'before'/id/'pack.json')[0]
  dest=out/id;dest.mkdir();(dest/'pack.json').write_bytes((P/'before'/id/'pack.json').read_bytes())
  report['cases'].append(dict(id=id,source='unchanged normal CLI pack from before',exit_code=0))
'''+src[b:]
src=src.replace("assert arm=='before'","assert arm=='before-r2'").replace("read(P/'compositions.json')","read(P/'compositions-r2.json')").replace("assert state(man)==man['source_state']","assert state(man)['source_hashes']==man['source_hashes']")
# r2 adds its own frozen-contents check before existing original manifest checks.
src=src.replace(' g,audit=modules();man='," assert H((P/'compositions-r2.json').read_bytes())==D(P/'repair-r2-manifest.json')['compositions_sha256']\n g,audit=modules();man=")
(P/'run_r2.py').write_text(src)
