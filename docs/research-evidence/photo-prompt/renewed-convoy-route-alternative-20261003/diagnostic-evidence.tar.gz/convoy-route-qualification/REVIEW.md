# Independent source-guided review

Propose one English additive alternative in exactly two arrays. Do not change source during qualification.

## Intent and evidence

The maintained profile definition explicitly allows cart, pack animal, or coherent transport unit. Its owned_loaded_cargo group repeats that alternative. The native route-continuity gate already requires generic transport contact points and body orientations through yard, gate, road. The current evidence and component anchors instead conjoin wheels, hooves, handles, excluding a coherent loaded pack mule without wheels or handles and a handcart without hooves.

The local original research (wuxia-20260901/source-research.md) Tier 2 and biaoju source ledger require sealed owned load, distributed armed adult protection, bureau origin and continuous departure; they disclaim a canonical convoy arrangement. The museum source supports institution/vehicles/cargo, the Hebei historical source supports commercial cargo/silver escort by martial professionals. Neither supports requiring all three contact/object categories on every transport. This decision relies on the maintained source intent, not a newly asserted historical fact.

Proposed anchor: “transport contact points and body orientations continue from yard through gate onto one readable road”. Add it to continuous_departure_route.any_terms and departure_route_phrase.must_mention_any. Preserve existing EN/KO anchors, min_content_words=15, all five duties, render gates, activation, exclusions, and cart-specific optional candidate biaoju_loaded_cart_sealed_cargo_set. No Korean additions: existing Korean compound has the same problem, but a multilingual binding extension needs separate qualification.

## Consumer check

prompt_generator.validate_visual_intent_evidence_requirement lowercases/normalizes spaces, then requires an accepted anchor as a literal substring and enforces content-word minimum. candidate_pack_visual_component_match uses intent_alias_matches over each any_terms list; all five required group IDs remain required. audit_composed_prompt consumes the same profile evidence contract. This is an expressibility correction, not a parser or retrieval-engine change.

## Coherence and qualification

All positive scenes preserve one origin, one owned loaded unit, exactly four adult martial escorts (front, rear, both flanks), complete transport/contact view, and continuous threshold/road. Legacy control is a mule-drawn cart with actual wheels, hooves and brake handles. New cases separately realize a pack mule or a handcart; the old loaded-cargo OR anchor is retained as a taxonomy phrase immediately resolved to the chosen single unit. One Korean exact request uses English bindings and is not Korean-binding coverage.

Complete V6 composition audits will reject optional candidates. A component-only route selects the profile only when offered and eligible. Ordinary unarmed merchant control is coherent and has no institutional-origin relation. Five omitted-binding and three anchor-free wrong-binding controls probe rejection; the latter are diagnostic evidence mutations against a coherent legacy prompt, not organic scenes.

This is openly source-guided synthetic qualification. It does not establish organic recall, clean pre-core sampling, generated pixel accuracy, historical authenticity or aesthetic quality. No provider calls or generated images. Existing concurrent source changes are recorded in the freeze; they are not this worker's edits.
