# Consumer-name correction

REVIEW.md names the evidence validator incorrectly as validate_visual_intent_evidence_requirement. The actual consumer function is prompt_generator.validate_visual_intent_binding. The described lowercase/space-normalized literal-anchor and content-word checks refer to that function. Original frozen review is preserved unchanged.
