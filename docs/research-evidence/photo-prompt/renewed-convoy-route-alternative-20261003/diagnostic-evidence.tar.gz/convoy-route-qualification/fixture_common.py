from pathlib import Path
import json,hashlib,copy,sys,subprocess
P=Path(__file__).resolve().parent;R=P.parent.parent/'image-prompt';S=R/'skills/photo-prompt-image-generator/scripts';A=S.parent/'assets';PRE=S.parent/'precore'
sys.path[:0]=[str(S),str(PRE)];import creative_controls
D=lambda p:json.loads(p.read_text());H=lambda b:hashlib.sha256(b).hexdigest()
def W(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
PID='biaoju_guarded_cargo_departure';FIELD='departure_route_phrase'
body='Each adult has one separate complete body with arms hanging naturally and both feet supported on the road; the transport stands level on its visible ground contacts. Clear gaps separate every figure from the cargo, and the wide unobstructed view keeps each body and its support visible.'
def embodiment(prompt,phase='agent_prepack'):
 return dict(contract_version='photo-embodiment-review/v1',provenance=phase,prompt_sha256=H(prompt.encode()),scope='body_action',summary='Textual review of supported standing adults around grounded transport; no pixels verified.',checks={k:dict(status='supported',reason=v,prompt_evidence=[body])for k,v in [('body_ownership','Separate complete bodies and cargo ownership are explicitly described.'),('joint_chain_and_reach','Naturally hanging arms require no implausible reach or joint reversal.'),('support_and_balance','Adults stand on both feet and the transport has grounded contact points.'),('contact_and_space','Clear gaps avoid intersections between adults and the loaded transport.'),('visibility_and_projection','The unobstructed wide view includes all bodies and their ground supports.')]})
