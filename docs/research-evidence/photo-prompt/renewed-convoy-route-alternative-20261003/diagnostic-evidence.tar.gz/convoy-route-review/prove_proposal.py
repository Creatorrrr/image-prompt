"""Independent read-only source/consumer and retrieval-delta proof; no providers."""
from pathlib import Path
import copy,hashlib,json,sys
from unittest.mock import patch
sys.dont_write_bytecode=True
P=Path(__file__).resolve().parent;Q=P.parent/'convoy-route-qualification';R=P.parent.parent/'image-prompt';A=R/'skills/photo-prompt-image-generator/assets';S=A.parent/'scripts';sys.path.insert(0,str(S))
import prompt_generator as pg
import build_visual_profile_index as builder
PID='biaoju_guarded_cargo_departure';NEW='transport contact points and body orientations continue from yard through gate onto one readable road'
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def digest(x):return hashlib.sha256(json.dumps(x,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()
tracked=[A/'photo_prompt_visual_obligations.json',A/'photo_prompt_visual_profile_index.json',A/'photo_prompt_tags.json',S/'prompt_generator.py',S/'audit_composed_prompt.py']
start={str(p.relative_to(R)):sha(p)for p in tracked}
with patch.object(pg,'embed_texts_with_gemini',side_effect=AssertionError('provider forbidden')),patch.object(builder,'embed_texts_with_gemini',side_effect=AssertionError('provider forbidden')),patch('socket.create_connection',side_effect=AssertionError('network forbidden')):
 reg=pg.load_visual_obligation_registry(A/'photo_prompt_visual_obligations.json');old=next(p for p in reg['profiles']if p['id']==PID);assert old==read(Q/'before-profile.json')
 new=read(Q/'proposed-profile.json');expected=copy.deepcopy(old)
 g=next(x for x in expected['semantics']['component_semantics']['groups']if x['id']=='continuous_departure_route');g['any_terms'].append(NEW)
 expected['evidence_requirements']['departure_route_phrase']['must_mention_any'].append(NEW);assert expected==new
 assert old['evidence_requirements']['departure_route_phrase']['min_content_words']==new['evidence_requirements']['departure_route_phrase']['min_content_words']==15
 for key in ['activation','composition_instruction','required_evidence_fields','render_gates','reject_substitutes','concept_candidate','runtime_expression']:assert old[key]==new[key]
 before_required=old['semantics']['component_semantics']['required_group_ids'];assert before_required==new['semantics']['component_semantics']['required_group_ids']and len(before_required)==5
 assert old['semantics']['component_semantics']['minimum_component_groups']==new['semantics']['component_semantics']['minimum_component_groups']==5
 after=copy.deepcopy(reg);after['profiles'][next(i for i,p in enumerate(after['profiles'])if p['id']==PID)]=new
 ot={p['id']:pg.visual_profile_semantic_text(p)for p in reg['profiles']};nt={p['id']:pg.visual_profile_semantic_text(p)for p in after['profiles']};changed_text=[k for k in ot if ot[k]!=nt[k]];assert changed_text==[PID]
 of=pg.visual_profile_bm25f_documents(reg);nf=pg.visual_profile_bm25f_documents(after);changed_fields=[k for k in of if of[k]!=nf[k]];assert changed_fields==[PID]
 cache=pg.load_json(A/'photo_prompt_visual_profile_index.json');opts=dict(provider=cache['provider'],model=cache['embedding_model'],dimensions=cache['embedding_dimensions'])
 ov=builder.reusable_vectors([A/'photo_prompt_visual_profile_index.json'],reg,**opts);nv=builder.reusable_vectors([A/'photo_prompt_visual_profile_index.json'],after,**opts)
 assert len(ov)==len(reg['profiles']);assert set(ov)-set(nv)=={PID};assert all(ov[k]==nv[k]for k in nv)
 with patch.object(pg,'load_visual_obligation_registry',return_value=reg):c1=pg.load_json(A/'photo_prompt_tags.json')
 with patch.object(pg,'load_visual_obligation_registry',return_value=after):c2=pg.load_json(A/'photo_prompt_tags.json')
 assert c1==c2
 cart=next(x for x in c1['slots']['prop']if x['id']=='biaoju_loaded_cart_sealed_cargo_set');cart2=next(x for x in c2['slots']['prop']if x['id']==cart['id']);assert cart==cart2
 st1={k:pg.semantic_text_for_entry(e,s,kind=t)for k,t,e,s in pg.iter_semantic_entries(c1)};st2={k:pg.semantic_text_for_entry(e,s,kind=t)for k,t,e,s in pg.iter_semantic_entries(c2)};assert st1==st2
 assert pg.semantic_bm25f_documents(c1)==pg.semantic_bm25f_documents(c2)
 checks=[]
 for t in read(Q/'compositions-r2.json'):
  phrase=t['bindings'].get('departure_route_phrase')
  if not phrase:continue
  row=dict(id=t['id'],phrase=phrase)
  for phase,p in [('before',old),('proposed',new)]:
   try:pg.validate_visual_intent_binding(obligation_index=0,field='departure_route_phrase',phrase=phrase,requirement=p['evidence_requirements']['departure_route_phrase']);row[phase]='pass'
   except ValueError as e:row[phase]=dict(status='fail',error=str(e))
  checks.append(row)
 manifest=read(Q/'manifest.json');hashes=manifest['input_hashes'];assert all(sha(Q/f)==h for f,h in hashes.items())
 repair=read(Q/'repair-r2-manifest.json');assert sha(Q/'compositions-r2.json')==repair['compositions_sha256'];assert all(sha(Q/'before'/k/'pack.json')==h for k,h in repair['pack_hashes'].items())
assert start=={str(p.relative_to(R)):sha(p)for p in tracked}
out=dict(verdict='APPROVE_EXACT_TWO_ARRAY_EN_ADDITION_SUBJECT_TO_AFTER_QUALIFICATION',exact_two_appends_verified=True,legacy_EN_KO_anchors_preserved=True,minimum_content_words=15,required_group_count=5,all_other_profile_fields_preserved=True,source_internal_conflict_acknowledged=True,consumer_function_correction='Actual helper is prompt_generator.validate_visual_intent_binding, not nonexistent validate_visual_intent_evidence_requirement named in qualification REVIEW.md.',source_consumers=['prompt_generator.py:6748 validate_visual_intent_binding','prompt_generator.py:7102 candidate_pack_visual_component_match','audit_composed_prompt.py:1801 profile-declared component-anchor checks'],changed_visual_embedding_document_ids=changed_text,changed_visual_BM25F_document_ids=changed_fields,visual_profile_count=len(ot),reusable_vectors_before=len(ov),reusable_vectors_proposed=len(nv),required_fresh_embedding_ids=[PID],all_other_vectors_reusable_unchanged=True,old_embedding_text=ot[PID],proposed_embedding_text=nt[PID],old_BM25F_fields=of[PID],proposed_BM25F_fields=nf[PID],general_index_document_count=len(st1),general_texts_and_fields_unchanged=True,optional_cart_candidate_preserved=True,optional_cart_candidate_sha256=digest(cart),binding_helper_results=checks,original_frozen_input_count=len(hashes),original_frozen_inputs_unchanged=True,repaired_compositions_and_saved_packs_unchanged=True,source_hashes=start,provider_calls=0,source_writes=0)
(P/'proof.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items()if k not in ['binding_helper_results','old_embedding_text','proposed_embedding_text','old_BM25F_fields','proposed_BM25F_fields','source_hashes']},indent=2))
