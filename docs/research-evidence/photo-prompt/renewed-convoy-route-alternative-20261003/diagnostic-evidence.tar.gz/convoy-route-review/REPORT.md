# Independent convoy route DATA review

## Verdict: APPROVE the exact two-array English addition, subject to production AFTER qualification

Profile: `biaoju_guarded_cargo_departure` in `skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations.json`.

Append exactly this existing gate-aligned relation to `continuous_departure_route.any_terms` and `departure_route_phrase.must_mention_any`:

“transport contact points and body orientations continue from yard through gate onto one readable road”

The supplied proposed profile equals the current profile plus precisely those two appends. No source was changed in this review. The source problem is **an internal inconsistency**, not a transcription mistake: the original research itself explicitly conjoins wheels, hooves, handles and body directions. Adoption should preserve that disclosure.

## Why this narrow interpretation is supported

The original `wuxia-20260901/source-research.md` section 6, lines 185–195, has conflicting clauses: component 2 explicitly allows cart, pack animal OR coherent transport unit; component 4 conjoins wheels, hooves, handles and body directions. The current definition and owned-load component preserve the cart/pack alternatives. The current native gate `vo_wuxia_biaoju_route_continuity` already requires generic “Transport contact points and body orientations” continuing from yard through gate onto one road. The proposed sentence therefore recovers an already authored type-independent route relation while leaving the narrower legacy realization valid.

The original source ledger entries `wuxia_biaoju_museum_material_institution` and `wuxia_hebei_biaoju_cargo_escort_history` support commercial owned cargo, martial protection and route continuity, and disclaim a universal vehicle/layout. These records do not prove a new historical practice. They help resolve the package's internal contradictory conjunction in favor of its explicit transport alternatives.

The selected full event remains narrower than generic cargo transport: one bureau/loading origin, owned loaded transport, adult front/rear/flank escorts, continuous yard–gate–road and confound control. No generic caravan or new occupational identity is introduced. The cart-specific optional prop stays cart-specific.

## Verified invariants and consumer correction

`prove_proposal.py` independently checked:

- Exactly two append operations; every original English and Korean anchor remains at its original position
- `departure_route_phrase.min_content_words` stays 15
- Five required groups and minimum five groups stay compulsory
- All activation, composition, evidence fields, render gates, rejects, runtime expression and concept fields remain unchanged
- Full optional candidate `biaoju_loaded_cart_sealed_cargo_set` remains unchanged; its canonical hash is in `proof.json`
- All 52 original frozen input hashes, revised-composition hash and six saved-pack hashes remain intact

One documentation correction: `REVIEW.md` names `validate_visual_intent_evidence_requirement`, which does not exist in this runtime. The actual helper is `prompt_generator.validate_visual_intent_binding` at line 6748. It enforces content-word minima and an accepted literal anchor. `candidate_pack_visual_component_match` at line 7102 uses the required-group list and component terms; it does not itself create a hard obligation. The full composition consumer checks the same source anchors in `audit_composed_prompt.py` around line 1801. This reference typo does not undermine the demonstrated DATA issue.

Using the actual binding helper against existing frozen revised evidence, pack-animal, handcart and Korean-request English evidence fail the old anchor and pass the proposed anchor. The legacy mule-cart binding passes both. The three anchor-free wrong/absent route bindings fail both. These are helper-boundary results; they are not a substitute for actual AFTER CLI/whole-composition replay, and do not make the unavailable component route a target-contract pass.

## Exact retrieval delta: one refreshed vector required

Real builder-helper comparison, with provider/network entrypoints blocked:

- Exactly one of 1,510 visual-profile embedding documents changes: `biaoju_guarded_cargo_departure`
- Exactly that profile's BM25F document fields change
- Real cached-vector reuse falls from 1,510 to 1,509; the sole non-reusable ID is the convoy profile
- All 1,509 other vectors remain reusable and equal
- The separate general semantic corpus's 9,739 embedding documents and BM25F fields remain identical

Unlike the ghost-ship gate-only correction, a fingerprint-only update is insufficient. The added component sentence is included in the allowed semantic-text projection, so integration requires the target's fresh embedding and an updated visual index/BM25F/source binding. Do not copy the old target vector or claim zero required vector updates. This review itself made zero provider calls and persisted no index.

## Qualification assessment and stopping boundary

The existing BEFORE report appropriately distinguishes the component-only route as target unavailable. Its ordinary composition pass is not evidence that the convoy contract accepted the new branch. English evidence on the Korean exact request does not establish Korean binding support.

The retained original insufficient-word/safe-label failures and frozen composition-only repair are transparently disclosed. Repaired evidence elaborates the same selected duties and preserves the public inputs and saved packs. No source proposal changed in response to outcomes. Review does not relabel these source-guided synthetic cases as blind/clean-precore or organic query coverage.

After authorized source/index integration, require actual normal CLI regeneration and unchanged revised-composition replay. New exact-route cases should pass the route binding, legacy and ordinary controls should remain stable, all eight missing/wrong-binding controls should still fail, and component exposure must be recorded as observed without forced selection. Candidate/order changes, if any, must be attributed and reviewed rather than hidden because this is a genuine retrieval-document change.

No rendered pixels, historical authenticity or image-quality claim is supported. This verdict authorizes no provider calls or production mutation by this reviewer.

## Reproduction

From repository root: `python ../daylong-progress-20261002/convoy-route-review/prove_proposal.py`.

Evidence: `proof.json`, `proof.log`, source hash snapshot and exact old/proposed embedding text and BM25F fields embedded in the proof. Original source remains unchanged throughout the proof.
