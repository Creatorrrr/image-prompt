exec(open(__file__.replace('inspect_lanes.py','probe.py')).read().split('result={')[0])
x=json.loads((O/'consumer-proof.json').read_text())
for c in x['cases']:
 core,controls=c['core'],c['controls']
 for name,data in [('before',D),('hypothesis',P)]:
  contract,picked=g.frozen_core_context(data,core,controls)
  focus,fields=g.core_slot_focus_text(data,core,'apparatus_pov')
  eligible=[r for r in data['slots']['apparatus_pov'] if g.core_slot_entry_eligible(data,core,contract,picked,'apparatus_pov',r)]
  ids=['slot:apparatus_pov:'+r['id'] for r in eligible]
  corpus=json.dumps(data['slots'],ensure_ascii=False,sort_keys=True,separators=(',',':'))
  index=g._core_slot_index(corpus)
  query=g.authorial_core_retrieval_text(core)[0]
  c[name]['same_slot_lane_diagnostic']={'focus':focus,'fields':fields,'eligible_ids':ids,'broad':g.rank_bm25f(index,{'global_context':query},allowed_ids=ids,limit=12),'focal':g.rank_bm25f(index,{'slot_focus':focus},allowed_ids=ids,limit=12)}
  print(c['name'],name,[r['document_id'] for r in c[name]['same_slot_lane_diagnostic']['focal']])
 c['retrieved_inventory_unchanged']=c['before']['all_slot_ids']==c['hypothesis']['all_slot_ids']
(O/'consumer-proof.json').write_text(json.dumps(x,ensure_ascii=False,indent=2))
