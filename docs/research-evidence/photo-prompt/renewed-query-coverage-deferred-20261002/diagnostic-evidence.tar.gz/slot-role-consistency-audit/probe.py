from pathlib import Path
import sys,json,copy,hashlib,subprocess
R=Path('REPOSITORY_ROOT');O=Path(__file__).resolve().parent
sys.path[:0]=[str(R),str(R/'skills/photo-prompt-image-generator/scripts')]
import prompt_generator as g
from tests import photo_prompt_fixtures as f
D=g.load_json(R/'skills/photo-prompt-image-generator/assets/photo_prompt_tags.json')
D[g.QUALITY_LAYERS_DATA_KEY]=g.load_quality_layers(R/'skills/photo-prompt-image-generator/assets/photo_prompt_quality_layers.json')
base=next(r for r in D['slots']['apparatus_pov'] if r['id']=='scanner_platen_topdown')
proposed=copy.deepcopy(base)
proposed.update(en='flatbed-scanner optical view through the platen glass from the carriage side',ko='스캐너 유리판 아래 캐리지 쪽에서 유리판을 통과해 보는 광학 시점',tags=[x for x in base['tags'] if x!='topdown'])
# Hypothesis only, not an accepted correction. Preserve all guards and stable ID.
P=copy.deepcopy(D);P['slots']['apparatus_pov']=[proposed if r['id']==base['id'] else r for r in P['slots']['apparatus_pov']]
cases=[
('scanner_optical','An adult office worker holds a hand above a flatbed scanner for a scanner-origin optical portrait.','one adult office worker','an office document scanning room','the hand rests lightly above the platen glass','scanner-origin optical view from beneath the glass'),
('scanner_legacy','An adult office worker in a scanner platen top-down portrait.','one adult office worker','an office document scanning room','the worker presents a document beside a flatbed scanner','scanner platen top-down portrait'),
('external_overhead','An overhead photograph of an adult office worker inspecting an open flatbed scanner.','one adult office worker','an office document scanning room','the worker inspects the scanner from above','external overhead camera showing the scanner glass and open cover'),
('office_overhead','An overhead photograph of an adult office worker sorting documents on a desk.','one adult office worker','an office records room','the worker sorts documents on the desk','top-down composition of hands and paper'),
('peephole','An adult visitor seen through a door peephole.','one adult visitor','an apartment doorway','the visitor waits near the closed door','fisheye view through a door peephole'),
('microscope','An adult scientist examining a magnified specimen in a laboratory.','one adult scientist','a science laboratory','the scientist inspects a specimen','circular magnified microscope field of view')]
result={'git_head':subprocess.check_output(['git','-C',str(R),'rev-parse','HEAD'],text=True).strip(),'slot_count':len(D['slots']),'row_count':sum(map(len,D['slots'].values())),'before':base,'hypothesis':proposed,'cases':[]}
for name,request,subject,setting,event,priority in cases:
 core=f.core(request,subject=subject,setting=setting,event=event,interpreted_intent=request,visual_priorities=(priority,),baseline_prompt_en=f'{subject} is photographed in {setting}. {event}. The image uses {priority}. Spatial relations remain clear across the image, with coherent illumination and continuous forms.',locked_dimensions=('subject','event'),open_dimensions=('camera','composition','framing','lighting','color','material','atmosphere','pose','action','relationship','expression'))
 core['request_binding']={'active_spans':[{'text':request}]}
 controls=g.creative_controls.resolve(request,context={'subject_category':'human'},overrides={'sensual':0,'fetish':0,'creativity':1},seed=1)
 core['creative_controls_sha256']=controls['canonical_sha256'];core['canonical_sha256']=g.canonical_json_sha256(core)
 item={'name':name,'core':core,'controls':controls}
 for label,data in [('before',D),('hypothesis',P)]:
  slots,binding,contract=g.retrieve_core_slots(data,core,controls)
  item[label]={'apparatus_pov':slots.get('apparatus_pov'), 'all_slot_ids':{s:[r['id'] for r in v['candidates']] for s,v in slots.items()},'binding':binding}
 result['cases'].append(item)
 print(name,[(lab, [r['id'] for r in (item[lab]['apparatus_pov'] or {}).get('candidates',[])]) for lab in ['before','hypothesis']],flush=True)
result['projection']={lab:f.project_slot_candidate(data,'apparatus_pov',row) for lab,data,row in [('before',D,base),('hypothesis',P,proposed)]}
result['neighbor_projections']={r['id']:f.project_slot_candidate(D,'apparatus_pov',r) for r in D['slots']['apparatus_pov'] if r['id']!=base['id']}
(O/'consumer-proof.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
