# Slot role consistency audit

## Outcome

No data correction promoted. The strongest new lead was `apparatus_pov/scanner_platen_topdown`, but its authored provenance does not establish scanner-sensor POV rather than an external-camera scanner aesthetic. Reversing its direction would risk rewriting the intended candidate. Six same-query full-corpus production retrieval probes also failed to expose this row in the actual output, so this audit does not establish a production ranking benefit from the hypothetical correction.

No repository edits, provider calls, synthetic vectors, or image-quality claims. All scripts and diagnostic artifacts are isolated in this directory. The baseline commit is recorded in `consumer-proof.json`; source was loaded once for each script.

## Inspected scope

Read the current skill, retrieval contract, schema policy, raw/merged rows, existing instrument-hand and slot data regressions. Visually inspected roles across partner_role, partner_framing, prop_direction, contact_point, relational_action, hand_pose, body_pose, gaze_target, reflection_logic, apparatus_pov, anatomical_connection, body_evidence_region, and duty_prop_state. No blanket exception lists or role restrictions were proposed. Existing instrument fixes were not reopened.

The paired actor/contact candidates retain distinct first/second actor roles, traceable entering limbs, explicit receiving support, and source-specific target scopes. A shared parent alias is not by itself proof that a narrower optional component overwrites a frozen actor. Several pose/optic rows are intentionally particular variants, not universal claims; no corrections were inferred merely because other valid variants exist.

## Scanner lead and exact provenance

Current raw source: `skills/photo-prompt-image-generator/assets/photo_prompt_tags.json`, slots.apparatus_pov, id `scanner_platen_topdown` (around line 94748).

- English: `top-down flatbed-scanner platen light`
- Korean: `스캐너 유리판 위 평면 탑다운 시점`
- Tags: human, pov, apparatus, office, topdown
- Existing primary guard: office/document/inspection/science/technology
- No explicit embedding_text, aliases, keywords, relations, or research_source_urls
- Schema ownership: camera

`project_slot_candidate` exercises `candidate_pack_summarize_slot_candidate`, v6 surface projection, `apply_public_semantics`, and detail-view verification. The actual public semantic surface keeps the entire English phrase as one optional concept unit; no actor or scanner/carriage relation is supplied. The generated semantic text therefore derives from the same ambiguous label, not a separate authored optical explanation. Neighbor apparatus rows explicitly name views through peepholes, mirrors, and keyholes, suggesting device viewpoint, but not enough to override contrary history.

The original introduction is commit `f815680b` (`Expand photo prompt concept anchors`). The row already had the same bilingual top-down wording. Historical preset `scanner_platen_topdown_portrait` explicitly called itself a scanner platen top-down portrait and selected ordinary 35mm, 50mm, 85mm, or macro_100mm camera lenses. It allowed top_down, hands_first_task_pov, or document_foreground_face_background composition. This is positive evidence of an external-camera scanner aesthetic or at least mixed intent. Presets were subsequently removed in `0ff27d08`; the surviving candidate is not sufficient evidence to settle that intent. Snapshot and full relevant preset are in `legacy-scanner-preset.json`.

## Physical source check

Epson's primary hardware diagram places the carriage beneath the scanner glass:
https://files.support.epson.com/docid/cpd6/cpd62790/source/scanners/source/product_info/references/v19_v39/v19_v39_parts.html

Epson's original-placement instructions require the scanned face toward the glass:
https://files.support.epson.com/docid/cpd6/cpd62639/source/placing_originals/tasks/placing_originals_glass.html

Thus a scanner-origin optical image and an external top-down camera image have different device-to-subject directions. This physical distinction is supported; the claim that the old candidate necessarily means the former is not. No assumption about human contact safety, scanner imaging quality, or artistic desirability follows.

## Isolated hypothesis and consumer controls

`probe.py` creates a deep-copy-only hypothesis changing bilingual labels to a flatbed-scanner optical view through platen glass from the carriage side, dropping only the topdown tag. IDs, guards, weight, and unrelated rows remain intact. This is an unaccepted hypothesis, not a proposed patch.

Both arms use the identical core and control snapshot for each of six scenes: scanner-origin optical portrait, legacy top-down scanner portrait, external overhead scanner inspection, overhead document sorting, door peephole, and microscope. Every call runs actual `retrieve_core_slots` across all 112 slots / 9,664 loaded slot rows with current quality-layer context. Public projection and verified detail output are recorded for the target and all five apparatus neighbors. `inspect_lanes.py` adds actual production BM25F same-slot broad/focal lane output, preserving the full corpus statistics; these lane diagnostics are explicitly not actual PACK admission.

All six actual retrieved inventories are byte-equivalent at the candidate-ID level across arms. The apparatus slot is absent in both full-PACK arms for all six cases. Each actual inventory reaches the 64-candidate cap before this support slot. Consequently a standalone public projection of the changed candidate cannot establish an actual scene retrieval improvement. Do not promote this on lexical score movement alone, and do not insert an observation-discovery flag solely to force the example into the output.

## Decision and reopening condition

Defer scanner mutation. To reopen, obtain source evidence distinguishing the intended camera/device role and a genuine production consumer case where that source-authorized correction changes a wrong admitted candidate value. If the intended role is external overhead photography, keep it or clarify that role only with corresponding evidence; do not rotate it into scanner-origin view. The cap behavior is a runtime inventory issue, not a reason to accumulate data exceptions or weaken source guards.

Lane-only detail: the hypothesis moves the scanner row from focal rank 4 to 1 in scanner-origin text and from 1 to 4 for generic overhead office text, while peephole and microscope remain rank 1 for their own controls. However, it also moves the scanner row from 2 to 1 for external-overhead scanner inspection, exposing exactly the unresolved device-versus-external-camera semantic ambiguity. None of these movements change actual admitted inventories.
