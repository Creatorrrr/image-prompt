import json,sys,pathlib,hashlib,subprocess,os
sys.dont_write_bytecode=True
O=pathlib.Path(__file__).parent;R=O.parent.parent/'image-prompt';sys.path[:0]=[str(R),str(R/'skills/photo-prompt-image-generator/scripts')]
import prompt_generator as pg
from tests import photo_prompt_fixtures as fx
sha=lambda x:hashlib.sha256(x.encode()).hexdigest()
cases=json.loads((O/'heldout.json').read_text());cases=(cases.get('cases') or cases['positive_cases']+cases['negative_cases']) if isinstance(cases,dict) else cases
c=cases[0];q=c.get('text') or c.get('query') or c.get('query_text');env=fx.envelope(q);ctl=pg.creative_controls.resolve(q,overrides={'sensual':0,'fetish':0,'creativity':1,'surreal':0},seed=706)
core=fx.core(q,interpreted_intent=q,subject='one physical still life',setting='a continuous physical environment',event='the arranged objects occupy distinct depths',visual_priorities=('depth-specific sharpness','recognizable near and far forms','continuous optical transitions'),baseline_prompt_en=q.replace('do not soften the entire photograph with one even filter.', 'the focused slice remains sharply resolved while spatial separation controls softness on either side.'),locked_dimensions=('concept','subject','event'),open_dimensions=('framing','lighting','color','material','atmosphere'));core['creative_controls_sha256']=ctl['canonical_sha256'];norm=pg.normalize_authorial_core(core,request_envelope=pg.normalize_request_envelope(env),creative_control_snapshot=ctl)
base=core['baseline_prompt_en'];review={'contract_version':'photo-embodiment-review/v1','provenance':'agent_prepack','prompt_sha256':sha(base),'scope':'not_applicable','summary':'This still life describes objects at different depths without person or animal body action. Text-only applicability review; no rendered image assessment.','checks':{}}
pg.photo_embodiment.build_policy(norm,review)
D=O/'public-cli-baseline';D.mkdir(exist_ok=True)
for n,v in [('request-envelope',env),('creative-controls',ctl),('authorial-core',core),('embodiment-review',review)]: (D/(n+'.json')).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
cmd=[sys.executable,str(R/'skills/photo-prompt-image-generator/scripts/generate_photo_prompt.py'),'--seed','706']
for n in ['request-envelope','authorial-core','creative-controls','embodiment-review']:cmd+=['--'+n+'-json',str(D/(n+'.json'))]
cmd+=['--output-file',str(D/'pack.json')]
p=subprocess.run(cmd,cwd=R,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},capture_output=True,text=True,timeout=240)
(D/'stdout').write_text(p.stdout);(D/'stderr').write_text(p.stderr)
report={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'command':cmd,'exit_code':p.returncode,'request':q,'baseline_prompt':base,'scope':'Unmodified public CLI with genuine current index and authored candidate-free inputs. Not a trial-after result; no provider calls initiated by this audit.'}
if p.returncode==0:
 pack=json.loads((D/'pack.json').read_text())[0];report['obligation_ids']=[o['id'] for o in pack.get('visual_obligations',{}).get('obligations',[])];report['target_string_occurrences']=json.dumps(pack).count('shallow_depth_focus_falloff_relation')
(D/'manifest.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps(report,ensure_ascii=False));print(p.stderr[-2000:])
