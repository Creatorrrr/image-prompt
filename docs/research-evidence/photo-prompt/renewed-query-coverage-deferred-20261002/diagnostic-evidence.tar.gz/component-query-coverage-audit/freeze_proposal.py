import json,pathlib,hashlib
O=pathlib.Path(__file__).parent
proposal={
'shallow_primary_plane':['narrow crisp focus plane','thin plane of sharp detail','좁고 선명한 초점면'],
'shallow_foreground_falloff':['progressive foreground focus falloff','foreground progressively loses focus','전경의 점진적 초점 이탈'],
'shallow_background_falloff':['progressive background focus falloff','background progressively loses focus','배경의 점진적 초점 이탈'],
'shallow_optical_edges':['continuous optical edge transition','defocus transitions continuously across occlusions','가장자리의 연속적인 광학적 초점 전이'],
'shallow_not_global_softness':['depth-dependent defocus','depth-driven focus falloff','깊이에 따른 초점 이탈']}
(O/'frozen-short-cue-proposal.json').write_text(json.dumps(proposal,ensure_ascii=False,indent=2)+'\n')
print(hashlib.sha256((O/'frozen-short-cue-proposal.json').read_bytes()).hexdigest())
