# Shallow-focus natural-query coverage audit

## Decision: defer, no repository change

At baseline commit `dbfd897ce20b5c7c21456af2234ec140e42676a9`, tested exactly one existing capture profile: `shallow_depth_focus_falloff_relation`. A frozen, source-grounded short-cue trial did **not** improve any of four independent complete natural scene queries. It also permitted a short-cue caption-owner negative. There is no qualified data-only improvement to recommend from this audit. This rejects the tested proposal, not a mathematical claim that no finite lexicon could ever improve recall.

The real unmodified public CLI completed successfully for the same held-out greenhouse request with **zero target candidate or obligation occurrences**. All files in this directory are evidence outside the repository; no providers, repository edits, index fabrication, runtime change, or image generation were used.

## Actual consumer, not merely contract acceptance

`prompt_generator.py:6500–6526` computes `semantically_applicable_ids` before BM25F ranking and before vector scoring. This profile sets `semantic_discovery_requires_component_evidence=true`; it is removed unless `candidate_pack_visual_component_match` returns a result.

`candidate_pack_visual_component_match` at lines 7094 onward preserves exclusions, matches each group's `any_terms` with `intent_alias_matches`, requires all five required IDs and minimum five groups, and also has a fallback for a complete authored `paraphrase_examples` match. The existing fallback was not modified.

`intent_alias_matches` at lines 2702 onward is normalized contiguous phrase matching, with negation checks, English word boundaries/plural handling and CJK substring behavior. BM25F token coverage does not satisfy these phrase guards. The gate applies to both ranking lanes, so a better embedding alone cannot rescue a query removed at this stage.

The five component groups own: a narrow crisp plane; recognizable progressively defocused foreground; recognizable progressively defocused background; continuous optical transitions across object edges; and depth-driven, not global, softening. All required IDs, minimum groups, activation, exclusions, evidence requirements, instructions, render gates, labels, and paraphrases were preserved in the experiment. Only appended `any_terms` were changed in memory.

## Independent and frozen evaluation

`frozen-short-cue-proposal.json` was frozen before the independent controls were delivered (SHA-256 `53eb58d1409887b623d35ff3f1e39a15cf2f01e382bd6cce8db950bb268047ee`). Its 15 terms are compact relational phrases derived from existing concept cues, definition and instructions, with EN/KO alternatives. Examples are `narrow crisp focus plane`, `progressive foreground focus falloff`, `continuous optical edge transition`, and `depth-dependent defocus`. They are not copies of the held-out queries. These remain an unapproved trial: shortening loses some explicit owner/recognizability detail even when the intended technical meaning is sensible.

An independent worker read only the current source profile and authored four complete positives and five negatives without viewing that proposal. `heldout.json` SHA-256 is `51ef6a50c3bd3385725abe4aa72493a7d7a4533a5cbf4c39dae9049d0096a286`. Positives comprise two English scenes, one Korean scene and one EN/KO code-switch scene. Each includes explicit evidence for all five source relations. None copies a complete any_terms or paraphrase_example. Negatives remove/change a necessary relation or assign the phrases to a poster rather than the requested photograph.

## Results

Full 1,496-profile real resolver with the genuine, registry-bound checked-in index:

- Greenhouse English: target raw/unfiltered BM25F rank 5; component gate fails; zero target hits
- Violin-bench English: raw rank 1; component gate fails; zero target hits
- Pottery-shelf Korean: raw rank 3; component gate fails; zero target hits
- Station-model code-switch: raw rank 1; component gate fails; zero target hits

Full-registry in-memory lexical-only short-cue trial:

- Same four queries: zero target hits, zero matched component groups, despite raw target ranks 2, 1, 3, 1
- All five independent negative controls remain rejected
- A deliberately cue-containing smoke query becomes one optional BM25F hit, never hard-eligible
- Removing foreground progression, requesting excluded global soft focus, or explicitly negating the foreground cue each keeps the target rejected
- A museum-sign query listing all short cues while asking for every scene depth to remain sharp incorrectly becomes an optional hit. This is a failed owner check. It is not proof that the baseline matcher generally solves ownership; complete long phrases could have the same lexical limitation. It is enough to reject this cue trial as a validated ownership-preserving gain

Thus canonical cue acceptance is not independent natural-query improvement. It would be misleading to report the smoke-query pass as a useful recall fix.

## Genuine public baseline, separately identified

`public-cli-baseline/manifest.json` records the ordinary public `generate_photo_prompt.py` invocation, request/core/control/review inputs, commit and exit code. The request is the exact held-out greenhouse query. Its authored baseline preserves the scene and all five relations, expressing the final global-softness exclusion positively because the normal core validator rejects a blanket negative command inside baseline prose. The request itself was not changed. No candidates or target IDs were injected into inputs.

Result: exit 0, `obligation_ids=[]`, target string occurrences across the complete emitted pack = 0. A missing hard obligation by itself would be expected for optional discovery; the zero target occurrences also proves there was no target optional candidate in this output.

`results.json` is a separate resolver diagnostic. Its baseline loads the genuine 768-dimensional Gemini index, but supplies no query vector; it measures the actual BM25F lane and pre-ranking gate, not vector retrieval. Its proposal uses the actual builder without any supplied vectors, producing empty entry vectors. The builder retains default dimension metadata 768, which does not mean vectors were generated or evaluated. Every resolver row has `embedding_evaluated=false`. No public after-index or public after-CLI result is claimed.

The trial changes positive retrieval text, so an eventual accepted proposal would require the normal registry-bound genuine index rebuild, including a fresh target embedding. It must not reuse the old target vector or fabricate one. No such rebuild is justified by these results.

## Existing tests and boundaries

The existing capture semantic suite passed: 8 tests, recorded in `existing-tests.log`. Its relevant coverage is five-group contract shape, exact narrow aliases, broad-label nonactivation, negative exact routing and index integrity. Its semantic optional-candidate example is a different panning profile with source-authored compound language and a fake two-dimensional test index; it does not establish held-out shallow-focus recall. This audit did not use that fake index.

No broad words, removed groups, relaxed exclusions, negation exceptions, exact test-sentence additions, phrase-specific runtime behavior or guard bypasses were introduced. For this profile, natural phrasing varies across subject nouns, word order and bilingual morphology while retaining all the actual relations. Shortening to ownerless words would inflate coverage but violate the assignment. Defer rather than shipping vocabulary tailored to these four test cases.

## Reproducibility

- `probe.py`: real full-registry resolver, raw rank diagnostic, independent cases and local guard/owner tests
- `results.json`, `probe.log`: full outcomes and source hashes
- `before-profile.json`, `trial-profile.json`: exact baseline and unapproved in-memory proposal
- `public_baseline.py`, `public-cli-baseline/`: public baseline inputs, pack, log and manifest
- `freeze_proposal.py`, `frozen-short-cue-proposal.json`, `heldout.json`: frozen proposal and independent inputs

Re-run against the recorded commit for identical source hashes. The parent was allowed to resume unrelated source edits after baseline completion.
