# Botanical tendril contact-coiling: DATA-only feasibility

## Decision

**DEFER this optional extension from the current improvement cycle.** There is genuinely missing morphology/attachment coverage at source pin `8a0fb5b8dd30d70bc9dbae7f63fbce38daa3bbfc`, and a single profile is structurally consumable without runtime changes. However, the coordinator independently qualified the proposed draft against an already-frozen living-vine case and reported zero component matches in all four original English/Korean request and baseline checks. Those inputs were not shared with or inspected by this worker, and no synonyms were tuned to them. The clean development positives therefore do not establish natural-case recovery. Preserve the source-grounded profile as research only; do not pay to embed or merge it as a demonstrated improvement. Explicitly targeted contract coverage can be evaluated separately, with no broad discovery claim.

This assessment read repository source, existing general contract tests and relevant historical reports. It did not inspect any fresh 48-hour nonhuman request/core/replay folders. No source was edited, no provider was called and no image was generated. Scratch diagnostics here are development probes, not independent evaluation.

## Primary evidence and what it supports

1. **Gerbode, Puzey, McCormick and Mahadevan, Science (2012), How the Cucumber Tendril Coils and Overwinds.** DOI https://doi.org/10.1126/science.1223304; author-hosted full paper and supplement https://softmath.seas.harvard.edu/wp-content/uploads/2019/10/2012-18.pdf. Supplementary Figure S1, PDF page 17, explicitly separates initial wrapping of the tendril tip around a support rod from later helical shortening of the suspended segment. This directly supports the distinct plant–tendril–rod topology and prevents treating an unattached spring shape as support contact. The study concerns cucumber/wild cucumber, not every climbing plant. Its internal tissue and force results are not obligations for an ordinary external photograph.
2. **Klimm, Speck and Thielen, Advanced Science (2023), Force Generation in the Coiling Tendrils of Passiflora caerulea.** DOI https://doi.org/10.1002/advs.202301496; actual article https://pmc.ncbi.nlm.nih.gov/articles/PMC10558631/; PubMed identity https://pubmed.ncbi.nlm.nih.gov/37544907/. Figure 7 describes an independently retained plant stem at the tendril base and a separate sensor handle encircled by the tendril apex. Introduction/Figure 1 distinguish contact attachment from free coiling. The force measurements required a force sensor and temporal measurement; a still photograph does not establish them. The publisher full-text search result was available; direct publisher fetch returned 403 and direct PMC fetch returned a browser-check page. The search-indexed primary full text supplied the relevant figure caption and method. **PMC10558661 is the cover notice, DOI 10.1002/advs.202370189, not this experimental article.**
3. **Klimm et al., Journal of Experimental Botany (2022), Biomechanics of tendrils and adhesive pads of the climbing passion flower Passiflora discophora.** https://academic.oup.com/jxb/article/73/4/1190/6407680; DOI https://doi.org/10.1093/jxb/erab456. This supplied lead is a valuable contrast: adhesive terminal pads can attach to broad or flat substrates, and free coiling can occur between attachment endpoints. Its P. discophora photographs must not be relabeled as direct evidence of a tip encircling a rod. Its introduction also distinguishes twining stems, contact-coiling tendrils and adhesive attachment.
4. **Royal Botanic Gardens, Kew, Evolve and adapt card sort.** https://endeavour.kew.org/sites/endeavour/files/documents/2022-06/Kew-KS2-Evolve-and-adapt-Adaptations-card-sort.pdf, page 3. It associates passionflower with climbing tendrils but does not establish detailed attachment topology. Kew's species account https://www.kew.org/plants/purple-passionflower identifies P. incarnata as a tendril climber. These are corroborating botanical context, not substitutes for the direct experimental evidence above.

The required photographic geometry below is an authored observable abstraction of those sources. It is not a claim that anatomy, species, growth history or measured performance can be diagnosed from a picture.

## Missing coverage

A focused scan of authored photo assets, excluding generated index documents, found no plant-tendril contact-coiling candidate or visual profile. Adjacent living-plant entries include `fern_unfurling`, `rice_seedling_tray`, `pollinator_moth_night`, the pollinator–flower observational relation and the natural-environment landscape/root-system families. Their actions or owners are different, so adding tendril aliases to those entries would be a semantic substitution.

The natural-environment extension currently has 75 rows across seven slots (12 aesthetics, 12 subjects, 12 actions, 12 locations, 11 surfaces, 12 compositions, four weather entries). Its eight structural hard profiles cover forest, wetland, intertidal, karst, glacier, dunes, storm and treeline relations. Mangrove root attachment is not an equivalent climbing-organ support relation.

Existing `tendril` matches principally concern `y2kr_tendrils`/face-framing hair, hair-profile counterexamples, or `ink_in_water_vessel`. Generic greenhouse, moss, flower and overgrown-setting prose does not carry the proposed relation.

## Minimal target and generated consequences

- Authored target: `skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations.json`, append one row at `profiles[]` with stable ID `botanical_tendril_contact_coiling`
- Existing schema: `photo-visual-obligation-registry/v3`; component source: `authored_components` using `photo-authored-visual-components/v1`
- Proposed source row: `proposed-profile.json` in this scratch directory; this is a draft, not a repository patch
- Generated target: `skills/photo-prompt-image-generator/assets/photo_prompt_visual_profile_index.json`, rebuilt from the changed registry through the existing builder
- Focused proposed test: `tests/test_photo_tendril_contact_coiling_data.py`
- Source provenance can be appended through the existing research-evidence record convention after acceptance; no new loader is needed

Do not create `photo_prompt_visual_obligations_natural_environment.json`: the runtime's extension names are an explicit tuple, and this unregistered filename would be dead data unless runtime code changed. Existing natural profiles already reside in the main registry. The existing natural candidate extension is loaded, but a new ordinary action row would also require auditing its full geometry/relationship effects and primary subject compatibility, and it would change the generic dictionary index. A single profile isolates this relation and avoids inventing a scene cluster solely to make an action reachable.

A profile-only addition leaves ordinary slot rows and `dictionary_hash()` inputs unchanged. The visual index must change: one new profile vector, one precise English exact surface in this draft, rebuilt exact/BM25F structures and new registry hash. Reuse every unchanged vector only by byte-identical text and identical provider/model/dimensions. The normal builder will call the provider for a missing vector. This assessment did not do so, and a vectors-empty scratch index is never a production replacement. Check the general index remains valid rather than rebuilding it needlessly.

## Concrete meaning and safeguards

The four independent visible duties are:

1. **Plant ownership:** the tendril base can be traced continuously into its living leafy plant
2. **Organ distinction:** the slender tendril remains distinguishable from the main leafy stem
3. **Actual support contact:** the same tendril passes around and meets the exterior of the support; the front/back occlusion and visible curvature agree with wrapping, without a floating gap, impossible penetration or fused material
4. **Separate support identity:** the support stays distinguishable from both stem and tendril, with coherent visible contours on either side of genuine tendril occlusion

The support can be a rod, twig, trellis part or string. A string used as support is valid; string substituted for the biological tendril is not. An attached coil cannot be established merely by placing disconnected curls beside a plant or by a caption calling them tendrils. Overlapping silhouettes with no readable junction/contact are insufficient. A photographic image can support visible attachment topology, not its force or hidden contact area.

Preserve these boundaries:

- Whole-stem twining does not substitute for a separate climbing tendril
- Adhesive pads against a flat wall do not substitute for the tip winding around a slender support
- Free helical shortening between endpoints is distinct from contact coiling; it is optional and does not replace the wrapping region
- Do not prescribe a universal axillary, leaf-derived or stem-derived origin; tendril ontogeny varies
- Do not prescribe species, flower, pot, stem color, support material, coil count, winding handedness or camera recipe
- Do not infer elapsed growth, direction/speed of motion, turgor, cellular mechanism, strength, measured force, ecological benefit or species identification from one image
- All checks are native-scale relational checks. Partial/missing/occluded evidence cannot pass. A wider attractive photograph does not repair an unreadable junction

## Production consumer semantics

The main registry is loaded by `load_visual_obligation_registry()` and components are generically compiled by `visual_profile_contracts.compile_visual_profile()`. The draft provides all four components once; the compiler derives the component groups, evidence fields, instruction and render gates.

- `activation.exact_terms` contains only the complete four-part visible definition. It deliberately contains no bare `tendril`, `climbing plant`, `passionflower`, `vine`, `덩굴손` or species shorthand. Full requester-owned exact meaning can activate a hard obligation; descriptive discovery cannot
- `requires_adult_character` is false; no adult/safety policy changes
- `semantic_discovery_requires_component_evidence` is true. Development wording requires a plant-qualified tendril/plant-origin cue, the organ, a wrapping relation and a support cue. This uses the existing generic component guard, not a new parser
- `concept_candidate.affected_dimensions` is explicitly `body_geometry` and `relationship`. Opt-in is available only when both are genuinely open under the frozen intent lock; the existing projection suppresses it if either is locked. Do not remove these fields to manufacture retrieval gain
- Do not enable `core_assertion_discovery` for this small profile: that additional lane is unnecessary to prove reachability and has a distinct eligibility path
- BM25F/embedding resolution is advisory. `candidate_pack_visual_concept_candidates()` packages four gates under `opt_in_contract`; unselected candidates impose no prompt or review duties. Selecting the profile promotes the complete contract, never an arbitrary subset
- Requester definitions and exclusions continue to take precedence. None of the contrast strings are global negative-prompt entries or a veto on valid string supports
- Candidate discovery is not semantic ownership verification. Co-occurring botanical/coil/support words, even in one sentence, do not prove those relations are true or compatible with locked meaning. The composer must read the complete contract and reject an inapplicable hit

This intentionally has a narrow useful reach. A request that locks the contact geometry and relationship should be honored by its existing frozen request/typed assertions; the optional profile is not a loophole for altering it. The new profile can support open-detail botanical compositions and fully specified direct bindings without changing routing or the pre-core phase.

## Evidence collected versus still required

`offline-probe-results.json` records the final scratch schema/compiler/resolver/projection checks. The final version corrects a geometric ambiguity: support contours may be genuinely occluded by tendril wraps and need only continue coherently on either side. It also preserves the mixed-owner, air-gap and raw negated-wrapper controls requested in review. `offline-probe-scoped-schema-failure.json` retains a development schema failure: once scoped candidate effects were added, the schema required positive `semantics.visual_components` for its concept-unit projection; adding those existing-schema fields resolved that failure. No runtime code was changed. `offline-probe-unscoped-initial.json` preserves the first discovery-only probe before explicit effect scope and qualified ownership cues were added. These probes use the full current profile corpus and the unchanged resolver, with a derived vectors-empty index. They do not pretend to be production index validation or independent authorial work.

### Final observed results

- Schema/compiler validation: passes with zero errors
- Consumer scope-projection microchecks: 4/4 pass; open body geometry plus relationship permits the candidate, while either closed suppresses it
- Development resolver probes: **19/21 pass; two preserved failures**
  - Mixed owner: a straight living-plant tendril is merely near the rod, while separate string wraps it. The profile is incorrectly offered as an optional candidate
  - Air gap: an apparent tendril coil surrounds the rod in projection, but an explicitly clear gap separates them. The profile is incorrectly offered as an optional candidate
  - Neither failure creates a hard obligation. Neither is a complete bound-v3 composed adoption test, so they establish a resolver precision limit rather than proving a locked request was changed
  - The raw negated-wrapper control, excluded-source control, bare labels and isolated twining/pad/hair/ink/decorative controls remain absent
- Coordinator's independent component generalization: **0/4 matches**, without worker access to those request/core inputs
- Repository remains clean at the original pin. Provider/image calls: zero

The combined outcome is a scientific coverage opportunity with an unqualified data proposal, not an accepted extension. No negative keyword vetoes were added after these failures. No synonym tuning followed the independent result. The next step for this cycle is to move to another genuinely promising topic, retaining this evidence for a later explicit-contact contract study if warranted.

The test plan is falsifiable:

1. **Data integrity:** exactly one new profile, all old semantic texts/IDs/exact terms/effect scopes unchanged, no runtime or pre-core edits; schema validation passes; generated visual index matches the final registry and complete vector cardinality
2. **Independent positive reach:** fresh complete English and Korean v3 request/core artifacts, authored by a writer who has not read this proposal, must expose the profile as optional in actual public candidate output for plant-owned contact-coiling with open effects. Include a rod, a twig and a string support
3. **Near negatives:** whole-stem twining, adhesive pads, unsupported free coils, detached wire/string, artificial vines, hair tendrils and ink must not gain this optional profile on the corresponding isolated cores. Mixed-owner near negatives must be tested and reported; a composer can reject an advisory hit, but unexplained cross-owner leakage must not be called a clean retrieval success
4. **Meaning authority:** bare labels create no hard obligation. Negated/excluded contact coiling and an explicit alternative requester definition must not be reintroduced. Complete requester-owned exact definition and valid explicit post-core binding can create all four duties only
5. **Scope:** both effect dimensions open permits optional projection; either closed suppresses it. Property-lock conflicts and a locked no-contact condition cannot be bypassed. Profile selection never edits the frozen core or creates requester ownership retrospectively
6. **Opt-in mutation tests:** select none and show zero new duties. Select this profile and show all four evidence fields and native gates. Delete each evidence phrase separately, disconnect the plant base, substitute twining or pads, detach/float the contact, or fuse/penetrate the support; the corresponding prompt/audit or pixel review must fail at its own evidence layer
7. **Privacy/regression:** public views must not expose rank, vector, matched term or private score; existing natural-environment and hair-tendril behavior is unchanged. Run affected visual-profile, authorial core, intent precedence, composer-view and index-integrity tests
8. **No fabricated image result:** no image was generated here. Prompt/compiler success is not pixel attachment fidelity. Any later render campaign must be independently authorized and preserve failures and source binding

**The independent-reach stopping condition has already been met: defer.** If revisited for a separately justified purpose, stop/defer if independent positives are unreachable under honest effect scope, new embedding work is unavailable, adjacent confounders cannot be distinguished without broad scene rewrites, or success would require runtime keyword exceptions. No universal coil claim, new generation call, index bypass, synthetic production vector or weakening of requester locks is justified by this proposal.
