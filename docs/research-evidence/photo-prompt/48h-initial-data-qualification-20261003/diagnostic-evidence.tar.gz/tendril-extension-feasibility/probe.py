"""Offline feasibility only: no repository writes, network, image or vector provider."""
from pathlib import Path
import sys,json,copy,hashlib,subprocess
ROOT=Path('REPOSITORY_ROOT')
OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'skills/photo-prompt-image-generator/scripts'))
import prompt_generator as pg
import validate_photo_prompt_dictionary as vd
from visual_profile_contracts import compile_visual_profile
A=ROOT/'skills/photo-prompt-image-generator/assets'
components=[
 ('plant_origin',['plant tendril','cucumber tendril','passionflower tendril','pea tendril','tendril attached to its plant','tendril grows from','식물의 덩굴손','오이 덩굴손','시계꽃 덩굴손','완두 덩굴손'], 'the tendril base remains continuously attached to its living leafy plant', 'Keep the tendril base visibly continuous with the living plant that owns it.', 'The tendril base joins the plant continuously; a detached cord near foliage fails.'),
 ('slender_tendril',['tendril','덩굴손'], 'a slender tendril branches from the plant while the main leafy stem remains distinct', 'Keep the slender climbing organ distinguishable from its main leafy stem.', 'The wrapping organ is a slender plant-owned tendril, distinguishable from the main leafy stem.'),
 ('contact_coil',['coils around','coiled around','wraps around','wrapped around','감싼','감긴','감고'], 'the tendril coils around and contacts the outside of the support', 'Show the tendril curving around the support with credible contact and front-to-back occlusion.', 'Visible tendril arcs wrap around the support exterior with credible contact and occlusion, rather than passing through it.'),
 ('separate_support',['support','rod','twig','trellis','지지대','가지'], 'the separate support has coherent visible contours on both sides of tendril overlaps', 'Keep the support distinguishable from the plant, with coherent contours visible on both sides of tendril overlaps.', 'The support and plant stem remain distinct; support contours continue coherently on either side of tendril overlaps, allowing real occlusion.'),
]
full='; '.join(c[2] for c in components)
profile={
 'id':'botanical_tendril_contact_coiling',
 'category':'natural_environment_plant_attachment',
 'activation':{'exact_terms':[full], 'requires_adult_character':False, 'semantic_discovery_requires_component_evidence':True},
 'semantics':{
  'visual_components':[c[2] for c in components],
  'definition':'A living plant is attached to a separate slender support by a plant-owned tendril whose tip coils around and contacts the support. The tendril remains continuous with its plant, while the main leafy stem, wrapping tendril, and support have distinguishable contours with coherent continuation across real occlusions.',
  'paraphrase_examples':['a cucumber plant tendril coiled around a separate rod with its plant attachment visible','a passionflower tendril wrapped around a supporting twig while remaining attached to its plant','살아 있는 식물의 덩굴손이 별도 지지대를 감고 있으며 식물에서 이어지는 부착부가 보인다'],
  'contrast_examples':['a main plant stem twining around a pole','adhesive tendril pads attached to a flat wall','a detached piece of string looped around a plant','decorative artificial vines','hair tendrils beside a face','a free helical tendril suspended without wrapping a support'],
  'claim_limits':['This is one selected contact-coiling configuration, not a universal climbing-plant feature.','Tendril developmental origins vary across taxa; no universal leaf, stem, or axil origin is prescribed.','Free helical contraction between plant and support is distinct from contact coiling and is optional here.','One image cannot establish growth direction, speed, force, contact-response physiology, or exact species.','A string may be the separate support; artificial string cannot substitute for the plant-owned tendril.','A species, stem color, turn count, handedness, support material, flower, pot, or camera recipe is not required.']},
 'concept_candidate':{'affected_dimensions':['body_geometry','relationship'],'concept_terms':['botanical tendril contact coiling','living plant tendril attachment','tendril wrapped around separate support','덩굴손 지지대 감김']},
 'runtime_expression':{'default_mode':'definition_with_optional_label','prompt_label_terms':[],'forbidden_prompt_terms':[],'runtime_forbidden_labels':[]},
 'reject_substitutes':['whole_stem_twining_only','adhesive_pad_only','detached_string_as_tendril','decorative_artificial_vine','free_coil_without_support_wrap','plant_tendril_discontinuity','support_penetration_or_fusion'],
 'authored_components':{'contract_version':'photo-authored-visual-components/v1','components':[{'id':i,'match_terms':m,'evidence_field':i+'_phrase','evidence_terms':[p],'min_content_words':5,'instruction':inst,'render_gate':{'id':'vo_tendril_'+i,'review_scale':'native','description':desc}} for i,m,p,inst,desc in components]}
}
(OUT/'proposed-profile.json').write_text(json.dumps(profile,ensure_ascii=False,indent=2)+'\n')
registry=pg.load_visual_obligation_registry(A/'photo_prompt_visual_obligations.json')
profile=compile_visual_profile(profile)
registry['profiles'].append(profile)
# This scratch file is a merged copy, never an authoritative asset.
merged=OUT/'scratch-merged-registry.json'
merged.write_text(json.dumps(registry,ensure_ascii=False))
errors=[]
vd.validate_visual_obligation_registry(merged,errors)
index=pg.build_visual_profile_index_payload(registry)
queries=[
 ('positive_en_rod','A cucumber plant tendril is coiled around a separate support rod, its base visibly connected to the leafy plant.',True),
 ('positive_en_twig','A passionflower tendril wrapped around a separate twig, still joined to the living plant beside it.',True),
 ('positive_en_string_support','A living plant tendril coils around a string support, connected at its base to the leafy stem.',True),
 ('positive_ko','살아 있는 식물의 덩굴손이 별도 지지대를 감고 있으며 식물에서 이어지는 부착부가 보인다.',True),
 ('negative_hair','Face-framing tendrils curl beside a woman in a botanical greenhouse.',False),
 ('negative_ink','Ink tendrils curl through water in a glass beside a potted plant.',False),
 ('negative_twining','A bean plant with the whole main stem twining around a narrow support rod.',False),
 ('negative_pads','A Passiflora discophora plant with tendril adhesive pads attached to a flat support wall.',False),
 ('negative_free_coil','A living cucumber plant tendril forms a free helical spring suspended beside a support, without contact.',False),
 ('negative_string','A living plant is fastened to a support rod with a string wrapped around its stem.',False),
 ('negative_artificial','A decorative artificial vine is wrapped around a trellis.',False),
 ('negative_wrong_owner','A living plant stands beside a detached synthetic tendril coiled around a separate support rod.',False),
 ('negative_mixed_owner','A living plant tendril remains straight near a support rod while a separate string is coiled around the rod.',False),
 ('negative_no_contact_gap','A living plant tendril is coiled around a support rod in perspective but separated from the rod by a clear air gap.',False),
 ('negative_wrapper_raw','A living plant tendril is not coiled around a support rod and does not touch it.',False),
 ('broad_tendril','tendril',False),('broad_plant','plant',False),('broad_climber','climbing plant',False),('broad_ko','덩굴손',False),
 ('full_exact',full,True),
 ('explicit_excluded',full,False),
]
results=[]
for name,q,expected in queries:
 rows=[{'source':'concept_lock','text':q,'polarity':'excluded' if name=='explicit_excluded' else 'required'}]
 if name!='explicit_excluded': rows.append({'source':'authorial_core_interpretation','text':q,'polarity':'advisory'})
 resolution=pg.resolve_visual_profile_hits(registry,rows,visual_profile_index=index,query_text=q,query_fields={'active_request':q})
 hits=[h for h in resolution['hits'] if h['profile_id']==profile['id']]
 results.append({'id':name,'query':q,'expected_present':expected,'actual_present':bool(hits),'hits':hits,'pass':bool(hits)==expected and (name=='full_exact' or all(not h['hard_eligible'] for h in hits))})
projection_checks=[]
for case,open_dims,expected in [('open_effects',['body_geometry','relationship'],True),('locked_geometry',['relationship'],False),('locked_relationship',['body_geometry'],False),('nothing_open',[],False)]:
 result={'provenance':{'authorial_core':{'intent_lock':{'open_dimensions':open_dims}}}}
 concepts=pg.candidate_pack_visual_concept_candidates({pg.VISUAL_OBLIGATIONS_DATA_KEY:registry},result,{},None,None,{'hits':[{'profile_id':profile['id'],'optional_eligible':True,'hard_eligible':False,'match_basis':'bm25f'}]})
 found=bool(concepts and any(c['id']=='visual-concept:'+profile['id'] for c in concepts['candidates']))
 projection_checks.append({'id':case,'present':found,'pass':found==expected,'scope':open_dims})
 if found: (OUT/'public-candidate-projection.json').write_text(json.dumps(concepts,ensure_ascii=False,indent=2)+'\n')
report={'projection_checks':projection_checks,'source_pin':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'scope':'offline resolver diagnostic only; not a live independent authorial core, not production vector/index qualification and not pixel evidence','provider_calls':0,'image_generations':0,'schema_errors':errors,'compiled_evidence_fields':profile['required_evidence_fields'],'compiled_gate_ids':[g['id'] for g in profile['render_gates']],'queries':results,'scratch_files_only':True}
(OUT/'offline-probe-results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'schema_errors':errors,'projection_checks':projection_checks,'probes':[{'id':r['id'],'present':r['actual_present'],'pass':r['pass'],'hard':[h['hard_eligible'] for h in r['hits']]} for r in results]},ensure_ascii=False,indent=2))
