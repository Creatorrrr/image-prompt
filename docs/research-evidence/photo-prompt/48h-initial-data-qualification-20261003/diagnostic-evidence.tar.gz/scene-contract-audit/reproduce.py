#!/usr/bin/env python3
"""Read-only source/contract audit; writes evidence outside the repository only."""
from __future__ import annotations

import argparse
import copy
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tarfile

sys.dont_write_bytecode = True
parser = argparse.ArgumentParser()
parser.add_argument("--repo", type=Path, default=Path(__file__).resolve().parents[2] / "image-prompt")
parser.add_argument("--out", type=Path, default=Path(__file__).resolve().parent)
args = parser.parse_args()
repo, out = args.repo.resolve(), args.out.resolve()
if out == repo or repo in out.parents:
    raise SystemExit("Evidence output must remain outside the repository")
out.mkdir(parents=True, exist_ok=True)
scripts = repo / "skills/photo-prompt-image-generator/scripts"
assets = scripts.parent / "assets"
sys.path.insert(0, str(scripts))
import prompt_generator as g

def read(path):
    return json.loads(path.read_text())

def write(name, value):
    (out / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def git(*arguments):
    return subprocess.check_output(["git", *arguments], cwd=repo, text=True).strip()

families = ("everyday_scene", "poverty", "realistic_background")
excluded = {
    "rb_exposure_priority", "rb_readable_environment_focus", "rb_local_motion_blur",
    "rb_low_light_noise", "rb_optional_lens_falloff", "rb_optional_chromatic_fringe",
    "rb_restrained_processing", "rb_film_grain_choice",
}
source_paths = ["skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations.json"]
for family in families:
    source_paths += [
        f"skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations_{family}.json",
        f"skills/photo-prompt-image-generator/assets/photo_prompt_{family}_extension.json",
    ]
source_paths += [
    "skills/photo-prompt-image-generator/scripts/prompt_generator.py",
    "skills/photo-prompt-image-generator/scripts/visual_profile_contracts.py",
    "skills/photo-prompt-image-generator/scripts/audit_composed_prompt.py",
    "docs/research-evidence/photo-prompt/everyday-scene-20260923/candidate-bundles.json",
    "docs/research-evidence/photo-prompt/everyday-scene-20260923/report.md",
    "docs/research-evidence/photo-prompt/poverty-visual-semantics-20260907/candidate-data-proposal.json",
    "docs/research-evidence/photo-prompt/poverty-visual-semantics-20260907/report-source.md",
    "docs/research-evidence/photo-prompt/realistic-background-20260912/visual-proposals.json",
    "docs/research-evidence/photo-prompt/renewed-data-closeout-20261003/NEXT_WORK.md",
    "docs/research-evidence/photo-prompt/renewed-keep-defer-audits-20261003/README.md",
    "docs/research-evidence/photo-prompt/renewed-aurora-anchor-alternative-20261003/diagnostic-evidence.tar.gz",
    "skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations_opening_era.json",
    "skills/photo-prompt-image-generator/assets/photo_prompt_opening_era_extension.json",
    "docs/research-evidence/photo-prompt/korean-opening-era-20260907/candidate-data-proposal.json",
]
before = {name: digest(repo / name) for name in source_paths}
head_before, status_before = git("rev-parse", "HEAD"), git("status", "--short")
registry = g.load_visual_obligation_registry(assets / "photo_prompt_visual_obligations.json")
loaded = {p["id"]: p for p in registry["profiles"]}
inventory, component_checks, omissions, projection_checks = [], [], [], []
for family in families:
    name = f"skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations_{family}.json"
    for index, profile in enumerate(read(repo / name)["profiles"]):
        if profile["id"] in excluded:
            continue
        components = profile["authored_components"]["components"]
        pointer = f"/profiles/{index}"
        inventory.append({"profile_id": profile["id"], "family": family,
            "file": name, "pointer": pointer, "component_count": len(components)})
        materialized = g.candidate_pack_visual_profile_obligation(
            profile, registry, activation_source="read_only_source_consistency_audit", source_intent_ids=[])
        bindings = {c["evidence_field"]: c["evidence_terms"][0] for c in components}
        full_match = g.candidate_pack_visual_component_match(loaded[profile["id"]], "; ".join(bindings.values()))
        projection = {
            "profile_id": profile["id"],
            "composition_instruction_exact": materialized["composition_instruction"] == " ".join(c["instruction"] for c in components),
            "render_gates_exact": materialized["render_gates"] == [c["render_gate"] for c in components],
            "required_fields_exact": materialized["prompt_binding"]["required_evidence_fields"] == list(bindings),
            "evidence_requirements_exact": materialized["evidence_requirements"] == {
                c["evidence_field"]: {"min_content_words": c["min_content_words"], "must_mention_any": c["evidence_terms"]}
                for c in components},
            "complete_component_match": full_match,
            "actual_materialized_obligation": materialized,
        }
        projection_checks.append(projection)
        for component_index, component in enumerate(components):
            field, phrase = component["evidence_field"], component["evidence_terms"][0]
            error = None
            try:
                g.validate_visual_intent_binding(obligation_index=0, field=field, phrase=phrase,
                    requirement=materialized["evidence_requirements"][field])
            except ValueError as exc:
                error = str(exc)
            component_checks.append({
                "profile_id": profile["id"], "component_id": component["id"], "file": name,
                "pointer": f"{pointer}/authored_components/components/{component_index}",
                "evidence_field": field, "canonical_phrase": phrase,
                "requirement": materialized["evidence_requirements"][field],
                "accepted": error is None, "error": error,
            })
            remaining = "; ".join(value for key, value in bindings.items() if key != field)
            match = g.candidate_pack_visual_component_match(loaded[profile["id"]], remaining)
            omissions.append({"profile_id": profile["id"], "omitted_component_id": component["id"],
                "omitted_field": field, "remaining_evidence": remaining, "actual_match": match,
                "expected_match": None, "rejected_as_expected": match is None})

rain = loaded["ed_rain_threshold"]
rain_source = next(p for p in read(repo / source_paths[10])["candidate_bundles"] if p["id"] == "ed_rain_threshold")
rain_checks = []
for phrase in [
    "a nearby floor mat or stable surface receives the folded umbrella",
    "a floor mat receives the drips",
    "a nearby stable surface receives the folded umbrella",
    "a dry open umbrella rests indoors",
]:
    error = None
    try:
        g.validate_visual_intent_binding(obligation_index=0, field="component_4_phrase", phrase=phrase,
            requirement=rain["evidence_requirements"]["component_4_phrase"])
    except ValueError as exc:
        error = str(exc)
    rain_checks.append({"phrase": phrase, "accepted": error is None, "error": error})
trial = copy.deepcopy(rain)
removed = trial["semantics"]["paraphrase_examples"].pop(2)
rain_counterfactual = []
for label, phrase in [
    ("original_source_seed", removed),
    ("short_authored_alias", rain["semantics"]["paraphrase_examples"][1]),
    ("complete_exact_request", rain["activation"]["exact_terms"][0]),
    ("unrelated_dry_scene", "An adult stands inside a dry empty room holding a closed dry umbrella."),
]:
    rain_counterfactual.append({"case": label, "text": phrase,
        "before": g.candidate_pack_visual_component_match(rain, phrase),
        "in_memory_example_deletion": g.candidate_pack_visual_component_match(trial, phrase)})
kwargs = {"activation_source": "read_only_audit", "source_intent_ids": []}
rain_results = {"source_record": rain_source, "binding_checks": rain_checks,
    "source_seed_helper_match": g.candidate_pack_visual_component_match(rain, rain_source["prompt_seed_en"]),
    "in_memory_only_counterfactual": rain_counterfactual,
    "materialized_obligation_equal_after_example_deletion":
        g.candidate_pack_visual_profile_obligation(rain, registry, **kwargs)
        == g.candidate_pack_visual_profile_obligation(trial, registry, **kwargs),
    "decision": "DEFER: contradictory source descriptions do not authorize widening; deletion has no established benefit"}

opening_source = read(repo / "docs/research-evidence/photo-prompt/korean-opening-era-20260907/candidate-data-proposal.json")
opening = {
    "runtime_profile": loaded["opening_hotel_coffee_service"],
    "source_profile": next(p for p in opening_source["profiles"] if p["id"] == "hotel_coffee_service"),
    "source_atoms": [p for p in opening_source["candidate_atoms"] if p["id"].startswith("opening_hotel_coffee_service_")],
    "decision": "KEEP pending event-phase clarification: first contact with the handle held is a defensible shared instant; no air gap is required",
    "limits": "Source inspection only, no pixel evaluation or proof of real downward motion from a still image",
}

archive = repo / "docs/research-evidence/photo-prompt/renewed-aurora-anchor-alternative-20261003/diagnostic-evidence.tar.gz"
member = "built-environment-alternative-audit/REPORT.md"
with tarfile.open(archive) as handle:
    prior_report = handle.extractfile(member).read()
(out / "prior-built-environment-audit.md").write_bytes(prior_report)

after = {name: digest(repo / name) for name in source_paths}
summary = {
    "head": head_before, "head_unchanged": head_before == git("rev-parse", "HEAD"),
    "profile_count": len(inventory), "family_counts": {family: sum(p["family"] == family for p in inventory) for family in families},
    "canonical_component_checks": len(component_checks),
    "canonical_binding_failures": sum(not x["accepted"] for x in component_checks),
    "single_component_omission_checks": len(omissions),
    "unexpected_omission_acceptances": sum(not x["rejected_as_expected"] for x in omissions),
    "all_materialized_projections_exact": all(all(p[k] for k in (
        "composition_instruction_exact", "render_gates_exact", "required_fields_exact", "evidence_requirements_exact")) for p in projection_checks),
    "all_complete_component_matches": all(p["complete_component_match"] for p in projection_checks),
    "excluded_capture_optics_profiles": sorted(excluded), "source_hashes_unchanged": before == after,
    "worktree_status_before": status_before, "worktree_status_after": git("status", "--short"),
    "provider_calls": 0, "public_cli_runs": 0, "images": 0,
    "limits": [
        "Production functions were called directly; no complete public candidate-pack CLI workflow was executed.",
        "Canonical checks cover the first evidence anchor for every component, not every authored alternative or free paraphrase.",
        "Component omission rejection is helper evidence, not a normalize_visual_intent completeness guarantee.",
        "An example helper match does not establish hard activation, eligible exposure, optional adoption or final audit success.",
        "No image quality, physical correctness, historical authenticity, broad retrieval gain or user evaluation is claimed.",
        "Opening-era cross-check is additional source-only review and excluded from the 40-profile and 145-check counts.",
    ],
}
manifest = {"generated_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "repository": str(repo), "head": head_before, "source_sha256": before,
    "source_hashes_unchanged": before == after,
    "prior_report_archive_member": member,
    "prior_report_sha256": hashlib.sha256(prior_report).hexdigest(),
    "reproduction_command": f"PYTHONDONTWRITEBYTECODE=1 python {Path(__file__).resolve()} --repo {repo} --out {out}"}
write("profile-inventory.json", inventory)
write("component-binding-checks.json", component_checks)
write("component-omission-checks.json", omissions)
write("materialization-checks.json", projection_checks)
write("rain-threshold-checks.json", rain_results)
write("opening-coffee-source-check.json", opening)
write("source-manifest.json", manifest)
write("summary.json", summary)
assert len(inventory) == 40 and len(component_checks) == len(omissions) == 145
assert not summary["canonical_binding_failures"] and not summary["unexpected_omission_acceptances"]
assert summary["all_materialized_projections_exact"] and summary["all_complete_component_matches"]
assert summary["source_hashes_unchanged"] and summary["head_unchanged"]
print(json.dumps(summary, ensure_ascii=False, indent=2))
