# Scene source/contract audit

## Decision

**KEEP / DEFER. No new source-supported DATA edit qualifies.** Audit pinned to repository commit `8a0fb5b8dd30d70bc9dbae7f63fbce38daa3bbfc`. Repository files were not edited and there were no provider calls. This directory preserves the completed read-only audit; it does not represent a new DATA cycle.

## Bounded scope and results

- 40 profiles: 7 everyday-scene, 9 poverty, 24 realistic-background
- 145 canonical component evidence checks: all accepted
- 145 single-component omission checks: all rejected by the component matcher
- All 40 authored instruction, required-field, evidence-anchor and render-gate projections agree with the actual production materializer
- 8 realistic-background capture/optics profiles excluded to honor the no-camera scope: `rb_exposure_priority`, `rb_readable_environment_focus`, `rb_local_motion_blur`, `rb_low_light_noise`, `rb_optional_lens_falloff`, `rb_optional_chromatic_fringe`, `rb_restrained_processing`, `rb_film_grain_choice`
- The supplemental opening-era coffee review is source-only and outside these counts

`profile-inventory.json` lists every audited ID, source file, JSON pointer and component count. `component-binding-checks.json` contains all 145 inputs and outcomes. `component-omission-checks.json` preserves all 145 omitted fields, remaining evidence and actual matcher outcomes. `materialization-checks.json` preserves complete materialized obligations and per-surface equality checks. `source-manifest.json` records SHA-256 values for source, runtime and prior-evidence inputs and the exact reproduction command.

## Ranked findings

### 1. Rain threshold: source-state tension, no authorized widening

Runtime source: `skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations_everyday_scene.json`, `/profiles/4` (`ed_rain_threshold`).

The profile's `semantics.paraphrase_examples[2]` describes a floor mat receiving drips. In contrast, `authored_components.components[id=component_4]` requires a nearby floor mat or stable surface receiving the folded umbrella itself. That narrower relation is consistent across `match_terms`, `evidence_terms`, `instruction`, `render_gate.description`, the definition and the complete exact activation phrase.

Original research: `docs/research-evidence/photo-prompt/everyday-scene-20260923/candidate-bundles.json`, `candidate_bundles[id=ed_rain_threshold]`. Its `prompt_seed_en` contains the same drip-receiving scene, while `role_graph` and `visible_requirements` localize wetness to the umbrella and weather-exposed area. `optional_context` includes small drops and a floor mat. The corresponding runtime extension retains that localization. This is mixed original-source scope, not an isolated dropped alternative in a gate.

The prior bounded audit is preserved in `prior-built-environment-audit.md`; its verified archive/member and hashes are in the manifest. It already kept the profile's mat-or-stable-surface choice. It did not establish that the alternate object being received should be widened from umbrella to drips.

Actual direct-consumer results (`rain-threshold-checks.json`):

1. Canonical component_4 anchor is accepted as evidence
2. “a floor mat receives the drips” is rejected as component_4 evidence
3. “a nearby stable surface receives the folded umbrella” is also rejected without the full literal authored anchor. This demonstrates the exact-anchor contract, not proof that the stable-surface alternative is semantically forbidden
4. An unrelated dry-open-umbrella phrase is rejected
5. The original source seed receives `semantic_paraphrase_example` from `candidate_pack_visual_component_match`
6. An in-memory-only deletion of the third paraphrase removes that source seed's helper match, while preserving the existing short alias, complete exact request and dry-scene negative
7. Materialized obligations are identical before/after that in-memory example deletion

**Decision:** defer widening and deletion. A source example does not override the majority of the authored narrow contract. Deletion removes source-authored advisory wording without demonstrating an improvement in retrieval, admission or final composition.

**Falsifiable next test:** freeze drip-receiving, umbrella-supporting, unrelated-wet-floor and dry-umbrella requests before choosing a correction. Resolve the intended event phase and receiver relation from source intent first. Then require discovery and evidence binding to agree, retain all other scene duties, preserve explicit umbrella-support requests, and keep negative cases rejected. A broader anchor alone would not meet these requirements.

### 2. Poverty energy and housing: existing scope deferrals remain

File: `skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations_poverty.json`.

- `profiles[id=household_energy_affordability_coping_relation]`: `semantics.definition` allows consolidating activity OR sealing heat transfer. `authored_components.components[id=practical_same_household_coping_action]` requires consolidation AND practical thermal control. Original proposal meaning and exact/detailed scenarios already carry this tension
- `profiles[id=occupied_housing_habitability_mitigation_relation]`: `semantics.definition` includes cold, damp, leak, ventilation and sanitation. `authored_components.components[id=traceable_defect_source]` consistently names leak, dampness or draft. Some source candidate action/prop descriptions permit ventilation, while sanitation lacks a separately specified full observable branch

Relevant source: `docs/research-evidence/photo-prompt/poverty-visual-semantics-20260907/candidate-data-proposal.json` and `report-source.md`. Prior disposition: `prior-built-environment-audit.md` and `docs/research-evidence/photo-prompt/renewed-data-closeout-20261003/NEXT_WORK.md`.

**Decision:** retain existing deferrals, do not count as fresh discoveries or edit isolated anchors/gates. Such edits would leave other authored surfaces contradictory.

**Falsifiable next test:** specify complete, independently reviewed alternative event contracts before comparing before/after materialization: service constraint, same household action and thermal result for energy; traceable physical cause/path, living-zone consequence, provisional mitigation and unresolved defect for housing. Preserve all unaffected duties and no-class/health/housing-status inference limits. Run every single-duty omission control.

### 3. Remaining bounded scene profiles: KEEP

The directly inspected authored choices and existing alternatives survive compilation and materialization. No fresh clear internal contradiction justified replacing narrow manifestations, weakening ownership duties or changing explicit requests. In particular, broad profile labels are not sufficient reason to enlarge selected glass, support, wind, wear, architecture or everyday-event manifestations.

This is a bounded maintained-source consistency conclusion, not a certification that every plausible natural-language paraphrase or image is correct.

## Supplemental independent review: opening-era coffee service

Runtime file: `skills/photo-prompt-image-generator/assets/photo_prompt_visual_obligations_opening_era.json`, `profiles[id=opening_hotel_coffee_service]`.

Original source: `docs/research-evidence/photo-prompt/korean-opening-era-20260907/candidate-data-proposal.json`, `/profiles/9` (`hotel_coffee_service`), `/candidate_atoms/36` and `/candidate_atoms/37`. The original atoms already say that a small handled cup rests on its matching saucer and that the subject lowers it toward that saucer. The native source gate asks for agreement among cup, saucer, table and hand action. The runtime extension and hard profile faithfully repeat these authored atoms.

**Conservative conclusion: KEEP pending event-phase clarification.** The first-contact instant of setting down a cup while retaining the handle is a defensible shared moment. Neither clause requires an air gap, ongoing velocity or a released handle, and Korean `잔 내려놓기` can encompass the endpoint. The still-image source does not prove a contradiction. Changing to a hovering cup or removing the resting state would alter an authored choice.

**Falsifiable next test:** freeze pre-contact-with-gap, first-contact-handle-held and completed-release cases, then obtain an event-phase/source-intent decision. Lexical acceptance cannot establish the intended physical phase. Full source records are in `opening-coffee-source-check.json`.

## Consumer reachability and limits

The audit calls existing production functions directly: `load_visual_obligation_registry`, `candidate_pack_visual_profile_obligation`, `validate_visual_intent_binding`, and `candidate_pack_visual_component_match`. There are **zero public CLI runs** and zero complete V6 candidate-pack workflows in this evidence.

- Canonical binding checks use the first authored evidence anchor per component; they are not exhaustive alternative/paraphrase tests
- Omission checks test the component matcher, not a guarantee that every partial `normalize_visual_intent` input is rejected
- A `semantic_paraphrase_example` result does not demonstrate hard activation, eligible candidate exposure, optional adoption, requester-lock preservation or final audit success
- No composed image, historical authenticity, physical correctness, general retrieval gain, visual improvement or requesting-user evaluation is claimed
- Source SHA values are maintained repository inputs, not independent empirical validation of the original public research claims
- The source and HEAD stability checks assert that the evidence rerun did not race changes in its inspected inputs

## Reproduction

Run the exact command in `source-manifest.json`, or:

```sh
PYTHONDONTWRITEBYTECODE=1 python EVIDENCE_ROOT/scene-contract-audit/reproduce.py --repo REPOSITORY_ROOT --out EVIDENCE_ROOT/scene-contract-audit
```

The script refuses an output path inside the repository, disables bytecode writes, performs no network/provider operations, and writes only its evidence output. `reproduction.stdout.log` captures the completed preservation rerun. Current results are in `summary.json`.
