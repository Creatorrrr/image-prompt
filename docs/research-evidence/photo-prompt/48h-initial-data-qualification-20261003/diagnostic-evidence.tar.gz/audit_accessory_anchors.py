"""Read-only literal authored-evidence consistency, not semantic/pixel proof."""
import json, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1] / 'image-prompt'
sys.path.insert(0,str(ROOT/'skills/photo-prompt-image-generator/scripts'))
import prompt_generator as pg
ASSETS=ROOT/'skills/photo-prompt-image-generator/assets'
registry=pg.load_visual_obligation_registry(ASSETS/'photo_prompt_visual_obligations.json')
raw=json.loads((ASSETS/'photo_prompt_visual_obligations_accessory_structure.json').read_text())
ids={p['id'] for p in raw['profiles']}
results=[]
for profile in registry['profiles']:
    if profile['id'] not in ids: continue
    for field, requirement in profile.get('evidence_requirements',{}).items():
        for term in requirement.get('must_mention_any',[]):
            for kind, text in [('anchor',term),('unrelated','A quiet scene contains a plain ceramic bowl on a table')]:
                try:
                    pg.validate_visual_intent_binding(obligation_index=0,field=field,phrase=text,requirement=requirement)
                    accepted,error=True,None
                except ValueError as exc:
                    accepted,error=False,str(exc)
                results.append(dict(id=profile['id'],field=field,text=text,kind=kind,accepted=accepted,error=error))
report={'profiles':len(ids),'checks':len(results),'unexpected':[r for r in results if r['accepted'] != (r['kind']=='anchor')],'results':results}
Path(__file__).with_name('accessory-anchor-report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='results'}))
