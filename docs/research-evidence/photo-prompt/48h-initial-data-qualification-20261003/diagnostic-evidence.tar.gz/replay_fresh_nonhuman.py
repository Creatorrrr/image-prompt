from pathlib import Path
import json,hashlib,subprocess,os,time
P=Path(__file__).resolve().parent; R=P.parent/'image-prompt'; C=P/'fresh-nonhuman-cores'; O=P/'fresh-nonhuman-replay';O.mkdir(exist_ok=True)
mp=C/'manifest.json';assert hashlib.sha256(mp.read_bytes()).hexdigest()=='1ff45a8844b9e1266e20323817cdac1bbe71004b459d032a33dde9b4aa7e57f1'
m=json.loads(mp.read_text());env={k:v for k,v in os.environ.items() if not any(t in k.upper() for t in ['TOKEN','API_KEY','CREDENTIAL'])};out=[]
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head=='8a0fb5b8dd30d70bc9dbae7f63fbce38daa3bbfc'
for a in m['arms']:
 d=C/a['arm']
 for n,h in a['files_sha256'].items():assert hashlib.sha256((d/n).read_bytes()).hexdigest()==h
 e=Path(a['request_envelope_path']);assert hashlib.sha256(e.read_bytes()).hexdigest()==a['request_envelope_file_sha256']
 cmd=['python',str(R/'skills/photo-prompt-image-generator/scripts/generate_photo_prompt.py'),'--request-envelope-json',str(e),'--authorial-core-json',str(d/'authorial_core.json'),'--creative-controls-json',str(d/'creative_controls.json'),'--embodiment-review-json',str(d/'embodiment_review.json'),'--seed','1003','--output-file',str(O/(a['arm']+'.pack.json'))]
 t=time.monotonic();p=subprocess.run(cmd,cwd=R,env=env,capture_output=True,text=True,timeout=180);(O/(a['arm']+'.stdout.txt')).write_text(p.stdout);(O/(a['arm']+'.stderr.txt')).write_text(p.stderr)
 out.append({'arm':a['arm'],'returncode':p.returncode,'seconds':round(time.monotonic()-t,3),'stderr':p.stderr[-3000:]});print(a['arm'],p.returncode,flush=True)
 for n,h in a['files_sha256'].items():assert hashlib.sha256((d/n).read_bytes()).hexdigest()==h
 (O/'results.json').write_text(json.dumps({'head':head,'conceptual_scenes':8,'translation_inputs':16,'provider_calls':0,'results':out},indent=2)+'\n')
