#!/usr/bin/env python3
"""Bounded source-coverage check; no invented candidate expectations or inputs."""
import hashlib
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent
REPO = OUT.parent.parent / "image-prompt"
S = REPO / "skills/photo-prompt-image-generator/scripts"
sys.path.insert(0, str(S))
import prompt_generator as g

raw = json.loads((S.parent / "assets/photo_prompt_tags.json").read_text())
inventory = [e for e in raw["slots"]["action"] if "animal" in set(e.get("tags", []) + e.get("for_any", []))]
data = g.load_runtime_data()
checks = []
for name, target in [("scene_05-en", "pollinating"), ("scene_04-en", "grazing"), ("scene_03-en", "probing_tidepool")]:
    pack_path = OUT.parent / "fresh-nonhuman-replay" / f"{name}.pack.json"
    pack = json.loads(pack_path.read_text())[0]
    core = pack["authorial_core"]
    contract, picked = g.frozen_core_context(data, core, pack["creative_controls"])
    entry = g.candidate_pack_slot_entry_by_id(data, "action", target)
    tokens = g.entry_tags(picked["subject"]) | g.entry_kinds(picked["subject"])
    checks.append({"case": name, "pack_sha256": hashlib.sha256(pack_path.read_bytes()).hexdigest(),
        "entry": entry, "primary_subject_tokens": sorted(tokens), "for_any_intersection": sorted(set(entry.get("for_any", [])) & tokens),
        "recomputed_eligible": g.core_slot_entry_eligible(data, core, contract, picked, "action", entry),
        "exposed": any(e["entry_id"] == target for e in pack.get("slots", {}).get("action", {}).get("candidates", [])),
        "action_open": "action" in core["intent_lock"]["open_dimensions"]})
result = {"base_tags_json_animal_labelled_action_rows": len(inventory), "inventory": inventory, "checks": checks,
    "limits": ["Inventory is limited to the base tags file, not a global extension count.",
        "Butterfly feeding does not establish pollen transfer; pollinating is not a predeclared expected candidate.",
        "Grazing and tidepool probing are narrower source manifestations, not automatic replacements for biting an attached leaf or entering a pot.",
        "Ineligible vocabulary does not establish a DATA defect or permission to open action in these inputs."]}
(OUT / "bounded-source-coverage.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({"inventory_count": len(inventory), "checks": [{k: v for k, v in x.items() if k not in {"entry", "primary_subject_tokens"}} for x in checks]}, indent=2))
