#!/usr/bin/env python3
"""Read frozen nonhuman replay; direct diagnostic probes only, no provider calls."""
import copy
import hashlib
import json
from pathlib import Path
import subprocess
import sys

sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent
BASE = OUT.parent
REPO = BASE.parent / "image-prompt"
SCRIPTS = REPO / "skills/photo-prompt-image-generator/scripts"
ASSETS = SCRIPTS.parent / "assets"
CORES = BASE / "fresh-nonhuman-cores"
REPLAY = BASE / "fresh-nonhuman-replay"
sys.path.insert(0, str(SCRIPTS))
import prompt_generator as g
import audit_composed_prompt as a
from photo_contracts import property_effects_allowed, INTENT_LOCK_DIMENSIONS

def read(p):
    return json.loads(p.read_text())

def write(name, data):
    (OUT / name).write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n")

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def git(*args):
    return subprocess.check_output(["git", *args], cwd=REPO, text=True).strip()

source_files = [
    ASSETS / "photo_prompt_tags.json",
    ASSETS / "photo_prompt_everyday_scene_extension.json",
    ASSETS / "photo_prompt_quality_layers.json",
    SCRIPTS / "prompt_generator.py", SCRIPTS / "audit_composed_prompt.py",
    SCRIPTS / "photo_contracts.py", SCRIPTS / "photo_candidate_semantics.py",
    SCRIPTS / "photo_embodiment.py",
    REPO / "docs/research-evidence/photo-prompt/everyday-scene-20260923/candidate-bundles.json",
]
frozen_files = sorted(p for parent in (CORES, REPLAY) for p in parent.rglob("*") if p.is_file())
before = {str(p): sha(p) for p in source_files + frozen_files}
head_before, status_before = git("rev-parse", "HEAD"), git("status", "--short")
original = read(REPLAY / "results.json")
data = g.load_runtime_data()
provenance = {}
for path in [ASSETS / "photo_prompt_tags.json", ASSETS / "photo_prompt_everyday_scene_extension.json"]:
    payload = read(path)
    for i, entry in enumerate(payload.get("slots", {}).get("action", [])):
        provenance[entry["id"]] = {"file": str(path.relative_to(REPO)), "pointer": f"/slots/action/{i}", "raw_entry": entry}

exposures, checks, abstentions, guards = [], [], [], []
packs = {}
for result in original["results"]:
    case = result["arm"]
    raw_core = read(CORES / case / "authorial_core.json")
    record = {"case": case, "conceptual_scene": case.rsplit("-", 1)[0], "language": case.rsplit("-", 1)[1],
        "original_returncode": result["returncode"], "original_stderr": result["stderr"],
        "subject": raw_core["subject"], "event": raw_core["event"],
        "source_request": raw_core["source_request"], "action_candidates": []}
    if result["returncode"]:
        exposures.append(record)
        continue
    payload = read(REPLAY / f"{case}.pack.json")
    assert isinstance(payload, list) and len(payload) == 1
    pack = payload[0]
    packs[case] = pack
    core = pack["authorial_core"]
    lock = core["intent_lock"]
    contract, picked = g.frozen_core_context(data, core, pack["creative_controls"])
    record.update(subject_category=contract["subject_category"], no_people=contract["no_people"],
        locked_dimensions=lock["locked_dimensions"], open_dimensions=lock["open_dimensions"],
        action_candidates=pack.get("slots", {}).get("action", {}).get("candidates", []))
    exposures.append(record)
    if int(case[6:8]) > 6:
        continue
    candidates = a.candidate_objects_from_pack(pack)
    abstentions.append({"case": case, "chosen_ids": [], "failures": a.audit_candidate_interpretations(
        pack, {}, core["baseline_prompt_en"], set(), candidates), "scope": "candidate-interpretation helper only"})
    for candidate in record["action_candidates"]:
        entry = g.candidate_pack_slot_entry_by_id(data, "action", candidate["entry_id"])
        effects = candidate["affected_dimensions"]
        original_eligible = g.core_slot_entry_eligible(data, core, contract, picked, "action", entry)
        introduced = entry["en"].rstrip(".") + ". This diagnostic addition is framed beside a cobalt marker and a serrated border."
        interpretation = {
            "candidate_id": candidate["id"],
            "artistic_interpretation": "Introduce the selected source relation as a separate scene action",
            "transformation": "Add the source event beside explicit diagnostic visual markers",
            "prompt_evidence": introduced,
            "relation_evidence": {r["id"]: introduced for r in candidate.get("relations", [])},
        }
        failures = a.audit_candidate_interpretations(pack, {"candidate_interpretations": [interpretation]},
            core["baseline_prompt_en"] + " " + introduced, {candidate["id"]}, candidates)
        checks.append({"case": case, "candidate_id": candidate["id"], "source": provenance.get(entry["id"]),
            "runtime_loaded_entry": entry, "published_applicability": candidate["applicability"],
            "recomputed_entry_eligible": original_eligible, "affected_dimensions": effects,
            "effects_subset_of_open_dimensions": set(effects) <= set(lock["open_dimensions"]),
            "property_effects_allowed": property_effects_allowed(lock, effects, candidate.get("affected_properties", [])),
            "introduced_phrase": introduced, "interpretation": interpretation, "helper_failures": failures,
            "scope": "Direct ordinary candidate-interpretation helper; no physical review or full-composition approval"})
        if "human" in entry.get("tags", []):
            trial = copy.deepcopy(entry)
            trial["for_any"] = ["human"]
            guards.append({"case": case, "candidate_id": candidate["id"], "existing_tags": entry["tags"],
                "original_for_any": entry.get("for_any"), "original_eligible": original_eligible,
                "in_memory_for_any_human_eligible": g.core_slot_entry_eligible(data, core, contract, picked, "action", trial),
                "qualification": "Diagnostic only; no reranking, no admitted human/mixed-owner positive, no source or index edit"})

def baseline_composition(pack):
    core, lock = pack["authorial_core"], pack["authorial_core"]["intent_lock"]
    review = copy.deepcopy(pack["embodiment_preflight"]["baseline_review"])
    review["provenance"] = "agent_postcomposition"
    composed = {
        "core_retrieval_sha256": pack["core_retrieval"]["canonical_sha256"], "pack_id": pack["pack_id"],
        "prompt_en": core["baseline_prompt_en"], "negative_en": pack["negative_en"],
        "chosen_candidate_ids": [], "chosen_visual_concept_ids": [], "composer": "agent",
        "embodiment_review": {"source_contract_sha256": pack["embodiment_preflight"]["canonical_sha256"], "review": review},
        "candidate_interpretations": [],
        "authorial_core_binding": {"source_authorial_core_sha256": core["canonical_sha256"],
            "source_intent_lock_sha256": lock["canonical_sha256"],
            "preserved_anchor_ids": [x["anchor_id"] for x in lock["semantic_anchors"]],
            "preserved_evidence": [], "authorial_decisions": []},
        "semantic_clarification_decisions": [{"clarification_id": x["id"],
            "decision": "applied" if x.get("required_in_final_prompt") else "rejected",
            "rationale": "Retain the exact frozen requester-owned scene and reject unrelated optional reinterpretations",
            "prompt_evidence": lock["semantic_anchors"][0]["prompt_evidence"]}
            for x in pack["semantic_clarification"]["candidates"]],
        "creative_augmentation_brief": {"decisions": [{"candidate_id": x["id"], "decision": "rejected",
            "rationale": "Retain the exact frozen requester-owned physical event"}
            for x in pack["creative_augmentation"]["candidates"]]},
    }
    contract = pack["semantic_assertion_obligations"]
    composed["semantic_assertion_evidence"] = {"source_contract_sha256": contract["canonical_sha256"],
        "evidence": {x["assertion_id"]: x["frozen_evidence"] for x in contract["obligations"]}}
    return composed

pack = packs["scene_01-en"]
baseline = baseline_composition(pack)
target = next(x for x in pack["slots"]["action"]["candidates"] if x["entry_id"] == "ed_subway_exit_candidate")
metadata_only = copy.deepcopy(baseline)
metadata_only["chosen_candidate_ids"] = [target["id"]]
evidence = pack["authorial_core"]["intent_lock"]["semantic_anchors"][2]["prompt_evidence"]
metadata_only["candidate_interpretations"] = [{"candidate_id": target["id"],
    "artistic_interpretation": "Use the leaves as the immediate boundary for the animal",
    "transformation": "Retain the original nose contact without adding railway architecture",
    "prompt_evidence": evidence, "realization": "baseline",
    "relation_evidence": {r["id"]: evidence for r in target.get("relations", [])}}]
disclosed = copy.deepcopy(metadata_only)
disclosed["authorial_core_binding"]["authorial_decisions"] = [{"dimension": "action",
    "decision": "adopt a railway crossing action", "rationale": "explicitly disclose the action dimension in this diagnostic"}]
introduced_phrase = "The hedgehog steps out through an open train door onto an elevated railway platform far away from the garden fence."
introduced = copy.deepcopy(baseline)
introduced["prompt_en"] += " " + introduced_phrase
introduced["chosen_candidate_ids"] = [target["id"]]
introduced["candidate_interpretations"] = [{"candidate_id": target["id"],
    "artistic_interpretation": "Place the animal in a secondary threshold event",
    "transformation": "Add railway architecture and a separate crossing gesture",
    "prompt_evidence": introduced_phrase,
    "relation_evidence": {r["id"]: introduced_phrase for r in target.get("relations", [])}}]
review = introduced["embodiment_review"]["review"]
review["prompt_sha256"] = hashlib.sha256(introduced["prompt_en"].encode()).hexdigest()
review["summary"] = "Diagnostic scene contains conflicting garden contact and a distant railway-crossing event; physical approval is withheld."
review["checks"]["contact_and_space"].update(status="unresolved",
    reason="The additional distant railway crossing is not reconciled with the unchanged garden contact in one coherent frame.")
full_audits = []
for label, composed in [("reject_all_unchanged_baseline", baseline),
    ("mismatched_candidate_metadata_unchanged_baseline", metadata_only),
    ("same_metadata_plus_explicit_action_decision", disclosed),
    ("introduced_railway_phrase_with_honest_unresolved_physical_review", introduced)]:
    result = a.audit_composed_prompt(pack, composed)
    full_audits.append({"case": "scene_01-en", "probe": label, "composed": composed, "audit": result,
        "prompt_equals_frozen_baseline": composed["prompt_en"] == baseline["prompt_en"],
        "introduced_candidate_phrase": introduced_phrase if label.startswith("introduced_") else None,
        "core_and_pack_modified": False})
    print(label, result["status"], [x["check"] for x in result["failures"]], flush=True)

augmentation_target = next(x for x in pack["creative_augmentation"]["candidates"] if x["slot"] == "action")
augmentation_probe = copy.deepcopy(baseline)
aug_evidence = "The hedgehog spreads two broad wings above a cobalt marker beside the garden leaves."
augmentation_probe["prompt_en"] += " " + aug_evidence
for decision in augmentation_probe["creative_augmentation_brief"]["decisions"]:
    if decision["candidate_id"] == augmentation_target["id"]:
        decision.update(decision="transformed", artistic_interpretation="Introduce wing extension into the animal event",
            transformation="Add a distinct source-inspired wing movement", prompt_evidence=aug_evidence,
            affected_dimensions=["action"])
augmentation_probe["chosen_candidate_ids"] = [augmentation_target["id"]]
augmentation_check = {"case": "scene_01-en", "candidate_id": augmentation_target["id"],
    "composed_probe": augmentation_probe,
    "failures": a.audit_creative_augmentation(pack, augmentation_probe, augmentation_probe["prompt_en"], {augmentation_target["id"]}),
    "scope": "augmentation helper only; synthetic wing addition is not physically approved"}

summary = {
    "head": head_before, "head_unchanged": head_before == git("rev-parse", "HEAD"),
    "conceptual_scenes": 8, "translated_inputs": len(original["results"]),
    "admitted_original_inputs": sum(x["returncode"] == 0 for x in original["results"]),
    "failed_original_inputs": [x for x in original["results"] if x["returncode"]],
    "living_nonhuman_conceptual_scenes": 6, "living_nonhuman_translated_inputs": 12,
    "living_nonhuman_action_exposures": len(checks),
    "living_nonhuman_human_tagged_action_exposures": len(guards),
    "unique_exposed_action_ids": sorted({x["candidate_id"] for x in checks}),
    "effects_within_open_dimensions": sum(x["effects_subset_of_open_dimensions"] for x in checks),
    "recomputed_eligible_exposures": sum(x["recomputed_entry_eligible"] for x in checks),
    "ordinary_interpretation_helper_passes": sum(not x["helper_failures"] for x in checks),
    "reject_all_helper_passes": sum(not x["failures"] for x in abstentions),
    "hypothetical_human_guard_remaining_eligible": sum(x["in_memory_for_any_human_eligible"] for x in guards),
    "full_audit_results": [{"probe": x["probe"], "status": x["audit"]["status"],
        "failure_checks": [f["check"] for f in x["audit"]["failures"]]} for x in full_audits],
    "augmentation_failure_checks": [x["check"] for x in augmentation_check["failures"]],
    "dimension_findings": {"action_and_event_are_distinct_allowed_names": {"action", "event"} <= INTENT_LOCK_DIMENSIONS,
        "action_focus_fields": g.DIMENSION_FIELDS["action"], "event_focus_fields": g.DIMENSION_FIELDS["event"],
        "interpretation": "Same retrieval field projection does not alias literal dimension names in openness/property checks"},
    "source_and_frozen_file_hashes_unchanged": before == {str(p): sha(p) for p in source_files + frozen_files},
    "worktree_status_before": status_before, "worktree_status_after": git("status", "--short"),
    "provider_calls": 0, "new_public_cli_runs": 0, "images": 0,
    "limits": ["EN/KO pairs are translations, not independent conceptual scenes.",
        "Exposure marked eligible is not validated actor-specific applicability or completed adoption.",
        "Ordinary helper probes are not full composition acceptance or physical review.",
        "Full audit accepts only unchanged baseline variants in this review; introduced conflicting scene is honestly blocked by unresolved embodiment review.",
        "Hypothetical for_any guard was changed only on detached in-memory entries; no retrieval rerun or human/mixed-owner qualification was done.",
        "No global prohibition on background humans is inferred from the raw animal/plant requests."]}
write("original-replay-denominators.json", original)
write("exposure-inventory.json", exposures)
write("ordinary-action-helper-checks.json", checks)
write("reject-all-helper-checks.json", abstentions)
write("hypothetical-human-guard-checks.json", guards)
write("full-composition-audit-checks.json", full_audits)
write("augmentation-openness-control.json", augmentation_check)
write("source-and-input-manifest.json", {"head": head_before, "sha256": before,
    "reproduction_command": f"PYTHONDONTWRITEBYTECODE=1 python {Path(__file__).resolve()}"})
write("summary.json", summary)
assert summary["source_and_frozen_file_hashes_unchanged"] and summary["head_unchanged"]
print(json.dumps(summary, indent=2))
