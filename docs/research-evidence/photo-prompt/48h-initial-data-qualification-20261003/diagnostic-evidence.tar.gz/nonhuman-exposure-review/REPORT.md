# Frozen nonhuman action exposure and adoption review

## Decision

**KEEP DATA; defer correction to owner-aware applicability, openness/selection semantics and evaluation coverage.** No new action row or metadata edit is qualified by this cohort. Existing human tags are not absent. A narrow detached-entry `for_any=["human"]` trial suppresses the observed human-action exposures, but it has not been qualified against legitimate human or mixed-owner scenes, and is stronger than a source requirement that some actor is human.

There is a real distinction between an exposed candidate's `eligible` label and verified applicability or adoption. It would also be incorrect to claim that all exposed actions are automatically rejected because action is unopened: the ordinary interpretation helper accepts these diagnostic selections. Bundle/augmentation and explicit authorial-decision paths apply different openness checks. The complete auditor blocks the deliberately inconsistent added scene when the physical reviewer honestly reports it unresolved.

Repository pin: `8a0fb5b8dd30d70bc9dbae7f63fbce38daa3bbfc`. Original inputs, packs, runtime and source DATA were not edited. Zero new public CLI runs, zero provider calls and zero images.

## Frozen denominator and provenance

Original replay: **8 conceptual scenes, 16 translated inputs, 14 admitted and 2 rejected**. English/Korean pairs are translations, not independent scenes. The six living-nonhuman scenes are five animals and one plant; they contribute 12 admitted translated inputs. Scene07 is a ceramic ornament control. Scene08 is an adult with a secondary dog and is not a living-nonhuman-primary case.

Both scene08 runs remain in the denominator, rejected with `Error: authorial core setting needs at least 3 concrete content words`. They were not repaired or retried. Thus the intended admitted mixed-owner control is unavailable.

The supplied core provenance records independent candidate-unexposed authoring before retrieval. This review was deliberately source- and candidate-exposed and is a diagnostic investigation, not another blind cohort. `original-replay-denominators.json` preserves the original result object. `source-and-input-manifest.json` hashes every original core/replay file and the reviewed implementation sources.

## Observed action exposure

The counts below are per language; each EN/KO pair has the same listed action IDs.

| Scene | Subject / requested event | Action rows per input | Human-tagged rows per input |
|---|---|---:|---:|
| 01 | Hedgehog nose touching fallen leaves | 3 | 2 |
| 02 | Frog toes gripping a reed | 2 | 1 |
| 03 | Octopus arm entering a pot | 2 | 1 |
| 04 | Tortoise biting an attached leaf | 2 | 2 |
| 05 | Butterfly feeding through its proboscis | 0 | 0 |
| 06 | Living vine tendril around wire | 4 | 4 |
| 07, control | Ceramic owl ornament on a sill | 2 | 0 |
| 08, rejected control | Adult with umbrella beside dog holding rope | No pack | No pack |

Across the living-nonhuman inputs there are **26 action exposures**, of which **20 are already human-tagged**. These are nine unique action IDs:

- `ed_cafe_pickup_wait_candidate`
- `ed_kitchen_prep_candidate`
- `ed_library_page_turn_candidate`
- `ed_office_return_candidate`
- `ed_parcel_open_candidate`
- `ed_park_rest_candidate`
- `ed_subway_exit_candidate`
- `opening_two_world_threshold_crossing`
- `wyvern_spreading_wings_two_leg_profile`

All 26 are independently recomputed as eligible by `core_slot_entry_eligible` with the complete `load_runtime_data()` result and each frozen core/control snapshot. All have source `affected_dimensions=["action"]`; **0/26 are within the frozen open dimensions**. Their published `applicability.source` is `frozen_core_slot_contract`.

All six cores lock `event`, and none opens `action`. `action` and `event` are distinct allowed names in `photo_contracts.INTENT_LOCK_DIMENSIONS`. Both project to `core.event` in `prompt_generator.DIMENSION_FIELDS`, but this retrieval projection is not an alias-normalization rule for the literal dimension checks. No dimension alias conversion was found in the reviewed normalization/selection paths. “Event locked” and “action unopened” are therefore reported separately.

Exact candidate records, source JSON pointers and runtime-loaded entries are saved in `exposure-inventory.json` and `ordinary-action-helper-checks.json`.

## Source-to-consumer trace

### DATA already declares human meaning

The seven everyday rows live in `skills/photo-prompt-image-generator/assets/photo_prompt_everyday_scene_extension.json`, under `slots.action`. They already carry `human` tags and ordinary person/customer/passenger action meanings. Original research records are in `docs/research-evidence/photo-prompt/everyday-scene-20260923/candidate-bundles.json`. The chosen concepts are explicitly authored human events, not generic animal motions with missing nouns.

The wyvern and two-world-threshold rows live in `skills/photo-prompt-image-generator/assets/photo_prompt_tags.json`, under `slots.action`. Their authored meanings are narrower than ordinary wildlife motion. The former already restricts `for_any` to animal; that broad category does not distinguish a wyvern from a hedgehog or frog. The latter allows human, animal and object subjects but describes an explicit two-world threshold rather than an ordinary pot opening.

### Why exposure is not owner proof

`prompt_generator.entry_block_reason` blocks human-tagged rows under explicit `no_people`. Its typed-nonhuman person-slot set contains appearance/pose/garment slots, but not `action`. `core_slot_entry_eligible` respects an explicit `for_any` selector, context rules and other guards. A bare `human` tag is not a universal actor-ownership guard in the action slot.

`retrieve_core_slots` obtains its eligible pool from that function and labels selected ordinary entries `eligible` with the frozen-core-slot source. It does not require an ordinary candidate's affected dimensions to be open before exposure. Retrieval matches do not prove that the candidate actor is the primary animal/plant, an authorized secondary person, or a contextually correct subject.

These raw requests are not universally explicit no-human requests. This audit therefore does **not** infer a global prohibition on background people. The concern is insufficient owner/context qualification and unopened-effect handling, not proof that every additional human would contradict every original request.

## Optional adoption: exact checked layers

### Direct ordinary helper probes

For each of the 26 exposed living-nonhuman action rows, the probe preserves the original baseline and appends one separately recorded diagnostic sentence built from the source's English action, with two distinguishing visual markers. It supplies a substantive candidate interpretation and literal relation evidence. **26/26 calls to `audit_candidate_interpretations` return no failures**, despite action being unopened.

This is not 26 full-audit passes. Some IDs also appear in creative augmentation, whose provenance/dimension rules apply at the complete audit. No physical review was supplied for those helper-only appended scenes.

`property_effects_allowed` checks property overlaps, not ordinary dimension openness. In these cases there is no action property lock, so it returns true. `audit_candidate_semantic_contracts` checks source-matching effects and property locks for chosen ordinary rows, but does not perform the same open-dimension subset check used for bundles. `audit_candidate_interpretations` likewise relies on property checks and literal/authored evidence. Its result alone cannot certify semantic equivalence of relation evidence.

Rejecting every ordinary candidate returns no helper failures for **12/12 living-nonhuman inputs**. This is a legitimate available response to the exposed noise, not evidence of missing action DATA.

### Complete auditor controls on the exact hedgehog EN pack

`full-composition-audit-checks.json` preserves every composed diagnostic and complete auditor output. Original pack, core, controls and locks are unchanged throughout.

1. **Reject all; unchanged baseline: PASS.** The original body-action review is reused for the identical prompt with the postcomposition phase correctly declared. Required semantic assertions and anchors remain bound
2. **Claim the subway-exit candidate as a baseline realization; unchanged baseline: PASS.** The declared relation evidence is the original nose–leaf phrase. This establishes that machine acceptance of selection metadata does not verify the source relation's semantic realization. It does not establish a wrong rendered image: prompt bytes and physical event are unchanged
3. **Same metadata, with an explicitly declared action authorial decision: FAIL**, `intent_lock_authorial_dimensions`. The direct dimension control proves action is unopened rather than treated as an allowed alias
4. **Append only the explicitly marked railway-crossing sentence to the exact baseline, with an honest unresolved contact/space review: FAIL**, `embodiment_preflight`. The sentence is: “The hedgehog steps out through an open train door onto an elevated railway platform far away from the garden fence.” The reviewer does not approve the unreconciled second event. No forged supported physical review was used

The added railway sentence separately passes the ordinary interpretation helper; it does **not** pass the complete auditor in this review. No unsafe introduced scene, provider rendering or bad pixels are claimed.

An additional augmentation-only control transforms the already sampled wyvern action with declared effects `["action"]`; it fails `intent_lock_creative_dimensions`. That result is saved in `augmentation-openness-control.json`. The transformed bundle path also contains an explicit dimensions-within-open check in source, but no separate bundle-adoption experiment was run here.

The procedural distinction is real: ordinary candidate interpretation, baseline realization, explicit authorial decisions and augmentation have different scope checks. Baseline realizations that genuinely match the requested event may reasonably remain selectable without authorizing a change. A repair needs to preserve those legitimate cases rather than simply banning every candidate in a closed dimension.

## Is there a source-supported DATA correction?

### Human guard experiment: narrows exposure, not yet a qualified fix

On detached copies of the 20 human-tagged exposed records, setting `for_any=["human"]` changes recomputed entry eligibility from true to false in **20/20** cases. No DATA file, runtime, input, index or pack was changed; no reranking was run. The experiment is in `hypothetical-human-guard-checks.json`.

This could reduce the observed noise, but is not yet a safe source-equivalent correction:

- Human event authorship establishes a human actor, not necessarily a human primary subject
- A primary-human selector can remove a legitimate requested human supporting action in an animal-primary mixed-owner scene
- The one intended mixed-owner control failed admission, so it cannot qualify this tradeoff
- It does not address nonhuman fantasy actions exposed for ordinary animals, ordinary-selection scope checking, or semantic verification of relation evidence
- None of these cores opens action, so they cannot establish a benefit to allowed new action adoption

**Decision: DEFER metadata changes.** Adding a `human` tag is redundant. Adding a stronger selector without qualified owner/positive controls risks suppressing authored legitimate uses.

### Natural-mechanism coverage is not a demonstrated missing-row defect

The base tags file already contains **33 animal-labelled or animal-admitted action rows**, including `pollinating`, `grazing`, `probing_tidepool`, flight, rest, foraging and multiple fantasy forms. This is a bounded base-file inventory, not a whole-extension count.

`bounded-source-coverage.json` records three source checks: `pollinating` requires `insect` and does not match the butterfly's primary subject tokens; `grazing` requires `herbivore` and does not match the tortoise's primary subject tokens; `probing_tidepool` has an animal selector intersection but is rejected by the complete eligibility function. All three are unexposed and action is unopened.

These are diagnostic vocabulary/context facts, not predeclared expected hits. Butterfly feeding does not demonstrate pollen transfer. Biting a particular attached leaf need not call for an added grazing variant; entering a pot is not necessarily a tidepool probe. Widening trait selectors to all animals or adding species synonyms just to surface these records is not justified. The preserved baselines already express the requested physical events without optional action adoption.

## Recommended next falsifiable evaluation

1. Keep this cohort frozen, including both scene08 admission failures and the translated-input denominator
2. Independently author an admitted owner matrix with animal-only, plant-only, primary animal plus explicitly requested secondary human action, primary human plus animal, and genuine nonhuman source actions. Do not infer source actor ownership solely from primary subject category
3. Include genuinely open action requests and explicitly protected events as separate strata. Freeze source/action ownership and expected applicability before retrieval
4. Compare producer exposure, selected-source effects, baseline-realization semantics, augmentation/ordinary scope checks and full composed audits separately. Test both correct rejection and preservation of legitimate source-aligned baseline choices
5. Only then qualify a narrowly scoped DATA guard or missing natural-mechanism row. Do not relax locks to raise candidate counts. Pixels remain a separate unperformed layer

## Files and reproduction

- `summary.json`: numeric results and all original failures
- `source-and-input-manifest.json`: source and frozen-input SHA-256 values
- `exposure-inventory.json`: all 16 input records, including the two failed runs
- `ordinary-action-helper-checks.json`: all 26 source/eligibility/selection-helper records
- `reject-all-helper-checks.json`: 12 abstention controls
- `hypothetical-human-guard-checks.json`: detached-entry guard experiment
- `full-composition-audit-checks.json`: four complete hedgehog auditor controls
- `augmentation-openness-control.json`: augmentation dimension control
- `bounded-source-coverage.json`: 33-row base inventory and three bounded reachability checks
- `reproduce.py`, `coverage_probe.py` and their stdout logs: exact executable commands/results

```sh
PYTHONDONTWRITEBYTECODE=1 python EVIDENCE_ROOT/nonhuman-exposure-review/reproduce.py
PYTHONDONTWRITEBYTECODE=1 python EVIDENCE_ROOT/nonhuman-exposure-review/coverage_probe.py
```

Both scripts write only review artifacts outside the repository. Input/source hash checks and a clean worktree verify the main run did not alter the frozen evidence or implementation. The diagnostic compositions and detached guards are intentionally source-exposed counterexamples, not independent natural-scene authoring or production changes.
