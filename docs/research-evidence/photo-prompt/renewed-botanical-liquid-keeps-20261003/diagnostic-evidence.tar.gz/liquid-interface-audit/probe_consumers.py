"""Offline current production helpers, source-bound actual index; not a public CLI or image run."""
from pathlib import Path
import copy,hashlib,json,subprocess,sys
R=Path('REPOSITORY_ROOT'); O=Path(__file__).resolve().parent; A=R/'skills/photo-prompt-image-generator/assets';sys.path.insert(0,str(A.parent/'scripts'))
import prompt_generator as pg
import audit_composed_prompt as ac
sha=lambda b:hashlib.sha256(b).hexdigest()
canon=lambda x:sha(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())
def save(name,x):(O/name).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
reg=pg.load_visual_obligation_registry(A/'photo_prompt_visual_obligations.json');idx=pg.load_visual_profile_index(A/'photo_prompt_visual_profile_index.json',reg)
data=pg.load_json(A/'photo_prompt_tags.json');data[pg.QUALITY_LAYERS_DATA_KEY]=pg.load_quality_layers(A/pg.QUALITY_LAYERS_FILENAME)
records=json.loads((O/'source-records.json').read_text()); by={x['id']:x for x in records}
positive_requests={'sw_wet':'Photograph one adult wearing a swimsuit: discrete water droplets rest on the swimsuit fabric; the fabric texture remains visible between the droplets.', 'ae_profile_held_tears_lips':'Make a close portrait of one adult actor with pooled tears with pressed lips.'}
negative_requests=[('sw_wet','Photograph wet fabric on a raincoat.'),('sw_wet','Photograph a close view of a swimsuit made darker by a continuous film of water.'),('sw_wet','Photograph tiny water droplets resting on a glass vessel.'),('sw_wet','Photograph a softly illuminated glossy swimsuit.'),('ae_profile_held_tears_lips','Photograph an actor with tear fluid visibly pooled along the lower eyelid margins and a relaxed open mouth.'),('ae_profile_held_tears_lips','Photograph a portrait with luminous eye catchlights and a small smile.'),('ae_profile_held_tears_lips','Photograph tear fluid pooled at the eyelid margins while the mouth corners form a small smile.'),('ae_profile_held_tears_lips','Photograph sorrow on a human face.')]
def resolve(request):
 res={'provenance':{'concept_lock':[request]}}
 sources=pg.candidate_pack_visual_obligation_request_sources(res,{})
 resolution=pg.resolve_visual_profile_hits(reg,sources,visual_profile_index=idx,adult_context=True)
 c=pg.candidate_pack_visual_obligations({pg.VISUAL_OBLIGATIONS_DATA_KEY:reg},res,{},None,visual_profile_resolution=resolution)
 return resolution,c
profile_tests=[]
for pid,request in positive_requests.items():
 resolution,c=resolve(request)
 assert c and pid in [o['id'] for o in c['obligations']],(pid,c)
 o=next(o for o in c['obligations'] if o['id']==pid);ev={f:r['must_mention_any'][0] for f,r in o['evidence_requirements'].items()}
 all_ev={x['id']:{f:r['must_mention_any'][0] for f,r in x['evidence_requirements'].items()} for x in c['obligations']}
 def audit(e):
  evidence={**all_ev,pid:e};return ac.audit_visual_obligations({'visual_obligations':c},{'visual_obligation_evidence':evidence},'. '.join(s for fields in evidence.values() for s in fields.values()))
 assert not audit(ev),audit(ev)
 substitutions={'sw_wet': [('component_1_phrase','The swimsuit cloth is uniformly darker from a continuous water film without separate beads.','continuous_film_is_not_selected_droplet_variant'),('component_1_phrase','Tiny water droplets remain on the glass held beside the swimsuit.','wrong_droplet_owner'),('component_2_phrase','A mirrorlike wet sheen hides every part of the underlying garment weave.','glare_without_between_droplet_texture')], 'ae_profile_held_tears_lips':[('component_1_phrase','Bright light catchlights shine inside both eyes while the lower eyelid edges remain dry.','catchlights_not_tear_pool'),('component_2_phrase','The same actor keeps a small raised-corner smile with visibly separated lips.','different_mouth_configuration')]}[pid]
 failures=[]
 for field in ev:
  changed={k:v for k,v in ev.items() if k!=field}; fs=audit(changed);assert any(f.get('field')==field for f in fs)
  failures.append({'kind':'missing_field','field':field,'failures':fs})
 for field,text,label in substitutions:
  changed={**ev,field:text};fs=audit(changed);assert any(f.get('field')==field for f in fs)
  failures.append({'kind':'replacement_without_declared_anchor','label':label,'field':field,'evidence':text,'failures':fs})
 p=next(p for p in reg['profiles'] if p['id']==pid); groups=p['semantics']['component_semantics']['groups']; terms=[g['any_terms'][0] for g in groups]
 component_tests=[{'text':'; '.join(terms),'match':pg.candidate_pack_visual_component_match(p,'; '.join(terms))}]
 for i,g in enumerate(groups):
  t='; '.join(x for j,x in enumerate(terms) if j!=i); m=pg.candidate_pack_visual_component_match(p,t);assert m != "component_semantics"
  component_tests.append({'omitted_group':g['id'],'text':t,'match':m})
 profile_tests.append({'id':pid,'request':request,'hits':resolution['hits'],'contract':c,'positive_evidence':ev,'full_positive_evidence':all_ev,'positive_failures':audit(ev),'negative_evidence_controls':failures,'component_match_controls':component_tests})
negative_tests=[]
for pid,request in negative_requests:
 res,c=resolve(request);hard=[h for h in res['hits'] if h['profile_id']==pid and h.get('hard_eligible')];assert not hard,(request,hard)
 negative_tests.append({'target':pid,'request':request,'target_hard_hits':hard,'all_hits':res['hits']})
# Context-token helper only. These carriers do not claim a validated frozen core or full candidate pack.
contexts={'primary_condensation':{'subject':by['cold_surface_condensation_boundary']['record']},'ordinary_human':{'subject':{'en':'an adult holding an ordinary dry cup','tags':['human','adult'],'kind':['human']}},'primary_water':{'subject':{'en':'an open water surface','tags':['water','environment'],'kind':['environment']}},'only_optional_condensation_texture':{'subject':{'en':'an ordinary adult portrait','tags':['human'],'kind':['human']},'texture':by['condensation_bead_coalescence_gradient_texture']['record']}}
context_tests=[]
for cid in ['condensation_beading_across_cold_boundary','cold_surface_observation_station','cold_condensation_test_surface','condensation_bead_coalescence_gradient_texture','natural_process_fixed_reference_capture']:
 row=by[cid]; outcomes={name:pg.compatible_with_slot_context(row['slot'],row['record'],picked,data) for name,picked in contexts.items()};assert outcomes=={'primary_condensation':True,'ordinary_human':False,'primary_water':False,'only_optional_condensation_texture':False},(cid,outcomes)
 context_tests.append({'id':cid,'slot':row['slot'],'outcomes':outcomes})
row=by['water_refraction_texture']; bubble_contexts={'water':contexts['primary_water'],'dry_portrait':contexts['ordinary_human']}; outcomes={k:pg.compatible_with_slot_context(row['slot'],row['record'],v,data) for k,v in bubble_contexts.items()};assert outcomes=={'water':True,'dry_portrait':False}
context_tests.append({'id':row['id'],'outcomes':outcomes})
projections=[]
for cid in ['ae_tears','ae_held_tears_lips','ae_smile_tears','sw_candidate_wet','ctx_cool_glass_trace','ctx_tea_sequence']:
 row=by[cid];projections.append({'id':cid,'source':pg.photo_candidate_semantics.semantic_source(row['record'],row['slot'],data.get('candidate_semantic_policy'))})
save('consumer-proof.json',{'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'actual_index_loaded':True,'index_sha256':sha((A/'photo_prompt_visual_profile_index.json').read_bytes()),'scope':'Current request-only exact resolver, actual hash-bound index, obligation projection, lexical component and literal-evidence audit; separate context compatibility and public semantic projection helpers. No query vectors, public CLI run, full frozen-core qualification, generation or pixels.','profile_tests':profile_tests,'negative_activation_controls':negative_tests,'context_carriers':contexts,'context_guard_controls':context_tests,'public_semantic_projections':projections,'counts':{'positive_profile_cases':len(profile_tests),'evidence_negative_cases':sum(len(x['negative_evidence_controls']) for x in profile_tests),'component_omission_cases':sum(len(x['component_match_controls'])-1 for x in profile_tests),'nonactivation_cases':len(negative_tests),'context_boolean_checks':sum(len(x['outcomes']) for x in context_tests)}})
print(json.dumps({'positive_profiles':2,'evidence_negative_cases':9,'component_omissions':4,'nonactivation_cases':8,'context_checks':22,'status':'all assertions passed'}))
