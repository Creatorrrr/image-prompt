"""Bounded source snapshot. Writes outside the repository only; no network calls."""
from pathlib import Path
import hashlib,json,subprocess,sys
R=Path('REPOSITORY_ROOT'); O=Path(__file__).resolve().parent; A=R/'skills/photo-prompt-image-generator/assets'
IDS='sw_wet ae_profile_held_tears_lips sw_candidate_wet cold_surface_condensation_boundary condensation_beading_across_cold_boundary cold_surface_observation_station cold_condensation_test_surface condensation_bead_coalescence_gradient_texture natural_process_fixed_reference_capture ctx_cool_glass_trace ctx_tea_sequence pouring_coffee matcha_latte_art liquid_holding_intent liquid_mercury_symbols ink_flowing_uphill_slow water_refraction_texture water_droplet_freeze dew_water_droplets_texture water_droplets_on_lens light_drizzle condensation_forming_pattern ae_tears ae_held_tears_lips ae_smile_tears'.split()
sha=lambda b:hashlib.sha256(b).hexdigest()
canon=lambda x:sha(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())
def save(name,x): (O/name).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def git(*args):return subprocess.check_output(['git',*args],cwd=R,text=True)
records=[]; paths=set()
for f in sorted(A.glob('*.json')):
 if 'index' in f.name:continue
 d=json.loads(f.read_text())
 for i,p in enumerate(d.get('profiles',[])):
  if p['id'] in IDS: records.append({'kind':'profile','id':p['id'],'file':str(f.relative_to(R)),'pointer':f'/profiles/{i}','canonical_sha256':canon(p),'record':p});paths.add(f)
 for slot,rows in d.get('slots',{}).items():
  for i,p in enumerate(rows):
   if p['id'] in IDS: records.append({'kind':'candidate','id':p['id'],'slot':slot,'file':str(f.relative_to(R)),'pointer':f'/slots/{slot}/{i}','canonical_sha256':canon(p),'record':p});paths.add(f)
assert len(records)==25 and set(IDS)=={x['id'] for x in records}
save('source-records.json',records)
source_names=['docs/research-evidence/photo-prompt/swimwear-20260909/research-report.md','docs/research-evidence/photo-prompt/swimwear-20260909/keyword-matrix.json','docs/research-evidence/photo-prompt/swimwear-20260909/candidate-drafts.json','docs/research-evidence/photo-prompt/acting-expression-semantics-20261003/RESEARCH.md','docs/research-evidence/photo-prompt/acting-expression-semantics-20261003/CATALOGUE.md','docs/research-evidence/photo-prompt/acting-expression-semantics-20261003/PROPOSED-DATA.json','docs/research-evidence/photo-prompt/contextual-appeal-20260929/research/academic/candidate-research.json','docs/research-evidence/photo-prompt/research_evidence.jsonl','skills/photo-prompt-image-generator/assets/photo_prompt_quality_layers.json']
(O/'source-documents').mkdir(exist_ok=True)
for name in source_names:
 f=R/name;paths.add(f); (O/'source-documents'/name.replace('/','__')).write_bytes(f.read_bytes())
# Original source records; these are earlier corpus definitions, not independent physics literature.
historical=[]
for commit,name,ids in [('cfd8e929','photo_prompt_research_extension.json',[x for x in IDS if x.startswith(('cold_','condensation_bead','natural_process_'))]),('c44816b3','photo_prompt_tags.json',['liquid_holding_intent','liquid_mercury_symbols','ink_flowing_uphill_slow','condensation_forming_pattern']),('ec6abe71','photo_prompt_tags.json',['water_droplet_freeze'])]:
 path='skills/photo-prompt-image-generator/assets/'+name;b=subprocess.check_output(['git','show',commit+':'+path],cwd=R);d=json.loads(b)
 h={'commit':git('rev-parse',commit).strip(),'path':path,'historical_file_sha256':sha(b),'records':[]}
 for slot,rows in d.get('slots',{}).items():
  for i,p in enumerate(rows):
   if p['id'] in ids:h['records'].append({'id':p['id'],'slot':slot,'pointer':f'/slots/{slot}/{i}','canonical_sha256':canon(p),'record':p})
 if commit=='ec6abe71':
  h['historical_usage_not_current_presets']=[{'id':p['id'],'en':p.get('en'),'filters':p.get('filters')} for p in d.get('presets',[]) if 'water_droplet_freeze' in json.dumps(p)]
 historical.append(h)
save('historical-source-records.json',historical)
sys.path.insert(0,str(A.parent/'scripts'));import prompt_generator as pg
reg=pg.load_visual_obligation_registry(A/'photo_prompt_visual_obligations.json'); idx=pg.load_visual_profile_index(A/'photo_prompt_visual_profile_index.json',reg)
profiles=[p for p in reg['profiles'] if p['id'] in IDS]
save('compiled-profiles.json',[{'id':p['id'],'canonical_sha256':canon(p),'profile':p} for p in profiles])
for name in ['prompt_generator.py','visual_profile_contracts.py','audit_composed_prompt.py','photo_candidate_semantics.py','photo_contracts.py','creative_controls.py']:
 paths.add(A.parent/'scripts'/name)
for name in ['photo_prompt_visual_obligations.json','photo_prompt_visual_profile_index.json','photo_prompt_semantic_index.json']:
 paths.add(A/name)
prior_names=['reflection-material-audit/README.md','light-medium-receiver-audit/REPORT.md','hair-material-alternative-audit/REPORT.md','food-object-process-audit/REPORT.md','containment-gap-review/report.md']
save('source-manifest.json',{'head':git('rev-parse','HEAD').strip(),'status_before':git('status','--short'),'scope':'25 complete current DATA records: 2 profiles and 23 candidate rows; lexical screening is not full-corpus validation','records':len(records),'profiles':len(profiles),'candidates':23,'actual_bound_visual_index_loaded':True,'loaded_registry_profile_count':len(reg['profiles']),'hash_convention':'Exact-byte SHA-256 for files; UTF-8 sorted-key compact ensure_ascii=False JSON for records','files':[{'path':str(f.relative_to(R)),'sha256':sha(f.read_bytes())} for f in sorted(paths) if f.exists()],'prior_reports_reviewed':[{'path':n,'sha256':sha((O.parent/n).read_bytes())} for n in prior_names]})
print(json.dumps({'records':len(records),'profiles':len(profiles),'registry_profiles':len(reg['profiles']),'bound_index_loaded':True}))
