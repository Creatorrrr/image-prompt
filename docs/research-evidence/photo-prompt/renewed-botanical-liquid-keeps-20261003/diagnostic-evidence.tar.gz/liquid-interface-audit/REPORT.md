# Liquid/interface DATA audit

## Result

**24 KEEP, 1 DEFER; no source proposal or implementation patch.**

The bounded selection contains **25 complete current DATA records: two hard profiles and 23 candidate rows**, pinned to `6b9381a0` (full hash in `source-manifest.json`). All 25 current records still equal the pinned revision and their initial snapshots. The actual production visual registry and its genuine hash-bound index load successfully; the loaded registry contains 1,510 profiles, but that is a loader count, not an audit-coverage claim.

The strongest apparent alternatives did **not** justify edits:

- `sw_wet` is explicitly a selected discrete-droplet-on-swimsuit variant with readable fabric between beads. Its original research separates visible wet state from optical finish, hidden composition and performance. A continuous wet film is physically plausible, but the inspected source does not make it an alternative inside this deliberately narrower two-component profile
- `ae_profile_held_tears_lips` explicitly selects lower-eyelid tear pooling **and** a compressed closed lip seam. Original research contains separate tears-only and tears-with-small-smile candidates. Those alternatives already have their own optional entries; they are not permission to delete the held-tears profile's declared lip relation
- The six sampled condensation/process rows retain their original `cfd8e929` English definitions, and their complete original records also match current records. Their dry/condensed boundary and same substrate are selected observation relationships, not universal claims about all condensation
- Against-gravity liquid, metallic liquid symbols, uphill ink and deliberately patterned condensation retain their original surreal/magic definitions from `c44816b3`. Treating them as normal capillarity or buoyancy would change their scene meaning

No new meniscus, foam, bubble, buoyancy or containment hard contract was invented. Screening surfaced foam-art, small-water-bubble and pouring candidates; none supplied an inspected hard gate with a source-declared alternate scene being rejected. This is not an exhaustive absence claim for all fluid-related DATA.

## Deferred ambiguity: frozen droplets

`texture:water_droplet_freeze` says only “frozen water droplet texture” in both language fields. Its origin commit `ec6abe71` uses the row in swimmer/splash, high-speed-strobe and underwater presets. Two of those contexts support the **motion-freeze** reading; the underwater context also shows why this is not enough to infer one narrowly specified present-day use.

The historical linkage is preserved in `historical-source-records.json`. These retired presets are provenance evidence, not a current routing recommendation. The audit found no measured current ice-versus-liquid failure, no declared alternative blocked by a current hard consumer, and no reason to invent ice or frozen-motion aliases. **DEFER wording clarification; no frozen patch.**

## Measured current consumer behavior

`probe_consumers.py` runs only local production helpers. `consumer-proof.json` contains complete inputs, returned contracts, evidence and failures.

- Two exact-request positives materialize their intended hard profiles and pass the literal evidence audit
- Nine evidence negatives reject the tested missing fields or replacement phrases: four omissions and five replacements covering continuous film in place of discrete beads, wrong droplet owner, glare replacing readable fabric, eye catchlights replacing tear pools and the wrong mouth configuration
- Four component omissions fail the complete `component_semantics` match. One swimsuit omission still returns `semantic_paraphrase_example` because “water droplets” is declared discovery vocabulary. This is **soft discovery**, not a complete component match or a hard-gate pass
- Eight broader/different requests produce no hard hit for the audited target profile: ordinary wet cloth, uniformly wet swimsuit, droplets on glass, glossy swimsuit, tears with open mouth, catchlights, tears with smile and generic sorrow
- Twenty-two context-helper checks retain source guards: five condensation/process support rows accept the established condensation primary context and reject the ordinary-human, generic-water and optional-condensation-texture-only carriers; the bubble/refraction texture accepts water context and rejects a dry portrait
- Public semantic projections preserve the sampled expression actor relation and the candidate effects/units. A textual contextual condition is not claimed to be an executable predicate or a completed adoption guard

The English held-tears request additionally activates the compatible existing `ae_profile_lip_press` profile through overlapping exact wording. The test retains that returned sibling obligation and supplies its evidence rather than dropping it to obtain a pass. This is an incidental runtime output, **not a third audited source profile** and not a new defect finding.

These controls measure literal anchors, exact activation and specific context helpers. A rejected replacement phrase does not prove that the consumer recognizes its complete physical meaning. Owner and saved-image requirements remain in the returned contracts, but no real image was reviewed. There was no full public CLI, vector retrieval evaluation, validated frozen-core generation or pixel qualification.

## Ownership, visibility and phase boundaries retained

- Swimsuit fabric, lower eyelid, outer glass, lens and environmental substrate remain different liquid owners
- The cold-glass hand relation selects a dry contact beside condensation; it is not wet skin or an implied temperature measurement
- The tea preparation relation deliberately stops **before** pouring and keeps the saucer dry. The original research explicitly chooses that phase. Ordinary active `pouring_coffee` is a separate optional event
- Foam-art subject wording does not impose microscopic bubble resolution, active pouring or a stability mechanism
- Water/refraction texture does not become a universal foam or buoyancy requirement
- Dew and drizzle are not conflated with lens droplets, optical glare, wet hair or reflected-light source ownership
- The original natural-process evidence ledger supports observation context/substrate/scale broadly. It does not independently validate condensation microphysics or a hidden time-lapse claim
- Original acting-expression and contextual research label specific photograph relations as authored proposals, not validated proof of inner emotion, sensuality, temperature or intent

## Prior work and rejected hypotheses

The audit first reviewed the prior wet-hair, reflection/material, light/medium/receiver, food/process and containment reports. Their completed fixes or KEEP conclusions were not reopened. In particular, wet-surface owner/dry-wet constraints, diffuse receiver alternatives, single food allocator, narrow nucleation/growth, alchemist apparatus and context-owned housing mitigation are excluded from the new 25-record selection.

Rejected hypotheses are explicit in `decisions.json`:

1. Broaden every “wet” profile to every physically wet state: rejected because selected source variants and exact activation matter
2. Require pressed lips for every tear scene: rejected because separate current candidates already preserve tears-only and smile alternatives
3. Turn uphill ink into ordinary capillary flow: rejected because it is source-declared surreal physics
4. Infer mercury chemistry from “mercury-like”: rejected as outside the candidate's visual comparison
5. Add universal containers, streams, menisci, resolved bubbles or buoyancy gates to broad beverage/texture rows: rejected as unsupported new authorship
6. Treat a retrieval/discovery label as complete mandatory visual evidence: rejected; soft fallback is recorded separately
7. Infer a general active-containment row from ordinary towel/tarp/catcher scenes: not reopened after the prior containment review

## Provenance and write boundary

All artifacts are outside `image-prompt/`. No repository source, test, runtime, semantic index, vector or publication was changed. There were no external APIs, installs, provider calls or images. Original research was read from the repository; its cited web pages were not reopened, so this is an internal source-consistency audit, not a new scientific literature review.

- `source-records.json`: 25 full records, exact pointers and canonical record hashes
- `compiled-profiles.json`: two production-compiled profiles and hashes
- `profile-index-record-hashes.json`: actual bound-index entry hashes for the two targets
- `source-manifest.json`: initial revision, whole-file hashes and prior reports read
- `historical-source-records.json` and `historical-comparison.json`: original rows, commit/file/record hashes and current comparisons
- `source-documents/`: byte copies of the inspected original research and quality layer sources
- `consumer-proof.json`: exact positive/negative helper results and all returned gates
- `runtime-manifest.json`: 11 locally imported repository module hashes plus merged-DATA and compiled-registry hashes
- `ending-verification.json`: pinned/current per-record equality, source-file stability and ending repository status
- `diagnostic-log.md`: two corrected harness assumptions, preserved rather than hidden
- `decisions.json` and `decision.json`: per-record KEEP/DEFER and empty proposal list

Stopping condition reached: bounded records, original sources, current contracts, measured controls and reproducible hashes are complete. A broad “all liquid semantics are correct” or render-quality conclusion is not supported.
