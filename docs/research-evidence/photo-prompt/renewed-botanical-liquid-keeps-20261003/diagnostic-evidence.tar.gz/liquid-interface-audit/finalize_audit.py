from pathlib import Path
import hashlib,json,subprocess,sys
R=Path('REPOSITORY_ROOT'); O=Path(__file__).resolve().parent; A=R/'skills/photo-prompt-image-generator/assets'
sha=lambda b:hashlib.sha256(b).hexdigest()
canon=lambda x:sha(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())
def save(n,x):(O/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def git(*a):return subprocess.check_output(['git',*a],cwd=R,text=True)
def pointed(d,p):
 for part in p.strip('/').split('/'):d=d[int(part)] if isinstance(d,list) else d[part]
 return d
records=json.loads((O/'source-records.json').read_text()); by={r['id']:r for r in records}; m=json.loads((O/'source-manifest.json').read_text())
source_refs={
 'sw_wet':['docs/research-evidence/photo-prompt/swimwear-20260909/keyword-matrix.json: sw_wet','docs/research-evidence/photo-prompt/swimwear-20260909/research-report.md: sections 3.7 and 4'],
 'ae_profile_held_tears_lips':['docs/research-evidence/photo-prompt/acting-expression-semantics-20261003/PROPOSED-DATA.json: ae_held_tears_lips','docs/research-evidence/photo-prompt/acting-expression-semantics-20261003/RESEARCH.md: section 7'],
 'ctx_cool_glass_trace':['docs/research-evidence/photo-prompt/contextual-appeal-20260929/research/academic/candidate-research.json: sfr26.cool-glass-trace'],
 'ctx_tea_sequence':['docs/research-evidence/photo-prompt/contextual-appeal-20260929/research/academic/candidate-research.json: sfr26.tea-sequence']}
rationale={
'sw_wet':'KEEP selected droplet-on-swimsuit variant, visible inter-droplet fabric and exact activation. Original source separates surface state from finish and hidden performance. No evidence that this selected contract must accept a uniform wet film or unrelated object droplets.',
'sw_candidate_wet':'KEEP selected same-garment surface relationship. Labels wet fabric/water droplets are discovery vocabulary, not a reason to hard-activate every wet surface. Appearance ownership does not certify water chemistry, waterproofness, transparency or latex.',
'ae_profile_held_tears_lips':'KEEP authored paired relation: lower-lid tear pool plus compressed closed lip seam. Original proposal explicitly makes these conjunctive and forbids universal tear-suppression or sobbing inference. No source-declared smile/open-mouth alternative belongs inside this selected profile.',
'ae_tears':'KEEP separate optional tears-only relation. Same-actor lower-lid moisture need not impose lip compression. Original catalogue excludes light catchlights and inferred grief/relief.',
'ae_held_tears_lips':'KEEP selected tears-plus-lip relation matching original proposal. Owner is frozen main actor; optional effects remain expression/face.expression.',
'ae_smile_tears':'KEEP distinct source-authored smile-and-tears alternative outside held-tears profile; preserve tears primary context and no automatic relief inference.',
'cold_surface_condensation_boundary':'KEEP bounded cold substrate and dry-to-condensed boundary. Exact original source row recovered unchanged; no universal claim that all condensation must have a dry region.',
'condensation_beading_across_cold_boundary':'KEEP coalescing-bead process tied to the established condensation specimen; do not rewrite as generic wetness, poured liquid or a completed uniformly wet state.',
'cold_surface_observation_station':'KEEP selected controlled dry/condensed-boundary observation setting. This is not a universal laboratory requirement for all dew or cold drinks.',
'cold_condensation_test_surface':'KEEP continuous dry material, separate beads and coalesced droplets on one test surface; no physical-state alternative was removed from the original authored source.',
'condensation_bead_coalescence_gradient_texture':'KEEP distinct texture role and established-primary condensation guard. Optional texture alone cannot satisfy this tested helper primary guard.',
'natural_process_fixed_reference_capture':'KEEP fixed substrate/scale/boundary/surrounding-state capture. Original evidence ledger supports natural-process observation broadly, not laboratory validation of condensation microphysics or a hidden time-lapse claim.',
'ctx_cool_glass_trace':'KEEP existing adult fingers selecting a dry external glass contact beside condensation; wet skin is not the same owner. Original research explicitly allows ordinary practical handling and forbids temperature-number/hidden-state claims.',
'ctx_tea_sequence':'KEEP before-pouring preparation with dry saucer and paused hand. Original source explicitly selects the pre-pour phase; active liquid transfer is a different event and must not be used as an alternative anchor.',
'pouring_coffee':'KEEP broad optional human pouring action. No mandatory meniscus, stream continuity, receiving cup, hand-count or fill-height contract is authored here; adding one would create new evidence obligations rather than recover an existing alternative.',
'matcha_latte_art':'KEEP foam-art drink subject; no profile forces resolved microscopic bubbles, active pouring or a particular foam-stability mechanism. Subject meaning alone does not support a new hard fluid contract.',
'liquid_holding_intent':'KEEP explicit surreal against-gravity deliberate liquid shape with meniscus/surface tension cue. Original source is a magical-physics option, not a claim of normal buoyancy or permission to remove the anomalous relation.',
'liquid_mercury_symbols':'KEEP mercury-like metallic liquid symbols and surreal scope. The comparison does not establish chemical mercury identity; no real-fluid manufacturing or safety claim is made.',
'ink_flowing_uphill_slow':'KEEP explicitly surreal uphill ink with strained meniscus. Do not silently recast it as ordinary capillarity, change the direction, or remove its magical scene ownership.',
'condensation_forming_pattern':'KEEP deliberate cold-glass beading pattern in the surreal family; it is not a mandatory intentional pattern for ordinary condensation.',
'water_refraction_texture':'KEEP optional water/refraction/tiny-bubble texture under existing water context. This is neither foam topology nor universal buoyancy; do not force bubbles into every liquid scene.',
'water_droplet_freeze':'DEFER ambiguous legacy frozen wording. Origin commit associates it with high-speed strobe/frozen-action splash, swimmer and underwater scenes, which suggests captured motion, but current text does not explicitly distinguish ice from motion freezing. No current consumer/actual image failure demonstrated and no source-declared blocked alternative established. Freeze no patch or new alias.',
'dew_water_droplets_texture':'KEEP optional dew-droplet surface texture. Do not upgrade it to chemical phase proof, require an air-temperature claim or mistake it for a lens artifact.',
'water_droplets_on_lens':'KEEP optical-surface owner explicit in the candidate; it is separate from droplets on swimsuit, glass or an environmental substrate. No source evidence supports merging these owners.',
'light_drizzle':'KEEP small visible atmospheric droplets and authored outdoor-compatible contexts. This does not force droplets to rest on the subject or create a surface-reflection obligation.'}
for cid in ['ae_tears','ae_held_tears_lips','ae_smile_tears']:source_refs[cid]=['docs/research-evidence/photo-prompt/acting-expression-semantics-20261003/CATALOGUE.md: '+cid,'docs/research-evidence/photo-prompt/acting-expression-semantics-20261003/PROPOSED-DATA.json: '+cid]
source_refs['sw_candidate_wet']=['docs/research-evidence/photo-prompt/swimwear-20260909/candidate-drafts.json: sw_candidate_wet']
hist=json.loads((O/'historical-source-records.json').read_text());hist_checks=[]
for h in hist:
 for x in h['records']:
  source_refs[x['id']]=[h['commit']+':'+h['path']+'#'+x['pointer']]
  hist_checks.append({'id':x['id'],'commit':h['commit'],'whole_row_unchanged':x['canonical_sha256']==by[x['id']]['canonical_sha256'],'original_en_unchanged':x['record'].get('en')==by[x['id']]['record'].get('en')})
decisions=[]
for r in records:
 decisions.append({k:r[k] for k in ['kind','id','file','pointer','canonical_sha256']}|{'disposition':'DEFER' if r['id']=='water_droplet_freeze' else 'KEEP','reason':rationale[r['id']],'source_evidence':source_refs.get(r['id'],[r['file']+'#'+r['pointer']+' (current original DATA meaning; no dedicated original research attribution identified in bounded search)']),'patch':None})
save('decisions.json',decisions);save('historical-comparison.json',hist_checks)
index=json.loads((A/'photo_prompt_visual_profile_index.json').read_text());save('profile-index-record-hashes.json',{'index_file_sha256':sha((A/'photo_prompt_visual_profile_index.json').read_bytes()),'registry_binding':index['registry_sha256'],'entries':[{'id':r['id'],'canonical_sha256':canon(index['entries'][r['id']])} for r in records if r['kind']=='profile']})
checks=[]
for r in records:
 now=pointed(json.loads((R/r['file']).read_text()),r['pointer']);pinned=pointed(json.loads(git('show',m['head']+':'+r['file'])),r['pointer']);checks.append({'id':r['id'],'snapshot_matches_current':canon(now)==r['canonical_sha256'],'snapshot_matches_pinned_head':canon(pinned)==r['canonical_sha256']})
assert all(c['snapshot_matches_current'] and c['snapshot_matches_pinned_head'] for c in checks)
sys.path.insert(0,str(A.parent/'scripts'));import prompt_generator as pg;import audit_composed_prompt
reg=pg.load_visual_obligation_registry(A/'photo_prompt_visual_obligations.json');pg.load_visual_profile_index(A/'photo_prompt_visual_profile_index.json',reg);data=pg.load_json(A/'photo_prompt_tags.json');data[pg.QUALITY_LAYERS_DATA_KEY]=pg.load_quality_layers(A/pg.QUALITY_LAYERS_FILENAME)
mods=set()
for module in list(sys.modules.values()):
 path=getattr(module,'__file__',None)
 if path:
  p=Path(path).resolve()
  if p.is_relative_to(A.parent/'scripts') and p.suffix=='.py':mods.add(p)
save('runtime-manifest.json',{'scope':'Locally imported repository runtime modules and production-loaded merged DATA; source-only/hash-bound loading, no external service calls','head':git('rev-parse','HEAD').strip(),'merged_dictionary_canonical_sha256':canon(data),'compiled_registry_canonical_sha256':canon(reg),'runtime_files':[{'path':str(p.relative_to(R)),'sha256':sha(p.read_bytes())} for p in sorted(mods)]})
save('ending-verification.json',{'head':git('rev-parse','HEAD').strip(),'status_after':git('status','--short'),'records':checks,'source_files':[{'path':x['path'],'before_sha256':x['sha256'],'after_sha256':sha((R/x['path']).read_bytes()),'unchanged':x['sha256']==sha((R/x['path']).read_bytes())} for x in m['files']],'actual_bound_visual_index_loaded':True})
save('decision.json',{'status':'BOUNDED_KEEP_DEFER_NO_PATCH','inspected_current_data_records':25,'profiles':2,'candidates':23,'keep':24,'defer':1,'frozen_proposals':[],'scope_exclusions':['previous wet-hair alternative','wet-surface reflection ownership','receiver material alternatives','food allocation','previously kept nucleation/growth and alchemist process contracts','routine containment redevelopment already audited'],'stopping_condition':'Original/current contract comparison, minimal source search, actual consumer positives/negatives and record/runtime hashes completed; no source-declared alternative blocked by these selected hard contracts was found. No further category expansion or invented alias.'})
print(json.dumps({'keep':24,'defer':1,'records_unchanged':len(checks),'source_files_unchanged':all(x['sha256']==sha((R/x['path']).read_bytes()) for x in m['files']),'runtime_modules':len(mods)}))
