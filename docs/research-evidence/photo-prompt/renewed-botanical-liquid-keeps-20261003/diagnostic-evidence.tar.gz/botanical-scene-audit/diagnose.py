import hashlib,json,sys
from pathlib import Path
O=Path(__file__).resolve().parent;R=O.parents[1]/'image-prompt';S=R/'skills/photo-prompt-image-generator';sys.path[:0]=[str(R),str(S/'scripts')]
import prompt_generator as pg
from tests import photo_prompt_fixtures as fixture
D=pg.load_runtime_data(); results=[]
old=json.loads((O/'consumer-cases.json').read_text()); entries={x['id']:(x['slot'],x['record']) for x in json.loads((O/'inspected-records.json').read_text()) if x['slot']}
new=[
 ('radicle_exact_domain_positive','a plant seed in radicle germination with a white radicle at its split seed coat','a controlled observation bench with moist substrate','the emerging radicle breaks through the seed coat into moist substrate'),
 ('radicle_canonical_candidate_labels','a germinating seed with the radicle visibly breaking through the seed coat','a controlled germination observation bench with moist substrate and fixed macro reference','the radicle physically breaking through the seed coat into moist substrate'),
 ('tree_exact_domain_in_background','a mature tree plant with an intact trunk and exposed woody roots','a garden beside a bench for radicle germination','the tree roots lie across the soil beside the trunk'),
 ('fern_grounded_setting_growth','a rosemary plant with straight attached leaves and a separate fern plant with a curled new frond','a damp garden after rain','the fern is slowly unfurling after rain beside the upright rosemary'),
]
for name,subject,setting,event in new:
 req=f'Photograph {subject} in {setting}, showing {event}, without people.'
 prompt=f'A botanical photograph shows {subject} in {setting}. Here {event}. The main plant and its immediate support remain clearly visible together. Soft side lighting reveals the attached surfaces and small moisture highlights, while a restrained background and a clear focal plane preserve the visible physical relationship at the center of the frame.'
 raw=fixture.core(req,subject=subject,setting=setting,event=event,baseline_prompt_en=prompt,interpreted_intent='A botanical plant growth and attachment study preserving the requested visible state.',visual_priorities=('the main plant and its immediate support','the attached surfaces and small moisture highlights'),anchor_evidence=(subject,event,'The main plant and its immediate support remain clearly visible together'))
 controls=pg.creative_controls.resolve(req,context={'subject_category':'nonhuman','no_people':True,'explicit_nonsexual':False},overrides={'sensual':0,'fetish':0,'surreal':0,'creativity':1},seed=0);raw['creative_controls_sha256']=controls['canonical_sha256']
 core=pg.normalize_authorial_core(raw,request_envelope=pg.normalize_request_envelope(fixture.envelope(req)),creative_control_snapshot=controls)
 old.append({'case':{'id':name},'core':core,'controls':controls})
for row in old:
 core=row['core'];controls=row['controls'];contract,picked=pg.frozen_core_context(D,core,controls); checks={}
 for id in ['unfurling_after_rain','radicle_breaking_seed_coat','moist_germination_substrate_surface']:
  slot,entry=entries[id];others={k:v for k,v in picked.items() if k!=slot};subject_tokens=pg.entry_tags(picked['subject'])|pg.entry_kinds(picked['subject']);scoped={domain for tag,domain in pg.INTENT_SCOPED_ENTRY_DOMAIN_TAGS.items() if tag in pg.entry_tags(entry)|pg.entry_kinds(entry)}
  checks[id]={'slot_block_reason':pg.slot_block_reason(D,slot,contract),'entry_block_reason':pg.entry_block_reason(entry,slot,contract),'subject_kind_guard':not entry.get('for_any') or bool(set(entry['for_any'])&subject_tokens),'required_domains':sorted(scoped),'core_domains':contract['intent_constraints']['domains'],'domain_guard':not scoped or bool(scoped&set(contract['intent_constraints']['domains'])),'slot_context_guard':pg.compatible_with_slot_context(slot,entry,others,D),'eligible':pg.core_slot_entry_eligible(D,core,contract,picked,slot,entry)}
 result={'case':row['case']['id'],'core':core,'controls':controls,'picked':picked,'checks':checks}
 if row['case']['id'] in {n[0] for n in new}:
  slots,binding,_=pg.retrieve_core_slots(D,core,controls);result['retrieved_targets']={slot:[x['entry_id'] for x in v['candidates'] if x['entry_id'] in entries] for slot,v in slots.items()};result['retrieval_binding']=binding
 results.append(result)
 print(row['case']['id'],{k:{p:v[p] for p in ['domain_guard','slot_context_guard','eligible']} for k,v in checks.items()},flush=True)
(O/'guard-diagnosis.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n')
manifest=json.loads((O/'manifest-before.json').read_text());diff={rel:{'before':sha,'now':hashlib.sha256((R/rel).read_bytes()).hexdigest()} for rel,sha in manifest['files'].items() if hashlib.sha256((R/rel).read_bytes()).hexdigest()!=sha};(O/'diagnosis-source-verification.json').write_text(json.dumps({'file_deltas':diff},indent=2)+'\n');print('source deltas',diff)
