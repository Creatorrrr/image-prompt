# Botanical growth, structure and attachment DATA audit

## Result

**No DATA patch proposed.** Reviewed 22 bounded records: 21 optional candidates and one selected cross-owner wind-response profile. Preserve their authored meanings. Retain two reproducible advisory retrieval/guard diagnoses for a separately scoped runtime design review.

The successful frozen run used revision `6b9381a0585049cbaca1522dde405b4e6203b295`. All 22 record hashes and every file hash in the focused manifest stayed unchanged through the main and diagnosis runs. The parent's lattice integration landed during audit preparation; the successful baseline is the subsequent clean checkout, not a claim that pending changes were reverted. No repository/source/index edits, provider calls, installs, publishing, images, or runtime patches occurred.

The excluded natural-environment families (glacier, cumulonimbus, wetland, dune, krummholz, and previously audited old-growth) were not counted or proposed again. No epiphyte, climbing-vine, graft, tendril-attachment, rhizome, or stolon profile was invented to fill sparse coverage.

## 1. Fern applicability does not bind the actor

Current candidate `action.unfurling_after_rain` declares `for_any: [plant]` and `requires_any_tags: [fern]`. Its EN/KO labels, aliases, keywords and embedding consistently describe the fern-unfurling-after-rain variant. The same complete record exists in its introduction commit `d7911037b1ec485e0aed32650ab7f4bc9975b3f9`.

Actual current production results:

- Fern growth, English request and English core: eligible; action retrieved
- Equivalent Korean request, English frozen core: eligible; action retrieved
- Upright rosemary leaves, no fern: ineligible; action absent
- Same upright rosemary, a separate fern only in the background setting: eligible; action retrieved
- Explicitly depicted fern growing beside rosemary: eligible; action retrieved

The coherent background-only counterexample preserves an upright rosemary subject and droplet-bearing event. It does not describe that subject as unfurling. Adding the unrelated background fern is enough for the authored lexical prerequisite. This is a demonstrated advisory actor-applicability mismatch, **not** a hard obligation, accepted adoption, or pixel failure. All ten main diagnostic cores emitted zero direct hard profiles.

A superficially plausible one-key DATA replacement does not fix it. `guard-key-counterexample.json` tests replacing `requires_any_tags` with `requires_primary_any_tags` in memory only. `picked_core_context_tokens` includes `location` alongside `subject`, `medium`, and `genre`; both guards therefore admit the background-fern case. The public current path excludes the candidate's own action slot when checking prerequisites, but still includes the frozen setting.

**Disposition:** keep the candidate's genuine fern meaning; defer actor-aware suitability. Do not remove “fern,” add subject string exceptions, mutate its action scope, or claim the primary-tag key binds the botanical owner. The current schema knob tested here does not express the missing relation.

## 2. Declared germination scene is gated by a narrow inferred domain

The seven research-extension records for seed/radicle, action, bench, substrate and general process support are byte-equivalent at record level to their original `cfd8e929b470446d0bbfbc08d1e4076710219c67` introduction. Their narrow visible seed-coat/radicle/substrate meaning is not a proposed new botanical interpretation.

The source candidates declare `natural_process`. The quality source's `/intent_routing/domains/20/aliases` natural-process aliases include the adjacent phrase `radicle germination` and Korean `유근 발아`, among other process-specific phrases. The frozen-core consumer infers domains from typed core text; it does not simply copy authored candidate domains to the scene.

Observed production results:

- Natural English seed-emergence request with `a plant seed in germination with a white radicle at its split seed coat`: normalizes successfully, plant category inferred, radicle/substrate prerequisite passes, inferred domains `[]`, natural_process domain guard fails, target action/substrate not eligible or retrieved
- Equivalent Korean request with the same English frozen meaning: the same result
- Current canonical subject, action and location EN strings together: core normalizes; domain guard still fails; target cluster absent. Its bench contains “germination,” so the tested local prerequisite passes; missing inferred domain is the isolated failure
- Explicit `radicle germination` in the seed subject: domain guard and local prerequisite pass; intended subject, action, location and substrate are actually retrieved
- Negative control: a mature tree with a background bench for `radicle germination`: domain and prerequisite also pass; the radicle action is actually retrieved even though the tree event is exposed woody roots resting on soil
- Mature-tree scenes without that exact domain phrase: target radicle action remains ineligible and absent

`guard-diagnosis.json` records separate slot block, entry block, subject-kind, declared required domains, inferred core domains, domain guard, slot-context guard and final eligibility for every diagnostic. The matched domain is not assumed from a request-language synonym or from a registry label.

This establishes **schema preflight success followed by advisory eligibility/retrieval failure for declared scene vocabulary**, and an owner-confusion counterexample when the domain is admitted. It is not a malformed-core failure. The canonical-string and exact-domain cases are source-guided controls, not independent recall or quality benchmarks.

**Disposition:** preserve source semantics and current domain boundaries pending a runtime/guard design decision. No phrase list, new routing field, tag broadening, or threshold change is frozen. Adding aliases might repair the measured positive but does not resolve source-to-owner binding; the background-only negative must remain part of any later qualification. The absence of a hard profile here is deliberate, not evidence that a new germination hard profile should be added.

## 3. Lichen/moss is a composite candidate, not an established alternative defect

`surface_material.lichen_bark_surface` is unchanged from its introduction commit. EN label abbreviates to lichen-covered bark, while KO names both lichen and moss, the embedding explicitly includes moss, and aliases include mossy bark. The full candidate is a specific bark-surface combination; the source does not explicitly declare a lichen-only versus moss-only disjunction that a later hard contract has lost.

Current lichen-and-moss bark scene retrieves it. An explicit lichen exclusion makes the same candidate ineligible and absent; ordinary moss candidates remain available. `consumer-projections.json` preserves both localized labels and the actual optional semantic source. Do not broaden this into all mossy surfaces or turn moss/lichen into a biological equivalence. **KEEP**, with full-candidate review still necessary when optional inspiration is considered.

## 4. Selected wind profile correctly retains attachment and owner duties

`rb_shared_wind_response` and its candidate are a selected manifestation involving loose hair, a free jacket hem and exposed leaves. The original `realistic-background-20260912/visual-catalog.md` section at lines 327–339 names those owners, attachment points, compatible response and material/occlusion differences; it explicitly calls this a design/mechanics hypothesis without direct empirical evidence.

The production compiler retains all three component/evidence groups and all three render gates. Each gate requires its named owner visibly present; leaves keep their own stems and stiffness. The runtime expression remains `definition_with_optional_label`; no botanical noun is a hard alias. Exact full definition activates the selected profile. Generic EN plant-wind prose, generic KO plant-wind prose and fallen-leaf/jacket co-presence controls do not. The source candidate sentence matches the semantic paraphrase helper but is not a direct hard alias.

This is not a generic botany profile accidentally requiring a person. Broad plant scenes are not forced to grow hair or acquire clothing. **KEEP** the complete selected manifestation; do not drop the hair/hem owners to make it a general wind profile.

## Other bounded KEEP decisions

- `ancient_tree`: giant/old-tree structure is consistent across EN/KO; no hard growth or support process is invented
- `fern_unfurling`: intentionally narrow subject/state after rain; do not turn its broad discovery aliases into permission to replace another locked plant
- `mycelium_forest_floor`: keep fungal/leaf-litter candidate identity. `plant` is a coarse project routing category here, not a scientific kingdom claim
- `rice_seedling_tray`: nursery-tray/ready-for-transplanting meaning remains consistent with the Korean rice-transplanting context
- `resting_moss`, `covered_dew`, `wind_swaying`, `sprouting_soil`: ordinary optional state/action variants; no claim that every plant can perform them or that their retrieval authorizes changing its frozen event
- `moss_attached_surface`, `mossy_concrete_surface`: preserve substrate/attachment specificity; neither is a universal plant-support hard relation
- General fixed-reference capture, process-boundary check and fixed scale prop: remain optional monitoring variants; do not require every botanical photograph to be a bench experiment
- `nature_habitat_subject_state_advisory`: visible habitat contact/shelter/weather relationship remains advisory and explicitly avoids inferred hidden ecological function

## Evidence boundaries and reproducibility

`inspected-records.json` supplies all source paths, pointers, full records and canonical hashes. Fourteen original authored records are preserved with introduction revisions, full original-file hashes and equality checks. `research-links.json` contains the one directly matched existing research row: NPS soil/biocrust monitoring supports general process-boundary/fixed-reference design. It does **not** independently establish seed physiology or fern/lichen biology. Other candidate-specific external literature was not inferred or freshly researched. Current source records are the authority for this internal consistency audit.

Main run: 10 normalized core/control cases, 60 explicit target eligibility checks, actual same-slot BM25F retrieval over the unchanged complete corpus, 21 candidate projections, one compiled profile, and 5 direct-activation/component controls. Additional diagnosis: 4 new normalized cases and retrievals, plus decomposed guards across all 14 cases. No fabricated vectors, provider calls or public-index replacements. The separate one-key guard experiment is hypothetical and is labeled accordingly.

An initial fixture-preparation attempt used an untranslated English exclusion for a Korean-only request and was rejected by existing grounding validation. `preparation-failure.log` is preserved; the corrected fixtures use the explicitly bound no-people creative context. This preparation error is not a product bug or counted positive/negative result.

No full public CLI, composed adoption, runtime image request, original-pixel review or independent aesthetic preference was measured. There is no accepted DATA change to qualify further. Any continuation should keep the exact frozen cores, source hashes, positive controls and owner-confusion negatives rather than tailoring synonyms to make these probes pass.
