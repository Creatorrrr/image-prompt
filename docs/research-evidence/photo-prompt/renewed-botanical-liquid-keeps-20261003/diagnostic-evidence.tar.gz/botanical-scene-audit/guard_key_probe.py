import copy,hashlib,json,sys
from pathlib import Path
O=Path(__file__).resolve().parent;R=O.parents[1]/'image-prompt';S=R/'skills/photo-prompt-image-generator';sys.path.insert(0,str(S/'scripts'))
import prompt_generator as pg
D=pg.load_runtime_data();entry=pg.candidate_pack_slot_entry_by_id(D,'action','unfurling_after_rain'); alternate=copy.deepcopy(entry); alternate['requires_primary_any_tags']=alternate.pop('requires_any_tags')
rows=[]
for r in json.loads((O/'consumer-cases.json').read_text()):
 if r['case']['id'] not in ['fern_growth_en','fern_growth_ko','rosemary_without_fern','rosemary_with_background_fern']:continue
 core=r['core'];contract,picked=pg.frozen_core_context(D,core,r['controls']);others={k:v for k,v in picked.items() if k!='action'}
 rows.append({'case':r['case']['id'],'current_guard':entry['requires_any_tags'],'hypothetical_primary_guard':alternate['requires_primary_any_tags'],'current_eligible':pg.core_slot_entry_eligible(D,core,contract,picked,'action',entry),'hypothetical_eligible':pg.core_slot_entry_eligible(D,core,contract,picked,'action',alternate),'picked_primary_context':sorted(pg.picked_core_context_tokens(others))})
(O/'guard-key-counterexample.json').write_text(json.dumps({'purpose':'Hypothetical schema-knob counterexample only. Not a proposed patch or index-backed variant.','cases':rows},ensure_ascii=False,indent=2)+'\n')
for r in rows:print(r['case'],r['current_eligible'],r['hypothetical_eligible'])
# Freeze all current authored JSON/source/test helper hashes to aid independent replay.
paths=list((S/'assets').glob('*.json'))+list((S/'scripts').glob('*.py'))+[R/'tests/photo_prompt_fixtures.py']
manifest={str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(paths)}
(O/'all-runtime-source-hashes.json').write_text(json.dumps(manifest,indent=2)+'\n')
