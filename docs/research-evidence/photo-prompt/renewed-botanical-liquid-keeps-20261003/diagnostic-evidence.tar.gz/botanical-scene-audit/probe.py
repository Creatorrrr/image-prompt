"""Read-only source/production-function audit; all outputs stay outside checkout."""
import copy,hashlib,json,os,subprocess,sys
from pathlib import Path
O=Path(__file__).resolve().parent; R=O.parents[1]/'image-prompt'; S=R/'skills/photo-prompt-image-generator'; A=S/'assets'
sys.path[:0]=[str(R),str(S/'scripts')]
import prompt_generator as pg
import photo_candidate_semantics as pcs
from tests import photo_prompt_fixtures as fixture

def h(b):return hashlib.sha256(b).hexdigest()
def digest(v):return h(json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())
def git(*args):return subprocess.check_output(['git','-C',str(R),*args])
def write(name,v): (O/name).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
files=[S/'SKILL.md',S/'references/maintenance.md',S/'scripts/prompt_generator.py',S/'scripts/photo_candidate_semantics.py',S/'scripts/visual_profile_contracts.py',R/'tests/photo_prompt_fixtures.py',A/'photo_prompt_tags.json',A/'photo_prompt_research_extension.json',A/'photo_prompt_reactorprompt_visual_relations_extension.json',A/'photo_prompt_realistic_background_extension.json',A/'photo_prompt_visual_obligations_realistic_background.json',A/'photo_prompt_quality_layers.json',A/'photo_prompt_visual_profile_index.json',A/'photo_prompt_semantic_index.json',A/'photo_prompt_visual_obligations_reactorprompt.json',R/'docs/research-evidence/photo-prompt/research_evidence.jsonl',R/'docs/research-evidence/photo-prompt/realistic-background-20260912/visual-catalog.md',R/'docs/research-evidence/photo-prompt/extension-maintenance/photo_prompt_research_extension_metadata_20260929.json']
manifest={'head':git('rev-parse','HEAD').decode().strip(),'status':git('status','--short').decode(),'files':{str(p.relative_to(R)):h(p.read_bytes()) for p in files},'record_hash_recipe':'SHA256 UTF-8 json.dumps(ensure_ascii=False, sort_keys=True, separators=(comma,colon))','limits':'No provider calls, source edits, index edits, CLI runs or rendered images. Current pending lattice changes intentionally retained.'}
write('manifest-before.json',manifest)
selected=['ancient_tree','fern_unfurling','mycelium_forest_floor','rice_seedling_tray','resting_moss','covered_dew','wind_swaying','sprouting_soil','unfurling_after_rain','moss_attached_surface','mossy_concrete_surface','lichen_bark_surface','seed_radicle_emergence_macro','radicle_breaking_seed_coat','controlled_germination_observation_bench','natural_process_fixed_reference_capture','natural_process_boundary_check_step','fixed_process_scale_reference_prop','moist_germination_substrate_surface','nature_habitat_subject_state_advisory','rb_shared_wind_response_candidate']
rows=[]
for file in files:
 if not file.name.endswith('.json') or 'extension_metadata' in file.name:continue
 d=json.loads(file.read_text())
 for slot,rs in d.get('slots',{}).items():
  for i,r in enumerate(rs):
   if r.get('id') in selected:rows.append({'path':str(file.relative_to(R)),'pointer':f'/slots/{slot}/{i}','slot':slot,'id':r['id'],'record_sha256':digest(r),'record':r})
assert len(rows)==len(selected),(len(rows),len(selected))
profile_path=A/'photo_prompt_visual_obligations_realistic_background.json'
p_index,p=next((i,p) for i,p in enumerate(json.loads(profile_path.read_text())['profiles']) if p['id']=='rb_shared_wind_response')
rows.append({'path':str(profile_path.relative_to(R)),'pointer':f'/profiles/{p_index}','slot':None,'id':p['id'],'record_sha256':digest(p),'record':p})
write('inspected-records.json',rows)
# Capture original authored rows from introduction commits, with complete original file byte hashes.
origins=[]
for commit,filename,ids in [('cfd8e929b470446d0bbfbc08d1e4076710219c67','photo_prompt_research_extension.json',selected[12:19]),('d7911037','photo_prompt_tags.json',['fern_unfurling','mycelium_forest_floor','rice_seedling_tray','unfurling_after_rain','mossy_concrete_surface','lichen_bark_surface']),('22b070c0','photo_prompt_tags.json',['moss_attached_surface'])]:
 path='skills/photo-prompt-image-generator/assets/'+filename; raw=git('show',f'{commit}:{path}'); d=json.loads(raw)
 found=[]
 for slot,rs in d['slots'].items():
  for i,r in enumerate(rs):
   if r.get('id') in ids:found.append({'pointer':f'/slots/{slot}/{i}','slot':slot,'id':r['id'],'record_sha256':digest(r),'record':r,'current_record_equal':r==next(x['record'] for x in rows if x['id']==r['id'])})
 origins.append({'commit':git('rev-parse',commit).decode().strip(),'path':path,'full_file_sha256':h(raw),'rows':found})
write('original-authored-records.json',origins)
research=[]
for i,line in enumerate((R/'docs/research-evidence/photo-prompt/research_evidence.jsonl').read_text().splitlines(),1):
 r=json.loads(line)
 if set(r.get('candidate_ids',[]))&set(selected): research.append({'path':'docs/research-evidence/photo-prompt/research_evidence.jsonl','line':i,'record_sha256':digest(r),'record':r})
write('research-links.json',research)
D=pg.load_runtime_data(); registry=D[pg.VISUAL_OBLIGATIONS_DATA_KEY]; index=D[pg.VISUAL_PROFILE_INDEX_DATA_KEY]
compiled=next(p for p in registry['profiles'] if p['id']=='rb_shared_wind_response')
write('compiled-wind-profile.json',compiled)
projections=[]
for r in rows:
 if r['slot'] is None:continue
 slot=r['slot'];entry=pg.candidate_pack_slot_entry_by_id(D,slot,r['id'])
 public,_=pg.candidate_pack_summarize_slot_candidate(D,slot,{'id':r['id']})
 projections.append({'id':r['id'],'slot':slot,'runtime_record_sha256':digest(entry),'runtime_equals_authored':entry==r['record'],'semantic_source':pcs.semantic_source(entry,slot,D['candidate_semantic_policy']),'public_summary':public,'associated_bundles':[b for b in D.get('candidate_bundles',[]) if r['id'] in b.get('member_candidates',[])]})
write('consumer-projections.json',projections)
cases=[
 {'id':'fern_growth_en','request':'Photograph a fern frond unfurling after rain, with no people.','subject':'a botanical fern plant with one curled new frond','setting':'a damp forest floor after rain','event':'the fern is slowly unfurling after rain with attached droplets'},
 {'id':'fern_growth_ko','request':'비 뒤 고사리 새순이 펼쳐지는 모습을 찍어 줘. 사람은 제외해.','subject':'a botanical fern plant with one curled new frond','setting':'a damp forest floor after rain','event':'the fern is slowly unfurling after rain with attached droplets'},
 {'id':'rosemary_without_fern','request':'Photograph upright rosemary leaves after rain, with no people.','subject':'a rosemary plant with straight attached narrow leaves','setting':'a damp garden after rain','event':'the plant carries droplets along its attached narrow leaves'},
 {'id':'rosemary_with_background_fern','request':'Photograph upright rosemary leaves after rain, with a fern in the background and no people.','subject':'a rosemary plant with straight attached narrow leaves','setting':'a damp garden after rain with a separate fern behind the rosemary','event':'the rosemary carries droplets along its attached narrow leaves'},
 {'id':'radicle_growth_en','request':'Photograph a germinating seed with an emerging root in moist substrate, with no people.','subject':'a plant seed in germination with a white radicle at its split seed coat','setting':'a germination observation bench with moist substrate','event':'the emerging radicle breaks through the seed coat into moist substrate'},
 {'id':'radicle_growth_ko','request':'사람 없이 발아 중인 씨앗의 종피를 뚫고 나오는 유근과 젖은 기질을 찍어 줘.','subject':'a plant seed in germination with a white radicle at its split seed coat','setting':'a germination observation bench with moist substrate','event':'the emerging radicle breaks through the seed coat into moist substrate'},
 {'id':'mature_tree_negative','request':'Photograph a mature tree trunk and exposed roots, with no people.','subject':'a mature tree plant with an intact trunk and exposed woody roots','setting':'a shaded garden bed with damp soil','event':'the tree roots lie across the soil beside the trunk'},
 {'id':'mature_tree_background_germination','request':'Photograph a mature tree trunk beside a germination bench, with no people.','subject':'a mature tree plant with an intact trunk and exposed woody roots','setting':'a shaded garden beside a germination observation bench','event':'the tree roots lie across the soil beside the trunk'},
 {'id':'lichen_and_moss_positive','request':'Photograph lichen and moss attached to tree bark, with no people.','subject':'a tree plant with lichen and moss attached to fissured bark','setting':'a shaded forest floor','event':'lichen crust and moss cushions follow separate patches of the same bark'},
 {'id':'moss_only_exclusion','request':'Photograph moss on tree bark, without lichen or people.','subject':'a tree plant with moss cushions on fissured bark','setting':'a shaded forest floor','event':'moss cushions spread across the rough bark','exclusions':['lichen','people']},
]
results=[]
for case in cases:
 subject,setting,event=case['subject'],case['setting'],case['event']; req=case['request']
 prompt=f'A botanical photograph shows {subject} in {setting}. Here {event}. The main plant and its immediate support remain clearly visible together. Soft side lighting reveals the attached surfaces and small moisture highlights, while a restrained background and a clear focal plane preserve the visible physical relationship at the center of the frame.'
 raw=fixture.core(req,subject=subject,setting=setting,event=event,baseline_prompt_en=prompt,interpreted_intent='A plant structure and attachment study preserving the requested visible growth stage.',visual_priorities=('the main plant and its immediate support','the attached surfaces and small moisture highlights'),exclusions=tuple(case.get('exclusions',[])),anchor_evidence=(subject,event,'The main plant and its immediate support remain clearly visible together'))
 controls=pg.creative_controls.resolve(req,context={'subject_category':'nonhuman','no_people':True,'explicit_nonsexual':False},overrides={'sensual':0,'fetish':0,'surreal':0,'creativity':1},seed=0)
 raw['creative_controls_sha256']=controls['canonical_sha256']
 core=pg.normalize_authorial_core(raw,request_envelope=pg.normalize_request_envelope(fixture.envelope(req)),creative_control_snapshot=controls)
 contract,picked=pg.frozen_core_context(D,core,controls)
 checks={}
 for target in ['unfurling_after_rain','radicle_breaking_seed_coat','moist_germination_substrate_surface','lichen_bark_surface','wind_swaying','sprouting_soil']:
  r=next(x for x in rows if x['id']==target);entry=pg.candidate_pack_slot_entry_by_id(D,r['slot'],target)
  checks[target]=pg.core_slot_entry_eligible(D,core,contract,picked,r['slot'],entry)
 # Real current same-slot BM25F retrieval with all authored candidates, never injected query vectors.
 slots,binding,_=pg.retrieve_core_slots(D,core,controls)
 target_ids={r['id'] for r in rows}
 actual={slot:[x['entry_id'] for x in val['candidates'] if x['entry_id'] in target_ids] for slot,val in slots.items()}
 actual={k:v for k,v in actual.items() if v}
 wind_sources=[{'source':'concept_lock','text':req,'polarity':'required'},{'source':'authorial_core_baseline','text':prompt,'polarity':'advisory'}]
 hard=pg.candidate_pack_auto_visual_obligation_matches(registry,wind_sources)
 result={'case':case,'core':core,'controls':controls,'context':contract['intent_constraints'],'picked':picked,'eligibility':checks,'retrieved_selected_audit_ids':actual,'retrieval_binding':binding,'hard_profile_ids':list(hard)}
 results.append(result);print(case['id'],checks,actual,flush=True)
write('consumer-cases.json',results)
# Test selected wind contract separately from unselected plant-only applicability.
wind_probes=[]
for name,text in [('explicit_full_definition',compiled['semantics']['definition']),('generic_en','A plant sways in the wind while its leaves stay attached to the stems.'),('generic_ko','바람에 흔들리는 식물의 잎은 줄기에 붙어 있다.'),('same_labels_missing_owners','Loose fallen leaves lie near a jacket on a table.'),('source_candidate_en','Loose hair, the free jacket hem and exposed leaves respond compatibly to the breeze, each retaining its own attachment and stiffness.')]:
 sources=[{'source':'concept_lock','text':text,'polarity':'required'}]
 hard=pg.candidate_pack_auto_visual_obligation_matches(registry,sources)
 wind_probes.append({'case':name,'text':text,'hard_ids':list(hard),'target_hard':'rb_shared_wind_response' in hard,'component_match':pg.candidate_pack_visual_component_match(compiled,text)})
write('wind-contract-controls.json',wind_probes)
end={'head':git('rev-parse','HEAD').decode().strip(),'status':git('status','--short').decode(),'files':{str(p.relative_to(R)):h(p.read_bytes()) for p in files}}
end['file_deltas']={k:{'before':manifest['files'][k],'after':v} for k,v in end['files'].items() if manifest['files'][k]!=v}
end['record_deltas']=[]
for r in rows:
 v=json.loads((R/r['path']).read_text())
 for comp in r['pointer'].split('/')[1:]:v=v[int(comp)] if isinstance(v,list) else v[comp]
 if digest(v)!=r['record_sha256']:end['record_deltas'].append(r['id'])
write('verification.json',end)
print('DONE',len(rows),'records',len(results),'cases',len(wind_probes),'wind controls',end['file_deltas'],end['record_deltas'])
