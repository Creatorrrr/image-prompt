# Botanical growth and attachment audit

This is a bounded read-only DATA audit, with 21 optional candidate records and one specifically selected wind-response profile. It excludes glacier, cumulonimbus, wetland, dune, krummholz, and the previously audited old-growth profile. All outputs are outside the checkout.

`probe.py` reads the real current production loader and indexes, creates normalized source-guided diagnostic cores, and calls the actual eligibility, same-slot retrieval, semantic projection, profile compilation, and direct-activation functions. It does not call a provider or mutate the source/index. It is not a public-CLI, composition, pixel, or artistic-quality test.

- `inspected-records.json`: all 22 complete source records, JSON pointers, and canonical record hashes
- `original-authored-records.json`: 14 original introduction-commit records and original full-file hashes
- `research-links.json`: exact directly linked existing research record; no external citations independently re-fetched
- `manifest-before.json`, `verification.json`: source/runtime/index hashes and checkout state before/after
- `consumer-projections.json`: source identity, EN/KO public summaries, semantic ownership, optional adoption and bundle associations
- `consumer-cases.json`: ten fully frozen diagnostic cores/controls, actual eligibility and retrieval results
- `compiled-wind-profile.json`, `wind-contract-controls.json`: selected-contract components, evidence duties and gates, plus five positive/negative activation controls
- `guard-diagnosis.json`, `diagnose.log`: four additional normalized controls, actual retrieval, and decomposed domain/local-guard results
- `guard-key-counterexample.json`: existing primary-tag key fails to distinguish an unrelated background fern (hypothetical in-memory check only)
- `all-runtime-source-hashes.json`: final complete authored JSON and runtime Python hashes
- `probe.log`: execution output
- `preparation-failure.log`: retained initial fixture-preparation failure from using the English exclusion `people` in a Korean-only request; no source defect is inferred. The corrected fixture binds explicit no-people meaning in its creative context instead of inventing an untranslated literal exclusion

Run from the repository: `PYTHONDONTWRITEBYTECODE=1 .venv/bin/python ../daylong-progress-20261002/botanical-scene-audit/probe.py`

All fixtures are source-guided maintenance diagnostics, not actual user image requests or blind holdouts. No proposal is implied by eligibility alone.
