#!/usr/bin/env bash
set -u
OUT=<WORKSPACE>/daylong-progress-20261002/current-full-regression
cd "$OUT/snapshot"
date -u +%FT%TZ > "$OUT/start-time.txt"
{ time -p env -u GEMINI_API_KEY -u GOOGLE_API_KEY PYTHONDONTWRITEBYTECODE=1 <WORKSPACE>/image-prompt/.venv/bin/python -m unittest discover -s tests -p 'test*.py' -v > "$OUT/full-suite.log" 2>&1; } 2> "$OUT/timing.txt"
STATUS=$?
printf '%s\n' "$STATUS" > "$OUT/full-suite.exit"
date -u +%FT%TZ > "$OUT/end-time.txt"
git status --porcelain=v1 > "$OUT/snapshot-status-after.txt"
exit "$STATUS"
