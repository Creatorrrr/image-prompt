# Fresh pinned full-regression evidence

Commit: 3c3b3a649afc04a5b39abc23a0e57084ba34fec2. This result does not cover later main/upstream commits.

## Result

All 136 discovered test modules completed in fresh sequential subprocesses. Effective aggregate: **1221 tests, 10 assertion failures, 1 error, 0 skips**. Exactly all 1221 discovered IDs are represented once after replacing the two environment-affected module results with their full successful reruns. No missing, unexpected, or duplicate IDs. The suite remains red solely at the previously observed missing-asset checks; no new failing test identities occurred.

This is complete module-isolated coverage, **not a completed monolithic unittest run**. The monolithic attempt ended with signal 9 / exit 137 after 2647.97 seconds during space-semantics; no aggregate was emitted. The cause of the kill was not established. Its log and timing remain intact.

The initial per-module pass completed 1221 tests with 10 failures and 4 errors. Three illustration errors were solely missing snapshot-relative `.venv/bin/python`, distinct from historical hash drift. A symlink to the existing repository environment supplied that expected path. Both entire affected modules then passed unchanged. This confirms the three prior stale-hash methods pass at this pin. Original error logs remain intact.

## Historical failures retained

- Korean emotional: 3 subtest failures on `reference.is_file()`, absent external JPEG
- Makeup reference: 1 failure (zero frozen cores instead of five) and 1 FileNotFoundError for source observation
- Poverty: 3 subtest failures on `result_path.is_file()`, absent result PNGs
- Rare photo: 3 subtest failures on `artifact.is_file()`, absent run request-envelope JSONs

All 11 retained failure/error labels match the earlier full-suite log. Previous Korean/makeup/rare baseline reproductions are documented in full-suite-baseline-diagnosis/REPORT.md. Poverty classification matches the same old traceback but is not a new original-baseline reproduction.

## Reproduction and timing

Module-isolated start: 2026-10-03T02:57:15.218731+00:00; original module pass finish: 2026-10-03T04:00:05.318555+00:00; recovery finish: 2026-10-03T04:05:58.874525+00:00.

Original module process wall-time sum: 3769.986 seconds. Recovery wall-time sum: 333.163 seconds. Exact per-module commands/timings and test file hashes are in module-suite-results.json and interpreter-recovery-results.json. `run.sh` records the monolithic command; `run-module-suite.py` and `run-interpreter-recovery.py` record the recovery procedure. Both GEMINI_API_KEY and GOOGLE_API_KEY were removed from every test subprocess environment; bytecode generation was disabled. No installations or provider calls were performed.

No source, tests, assertions, golden expectations, or missing assets were modified or fabricated. The temporary `.venv` symlink was removed after the recovery runs; final tracked/untracked worktree status is clean. The first launcher attempt never ran a test because `/usr/bin/time` was absent; it is separately preserved, and Bash built-in time was used for the actual monolithic attempt.

## Evidence

`summary.json` selects the effective logs without discarding earlier attempts. `discovered-test-ids.json` provides the exact full discovery inventory. `historical-comparison.json` preserves matching and resolved failure names. Raw files remain private. `export/` contains normalized copies with local workspace/runtime and personal Downloads paths replaced; `export-manifest.json` records SHA-256 for each raw and normalized copy. Normalization changes paths only, not outcomes.
