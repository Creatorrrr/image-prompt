import datetime, hashlib, json, os, pathlib, subprocess, time
out=pathlib.Path(__file__).resolve().parent
root=out/'snapshot'
python='<WORKSPACE>/image-prompt/.venv/bin/python'
env=os.environ.copy()
for key in ('GEMINI_API_KEY','GOOGLE_API_KEY'): env.pop(key,None)
env['PYTHONDONTWRITEBYTECODE']='1'
logs=out/'interpreter-recovery-logs';logs.mkdir(exist_ok=True)
files=[root/'tests'/name for name in ('test_subculture_illustration_contract_v1.py', 'test_subculture_illustration_universal_scene_v3.py')]
manifest={'commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'strategy':'Rerun the two modules affected by snapshot-relative .venv absence, after adding a symlink to the existing repository virtualenv. No source or test changes.','test_files':[str(f.relative_to(root)) for f in files],'results':[]}
for i,file in enumerate(files):
 command=[python,'-m','unittest','discover','-s','tests','-p',file.name,'-v']
 start=time.monotonic()
 with (logs/(file.stem+'.log')).open('w') as log:
  p=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 result={'test_file':str(file.relative_to(root)),'sha256':hashlib.sha256(file.read_bytes()).hexdigest(),'command':command,'exit_code':p.returncode,'seconds':time.monotonic()-start}
 manifest['results'].append(result)
 (out/'interpreter-recovery-progress.json').write_text(json.dumps(manifest,indent=2)+'\n')
 print(f'{i+1}/{len(files)} {file.name}: exit {p.returncode}, {result["seconds"]:.2f}s',flush=True)
manifest['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
(out/'interpreter-recovery-results.json').write_text(json.dumps(manifest,indent=2)+'\n')
